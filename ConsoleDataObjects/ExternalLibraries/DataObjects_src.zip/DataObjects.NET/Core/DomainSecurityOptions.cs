// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Attributes;

namespace DataObjects.NET
{
  /// <summary>
  /// Enumeration of possible security options for a <see cref="Domain"/>.
  /// <seealso cref="Domain.SecurityOptions"/>
  /// </summary>
  [Flags]
  public enum DomainSecurityOptions
  {
    /// <summary>
    /// Maximal security level.
    /// Value is <see langword="0"/>. 
    /// </summary>
    Maximal = 0,
    /// <summary>
    /// Unauthenticated <see cref="Session"/>s creation is allowed
    /// (see <see cref="Session.Authenticate"/>).
    /// It will be impossible to create
    /// a <see cref="Session"/> without specifying 
    /// <see cref="Session.Authenticate">authentication 
    /// parameters</see> for any callers except 
    /// <see cref="DataObject"/>s and <see cref="DataService"/>s
    /// while this option is turned off.
    /// Value is <see langword="0x1"/>. 
    /// </summary>
    AllowCreateUnauthenticatedSessions = 0x1,
    /// <summary>
    /// Unauthenticated <see cref="Session"/>s creation is allowed
    /// (see <see cref="Session.Authenticate"/>) for .NET Remoting
    /// callers. 
    /// This option has no effect if 
    /// <see cref="AllowCreateUnauthenticatedSessions"/> is off 
    /// (<see cref="AllowCreateUnauthenticatedSessions"/> option
    /// overrides the value of this option in this case).
    /// We <see langword="strongly"/> recommend to disable this
    /// option if you're going to marshal the <see cref="Domain"/>
    /// instance via .NET Remoting.
    /// Value is <see langword="0x2"/>. 
    /// </summary>
    AllowCreateUnauthenticatedSessionsRemotely = 0x2,
    /// <summary>
    /// Access to <see cref="Domain.ConnectionInfo"/> allowed.
    /// Value is <see langword="0x10"/>. 
    /// </summary>
    AllowAccessToConnectionInfo       = 0x10,
    /// <summary>
    /// Access to <see cref="Domain.Driver"/> allowed.
    /// Value is <see langword="0x20"/>. 
    /// </summary>
    AllowAccessToDriver               = 0x20,
    /// <summary>
    /// Standard security level. 
    /// Normally use of this security level is enough in
    /// almost any circumstances.
    /// Value is <see langword="0x1"/>. 
    /// </summary>
    Standard                          = 0x1,
    /// <summary>
    /// Anything is allowed.
    /// Value is <see langword="0x1FFFFFFF"/>. 
    /// </summary>
    Minimal = 0x1FFFFFFF,
  }
}
