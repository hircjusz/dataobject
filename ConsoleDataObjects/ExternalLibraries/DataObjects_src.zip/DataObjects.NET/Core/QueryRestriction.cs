// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Runtime.Serialization;
using DataObjects.NET;
using DataObjects.NET.ObjectModel;

namespace DataObjects.NET
{
  /// <summary>
  /// An abstract base class for any query restriction.
  /// You can't create instances of this type or its descendants manually.
  /// <seealso cref="DataObjectCollectionQueryRestriction"/>
  /// <seealso cref="Query"/>
  /// <seealso cref="SqlQuery"/>
  /// </summary>
  #if (!NoMBR)
  public abstract class QueryRestriction: MarshalByRefObject
  #else
  public abstract class QueryRestriction
  #endif
  {
  }
}
