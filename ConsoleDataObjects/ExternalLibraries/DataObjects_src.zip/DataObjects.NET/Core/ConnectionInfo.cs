// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections.Specialized;
using System.Globalization;
using System.IO;
using System.Runtime.Serialization;
using System.Text;
using System.Text.RegularExpressions;
using DataObjects.NET.Exceptions;

namespace DataObjects.NET
{
  /// <summary>
  /// Holds information allowing to connect to the database 
  /// (<see cref="Url">connection URL</see>) and provides simple 
  /// way to access <see cref="Url">connection URL</see>
  /// parts.
  /// </summary>
  [Serializable]
  public sealed class ConnectionInfo: Object, ISerializable
  {
    private string url = "";
    /// <summary>
    /// Gets or sets the connection URL.
    /// </summary>
    public  string Url {
      get {return url;}
      set {ParseURL(value);}
    }
    
    private string protocol = "";
    /// <summary>
    /// Gets or sets the protocol part 
    /// (e.g. "mssql" is the protocol part of URL "http://admin:password@localhost/database").
    /// </summary>
    public  string Protocol {
      get {return protocol;}
      set {protocol = value; OnChanged(EventArgs.Empty);}
    }
    
    private string host = "";
    /// <summary>
    /// Gets or sets the host part 
    /// (e.g. "localhost" is the host part of URL "http://admin:password@localhost/database").
    /// </summary>
    public  string Host {
      get {return host;}
      set {host = value; OnChanged(EventArgs.Empty);}
    }
    
    private int port = 0;
    /// <summary>
    /// Gets or sets the port part 
    /// (e.g. 40000 is the port part of URL "http://admin:password@localhost:40000/database").
    /// </summary>
    public  int Port {
      get {return port;}
      set {port = value; OnChanged(EventArgs.Empty);}
    }
    
    private string database = "";
    /// <summary>
    /// Gets or sets the database name part 
    /// (e.g. "database" is the database name part of URL "http://admin:password@localhost/database").
    /// </summary>
    public  string Database {
      get {return database;}
      set {database = value; OnChanged(EventArgs.Empty);}
    }
    
    private string user = "";
    /// <summary>
    /// Gets or sets the user name part 
    /// (e.g. "admin" is the user name part of URL "http://admin:password@localhost/database").
    /// </summary>
    public  string User {
      get {return user;}
      set {user = value; OnChanged(EventArgs.Empty);}
    }
    
    private string password = "";
    /// <summary>
    /// Gets or sets the password part 
    /// (e.g. "password" is the password part of URL "http://admin:password@localhost/database").
    /// </summary>
    public  string Password {
      get {return password;}
      set {password = value; OnChanged(EventArgs.Empty);}
    }
    
    private NameValueCollection _params = null;
    /// <summary>
    /// Gets or sets the additional connection parameters.
    /// (e.g. "?param1=value1&amp;param2=value2" is the additional connection parameters 
    /// of URL "http://admin:password@localhost/database?param1=value1&amp;param2=value2").
    /// </summary>
    public  NameValueCollection Params  
    {
      get {return _params;}
      set {_params = value; OnChanged(EventArgs.Empty);}
    }
    
    
    /// <summary>
    /// Splits URL into parts (protocol, host, port, database, user, password) and set all
    /// derived values to the corresponding properties of the instance.
    /// </summary>
    /// <param name="url">URL to split</param>
    /// <remarks>
    /// The expected URL format is as the following:
    /// proto://[[user[:password]@]host[:port]]/database_name.
    /// Note that the empty URL would cause an exception.
    /// </remarks>
    private void ParseURL(string url) 
    {
      try {
        string tUrl = url;
        if (tUrl.Length==0) 
          tUrl=":///";      

        Regex URLextractor = new Regex(
          @"^(?'proto'[^:]*)://"+
          @"((?'username'[^:@]*)"+
          @"(:(?'password'[^@]*))?@)?"+
          @"(?'host'[^:/]*)"+
          @"(:(?'port'\d+))?"+
          @"/(?'database'[^?]*)?"+
          @"(\?(?'params'.*))?");
        Match URLmatch = URLextractor.Match(tUrl);
        if (!URLmatch.Success)
          throw new InvalidConnectionUrlException("This URL cannot be parsed.");
          
        string tUser =     UrlDecode(URLmatch.Result("${username}"));
        string tPassword = UrlDecode(URLmatch.Result("${password}"));
        string tDatabase = UrlDecode(URLmatch.Result("${database}"));
        string tHost =     UrlDecode(URLmatch.Result("${host}"));
        string tProtocol = UrlDecode(URLmatch.Result("${proto}"));
        int    tPort = 0;
        
        if (URLmatch.Result("${port}").Length!=0) 
          tPort = Int32.Parse(URLmatch.Result("${port}"));
        if (tPort<0 || tPort>65535)
          throw new InvalidConnectionUrlException("This URL cannot be parsed.");

        string tParams = URLmatch.Result("${params}");
        string[] aParams = tParams.Split('&');
        NameValueCollection nvParams = new NameValueCollection();
        if (tParams!=null && tParams!="") {
          foreach (string sPair in aParams) {
            string[] aNameValue = sPair.Split(new char[] {'='},2);
            if (aNameValue.Length!=2)
              throw new InvalidConnectionUrlException("This URL cannot be parsed.");
            nvParams.Add(UrlDecode(aNameValue[0]), UrlDecode(aNameValue[1]));  
          }
        }

        this.url = url;
        user     = tUser;
        password = tPassword;
        database = tDatabase;
        host     = tHost;
        protocol = tProtocol;
        port     = tPort;
        _params  = nvParams;
      }
      catch (Exception e) {
        if (e is InvalidConnectionUrlException)
          throw;
        else
          throw new InvalidConnectionUrlException("This URL cannot be parsed.",e);
      }
      OnChanged(EventArgs.Empty);
    }


    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    public ConnectionInfo()
    {
      ParseURL("");
      //We pass an empty URL to the constructor.
      //Does it mean anything valuable?
    }
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="url">Connection URL.</param>
    public ConnectionInfo(string url)
    {
      ParseURL(url);
    }
        
    // Event handlers, etc...

    /// <summary>
    /// This event is raised on any parameter change.
    /// </summary>
    public event EventHandler Changed;

    /// <summary>
    /// Event "activator". 
    /// </summary>
    /// <param name="e">Always <see cref="EventArgs.Empty"/>.</param>
    private void OnChanged(EventArgs e) {
      if (Changed!=null)
        Changed(this,e);
    }
    
    private string UrlDecode (string str) 
    {
      return UrlDecode(str, Encoding.UTF8);
    }

    private string UrlDecode(string s, Encoding e)
    {
      int len = s.Length;
      UrlDecoder decoder = new UrlDecoder(len, e);
      for (int i=0; i<len; i++) {
        char c = s[i];
        if (c=='+') {
          c = ' ';
        } else if (c=='%' && i<(len-2)) {
          if (s[i+1]=='u' && i<(len-5)) {
            int num3 = HexToInt(s[i+2]);
            int num4 = HexToInt(s[i+3]);
            int num5 = HexToInt(s[i+4]);
            int num6 = HexToInt(s[i+5]);
            if ((num3<0 || num4<0) || (num5<0 || num6<0))
              goto loc_1;
            c = (char)((ushort)((((num3 << 12) | (num4 << 8)) | (num5 << 4)) | num6));
            i += 5;
            decoder.AddChar(c);
            continue;
          }
          int num7 = HexToInt(s[i+1]);
          int num8 = HexToInt(s[i+2]);
          if (num7>=0 && num8>=0) {
            byte num9 = (byte)((num7 << 4) | num8);
            i += 2;
            decoder.AddByte(num9);
            continue;
          }
        }
      loc_1:
        if ((c & 0xff80)=='\0')
          decoder.AddByte((byte) c);
        else
          decoder.AddChar(c);
      }
      return decoder.GetString();
    }
    
    private int HexToInt(char h)
    {
      if (h>='0' && h<='9')
        return h-'0';
      if (h<'a' || h>'f') {
        if (h>='A' && h<='F')
          return h-'A'+'\n';
        return -1;
      }
      return h-'a'+'\n';
    }



    // Serializer/deserializer.

    /// <summary>
    /// Serializer.
    /// </summary>
    /// <param name="info"><see cref="SerializationInfo"/> object.</param>
    /// <param name="context"><see cref="StreamingContext"/> object.</param>
    public void GetObjectData(SerializationInfo info, StreamingContext context)
    {
      info.AddValue("Url",url);
    }

    /// <summary>
    /// Deserialization constructor.
    /// </summary>
    /// <param name="info"><see cref="SerializationInfo"/> object.</param>
    /// <param name="context"><see cref="StreamingContext"/> object.</param>
    private ConnectionInfo(SerializationInfo info, StreamingContext context)
    {
      ParseURL(info.GetString("Url"));
    }
    

    #region UrlDecoder
    
    private class UrlDecoder
    {
      // Fields
      private int _bufferSize;
      private byte[] _byteBuffer;
      private char[] _charBuffer;
      private Encoding _encoding;
      private int _numBytes;
      private int _numChars;
      
      // Methods
      internal UrlDecoder(int bufferSize, Encoding encoding)
      {
        this._bufferSize = bufferSize;
        this._encoding = encoding;
        this._charBuffer = new char[bufferSize];
      }
      
      internal void AddByte(byte b)
      {
        if (this._byteBuffer == null)
          this._byteBuffer = new byte[this._bufferSize];
        this._byteBuffer[this._numBytes++] = b;

      }
      
      internal void AddChar(char ch)
      {
        if (this._numBytes > 0)
          this.FlushBytes();
        this._charBuffer[this._numChars++] = ch;
      }
      
      private void FlushBytes()
      {
        if (this._numBytes > 0) {
          this._numChars += this._encoding.GetChars(this._byteBuffer, 0, this._numBytes, this._charBuffer, this._numChars);
          this._numBytes = 0;
        }
      }
      
      internal string GetString()
      {
        if (this._numBytes > 0)
          this.FlushBytes();
        if (this._numChars > 0)
          return new string(this._charBuffer, 0, this._numChars);
        return string.Empty;
      }
    }

    #endregion

  }
}
