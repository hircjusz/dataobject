// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Diagnostics;

namespace DataObjects.NET.Diagnostics
{
  /// <summary>
  /// Default trace provider that posts messages to the attached debugger.
  /// </summary>
  public sealed class DebugOutputProvider: ITraceProvider
  {
    private static string cCategory = "DataObjects.NET diagnostic trace";
    
    /// <summary>
    /// Writes an entry to the event log.
    /// </summary>
    /// <param name="context">Trace context.</param>
    public void LogEvent(TraceContext context)
    {
      string message = context.Message;
      if (!message.EndsWith("\n"))
        message = message + "\n";
      Debugger.Log(0, cCategory, message);
    }
    
    // Constructors
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    public DebugOutputProvider()
    {
    }
  }
}
