// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;

namespace DataObjects.NET.Attributes
{
  /// <summary>
  /// Base class for any DataObjects.NET attribute.
  /// This attribute shouldn't be used directly.
  /// </summary>
  [Serializable]
  public class DataObjectAttribute: Attribute
  {
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    public DataObjectAttribute()
    {
    }
  }
}