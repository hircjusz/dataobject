// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;

namespace DataObjects.NET.Attributes
{
  /// <summary>
  /// Specifies the action type that should be performed with the reference\collection property 
  /// on removal of its target. By default <see cref="AutoFixupAction.Clear"/> action
  /// is performed for any reference\collection property.
  /// </summary>
  /// <remarks>
  /// <note>This attribute can be applied to any persistent property that may hold a reference 
  /// (<see cref="DataObject"/>, <see cref="DataObjectCollection"/>).</note>
  /// <para>
  /// <example>Example:
  /// <code lang="C#">
  ///  public abstract class Article: DataObject
  ///  {
  ///    [ItemType(Author)]
  ///    [PairTo(typeof(Author),"Articles")]
  ///    [AutoFixup(AutoFixupAction.Block)] // !!!
  ///    public abstract DataObjectCollection Authors {get; set;}
  ///    ...
  ///
  ///    [AutoFixup(AutoFixupAction.None)] // !!!
  ///    public abstract Publisher Publisher {get; set;}
  ///    ...
  ///  }
  /// </code>
  /// </example>
  /// </para>
  /// <seealso cref="AutoFixupAction"/>
  /// <seealso cref="CollatableAttribute"/>
  /// </remarks>
  [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field, 
    AllowMultiple = true, Inherited = true)]
  [Serializable]
  public class AutoFixupAttribute: DataObjectAttribute
  {
    private AutoFixupAction action = AutoFixupAction.Clear;
    
    /// <summary>
    /// Gets or sets the <see cref="AutoFixupAction"/> that should be performed 
    /// to maintain the referential integrity.
    /// </summary>
    public AutoFixupAction Action 
    {
      get {return action;}
      set {action = value;}
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    public AutoFixupAttribute() 
    {
    }
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="action">The <see cref="AutoFixupAction"/> that should be performed to maintain the referential integrity.</param>
    public AutoFixupAttribute(AutoFixupAction action) 
    {
      this.action = action;
    }
  }
}
