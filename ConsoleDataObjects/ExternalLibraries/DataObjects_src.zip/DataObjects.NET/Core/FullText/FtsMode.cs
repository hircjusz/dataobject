// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Attributes;

namespace DataObjects.NET.FullText
{
  /// <summary>
  /// Enumerates <see cref="FtsCondition"/> full-text search modes.
  /// <seealso cref="Query"/>
  /// <seealso cref="Query.Text"/>
  /// <seealso cref="Query.FtsCondition"/>
  /// <seealso cref="SqlQuery"/>
  /// <seealso cref="SqlQuery.FtsCondition"/>
  /// </summary>
  public enum FtsMode
  {
    /// <summary>
    /// Condition is a simple search string.
    /// Microsoft SQL Server driver uses FREETEXTTABLE rowset function
    /// to perform search in this case.
    /// </summary>
    FreeText,
    /// <summary>
    /// Condition is a real full-text search condition.
    /// Microsoft SQL Server driver uses CONTAINSTABLE rowset function
    /// to perform search in this case.
    /// </summary>
    Condition,
    /// <summary>
    /// Condition is a LIKE expression. This is the slowest full-text
    /// search mode, but nevertheless it should work even there is no
    /// full-text indexing service available.
    /// </summary>
    LikeExpression
  }
}
