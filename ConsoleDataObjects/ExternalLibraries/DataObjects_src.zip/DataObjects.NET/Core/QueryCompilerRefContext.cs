// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;
using DataObjects.NET.ObjectModel;

namespace DataObjects.NET
{
  internal class QueryCompilerRefContext:
    IEnumerable
  {
    private ArrayList stack;

    public int Count {
      get {
        return stack.Count;
      }
    }

    public QueryCompilerRefLayer this[int index] {
      get {
        return (QueryCompilerRefLayer)stack[index];
      }
    }
    
    public IEnumerator GetEnumerator()
    {
      return stack.GetEnumerator();
    }

    public void Push(QueryCompilerRefLayer layer)
    {
      stack.Add(layer);
    }

    public QueryCompilerRefLayer Pop()
    {
      int cnt = stack.Count;
      QueryCompilerRefLayer e = this[cnt-1];
      stack.RemoveAt(cnt-1);
      return e;
    }

    public QueryCompilerRefLayer PopToLevel(int level)
    {
      int cnt = stack.Count;
      if (cnt<=level)
        return null;
      QueryCompilerRefLayer e = this[level];
      stack.RemoveRange(level, cnt-1);
      return e;
    }

    public QueryCompilerRefLayer Peek()
    {
      return TopEntry;
    }

    public QueryCompilerRefLayer TopEntry {
      get {
        return (QueryCompilerRefLayer)stack[stack.Count-1];
      }
    }

    public QueryCompilerRefLayer PreTopEntry {
      get {
        return (QueryCompilerRefLayer)stack[stack.Count-2];
      }
    }

    public QueryCompilerRefLayer BottomEntry {
      get {
        return (QueryCompilerRefLayer)stack[0];
      }
    }

    public void Clear()
    {
      stack.Clear();
    }

    public QueryCompilerRefContext Clone()
    {
      return new QueryCompilerRefContext(this);
    }


    // Constructors
    
    public QueryCompilerRefContext()
    {
      stack = new ArrayList();
    }

    public QueryCompilerRefContext(QueryCompilerRefContext source)
    {
      stack = (ArrayList)source.stack.Clone();
    }
  }
}
