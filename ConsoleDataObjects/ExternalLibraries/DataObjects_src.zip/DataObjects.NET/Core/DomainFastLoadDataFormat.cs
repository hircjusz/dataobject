// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Attributes;

namespace DataObjects.NET
{
  /// <summary>
  /// Enumeration of possible <see cref="DataObject.FastLoadData"/>
  /// serialization formats. 
  /// Note that any of these formats is automatically
  /// recognized by DataObjects.NET while reading 
  /// <see cref="DataObject.FastLoadData"/>, so you can freely
  /// switch between these formats.
  /// </summary>
  public enum DomainFastLoadDataFormat
  {
    /// <summary>
    /// Default <see cref="DataObject.FastLoadData"/> format.
    /// The synonym of <see cref="Comprehensive"/> format.
    /// Value is <see langword="2"/>. 
    /// </summary>
    Default = 3,
    /// <summary>
    /// Compact <see cref="DataObject.FastLoadData"/> format.
    /// We recommend using this format with production-ready applications.
    /// Value is <see langword="1"/>. 
    /// </summary>
    Compact = 1,
    /// <summary>
    /// Comprehensive <see cref="DataObject.FastLoadData"/> format.
    /// This format provides some additional information with stored
    /// <see cref="DataObject.FastLoadData"/> - e.g. field names.
    /// We recommend using this format during application development,
    /// and switching to the <see cref="Compact"/> format on
    /// production-ready applications.
    /// Value is <see langword="2"/>. 
    /// </summary>
    Comprehensive = 2,
    Compromise = 3
  }
}
