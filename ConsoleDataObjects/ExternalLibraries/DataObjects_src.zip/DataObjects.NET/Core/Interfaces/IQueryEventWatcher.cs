// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;
using System.Runtime.Serialization;
using DataObjects.NET.Attributes;
using DataObjects.NET.Serialization;
using DataObjects.NET.Security;
using DataObjects.NET.Security.Permissions;

namespace DataObjects.NET
{
  /// <summary>
  /// An interface that should be implemented by <see cref="DataServiceType.Shared">Shared</see> <see cref="DataService"/>
  /// if it needs to be notified on <see cref="QueryBase">query</see>-related events.
  /// </summary>
  public interface IQueryEventWatcher
  {
    /// <summary>
    /// Called before execution of a <see cref="QueryBase">query</see>.
    /// Using this method you can add an additional restrictions
    /// to "where" clause of underlying SQL statement.  
    /// </summary>
    /// <param name="queryBase"><see cref="QueryBase"/> instance the event invoked for.</param>
    /// <param name="additionalRestriction"><see cref="String"/> with 
    /// additional SQL expression to be added to "where" clause of underlying SQL
    /// statement (so final SQL statement will look like 
    /// "Select ... where (originalRestriction) and (additionalRestriction)").</param>
    void OnQueryExecute(QueryBase queryBase, ref string additionalRestriction);
  }
}
