// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;

namespace DataObjects.NET.Attributes
{
  /// <summary>
  /// Indicates that value of the property can be <see langword="null"/>,
  /// and can be stored as <see cref="DBNull"/> in the database.
  /// </summary>
  /// <remarks>
  /// <note>This attribute can be applied to persistent properties of any type.</note>
  /// This attribute is a <see cref="DriverTypeSpecificAttribute">driver type-specific</see>,
  /// that means that it can be applied multiple times (with different parameters). 
  /// Each its application can be used or not - dependently on the current type 
  /// of the database driver. 
  /// See <see cref="DriverTypeSpecificAttribute.DriverTypes"/> property
  /// for further information.
  /// <para>
  /// <example>Example:
  /// <code lang="C#">
  ///  public abstract class Article: DataObject
  ///  {
  ///    [Nullable] // !!!
  ///    public abstract DateTime PublicationDate {get; set;}
  ///    
  ///    // This property can be not transactional, since it executes
  ///    // a single method that is transactional itself.
  ///    [NotPersistent]
  ///    [Transactional(TransactionMode.Disabled)] // Anyway necessary, since this isn't
  ///                                              // a virtual property.
  ///                                              // Otherwise DataObjects.NET will consider
  ///                                              // this method (property) as requiring a 
  ///                                              // transaction, but it couldn't implement a
  ///                                              // wrapper for it, because it isn't a virtual
  ///                                              // method (property).
  ///    public bool IsPublicationDateNull  {
  ///      get {
  ///        return this["PublicationDate"]==null;
  ///        // Or GetProperty("PublicationDate")==null;
  ///      }
  ///    }
  ///    
  ///    ...
  ///  }
  /// </code>
  /// </example>
  /// </para>
  /// <seealso cref="SqlTypeAttribute"/>
  /// <seealso cref="LengthAttribute"/>
  /// </remarks>
  [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field, 
    AllowMultiple = true, Inherited = true)]
  [Serializable]
  public class NullableAttribute: DriverTypeSpecificAttribute
  {
    private bool nullable = true;
    /// <summary>
    /// <see langword="True"/> if property value is <see langword="null"/>able.
    /// </summary>
    public  bool Nullable 
    {
      get {return nullable;}
      set {nullable = value;}
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    public NullableAttribute() 
    {
    }
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="nullable"><see langword="True"/> if property value is <see langword="null"/>able.</param>
    public NullableAttribute(bool nullable) 
    {
      this.nullable = nullable;
    }
  }
}
