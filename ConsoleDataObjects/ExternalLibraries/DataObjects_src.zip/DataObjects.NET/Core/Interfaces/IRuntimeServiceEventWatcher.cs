// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using DataObjects.NET.Attributes;

namespace DataObjects.NET
{
  /// <summary>
  /// An interface that should be implemented by <see cref="DataServiceType.Shared">Shared</see> <see cref="DataService"/>
  /// if it needs to be notified on <see cref="RuntimeService"/>-related events, such as executing.
  /// </summary>
  public interface IRuntimeServiceEventWatcher
  {
    /// <summary>
    /// Called before a <see cref="RuntimeService"/> is executed.
    /// <seealso cref="RuntimeService.Execute"/>
    /// </summary>
    /// <param name="runtimeService">A <see cref="RuntimeService"/> instance going to be executed.</param>
    /// <remarks>
    ///  The code that executes the runtime service works as follows:
    ///  <code lang="C#">
    ///  TransactionController tc = null;
    ///  try {
    ///     session.OnRuntimeServiceBeforeExecute(rs);
    ///     tc = session.CreateTransactionController(TransactionMode.TransactionRequired);
    ///     rs.Execute();
    ///     tc.Commit();
    ///     try { session.OnRuntimeServiceAfterExecute(rs, null); } catch {}
    ///   }
    ///   catch (Exception e) {
    ///     if (tc!=null)
    ///       tc.Rollback(e); 
    ///     session.OnRuntimeServiceAfterExecute(rs, e); 
    ///   }
    ///  </code>
    /// </remarks>
    void OnBeforeExecute(RuntimeService runtimeService);
    
    /// <summary>
    /// Called after a <see cref="RuntimeService"/> is executed.
    /// <seealso cref="RuntimeService.Execute"/>
    /// </summary>
    /// <param name="runtimeService">A <see cref="RuntimeService"/> object that has been just executed.</param>
    /// <param name="exception">An <see cref="Exception"/> which was throwed by <see cref="RuntimeService.Execute"/> method. 
    /// Equal to <see langword="Null"/> when the <paramref name="runtimeService"/> has been executed normally.</param>
    /// <remarks>
    ///  The code that executes the runtime service works as follows:
    ///  <code lang="C#">
    ///  TransactionController tc = null;
    ///  try {
    ///     session.OnRuntimeServiceBeforeExecute(rs);
    ///     tc = session.CreateTransactionController(TransactionMode.TransactionRequired);
    ///     rs.Execute();
    ///     tc.Commit();
    ///     try { session.OnRuntimeServiceAfterExecute(rs, null); } catch {}
    ///   }
    ///   catch (Exception e) {
    ///     if (tc!=null)
    ///       tc.Rollback(e); 
    ///     session.OnRuntimeServiceAfterExecute(rs, e); 
    ///   }
    ///  </code>
    /// </remarks>
    void OnAfterExecute(RuntimeService runtimeService, Exception exception);
  }
}
