// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.IO;
using System.Text;
using System.Threading;
using System.Collections;
using System.Collections.Specialized;
using System.Data;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Attributes;
using DataObjects.NET.Security;
using DataObjects.NET.Security.Permissions;

namespace DataObjects.NET
{
  /// <summary>
  /// Provides set of properties allowing to simplify access to the
  /// system objects in the <see cref="Session"/>.
  /// <seealso cref="DataObjects.NET.Session.SystemObjects"/>
  /// <seealso cref="SystemObjectNames"/>
  /// </summary>
  public class SystemObjects: SessionBoundObject
  {
    private User systemUser;
    private User administratorUser;
    private User guestUser;
    private User anonymousUser;
    private Role administratorsRole;
    private Role usersRole;
    private Role guestsRole;
    private Role everyoneRole;
    private DataObject securityRoot;
    private bool systemUserCached;
    private bool administratorUserCached;
    private bool guestUserCached;
    private bool anonymousUserCached;
    private bool administratorsRoleCached;
    private bool usersRoleCached;
    private bool guestsRoleCached;
    private bool everyoneRoleCached;
    private bool securityRootCached;


    /// <summary>
    /// Gets the System <see cref="User"/>.
    /// </summary>
    public  User SystemUser {
      get {
        if (!systemUserCached) {
          Query q = new Query(session, 
            "Select "+typeof(User).FullName+" instances where {Name}=" +
            session.utils.QuoteString(session.domain.systemObjectNames.systemUserName));
          DataObject[] r = q.ExecuteArray();
          if (r.Length==0)
            systemUser = null;
          else
            systemUser = (User)r[0];
          systemUserCached = true;
        }
        return systemUser;
      }
    }
    
    /// <summary>
    /// Gets the Administrator <see cref="User"/>.
    /// </summary>
    public  User AdministratorUser {
      get {
        if (!administratorUserCached) {
          Query q = new Query(session, 
            "Select "+typeof(User).FullName+" instances where {Name}=" +
            session.utils.QuoteString(session.domain.systemObjectNames.administratorUserName));
          DataObject[] r = q.ExecuteArray();
          if (r.Length==0)
            administratorUser = null;
          else
            administratorUser = (User)r[0];
          administratorUserCached = true;
        }
        return administratorUser;
      }
    }
    
    /// <summary>
    /// Gets the Guest <see cref="User"/>.
    /// </summary>
    public  User GuestUser {
      get {
        if (!guestUserCached) {
          Query q = new Query(session, 
            "Select "+typeof(User).FullName+" instances where {Name}=" +
            session.utils.QuoteString(session.domain.systemObjectNames.guestUserName));
          DataObject[] r = q.ExecuteArray();
          if (r.Length==0)
            guestUser = null;
          else
            guestUser = (User)r[0];
          guestUserCached = true;
        }
        return guestUser;
      }
    }
    
    /// <summary>
    /// Gets the Anonymous <see cref="User"/>.
    /// </summary>
    public  User AnonymousUser {
      get {
        if (!anonymousUserCached) {
          Query q = new Query(session, 
            "Select "+typeof(User).FullName+" instances where {Name}=" +
            session.utils.QuoteString(session.domain.systemObjectNames.anonymousUserName));
          DataObject[] r = q.ExecuteArray();
          if (r.Length==0)
            anonymousUser = null;
          else
            anonymousUser = (User)r[0];
          anonymousUserCached = true;
        }
        return anonymousUser;
      }
    }
    
    /// <summary>
    /// Gets the Administrators <see cref="Role"/>.
    /// </summary>
    public  Role AdministratorsRole {
      get {
        if (!administratorsRoleCached) {
          Query q = new Query(session, 
            "Select "+typeof(Role).FullName+" instances where {Name}=" +
            session.utils.QuoteString(session.domain.systemObjectNames.administratorsRoleName));
          DataObject[] r = q.ExecuteArray();
          if (r.Length==0)
            administratorsRole = null;
          else
            administratorsRole = (Role)r[0];
          administratorsRoleCached = true;
        }
        return administratorsRole;
      }
    }
    
    /// <summary>
    /// Gets the Users <see cref="Role"/>.
    /// </summary>
    public  Role UsersRole {
      get {
        if (!usersRoleCached) {
          Query q = new Query(session, 
            "Select "+typeof(Role).FullName+" instances where {Name}=" +
            session.utils.QuoteString(session.domain.systemObjectNames.usersRoleName));
          DataObject[] r = q.ExecuteArray();
          if (r.Length==0)
            usersRole = null;
          else
            usersRole = (Role)r[0];
          usersRoleCached = true;
        }
        return usersRole;
      }
    }
    
    /// <summary>
    /// Gets the Guests <see cref="Role"/>.
    /// </summary>
    public  Role GuestsRole {
      get {
        if (!guestsRoleCached) {
          Query q = new Query(session, 
            "Select "+typeof(Role).FullName+" instances where {Name}=" +
            session.utils.QuoteString(session.domain.systemObjectNames.guestsRoleName));
          DataObject[] r = q.ExecuteArray();
          if (r.Length==0)
            guestsRole = null;
          else
            guestsRole = (Role)r[0];
          guestsRoleCached = true;
        }
        return guestsRole;
      }
    }
    
    /// <summary>
    /// Gets the Everyone <see cref="Role"/>.
    /// </summary>
    public  Role EveryoneRole {
      get {
        if (!everyoneRoleCached) {
          Query q = new Query(session, 
            "Select "+typeof(Role).FullName+" instances where {Name}=" +
            session.utils.QuoteString(session.domain.systemObjectNames.everyoneRoleName));
          DataObject[] r = q.ExecuteArray();
          if (r.Length==0)
            everyoneRole = null;
          else
            everyoneRole = (Role)r[0];
          everyoneRoleCached = true;
        }
        return everyoneRole;
      }
    }
    
    /// <summary>
    /// Gets the security root object (see <see cref="ISecurityRoot"/>).
    /// </summary>
    public  DataObject SecurityRoot {
      get {
        if (!securityRootCached) {
          Query q = new Query(session, 
            "Select "+typeof(ISecurityRoot).FullName+" instances");
          DataObject[] r = q.ExecuteArray();
          if (r.Length==0)
            securityRoot = null;
          else
            securityRoot = r[0];
          securityRootCached = true;
        }
        return securityRoot;
      }
    }
    
    /// <summary>
    /// Invalidates cached security objects. Invoke this method
    /// in the <see cref="Domain.InitializeSystemObjects"/> event
    /// handler after some security objects was added or removed
    /// to obtain correct <see cref="SystemObjects"/>' property 
    /// values further.
    /// You shouldn't call this method in any other circumstances.
    /// </summary>
    public void InvalidateCachedSystemObjects()
    {
      if (session.domain.status!=DomainStatus.InitializingSystemObjects)
        throw new InvalidOperationException(
          "This method can be called only during the system " +
          "objects initialization period. Normally you should never call it.");
      
      systemUserCached = false;
      administratorUserCached = false;
      guestUserCached = false;
      anonymousUserCached = false;
      administratorsRoleCached = false;
      usersRoleCached = false;
      guestsRoleCached = false;
      everyoneRoleCached = false;
      securityRootCached = false;
    }
    
  
    // Constructors
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="session">Session, to which current instance should be bound.</param>
    internal SystemObjects(Session session):
      base(session)
    {
    }
  }
}
