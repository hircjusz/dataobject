// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;
using System.Data;
using System.Windows.Forms;
using DataObjects.NET.Data;
using DataObjects.NET.Data.CodeManage;

namespace DataObjects.NET.Data
{
  /// <summary>
  /// Automatic mappings generator used in designtime only.
  /// </summary>
  internal class DesigntimeMappingGenerator: MappingGenerator
  {
    private bool removeAll = false;
    private bool preserveAll = false;
    
    /// <summary>
    /// Returns <see langword="true"/> if specified mapping item can be removed, otherwise <see langword="false"/>.
    /// </summary>
    /// <param name="item">mapping item.</param>
    /// <returns><see langword="True"/> if specified mapping item can be removed, otherwise <see langword="false"/>.</returns>
    protected internal override bool CanRemoveMappingItem(MappingItemBase item)
    {
      if (removeAll)
        return true;
      if (preserveAll)
        return false;
        
      string map = 
        MappingLog.GetMappingItemSource(item) +
        " - " +
        MappingLog.GetMappingItemDestination(item);
        
      DialogResult dialogResult = MessageBox.Show(
        "The following mapping item is to be removed:\n" +
        "\"" + map + "\"",
        "Confirm mapping item removal",
        MessageBoxButtons.OKCancel,
        MessageBoxIcon.Question);

      return (dialogResult==DialogResult.OK);
    }
    
    /// <summary>
    /// Initializes a new instance of the <see cref="DesigntimeMappingGenerator"/> class.
    /// </summary>
    /// <param name="adapter"><see cref="Adapter"/> to generate mappings for.</param>
    internal DesigntimeMappingGenerator(Adapter adapter): base(adapter)
    {
    }
  }
}
