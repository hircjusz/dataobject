// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;

namespace DataObjects.NET
{
  /// <summary>
  /// An interface that should be implemented by a class
  /// providing information about the <see cref="DataObjects.NET.Domain.Environment"/>
  /// of the <see cref="Domain"/>. Environment is anything that
  /// is important to persistent entities or services.
  /// </summary>
  public interface IEnvironment
  {
    /// <summary>
    /// Gets or sets the <see cref="Domain"/> object this enviroment 
    /// is bound to.
    /// </summary>
    Domain Domain {get; set;}
  }
}
