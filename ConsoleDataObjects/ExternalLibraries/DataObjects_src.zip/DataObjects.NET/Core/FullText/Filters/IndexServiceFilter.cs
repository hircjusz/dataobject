// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.IO;
using System.Text;
using System.Runtime.InteropServices;
using Microsoft.Win32;

namespace DataObjects.NET.FullText.Filters
{
  /// <summary>
  /// Managed wrapper for Microsoft Index Service Filters. 
  /// </summary>
  /// <remarks>
  /// <para>
  /// See <see href="http://msdn.microsoft.com/library/default.asp?url=/library/en-us/indexsrv/html/ixrefint_9sfm.asp">Microsoft Index Service Documentation (MSDN Library)</see>
  /// for additional details.
  /// </para>
  /// <example>Example:
  /// <code lang="C#">
  ///   Filter docFilter = Filter.Create("doc");
  ///   FileStream docFile = new FileStream(@"C:\AnyMicrosoftWordFile.doc",FileMode.Open);
  ///   Debug.WriteLine(docFilter.GetFilteredContent(docFile));
  ///
  ///   Filter txtFilter = Filter.Create("txt");
  ///   FileStream txtFile = new FileStream(@"C:\AnyPlainTextFile.txt",FileMode.Open);
  ///   Debug.WriteLine(txtFilter.GetFilteredContent(txtFile));
  /// </code>
  /// </example>
  /// </remarks>
  public sealed class IndexServiceFilter: Filter
  {
    private string    extension;
    private Type      filterType;
    
    /// <summary>
    /// Gets extension this instance is capable to process.
    /// </summary>
    public override string Extension {
      get {
        return extension;
      }
    }
    
    /// <summary>
    /// Extracts filtered content from the specified byte stream
    /// (applies filter to the specified byte stream).
    /// </summary>
    /// <param name="stream">A stream containing document data in the format 
    /// that can be parsed by this instance of <see cref="Filter"/>.</param>
    /// <param name="maxOutputLength">Maximal <see cref="String.Length">length</see> of returned <see cref="String"/>;
    /// <see langword="0"/> means there is no restriction on its <see cref="String.Length">length</see>.</param>
    /// <returns>Extracted filtered content of the document.</returns>
    public override string GetFilteredContent(Stream stream, int maxOutputLength)
    {
      if (maxOutputLength<0)
        throw new ArgumentOutOfRangeException(
          "maxOutputLength", maxOutputLength, 
          "Maximal output length should be greater then or equal to 0.");

      StringBuilder sbResult = new StringBuilder();
      StringBuilder sbBuffer = new StringBuilder(256);
      string ipfFileName = null;
      UCOMIPersistFile ipf = null;
      IFilter filter = (IFilter)Activator.CreateInstance(filterType);

      try {
        IPersistStream ips = filter as IPersistStream;
        if (ips!=null) {
          ips.Load(new Stream2UCOMIStreamWrapper(stream));
        }
        else {
          ipf = filter as UCOMIPersistFile;
          if (ipf==null)
            return "";
          ipfFileName = Path.GetTempFileName();
          byte[] bBuffer = new byte[stream.Length];
          stream.Read(bBuffer, 0, (int)stream.Length);
          using (FileStream fs = File.OpenWrite(ipfFileName)) {
            fs.Write(bBuffer, 0, bBuffer.Length);
          }
          ipf.Load(ipfFileName,0);
        }
        
        uint i = 0;
        STAT_CHUNK ps = new STAT_CHUNK();
        filter.Init(0, 0, null, ref i);

        while (true) {
          int hr = filter.GetChunk(out ps);
          if (hr==FILTER_CONST.FILTER_E_END_OF_CHUNKS)
            break;
          if (hr==0 && ps.flags==CHUNKSTATE.CHUNK_TEXT) {
            while (true) {
              uint pcwcBuffer = (uint)(sbBuffer.Capacity+1);
              hr = filter.GetText(ref pcwcBuffer, sbBuffer);
              if (hr!=FILTER_CONST.FILTER_S_LAST_TEXT && hr!=0)
                break;
              if (sbBuffer.Length>pcwcBuffer)
                sbResult.Append(sbBuffer.ToString(0, (int)pcwcBuffer));
              else
                sbResult.Append(sbBuffer.ToString());
              if (maxOutputLength>0 && sbResult.Length>=maxOutputLength) {
                if (extension!="pdf") // Adobe PDF filter doesn't close the file
                  goto Done;          // on Marshal.ReleaseComObject in this case
              }
              if (hr==FILTER_CONST.FILTER_S_LAST_TEXT)
                break;
            }
          }
        }

      Done:
        if (maxOutputLength>0 && sbResult.Length>maxOutputLength) {
          string result = sbResult.ToString(0, maxOutputLength);
          int j = result.Length-1;
          while (j>=0 && !Char.IsWhiteSpace(result[j])) j--;
          while (j>=0 &&  Char.IsWhiteSpace(result[j])) j--;
          return result.Substring(0,j+1);
        }
        else
          return sbResult.ToString();
      }
      finally {
        if (filter!=null)
          Marshal.ReleaseComObject(filter);
        if (ipfFileName!=null)
          File.Delete(ipfFileName);
      }
    }
    

    // Constructors

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="extension">An extension to create <see cref="IndexServiceFilter"/> for 
    /// (without leading dot, e.g. "txt"). A value of this argument will be
    /// further available via <see cref="Extension"/> property of the newly
    /// created object.</param>
    /// <remarks>
    /// <para>
    /// This method locates an Index Service Filter (COM object) the specified 
    /// <paramref name="extension"/>, and returns a newly created managed wrapper 
    /// (<see cref="IndexServiceFilter"/> object) located unmanaged COM object, 
    /// if it was found; otherwise, it throws <see cref="NotSupportedException"/>.</para>
    /// </remarks>
    public IndexServiceFilter(string extension)
    {
      string phStr = null;
      RegistryKey phKey = Registry.ClassesRoot.OpenSubKey(String.Format(
        @".{0}\PersistentHandler", extension));

      if (phKey==null) {
        phKey = Registry.ClassesRoot.OpenSubKey(String.Format(
          @".{0}", extension));
        if (phKey==null)
          throw new NotSupportedException(String.Format(
            "Associated Index Service Filter wasn't found for \"{0}\" extension.", extension));

        phStr = phKey.GetValue(null) as string;
        if (phStr==null || phStr=="")
          throw new NotSupportedException(String.Format(
            "Associated Index Service Filter wasn't found for \"{0}\" extension.", extension));
        
        phKey = Registry.ClassesRoot.OpenSubKey(String.Format(
          @"{0}\CLSID", phStr));
        if (phKey==null)
          throw new NotSupportedException(String.Format(
            "Associated Index Service Filter wasn't found for \"{0}\" extension.", extension));
        
        phStr = phKey.GetValue(null) as string;
        if (phStr==null || phStr=="")
          throw new NotSupportedException(String.Format(
            "Associated Index Service Filter wasn't found for \"{0}\" extension.", extension));

        phKey = Registry.ClassesRoot.OpenSubKey(String.Format(
          @"CLSID\{0}\PersistentHandler", phStr));
        if (phKey==null)
          throw new NotSupportedException(String.Format(
            "Associated Index Service Filter wasn't found for \"{0}\" extension.", extension));
        
        phStr = phKey.GetValue(null) as string;
        if (phStr==null || phStr=="")
          throw new NotSupportedException(String.Format(
            "Associated Index Service Filter wasn't found for \"{0}\" extension.", extension));
      }
      else {
        phStr = phKey.GetValue(null) as string;
        if (phStr==null || phStr=="")
          throw new NotSupportedException(String.Format(
            "Associated Index Service Filter wasn't found for \"{0}\" extension.", extension));
      }
      
      RegistryKey ftKey = Registry.ClassesRoot.OpenSubKey(String.Format(
        @"CLSID\{0}\PersistentAddinsRegistered\{1}", phStr, typeof(IFilter).GUID.ToString("B")));
      if (ftKey==null)
        throw new NotSupportedException(String.Format(
          "Associated Index Service Filter wasn't found for \"{0}\" extension.", extension));

      string ftStr = ftKey.GetValue(null) as string;
      if (ftStr==null || ftStr=="")
        throw new NotSupportedException(String.Format(
          "Associated Index Service Filter wasn't found for \"{0}\" extension.", extension));
      
      Guid ftGuid;
      try {
        ftGuid = new Guid(ftStr);
      }
      catch (FormatException) {
        throw new NotSupportedException(String.Format(
          "Associated Index Service Filter wasn't found for \"{0}\" extension.", extension));
      }

      this.extension  = extension;
      this.filterType = Type.GetTypeFromCLSID(ftGuid);
    }
  }
}
