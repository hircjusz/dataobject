// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;

namespace DataObjects.NET
{
  /// <summary>
  /// Represents an pair of <see cref="Int64"/> values.
  /// </summary>
  internal struct Int64x2
  {
    /// <summary>
    /// Left value in the pair.
    /// </summary>
    public long L;

    /// <summary>
    /// Right value in the pair.
    /// </summary>
    public long R;
    
    /// <summary>
    /// Returns a hash code for the current instance.
    /// </summary>
    /// <returns>A hash code for the current instance.</returns>
    public override int GetHashCode()
    {
      return L.GetHashCode() + R.GetHashCode();
    }
    
    /// <summary>
    /// Returns <see langword="true"/>, if current instance
    /// equals to <paramref name="obj"/>; otherwise, <see langword="false"/>.
    /// </summary>
    /// <param name="obj">An object to check the equality with.</param>
    /// <returns><see langword="True"/>, if current instance
    /// equals to <paramref name="obj"/>; otherwise, <see langword="false"/>.</returns>
    public override bool Equals(object obj)
    {
      if (obj==null)
        return false;
      if (!(obj is Int64x2))
        return false;
      Int64x2 i = (Int64x2)obj;
      if (L==i.L && R==i.R)
        return true;
      return false;
    }
    
    /// <summary>
    /// Returns an indication whether the values of two specified 
    /// <see cref="Int64x2"/> objects are equal.
    /// </summary>
    /// <param name="a">An <see cref="Int64x2"/> object.</param>
    /// <param name="b">An <see cref="Int64x2"/> object.</param>
    /// <returns></returns>
    public static bool operator==(Int64x2 a, Int64x2 b)
    {
      return (a.L==b.L && a.R==b.R);
    }

    /// <summary>
    /// Returns an indication whether the values of two specified 
    /// <see cref="Int64x2"/> objects are equal.
    /// </summary>
    /// <param name="a">An <see cref="Int64x2"/> object.</param>
    /// <param name="b">An <see cref="Int64x2"/> object.</param>
    /// <returns></returns>
    public static bool operator != (Int64x2 a, Int64x2 b)
    {
      return !(a.L==b.L && a.R==b.R);
    }

    
    // Constructors
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="l">Initial left value in the pair.</param>
    /// <param name="r">Initial right value in the pair.</param>
    public Int64x2(long l, long r)
    {
      L = l;
      R = r;
    }
  }
}
