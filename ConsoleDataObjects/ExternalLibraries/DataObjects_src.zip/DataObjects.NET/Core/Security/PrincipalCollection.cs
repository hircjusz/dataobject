// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.IO;
using System.Threading;
using System.Configuration;
using System.Diagnostics;
using System.Globalization;
using System.Collections;
using DataObjects.NET;
using DataObjects.NET.Attributes;
using DataObjects.NET.Exceptions;

namespace DataObjects.NET.Security
{
  /// <summary>
  /// Collection of <see cref="Principal"/>s.
  /// </summary>
  public abstract class PrincipalCollection: DataObjectCollection
  {
    /// <summary>
    /// Adds new element to the collection.
    /// </summary>
    /// <param name="item">Item to add.</param>
    /// <returns>Index of newly added item.</returns>
    [Transactional(TransactionMode.Disabled)]
    public int Add(Principal item) 
    {
      return List.Add(item);
    }

    /// <summary>
    /// Gets or sets the element of collection by its index.
    /// </summary>
    [Transactional(TransactionMode.Disabled)]
    public new Principal this[int n] {
      get {
        return (Principal)List[n];
      }
      set {
        List[n] = value;
      }
    }
    
    
    // Contrsuctors
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="itemType">Type of collection items.</param>
    public PrincipalCollection(System.Type itemType): base(itemType)
    {
      if (!(itemType==typeof(Principal) || itemType.IsSubclassOf(typeof(Principal))))
        throw new ObjectModelBuilderException(
          String.Format("Illegal ItemType value: \"{0}\".",itemType)
          );
    }
  }
}
