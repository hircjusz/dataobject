// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;

namespace DataObjects.NET.Attributes
{
  /// <summary>
  /// Specifies <see cref="ChangesTrackingMode"/> to use for the field.
  /// </summary>
  /// <remarks>
  /// <note>This attribute can be applied to persistent properties
  /// of <see cref="DataObjectCollection"/> or <see cref="ValueTypeCollection"/> 
  /// types.</note>
  /// <para>
  /// <example>Example:
  /// <code lang="C#">
  ///  public abstract class Person: DataObject
  ///  {
  ///    ...
  ///    
  ///    [ChangesTracking(ChangesTrackingMode.Independently)] // Changes are tracked independently
  ///    [Symmetric]
  ///    [ItemType(typeof(Person))]
  ///    public abstract DataObjectCollection Friends {get;}
  ///
  ///    ...
  ///  }
  /// </code>
  /// </example>
  /// </para>
  /// </remarks>
  [AttributeUsage(AttributeTargets.Property, AllowMultiple = false, Inherited = true)]
  [Serializable]
  public class ChangesTrackingAttribute: DataObjectAttribute
  {
    private ChangesTrackingMode changesTrackingMode;
    /// <summary>
    /// Gets or sets <see cref="ChangesTrackingMode"/> to use for the field.
    /// </summary>
    public ChangesTrackingMode ChangesTrackingMode
    {
      get {return changesTrackingMode;}
      set {changesTrackingMode = value;}
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="changesTrackingMode">Specifies <see cref="ChangesTrackingMode"/> to use for the field.</param>
    public ChangesTrackingAttribute(ChangesTrackingMode changesTrackingMode) 
    {
      this.changesTrackingMode = changesTrackingMode;
    }
  }
}
