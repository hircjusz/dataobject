// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;
using DataObjects.NET;

namespace DataObjects.NET.Services
{
  /// <summary>
  /// Provides access to a collection of tracked <see cref="DataObject"/>'s IDs.
  /// </summary>
  public class TrackingSet: SessionBoundObject
  {
    private TrackingService trackingService;
    private TrackingOptions options;
    private Transaction     transaction;
    private bool            isActive;
    private bool            isOverflown;
    private TrackingSet     innerSet;
    private TrackingSet     outerSet;
    private Hashtable       hTracked;
    private Hashtable       hCreated;
    private int             limit;
    
    /// <summary>
    /// Checks whether it is possible to create <see cref="TrackingSet"/> 
    /// instance for the specified <see cref="Domain"/>.
    /// </summary>
    /// <param name="domain">The <see cref="Domain"/> instance to perform checking for.</param>
    /// <returns><see langword="True"/> if the tracking allowed for the specified domain; otherwise <see langword="false"/>.</returns>
    /// <remarks>
    /// Tracking is allowed, if <see cref="TrackingService"/> is registered
    /// in the specified <paramref name="domain"/>.
    /// </remarks>
    public static bool IsTrackingAllowed(Domain domain)
    {
      return domain.IsServiceRegistered(typeof(TrackingService));
    }
    
    /// <summary>
    /// Gets tracking options.
    /// </summary>
    public TrackingOptions Options {
      get {
        return options;
      }
    }
    
    /// <summary>
    /// Gets transaction where tracking was started.
    /// </summary>
    public Transaction Transaction {
      get {
        return transaction;
      }
    }
    
    /// <summary>
    /// Indicates whether tracking is running in this
    /// set or not.
    /// </summary>
    public bool IsActive {
      get {
        return isActive;
      }
    }
    
    /// <summary>
    /// Raised on any tracking activity.
    /// </summary>
    public event TrackingActivityEventHandler Activity;
    
    /// <summary>
    /// Gets <see cref="TrackingService"/> instance
    /// that actually updates this tracking set.
    /// </summary>
    public TrackingService TrackingService {
      get {
        return trackingService;
      }
    }
    
    /// <summary>
    /// Returns an array of <see cref="DataObject"/> <see cref="DataObject.ID"/>s
    /// which belongs to this <see cref="TrackingSet"/> (i.e. which were 
    /// created, removed or changed - dependently on <see cref="TrackingOptions"/>).
    /// </summary>
    /// <returns>An array of <see cref="DataObject"/> <see cref="DataObject.ID"/>s.</returns>
    public long[] GetIDs()
    {
      Hashtable ht = hTracked;
      if (innerSet!=null) {
        ht = new Hashtable(hTracked);
        TrackingSet ts = innerSet;
        while (ts!=null) {
          ICollection keys = ts.hTracked.Keys;
          foreach (long id in keys)
            ht[id] = ht;
          ts = ts.innerSet;
        }
      }
      long[] ids = new long[ht.Count];
      ht.Keys.CopyTo(ids, 0);
      return ids;
    }
    
    /// <summary>
    /// Returns <see langword="true"/> if <see cref="DataObject"/> instance 
    /// with specified <see cref="DataObject.ID"/> belongs to this 
    /// <see cref="TrackingSet"/>; otherwise, <see langword="false"/>.
    /// </summary>
    public bool this[long id] {
      get {
        if (IsOverflown)
          return true;
        if (hTracked.ContainsKey(id))
          return true;
        if (innerSet!=null)
          return innerSet[id];
        return false;
      }
    }
    
    /// <summary>
    /// Returns <see langword="true"/> if specified <see cref="DataObject"/> instance
    /// belongs to this <see cref="TrackingSet"/>; otherwise, <see langword="false"/>.
    /// </summary>
    public bool this[DataObject dataObject] {
      get {
        if (dataObject==null)
          throw new ArgumentNullException("dataObject");
        if (dataObject.session!=session)
          throw new InvalidOperationException("Validation failed: instance belongs to different session.");
        return this[dataObject.ID];
      }
    }

    /// <summary>
    /// Gets or sets tracking limit. Limit value indicates maximal number of
    /// <see cref="DataObject.ID"/>s  this <see cref="TrackingSet"/> can store. 
    /// </summary>
    /// <remarks>
    /// <para>
    /// If limit is exceeded, <see cref="TrackingSet"/> starts to 
    /// report that any <see cref="DataObject.ID"/>
    /// belongs to it (see the <see cref="this">indexer</see> of this class). 
    /// </para>
    /// <para>
    /// Setting <see cref="Limit"/> value to <see langword="0"/> means that
    /// there is no limitation on the number of <see cref="DataObject.ID"/>s
    /// that can be stored in this <see cref="TrackingSet"/>.
    /// </para>
    /// </remarks>
    public int Limit {
      get {
        return limit;
      }
      set {
        if (value<0)
          throw new ArgumentOutOfRangeException("value", value, 
            "Limit should be greater then or equal to 0.");
        limit = value;
        isOverflown = false;
        CheckOverflow();
      }
    }
    
    /// <summary>
    /// Gets a count of <see cref="DataObject.ID"/>s 
    /// that are stored in this tracking set (without
    /// counting <see cref="DataObject.ID"/>s stored in
    /// nested tracking sets, which track the changes in 
    /// nested transactions). 
    /// </summary>
    /// <remarks>
    /// This value is always equal or lower then actual
    /// amount of different IDs returned by <see cref="GetIDs"/>
    /// method. 
    /// See <see cref="TotalCount"/> property also.
    /// </remarks>
    public int Count {
      get {
        return hTracked.Count;
      }
    }
    
    /// <summary>
    /// Gets a count of <see cref="DataObject.ID"/>s 
    /// that are stored in this tracking set, and inner
    /// tracking sets (created to track events in the
    /// nested transactions).
    /// </summary>
    /// <remarks>
    /// This value is always equal or greater then actual
    /// amount of different IDs returned by <see cref="GetIDs"/>
    /// method. 
    /// See <see cref="Count"/> property also.
    /// </remarks>
    public int TotalCount {
      get {
        int count = hTracked.Count;
        if (innerSet!=null)
          count += innerSet.Count;
        return count;
      }
    }
    
    /// <summary>
    /// Gets a value indicating whether <see cref="Limit"/> 
    /// is reached or not.
    /// </summary>
    public bool IsOverflown {
      get {
        return isOverflown;
      }
    }
    void CheckOverflow()
    {
      if (isOverflown || limit==0)
        return;
      if (Count>=limit)
        isOverflown = true;
    }
    
    /// <summary>
    /// Called on <see cref="DataObject"/> instance initialization.
    /// </summary>
    /// <param name="dataObject">The DataObject instance the event invoked for.</param>
    internal void OnDataObjectCreated(DataObject dataObject)
    {
      if (IsOverflown)
        return;
      if ((options & TrackingOptions.DetectCreations)!=0) {
        if (dataObject.State==DataObjectState.Persistent) {
          OnActivity(dataObject.ID, TrackingActivityType.ObjectCreated);
          CheckOverflow();
        }
        else {
          if (hCreated==null)
            hCreated = new Hashtable();
          hCreated[dataObject] = hCreated;
        }
      }
    }
    
    /// <summary>
    /// Called after changes are persisted (see <see cref="DataObject.Persist"/> method)
    /// to the database.
    /// </summary>
    /// <param name="dataObject">The DataObject instance the event invoked for.</param>
    internal void OnDataObjectPersisted(DataObject dataObject)
    {
      if (IsOverflown)
        return;
      if ((options & TrackingOptions.DetectCreations)!=0) {
        if (hCreated!=null && hCreated.Contains(dataObject)) {
          hCreated.Remove(dataObject);
          OnActivity(dataObject.ID, TrackingActivityType.ObjectCreated);
          CheckOverflow();
        }
      }
    }
    
    /// <summary>
    /// Called before <see cref="DataObject"/> instance is removed.
    /// </summary>
    /// <param name="dataObject">The DataObject instance the event invoked for.</param>
    internal void OnDataObjectRemove(DataObject dataObject)
    {
      if (IsOverflown)
        return;
      if ((options & TrackingOptions.DetectRemovals)!=0) {
        OnActivity(dataObject.ID, TrackingActivityType.ObjectRemoved);
        CheckOverflow();
      }
    }
    
    /// <summary>
    /// Called when some property was changed.
    /// </summary>
    /// <param name="dataObject">The DataObject instance the event invoked for.</param>
    internal void OnDataObjectChanged(DataObject dataObject)
    {
      if (IsOverflown)
        return;
      if (dataObject.State==DataObjectState.New)
        return;
      if (dataObject.State==DataObjectState.Removed)
        return;
      if ((options & TrackingOptions.DetectChanges)!=0) {
        OnActivity(dataObject.ID, TrackingActivityType.ObjectChanged);
        CheckOverflow();
      }
    }

    
    /// <summary>
    /// This method is invoked on any tracking activity - it raised
    /// <see cref="Activity"/> event.
    /// </summary>
    protected virtual void OnActivity(long id, TrackingActivityType activityType)
    {
      bool discard = false;
      if (Activity!=null) {
        TrackingActivityEventArgs activityEventArgs = 
          new TrackingActivityEventArgs(this, id, activityType);
        Activity(activityEventArgs);
        discard = activityEventArgs.Discard;
      }
      if (!discard)
        hTracked[id] = hTracked;
    }
    
    /// <summary>
    /// Called when a <see cref="Session"/> begins a new <see cref="Transaction"/>.
    /// </summary>
    /// <param name="transaction">The corresponding <see cref="Transaction"/>.</param>
    internal void OnTransactionBegin(Transaction transaction)
    {
      if (IsOverflown)
        return;
      innerSet = new TrackingSet(session, options);
      innerSet.outerSet = this;
      innerSet.limit = limit==0 ? 0 : limit-Count;
      innerSet.StartTracking();
    }

    /// <summary>
    /// Called when a <see cref="Session"/> commits a <see cref="Transaction"/>.
    /// </summary>
    internal void OnTransactionCommit()
    {
      StopTracking();
      if (outerSet!=null) {
        outerSet.innerSet = null;
        outerSet.Merge(this);
      }
    }

    /// <summary>
    /// Called when a <see cref="Session"/> rolls a <see cref="Transaction"/> back.
    /// </summary>
    internal void OnTransactionRollback()
    {
      StopTracking();
      if (outerSet!=null)
        outerSet.innerSet = null;
    }
    
    /// <summary>
    /// Merges current <see cref="TrackingSet"/> with provided one.
    /// </summary>
    /// <param name="trackingSet"><see cref="TrackingSet"/> to merge with.</param>
    public void Merge(TrackingSet trackingSet)
    {
      if (trackingSet==null)
        throw new ArgumentNullException("trackingSet");
        
      while (trackingSet!=null) {
        isOverflown |= trackingSet.isOverflown;
        if (isOverflown)
          break;
        ICollection keys = trackingSet.hTracked.Keys;
        foreach (long id in keys)
          hTracked[id] = hTracked;
        trackingSet = trackingSet.innerSet;
      }
    }

    /// <summary>
    /// Starts tracking <see cref="DataObject"/> events. 
    /// Tracking will be automatically stopped when active
    /// <see cref="Transaction"/> will be committed or rolled back.
    /// </summary>
    public void StartTracking()
    {
      Transaction transaction = session.Transaction;
      if (transaction==null)
        throw new InvalidOperationException("No transaction is started.");
      
      StartTracking(transaction);
    }
    
    private void StartTracking(Transaction transaction)
    {
      if (transaction==null)
        throw new ArgumentNullException("transaction");
      if (transaction.IsFinished)
        throw new InvalidOperationException("Transaction is already finished.");
      if (isActive)
        throw new InvalidOperationException("Tracking is already started.");
      
      this.transaction = transaction;
      this.hCreated = null;
        
      trackingService.RegisterTrackingSet(this);
      isActive = true;
      
      Transaction innerTransaction = transaction.InnerTransaction;
      if (innerTransaction!=null) {
        innerSet = new TrackingSet(session, options);
        innerSet.outerSet = this;
        innerSet.StartTracking(innerTransaction);
      }
    }
    
    /// <summary>
    /// Stops tracking <see cref="DataObject"/> events.
    /// </summary>
    public void StopTracking()
    {
      if (!isActive)
        throw new InvalidOperationException("Tracking is already stopped.");

      if (innerSet!=null)
        innerSet.StopTracking();
        
      trackingService.UnregisterTrackingSet(this);
      isActive = false;
      hCreated = null;
    }
    
    
    // Constructors
  
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="options">Tracking options.</param>
    /// <param name="session">Session, to which current instance should be bound.</param>
    public TrackingSet(Session session, TrackingOptions options): 
      this(session, options, 0, false)
    {
    }
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="options">Tracking options.</param>
    /// <param name="session">Session, to which current instance should be bound.</param>
    /// <param name="limit">Tracking limit. Zero value indicates no limit.</param>
    public TrackingSet(Session session, TrackingOptions options, int limit): 
      this(session, options, limit, false)
    {
    }
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="options">Tracking options.</param>
    /// <param name="session">Session, to which current instance should be bound.</param>
    /// <param name="start">Indicates whether to start tracking automatically or not.</param>
    public TrackingSet(Session session, TrackingOptions options, bool start): 
      this(session, options, 0, start)
    {
    }
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="options">Tracking options.</param>
    /// <param name="session">Session, to which current instance should be bound.</param>
    /// <param name="limit">Tracking limit. Zero value indicates no limit.</param>
    /// <param name="start">Indicates whether to start tracking automatically or not.</param>
    public TrackingSet(Session session, TrackingOptions options, int limit, bool start): base(session)
    {
      this.options         = options;
      this.limit           = limit;
      this.isActive        = false;
      this.isOverflown     = false;
      this.hTracked        = new Hashtable();
      this.hCreated        = null;
      this.trackingService = (TrackingService)session.GetService(typeof(TrackingService));
      if (start)
        StartTracking();
    }
  }
}
