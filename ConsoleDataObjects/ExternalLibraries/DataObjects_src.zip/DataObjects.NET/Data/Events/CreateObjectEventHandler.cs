// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using DataObjects.NET;
using DataObjects.NET.Data;

namespace DataObjects.NET.Data
{
  /// <summary>
  /// Represents a method that will handle the <see cref="Adapter.CreateObject"/> events.
  /// </summary>
  /// <param name="sender">The source of the event.</param>
  /// <param name="e">An <see cref="CreateObjectEventArgs"/> that contains the event data.</param>
  /// <remarks>
  /// <para>
  /// This event is raised when <see cref="Adapter"/> needs to create new <see cref="DataObject"/>
  /// instance. 
  /// </para>
  /// <para>
  /// When <see cref="Adapter"/> raises this event it sets 
  /// <see cref="CreateObjectEventArgs.SuggestedType"/> property and
  /// <see cref="CreateObjectEventArgs.Rows"/> property. Event handler may create new
  /// <see cref="DataObject"/> instance manually and set 
  /// <see cref="CreateObjectEventArgs.DataObject"/> property or it may not create
  /// <see cref="DataObject"/> instance and just correct the suggested type so 
  /// <see cref="Adapter"/> can create new <see cref="DataObject"/> instance automatically. 
  /// </para>
  /// <para>
  /// Setting <see cref="CreateObjectEventArgs.SuggestedType"/> to null suppresses 
  /// <see cref="Adapter"/> to create new object.
  /// </para>
  /// <para>
  /// Setting <see cref="CreateObjectEventArgs.Update"/> property to <see langword="false"/> suppresses
  /// <see cref="Adapter"/> to register newly created object for update.
  /// </para>
  /// <para>
  /// Setting <see cref="CreateObjectEventArgs.Delay"/> property to <see langword="true"/> supresses
  /// <see cref="Adapter"/> to create an object but <see cref="Adapter"/> will enqueue it's ID in
  /// <see cref="Adapter.UpdateQueue"/> for later creation.
  /// </para>
  /// </remarks>
  public delegate void CreateObjectEventHandler(object sender, CreateObjectEventArgs e);
}
