// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Diagnostics;

namespace DataObjects.NET.FullText
{
  /// <summary>
  /// <para>
  /// Contains DataObjects.NET full-text indexing and search support classes.
  /// </para>
  /// <para>
  /// The following <see cref="TraceSwitch"/>es are available in the
  /// full-text indexing and search layer:
  /// <see cref="FtsDriver.TraceUserCodeExceptionsSwitch"/>
  /// (see <see cref="FtsDriver.TraceUserCodeExceptionsSwitchName"/> also), 
  /// <see cref="FtsDriver.TraceIndexerExceptionsSwitch"/>
  /// (see <see cref="FtsDriver.TraceIndexerExceptionsSwitchName"/> also).
  /// </para>
  /// </summary>
  internal class NamespaceDoc {}
}
