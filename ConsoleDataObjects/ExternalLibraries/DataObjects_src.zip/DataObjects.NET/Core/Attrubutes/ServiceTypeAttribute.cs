// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using DataObjects.NET.FullText;
using DataObjects.NET.FullText.Drivers.Native;

namespace DataObjects.NET.Attributes
{
  /// <summary>
  /// Specifies the type of the <see cref="DataService"/>.
  /// <seealso cref="DataService"/>
  /// <seealso cref="Session.GetService"/>
  /// <seealso cref="Session.CreateService"/>
  /// </summary>
  /// <remarks>
  /// <note>This attribute can be applied to persistent services
  /// (<see cref="DataService"/> descendants).</note>
  /// <para>
  /// <example>Example (code of <see cref="NativeFtIndexer"/> service):
  /// <code lang="C#">
  ///  [ServiceType(DataServiceType.NonShared)] // !!
  ///  public abstract class NativeFtIndexer : RuntimeService
  ///  {
  ///    private TimeSpan period      = TimeSpan.FromMinutes(1);
  ///    private TimeSpan shortPeriod = TimeSpan.FromSeconds(3);
  ///    private TimeSpan nextPeriod  = TimeSpan.FromMinutes(1);
  ///    private int      maxObjectsPerIteration = 200;
  ///
  ///    [Transactional(TransactionMode.Disabled)]
  ///    public override TimeSpan GetDelay(Exception e)
  ///    {
  ///      return nextPeriod;
  ///    }
  ///
  ///    public override void Execute()
  ///    {
  ///      nextPeriod = period;
  ///      try {
  ///        // We need maximal permissions during re-indexing
  ///        DisableSecurity();
  ///        try {
  ///          string falseValue = Session.DriverInfo.SupportsRealBoolean ? "false" : "0";
  ///          Query q = new Query(Session, 
  ///            "Select top "+maxObjectsPerIteration.ToString()+" IFtObject instances " +
  ///            "with (SkipLocked) " +
  ///            "where {FtRecordIsUpToDate}="+falseValue);
  ///          QueryResult r = q.Execute();
  ///          if (r.Count==maxObjectsPerIteration)
  ///            nextPeriod = shortPeriod;
  ///          foreach (IFtObject ftObj in r)
  ///            ftObj.UpdateFtRecord();
  ///        }
  ///        finally {
  ///          EnableSecurity();
  ///        }
  ///      }
  ///      catch {
  ///        nextPeriod = shortPeriod;
  ///        throw;
  ///      }
  ///    }
  ///
  ///    protected virtual void OnCreate(TimeSpan period)
  ///    {
  ///      this.period = period;
  ///    }
  ///
  ///    protected virtual void OnCreate(TimeSpan period, TimeSpan shortPeriod)
  ///    {
  ///      this.period = period;
  ///      this.shortPeriod = shortPeriod;
  ///    }
  ///
  ///    protected virtual void OnCreate(TimeSpan period, TimeSpan shortPeriod,
  ///      int maxObjectsPerIteration)
  ///    {
  ///      this.period = period;
  ///      this.shortPeriod = shortPeriod;
  ///      this.maxObjectsPerIteration = maxObjectsPerIteration;
  ///    }
  ///
  ///    protected virtual void OnCreate(int maxObjectsPerIteration)
  ///    {
  ///      this.maxObjectsPerIteration = maxObjectsPerIteration;
  ///    }
  ///
  ///    protected override void OnCreate()
  ///    {
  ///    }
  ///  }
  /// </code>
  /// </example>
  /// </para>
  /// </remarks>
  [AttributeUsage(AttributeTargets.Class, AllowMultiple = false, Inherited = false)]
  [Serializable]
  public class ServiceTypeAttribute: DataObjectAttribute
  {
    private DataServiceType serviceType;
    /// <summary>
    /// Gets or sets the <see cref="DataServiceType">type</see> of the <see cref="DataService"/>.
    /// <seealso cref="DataServiceType"/>
    /// </summary>
    public  DataServiceType ServiceType {
      get {return serviceType;}
      set {serviceType = value;}
    }
    
    private DataServiceVisibilityLevel serviceVisibilityLevel;
    /// <summary>
    /// Gets or sets the <see cref="DataServiceVisibilityLevel">visibility level</see> of the <see cref="DataService"/>.
    /// <seealso cref="DataServiceVisibilityLevel"/>
    /// </summary>
    public  DataServiceVisibilityLevel ServiceVisibilityLevel {
      get {return serviceVisibilityLevel;}
      set {serviceVisibilityLevel = value;}
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    public ServiceTypeAttribute(DataServiceType serviceType) 
        :this(serviceType,DataServiceVisibilityLevel.Default)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    public ServiceTypeAttribute(DataServiceType serviceType, DataServiceVisibilityLevel serviceVisibilityLevel) 
    {
      this.serviceType = serviceType;
      this.serviceVisibilityLevel = serviceVisibilityLevel;
    }
  }
}
