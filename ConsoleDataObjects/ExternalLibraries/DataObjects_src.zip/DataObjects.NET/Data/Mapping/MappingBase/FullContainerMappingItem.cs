// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.ComponentModel;

namespace DataObjects.NET.Data
{
  /// <summary>
  /// Base class for all mapping item classes that maps to table
  /// and has a FieldMappingCollection, DocMappingCollection and VtcMappingCollection.
  /// </summary>
  public abstract class FullContainerMappingItem: FieldContainerMappingItem
  {
    private DocMappingCollection doCollections;
    private VtcMappingCollection vtCollections;
    
    /// <summary>
    /// Gets DataObjectCollection mapping collection.
    /// </summary>
    [Category("Mapping")]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    public DocMappingCollection DoCollections {
      get {
        return doCollections;
      }
    }
    
    /// <summary>
    /// Gets ValueTypeCollection mapping collection.
    /// </summary>
    [Category("Mapping")]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    public VtcMappingCollection VtCollections {
      get {
        return vtCollections;
      }
    }
    
    /// <summary>
    /// Initializes a new instance of the <see cref="MappingToTableItem"/> class.
    /// </summary>
    /// <param name="tableName">Database table name.</param>
    public FullContainerMappingItem(string tableName): base(tableName)
    {
      this.doCollections = new DocMappingCollection(this);
      this.vtCollections = new VtcMappingCollection(this);
    }
  }
}
