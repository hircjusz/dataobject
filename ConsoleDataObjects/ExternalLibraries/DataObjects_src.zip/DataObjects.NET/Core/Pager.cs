// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;

namespace DataObjects.NET
{
  /// <summary>
  /// Provides base paging functionality - allows to browse large 
  /// <see cref="IList">collections</see> page-by-page.
  /// <seealso cref="QueryPager"/>
  /// </summary>
  public class Pager: Object,
    IPager
  {
    /// <summary>
    /// Default <see cref="PageSize"/> value.
    /// </summary>
    protected const int DefaultPageSize = 10;
    
    private int page        = 0;
    private int pageSize    = DefaultPageSize;
    private int totalCount  = -1;
    private IList baseCollection = null;

    /// <summary>
    /// Gets or sets total count of items that are browsed by
    /// this <see cref="Pager"/>.
    /// </summary>
    public int TotalCount {      
      get {
        if (totalCount<0)
          totalCount = GetTotalCount();
        return totalCount;
      }
      set {
        if (value<0)
          throw new ArgumentOutOfRangeException("value", value,
            "TotalCount should be greater then or equal to zero.");
        totalCount = value;
      }
    }
    
    /// <summary>
    /// Returns total count of items when <see cref="TotalCount"/>
    /// isn't specified explicitely.
    /// This method should be property overriden in descendants -
    /// its implementation in this class always throws
    /// <see cref="InvalidOperationException"/>.
    /// </summary>
    /// <returns>Total count of items.</returns>
    protected virtual int GetTotalCount()
    {
      if (baseCollection==null)
        throw new InvalidOperationException(
          "PagerBase is incapable of getting total count of items while BaseCollection is null. " +
          "GetTotalCount() method should be property overriden.");
      else
        return BaseCollection.Count;
    }

    /// <summary>
    /// Gets count of pages that are browsed by
    /// this <see cref="Pager"/>.
    /// </summary>
    public int PageCount {      
      get {
        if (PageSize<=0)
          return 0;
        // return (TotalCount-1) / PageSize + 1;
        if (TotalCount>0) {
          int pc = TotalCount/PageSize;
          return (pc*PageSize==TotalCount ? pc : pc+1);
        }
        else 
          return 1;
      }
    }    

    /// <summary>
    /// Gets count of items on the current <see cref="Page"/>.
    /// </summary>
    public int Count {      
      get {
        if (pageSize<=0)
          return TotalCount;
        if (Page<PageCount-1)
          return PageSize;
        else if (Page==PageCount-1)
          return TotalCount - Page*PageSize;
        else
          return 0;
      }
    }    

    /// <summary>
    /// Gets or sets zero-based index of current page.
    /// </summary>
    public int Page {
      get {
        return page;
      } 
      set {
        if (pageSize==0 && value != 0)    
          throw new ArgumentOutOfRangeException("value", value,
            "When page size is equal to zero page should be equal to zero.");
        if (value<0)
          throw new ArgumentOutOfRangeException("value", value,
            "Page should be greater then or equal to zero.");        
        if (value>=PageCount) {
          if (pageSize>0)
            throw new ArgumentOutOfRangeException("value", value,
              String.Format("Page should be less then {0}.", PageCount));
          else if (page!=0)
            throw new ArgumentOutOfRangeException("value", value,
              "Page should be less then 1.");
        }
        int oldPage = page;
        OnPageChanging(oldPage, value);
        page = value;
        OnPageChanged(oldPage, value);
      }
    }
    
    /// <summary>
    /// Gets or sets page size.
    /// Default value of this property is <see langword="10"/>.
    /// </summary>
    public int PageSize {
      get {
        return pageSize;
      }
      set {
        if (value<0)
          throw new ArgumentOutOfRangeException("value", value,
            "PageSize should be greater then or equal to zero.");
        pageSize=value;
      }
    }                  
    
    /// <summary>
    /// Gets item with specified <paramref name="index"/>
    /// on the current page.
    /// </summary>
    /// <param name="index">Index of item to get.</param>
    public object this[int index] {
      get {
        return this[index, false];
      }
      set {
        throw new InvalidOperationException(
          "this[index]=value isn't supported by Pager.");
      }
    }
    
    /// <summary>
    /// Gets item with specified <paramref name="index"/>.
    /// </summary>
    /// <param name="index">Index of item to get.</param>
    /// <param name="indexIsAbsolute"><see langword="True"/> if specified
    /// <paramref name="index"/> is absolute; otheriwise <paramref name="index"/>
    /// is current page-based.</param>
    public object this[int index, bool indexIsAbsolute] {
      get {
        if (!indexIsAbsolute) {
          if (index<0 || index>=Count)
            throw new ArgumentOutOfRangeException("index", index, 
              "Index is out of range.");
          index = PageSize*Page+index;
        }
        else {
          if (index<0 || index>=TotalCount)
            throw new ArgumentOutOfRangeException("index", index, 
              "Index is out of range.");
        }
        EnsureItemAvailability(index);
        return BaseCollection[GetRealIndex(index)];
      }
      set {
        throw new InvalidOperationException(
          "this[index, indexIsAbsolute]=value isn't supported by Pager.");
      }
    }

      protected virtual int GetRealIndex(int index)
      {
          return index;
      }

    /// <summary>
    /// Returns an <see cref="Array"/> containing all items
    /// located on the current <see cref="Page"/>.
    /// </summary>
    /// <returns><see cref="Array"/> containing all items
    /// located on the current <see cref="Page"/>.</returns>
    public Array ToArray()
    {
      object[] a = new object[Count];
      ((ICollection)this).CopyTo(a, 0);
      return a;
    }

    /// <summary>
    /// Gets base <see cref="IList">collection</see> of this 
    /// <see cref="Pager"/> instance.
    /// <seealso cref="SetBaseCollection"/>
    /// <seealso cref="EnsureItemAvailability"/>
    /// <seealso cref="IsBaseCollectionItemLoaded"/>
    /// <seealso cref="LoadBaseCollectionRange"/>
    /// </summary>
    /// <remarks>
    /// Base collection is a collection containing currently loaded items.
    /// It may contain some empty spaces between loaded items - 
    /// all depends on underlying implementation of the following methods:
    /// <see cref="IsBaseCollectionItemLoaded"/>, 
    /// <see cref="LoadBaseCollectionRange"/>.
    /// </remarks>
    public IList BaseCollection {
      get {
        return baseCollection;
      }
    }
    
    /// <summary>
    /// Sets <see cref="BaseCollection"/> property to the specified 
    /// <paramref name="value"/>.
    /// <seealso cref="BaseCollection"/>
    /// <seealso cref="EnsureItemAvailability"/>
    /// <seealso cref="IsBaseCollectionItemLoaded"/>
    /// <seealso cref="LoadBaseCollectionRange"/>
    /// </summary>
    /// <param name="value">New <see cref="BaseCollection"/> value.</param>
    protected void SetBaseCollection(IList value)
    {
      baseCollection = value;
    }

    /// <summary>
    /// Ensures that item with specified <paramref name="absoluteIndex"/> 
    /// is available in <see cref="BaseCollection"/> by invoking
    /// <see cref="IsBaseCollectionItemLoaded"/>, and additionally -
    /// <see cref="LoadBaseCollectionRange"/> (for the required page), if 
    /// <see cref="IsBaseCollectionItemLoaded"/> returned <see langword="false"/>.
    /// <seealso cref="BaseCollection"/>
    /// <seealso cref="SetBaseCollection"/>
    /// <seealso cref="IsBaseCollectionItemLoaded"/>
    /// <seealso cref="LoadBaseCollectionRange"/>
    /// </summary>
    /// <param name="absoluteIndex">Absolute index of item.</param>
    public void EnsureItemAvailability(int absoluteIndex)
    {
      if (absoluteIndex<0 || absoluteIndex>=TotalCount)
        throw new ArgumentOutOfRangeException("absoluteIndex", absoluteIndex, 
          "Absolute index is out of range.");
      if (IsBaseCollectionItemLoaded(absoluteIndex))
        return;
      else {
        int count      = 1;
        int startIndex = absoluteIndex;
        if (PageSize!=0) {
          count = PageSize;
          startIndex = (absoluteIndex/PageSize)*PageSize;
          if (startIndex+count > TotalCount)          
            count = TotalCount - startIndex;
        }
        LoadBaseCollectionRange(startIndex, count, absoluteIndex);
      }
    }
    
    /// <summary>
    /// Returns <see langword="true"/> if <see cref="BaseCollection"/> 
    /// item with specified <paramref name="index"/> is loaded (available); 
    /// otherwise, <see langword="false"/>.
    /// Override this method to implement custom page loading behavior.
    /// <seealso cref="BaseCollection"/>
    /// <seealso cref="SetBaseCollection"/>
    /// <seealso cref="EnsureItemAvailability"/>
    /// <seealso cref="LoadBaseCollectionRange"/>
    /// </summary>
    /// <param name="index">Absolute index of item to check.</param>
    /// <returns><see langword="True"/> if <see cref="BaseCollection"/> 
    /// item with specified <paramref name="index"/> is loaded (available); 
    /// otherwise, <see langword="false"/>.</returns>
    protected virtual bool IsBaseCollectionItemLoaded(int index)
    {
      return true;
    }
    
    /// <summary>
    /// Loads a range of items into <see cref="baseCollection"/>.
    /// Override this method to implement custom page loading behavior.
    /// <seealso cref="BaseCollection"/>
    /// <seealso cref="SetBaseCollection"/>
    /// <seealso cref="EnsureItemAvailability"/>
    /// <seealso cref="IsBaseCollectionItemLoaded"/>
    /// </summary>
    /// <param name="startIndex">Absolute index of first item to load.</param>
    /// <param name="requiredItemIndex">Index of item that should be definitely loaded.</param>
    /// <param name="count">Number of items to load.</param>
    protected virtual void LoadBaseCollectionRange(int startIndex, int count, int requiredItemIndex)
    {
      throw new InvalidOperationException(
        "Pager is incapable of loading BaseCollection range. " +
        "LoadBaseCollectionRange() method should be property overriden.");
    }
    
    /// <summary>
    /// Reloads the <see cref="BaseCollection"/> and sets current 
    /// <see cref="Page"/> index to <see langword="0"/>.
    /// </summary>
    public virtual void Reload()
    { 
      totalCount = -1; 
      page = 0; 
    }
    

    // Events
    
    /// <summary>
    /// Called before any <see cref="Page"/> change.
    /// </summary>
    /// <param name="oldPageValue">Old <see cref="Page"/> property value.</param>
    /// <param name="newPageValue">New <see cref="Page"/> property value.</param>
    protected void OnPageChanging(int oldPageValue, int newPageValue)
    {
    }

    /// <summary>
    /// Called after any <see cref="Page"/> change.
    /// </summary>
    /// <param name="oldPageValue">Old <see cref="Page"/> property value.</param>
    /// <param name="newPageValue">New <see cref="Page"/> property value.</param>
    protected void OnPageChanged(int oldPageValue, int newPageValue)
    {
    }
    

    // IList, ICollection & IEnumerable methods

    /// <summary>
    /// Always throws <see cref="InvalidOperationException"/>:
    /// <see cref="Pager"/> doesn't support this method.
    /// </summary>
    /// <param name="value">Value to search for.</param>
    /// <returns><see langword="True"/> if the object is found; otherwise, <see langword="false"/>.</returns>
    bool IList.Contains(object value) 
    {
      throw new InvalidOperationException(
        "IList.Contains isn't supported by Pager.");
    }
    
    /// <summary>
    /// Always throws <see cref="InvalidOperationException"/>:
    /// <see cref="Pager"/> doesn't support this method.
    /// </summary>
    /// <param name="value">The value to locate.</param>
    /// <returns>The index of the first occurrence of value within the entire collection, if found; otherwise, -1.</returns>
    int  IList.IndexOf(object value)
    {
      throw new InvalidOperationException(
        "IList.IndexOf isn't supported by Pager.");
    }

    /// <summary>
    /// Always throws <see cref="InvalidOperationException"/>:
    /// <see cref="Pager"/> doesn't support this method.
    /// </summary>
    /// <param name="value">Item to add.</param>
    /// <returns>Index of newly added item.</returns>
    int  IList.Add(Object value) 
    {
      throw new InvalidOperationException(
        "IList.Add isn't supported by Pager.");
    }
    
    /// <summary>
    /// Always throws <see cref="InvalidOperationException"/>:
    /// <see cref="Pager"/> doesn't support this method.
    /// </summary>
    /// <param name="index">The zero-based index at which value should be inserted.</param>
    /// <param name="value">Item to insert.</param>
    void IList.Insert(int index, Object value)
    {
      throw new InvalidOperationException(
        "IList.Insert isn't supported by Pager.");
    }

    /// <summary>
    /// Always throws <see cref="InvalidOperationException"/>:
    /// <see cref="Pager"/> doesn't support this method.
    /// </summary>
    /// <param name="value">Item to remove.</param>
    void IList.Remove(Object value)
    {
      throw new InvalidOperationException(
        "IList.Remove isn't supported by Pager.");
    }

    /// <summary>
    /// Always throws <see cref="InvalidOperationException"/>:
    /// <see cref="Pager"/> doesn't support this method.
    /// </summary>
    /// <param name="index">The zero-based index of the element to remove.</param>
    void IList.RemoveAt(int index)
    {
      throw new InvalidOperationException(
        "IList.RemoveAt isn't supported by Pager.");
    }
    
    /// <summary>
    /// Always throws <see cref="InvalidOperationException"/>:
    /// <see cref="Pager"/> doesn't support this method.
    /// </summary>
    void IList.Clear()
    {
      throw new InvalidOperationException(
        "IList.Clear isn't supported by Pager.");
    }

    /// <summary>
    /// Gets a value indicating whether the <see cref="IList"/> has a fixed size.
    /// </summary>
    /// <returns>Always returns <see langword="true"/>.</returns>
    bool IList.IsFixedSize {
      get {
        return true;
      }
    }
    
    /// <summary>
    /// Gets a value indicating whether the <see cref="IList"/> is read-only.
    /// </summary>
    /// <returns>Always returns <see langword="true"/>.</returns>
    bool IList.IsReadOnly {
      get {
        return true;
      }
    }
    
    /// <summary>
    /// Returns an enumerator that can iterate through the
    /// <see cref="Pager"/> instance.
    /// </summary>
    /// <returns>
    /// An <see cref="IEnumerator"/> for the 
    /// <see cref="Pager"/> instance.
    /// </returns>
    public IEnumerator GetEnumerator()
    {
       return new PagerEnumerator(this);
    }
    
    /// <summary>
    /// Copies items located on the current <see cref="Page"/> to an <see cref="Array"/>, 
    /// starting at a particular <see cref="Array"/> <paramref name="index"/>.
    /// </summary>
    /// <param name="array">One-dimensional <see cref="Array"/> that is 
    /// the destination of the elements copied from this collection. 
    /// The <see cref="Array"/> must have zero-based indexing.</param>
    /// <param name="index">Zero-based index in <paramref name="array"/> 
    /// at which copying begins.</param>
    void ICollection.CopyTo(Array array, int index)
    {
      int cnt = Count;
      for (int i = 0; i<cnt; i++)
        array.SetValue(this[i], index+i);
    }
    
    /// <summary>
    /// Gets a value indicating whether access to the 
    /// collection is synchronized (thread-safe).
    /// </summary>
    /// <returns><see langword="True"/> if access to the collection is synchronized (thread-safe); otherwise, <see langword="false"/>.</returns>
    bool ICollection.IsSynchronized {
      get {
        return false;
      }
    }
    
    /// <summary>
    /// Gets an object that can be used to synchronize access to the collection.
    /// </summary>
    /// <returns>An object that can be used to synchronize access to the collection.</returns>
    object ICollection.SyncRoot {
      get {
        return this;
      }
    }
    
    
    // Constructors
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    protected Pager()
    {
    }            

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="baseCollection">A <see cref="IList">collection</see> 
    /// that should be browsed page-by-page by this <see cref="Pager"/>.</param>
    /// <param name="pageSize">Page size.</param>
    public Pager(IList baseCollection, int pageSize)
    {
      if (baseCollection==null)
        throw new ArgumentNullException("baseCollection");
      this.baseCollection = baseCollection;
      PageSize = pageSize;
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="baseCollection">A <see cref="IList">collection</see> 
    /// that should be browsed page-by-page by this <see cref="Pager"/>.</param>
    public Pager(IList baseCollection): this(baseCollection, DefaultPageSize)
    {
    }
  }
}
