// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;

namespace DataObjects.NET.Install
{
  /// <summary>
  /// Contains DataObjects.NET installer.
  /// Currently installer is used only to install\uninstall
  /// DataObjects.NET performance counters.
  /// </summary>
  internal class NamespaceDoc {}
}
