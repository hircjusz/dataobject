// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using DataObjects.NET.Attributes;

namespace DataObjects.NET.Helpers
{
  /// <summary>
  /// Enumerates different compression methods (algorithms) that can be used by
  /// <see cref="Compressor"/>.
  /// </summary>
  public enum CompressionMethod
  {
    /// <summary>
    /// No compression (value should be stored as is).
    /// Value is <see langword="0x0"/>.
    /// </summary>
    None = 0x0,
    /// <summary>
    /// Zip compression method (uses classes from <see langword="SharpZipLib"/> library).
    /// Value is <see langword="0x1"/>.
    /// </summary>
    Zip  = 0x1,
  }
}
