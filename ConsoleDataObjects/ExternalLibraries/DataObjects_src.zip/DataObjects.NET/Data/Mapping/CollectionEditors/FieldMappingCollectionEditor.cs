// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using DataObjects.NET.Data;

namespace DataObjects.NET.Data.Design
{
  /// <summary>
  /// Editor for the field mapping collections.
  /// </summary>
  public class FieldMappingCollectionEditor: MappingCollectionEditorBase
  {
    /// <summary>
    /// Initializes a new instance of the <see cref="FieldMappingCollectionEditor"/> class.
    /// </summary>
    public FieldMappingCollectionEditor(): base(typeof(FieldMappingCollection), typeof(FieldMappingItem))
    {
    }
  }
}
