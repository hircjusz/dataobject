// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Attributes;
using DataObjects.NET.Security;

namespace DataObjects.NET
{
  /// <summary>
  /// Enumeration of possible security modes for a <see cref="Domain"/>
  /// (see <see cref="Domain.SecurityMode">Domain.SecurityMode</see>).
  /// <seealso cref="Domain.SecurityMode"/>
  /// </summary>
  [Flags]
  public enum DomainSecurityMode
  {
    /// <summary>
    /// Standard security mode.
    /// Inherited "deny" wins explicit "allow" on a particular object.
    /// "Deny" for any role wins any "allow" for any user or role
    /// that belongs to this role.
    /// Value is <see langword="0"/>. 
    /// </summary>
    Standard = 0,
    /// <summary>
    /// Standard security mode.
    /// Inherited "deny" wins explicit "allow" on a particular object.
    /// "Deny" for any role wins any "allow" for any user or role
    /// that belongs to this role.
    /// Value is <see langword="0"/>. 
    /// </summary>
    InheritedDenyWinsExplicitAllow = 0,
    /// <summary>
    /// Modern security mode (introduced in DataObjects.NET 2.2).
    /// Explicit "allow" or "deny" wins inherited "allow" or "deny" 
    /// on a particular object.
    /// "Deny" for any role wins any "allow" for any user or role
    /// that belongs to this role.
    /// Value is <see langword="1"/>. 
    /// </summary>
    ExplicitAllowOrDenyWinsInheritedAllowOrDeny = 1,
    /// <summary>
    /// Modern security mode (introduced in DataObjects.NET 2.2).
    /// Explicit "allow" or "deny" wins inherited "allow" or "deny" 
    /// on a particular object.
    /// "Deny" for any role wins any "allow" for any user or role
    /// that belongs to this role.
    /// Value is <see langword="1"/>. 
    /// </summary>
    Modern = 1,
    /// <summary>
    /// Allows to not inherit security permissions from
    /// security parent object if <see cref="AccessControlList.Inherit"/>
    /// is <see langword="false"/>.
    /// Value is <see langword="0x10000"/>. 
    /// </summary>
    AllowNotInheritPermissions = 0x10000,
  }
}
