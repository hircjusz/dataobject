// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Runtime.Serialization;
using DataObjects.NET.Security;

namespace DataObjects.NET.Exceptions
{
  /// <summary>
  /// Thrown on different security violation attemps.
  /// <seealso cref="Session.SecurityOptions"/>
  /// <seealso cref="Domain.SecurityOptions"/>
  /// <seealso cref="Domain.SessionSecurityOptions"/>
  /// <seealso cref="SessionBoundObject.DisableSecurity"/>
  /// <seealso cref="SessionBoundObject.EnableSecurity"/>
  /// <seealso cref="DataObjects.NET.Security"/>
  /// <seealso cref="DataObjects.NET.Security.Permissions"/>
  /// </summary>
  [Serializable]
  public class SecurityException: DataObjectsDotNetException, 
    ISerializable
  {
    private IPermission requiredPermission;
    
    /// <summary>
    /// Required permission
    /// (e.g. a permission, that was failed to pass 
    /// the <see cref="ISecureObject.Demand"/>).
    /// </summary>
    public IPermission RequiredPermission {
      get {
        return requiredPermission;
      }
    }
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    public SecurityException(): base("Security violation occured.") {}
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="text">Text of message.</param>
    public SecurityException(string text): base(text) {}

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="innerException">Inner exception.</param>
    public SecurityException(Exception innerException): this("Security violation occured.",innerException) 
    {
    }
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="text">Text of message.</param>
    /// <param name="innerException">Inner exception.</param>
    public SecurityException(string text, Exception innerException): base(text,innerException) 
    {
    }
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="requiredPermission">Required permission
    /// (e.g. a permission, that was failed to pass 
    /// the <see cref="ISecureObject.Demand"/>).</param>
    public SecurityException(IPermission requiredPermission): 
      base("Security violation occured.") 
    {
      this.requiredPermission = requiredPermission;
    }
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="text">Text of message.</param>
    /// <param name="requiredPermission">Required permission
    /// (e.g. a permission, that was failed to pass 
    /// the <see cref="ISecureObject.Demand"/>).</param>
    public SecurityException(string text, IPermission requiredPermission): 
      base(text) 
    {
      this.requiredPermission = requiredPermission;
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="innerException">Inner exception.</param>
    /// <param name="requiredPermission">Required permission
    /// (e.g. a permission, that was failed to pass 
    /// the <see cref="ISecureObject.Demand"/>).</param>
    public SecurityException(Exception innerException, IPermission requiredPermission): 
      this("Security violation occured.", innerException, requiredPermission) 
    {
    }
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="text">Text of message.</param>
    /// <param name="innerException">Inner exception.</param>
    /// <param name="requiredPermission">Required permission
    /// (e.g. a permission, that was failed to pass 
    /// the <see cref="ISecureObject.Demand"/>).</param>
    public SecurityException(string text, Exception innerException, IPermission requiredPermission): 
      base(text, innerException) 
    {
      this.requiredPermission = requiredPermission;
    }
    
    // Serialization support
    
    /// <summary>
    /// Serializer.
    /// </summary>
    /// <param name="info"><see cref="SerializationInfo"/> object.</param>
    /// <param name="context"><see cref="StreamingContext"/> object.</param>
    public override void GetObjectData(SerializationInfo info, StreamingContext context)
    {
      base.GetObjectData(info, context);
      info.AddValue("RequiredPermission", requiredPermission);
    }

    /// <summary>
    /// Deserialization constructor.
    /// </summary>
    /// <param name="info"><see cref="SerializationInfo"/> object.</param>
    /// <param name="context"><see cref="StreamingContext"/> object.</param>
    protected SecurityException(SerializationInfo info, StreamingContext context):
      base(info, context)
    {
      requiredPermission = (IPermission)info.GetValue("RequiredPermission", typeof(object));
    }
  }
}
