// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using DataObjects.NET;
using DataObjects.NET.Data;

namespace DataObjects.NET.Data
{
  /// <summary>
  /// Represents a method that will handle the 
  /// <see cref="Adapter.SetProperty"/> events.
  /// </summary>
  /// <param name="sender">The source of the event.</param>
  /// <param name="e">An <see cref="PropertyEventArgs"/> that contains the event data.</param>
  /// <remarks>
  /// This event is raised when <see cref="Adapter"/> 
  /// needs to set <see cref="DataObject"/>'s property value.
  /// </remarks>
  public delegate void SetPropertyEventHandler(object sender, PropertyEventArgs e);
}
