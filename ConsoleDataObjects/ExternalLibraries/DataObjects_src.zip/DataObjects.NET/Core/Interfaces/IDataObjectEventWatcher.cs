// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;
using System.Runtime.Serialization;
using DataObjects.NET.Attributes;
using DataObjects.NET.Serialization;
using DataObjects.NET.Security.Permissions;

namespace DataObjects.NET
{
  /// <summary>
  /// An interface that should be implemented by <see cref="DataServiceType.Shared">Shared</see> <see cref="DataService"/>
  /// if it needs to be notified on <see cref="DataObject"/>-related events, such as creation, modification
  /// and deletion of <see cref="DataObject"/> instance.
  /// </summary>
  public interface IDataObjectEventWatcher
  {
    /// <summary>
    /// Called on <see cref="DataObject"/> instance initialization.
    /// <seealso cref="DataObject.OnCreate"/>
    /// </summary>
    /// <remarks>
    /// <para>
    /// This method is executed prior to persisting the instance
    /// to the database, right after <see cref="DataObject.OnCreate"/> 
    /// so some of instance's properties (e.g. <see cref="DataObject.ID"/>, 
    /// <see cref="DataObject.VersionID"/>) aren't initialized on this moment. An attempt
    /// to read the value of such property will lead to <see cref="DataObject.Persist"/>
    /// method invocation.
    /// </para>
    /// <note type="note"><see cref="DataObject.IsCreating"/> is <see langword="true"/>
    /// during this method execution.</note>
    /// <note type="note">This method is always executed in the delayed 
    /// updates mode.</note>
    /// </remarks>
    void OnDataObjectCreated(DataObject dataObject);

    /// <summary>
    /// Called after changes are persisted (see <see cref="DataObject.Persist"/> method)
    /// to the database.
    /// </summary>
    void OnDataObjectPersisted(DataObject dataObject);

    /// <summary>
    /// Called before <see cref="DataObject"/> instance is removed (see <see cref="DataObject.Remove"/> method).
    /// <seealso cref="DataObject.OnRemove"/>
    /// <seealso cref="DataObject.OnRemoved"/>
    /// <seealso cref="DataObject.Remove"/>
    /// <seealso cref="Session.RemoveObjects"/>
    /// <seealso cref="DataObject.RemovalQueue"/>
    /// <seealso cref="DataObjectRemovalQueue"/>
    /// </summary>
    /// <remarks>
    /// <para>
    /// It's recommended to use <see cref="DataObjectRemovalQueue.Add">RemovalQueue.Add(...)</see>
    /// rather than <see cref="DataObject.Remove">DataObject.Remove</see> in this method.
    /// </para>
    /// </remarks>
    void OnDataObjectRemove(DataObject dataObject);
    
    /// <summary>
    /// Called before trying to reload the instance.
    /// Using this method you can disable instance reloading
    /// under certain circumstances (e.g. when it's well known that
    /// instance is never changing).
    /// </summary>
    /// <param name="dataObject">The DataObject instance the event invoked for.</param>
    /// <param name="skipReload">Caller always sets this 
    /// <see langword="false"/> parameter to false. You can set it to
    /// <see langword="true"/>, if reloading should be skipped.</param>
    /// <remarks>
    /// <note type="note">
    /// This method isn't called when it's impossible to skip reloading,
    /// e.g. when instance is dirty.
    /// </note>
    /// <note type="note">
    /// It isn't necessary that instance will be reloaded after execution
    /// of this method, even if <paramref name="skipReload"/> is set to
    /// <see langword="false"/>. For example, no reload will occur if
    /// instance will successfully pass version check further.
    /// </note>
    /// </remarks>
    void OnDataObjectBeforeReload(DataObject dataObject, ref bool skipReload);
    
    /// <summary>
    /// Called after instance is loaded or reloaded.
    /// </summary>
    /// <param name="dataObject">The DataObject instance the event invoked for.</param>
    /// <param name="reload"><see langword="True"/>, if this method is
    /// invoked on reload; otherwise, <see langword="false"/>.</param>
    /// <remarks>
    /// <para>
    /// Parameter <paramref name="reload"/> is <see langword="false"/> during the
    /// instantiation, and <see langword="true"/> on its successive reloads
    /// (e.g. after rollbacks).
    /// </para>
    /// <note type="note">This method is also invoked when instance was removed 
    /// after reloading its data (so check <see cref="DataObject.State"/> property
    /// to detect this situation).
    /// </note>
    /// </remarks>
    void OnDataObjectLoad(DataObject dataObject, bool reload);

    /// <summary>
    /// Serializes object identity, when object is serialized as reference.
    /// <seealso cref="DataObject.OnDeserializeIdentity"/>
    /// <seealso cref="Serializer"/>
    /// <seealso cref="SerializationOptions"/>
    /// <seealso cref="DeserializationOptions"/>
    /// </summary>
    /// <param name="dataObject">The DataObject instance the event invoked for.</param>
    /// <param name="serializer">Serializer that performs the serialization.</param>
    /// <param name="info">Serialization info.</param>
    /// <param name="context">Streaming context.</param>
    void OnDataObjectSerializeIdentity(DataObject dataObject, Serializer serializer, 
      SerializationInfo info, StreamingContext context);
    
    /// <summary>
    /// Converts serialized object identity to real <see cref="DataObject"/>
    /// instance. This method always called with so-called "null object"
    /// (see <see cref="Session.GetNullObject">Session.GetNullObject</see>)
    /// as it's first argument.
    /// <seealso cref="OnDataObjectSerializeIdentity"/>
    /// <seealso cref="Serializer"/>
    /// <seealso cref="SerializationOptions"/>
    /// <seealso cref="DeserializationOptions"/>
    /// </summary>
    /// <param name="dataObject">The DataObject instance the event invoked for.
    /// (It is always so-called "null object" 
    /// the result of <see cref="Session.GetNullObject">Session.GetNullObject</see> call)</param>
    /// <param name="deserializationResult">The result of identity deserialization.
    /// Initially it is the result of <see cref="DataObject.OnDeserializeIdentity"/> method call.</param>
    /// <param name="serializer">Serializer that performs the deserialization.</param>
    /// <param name="info">Serialization info.</param>
    /// <param name="context">Streaming context.</param>
    /// <returns><see cref="DataObject"/> instance that corresponds to
    /// serialized object identity, or <see langword="null"/>.</returns>
    void OnDataObjectDeserializeIdentity(DataObject dataObject, ref DataObject deserializationResult, 
      Serializer serializer, SerializationInfo info, StreamingContext context);

    /// <summary>
    /// Called before instance is serialized (see <see cref="Serializer"/> class).
    /// <seealso cref="DataObject.OnCreateDeserializable"/>
    /// <seealso cref="DataObject.OnDeserializing"/>
    /// <seealso cref="DataObject.OnPropertyDeserializationError"/>
    /// <seealso cref="DataObject.OnDeserialized"/>
    /// <seealso cref="DataObject.OnGraphDeserialized"/>
    /// <seealso cref="Serializer"/>
    /// <seealso cref="SerializationOptions"/>
    /// <seealso cref="DeserializationOptions"/>
    /// </summary>
    /// <param name="dataObject">The DataObject instance the event invoked for.</param>
    /// <param name="serializer">Serializer that performs the serialization.</param>
    /// <param name="info">Serialization info.</param>
    /// <param name="context">Streaming context.</param>
    /// <param name="fields">A <see cref="Hashtable"/> initially containing pairs (Field name, <see langword="true"/>).
    /// You should set some values to <see langword="false"/> or <see langword="null"/> 
    /// in it to disable automatic serialization of corresponding field.
    /// E.g. you should clear it in case when you serialize all fields manually.</param>
    /// <remarks>
    /// <para>
    /// This method demands the following permissions:
    /// <see cref="SerializationPermission"/>.
    /// </para>
    /// <para>
    /// This method is called only when instance is truely 
    /// serialized (also instance can be "serialized"
    /// as "reference" - by simply serializing its ID). 
    /// See <see cref="SerializationOptions"/> and
    /// <see cref="DeserializationOptions"/> for details.
    /// </para>
    /// </remarks>
    void OnDataObjectSerializing(DataObject dataObject, Serializer serializer, 
      SerializationInfo info, StreamingContext context, Hashtable fields);

    /// <summary>
    /// Called before instance is deserialized (see <see cref="Serializer"/> class).
    /// <seealso cref="DataObject.OnCreateDeserializable"/>
    /// <seealso cref="DataObject.OnPropertyDeserializationError"/>
    /// <seealso cref="DataObject.OnDeserialized"/>
    /// <seealso cref="DataObject.OnGraphDeserialized"/>
    /// <seealso cref="DataObject.OnSerializing"/>
    /// <seealso cref="Serializer"/>
    /// <seealso cref="SerializationOptions"/>
    /// <seealso cref="DeserializationOptions"/>
    /// </summary>
    /// <param name="dataObject">The DataObject instance the event invoked for.</param>
    /// <param name="serializer">Serializer that performs the deserialization.</param>
    /// <param name="info">Serialization info.</param>
    /// <param name="context">Streaming context.</param>
    /// <param name="fields">A <see cref="Hashtable"/> initially containing pairs (Field name, <see langword="true"/>).
    /// You should set some values to <see langword="false"/> or <see langword="null"/> 
    /// in it to disable automatic deserialization of corresponding field.
    /// E.g. you should clear it in case when you deserialize all fields manually.</param>
    /// <remarks>
    /// <note type="note"><see cref="DataObject.OnCreate"/>, <see cref="DataObject.OnSetProperty"/> 
    /// <see cref="DataObject.OnPropertyChanged"/>, <see cref="DataObject.OnPropertyContentChanging"/> 
    /// and <see cref="DataObject.OnPropertyContentChanged"/> methods aren't invoked during 
    /// the deserialization.
    /// </note>
    /// <para>
    /// This method is called only when instance is truely 
    /// deserialized (also instance can be "deserialized"
    /// as "reference" - by simply returning an instance with
    /// reference ID). 
    /// See <see cref="SerializationOptions"/> and
    /// <see cref="DeserializationOptions"/> for details.
    /// </para>
    /// <para>
    /// You shouldn't demand any permissions in this method,
    /// because permissions aren't deserialized on this moment.
    /// All permission demands passes for <see cref="DataObject.IsDeserializing"/> 
    /// instances. Use <see cref="DataObject.OnGraphDeserialized"/> event 
    /// handler for permission demands.
    /// </para>
    /// </remarks>
    void OnDataObjectDeserializing(DataObject dataObject, Serializer serializer, 
      SerializationInfo info, StreamingContext context, Hashtable fields);

    /// <summary>
    /// Called on any error during deserialization (see 
    /// <see cref="Serializer"/> class) of instance field.
    /// Implement this method to handle deserialization
    /// errors. This can be very necessary if it's required 
    /// to deserialize another version of object - e.g. if
    /// this version was containing a field that doesn't
    /// exists in the current version.
    /// <seealso cref="DataObject.OnCreateDeserializable"/>
    /// <seealso cref="DataObject.OnDeserializing"/>
    /// <seealso cref="DataObject.OnDeserialized"/>
    /// <seealso cref="DataObject.OnGraphDeserialized"/>
    /// <seealso cref="DataObject.OnSerializing"/>
    /// <seealso cref="Serializer"/>
    /// <seealso cref="SerializationOptions"/>
    /// <seealso cref="DeserializationOptions"/>
    /// </summary>
    /// <param name="dataObject">The DataObject instance the event invoked for.</param>
    /// <param name="serializer">Serializer that performs the deserialization.</param>
    /// <param name="info">Serialization info.</param>
    /// <param name="context">Streaming context.</param>
    /// <param name="propertyName">The name of the field that was 
    /// deserializing.</param>
    /// <param name="culture">The <see cref="Culture"/> of the field that was
    /// deserializing.</param>
    /// <param name="exception">Exception that was thrown during attempt
    /// to deserialize <paramref name="propertyName"/>.</param>
    /// <remarks>
    /// <note type="note"><see cref="DataObject.OnCreate"/>, <see cref="DataObject.OnSetProperty"/> 
    /// <see cref="DataObject.OnPropertyChanged"/>, <see cref="DataObject.OnPropertyContentChanging"/> 
    /// and <see cref="DataObject.OnPropertyContentChanged"/> methods aren't invoked during 
    /// the deserialization.
    /// </note>
    /// <para>
    /// This method can be invoked only when instance is truely 
    /// deserialized (also instance can be "deserialized"
    /// as "reference" - by simply returning an instance with
    /// reference ID).
    /// See <see cref="SerializationOptions"/> and
    /// <see cref="DeserializationOptions"/> for details.
    /// </para>
    /// <note type="note">Default implementation of this method
    /// always throws passed <paremref name="exception"/>.
    /// Don't throw any exception if your implementation has successfully
    /// handled the situation.
    /// </note>
    /// <para>
    /// You shouldn't demand any permissions in this method,
    /// because permissions aren't deserialized on this moment.
    /// All permission demands passes for <see cref="DataObject.IsDeserializing"/> 
    /// instances. Use <see cref="DataObject.OnGraphDeserialized"/> event 
    /// handler for permission demands.
    /// </para>
    /// </remarks>
    void OnDataObjectPropertyDeserializationError(DataObject dataObject, Serializer serializer, 
      SerializationInfo info, StreamingContext context, 
      string propertyName, Culture culture, Exception exception);


    /// <summary>
    /// Called after instance is deserialized.
    /// <seealso cref="DataObject.OnCreateDeserializable"/>
    /// <seealso cref="DataObject.OnDeserializing"/>
    /// <seealso cref="DataObject.OnPropertyDeserializationError"/>
    /// <seealso cref="DataObject.OnGraphDeserialized"/>
    /// <seealso cref="DataObject.OnSerializing"/>
    /// <seealso cref="Serializer"/>
    /// <seealso cref="SerializationOptions"/>
    /// <seealso cref="DeserializationOptions"/>
    /// </summary>
    /// <param name="dataObject">The DataObject instance the event invoked for.</param>
    /// <param name="serializer">Serializer that performs the deserialization.</param>
    /// <remarks>
    /// <note type="note"><see cref="DataObject.OnCreate"/>, <see cref="DataObject.OnSetProperty"/> 
    /// <see cref="DataObject.OnPropertyChanged"/>, <see cref="DataObject.OnPropertyContentChanging"/> 
    /// and <see cref="DataObject.OnPropertyContentChanged"/> methods aren't invoked during 
    /// the deserialization.
    /// </note>
    /// <para>
    /// You can change some instance properties here, e.g.
    /// to set correct <see cref="DataObject.SecurityParent"/> value.
    /// </para>
    /// <para>
    /// This method is called only when instance is truely 
    /// deserialized (also instance can be "deserialized"
    /// as "reference" - by simply returning an instance with
    /// reference ID). See <see cref="SerializationOptions"/> and
    /// <see cref="DeserializationOptions"/> for details.
    /// </para>
    /// <para>
    /// You shouldn't demand any permissions in this method,
    /// because permissions aren't deserialized on this moment.
    /// All permission demands passes for <see cref="DataObject.IsDeserializing"/> 
    /// instances. Use <see cref="DataObject.OnGraphDeserialized"/> event 
    /// handler for permission demands.
    /// </para>
    /// </remarks>
    void OnDataObjectDeserialized(DataObject dataObject, Serializer serializer);

    /// <summary>
    /// Called when the whole object graph is completely deserialized.
    /// <seealso cref="DataObject.OnCreateDeserializable"/>
    /// <seealso cref="DataObject.OnDeserializing"/>
    /// <seealso cref="DataObject.OnPropertyDeserializationError"/>
    /// <seealso cref="DataObject.OnDeserialized"/>
    /// <seealso cref="DataObject.OnSerializing"/>
    /// <seealso cref="Serializer"/>
    /// <seealso cref="SerializationOptions"/>
    /// <seealso cref="DeserializationOptions"/>
    /// </summary>
    /// <param name="dataObject">The DataObject instance the event invoked for.</param>
    /// <param name="serializer">Serializer that performs the deserialization.</param>
    /// <remarks>
    /// <note type="note"><see cref="DataObject.OnCreate"/>, <see cref="DataObject.OnSetProperty"/> 
    /// <see cref="DataObject.OnPropertyChanged"/>, <see cref="DataObject.OnPropertyContentChanging"/> 
    /// and <see cref="DataObject.OnPropertyContentChanged"/> methods are invoked during 
    /// the execution of this method.
    /// </note>
    /// <para>
    /// This method demands the following permissions:
    /// <see cref="ChildrenDeserializationPermission"/> (on <see cref="DataObject.SecurityParent"/> object),
    /// <see cref="ChildrenPermissionsDeserializationPermission"/> (on <see cref="DataObject.SecurityParent"/> object, but
    /// only when <paramref name="serializer"/>.<see cref="Serializer.DeserializationOptions"/>
    /// includes <see cref="DeserializationOptions.DeserializePermissions"/> option).
    /// </para>
    /// <para>
    /// This method is called only when instance is truely 
    /// deserialized (also instance can be "deserialized"
    /// as "reference" - by simply returning an instance with
    /// reference ID). See <see cref="SerializationOptions"/> and
    /// <see cref="DeserializationOptions"/> for details.
    /// </para>
    /// </remarks>
    void OnDataObjectGraphDeserialized(DataObject dataObject, Serializer serializer);

    /// <summary>
    /// Called during <see cref="DataObject.GetProperty"/> method execution.
    /// </summary>
    /// <param name="dataObject">The DataObject instance the event invoked for.</param>
    /// <param name="name">Property name.</param>
    /// <param name="culture">Property culture.</param>
    /// <param name="value">Stored property value.</param>
    /// <returns>Property value to return.</returns>
    /// <remarks>
    /// <para>
    /// This method demands the following permissions:
    /// <see cref="ReadPermission"/>, or
    /// <see cref="ReadPermissionsPermission"/> 
    /// (when <paramref name="name"/>=="Permissions").
    /// </para>
    /// </remarks>
    void OnDataObjectGetProperty(DataObject dataObject, string name, Culture culture, object value);

    /// <summary>
    /// Called during <see cref="DataObject.SetProperty"/> method execution.
    /// Note that this method isn't invoked during the deserialization.
    /// </summary>
    /// <param name="dataObject">The DataObject instance the event invoked for.</param>
    /// <param name="name">Property name.</param>
    /// <param name="culture">Property culture.</param>
    /// <param name="value">New property value.</param>
    /// <remarks>
    /// <para>
    /// This method demands the following permissions:
    /// <see cref="ChangePermission"/>.
    /// </para>
    /// </remarks>
    void OnDataObjectSetProperty(DataObject dataObject, string name, Culture culture, object value);
    
    /// <summary>
    /// Called when some property was changed.
    /// Note that this method isn't invoked during the deserialization.
    /// </summary>
    /// <param name="dataObject">The DataObject instance the event invoked for.</param>
    /// <param name="name">Property name.</param>
    /// <param name="culture">Property culture.</param>
    /// <param name="value">New property value.</param>
    void OnDataObjectPropertyChanged(DataObject dataObject, string name, Culture culture, object value);

    /// <summary>
    /// Called before inner content of some non-<see cref="ValueType"/> 
    /// property is changed.
    /// </summary>
    /// <param name="dataObject">The DataObject instance the event invoked for.</param>
    /// <param name="name">Property name.</param>
    /// <param name="culture">Property culture.</param>
    /// <param name="value">Old property value.</param>
    /// <remarks>
    /// <para>
    /// This method demands the following permissions:
    /// <see cref="ChangePermission"/>, or
    /// <see cref="ChangePermissionsPermission"/> 
    /// (when <paramref name="name"/>=="Permissions").
    /// </para>
    /// </remarks>
    void OnDataObjectPropertyContentChanging(DataObject dataObject, string name, Culture culture, object value);

    /// <summary>
    /// Called when inner content of some non-<see cref="ValueType"/> 
    /// property was changed.
    /// Note that this method isn't invoked during the deserialization.
    /// </summary>
    /// <param name="dataObject">The DataObject instance the event invoked for.</param>
    /// <param name="name">Property name.</param>
    /// <param name="culture">Property culture.</param>
    /// <param name="value">New property value.</param>
    void OnDataObjectPropertyContentChanged(DataObject dataObject, string name, Culture culture, object value);

  }
}
