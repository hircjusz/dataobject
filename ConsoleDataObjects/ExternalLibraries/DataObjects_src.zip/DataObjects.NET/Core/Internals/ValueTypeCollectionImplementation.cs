// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;
using System.Collections.Specialized;
using DataObjects.NET.Attributes;
using DataObjects.NET.Caching;
//using DataObjects.NET.Exceptions;
using DataObjects.NET.Database;
using DataObjects.NET.ObjectModel;
using DataObjects.NET.DatabaseModel;

namespace DataObjects.NET.Internals
{
  /// <summary>
  /// Underlying <see cref="ValueTypeCollection"/> implementation.
  /// </summary>
  internal class ValueTypeCollectionImplementation: 
    IValueTypeCollectionImplementation
  {
    const  int      queryThreshold = 64;

    private ValueTypeCollection     collection;
    private PersisterForCollections persister;
    private ISchemaNode schemaNode;
    private string cOwner;
    private string cItem;
    private DatabaseModel.Index uniqueSearchIndex = null;
    private bool             isLoaded   = false;
    private int              count      = -1;
    private ArrayList        columns;
    private ArrayList        items      = new ArrayList();
    private HybridDictionary itemsIndex = new HybridDictionary();
    private HybridDictionary itemsCache = new HybridDictionary();
    private HybridDictionary itemsUpdateActions = new HybridDictionary();
    private long             freeTemporaryItemId = -1;  
    

    /// <summary>
    /// Called on attachment to <see cref="DataObject"/>.
    /// </summary>
    public void Attach()
    {
      Field field         = collection.Field;
      Culture culture     = collection.Culture;
      ICollectionField cf = (ICollectionField)field;
      
      this.persister      = collection.session.persister.PersisterForCollections;
      this.schemaNode     = cf.GetSchemaNode(culture);
      this.columns        = cf.GetDataColumnNames(culture);
      this.cOwner         = cf.GetOwnerIdColumnName(culture);
      this.cItem          = cf.GetItemIdColumnName(culture);
    }
    
    /// <summary>
    /// Called on detachment from <see cref="DataObject"/>.
    /// </summary>
    public void Detach()
    {
    }

    public void InvalidateCache()
    {
      isLoaded = false;
      count    = -1;
      items.Clear();
      itemsIndex.Clear();
      itemsCache.Clear();
    }

    /// <summary>
    /// <see langword="True"/> if the collection is completely loaded;
    /// otherwise, <see langword="false"/>.
    /// </summary>
    public bool IsLoaded {
      get {
        return isLoaded;
      }
    }
    
    /// <summary>
    /// Indicates whether collection contains delayed updates.
    /// </summary>
    public bool IsChanged {
      get {
        return itemsUpdateActions.Count!=0;
      }
    }
    
    /// <summary>
    /// Caches the specified item.
    /// </summary>
    /// <param name="entry">Entry to cache.</param>
    public void CacheItem(ValueTypeCollectionEntry entry)
    {
      if (!isLoaded && !itemsCache.Contains(entry.InternalItemID))
        itemsCache[entry.InternalItemID] = entry;
    }
    
    /// <summary>
    /// Caches the specified item.
    /// </summary>
    /// <param name="entry">Entry to cache.</param>
    public void CacheItem(ValueTypeQueryResultEntry entry)
    {
      if (!isLoaded && !itemsCache.Contains(entry.ItemID))
        itemsCache[entry.ItemID] = 
          new ValueTypeCollectionEntry(collection, entry.ItemID, entry.InternalValue);
    }
    
    /// <summary>
    /// Loads collection from the database.
    /// </summary>
    public void Load()
    {
      try {
        isLoaded = true;
        items.Clear();
        itemsIndex.Clear();
        itemsCache.Clear();
        if (collection.Owner.State!=DataObjectState.Persistent) {
          count = 0;
          return;
        }
        
        Transaction t = collection.Session.Transaction;
        bool canReadCache = collection.ChangesTrackingMode==ChangesTrackingMode.ThroughOwner;
        bool canCache = (t==null ? false : t.IsReadOnly) && canReadCache;

        if (canReadCache) {
          object[] sHolders = null;
          long[] itemIds = LoadItemsFromGlobalCache(out sHolders);
          if (itemIds!=null) {
            count  = itemIds.Length;
            for (int i = 0; i<itemIds.Length; i++) {
              long itemId = itemIds[i];
              ValueTypeCollectionEntry entry = new ValueTypeCollectionEntry(
                collection, itemId, sHolders[i]);
              items.Add(entry);
              itemsIndex.Add(itemId, i);
              itemsCache[itemId] = entry;
            }
            return;
          }
        }
        
        ArrayList dbItems;
        try {
          dbItems = persister.LoadRange(schemaNode, cOwner, cItem, collection.Owner.ID, -1, RangeType.Greater, 0, columns);
        }
        catch (Exception e) {
          throw collection.session.utils.SubstituteException(e);
        }

        count = dbItems.Count;
        for (int i = 0; i<count; i++) {
          IDictionary dbItem = (IDictionary)dbItems[i];
          dbItem.Add(cOwner, collection.Owner.ID);
          long itemId = Convert.ToInt64(dbItem[cItem]);
          object iValue = collection.ContainedField.InternalValueFromRecord(
            collection.session, collection.Owner, collection.Culture, dbItem);
          ValueTypeCollectionEntry entry = new ValueTypeCollectionEntry(
            collection, itemId, iValue);
          items.Add(entry);
          itemsIndex.Add(itemId, i);
          itemsCache[itemId] = entry;
        }
        
        if (canCache)
          SaveItemsToGlobalCache();
      }
      catch {
        InvalidateCache();
        throw;
      }
    }

    /// <summary>
    /// Loads collection content from the given <see cref="ArrayList"/> contaning preload data.
    /// </summary>
    /// <param name="dbItems">List of items to load.</param>
    /// <param name="startIndex">index in <paaramref name="dbItems"/> to start from.</param>
    /// <param name="count">Number of items to load.</param>
    public void Load(ArrayList dbItems, int startIndex, int count) 
    {
      try {
        isLoaded = true;
        items.Clear();
        itemsIndex.Clear();
        itemsCache.Clear();
        if (collection.Owner.State!=DataObjectState.Persistent) {
          count = 0;
          return;
        }

        long   itemId = 0;
        object iValue = null;
        this.count = count;
        for (int i = 0; i<count; i++) {
          IDictionary dbItem = (IDictionary)dbItems[startIndex+i];
          // dbItem.Add(cOwner, collection.Owner.ID);
          itemId = Convert.ToInt64(dbItem[cItem]);
          iValue = collection.ContainedField.InternalValueFromRecord(
            collection.session, collection.Owner, collection.Culture, dbItem);
          ValueTypeCollectionEntry entry = new ValueTypeCollectionEntry(
            collection, itemId, iValue);
          items.Add(entry);
          itemsIndex.Add(itemId, i);
          itemsCache[itemId] = entry;
        }
      }
      catch {
        InvalidateCache();
        throw;
      }
    }
    
    /// <summary>
    /// Loads collection content from deserialized 
    /// <see cref="DataObject.FastLoadData"/> for this collection.
    /// </summary>
    /// <param name="itemIds">An <see cref="Array"/> containing item IDs.</param>
    /// <param name="iValues">An <see cref="Array"/> containing item values.</param>
    /// <param name="count">The count of items in the collection.</param>
    public void Load(long[] itemIds, object[] iValues, int count)
    {
      try {
        isLoaded = (itemIds.Length==count);
        items.Clear();
        itemsIndex.Clear();
        itemsCache.Clear();
        if (collection.Owner.State!=DataObjectState.Persistent) {
          this.count = 0;
          return;
        }

        long   itemId = 0;
        object iValue = null;
        this.count = count;
        for (int i = 0, itemCount=itemIds.Length; i<itemCount; i++) {
          itemId = itemIds[i];
          iValue = iValues[i];
          ValueTypeCollectionEntry entry = new ValueTypeCollectionEntry(collection, itemId, iValue);
          items.Add(entry);
          itemsIndex.Add(itemId, i);
          itemsCache[itemId] = entry;
        }
      }
      catch {
        InvalidateCache();
        throw;
      }
    }

    /// <summary>
    /// Gets the number of elements contained in the collection.
    /// </summary>
    public int Count {
      get {
        if (count>=0)
          return count;
        else {
          if (collection.Owner.State!=DataObjectState.Persistent)
            return 0;
          else {
            if (collection.PairTo==null)
              Persist();
            else
              collection.session.Persist();
              
            Transaction t = collection.Session.Transaction;
            bool canReadCache = collection.ChangesTrackingMode==ChangesTrackingMode.ThroughOwner;
            bool canCache = (t==null ? false : t.IsReadOnly) && canReadCache;

            if (canReadCache) {
              count = LoadCountFromGlobalCache();
              if (count>=0)
                return count;
            }

            try {
              count = persister.Count(schemaNode,cOwner,collection.Owner.ID);
            }
            catch (Exception e) {
              throw collection.session.utils.SubstituteException(e);
            }
            
            if (canCache)
              SaveCountToGlobalCache();
            
            return count;
          }
        }
      }
    }
    
    /// <summary>
    /// Returns an enumerator that can iterate through the
    /// collection instance.
    /// </summary>
    /// <returns>
    /// An <see cref="IEnumerator"/> for the 
    /// collection instance.
    /// </returns>
    public IEnumerator GetEnumerator()
    {
      return new ValueTypeCollectionEnumerator(items.GetEnumerator());
    }

    /// <summary>
    /// Removes all objects from the collection instance.
    /// </summary>
    public void Clear()
    {
      isLoaded = true;
      count    = 0;
      items.Clear();
      itemsIndex.Clear();
      itemsCache.Clear();
      itemsUpdateActions.Clear();
      try {
        if (collection.PairTo==null)
          persister.Clear(schemaNode, cOwner, collection.Owner.ID);
      }
      catch (Exception e) {
        throw collection.session.utils.SubstituteException(e);
      }
    }

    /// <summary>
    /// Returns <see langword="True"/> if the specified ItemID (key)
    /// exists in the collection; otherwise, <see langword="false"/>.
    /// </summary>
    /// <param name="itemId">ItemID (key) to check.</param>
    /// <returns><see langword="True"/> if the specified item
    /// exists in the collection; otherwise, <see langword="false"/>.</returns>
    public bool Contains(long itemId)
    {
      return isLoaded ? itemsIndex.Contains(itemId) : GetItem(itemId)!=null;
    }
    
    /// <summary>
    /// Returns item identifier if the specified <see cref="ValueTypeCollectionEntry"/> internal value
    /// exists in the collection; otherwise, <see cref="Int64.MinValue"/>.
    /// </summary>
    /// <param name="internalValue">Internal value to check.</param>
    /// <returns>Item identifier if the specified item
    /// exists in the collection; otherwise, <see cref="Int64.MinValue"/>.</returns>
    public long GetItemId(object internalValue)
    {
      if (isLoaded && this.Count<queryThreshold) {
        object valueForSearch = collection.ContainedField.ConvertInternalToValue(collection.Owner, collection.Culture, internalValue);
        if (valueForSearch!=null) 
          for (int i=0, count=this.Count; i<count; i++) {
            ValueTypeCollectionEntry entry = (ValueTypeCollectionEntry)items[i];
            if (valueForSearch.Equals(entry.Value))
              return entry.InternalItemID;
          }
      }
      else {
        Persist();
        ArrayList searchCriteria = ExtractSearchColumns(internalValue, UniqueSearchIndex);
        ArrayList columnsToFetch = new ArrayList(columns);
        columnsToFetch.Add(cItem);
        ArrayList dbItems = null;
        try {
          dbItems = persister.LoadRange(schemaNode, cOwner, collection.Owner.ID, searchCriteria, columnsToFetch);
        }
        catch (Exception e) {
          throw collection.session.utils.SubstituteException(e);
        }

        if (dbItems!=null && dbItems.Count>0) {
          if (UniqueSearchIndex!=null) {
            IDictionary dbItem = (IDictionary)dbItems[0];
            return Convert.ToInt64(dbItem[cItem]);
          }
          else {
            object valueForSearch = collection.ContainedField.ConvertInternalToValue(collection.Owner, collection.Culture, internalValue);
            for (int i = 0, count = dbItems.Count; i<count; i++) {
              IDictionary dbItem = (IDictionary)dbItems[0];
              dbItem.Add(cOwner, collection.Owner.ID);
              object iValue = collection.ContainedField.InternalValueFromRecord(
                collection.session, collection.Owner, collection.Culture, dbItem);
              object realValue = collection.ContainedField.ConvertInternalToValue(collection.Owner, collection.Culture, iValue);
              if (valueForSearch.Equals(realValue)) 
                return Convert.ToInt64(dbItem[cItem]);
            }
          }
        }
      }
      return ValueTypeCollectionEntry.UndefinedItemID;
    }

    private DatabaseModel.Index UniqueSearchIndex {
      get {
        if (uniqueSearchIndex==null) {
          int tableIndex = collection.Culture==null ? 0 : collection.Culture.Index;
          Table realTable = collection.PairTo==null ?
            collection.Field.RelatedTables[tableIndex] : collection.PairTo.RelatedTables[tableIndex];
          foreach (DatabaseModel.Index dbIndex in realTable.Indexes) {
            if (dbIndex.Unique && dbIndex.Columns[realTable.Columns[0].Name]==null && 
                (uniqueSearchIndex==null || uniqueSearchIndex.Columns.Count>dbIndex.Columns.Count))
              uniqueSearchIndex = dbIndex;
          }
        }
        return uniqueSearchIndex;
      }
    }

    private void ConvertInternalToFullRecord(StructField sf, Session session, DataObject dataObject, Culture culture, object value, ArrayList appendTo)
    {
      StructHolder data = (StructHolder)value;
      for (int i = 0; i < sf.ContainedFields.Count; i++) {
        if (sf.ContainedFields[i] is StructField)
          ConvertInternalToFullRecord((StructField)sf.ContainedFields[i], session, dataObject, culture, data.FieldValues[i], appendTo);
        else
          sf.ContainedFields[i].InternalValueToRecord(session, dataObject, culture, data.FieldValues[i], appendTo);
      }
    }   

    private ArrayList ExtractSearchColumns(object internalValue, DatabaseModel.Index searchIndex) 
    {
      ArrayList columnValues = new ArrayList();
      ConvertInternalToFullRecord(
        (StructField)collection.ContainedField, collection.session, collection.Owner, collection.Culture, internalValue, columnValues);
      if (searchIndex==null)
        for (int i=0, count=columnValues.Count; i<count; i++) {
          ColumnValue currentColValue = (ColumnValue)columnValues[i];
          SqlType type = currentColValue.Column.SqlType;
          if ( type==SqlType.Binary ||
                type==SqlType.Image  ||
                type==SqlType.VarBinary ) {
            columnValues.RemoveAt(i);
            i--;
            count--;
          }
        }
      else
        for (int i=0, count=columnValues.Count; i<count; i++) {
          ColumnValue currentColValue = (ColumnValue)columnValues[i];
          Column column = currentColValue.Column;
          if (searchIndex.Columns[column.Name]==null) {
            columnValues.RemoveAt(i);
            i--;
            count--;
          }
        }
      return columnValues;
    }
    
    /// <summary>
    /// Searches for the specified value and returns the index of the first occurrence within the current instance.
    /// </summary>
    /// <param name="itemId">The value to locate.</param>
    /// <returns>The index of the first occurrence of value within the entire collection, if found; otherwise, -1.</returns>
    public int IndexOf(long itemId)
    {
      if (!isLoaded)
        throw new DataObjectsDotNetException(
          "Internal error: IndexOf is invoked, but collection isn't loaded.");
      object o = itemsIndex[itemId];
      return o==null ? -1 : (int)o;
    }
    
    /// <summary>
    /// Searches for the specified internal value and returns the index of the first occurrence within the current instance.
    /// </summary>
    /// <param name="internalValue">The InternalValue to locate.</param>
    /// <returns>The index of the first occurrence of value within the entire collection, if found; otherwise, -1.</returns>
    public int IndexOf(object internalValue)
    {
      if (!isLoaded)
        throw new DataObjectsDotNetException(
          "Internal error: IndexOf is invoked, but collection isn't loaded.");
      return IndexOf(GetItemId(internalValue));
    }
        
    /// <summary>
    /// Gets the element at the specified index.
    /// </summary>
    /// <param name="index">Item index.</param>
    public ValueTypeCollectionEntry GetItem(int index)
    {
      if (!isLoaded)
        throw new DataObjectsDotNetException(
          "Internal error: GetItem is invoked, but collection isn't loaded.");
      return (ValueTypeCollectionEntry)items[index];
    }
    
    /// <summary>
    /// Gets the element by its ItemID (key).
    /// </summary>
    /// <param name="itemId">ItemID (key).</param>
    public ValueTypeCollectionEntry GetItem(long itemId)
    {
      if (itemsCache.Contains(itemId))
        return (ValueTypeCollectionEntry)itemsCache[itemId];
      
      ArrayList dbItems;
      try {
        dbItems = persister.LoadRange(schemaNode, cOwner, cItem, collection.Owner.ID, itemId, RangeType.Equal, 0, columns);
      }
      catch (Exception e) {
        throw collection.session.utils.SubstituteException(e);
      }
      
      if (dbItems.Count==0) {
        itemsCache.Add(itemId, null);
        return null;
      }
      else {
        IDictionary dbItem = (IDictionary)dbItems[0];
        dbItem.Add(cOwner, collection.Owner.ID);
        object iValue = collection.ContainedField.InternalValueFromRecord(
          collection.session, collection.Owner, collection.Culture, dbItem);
        ValueTypeCollectionEntry entry = new ValueTypeCollectionEntry(
          collection, itemId, iValue);
        itemsCache[itemId] = entry;
        return entry;
      }
    }
    
    /// <summary>
    /// Adds new element to the collection.
    /// </summary>
    /// <param name="iValue">Internal value of item to add.</param>
    /// <returns><see cref="ValueTypeCollectionEntry"/> holding newly added item.</returns>
    public ValueTypeCollectionEntry Add(object iValue)
    {
      long itemId = freeTemporaryItemId--;
      if (collection.PairTo==null)
        itemsUpdateActions[itemId]=itemsUpdateActions;

      if (count >= 0)
        count++;
        
      ValueTypeCollectionEntry entry = new ValueTypeCollectionEntry(
        collection, itemId, iValue);
      itemsCache[itemId] = entry;
      if (isLoaded) {
        int i = items.Add(entry);
        itemsIndex[itemId] = i;
      }
      return entry;
    }

    /// <summary>
    /// Adds new element to the collection.
    /// </summary>
    /// <param name="value">Internal value of item to add.</param>
    public void Add(ValueTypeCollectionEntry value)
    {
      if (collection.PairTo==null)
        throw new DataObjectsDotNetException(
          "Internal error: this method can be called only on paired collections.");

      if (count >= 0)
        ++count;      
        
      long itemId = value.InternalItemID;
      itemsCache[itemId] = value;
      if (isLoaded) {
        int i = items.Add(value);
        itemsIndex[itemId] = i;
      }
    }
        
    /// <summary>
    /// Removes element from the collection instance.
    /// </summary>
    /// <param name="value">Item to remove.</param>
    public void Remove(ValueTypeCollectionEntry value)
    {
      long itemId = value.InternalItemID;
      if (collection.PairTo==null) {
        if (itemsUpdateActions.Contains(itemId)) {
          if (itemsUpdateActions[itemId]!=null) {
            if (itemId<0)
              itemsUpdateActions.Remove(itemId);
            else
              itemsUpdateActions[itemId] = null;
          }
          else
            throw new DataObjectsDotNetException(String.Format(
              "Internal error: attempt to remove item with ID={0} while it is already marked as removed.",itemId));
        }
        else {
          if (itemId<0)
            throw new DataObjectsDotNetException(String.Format(
              "Internal error: attempt to remove item with ID={0} (negative ID, most likely it's a second removal attempt).",itemId));
          else
            itemsUpdateActions[itemId] = null;
        }
      }

      if (count > 0)
        --count;
      else if (count==0)
        throw new DataObjectsDotNetException(String.Format(
          "Internal error: attempt to remove item with ItemID={0} while Count==0.",value));
      
        
      itemsCache.Remove(itemId);
      if (isLoaded) {
        object oIndex = itemsIndex[itemId];
        if (oIndex==null)
          throw new DataObjectsDotNetException(String.Format(
            "Internal error: collection is loaded, but index of item with ItemID={0} is unknown.",value));
        int index = (int)oIndex;
        items.RemoveAt(index);
        itemsIndex.Clear();
        int i = 0;
        foreach (ValueTypeCollectionEntry e in items)
          itemsIndex.Add(e.InternalItemID, i++);
      }
    }
    
    /// <summary>
    /// Marks collection item as changed.
    /// </summary>
    /// <param name="value">Item to mark as changed.</param>
    public void MarkItemAsChanged(ValueTypeCollectionEntry value)
    {
      if (collection.PairTo==null) {
        long itemId = value.InternalItemID;
        itemsUpdateActions[itemId] = itemsUpdateActions;
      }
    }
    
    /// <summary>
    /// Persists all delayed updates from the collection to the database.
    /// </summary>
    public void Persist()
    {
      try {
        IChangesTrackingField ctf = collection.ContainedField as IChangesTrackingField;
        foreach (long key in itemsUpdateActions.Keys) {
          if (itemsUpdateActions[key]==null)
            persister.Remove(schemaNode,cOwner,cItem,collection.Owner.ID,key);
          else {
            ValueTypeCollectionEntry entry = (ValueTypeCollectionEntry)itemsCache[key];
            long itemId = entry.InternalItemID;
            ArrayList dbItem = new ArrayList();
            collection.ContainedField.InternalValueToRecord(
              collection.session, collection.Owner, collection.Culture, entry.InternalValue, dbItem);
            if (itemId<0) {
              long newItemId = collection.OwnerField==null ?
                persister.Add(schemaNode, cOwner, cItem, collection.Owner.ID, dbItem) :
                persister.Add(schemaNode, cItem, dbItem);
              itemsCache.Remove(itemId);
              entry.InternalItemID = newItemId;
              itemsCache[newItemId] = entry;
              if (isLoaded) {
                int i = (int)itemsIndex[itemId];
                itemsIndex.Remove(itemId);
                itemsIndex[newItemId] = i;
              }
            }
            else {
              if (dbItem.Count!=0)
                persister.Set(schemaNode, cOwner, cItem, collection.Owner.ID, itemId, dbItem);
            }
            if (ctf!=null)
              ctf.ClearChanges(collection.Owner, collection.Culture, entry.InternalValue);
          }
        }
      }
      catch (Exception e) {
        throw collection.session.utils.SubstituteException(e);
      }
      itemsUpdateActions.Clear();      
    }

    /// <summary>
    /// Clears all delayed updates.
    /// </summary>
    public void ClearChanges()
    {
      itemsUpdateActions.Clear();      
    }
    
    private void SaveInternalToList(StructHolder sHolder, ArrayList list)
    {
      object[] values = sHolder.FieldValues;
      for (int i=0; i<values.Length; i++) {
        object val = values[i];
        if (val is StructHolder)
          SaveInternalToList((StructHolder)val, list);
        else
          list.Add(val);
      }
    }
    
    private void LoadInternalFromList(StructHolder sHolder, object[] list, ref int index)
    {
      object[] values = sHolder.FieldValues;
      for (int i=0; i<values.Length; i++) {
        object val = values[i];
        if (val is StructHolder)
          LoadInternalFromList((StructHolder)val, list, ref index);
        else
          values[i] = list[index++];
      }
    }
    
    /// <summary>
    /// Loads collection content from <see cref="DataObjects.NET.Caching.GlobalCache"/>.
    /// </summary>
    /// <param name="sHolders">On return contains cached <see cref="StructHolder"/>s.</param>
    /// <returns>Cached collection content.</returns>
    public long[] LoadItemsFromGlobalCache(out object[] sHolders)
    {
      sHolders = null;
      
      Session s = collection.Session;
      Field f = collection.Field;
      Culture c = collection.Culture;
      DataObject owner = collection.Owner;
      
      string propertyName = f.Name + (f.Translatable ? "-"+c.Name : "");
      PropertyInstantiationInfo pInstInfo = (PropertyInstantiationInfo)
        s.Cache.GlobalCache[new PropertyKey(owner.ID, propertyName), owner.VersionID];
        
      if (pInstInfo==null) {
        s.Domain.PerformanceCounters.RegisterCacheHit(
          InstantiationInfoSource.Database, false);
        return null;
      }
        
      object data = pInstInfo.GetValue();
      if (data.GetType()!=typeof(object[])) {
        s.Domain.PerformanceCounters.RegisterCacheHit(
          InstantiationInfoSource.Database, false);
        return null;
      }
        
      StructHolder prot = (StructHolder)collection.ContainedField.CreateDefaultInternalValue(c, owner);
        
      object[] arr = (object[])data;
      long[] ids = new long[arr.Length];
      sHolders = new object[arr.Length];
      for (int i=0; i<arr.Length; i++) {
        object[] sdata = (object[])arr[i];
        ids[i] = (long)sdata[0];
        StructHolder sHolder = prot.Clone();
        int index = 1;
        LoadInternalFromList(sHolder, sdata, ref index);
        sHolders[i] = sHolder;
      }
      
      s.Domain.PerformanceCounters.RegisterCacheHit(
        InstantiationInfoSource.GlobalCache, false);      
      return ids;
    }
    
    /// <summary>
    /// Saves collection content to <see cref="DataObjects.NET.Caching.GlobalCache"/>.
    /// </summary>
    public void SaveItemsToGlobalCache()
    {
      Session s = collection.Session;
      Field f = collection.Field;
      Culture c = collection.Culture;
      DataObject owner = collection.Owner;
      
      object[] data = new object[count];
      for (int i=0; i<count; i++) {
        ValueTypeCollectionEntry entry = (ValueTypeCollectionEntry)items[i];
        StructHolder sHolder = (StructHolder)entry.InternalValue;
        ArrayList list = new ArrayList();
        SaveInternalToList(sHolder, list);
        object[] sdata = new object[1 + list.Count];
        sdata[0] = entry.ItemID;
        list.CopyTo(sdata, 1);
        data[i] = sdata;
      }
      
      string propertyName = f.Name + (f.Translatable ? "-"+c.Name : "");
      PropertyInstantiationInfo pInstInfo =
        new PropertyInstantiationInfo(GlobalCacheItemType.ValueTypeCollection, owner.ID, propertyName, owner.VersionID);
      pInstInfo.SetValue(data);
      s.Cache.GlobalCache.Remove(new PropertyKey(owner.ID, propertyName));
      s.Cache.GlobalCache.Add(pInstInfo);
    }
    
    /// <summary>
    /// Loads the number of elements contained in the collection from <see cref="DataObjects.NET.Caching.GlobalCache"/>.
    /// </summary>
    /// <returns>Cached collection size.</returns>
    public int LoadCountFromGlobalCache()
    {
      Session s = collection.Session;
      Field f = collection.Field;
      Culture c = collection.Culture;
      DataObject owner = collection.Owner;
      
      string propertyName = f.Name + (f.Translatable ? "-"+c.Name : "");
      PropertyInstantiationInfo pInstInfo = (PropertyInstantiationInfo)
        s.Cache.GlobalCache[new PropertyKey(owner.ID, propertyName), owner.VersionID];
        
      if (pInstInfo==null) {
        s.Domain.PerformanceCounters.RegisterCacheHit(
          InstantiationInfoSource.Database, false);
        return -1;
      }
      
      s.Domain.PerformanceCounters.RegisterCacheHit(
        InstantiationInfoSource.GlobalCache, false);
        
      object data = pInstInfo.GetValue();
      if (data is Array)
        return ((Array)data).Length;
      
      return (int)data;
    }
    
    /// <summary>
    /// Saves the number of elements contained int the collection to <see cref="DataObjects.NET.Caching.GlobalCache"/>.
    /// </summary>
    public void SaveCountToGlobalCache()
    {
      Session s = collection.Session;
      Field f = collection.Field;
      Culture c = collection.Culture;
      DataObject owner = collection.Owner;
      
      string propertyName = f.Name + (f.Translatable ? "-"+c.Name : "");
      PropertyInstantiationInfo pInstInfo =
        new PropertyInstantiationInfo(GlobalCacheItemType.ValueTypeCollection, owner.ID, propertyName, owner.VersionID);
      pInstInfo.SetValue(count);
      s.Cache.GlobalCache.Add(pInstInfo);
    }


    // Constructors

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="collection">Collection that will use this instance.</param>
    internal ValueTypeCollectionImplementation(ValueTypeCollection collection)
    {
      this.collection = collection;
    }
  }
}
