// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Text;

namespace DataObjects.NET.Data
{
  /// <summary>
  /// Window that shows mapping creation log.
  /// </summary>
  internal class LogWindow : System.Windows.Forms.Form
  {
    private System.Windows.Forms.TextBox tbLog;
    private System.Windows.Forms.Button bClose;
    private System.Windows.Forms.CheckBox cbWW;
    private System.ComponentModel.Container components = null;

    /// <summary>
    /// Initializes a new instance of the <see cref="LogWindow"/> class.
    /// </summary>
    /// <param name="log">Log to display.</param>
    public LogWindow(MappingLog log)
    {
      InitializeComponent();
      
      if (log!=null) {
        StringBuilder sb = new StringBuilder();
        sb.Append("The following mapping items were removed:");
        if (log.RemovedMappingItems.Count!=0) {
          MappingLogRecord[] recs = (MappingLogRecord[])log.RemovedMappingItems.ToArray(typeof(MappingLogRecord));
          string[] dsts = new string[recs.Length];
          for (int i = 0; i < recs.Length; i++)
            dsts[i] = recs[i].Source;
          Array.Sort(dsts, recs);
          foreach (MappingLogRecord rec in recs)
            sb.AppendFormat("\n  {0} - {1}", rec.Source, rec.Destination);
        } 
        else
          sb.AppendFormat("\n  None.");
        sb.AppendFormat("\n\nThe following mapping items were created:");
        if (log.CreatedMappingItems.Count!=0) {
          MappingLogRecord[] recs = (MappingLogRecord[])log.CreatedMappingItems.ToArray(typeof(MappingLogRecord));
          string[] srcs = new string[recs.Length];
          for (int i = 0; i < recs.Length; i++)
            srcs[i] = recs[i].Source;
          Array.Sort(srcs, recs);
          foreach (MappingLogRecord rec in recs)
            sb.AppendFormat("\n  {0} - {1}", rec.Source, rec.Destination);
        } 
        else
          sb.AppendFormat("\n  None.");
        tbLog.Lines = sb.ToString().Split('\n');
        tbLog.Select(0,0);
      }
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing"><see langword="True"/>, if this method
    /// is invoked by <see cref="IDisposable.Dispose"/>; otherwise,
    /// <see langword="false"/>.</param>
    protected override void Dispose( bool disposing )
    {
      if (disposing) {
        if (components != null) {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

    #region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.tbLog = new System.Windows.Forms.TextBox();
      this.bClose = new System.Windows.Forms.Button();
      this.cbWW = new System.Windows.Forms.CheckBox();
      this.SuspendLayout();
      // 
      // tbLog
      // 
      this.tbLog.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
        | System.Windows.Forms.AnchorStyles.Left) 
        | System.Windows.Forms.AnchorStyles.Right)));
      this.tbLog.BackColor = System.Drawing.SystemColors.HighlightText;
      this.tbLog.BorderStyle = System.Windows.Forms.BorderStyle.None;
      this.tbLog.Font = new System.Drawing.Font("Courier New", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(204)));
      this.tbLog.Location = new System.Drawing.Point(0, 0);
      this.tbLog.Multiline = true;
      this.tbLog.Name = "tbLog";
      this.tbLog.ReadOnly = true;
      this.tbLog.ScrollBars = System.Windows.Forms.ScrollBars.Both;
      this.tbLog.Size = new System.Drawing.Size(464, 273);
      this.tbLog.TabIndex = 0;
      this.tbLog.Text = "";
      this.tbLog.WordWrap = false;
      // 
      // bClose
      // 
      this.bClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
      this.bClose.DialogResult = System.Windows.Forms.DialogResult.OK;
      this.bClose.Location = new System.Drawing.Point(379, 285);
      this.bClose.Name = "bClose";
      this.bClose.TabIndex = 2;
      this.bClose.Text = "Close";
      // 
      // cbWW
      // 
      this.cbWW.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
      this.cbWW.Location = new System.Drawing.Point(15, 285);
      this.cbWW.Name = "cbWW";
      this.cbWW.Size = new System.Drawing.Size(82, 24);
      this.cbWW.TabIndex = 1;
      this.cbWW.Text = "Word wrap";
      this.cbWW.CheckedChanged += new System.EventHandler(this.cbWW_CheckedChanged);
      // 
      // LogWindow
      // 
      this.AcceptButton = this.bClose;
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.CancelButton = this.bClose;
      this.ClientSize = new System.Drawing.Size(464, 318);
      this.Controls.Add(this.cbWW);
      this.Controls.Add(this.bClose);
      this.Controls.Add(this.tbLog);
      this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
      this.Name = "LogWindow";
      this.ShowInTaskbar = false;
      this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
      this.Text = "Mapping creation log";
      this.ResumeLayout(false);

    }
    #endregion

    private void cbWW_CheckedChanged(object sender, EventArgs e) 
    {
      tbLog.WordWrap = !tbLog.WordWrap;
    }
  }
}
