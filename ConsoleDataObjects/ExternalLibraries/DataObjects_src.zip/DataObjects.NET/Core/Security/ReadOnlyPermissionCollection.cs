// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.IO;
using System.Threading;
using System.Configuration;
using System.Diagnostics;
using System.Globalization;
using System.Collections;
using System.Runtime.Serialization;
using DataObjects.NET;
using DataObjects.NET.Attributes;
using DataObjects.NET.Exceptions;


namespace DataObjects.NET.Security
{
  /// <summary>
  /// Read-only <see cref="IPermission"/> collection.
  /// <seealso cref="IPermission.GrantedIfGrantedAnyOf"/>
  /// </summary>
  [Serializable]
  public class ReadOnlyPermissionCollection: Object,
    ISerializable, IEnumerable, ICollection
  {
    private IPermission[] permissions;
    
    /// <summary>
    /// Gets the number of elements contained in the collection instance.
    /// </summary>
    public int Count {
      get {
        return permissions.Length;
      }
    }
    
    /// <summary>
    /// Gets or sets the element of collection by its index.
    /// </summary>
    public IPermission this[int index] {
      get {
        return permissions[index];
      }
    }
    
    /// <summary>
    /// Returns an enumerator that can iterate through the
    /// collection instance.
    /// </summary>
    /// <returns>
    /// An <see cref="IEnumerator"/> for the collection instance.
    /// </returns>
    public IEnumerator GetEnumerator()
    {
      return permissions.GetEnumerator();
    }

    /// <summary>
    /// Copies the elements of the collection to an <see cref="Array"/>, 
    /// starting at a particular <see cref="Array"/> index.
    /// </summary>
    /// <param name="array">The one-dimensional <see cref="Array"/> that is the destination of the elements copied from collection. The <see cref="Array"/> must have zero-based indexing.</param>
    /// <param name="index">The zero-based index in array at which copying begins.</param>
    public void CopyTo(Array array, int index)
    {
      permissions.CopyTo(array, index);
    }
    
    /// <summary>
    /// Gets a value indicating whether access to the 
    /// collection is synchronized (thread-safe).
    /// </summary>
    /// <returns><see langword="True"/> if access to the collection is synchronized (thread-safe); otherwise, <see langword="false"/>.</returns>
    public bool IsSynchronized {
      get {
        return permissions.IsSynchronized;
      }
    }

    /// <summary>
    /// Gets an object that can be used to synchronize access to the collection.
    /// </summary>
    /// <returns>An object that can be used to synchronize access to the collection.</returns>
    public object SyncRoot {
      get {
        return permissions.SyncRoot;
      }
    }

    // Constructor

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="permissions">Initial collection content.</param>
    public ReadOnlyPermissionCollection(IPermission[] permissions)
    {
      this.permissions = permissions;
    }

    // Serialization support
    
    /// <summary>
    /// Serializer.
    /// </summary>
    /// <param name="info"><see cref="SerializationInfo"/> object.</param>
    /// <param name="context"><see cref="StreamingContext"/> object.</param>
    public virtual void GetObjectData(SerializationInfo info, StreamingContext context)
    {
      info.AddValue("Permissions", permissions);
    }

    /// <summary>
    /// Deserialization constructor.
    /// </summary>
    /// <param name="info"><see cref="SerializationInfo"/> object.</param>
    /// <param name="context"><see cref="StreamingContext"/> object.</param>
    protected ReadOnlyPermissionCollection(SerializationInfo info, StreamingContext context)
    {
      permissions = (IPermission[])info.GetValue("Permissions", typeof(IPermission[]));
    }
  }
}
