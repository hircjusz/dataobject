// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;

namespace DataObjects.NET.Remoting
{
  /// <summary>
  /// Collection of the <see cref="MethodCallDescriptor"/> instances.
  /// </summary>
  [Serializable]
  public class MethodCallDescriptorCollection : CollectionBase,
    ICloneable
  {
    [NonSerialized]
    private CallContext callContext;
    
    #region ICloneable Members

    /// <summary>
    /// Creates a new object that is shallow copy of a curent instance.
    /// </summary>
    public virtual object Clone()
    {
      MethodCallDescriptorCollection mcdCollectionClone = new MethodCallDescriptorCollection();
      for (int i=0, count=Count; i < count; i++) 
      {
        MethodCallDescriptor mcdClone = (MethodCallDescriptor) this[i].Clone();
        mcdClone.SetOwnerCollection(mcdCollectionClone);
        mcdCollectionClone.InnerList.Add(mcdClone);
      }
      return mcdCollectionClone;
    }

    #endregion

    /// <summary>
    /// Gets or sets <see cref="CallContext"/> for the whole set of method invocation actions
    /// this collection describes.
    /// </summary>
    public CallContext CallContext 
    {
      get {
        return callContext;
      }
      set {
        callContext = value;
      }
    }
    
    /// <summary>
    /// Adds specified <see cref="MethodCallDescriptor"/> instance to the end of collection.
    /// </summary>
    public virtual int Add(MethodCallDescriptor descriptor)
    {
      return this.List.Add(descriptor);
    }
    
    /// <summary>
    /// Adds a range of the <see cref="MethodCallDescriptor"/> instances to the end of collection.
    /// </summary>
    internal void AddRange(MethodCallDescriptor[] descriptors)
    {
      for (int i=0, count=descriptors.Length; i<count; i++)
        this.List.Add(descriptors[i]);
    }
    
    /// <summary>
    /// Adds a range of the <see cref="MethodCallDescriptor"/> instances to the end of collection.
    /// </summary>
    internal void AddRange(MethodCallDescriptorCollection descriptors)
    {
      while(descriptors.Count>0)
        this.List.Add(descriptors[0]);
    }

    /// <summary>
    /// Inserts an <see cref="MethodCallDescriptor"/> instance to the collection at the specified index.
    /// </summary>
    public void Insert(int index, MethodCallDescriptor descriptor)
    {
      this.List.Insert(index, descriptor);
    }
    
    /// <summary>
    /// Determines whether collection contains specified <see cref="MethodCallDescriptor"/> instance.
    /// </summary>
    /// <param name="descriptor"><see cref="MethodCallDescriptor"/> instance to check for the containment.</param>
    /// <returns><see langword="True"/> if specified <paramref name="descriptor"/> is found; 
    /// otherwise, <see langword="false"/></returns>
    public bool Contains(MethodCallDescriptor descriptor)
    {
      return this.List.Contains(descriptor);
    }
    
    /// <summary>
    /// Returns the index of the specified <see cref="MethodCallDescriptor"/> instance in the collection.
    /// </summary>
    /// <param name="descriptor"><see cref="MethodCallDescriptor"/> instance to locate.</param>
    /// <returns>Index of the specified <paramref name="descriptor"/>, if found;
    /// otherwise, <see langword="-1"/>.</returns>
    public int IndexOf(MethodCallDescriptor descriptor)
    {
      return this.List.IndexOf(descriptor);
    }
    
    /// <summary>
    /// Removes specified <see cref="MethodCallDescriptor"/> instance from the collection"/>.
    /// </summary>
    /// <param name="descriptor">Instance to remove.</param>
    public void Remove(MethodCallDescriptor descriptor)
    {
      this.List.Remove(descriptor);
    }

    /// <summary>
    /// Gets or sets the <see cref="MethodCallDescriptor"/> instance by its index.
    /// </summary>
    public MethodCallDescriptor this[int index] {
      get {
        return (MethodCallDescriptor)this.List[index];
      }
      set {
        this.List[index] = value;
      }
    }

    /// <summary>
    /// Validates type of the inserted item.
    /// </summary>
    protected override void OnValidate(object value)
    {
      if (!(value is MethodCallDescriptor))
        throw new InvalidOperationException("Incompatible item type.\nCollection item should implement MethodCallDescriptor interface.");
    }

    /// <summary>
    /// Sets correct value of the descriptor  OwnerCollection property.
    /// </summary>
    protected override void OnSet(int index, object oldValue, object newValue)
    {
      base.OnSet(index, oldValue, newValue);
      MethodCallDescriptor oldParameter = (MethodCallDescriptor)oldValue;
      MethodCallDescriptor newParameter = (MethodCallDescriptor)newValue;
      oldParameter.SetOwnerCollection(null);
      if (newParameter.Owner!=null)
        newParameter.Owner.Remove(newParameter);
      newParameter.SetOwnerCollection(this);
    }

    /// <summary>
    /// Sets correct value of the descriptor OwnerCollection property.
    /// </summary>
    protected override void OnInsert(int index, object value)
    {
      base.OnInsert(index, value);
      MethodCallDescriptor descriptor = (MethodCallDescriptor)value;
      if (descriptor.Owner!=this) {
        if (descriptor.Owner!=null)
          descriptor.Owner.Remove(descriptor);
        descriptor.SetOwnerCollection(this);
      }
    }
    
    // Constructors
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    public MethodCallDescriptorCollection() :
      base()
    {
    }
  }
}
