// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;
using System.Diagnostics;
using DataObjects.NET.DatabaseModel;
using DataObjects.NET.Exceptions;
using DataObjects.NET.FullText.Drivers.Native;

namespace DataObjects.NET.FullText
{
  /// <summary>
  /// Base class for any DataObjects.NET full-text indexing 
  /// and search driver.
  /// </summary>
  /// <remarks>
  /// The following <see cref="TraceSwitch"/>es are available in the
  /// full-text indexing and search layer:
  /// <see cref="FtsDriver.TraceUserCodeExceptionsSwitch"/>
  /// (see <see cref="FtsDriver.TraceUserCodeExceptionsSwitchName"/> also), 
  /// <see cref="FtsDriver.TraceIndexerExceptionsSwitch"/>
  /// (see <see cref="FtsDriver.TraceIndexerExceptionsSwitchName"/> also).
  /// </remarks>
  public abstract class FtsDriver  
  #if NoMBR
    : Object
  #else
    : MarshalByRefObject
  #endif
  {
    /// <summary>
    /// Collection of currently loaded drivers.
    /// Any full-text driver should register itself in DataObjects.NET by
    /// executing by executing <c>RegisteredDrivers.Add(typeof(XXXDriver))</c>
    /// method in its static constructor.
    /// </summary>
    protected internal static Hashtable RegisteredDrivers     = new Hashtable();

//    static FtsDriver()
//    {
//    }
//
    #region Trace switches

    private static  TraceSwitch traceUserCodeExceptionsSwitch = new TraceSwitch(TraceUserCodeExceptionsSwitchName,    "Specifies how to trace exceptions thrown from the user code (e.g. IFtObject.ProduceFtData methods).");
    private static  TraceSwitch traceIndexerExceptionsSwitch  = new TraceSwitch(TraceIndexerExceptionsSwitchName, "Specifies how to trace exceptions thrown from the XxxFtIndexer code.");

    /// <summary>
    /// Specifies the name of <see cref="TraceSwitch"/> used by full-text 
    /// indexers to trace exceptions thrown from the user code
    /// (e.g. from the <see cref="IFtObject.ProduceFtData"/> methods).
    /// Value is 
    /// "<see langword="DataObjects.NET.FullText.Drivers.TraceUserCodeExceptions"/>".
    /// </summary>
    public const string TraceUserCodeExceptionsSwitchName = 
      "DataObjects.NET.FullText.Drivers.TraceUserCodeExceptions";

    /// <summary>
    /// Gets a <see cref="TraceSwitch"/> used by full-text 
    /// indexers to trace exceptions thrown from the user code
    /// (e.g. from the <see cref="IFtObject.ProduceFtData"/> methods).
    /// </summary>
    public static TraceSwitch TraceUserCodeExceptionsSwitch
    {
      get { return traceUserCodeExceptionsSwitch; }
    }

    /// <summary>
    /// Category name for tracing exceptions thrown from the user code.
    /// Value is "<see langword="DataObjects.NET.FullText, user code error"/>".
    /// </summary>
    public const string TraceUserCodeExceptionsCategoryName = "DataObjects.NET.FullText, user code error";

    
    /// <summary>
    /// Specifies the name of <see cref="TraceSwitch"/> used by full-text 
    /// indexers (XxxFtIndexer types) to trace their own exceptions.
    /// Value is "<see langword="DataObjects.NET.FullText.Drivers.TraceIndexerExceptions"/>".
    /// </summary>
    public const string TraceIndexerExceptionsSwitchName = 
      "DataObjects.NET.FullText.Drivers.TraceIndexerExceptions";

    /// <summary>
    /// Gets a <see cref="TraceSwitch"/> used by full-text 
    /// indexers (XxxFtIndexer types) to trace their own exceptions.
    /// </summary>
    public static TraceSwitch TraceIndexerExceptionsSwitch
    {
      get { return traceIndexerExceptionsSwitch; }
    }

    /// <summary>
    /// Category name for tracing exceptions thrown by full-text 
    /// indexers (XxxFtIndexer types).
    /// Value is <see langword="DataObjects.NET.FullText, indexer error"/>.
    /// </summary>
    public const string TraceIndexerExceptionsCategoryName = "DataObjects.NET.FullText, indexer error";
    
    #endregion

    private ConnectionInfo connectionInfo;
    /// <summary>
    /// Gets <see cref="ConnectionInfo"/> object
    /// describing configuration parameters of this
    /// full-text search driver.
    /// </summary>
    public  ConnectionInfo ConnectionInfo {
      get {return connectionInfo;}
    }

    private Domain domain;
    /// <summary>
    /// <see cref="Domain"/> to which this driver belongs.
    /// </summary>
    public  Domain Domain {
      get {return domain;}
    }

    /// <summary>
    /// Driver type (E.g. "Native", "Lucene").
    /// </summary>
    public abstract string Type {get;}

    /// <summary>
    /// Driver description.
    /// </summary>
    public abstract string Description {get;}

    /// <summary>
    /// Driver company (developer).
    /// </summary>
    public abstract string Company {get;}

    /// <summary>
    /// Returns <see langword="true"/> if this full-text driver can handle specified
    /// <see cref="ConnectionInfo"/>. It checks <see cref="RegisteredDrivers"/>
    /// to do this.
    /// <seealso cref="DataObjects.NET.Domain.FtsConnectionUrl"/>
    /// </summary>
    /// <returns><see langword="True"/> if this full-text driver can handle specified
    /// <see cref="ConnectionInfo"/>.</returns>
    public bool CanHandle(ConnectionInfo connectionInfo)
    {
      if (connectionInfo!=null && 
          RegisteredDrivers[connectionInfo.Protocol]==this.GetType())
        return true;
      return false;
    }
    
    /// <summary>
    /// Gets a value indicating whether you can use 
    /// full-text indexing and search.
    /// </summary>
    /// <remarks>
    /// Always true
    /// for any non-<see cref="NativeFtsDriver"/>,
    /// otherwise its value depends on 
    /// <see cref="ExtractedInfo.FullTextIndexingRunning">Domain.ExtractedDatabaseModel.ExtractedInfo.FullTextIndexingRunning</see>
    /// value.
    /// </remarks>
    public virtual bool FullTextFunctionsAvailable { 
      get {
        if (Domain==null || Domain.FtsDriver!=this)
          throw new InvalidOperationException(
            "Driver isn't associated with the Domain.");
        if (Domain.Status!=DomainStatus.Ready &&
          Domain.Status!=DomainStatus.InitializingSystemObjects &&
          Domain.Status!=DomainStatus.Initializing)
          throw new InvalidOperationException("Domain isn't built.");
        if (!(this is NativeFtsDriver))
          return true;
        else {
          DatabaseModel.Database edbm = Domain.ExtractedDatabaseModel;
          if (edbm==null)
            return false;
          if (edbm.ExtractedInfo==null)
            return false;
          return 
            edbm.ExtractedInfo.FullTextIndexingRunning && 
            (domain.DatabaseOptions & DomainDatabaseOptions.EnableFullTextSearch)!=0;
        }
      }
    }

    /// <summary>
    /// Creates a new full-text indexing service instance.
    /// </summary>
    /// <param name="session"><see cref="Session"/> to create full-text indexing service in.</param>
    /// <returns>Newly created full-text indexing service instance.</returns>
    public abstract RuntimeService CreateFtIndexer(Session session);
    
    /// <summary>
    /// Creates a new full-text indexing service instance.
    /// </summary>
    /// <param name="session"><see cref="Session"/> to create full-text indexing service in.</param>
    /// <param name="period">Time interval between indexing iterations.</param>
    /// <returns>Newly created full-text indexing service instance.</returns>
    public abstract RuntimeService CreateFtIndexer(Session session, TimeSpan period);

    /// <summary>
    /// Creates a new full-text indexing service instance.
    /// </summary>
    /// <param name="session"><see cref="Session"/> to create full-text indexing service in.</param>
    /// <param name="period">Time interval between indexing iterations.</param>
    /// <param name="shortPeriod">Time interval between next indexing iteration 
    /// in case when the previous indexing iteration wasn't fully completed.</param>
    /// <returns>Newly created full-text indexing service instance.</returns>
    public abstract RuntimeService CreateFtIndexer(Session session, TimeSpan period, TimeSpan shortPeriod);

    /// <summary>
    /// Creates a new full-text indexing service instance.
    /// </summary>
    /// <param name="session"><see cref="Session"/> to create full-text indexing service in.</param>
    /// <param name="period">Time interval between indexing iterations.</param>
    /// <param name="shortPeriod">Time interval between next indexing iteration 
    /// in case when the previous indexing iteration wasn't fully completed.</param>
    /// <param name="maxObjectsPerIteration">Maximal number of objects that can 
    /// be processed per one iteration.</param>
    /// <returns>Newly created full-text indexing service instance.</returns>
    public abstract RuntimeService CreateFtIndexer(Session session, TimeSpan period, TimeSpan shortPeriod, int maxObjectsPerIteration);

    /// <summary>
    /// Creates a new full-text indexing service instance.
    /// </summary>
    /// <param name="session"><see cref="Session"/> to create full-text indexing service in.</param>
    /// <param name="maxObjectsPerIteration">Maximal number of objects that can 
    /// be processed per one iteration.</param>
    /// <returns>Newly created full-text indexing service instance.</returns>
    public abstract RuntimeService CreateFtIndexer(Session session, int maxObjectsPerIteration);

    /// <summary>
    /// Starts full-text indexer as a <see cref="RuntimeService"/>.
    /// </summary>
    public abstract void StartBackgroundIndexing ();

    /// <summary>
    /// Starts full-text indexer as a <see cref="RuntimeService"/>.
    /// </summary>
    /// <param name="period">Time interval between indexing iterations.</param>
    public abstract void StartBackgroundIndexing (TimeSpan period);

    /// <summary>
    /// Starts full-text indexer as a <see cref="RuntimeService"/>.
    /// </summary>
    /// <param name="period">Time interval between indexing iterations.</param>
    /// <param name="shortPeriod">Time interval between next indexing iteration 
    /// in case when the previous indexing iteration wasn't fully completed.</param>
    public abstract void StartBackgroundIndexing (TimeSpan period, TimeSpan shortPeriod);

    /// <summary>
    /// Starts full-text indexer as a <see cref="RuntimeService"/>.
    /// </summary>
    /// <param name="period">Time interval between indexing iterations.</param>
    /// <param name="shortPeriod">Time interval between next indexing iteration 
    /// in case when the previous indexing iteration wasn't fully completed.</param>
    /// <param name="maxObjectsPerIteration">Maximal number of objects that can 
    /// be processed per one iteration.</param>
    public abstract void StartBackgroundIndexing (TimeSpan period, TimeSpan shortPeriod, int maxObjectsPerIteration);

    /// <summary>
    /// Starts full-text indexer as a <see cref="RuntimeService"/>.
    /// </summary>
    /// <param name="maxObjectsPerIteration">Maximal number of objects that can 
    /// be processed per one iteration.</param>
    public abstract void StartBackgroundIndexing (int maxObjectsPerIteration);

    /// <summary>
    /// Stops full-text indexer which is previously started with the <see cref="StartBackgroundIndexing"/>
    /// method, if any.
    /// </summary>
    public abstract void StopBackgroundIndexing ();

    /// <summary>
    /// Executes full-text query (see <see cref="FtsCondition"/>) in the
    /// specified <see paramref="session"/>.
    /// </summary>
    /// <param name="session"><see cref="Session"/> where query is executed.</param>
    /// <param name="ftsCondition">Full-text search condition.</param>
    /// <returns>Full-text query result.</returns>
    public abstract FtsResult ExecuteQuery(Session session, FtsCondition ftsCondition);

    /// <summary>
    /// This method is executed right after the moment when 
    /// <see cref="NET.Domain.Build"/> method completes to 
    /// update the database.
    /// </summary>
    internal protected virtual void UpdateIndex(DomainUpdateMode domainUpdateMode)
    {
    }

    // Constructor

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="connectionInfo">Configuration parameters of this full-text search driver.</param>
    /// <param name="domain"><see cref="Domain"/> this driver belongs to.</param>
    public FtsDriver(ConnectionInfo connectionInfo, Domain domain): base()
    {
      if (connectionInfo==null)
        throw new DatabaseDriverException("ConnectionInfo is null.");
      
      this.connectionInfo = connectionInfo;
      this.domain         = domain;
    } 
  }
}
