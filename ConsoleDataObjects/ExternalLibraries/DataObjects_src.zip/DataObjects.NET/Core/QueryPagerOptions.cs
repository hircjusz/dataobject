// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Attributes;

namespace DataObjects.NET
{
  /// <summary>
  /// Enumeration of possible operation modes of <see cref="QueryPager"/>.
  /// </summary>
  [Flags]
  public enum QueryPagerOptions
  {
    /// <summary>
    /// Default pager operation mode.
    /// The same as 
    /// <see cref="QueryPagerOptions.GrowExpotentially"/> |
    /// <see cref="QueryPagerOptions.PreLoadPages"/>.
    /// Value is <see langword="0x5"/>.
    /// </summary>
    Default = 0x5,
    /// <summary>
    /// Expotantial page loading behavior.
    /// Each time pager loads twice as more items,
    /// if this is necessary (necessary means that required page
    /// should fit into loaded result set, and it was not loaded
    /// earlier).
    /// Value is <see langword="0x1"/>.
    /// </summary>
    GrowExpotentially = 0x1,
    /// <summary>
    /// Linear page load behavior.
    /// Each time pager loads just one necessary page.
    /// Value is <see langword="0x2"/>.
    /// </summary>
    GrowPageByPage = 0x2,
    /// <summary>
    /// When page is accessed first time, <see cref="QueryPager"/>
    /// will <see cref="Session.Preload"/> all items contained
    /// on it.
    /// Value is <see langword="0x4"/>.
    /// </summary>
    PreLoadPages = 0x4,
  }
}
