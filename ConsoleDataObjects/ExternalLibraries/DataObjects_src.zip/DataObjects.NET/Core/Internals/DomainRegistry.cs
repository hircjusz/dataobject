// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;

namespace DataObjects.NET.Internals
{
  internal class DomainRegistry: IEnumerable
  {
    private static Domain[] emptyDomainArray = new Domain[] {};
    private Hashtable hDomainGuidsByObjectModelGuid = new Hashtable();
    private Hashtable hDomainByGuid                 = new Hashtable();
    
    public void RegisterDomain(Domain domain)
    {
      if (domain==null)
        throw new ArgumentNullException("domain");

      Domain d = FindDomainByGuid(domain.Guid);
      if (d!=null && d!=domain)
        throw new InvalidOperationException(String.Format(
          "Domain with guid \"{0}\" already exists.", domain.Guid));
      
      hDomainByGuid[domain.Guid] = domain;
      ArrayList domainGuids = hDomainGuidsByObjectModelGuid[domain.ObjectModelGuid]
        as ArrayList;
      if (domainGuids==null) {
        domainGuids = new ArrayList();
        hDomainGuidsByObjectModelGuid[domain.ObjectModelGuid] = domainGuids;
      }
      domainGuids.Add(domain.Guid);
    }
    
    public Domain[] GetRegisteredDomains()
    {
      Domain[] domains = new Domain[hDomainByGuid.Count];
      hDomainByGuid.Values.CopyTo(domains, 0);
      return domains;
    }
    
    public Domain FindDomainByGuid(Guid guid)
    {
      return (Domain)hDomainByGuid[guid];
    }

    public Domain[] FindDomainsByObjectModelGuid(Guid guid)
    {
      ArrayList domainGuids = hDomainGuidsByObjectModelGuid[guid] as ArrayList;
      if (domainGuids==null)
        return emptyDomainArray;

      ArrayList domains = new ArrayList();
      foreach(Guid g in domainGuids) {
        Domain d = (Domain)hDomainByGuid[g];
        if (d!=null)
          domains.Add(d);
      }
      return (Domain[])domains.ToArray(typeof(Domain));
    }
    
    public Domain this[Guid domainGuid] {
      get {
        return FindDomainByGuid(domainGuid);
      }
      set {
        hDomainByGuid[domainGuid] = value;
      }
    }

    #region IEnumerable Members

    public IEnumerator GetEnumerator()
    {
      return hDomainByGuid.GetEnumerator();
    }

    #endregion
  }
}