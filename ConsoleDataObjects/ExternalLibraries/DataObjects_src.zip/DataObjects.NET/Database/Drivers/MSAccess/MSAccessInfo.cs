// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;
using System.Globalization;
using System.Diagnostics;
using System.Data;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Attributes;

namespace DataObjects.NET.Database.Drivers.MSAccess
{
  /// <summary>
  /// Microsoft Access implementation of <see cref="Info"/>.
  /// </summary>
  public class MSAccessInfo: Info
  {
    /* cf. http://office.microsoft.com/en-us/assistance/HP051868081033.aspx */

    /// <summary>
    /// Driver type ("MSAccess").
    /// </summary>
    public override string Type {
      get {
        return "MSAccess";
      }
    }

    /// <summary>
    /// Driver description.
    /// </summary>
    public override string Description {
      get {
        return "Microsoft Access database driver for DataObjects.NET";
      }
    }

    /// <summary>
    /// Driver company (developer).
    /// </summary>
    public override string Company {
      get {
        return "X-tensive.com, INLINE";
      }
    }


    /// <summary>
    /// Is RDBMS supports distributed transactions?
    /// </summary>
    public override bool SupportsEnlist {get {return false;}}

    /// <summary>
    /// Is RDBMS supports savepoints\inner transactions when 
    /// connection is enlisted in distributed transaction?
    /// </summary>
    public override bool SupportsSavepointsWhenEnlisted {get {return false;}}

    /// <summary>
    /// Is RDBMS supports unicode?
    /// </summary>
    public override bool SupportsUnicode {get {return true;}} // yes - it's assumed

    /// <summary>
    /// Is RDBMS supports non-unicode strings?
    /// </summary>
    public override bool SupportsNonUnicode {get {return false;}} // no - strings are assumed unicode

    /// <summary>
    /// Is RDBMS supports collations?
    /// </summary>
    public override bool SupportsCollations {get {return false;}}

    /// <summary>
    /// Is RDBMS supports batches?
    /// </summary>
    public override bool SupportsBatches {get {return false;}}

    /// <summary>
    /// Is RDBMS supports names in square brackets?
    /// </summary>
    public override bool SupportsSquareBrackets {get {return true;}}

    /// <summary>
    /// Is RDBMS supports full-text indexing?
    /// </summary>
    public override bool SupportsFullTextIndexing {get {return false;}}

    /// <summary>
    /// Is RDBMS\Database driver supports constraints?
    /// </summary>
    public override bool SupportsConstraints {get {return true;}}

    /// <summary>
    /// Is RDBMS supports Int64 data type?
    /// </summary>
    public override bool SupportsInt64 {get {return false;}}

    /// <summary>
    /// Is RDBMS supports GUID data type?
    /// </summary>
    public override bool SupportsGuid {get {return false;}}

    /// <summary>
    /// Is RDBMS supports boolean data type?
    /// If the value of this property is <see langword="false"/>,
    /// RDMBS uses integer-like type to store boolean values.
    /// </summary>
    public override bool SupportsRealBoolean {get {return true;}}

    /// <summary>
    /// Does RDBMS or driver implementation support foreign key constraints?
    /// </summary>
    public override bool SupportsForeignKeyConstraints {get{return true;}}

    /// <summary>
    /// Does RDBMS or driver implementation support clustered indexes?
    /// </summary>
    public override bool SupportsClusteredIndexes {get{return false;}}
    
    /// <summary>
    /// Does RDBMS or driver implementation supprot versionizing?
    /// </summary>
    public override bool SupportsVersionizing {get{return false;}}

    /// <summary>
    /// Does RDBMS or driver implementation requires multi-table joins to have explicit order
    /// (like "(a join b) join c")?
    /// </summary>
    public override bool RequiresExplicitJoinOrder {get {return true;}}

    /// <summary>
    /// Gets if a primary key can  be treated as clustered index.
    /// </summary>
    public override bool PrimaryKeyCanBeClustered {get{return true;}}

    /// <summary>
    /// Maximal length of a query text (characters).
    /// </summary>
    public override int QueryLength {get {return 64000;}}

    /// <summary>
    /// Maximal number of compare operations for a single query.
    /// </summary>
    public override int QueryComparisonsLimit {get {return 99;}}

    /// <summary>
    /// Maximal length of database name (characters).
    /// </summary>
    public override int DatabaseNameLength {get {return 260;}} // 260 is max file name length in Windows

    /// <summary>
    /// Maximal length of identifier.
    /// </summary>
    public override int IdentifierLength {get {return 64;}}

    /// <summary>
    /// Maximal length of table row (bytes).
    /// </summary>
    public override int RowLength {get {return 4000;}}

    /// <summary>
    /// <see langword="True"/> if row length includes VarChar, AnsiVarChar and VarBinary column lengths.
    /// </summary>
    public override bool RowLengthIncludesVarDataTypes {get {return false;}} // technically excludes Memo and VarBinary

    /// <summary>
    /// Maximal length of index (bytes).
    /// </summary>
    public override int IndexLength {get {return RowLength;}} // spec doesn't say, so assume max row size

    /// <summary>
    /// Maximal length of indexed part of string.
    /// </summary>
    public override int IndexedStringPartLength {get {return int.MaxValue;}} // spec doesn't say

    /// <summary>
    /// Maximal length of index (columns).
    /// </summary>
    public override int IndexColumns {get {return 10;}}


    /// <summary>
    /// Maximal Char length (characters).
    /// </summary>
    public override int CharLength {get {return 255;}}

    /// <summary>
    /// Maximal AnsiChar length (characters).
    /// </summary>
    public override int AnsiCharLength {get {return 512;}}

    /// <summary>
    /// Maximal Binary length (bytes).
    /// </summary>
    public override int BinaryLength {get {return 1073741823;}} // 1 Gb

    /// <summary>
    /// Maximal VarChar length (characters).
    /// </summary>
    public override int VarCharLength {get {return 255;}}

    /// <summary>
    /// Maximal AnsiVarChar length (characters).
    /// </summary>
    public override int AnsiVarCharLength {get {return 512;}}

    /// <summary>
    /// Maximal VarBinary length (bytes).
    /// </summary>
    public override int VarBinaryLength {get {return 1073741823;}} // 1 Gb

    /// <summary>
    /// Maximal Text length (characters).
    /// </summary>
    public override int TextLength {get {return 536870910 ;}} // 1 Gb

    /// <summary>
    /// Maximal AnsiText length (characters).
    /// </summary>
    public override int AnsiTextLength {get {return 1073741823;}} // 1Gb

    /// <summary>
    /// Maximal Image length (bytes).
    /// </summary>
    public override int ImageLength {get {return 1073741823;}} // 1Gb

    /// <summary>
    /// Identity column length (bits).
    /// </summary>
    public override int IndentityBits {get {return 32;}} 

    /// <summary>
    /// Int32 length (bits).
    /// </summary>
    public override int Int64Bits {get {return 32;}}

    /// <summary>
    /// <see langword="True"/> if empty string ('') is considered as NULL.
    /// </summary>
    public override bool EmptyStringIsNull {get {return false;}}

    /// <summary>
    /// <see langword="True"/> if empty BLOB is considered as NULL.
    /// </summary>
    public override bool EmptyBlobIsNull {get {return false;}}


    /// <summary>
    /// Nested subqueries count.
    /// </summary>
    public override int NestedSubqueries {get {return 50;}}

    
    /// <summary>
    /// <see langword="True"/> if named parameters are allowed.
    /// </summary>
    public override bool SupportsNamedParameters {get {return true;}}

    /// <summary>
    /// Parameter prefix.
    /// </summary>
    public override string ParameterPrefix {get {return "@";}}

    /// <summary>
    /// Parameter prefix should be used in the name of the 
    /// parameter instance also.
    /// </summary>
    public override bool   UseParameterPrefixInParameterName {get {return true;}}

    /// <summary>
    /// Specifies whether underlying database driver automatically assigns 
    /// current <see cref="IDbTransaction"/> to the 
    /// <see cref="IDbCommand.Transaction">IDbCommand.Transaction</see>
    /// property (a transaction should be assigned manually when
    /// this parameter is <see langword="false"/>).
    /// </summary>
    public override bool   AutomaticallyAssignsTransactionToCommand {get {return false;}}
    
    
    // Constructor

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    public MSAccessInfo(Driver driver): base(driver)
    {
    }
  }
}
