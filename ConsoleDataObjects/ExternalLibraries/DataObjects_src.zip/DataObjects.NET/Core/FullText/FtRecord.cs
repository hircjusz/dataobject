// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Diagnostics;
using System.Collections;
using System.Runtime.Serialization;
using DataObjects.NET;
using DataObjects.NET.Attributes;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Serialization;
using DataObjects.NET.Security;
using DataObjects.NET.Security.Permissions;
using DataObjects.NET.FullText.Drivers.Native;

namespace DataObjects.NET.FullText
{
  /// <summary>
  /// Stores full-text data for a single <see cref="FtObject"/> instance
  /// (or object implementing <see cref="IFtObject"/>).
  /// Notice that <see cref="ChangeFullTextDataPermission"/> is required
  /// for almost any operation with this type.
  /// <see langword="Persistent"/>.
  /// </summary>
  [Sealed]
  [NotVersionized]
  public abstract class FtRecord : DataObject,
    IHasNoAccessControlList
  {
    /// <summary>
    /// <see langword="Persistent"/>.
    /// Gets the object for which this instance's full-text data (see
    /// <see cref="FtData"/>) is related.
    /// </summary>
    [Indexed]
    // [Nullable]
    public IFtObject FtObject {
      get {return (IFtObject)GetProperty("FtObject", null);}
    }

    /// <summary>
    /// <see langword="Persistent, Translatable"/>.
    /// Gets the full-text data stored in this record.
    /// You should have <see cref="AdministrationPermission"/>
    /// to read the value of this property.
    /// <seealso cref="IFtObject.FtRecordIsUpToDate"/>
    /// <seealso cref="IFtObject"/>
    /// </summary>
    [Translatable]
    [SqlType(SqlType.Text)]
    [SqlType(SqlType.VarCharMax,DriverTypes="MSSQL 9.0-*.*")]
    [SqlType(SqlType.AnsiText,  DriverTypes="Oracle, NativeOracle")]
    [SqlType(SqlType.VarChar,   DriverTypes="SAPDB")]
    [Length(1000,               DriverTypes="SAPDB")]
    [LoadOnDemand]
    [NotSerializable]
    [Indexed(FullText=true)]
    public string FtData {
      set {SetProperty("FtData", null, value);}
    }

    /// <summary>
    /// Indicates whether <see cref="FtRecord"/> 
    /// was already processed by full-text indexer
    /// (see <see cref="FtsDriver.CreateFtIndexer"/>)
    /// and consequently is included into full-text
    /// catalogue.
    /// <see cref="NativeFtIndexer"/> doesn't use this property.
    /// </summary>
    [Persistent]
    [LoadOnDemand]
    [ChangesTracking(ChangesTrackingMode.Independently)]
    [Indexed]
    public bool IsIndexed {
      get {return (bool)GetProperty("IsIndexed", null);}
      set {SetProperty("IsIndexed",value);}
    }

    /// <summary>
    /// Updates the full-text data stored in this record.
    /// You should have <see cref="ChangeFullTextDataPermission"/>
    /// to call this method.
    /// </summary>
    [NotOverridable]
    public virtual void UpdateFtData()
    {
      if (!(Domain.FtsDriver is NativeFtsDriver))
        throw new InvalidOperationException(
          "FtRecord.UpdateFtData can be invoked only by NativeFtsDriver.");
      if (this.State==DataObjectState.Removed)
        throw new InstanceIsRemovedException();
      
      IFtObject ftObject = this.FtObject;
      if (ftObject!=null && ftObject.State!=DataObjectState.Removed) {
        ObjectModel.StringField ftDataField = 
          (ObjectModel.StringField)Session.Types[typeof(FtRecord)].Fields["FtData"];
        int ftDataMaxLength = ftDataField.Length;
        FtData ftd = ProduceFtData();
        if (ftd!=null) {
          foreach (Culture c in session.domain.Cultures) {
            string ftData = string.Join(" ", ftd[FtField.ContentFieldName+"-"+c.Name].Values);
            if (ftDataMaxLength>0 && ftData.Length>ftDataMaxLength)
              ftData.Substring(0,ftDataMaxLength);
            this.SetProperty("FtData", c, ftData);
          }
        }
      }
    }
    
    /// <summary>
    /// Produces the full-text search data for this record.
    /// </summary>
    [NotOverridable]
    public virtual FtData ProduceFtData()
    {
      if (this.State==DataObjectState.Removed)
        throw new InstanceIsRemovedException();

      FtData ftData = new FtData();
      IFtObject ftObject = this.FtObject;
      if (ftObject!=null && ftObject.State!=DataObjectState.Removed) {
        DataObjects.NET.TransactionController transactionController = this.Session.CreateTransactionController(TransactionMode.NewTransactionRequired);
        try {
          // System fields
          ftData.Add(new FtField(
            FtField.ObjectIDFieldName, FtFieldType.Keyword,
            ftObject.ID.ToString()));
          ftData.Add(new FtField(
            FtField.TypeIDFieldName, FtFieldType.Keyword,
            ftObject.TypeID.ToString()));
          ftData.Add(new FtField(
            FtField.FtRecordIDFieldName, FtFieldType.Keyword,
            this.ID.ToString()));

          try {
            // User fields
            foreach (Culture c in session.domain.Cultures)
              ftData.Add(new FtField(
                FtField.ContentFieldName + "-" + c.Name,
                ftObject.ProduceFtData(c)));
            ftObject.ProduceFtData(ftData);
            foreach (Culture c in session.domain.Cultures)
              ftObject.ProduceFtData(ftData, c);
          }
          catch {
            foreach (Culture c in session.domain.Cultures)
              try {
                ftData.Add(new FtField(
                  FtField.ContentFieldName + "-" + c.Name,
                  "<ProduceFtDataError>"));
              } catch {};
            throw;
          }

          transactionController.Commit();
        }
        catch (TransactionCanBeReprocessedException e) {
#if DEBUG
          Debug.WriteLineIf(FtsDriver.TraceUserCodeExceptionsSwitch.TraceInfo, String.Format("{0} Info: An exception {1} occured during getting properties of the document {2}. User code will be rerun.", DateTime.Now, e.ToString(), FtObject.ID), FtsDriver.TraceUserCodeExceptionsCategoryName);
#else
          Trace.WriteLineIf(FtsDriver.TraceUserCodeExceptionsSwitch.TraceInfo, String.Format("{0} Info: An exception {1} occured during getting properties of the document {2}. User code will be rerun.", DateTime.Now, e.Message, FtObject.ID), FtsDriver.TraceUserCodeExceptionsCategoryName);
#endif
          transactionController.Rollback(e, false);
        }
        catch (Exception e) {
#if DEBUG
          Debug.WriteLineIf(FtsDriver.TraceUserCodeExceptionsSwitch.TraceError, String.Format("{0} Error: An exception {1} occured during getting properties of the document {2}", DateTime.Now, e.ToString(), FtObject.ID), FtsDriver.TraceUserCodeExceptionsCategoryName);
#else
          Trace.WriteLineIf(FtsDriver.TraceUserCodeExceptionsSwitch.TraceError, String.Format("{0} Error: An exception {1} occured during getting properties of the document {2}", DateTime.Now, e.Message, FtObject.ID), FtsDriver.TraceUserCodeExceptionsCategoryName);
#endif
          transactionController.Rollback(e, false);
        }
        return ftData;
      }
      else
        return null;
    }

    /// <summary>
    /// Gets the parent object for this instance.
    /// This property is used by the security system during permission
    /// demands.
    /// </summary>
    /// <returns>Parent object for this instance.</returns>
    /// <remarks>
    /// This method always returns <see cref="FtObject"/> property value
    /// (or <see cref="DataObjects.NET.Session.SecurityRoot"/> if it is
    /// <see langword="null"/>).
    /// </remarks>
    [NotPersistent]
    [Transactional(TransactionMode.TransactionRequired)]
    public override DataObject SecurityParent {
      get {
        DataObject parent = (DataObject)GetProperty("FtObject",null);
        if (parent==null || parent.State==DataObjectState.Removed)
          return base.SecurityParent;
        else
          return parent;
      }
    }


    // Constructors
    
    /// <summary>
    /// Always throws an exception
    /// (InvalidOperationException("This constructor can't be used with FtRecord.")).
    /// </summary>
    [Transactional(TransactionMode.Disabled)]
    protected override void OnCreate()
    {
      throw new InvalidOperationException("This constructor can't be used with FtRecord.");
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="ftObject">Related <see cref="IFtObject"/>.</param>
    [Transactional(TransactionMode.Disabled)]
    protected virtual void OnCreate(IFtObject ftObject)
    {
      SetProperty("FtObject", null, ftObject);
      base.OnCreate();
    }
    
    /// <summary>
    /// Perform custom actions after instance creation.
    /// Usually security permission <see cref="DataObject.Demand"/>s
    /// should be executed in it.
    /// </summary>
    [Transactional(TransactionMode.Disabled)]
    protected override void OnCreated()
    {
      Demand(ChangeFullTextDataPermission.Value);
      base.OnCreated();
    }

    /// <summary>
    /// Called during <see cref="DataObject.GetProperty"/> method execution.
    /// </summary>
    /// <param name="name">Property name.</param>
    /// <param name="culture">Property culture.</param>
    /// <param name="value">Stored property value.</param>
    /// <returns>Property value to return.</returns>
    /// <remarks>
    /// <para>
    /// This method demands the following permissions:
    /// <see cref="AdministrationPermission"/> on attemps to
    /// read the <see cref="FtData"/> property.
    /// </para>
    /// <para>
    /// See <see cref="DataObject.OnGetProperty"/> method description
    /// for additional information.
    /// </para>
    /// </remarks>
    protected override object OnGetProperty(string name, Culture culture, object value)
    {
      switch (name) {
      case "FtObject":
        return value; // No permission checks.
      case "FtData":
        // This property can contain some secure info, so
        // AdministrationPermission should be demanded!
        Demand(AdministrationPermission.Value);
        return value;
      default:
        return base.OnGetProperty(name, culture, value);
      }
    }

    /// <summary>
    /// Called during <see cref="DataObject.SetProperty"/> method execution.
    /// Note that this method isn't invoked during the deserialization.
    /// </summary>
    /// <param name="name">Property name.</param>
    /// <param name="culture">Property culture.</param>
    /// <param name="value">New property value.</param>
    /// <remarks>
    /// <para>
    /// This method allows to set <see cref="FtObject"/> property
    /// without any permission checks for <see cref="OnCreate"/>
    /// method, and denies all attempts to change this property
    /// in future.
    /// </para>
    /// <para>
    /// This method demands the following permissions:
    /// <see cref="ChangeFullTextDataPermission"/> on attemps to
    /// set the <see cref="FtData"/> property.
    /// </para>
    /// <para>
    /// See <see cref="DataObject.OnSetProperty"/> method description
    /// for additional information.
    /// </para>
    /// </remarks>
    protected override void OnSetProperty(string name, Culture culture, object value)
    {
      switch (name) {
      case "FtObject":
        if (!IsCreating) {
          IFtObject ftObject = FtObject;
          if (!IsRemoving && ftObject!=null && !ftObject.IsRemoving)
            throw new SecurityException("Property \"FtObject\" can't be changed.");
        }
        break;
      case "FtData":
        Demand(ChangeFullTextDataPermission.Value);
        return;
      }
      base.OnSetProperty(name, culture, value);
    }
  
    /// <summary>
    /// Called before instance is removed (see <see cref="DataObject.Remove"/> method).
    /// </summary>
    /// <remarks>
    /// <para>
    /// This method demands the following permissions:
    /// <see cref="ChangeFullTextDataPermission"/>.
    /// </para>
    /// <para>
    /// See <see cref="DataObject.OnRemove"/> method description
    /// for additional information.
    /// </para>
    /// </remarks>
    [Transactional(TransactionMode.Disabled)]
    protected internal override void OnRemove()
    {
      Demand(ChangeFullTextDataPermission.Value);
    }

    /// <summary>
    /// Called before instance is serialized (see <see cref="Serializer"/> class).
    /// <seealso cref="Serializer"/>
    /// <seealso cref="SerializationOptions"/>
    /// <seealso cref="DeserializationOptions"/>
    /// </summary>
    /// <param name="serializer">Serializer that performs the serialization.</param>
    /// <param name="info">Serialization info.</param>
    /// <param name="context">Streaming context.</param>
    /// <param name="fields">A <see cref="Hashtable"/> initially containing pairs (Field name, <see langword="true"/>).
    /// You should set some values to <see langword="false"/> or <see langword="null"/> 
    /// in it to disable automatic serialization of corresponding field.
    /// E.g. you should clear it in case when you serialize all fields manually.</param>
    /// <remarks>
    /// <para>
    /// This method always throws <see cref="SerializationException"/> -
    /// <see cref="FtRecord"/> instances shouldn't be serialized.
    /// </para>
    /// <para>
    /// See <see cref="DataObject.OnSerializing"/> method description
    /// for additional information.
    /// </para>
    /// </remarks>
    protected override void OnSerializing(Serializer serializer, 
      SerializationInfo info, StreamingContext context, Hashtable fields)
    {
      throw new SerializationException("FtRecord instances shouldn't be serialized.");
    }

    /// <summary>
    /// Called before instance is deserialized (see <see cref="Serializer"/> class).
    /// <seealso cref="Serializer"/>
    /// <seealso cref="SerializationOptions"/>
    /// <seealso cref="DeserializationOptions"/>
    /// </summary>
    /// <param name="serializer">Serializer that performs the deserialization.</param>
    /// <param name="info">Serialization info.</param>
    /// <param name="context">Streaming context.</param>
    /// <param name="fields">A <see cref="Hashtable"/> initially containing pairs (Field name, <see langword="true"/>).
    /// You should set some values to <see langword="false"/> or <see langword="null"/> 
    /// in it to disable automatic deserialization of corresponding field.
    /// E.g. you should clear it in case when you deserialize all fields manually.</param>
    /// <remarks>
    /// <para>
    /// This method always throws <see cref="SerializationException"/> -
    /// <see cref="FtRecord"/> instances shouldn't be serialized.
    /// </para>
    /// <para>
    /// See <see cref="DataObject.OnDeserializing"/> method description
    /// for additional information.
    /// </para>
    /// </remarks>
    protected override void OnDeserializing(Serializer serializer, 
      SerializationInfo info, StreamingContext context, Hashtable fields)
    {
      throw new SerializationException("FtRecord instances shouldn't be serialized.");
    }
  }
}
