// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.IO;
using System.Threading;
using System.Configuration;
using System.Diagnostics;
using System.Globalization;
using System.Collections;
using DataObjects.NET;
using DataObjects.NET.Attributes;
using DataObjects.NET.Exceptions;

namespace DataObjects.NET.Security
{
  /// <summary>
  /// An interface that should be implemented by any secure object.
  /// Secure object is an object that actually checks if the 
  /// permission(s) is(are) allowed.
  /// <seealso cref="IDataObject"/>
  /// <seealso cref="DataObject"/>
  /// <seealso cref="Session"/>
  /// <seealso cref="IPermission"/>
  /// <seealso cref="IPermissionSet"/>
  /// <seealso cref="Permission"/>
  /// <seealso cref="PermissionSet"/>
  /// </summary>
  /// <remarks>
  /// <para>
  /// There are 2 implementors of this interface in the DataObjects.NET:
  /// <see cref="DataObject"/> and <see cref="Session"/>.
  /// </para>
  /// <para>
  /// You can find more information about the whole DataObjects.NET
  /// security system <see cref="AccessControlList">here</see>.
  /// </para>
  /// </remarks>
  public interface ISecureObject
  {
    /// <summary>
    /// Demands the permission.
    /// </summary>
    /// <param name="permission">Permission that should be demanded.</param>
    /// <remarks>
    /// This method throws <see cref="SecurityException"/> if the pemission
    /// isn't allowed.
    /// </remarks>
    void Demand(IPermission permission);

    /// <summary>
    /// Checks if the permission is allowed.
    /// </summary>
    /// <param name="permission">Permission that should be checked.</param>
    /// <returns><see langword="True"/> if the permission is allowed; 
    /// otherwise, <see langword="false"/>.</returns>
    bool IsAllowed(IPermission permission);
  }
}
