// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.ComponentModel;
using DataObjects.NET.Data.Design;

namespace DataObjects.NET.Data
{
  /// <summary>
  /// Base class for all mapping item classes that maps to table
  /// </summary>
  public abstract class MappingToTableItem: MappingItemBase
  {
    private string tableName;
    
    /// <summary>
    /// Gets or sets table name.
    /// </summary>
    [Category("Mapping")]
    [TypeConverter(typeof(TableNameConverter))]
    public string TableName {
      get {
        return tableName;
      }
      set {
        tableName = value;
      }
    }
    
    /// <summary>
    /// Initializes a new instance of the <see cref="MappingToTableItem"/> class.
    /// </summary>
    /// <param name="tableName">Database table name.</param>
    public MappingToTableItem(string tableName) : base()
    {
      this.tableName = tableName;
    }
  }
}
