// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;

namespace DataObjects.NET
{
  /// <summary>
  /// Contains core DataObjects.NET classes.
  /// </summary>
  internal class NamespaceDoc {}
}
