// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;

namespace DataObjects.NET
{
  /// <summary>
  /// Represents version of a current RDBMS.
  /// </summary>
  public sealed class RDBMSVersion : IComparable
  {
    private static char[] digits = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9'};
    /// <summary>
    /// Major version of RDBMS.
    /// </summary>
    public readonly short Major;

    /// <summary>
    /// Major version of RDBMS.
    /// </summary>
    public readonly short Minor;

    /// <summary>
    /// Converts the string representation of <see cref="RDBMSVersion"/> to an
    /// equivalent <see cref="RDBMSVersion"/> object.
    /// </summary>
    /// <param name="strVersion">A string representation of <see cref="RDBMSVersion"/>.</param>
    /// <returns><see cref="RDBMSVersion"/> instance whouse value is the result of 
    /// <paramref name="strVersion"/> convertation.</returns>
    public static RDBMSVersion Parse (string strVersion)
    {
      strVersion = strVersion.Trim();
      string[] versionParts = strVersion.Split('.');
      if (versionParts.Length != 2 || versionParts[0].Length == 0 || versionParts[1].Length == 0 ||
         (versionParts[0].Trim(digits).Length != 0) || (versionParts[1].Trim(digits).Length != 0) )
        throw new ArgumentOutOfRangeException("strVersion",
          "The specified value does not corresponds to the \"n.n\" version format.\n" +
            "Where \"n\" is an integer from 0 to 32767.");
      return new RDBMSVersion(Convert.ToInt16(versionParts[0]), Convert.ToInt16(versionParts[1]));
    }

    /// <summary>
    /// Converts the value of the <see cref="RDBMSVersion"/> instance 
    /// to its equivalent string representation.
    /// </summary>
    /// <returns>A string representation of the <see cref="RDBMSVersion"/>.</returns>
    public override string ToString()
    {
      return String.Concat(Major, '.', Minor);
    }

    /// <summary>
    /// Compares the <see cref="RDBMSVersion"/> instance with an another one.
    /// </summary>
    /// <param name="version">An <see cref="RDBMSVersion"/> to compare with.</param>
    /// <returns>A 32-bit signed integer that indicates the relative order of the comparands. 
    /// The return value has these meanings:
    /// <list type="table">
    ///   <listheader>
    ///     <term>Value</term>
    ///     <description>Meaning</description>
    ///   </listheader>
    ///   <item>
    ///     <term>Less than zero</term>
    ///     <description>This instance is less than <paramref name="version"/>.</description>
    ///   </item>
    ///   <item>
    ///     <term>Zero</term>
    ///     <description>This instance is equal to <paramref name="version"/>.</description>
    ///   </item>
    ///   <item>
    ///     <term>Greater than zero</term>
    ///     <description>This instance is greater than <paramref name="version"/>.</description>
    ///   </item>
    /// </list>
    /// </returns>
    public int CompareTo(RDBMSVersion version)
    {
      if (Major==version.Major && Minor==version.Minor)
        return 0;
      if (Major<version.Major || (Major==version.Major && Minor<version.Minor))
        return -1;
      return 1;
    }
    
    int IComparable.CompareTo(object obj)
    {
      return CompareTo((RDBMSVersion)obj);
    }

    // Constructors

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    public RDBMSVersion(short major, short minor)
    {
      if (major<0)
        throw new ArgumentOutOfRangeException("major", "Version number should be positive.");
      if (minor<0)
        throw new ArgumentOutOfRangeException("minor", "Version number should be positive.");
      this.Major = major;
      this.Minor = minor;
    }
  }
}
