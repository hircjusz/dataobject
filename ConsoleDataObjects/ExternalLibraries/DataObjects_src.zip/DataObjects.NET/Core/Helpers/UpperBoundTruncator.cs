// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using DataObjects.NET.Attributes;
using Offline=DataObjects.NET.Offline;

namespace DataObjects.NET.Helpers
{
  /// <summary>
  /// A <see cref="IPropertyValueCorrector">corrector</see> that
  /// checks if property value is less then or equals to specified <see cref="IComparable"/> constant
  /// and replaces it with the specified constant if this condition is violated.
  /// <seealso cref="CorrectorAttribute"/>
  /// <seealso cref="IComparable"/>
  /// </summary>
  /// <remarks>
  /// See <see cref="CorrectorAttribute"/> also.
  /// See <see cref="IComparable"/> also.
  /// </remarks>
  [Serializable]
  public class UpperBoundTruncator: IPropertyValueCorrector, Offline.IPropertyValueCorrector
  {
    // We should hold object reference here instead of IComparable one
    // to prevent bug with a Validator deserialization
    private object upperBound;
    /// <summary>
    /// Gets maximal property value that passes through this corrector.
    /// <seealso cref="IComparable"/>.
    /// </summary>
    public IComparable UpperBound {
      get {
        return (IComparable)upperBound;
      }
    }

    /// <summary>
    /// Corrects <see cref="DataObject"/> property value 
    /// before it is actually set by 
    /// <see cref="DataObject.SetProperty">DataObject.SetProperty</see>
    /// method.
    /// </summary>
    /// <param name="dataObject"><see cref="DataObject"/> instance
    /// which property is to be changed.</param>
    /// <param name="propertyName">Property name.</param>
    /// <param name="culture">Property culture.</param>
    /// <param name="value">Property value to correct.</param>
    /// <returns>Corrected property value.</returns>
    /// <remarks>
    /// Checks if property value is less then or equals to specified <see cref="IComparable"/> <see cref="UpperBound"/> constant
    /// and replaces it with the specified <see cref="UpperBound"/> constant if this condition is violated.
    /// </remarks>
    public object CorrectValue(DataObject dataObject, string propertyName, Culture culture, object value)
    {
      return CorrectValue(value);
    }

    /// <summary>
    /// Corrects <see cref="DataObject"/> property value 
    /// before it is actually set by 
    /// <see cref="DataObject.SetProperty">DataObject.SetProperty</see>
    /// method.
    /// </summary>
    /// <param name="dataObject"><see cref="DataObject"/> instance
    /// which property is to be changed.</param>
    /// <param name="propertyName">Property name.</param>
    /// <param name="culture">Property culture.</param>
    /// <param name="value">Property value to correct.</param>
    /// <returns>Corrected property value.</returns>
    /// <remarks>
    /// Checks if property value is less then or equals to specified <see cref="IComparable"/> <see cref="UpperBound"/> constant
    /// and replaces it with the specified <see cref="UpperBound"/> constant if this condition is violated.
    /// </remarks>
    public object CorrectValue(Offline.DataObject dataObject, string propertyName, Offline.Culture culture, object value)
    {
      return CorrectValue(value);
    }
    
    private object CorrectValue(object value)
    {
      if ((upperBound==null)  || (value==null)) {
        return null; // null is considered to be the lowest value, so nothing can be less than it.
      }
      else {
        if (UpperBound.CompareTo(value) < 0) // upperBound < value
          return upperBound;
        else
          return value;
      }
    }
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="upperBound">
    /// Maximal property value that passes through this corrector.
    /// <seealso cref="IComparable"/>.
    /// </param>
  #if !MONO
    public UpperBoundTruncator(IComparable upperBound)
    {
      this.upperBound = upperBound;
    }
  #else
    public UpperBoundTruncator(object upperBound)
    {
      IComparable argUpperBound = upperBound as IComparable;
      if (argUpperBound==null)
        throw new ArgumentException( "Argument should implement IComparable interface", "upperBound");
      this.upperBound = upperBound;
    }
  #endif
  }
}
