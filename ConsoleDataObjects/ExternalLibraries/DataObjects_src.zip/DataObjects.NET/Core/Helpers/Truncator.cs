// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;
using DataObjects.NET.Attributes;
using Offline=DataObjects.NET.Offline;

namespace DataObjects.NET.Helpers
{
  /// <summary>
  /// A <see cref="IPropertyValueCorrector">corrector</see> that
  /// checks if length (see <see cref="String.Length">String.Length</see>,
  /// <see cref="Array.Length">Array.Length</see>) of property value 
  /// is less then or equal to specified constant
  /// and truncates it to the specified length if this condition is violated.
  /// <seealso cref="CorrectorAttribute"/>
  /// </summary>
  /// <remarks>
  /// See <see cref="CorrectorAttribute"/> also.
  /// </remarks>
  [Serializable]
  public class Truncator: IPropertyValueCorrector, Offline.IPropertyValueCorrector
  {
    private int maximalLength;
    /// <summary>
    /// Gets maximal length (see <see cref="String.Length">String.Length</see>,
    /// <see cref="Array.Length">Array.Length</see>) of property value that passes 
    /// through this corrector.
    /// </summary>
    public int MaximalLength {
      get {
        return maximalLength;
      }
    }

    private bool trimStart;
    /// <summary>
    /// Indicates whether truncator should remove white space characters
    /// from the beginning of the string before truncation (used only for
    /// <see cref="String"/>s).
    /// </summary>
    public bool TrimStart {
      get {
        return trimStart;
      }
    }

    private bool trimEnd;
    /// <summary>
    /// Indicates whether truncator should remove white space characters
    /// from the end of the string before truncation (used only for
    /// <see cref="String"/>s).
    /// </summary>
    public bool TrimEnd {
      get {
        return trimEnd;
      }
    }

    /// <summary>
    /// Corrects <see cref="DataObject"/> property value 
    /// before it is actually set by 
    /// <see cref="DataObject.SetProperty">DataObject.SetProperty</see>
    /// method.
    /// </summary>
    /// <param name="dataObject"><see cref="DataObject"/> instance
    /// which property is to be changed.</param>
    /// <param name="propertyName">Property name.</param>
    /// <param name="culture">Property culture.</param>
    /// <param name="value">Property value to correct.</param>
    /// <returns>Corrected property value.</returns>
    /// <remarks>
    /// Checks if length (see <see cref="String.Length">String.Length</see>,
    /// <see cref="Array.Length">Array.Length</see>) of property value 
    /// is less then or equal to specified constant
    /// and truncates it to the specified length if this condition is violated.
    /// </remarks>
    public object CorrectValue(DataObject dataObject, string propertyName, Culture culture, object value)
    {
      return CorrectValue(value);
    }
    
    /// <summary>
    /// Corrects <see cref="DataObject"/> property value 
    /// before it is actually set by 
    /// <see cref="DataObject.SetProperty">DataObject.SetProperty</see>
    /// method.
    /// </summary>
    /// <param name="dataObject"><see cref="DataObject"/> instance
    /// which property is to be changed.</param>
    /// <param name="propertyName">Property name.</param>
    /// <param name="culture">Property culture.</param>
    /// <param name="value">Property value to correct.</param>
    /// <returns>Corrected property value.</returns>
    /// <remarks>
    /// Checks if length (see <see cref="String.Length">String.Length</see>,
    /// <see cref="Array.Length">Array.Length</see>) of property value 
    /// is less then or equal to specified constant
    /// and truncates it to the specified length if this condition is violated.
    /// </remarks>
    public object CorrectValue(Offline.DataObject dataObject, string propertyName, Offline.Culture culture, object value)
    {
      return CorrectValue(value);
    }

    private object CorrectValue(object value)
    {
      if (value==null)
        return value;
      if ((value is string) && (value as string).Length>maximalLength) {
        string tmp = (value as string);
        if (trimStart) {
          if (trimEnd)
            tmp = tmp.Trim();
          else
            tmp = tmp.TrimStart(null);
        }
        else if (trimEnd)
          tmp = tmp.TrimEnd(null);
        return tmp.Substring(0, maximalLength);
      }
      if ((value is Array) && (value as Array).Length>maximalLength) {
        Array a = value as Array;
        Type at = a.GetType();
        Array b = Array.CreateInstance(at.GetElementType(), maximalLength);
        for (int i = 0; i<maximalLength; i++)
          b.SetValue(a.GetValue(i), i);
        return b;
      }
      return value;
    }
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="maximalLength">
    /// Sets maximal length (see <see cref="String.Length">String.Length</see>,
    /// <see cref="Array.Length">Array.Length</see>) of property value that passes 
    /// through this corrector.
    /// </param>
    /// <param name="trimStart">Indicates whether truncator should remove white space characters
    /// from the beginning of the string before truncation (used only for
    /// <see cref="String"/>s).</param>
    /// <param name="trimEnd">Indicates whether truncator should remove white space characters
    /// from the end of the string before truncation (used only for
    /// <see cref="String"/>s).</param>
    public Truncator(int maximalLength, bool trimStart, bool trimEnd)
    {
      this.maximalLength = maximalLength;
      this.trimStart = trimStart;
      this.trimEnd = trimEnd;
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="maximalLength">
    /// Sets maximal length (see <see cref="String.Length">String.Length</see>,
    /// <see cref="Array.Length">Array.Length</see>) of property value that passes 
    /// through this corrector.
    /// </param>
    /// <param name="trim">Indicates whether truncator should remove white space characters
    /// from the beginning and from the end of the string before truncation (used only for
    /// <see cref="String"/>s).</param>
    public Truncator(int maximalLength, bool trim): this(maximalLength, trim, trim)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="maximalLength">
    /// Sets maximal length (see <see cref="String.Length">String.Length</see>,
    /// <see cref="Array.Length">Array.Length</see>) of property value that passes 
    /// through this corrector.
    /// </param>
    public Truncator(int maximalLength): this(maximalLength, false, false)
    {
    }
  }
}
