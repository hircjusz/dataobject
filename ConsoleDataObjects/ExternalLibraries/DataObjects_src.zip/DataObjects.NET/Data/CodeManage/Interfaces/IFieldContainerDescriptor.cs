// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;

namespace DataObjects.NET.Data.CodeManage
{
  /// <summary>
  /// Describes a container of child fields.
  /// </summary>
  internal interface IFieldContainerDescriptor: IElementDescriptor
  {
    /// <summary>
    /// Gets child fields.
    /// </summary>
    IFieldDescriptor[] Fields {get;}
  }
}
