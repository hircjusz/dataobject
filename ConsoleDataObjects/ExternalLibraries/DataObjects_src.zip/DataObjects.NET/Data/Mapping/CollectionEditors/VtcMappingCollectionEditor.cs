// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using DataObjects.NET.Data;

namespace DataObjects.NET.Data.Design
{
  /// <summary>
  /// Editor for the ValueTypeCollection mapping collections.
  /// </summary>
  public class VtcMappingCollectionEditor: MappingCollectionEditorBase
  {
    /// <summary>
    /// Initializes a new instance of the <see cref="VtcMappingCollectionEditor"/> class.
    /// </summary>
    public VtcMappingCollectionEditor(): base(typeof(VtcMappingCollection), typeof(VtcMappingItem))
    {
    }
  }
}
