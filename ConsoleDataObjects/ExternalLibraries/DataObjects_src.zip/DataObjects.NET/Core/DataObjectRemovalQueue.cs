using System;
using System.Collections;
using System.Collections.Specialized;
using DataObjects.NET;
using DataObjects.NET.Attributes;
using DataObjects.NET.ObjectModel;

namespace DataObjects.NET
{
  /// <summary>
  /// Represents a set of <see cref="DataObject"/> instances that should be 
  /// removed together.
  /// </summary>
  public sealed class DataObjectRemovalQueue: SessionBoundObject, IEnumerable
  {
    private IDictionary allItemsHash = new HybridDictionary();
    private ArrayList   allItemsList = new ArrayList();
    private IDictionary allItemsGroupedByTypes = new HybridDictionary();
    
    
    /// <summary>
    /// Adds an <see cref="DataObject.ID"/> of object to the <see cref="DataObjectRemovalQueue"/>.
    /// </summary>
    /// <param name="id"><see cref="DataObject.ID"/> of instance to add to the queue.</param>
    public void Add(long id)
    {
      if (!Contains(id)) {
        allItemsList.Add(id);
        allItemsHash[id] = allItemsHash;
        GetOrCreateInstanceArray(session[id].Type).Add(id);
      }
    }

    /// <summary>
    /// Adds an <see cref="Array"/> of <see cref="DataObject.ID"/>s to the <see cref="DataObjectRemovalQueue"/>.
    /// </summary>
    /// <param name="ids">An <see cref="Array"/> of <see cref="DataObject.ID"/>s of instances to add to the queue.</param>
    public void Add(long[] ids)
    {
      if (ids==null)
        return;
      const int toPreLoadCnt = 1024;
      object holder = 0;
      for (int i = 0, cnt = ids.Length; i<cnt; i++) {
        if ((i%toPreLoadCnt)==0) { // Preloading...
          int j = (i/toPreLoadCnt + 1)*toPreLoadCnt;
          if (j>cnt)
            j = cnt;
          long[] toPreLoad = new long[j-i];
          for (int k = i; k<j; k++)
            toPreLoad[k-i] = ids[k];
          holder = session.Preload(toPreLoad);
        }
        Add(ids[i]);
      }
    }

    /// <summary>
    /// Adds an object to the <see cref="DataObjectRemovalQueue"/>.
    /// </summary>
    /// <param name="dataObject"><see cref="DataObject"/> instance to add to the queue.</param>
    public void Add(DataObject dataObject) 
    {
      if (dataObject==null)
        throw new ArgumentNullException("dataObject");
      if (dataObject.session!=session)
        throw new InvalidOperationException("Instance belongs to different session.");
      long id = dataObject.GetInternalID();
      if (!Contains(id)) {
        allItemsList.Add(id);
        allItemsHash[id] = allItemsHash;
        GetOrCreateInstanceArray(dataObject.Type).Add(id);
      }
    }
    
    /// <summary>
    /// Adds a content of <see cref="QueryResult"/> to the <see cref="DataObjectRemovalQueue"/>.
    /// </summary>
    /// <param name="queryResult"><see cref="QueryResult"/> containing instances to add to the queue.</param>
    public void Add(QueryResult queryResult)
    {
      if (queryResult==null)
        throw new ArgumentNullException("queryResult");
      if (queryResult.session!=session)
        throw new InvalidOperationException("QueryResult belongs to different session.");
      Add(queryResult.GetIDs());
    }
    
    /// <summary>
    /// Adds a content of <see cref="ICollection"/> to the <see cref="DataObjectRemovalQueue"/>.
    /// </summary>
    /// <param name="collection"><see cref="ICollection"/> containing instances to add to the queue.</param>
    public void Add(ICollection collection)
    {
      if (collection==null)
        throw new ArgumentNullException("collection");
      foreach (DataObject o in collection)
        Add(o);
    }
    
    /// <summary>
    /// Gets the number of elements contained in the collection.
    /// </summary>
    public int Count { 
      get {
        return allItemsList.Count;
      }
    }

    /// <summary>
    /// Gets <see cref="DataObject"/> instance at the specified index.
    /// </summary>
    /// <param name="index">The zero-based index of the element to get.</param>
    /// <returns><see cref="DataObject"/> instance at the specified index.</returns>
    public DataObject this[int index] {
      get {
        return session[(long)allItemsList[index]];
      }
    }

    /// <summary>
    /// Gets <see cref="DataObject.ID"/> of <see cref="DataObject"/> instance at the specified index.
    /// </summary>
    /// <param name="index">The zero-based index of the element to get.</param>
    /// <returns><see cref="DataObject.ID"/> of <see cref="DataObject"/> instance at the specified index.</returns>
    public long GetID(int index) 
    {
      return (long)allItemsList[index];
    }

    /// <summary>
    /// Determines whether an element is in the <see cref="DataObjectRemovalQueue"/>.
    /// </summary>
    /// <param name="item">The object to locate in the <see cref="DataObjectRemovalQueue"/>. </param>
    /// <returns><see langword="True"/> if <paramref name="item"/> is found; 
    /// otherwise, <see langword="false"/>.</returns>
    public bool Contains(DataObject item) 
    {
      return allItemsHash.Contains(item.ID);
    }

    /// <summary>
    /// Determines whether an element with specified 
    /// <see cref="DataObject.ID"/> is in the <see cref="DataObjectRemovalQueue"/>.
    /// </summary>
    /// <param name="id">The <see cref="DataObject.ID"/> of <see cref="DataObject"/> instance
    /// to locate in the <see cref="DataObjectRemovalQueue"/>.</param>
    /// <returns><see langword="True"/> if instance with specified <paramref name="id"/> is found; 
    /// otherwise, <see langword="false"/>.</returns>
    public bool Contains(long id) 
    {
      return allItemsHash.Contains(id);
    }
    
    /// <summary>
    /// Returns an enumerator that can iterate through the <see cref="DataObject.ID">ID</see>s of 
    /// collection instance.
    /// </summary>
    /// <returns>
    /// An <see cref="IEnumerator"/> for the 
    /// collection instance.
    /// </returns>
    public IEnumerator GetEnumerator() 
    {
      return new DataObjectRemovalQueueEnumerator(this);
    }
    
    internal ICollection GetAllTypes() 
    {
      return allItemsGroupedByTypes.Keys;
    }

    internal long[] GetInstancesOfType(ObjectModel.Type type) 
    {
      ArrayList instances = GetOrCreateInstanceArray(type);
      long[] result = new long[instances.Count];
      instances.CopyTo(result);
      return result;
    }

    private ArrayList GetOrCreateInstanceArray(ObjectModel.Type type) 
    {
      ArrayList result = (ArrayList)allItemsGroupedByTypes[type];
      if (result==null) {
        result = new ArrayList();
        allItemsGroupedByTypes[type] = result;
      }
      return result;
    }

    private ArrayList GetInstanceArray(ObjectModel.Type type) 
    {
      return (ArrayList)allItemsGroupedByTypes[type];
    }


    // Constructors
    
    /// <summary>
    /// Initializes a new instance of this type.
    /// </summary>
    internal DataObjectRemovalQueue(Session session): base(session) 
    {
    }
  }
}
