// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Runtime.Serialization;

namespace DataObjects.NET.Exceptions
{
  /// <summary>
  /// Thrown when savepoint is required for the operation.
  /// <seealso cref="Transaction"/>
  /// </summary>
  [Serializable]
  public class SavepointRequiredException: DataObjectsDotNetException
  {
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    public SavepointRequiredException(): base("Savepoint required.") {}
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="message">Text of message.</param>
    public SavepointRequiredException(string message): base(message) {}
    
    /// <summary>
    /// Deserialization constructor.
    /// </summary>
    /// <param name="info"><see cref="SerializationInfo"/> object.</param>
    /// <param name="context"><see cref="StreamingContext"/> object.</param>
    protected SavepointRequiredException(SerializationInfo info, StreamingContext context):
      base(info, context)
    {
    }
  }
}
