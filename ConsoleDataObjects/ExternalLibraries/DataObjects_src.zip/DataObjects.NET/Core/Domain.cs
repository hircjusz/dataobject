// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.IO;
using System.Data;
using System.Collections;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Runtime.Remoting.Lifetime;
using System.Threading;
using DataObjects.NET.Diagnostics;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Internals;
using DataObjects.NET.Security;
using DataObjects.NET.Security.Permissions;
using DataObjects.NET.Database;

#if EXPRESS
  using System.Windows.Forms;
#endif
#if MONO
  using System.Data.SqlClient;
#endif

namespace DataObjects.NET
{
  /// <summary>
  /// <see cref="Domain"/> instance represent single database (including set of persistent
  /// types, cultures, underlying database and so on). 
  /// </summary>
  /// <remarks>
  /// <para>
  /// This primarily the only type in DataObjects.NET that is safe for the multithreaded operations
  /// (one more thread-safe type is <see cref="RuntimeServicePool"/>).
  /// The only exception is a pre-build time (setup time) - during this period any <see cref="Domain"/>
  /// instance is NOT thread safe.</para>
  /// <para>
  /// During <see cref="Domain"/> setup time you should register a set of <see cref="Culture"/>s and
  /// <see cref="Type"/>s (<see cref="DataObject"/> descendants) in the <see cref="Domain"/>.
  /// Also you should set the <see cref="ConnectionUrl"/> property value and
  /// possibly change some other settings.</para>
  /// <para>
  /// To finish the setup you should call the <see cref="Build"/> method.
  /// It's your responsibility to provide an exclusive database access for the
  /// DataObjects.NET to the period of the <see cref="Build"/> method execution.</para>
  /// <example>Example:
  /// <code lang="C#">
  ///  d = new Domain("mssql://localhost/DataObjectsDotNetDemos", myProductKey);
  ///  d.NamingMode = DomainNamingMode.UseNamespaces;
  ///  d.RegisterCulture(new Culture("En",  "U.S. English", new CultureInfo("en-us", false)));
  ///  d.RegisterCulture(new Culture("Ru",  "Russian", new CultureInfo("ru-ru", false)));
  ///  d.RegisterCulture(new Culture("DeCh","Switzerland", new CultureInfo("de-CH", false)));
  ///  d.Cultures["En"].Default = true;
  ///  d.RegisterTypes("MyApp.PersistentModel");
  ///  d.RegisterServices("MyApp.PersistentModel");
  ///  d.Build(DomainUpdateMode.Perform);
  /// </code>
  /// </example>
  /// <seealso cref="Domain.RegisterType"/>
  /// <seealso cref="Domain.RegisterTypes"/>
  /// <seealso cref="Domain.RegisterCulture"/>
  /// <seealso cref="Domain.RegisterNamespaceSynonym"/>
  /// <seealso cref="Domain.NamingMode"/>
  /// <seealso cref="Domain.Build"/>
  /// <seealso cref="Domain.Status"/>
  /// <seealso cref="Domain.SecurityOptions"/>
  /// <seealso cref="DataObject"/>
  /// <seealso cref="Session"/>
  /// <seealso cref="Transaction"/>
  /// <seealso cref="Savepoint"/>
  /// <seealso cref="Query"/>
  /// <seealso cref="SqlQuery"/>
  /// </remarks>
  public sealed class Domain: MarshalByRefObject
  {
    private AssemblyResolver assemblyResolver;

    private AssemblyResolver AssemblyResolver {
      get {
        if (assemblyResolver==null)
          assemblyResolver = new AssemblyResolver(this);
        return assemblyResolver;
      }
    }

    private static DomainRegistry availableDomains = new DomainRegistry();
    /// <summary>
    /// Gets an <see cref="Array"/> of <see cref="Domain"/> instances 
    /// available in the current <see cref="AppDomain"/>.
    /// Note that only instances with successfully completed
    /// <see cref="Build"/> method exist in this list.
    /// </summary>
    public static Domain[] AvailableDomains {
      get {
        lock (availableDomains) {
          return availableDomains.GetRegisteredDomains();
        }
      }
    }

    private bool isRebuild = false;
    public bool IsRebuild
    {
        get { return isRebuild; }
        set { isRebuild = value; }
    }


    /// <summary>
    /// Locates a <see cref="Domain"/> instance with specified
    /// <see cref="Guid"/> in the current <see cref="AppDomain"/>.
    /// Note that only instances with successfully completed
    /// <see cref="Build"/> method can be located by this way.
    /// </summary>
    /// <param name="guid"><see cref="Guid"/> of <see cref="Domain"/> to locate.</param>
    /// <returns><see cref="Domain"/> with specified <see cref="Guid"/>, if found;
    /// otherwise, <see langword="null"/>.</returns>
    public static Domain FindByGuid(Guid guid)
    {
      lock (availableDomains) {
        return availableDomains.FindDomainByGuid(guid);
      }
    }
    
    /// <summary>
    /// Locates a <see cref="Domain"/> instances in the current <see cref="AppDomain"/>
    /// by the specified object model <see cref="Guid"/>.
    /// Note that only instances with successfully completed
    /// <see cref="Build"/> method can be located by this way.
    /// <seealso cref="ObjectModelGuid"/>
    /// </summary>
    /// <param name="objectModelGuid">A <see cref="Guid"/> of an object model 
    /// to locate <see cref="Domain"/> instances by.</param>
    /// <returns>An <see cref="Array"/> of a <see cref="Domain"/> instances 
    /// whose <see cref="ObjectModelGuid"/> property 
    /// equals to the specified <see cref="Guid"/>.</returns>
    public static Domain[] FindByObjectModelGuid(Guid objectModelGuid)
    {
      lock (availableDomains) {
        return availableDomains.FindDomainsByObjectModelGuid(objectModelGuid);
      }
    }

    internal DomainStatus status = DomainStatus.Created;
    /// <summary>
    /// Gets the status of <see cref="Domain"/>.
    /// </summary>
    public  DomainStatus Status {
      get {return status;}
    }
    
    /// <summary>
    /// This method actually does nothing and is used 
    /// to check the remote <see cref="Domain"/> existance
    /// as well as to prolong its .NET Remoting lease.
    /// </summary>
    public  void Ping()
    {
    }

    string name = "";
    /// <summary>
    /// Gets or sets the name of <see cref="Domain"/>.
    /// </summary>
    public string Name {
      get {return name;}
      set {
        if (value == null)
          throw new ArgumentNullException("Name","Domain.Name cannot be null.");
        if (status!=DomainStatus.Created && status!=DomainStatus.Error)
          throw new InvalidOperationException("Attempt to change Name of Domain with already called Build method.");
        if (name!="")
          throw new InvalidOperationException("Name can be set only once.");
        name = value;
      }
    }

    private TimeSpan runtimeServiceStartupDelay = new TimeSpan(0, 1, 0);

    /// <summary>
    /// Gets or sets a <see cref="TimeSpan"/> between <see cref="RuntimeService"/> creation
    /// moment and the moment of its first execution.
    /// </summary>
    public TimeSpan RuntimeServiceStartupDelay {
      get {
        return runtimeServiceStartupDelay;
      }
      set {
        if (status!=DomainStatus.Created && status!=DomainStatus.Error)
          throw new InvalidOperationException("Attempt to change RuntimeServiceStartupDelay property of Domain with already called Build method.");
        runtimeServiceStartupDelay = value;
      }
    }

    private Guid guid;
    /// <summary>
    /// Gets or sets globally unique identifier 
    /// of the current <see cref="Domain"/> instance.
    /// This property helps to distinguish between 
    /// different <see cref="Domain"/>s in .NET Remoting 
    /// interaction scenarios.
    /// </summary>
    /// <remarks>
    /// New <see cref="Guid"/> value is generated 
    /// on creation of each <see cref="Domain"/> instance.
    /// </remarks>
    public Guid Guid
    {
      get {return guid;}
      set {
        if (status!=DomainStatus.Created && status!=DomainStatus.Error)
          throw new InvalidOperationException("Attempt to change Guid of Domain with already called Build method.");
        guid = value;
      }
    }
    // TODO: Refactor to get rid of ObjectModelGuid
    private Guid objectModelGuid;
    /// <summary>
    /// Gets or sets globally unique identifier for the 
    /// <see cref="ObjectModel"/> of the current <see cref="Domain"/> instance.
    /// This property helps to distinguish between 
    /// different <see cref="ObjectModel"/>s in .NET Remoting 
    /// interaction scenarios.
    /// </summary>
    /// <remarks>
    /// New <see cref="ObjectModelGuid"/> value is generated 
    /// on creation of each <see cref="Domain"/> instance.
    /// </remarks>
    public Guid ObjectModelGuid
    {
      get {return guid;}
      set {
        if (status!=DomainStatus.Created && status!=DomainStatus.Error)
          throw new InvalidOperationException("Attempt to change ObjectModelGuid for Domain with already called Build method.");
        objectModelGuid = value;
      }
    }

    private DomainSecurityOptions securityOptions = DomainSecurityOptions.Standard;
    /// <summary>
    /// Gets or sets <see cref="Domain"/> security options.
    /// <seealso cref="Domain.ConnectionInfo"/>
    /// <seealso cref="Domain.FtsConnectionInfo"/>
    /// <seealso cref="ConnectionUrl"/>
    /// <seealso cref="Domain.Driver"/>
    /// <seealso cref="Domain.SessionSecurityOptions"/>
    /// </summary>
    public  DomainSecurityOptions SecurityOptions {
      get {
        return securityOptions;
      }
      set {
        if (status!=DomainStatus.Created && status!=DomainStatus.Error)
          throw new InvalidOperationException("Attempt to change SecurityOptions in the Domain with already called Build method.");
        securityOptions = value;
      }
    }
    
    private SessionSecurityOptions sessionSecurityOptions = SessionSecurityOptions.Standard;
    private SessionSecurityOptions remoteSessionSecurityOptions = SessionSecurityOptions.Remote;
    /// <summary>
    /// Gets or sets default <see cref="Session.SecurityOptions">security options</see>
    /// for <see cref="Session"/> instances.
    /// <seealso cref="Domain.SecurityOptions"/>
    /// <seealso cref="Domain.RemoteSessionSecurityOptions"/>
    /// </summary>
    public  SessionSecurityOptions SessionSecurityOptions {
      get {
        return sessionSecurityOptions;
      }
      set {
        if (status!=DomainStatus.Created && status!=DomainStatus.Error)
          throw new InvalidOperationException("Attempt to change SessionSecurityOptions in the Domain with already called Build method.");
        sessionSecurityOptions = value;
      }
    }

    /// <summary>
    /// Gets or sets default <see cref="Session.SecurityOptions">security options</see>
    /// for <see cref="Session"/> instances created by remote clients.
    /// <seealso cref="Domain.SecurityOptions"/>
    /// <seealso cref="Domain.SessionSecurityOptions"/>
    /// </summary>
    public  SessionSecurityOptions RemoteSessionSecurityOptions {
      get {
        return remoteSessionSecurityOptions;
      }
      set {
        if (status!=DomainStatus.Created && status!=DomainStatus.Error)
          throw new InvalidOperationException("Attempt to change RemoteSessionSecurityOptions in the Domain with already called Build method.");
        remoteSessionSecurityOptions = value;
      }
    }

    
    private DomainSecurityMode securityMode = DomainSecurityMode.Standard;
    /// <summary>
    /// Gets or sets <see cref="Domain"/> security mode.
    /// <seealso cref="Domain.SecurityOptions"/>
    /// <seealso cref="Domain.SessionSecurityOptions"/>
    /// </summary>
    public  DomainSecurityMode SecurityMode {
      get {
        return securityMode;
      }
      set {
        if (status!=DomainStatus.Created && status!=DomainStatus.Error)
          throw new InvalidOperationException("Attempt to change SecurityMode in the Domain with already called Build method.");
        securityMode = value;
      }
    }
    
    internal DomainFastLoadDataFormat fastLoadDataFormat = DomainFastLoadDataFormat.Default;
    /// <summary>
    /// Gets or sets serialization format of the <see cref="DataObject.FastLoadData"/>
    /// used in the <see cref="Domain"/>.
    /// </summary>
    /// <remarks>
    /// Note that changing of this setting doesn't leads to discard of all
    /// stored <see cref="DataObject.FastLoadData"/> - DataObjects.NET 
    /// automatically recognizes its actual format while reading its content.
    /// So this option affects only on "write format", while "read format"
    /// is detected automatically.
    /// </remarks>
    public  DomainFastLoadDataFormat FastLoadDataFormat {
      get {
        return fastLoadDataFormat;
      }
      set {
        if (status!=DomainStatus.Created && status!=DomainStatus.Error)
          throw new InvalidOperationException("Attempt to change FastLoadDataFormat in the Domain with already called Build method.");
        fastLoadDataFormat = value;
      }
    }
    
    private ConnectionInfo connectionInfo;
    /// <summary>
    /// Gets the <see cref="DataObjects.NET.ConnectionInfo"/> object
    /// specifying how to connect to the underlying database.
    /// <seealso cref="Domain.Driver"/>
    /// <seealso cref="Domain.SecurityOptions"/>
    /// </summary>
    public  ConnectionInfo ConnectionInfo {
      get {
        if (status>=DomainStatus.Ready)
          if ((securityOptions & DomainSecurityOptions.AllowAccessToConnectionInfo)==0)
            throw new SecurityException("Access to ConnectionInfo isn't allowed.");
        return connectionInfo;
      }
    }
    internal ConnectionInfo InternalConnectionInfo {
      get {
        return connectionInfo;
      }
    }
    
    /// <summary>
    /// Gets or sets the database connection URL. 
    /// The same as <see cref="NET.ConnectionInfo.Url">ConnectionInfo.Url</see>.
    /// <seealso cref="Domain.Driver"/>
    /// <seealso cref="Domain.SecurityOptions"/>
    /// </summary>
    public  string ConnectionUrl {
      get {
        if (status>=DomainStatus.Ready)
          if ((securityOptions & DomainSecurityOptions.AllowAccessToConnectionInfo)==0)
            throw new SecurityException("Access to ConnectionUrl isn't allowed.");
        return connectionInfo.Url;
      }
      set {
        connectionInfo.Url = value;
      }
    }
    
    private ConnectionInfo ftsConnectionInfo;
    /// <summary>
    /// Gets the <see cref="FtsConnectionInfo"/> object
    /// specifying the full-text search driver (<see cref="FtsDriver"/>)
    /// and its parameters.
    /// <seealso cref="Domain.FtsDriver"/>
    /// <seealso cref="Domain.SecurityOptions"/>
    /// </summary>
    public  ConnectionInfo FtsConnectionInfo {
      get {
        if (status>=DomainStatus.Ready)
          if ((securityOptions & DomainSecurityOptions.AllowAccessToConnectionInfo)==0)
            throw new SecurityException("Access to ConnectionInfo isn't allowed.");
        return ftsConnectionInfo;
      }
    }
    internal ConnectionInfo InternalFtsConnectionInfo {
      get {
        return ftsConnectionInfo;
      }
    }
    
    /// <summary>
    /// Gets or sets full-text search connection URL
    /// specifying the full-text search driver (<see cref="FtsDriver"/>)
    /// and its parameters.
    /// The same as <see cref="NET.ConnectionInfo.Url">FtsConnectionInfo.Url</see>.
    /// <seealso cref="Domain.SecurityOptions"/>
    /// </summary>
    public  string FtsConnectionUrl {
      get {
        if (status>=DomainStatus.Ready)
          if ((securityOptions & DomainSecurityOptions.AllowAccessToConnectionInfo)==0)
            throw new SecurityException("Access to ConnectionUrl isn't allowed.");
        return ftsConnectionInfo.Url;
      }
      set {
        ftsConnectionInfo.Url = value;
      }
    }

    internal readonly SystemObjectNames systemObjectNames;
    /// <summary>
    /// Gets the <see cref="DataObjects.NET.SystemObjectNames"/> object
    /// allowing to redefine system object names. 
    /// <seealso cref="SystemObjectNames"/>
    /// <seealso cref="SystemObjects"/>
    /// <seealso cref="InitializeSystemObjects"/>
    /// </summary>
    public  SystemObjectNames SystemObjectNames {
      get {
        return systemObjectNames;
      }
    }
    
    #if DEBUG
      private string debugInfoOutputFolder = @"C:/Debug";
    #else
      private string debugInfoOutputFolder = null;
    #endif
    /// <summary>
    /// Gets or sets the path to the folder where miscellaneous
    /// debug information should be stored. Also if this property
    /// is set to non-empty string, it will be possible to debug an 
    /// assembly with the proxy classes.
    /// </summary>
    /// <remarks>
    /// <para>
    /// Default value of this property is <see langword="null"/> - 
    /// this means that no any debug information should be written.
    /// </para>
    /// <para>
    /// If the value of this property isn't <see langword="null"/>,
    /// a set of text files will be written to the specified folder
    /// during call to the <see cref="Build"/> method.
    /// </para>
    /// <para>
    /// These files include dumps of Domain's <see cref="ObjectModel"/>,
    /// <see cref="DatabaseModel"/>, <see cref="ExtractedDatabaseModel"/>
    /// and list of SQL commands that could be performed during the 
    /// update of the Domain database.
    /// </para>
    /// <para>
    /// Additionaly a debug version of assembly with the proxy 
    /// classes and its C# source code will be stored in this folder. 
    /// This allows to step into this assembly during the debugging 
    /// of your application.
    /// </para>
    /// </remarks>
    public  string DebugInfoOutputFolder {
      get {
        return debugInfoOutputFolder;
      }
      set {
        if (status!=DomainStatus.Created && status!=DomainStatus.Error)
          throw new InvalidOperationException("Attempt to change DebugInfoOutputFolder in the Domain with already called Build method.");
        debugInfoOutputFolder = value;
      }
    }
    internal string _DebugInfoOutputFolder {
      get {
        if (debugInfoOutputFolder==null)
          throw new InvalidOperationException("DebugInfoOutputFolder is null.");
        string sPath;
        if (Path.IsPathRooted(debugInfoOutputFolder))
          sPath = debugInfoOutputFolder;
        else
          sPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, debugInfoOutputFolder);
        if (Directory.Exists(sPath))
          return sPath;
        else {
          Directory.CreateDirectory(sPath);
          return sPath;
        }
      }
    }
    
    private string proxyAssemblyCacheFolder = ".//ProxyAssemblyCache";
    /// <summary>
    /// Gets or sets the path to the folder where proxy
    /// assembly should be stored. If this property
    /// is set to non-empty string, proxy assembly compilation
    /// will happen rarely; otherwise this assembly
    /// will be compiled "in memory", so it will be impossible to
    /// "cache" it.
    /// </summary>
    public  string ProxyAssemblyCacheFolder {
      get {
        return proxyAssemblyCacheFolder;
      }
      set {
        if (status!=DomainStatus.Created && status!=DomainStatus.Error)
          throw new InvalidOperationException("Attempt to change ProxyAssemblyCacheFolder in the Domain with already called Build method.");
        if (value==null)
          throw new ArgumentNullException("value");
        proxyAssemblyCacheFolder = value;
      }
    }
    internal string _ProxyAssemblyOutputFolder {
      get {
        if (proxyAssemblyCacheFolder==null)
          throw new InvalidOperationException("ProxyAssemblyCacheFolder is null.");
        string sPath;
        if (Path.IsPathRooted(proxyAssemblyCacheFolder))
          sPath = proxyAssemblyCacheFolder;
        else
          sPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, proxyAssemblyCacheFolder);
        if (Directory.Exists(sPath))
          return sPath;
        else {
          Directory.CreateDirectory(sPath);
          return sPath;
        }
      }
    }

    #if !EXPRESS
      internal string productKey;

      /// <summary>
      /// Sets the DataObjects.NET product key.
      /// May contain any value in Express Edition.
      /// </summary>
      public string ProductKey {
        set {
          if (status!=DomainStatus.Created && status!=DomainStatus.Error)
            throw new InvalidOperationException("Attempt to change ProductKey of Domain with already called Build method.");
          productKey = value;
          object kvr = Base64Decoder.Decode(productKey);
          combinedPrefix = kvr;
          if (kvr == null && productKey != "" && productKey != null)
            throw new DataObjectsDotNetException("Invalid product key.");
          if (registeredFieldTypesHash == null) {
            byte[] cp = combinedPrefix as byte[];
            if (cp != null) {
              registeredFieldTypesHash = new Hashtable();
              for (int i = 0; i < cp.Length; i++)
                registeredFieldTypesHash[i] = cp[i];
              combinedPrefix = null;
            }
          }
        }
      }
    #endif
    
    private Database.Driver driver;
    /// <summary>
    /// Gets the database <see cref="Driver"/> used in the <see cref="Domain"/>. 
    /// It is changed automatically when <see cref="ConnectionInfo"/> object
    /// changes.
    /// <seealso cref="ConnectionInfo"/>
    /// <seealso cref="SecurityOptions"/>
    /// </summary>
    public  Database.Driver Driver {
      get {
        if (status>=DomainStatus.Ready)
          if ((securityOptions & DomainSecurityOptions.AllowAccessToDriver)==0)
              if (!IsRebuild)
                 throw new SecurityException("Access to Driver isn't allowed.");
        return driver;
      }
    }
    internal Database.Driver InternalDriver {
      get {
        return driver;
      }
    }
    
    private Database.Info driverInfo;
    /// <summary>
    /// The same as <see cref="DataObjects.NET.Database.Driver.Info">Driver.Info</see>.
    /// </summary>
    public  Database.Info DriverInfo {
      get {return driverInfo;}
    }
    
    private Database.Utils utils;
    /// <summary>
    /// The same as <see cref="DataObjects.NET.Database.Driver.Utils">Driver.Utils</see>.
    /// </summary>
    public  Database.Utils Utils {
      get {return utils;}
    }
    
    private Offline.Internals.ServerSideCacheBackend serverSideCacheBackend;
    /// <summary>
    /// Gets <see cref="DataObjects.NET.Offline.Internals.ServerSideCacheBackend"/> object.
    /// </summary>
    public  Offline.Internals.ServerSideCacheBackend ServerSideCacheBackend {
      get {return serverSideCacheBackend;}
    }
    
    private FullText.FtsDriver ftsDriver;
    /// <summary>
    /// Gets the <see cref="FtsDriver"/> used in the <see cref="Domain"/>. 
    /// It is changed automatically when <see cref="ConnectionInfo"/> object
    /// changes.
    /// <seealso cref="FtsConnectionInfo"/>
    /// <seealso cref="SecurityOptions"/>
    /// </summary>
    public FullText.FtsDriver FtsDriver {
      get { return ftsDriver; }
    }

    private Hashtable registeredTypes = new Hashtable();
    private ArrayList registeredTypesList = new ArrayList();
    /// <summary>
    /// Returns an <see cref="Array"/> containing <see cref="Type"/>s of
    /// all <see cref="DataObject"/> descentdants registreded in 
    /// the <see cref="Domain"/>. 
    /// </summary>
    /// <remarks>
    /// <p>To use any <see cref="DataObject"/> descendant, you should register
    /// it in one or more <see cref="Domain"/>s. Registration adds type and
    /// all its superclasses to list of types, that persistence is managed
    /// by this <b>Domain</b>.</p>
    /// <p>Note, that registration process should be finished before your
    /// call to <see cref="Domain.Build()"/>.</p>
    /// </remarks>
    public  Type[] GetRegisteredTypes()
    {
      Type[] a = new Type[registeredTypes.Count];
      registeredTypesList.CopyTo(a,0);
      return a;
    }
    
    private Hashtable registeredFieldTypes = new Hashtable();
    private ArrayList registeredFieldTypesList = new ArrayList();
    private Hashtable registeredFieldSourceTypes = new Hashtable();
    private Hashtable registeredFieldTypesHash = null;
    /// <summary>
    /// Returns an <see cref="Array"/> containing <see cref="Type"/>s of
    /// all <see cref="NET.ObjectModel.Field">Field</see> descentdants registreded in
    /// the <see cref="Domain"/>. 
    /// </summary>
    public  Type[] GetRegisteredFieldTypes()
    {
      Type[] a = new Type[registeredFieldTypes.Count];
      registeredFieldTypesList.CopyTo(a,0);
      return a;
    }
    
    internal Hashtable GetRegisteredFieldTypesHash()
    {
      return registeredFieldTypesHash;
    }
    
    Type[] registeredPermissions = null;
    /// <summary>
    /// Returns an <see cref="Array"/> of registered <see cref="IPermission">permission</see>
    /// <see cref="Type"/>s.
    /// </summary>
    /// <returns><see cref="Array"/> of registered <see cref="IPermission">permission</see>
    /// <see cref="Type"/>s.</returns>
    public Type[] GetRegisteredPermissons()
    {
      if (registeredPermissions==null) lock(this) if (registeredPermissions==null) {
        ArrayList typesToRegister = new ArrayList();
        Assembly[] ma = AppDomain.CurrentDomain.GetAssemblies();
        foreach (Assembly a in ma) {
          // It's better to skip some assemblies (like mscorlib)
          string[] fnParts = a.FullName.Split(new char[] {','});
          if (fnParts[0]=="mscorlib")
            continue;
          Type   permissionType  = typeof(IPermission);
          Type[] prohibitedTypes = {typeof(IParameterizedPermission),
                                           typeof(IPermissionSet)};
          Type[] mt = a.GetTypes();
          foreach (Type ct in mt) {
            bool prohibited = false;
            for (int i=0, count=prohibitedTypes.Length; i<count; i++)
              if (prohibitedTypes[i].IsAssignableFrom(ct)) {
                prohibited = true;
                break;
              }
            if (!prohibited &&
                !ct.IsAbstract && 
                !ct.IsInterface &&
                permissionType.IsAssignableFrom(ct) && 
                permissionType!=ct ) {
              typesToRegister.Add(ct);
            }
          }
        }
        registeredPermissions = new Type[typesToRegister.Count];
        typesToRegister.CopyTo(registeredPermissions);
      }
      return (Type[])registeredPermissions.Clone();
    }

    private Hashtable registeredNamespaceSynonyms = new Hashtable();
    /// <summary>
    /// Returns <see cref="Hashtable"/> containing all registered
    /// Namespace Synonyms.
    /// </summary>
    /// <returns>All registered Namespace Synonyms.</returns>
    public  Hashtable GetRegisteredNamespaceSynonyms()
    {
      Hashtable h = new Hashtable(registeredNamespaceSynonyms);
      return h;
    }
    
    /// <summary>
    /// Returns the Namespace Synonym (if registered) for 
    /// specified <paramref name="namespaceName"/>, or <see langword="null"/>.
    /// </summary>
    /// <param name="namespaceName">Full namespace name.</param>
    /// <returns>Namespace Synonym (if registered) for the
    /// specified <paramref name="namespaceName"/> or <see langword="null"/>.</returns>
    public  string GetNamespaceSynonym(string namespaceName)
    {
      return (string)registeredNamespaceSynonyms[namespaceName];
    }
    
    private DomainNamingMode namingMode = DomainNamingMode.Default;
    /// <summary>
    /// Gets or sets the <see cref="DomainNamingMode">naming mode</see> to use
    /// in the <see cref="Domain"/>. Default value of this property is 
    /// <see cref="DomainNamingMode">DomainNamingMode.Default</see>.
    /// </summary>
    public  DomainNamingMode NamingMode {
      get {
        return namingMode;
      }
      set {
        if (status!=DomainStatus.Created && status!=DomainStatus.Error)
          throw new InvalidOperationException("Build method was already called for the Domain.");
        string snm = (value & (
            DomainNamingMode.UseOnlyTypeNames |
            DomainNamingMode.UseNamespaces |
            DomainNamingMode.UseNamespaceSynonyms |
            DomainNamingMode.UseNamespaceHashes)).ToString();
        if (snm==null || snm=="" || snm=="0" || snm.IndexOf(',')>=0)
          throw new InvalidOperationException(String.Format(
            "Invalid NamingMode: {0}.", value.ToString()));
        if ((value & (
            DomainNamingMode.Uppercase |
            DomainNamingMode.Lowercase)).ToString().IndexOf(',')>=0)
          throw new InvalidOperationException(String.Format(
            "Invalid NamingMode: {0}.", value.ToString()));
        namingMode = value;
      }
    }
    
    private DomainDatabaseOptions databaseOptions = DomainDatabaseOptions.Default;
    /// <summary>
    /// Gets or sets the <see cref="DatabaseOptions">databse options</see> to use
    /// in the <see cref="Domain"/>. Default value of this property is
    /// <see cref="DomainDatabaseOptions.Default">Default</see>.
    /// </summary>
    public DomainDatabaseOptions DatabaseOptions {
      get {
        return databaseOptions;
      }
      set {
        if (status!=DomainStatus.Created && status!=DomainStatus.Error)
          throw new InvalidOperationException("Build method was already called for the Domain.");
#if (EXPRESS)
        if ((value & DomainDatabaseOptions.EnableVersionizing)!=0)
          throw new InvalidOperationException("Express Edition limitation: versionizing is not available.");
#endif
#if (STANDARD)
        if ((value & DomainDatabaseOptions.EnableVersionizing)!=0)
          throw new InvalidOperationException("Standard Edition limitation: versionizing is not available.");
#endif
        databaseOptions = value;
      }
    }
          
    private DomainUpdateMode defaultUpdateMode = DomainUpdateMode.Default;
    /// <summary>
    /// Gets or sets the <see cref="DomainUpdateMode">default mode</see> to use
    /// with the <see cref="Build"/> method. Default value of this property is 
    /// <see cref="DomainUpdateMode">DomainUpdateMode.Default</see>.
    /// </summary>
    public  DomainUpdateMode DefaultUpdateMode {
      get {
        return defaultUpdateMode;
      }
      set {
        if (status!=DomainStatus.Created && status!=DomainStatus.Error)
          throw new InvalidOperationException("Build method was already called for the Domain.");
        defaultUpdateMode = value;
      }
    }
          
    private bool transactionalUpdate = true;
    /// <summary>
    /// <see langword="True"/>, if <see cref="UpdateActions"/> generated 
    /// during <see cref="Build"/> execution should be performed
    /// in a single transaction; otherwise each action will
    /// be executed in its own transaction.
    /// </summary>
    public  bool TransactionalUpdate {
      get {
        return transactionalUpdate;
      }
      set {
        if (status!=DomainStatus.Created && status!=DomainStatus.Error)
          throw new InvalidOperationException("Build method was already called for the Domain.");
        transactionalUpdate = value;
      }
    }
          
    internal CultureCollection cultures;
    /// <summary>
    /// Gets the collection of registered <see cref="Culture"/>s.
    /// </summary>
    public CultureCollection Cultures {
      get {return cultures;}
    }

    internal ObjectModel.Model objectModel = null;
    /// <summary>
    /// Gets the <see cref="DataObjects.NET.ObjectModel.Model">Object Model</see> of the 
    /// <see cref="Domain"/> (see <see cref="ObjectModelBuilder"/> also).
    /// </summary>
    public ObjectModel.Model ObjectModel 
    {
      get {return objectModel;}
    }

    private ObjectModel.Builders.ObjectModelBuilder objectModelBuilder;
    internal ObjectModel.Builders.ObjectModelBuilder ObjectModelBuilder 
    {
      get {return objectModelBuilder;}
    }
    /// <summary>
    /// Gets the collection of registered types.
    /// Same as <see cref="DataObjects.NET.ObjectModel.Model.Types">ObjectModel.Types</see>.
    /// </summary>
    public ObjectModel.TypeCollection Types
    {
      get {return objectModel.Types;}
    }
    
    /// <summary>
    /// Gets the collecton of registered services.
    /// Same as <see cref="DataObjects.NET.ObjectModel.Model.Services">ObjectModel.Services</see>.
    /// </summary>
    public ObjectModel.ServiceCollection Services
    {
      get {return objectModel.Services;}
    }
    
    private IEnvironment environment;
    /// <summary>
    /// Gets or sets an <see cref="IEnvironment"/> object 
    /// providing access to <see cref="Domain"/> environment.
    /// </summary>
    public  IEnvironment Environment {
      set {
        if (status!=DomainStatus.Created && status!=DomainStatus.Error)
          throw new InvalidOperationException("Attempt to change RemoteSessionSecurityOptions in the Domain with already called Build method.");
        environment = value;
        environment.Domain = this;
      }
      get {
        return environment;
      }
    }
    
    private DatabaseModel.Database databaseModel;
    /// <summary>
    /// Gets the <see cref="DataObjects.NET.DatabaseModel.Builders.DatabaseModelBuilder">Database Model</see> 
    /// of the <see cref="Domain"/> (see <see cref="DataObjects.NET.DatabaseModel.Builders.DatabaseModelBuilder"/> also).
    /// </summary>
    public  DatabaseModel.Database DatabaseModel 
    {
      get {return databaseModel;}
    }
    
    private DatabaseModel.Database extractedDatabaseModel;
    /// <summary>
    /// Gets the <see cref="DataObjects.NET.DatabaseModel.Builders.DatabaseModelBuilder">Database Model</see> 
    /// that was extracted during the <see cref="Build">building</see> 
    /// of this <see cref="Domain"/>
    /// (see <see cref="DataObjects.NET.DatabaseModel.Extractors.DatabaseModelExtractor"/> also).
    /// </summary>
    public  DatabaseModel.Database ExtractedDatabaseModel
    {
      get {return extractedDatabaseModel;}
    }
    
    private DatabaseModel.UpdateActionCollection updateActions;
    /// <summary>
    /// Gets the collection of <see cref="DataObjects.NET.DatabaseModel.UpdateAction"/>s that 
    /// was (or could be) applied to update the underlying database
    /// during the <see cref="Build">building</see> 
    /// of this <see cref="Domain"/>.
    /// </summary>
    public  DatabaseModel.UpdateActionCollection UpdateActions 
    {
      get {return updateActions;}
    }

    private string proxyAssemblySuffix = "";
    /// <summary>
    /// Gets or sets the additional suffix added to the name of the
    /// <see cref="ProxyAssembly"/>.
    /// Should be used when different <see cref="Domain"/>s are used
    /// simultaneously in the same application (to avoid 
    /// proxy assembly caching caching conflicts).
    /// </summary>
    public string ProxyAssemblySuffix
    {
      get {return proxyAssemblySuffix;}
      set { 
        if (value==null)
          throw new InvalidOperationException("ProxyAssemblySuffix cannot be null");
        if (status!=DomainStatus.Created && status!=DomainStatus.Error)
          throw new InvalidOperationException("Attempt to change ProxyAssemblySuffix in the Domain with already called Build method.");
        proxyAssemblySuffix = value;
      }
    }

    private Assembly proxyAssembly;
    /// <summary>
    /// Holds the reference to assembly with proxy classes.
    /// See <see cref="NET.ObjectModel.Builders.ProxyBuilder"/> for details.
    /// </summary>
    public  Assembly ProxyAssembly 
    {
      get {return proxyAssembly;}
    }
    
    private ProxyBuilderResults proxyBuilderResults;
    /// <summary>
    /// Gets the result of proxy classes building.
    /// See <see cref="NET.ObjectModel.Builders.ProxyBuilder"/> for details.
    /// </summary>
    public  ProxyBuilderResults ProxyBuilderResults 
    {
      get {return proxyBuilderResults;}
    }
    
    private string identifierPrefix = "do";
    /// <summary>
    /// Gets or sets the prefix for top-level database object names
    /// (for names of tables and views) used to distinguish 
    /// them from foreign (i.e. from non-DataObjects.NET-managed) 
    /// objects.
    /// </summary>
    public string  IdentifierPrefix {
      get {return identifierPrefix;}
      set {
        if (status!=DomainStatus.Created && status!=DomainStatus.Error)
          throw new InvalidOperationException("Attempt to change IdentifierPrefix in the Domain with already called Build method.");
        Regex rPfx = new Regex(@"^[A-Z][_0-9A-Z\-]*$", RegexOptions.IgnoreCase | RegexOptions.Multiline);
        if (!rPfx.IsMatch(value))
          throw new InvalidOperationException("Illegal IdentifierPrefix.");
        identifierPrefix = value;
      }
    }
    
    private object combinedPrefix;

    /// <summary>
    /// Registers (or unregisters) the Namespace Synonym.
    /// Namespace Synonym is a short string that should be used
    /// as part (normally suffix) of database table\view name.
    /// </summary>
    /// <param name="nameSpace">Namespace to register the Synonym for.</param>
    /// <param name="synonym">The Synonym to register.</param>
    /// <remarks>    
    /// If the Namespace Synonym is not specified for some namespace
    /// and a naming conflict takes place than all depends on the 
    /// value of <see cref="NamingMode"/> property.
    /// </remarks>
    public void RegisterNamespaceSynonym(string nameSpace, string synonym)
    {
      if (status!=DomainStatus.Created && status!=DomainStatus.Error)
          throw new InvalidOperationException("Build method was already called for the Domain.");

      if (nameSpace==null)
        throw new ArgumentNullException("type");
        
      registeredNamespaceSynonyms[nameSpace] = synonym;
    }
    
    
    // Type registration methods

    /// <summary>
    /// Invoke this method to register persistent type in the <see cref="Domain"/>.
    /// </summary>
    /// <param name="type">Type to register.</param>
    /// <returns><b>True</b>, if registration was successful; 
    /// otherwise (e.g. if the type was registered before), <see langword="false"/>.</returns>
    /// <remarks>
    /// This method can throw <see cref="InvalidOperationException"/> if you try to
    /// register a type, that isn't descendant of <see cref="DataObject"/>.
    /// <seealso cref="RegisterTypes"/>
    /// </remarks>
    public bool RegisterType(Type type)
    {
      if (type==null)
        throw new ArgumentNullException("type");

      if (type.IsClass) {
        if (!type.IsSubclassOf(typeof(DataObject)) && type!=typeof(DataObject)) 
          throw new InvalidOperationException(
            String.Format("Type {0} must be a DataObject descendant.", type.FullName));
      }
      else if (type.IsInterface) {
        if (!typeof(IDataObject).IsAssignableFrom(type))
          throw new InvalidOperationException(
            String.Format("Interface {0} must be an IDataObject descendant.", type.FullName));
      }
      else
        throw new InvalidOperationException(String.Format(
          "Unsupported type: \"{0}\".",type.FullName));
          
#if DOTNET20
      if (type.IsGenericTypeDefinition)
        throw new InvalidOperationException(String.Format(
          "Can not register generic type definition: \"{0}\".", type.FullName));
#endif

      if (registeredTypes[type.FullName]!=null)
        return false;
      
      // Let's register base type first
      if (type.IsClass && type!=typeof(DataObject))
        RegisterType(type.BaseType);

      // And all supported interfaces
      if (type!=typeof(IDataObject)) {
        Type[] interfaces = type.FindInterfaces(new TypeFilter(InterfaceFilter), type);
        foreach (Type ti in interfaces)
          RegisterType(ti);
      }
      
      if (status==DomainStatus.Building) {
        if (objectModelBuilder==null)
          throw new ObjectModelBuilderException("Creation of user Types is possible only in Domain.ObjectModelBuilt event handler.");
        objectModelBuilder.BuildType(type);
        return true;
      }
      
      if (status!=DomainStatus.Created && status!=DomainStatus.Error)
        throw new InvalidOperationException("Attempt to register type in the Domain with already called Build method.");

      registeredTypes[type.FullName] = type;
      registeredTypesList.Add(type);
      
      return true;
    }
    private bool InterfaceFilter(Type typeObj, object criteriaObj)
    {
#if DOTNET20
      if (typeObj.IsGenericTypeDefinition)
        return false;
#endif
      return typeof(IDataObject).IsAssignableFrom(typeObj);
    }
    
    /// <summary>
    /// Invoke this method to register persistent type and all its descendants
    /// in the <see cref="Domain"/>.
    /// Search is restricted by assembly and namespace.
    /// </summary>
    /// <param name="type">Type to register.</param>
    /// <param name="assembly">Assembly to search for types.</param>
    /// <param name="nameSpace">Namespace to search for types.</param>
    public void RegisterTypes(Type type, Assembly assembly, string nameSpace)
    {
      RegisterType(type);

      bool isNSR = !(nameSpace==null || nameSpace=="");
      string nsWithDot = nameSpace+".";
      
      int registeredObjectsCounter = 0;
      
      // Search through all classes
      Assembly[] ma = assembly==null 
                        ? AppDomain.CurrentDomain.GetAssemblies() 
                        : new Assembly[] {assembly};
      foreach (Assembly a in ma) 
      {
        // It's better to skip some assemblies (like mscorlib)
        string[] fnParts = a.FullName.Split(new char[] {','});
        if (fnParts[0]=="mscorlib")
          continue;

        // Skip proxy assemblies
        if (Attribute.IsDefined(a,
          typeof(DataObjects.NET.Attributes.ProxyAssemblyAttribute)))
          continue;
        
        // OK :)  
        Type[] mt;
        try {
          mt = a.GetTypes();
        }
        catch (Exception e) {
          throw new DataObjectsDotNetException(String.Format("Coud not load types from assembly {0}", a.FullName), e);
        }
        
        foreach (Type ct in mt) {
#if DOTNET20
          if (ct.IsGenericTypeDefinition)
            continue;
#endif
          if (type.IsAssignableFrom(ct)) {
            if (isNSR) {
              if (ct.FullName.IndexOf(nsWithDot,0)!=0)
                continue;
            }
            RegisterType(ct);
            registeredObjectsCounter ++;
          }
        }
      }
      if (isNSR && (registeredObjectsCounter == 0))
        throw  new InvalidOperationException(String.Format("There are no suitable types in the \"{0}\" namespace.",nameSpace));
    }
    
    /// <summary>
    /// Invoke this method to register persistent type and all its descendants
    /// in the <see cref="Domain"/>.
    /// Search is restricted by namespace.
    /// </summary>
    /// <param name="type">Type to register.</param>
    /// <param name="nameSpace">Namespace to search for types.</param>
    public void RegisterTypes(Type type, string nameSpace)
    {
      RegisterTypes(type, null, nameSpace);
    }
    
    /// <summary>
    /// Invoke this method to register persistent type and all its descendants
    /// in the <see cref="Domain"/>.
    /// Search is restricted by assembly.
    /// </summary>
    /// <param name="type">Type to register.</param>
    /// <param name="assembly">Assembly to search for types.</param>
    public void RegisterTypes(Type type, Assembly assembly)
    {
      RegisterTypes(type, assembly, null);
    }
    
    /// <summary>
    /// Invoke this method to register persistent types in the <see cref="Domain"/>.
    /// Search is restricted by namespace.
    /// </summary>
    /// <param name="nameSpace">Namespace to search for types.</param>
    public void RegisterTypes(string nameSpace)
    {
      RegisterTypes(typeof(IDataObject), null, nameSpace);
    }
    
    /// <summary>
    /// Invoke this method to register persistent types in the <see cref="Domain"/>.
    /// Search is restricted by namespace and assembly.
    /// </summary>
    /// <param name="nameSpace">Namespace to search for types.</param>
    /// <param name="assembly">Assembly to search for types.</param>
    public void RegisterTypes(string nameSpace, Assembly assembly)
    {
      RegisterTypes(typeof(IDataObject), assembly, nameSpace);
    }

    /// <summary>
    /// Invoke this method to register persistent types in the <see cref="Domain"/>.
    /// Search is restricted by assembly.
    /// </summary>
    /// <param name="assembly">Assembly to search for types.</param>
    public void RegisterTypes(Assembly assembly)
    {
      RegisterTypes(typeof(IDataObject), assembly, null);
    }
    
    /// <summary>
    /// Invoke this method to register persistent type and all its descendants
    /// in the <see cref="Domain"/>.
    /// </summary>
    /// <param name="type">Type to register.</param>
    public void RegisterTypes(Type type)
    {
      RegisterTypes(type, null, null);
    }
    
    /// <summary>
    /// Invoke this method to register all persistent types
    /// in the <see cref="Domain"/>.
    /// </summary>
    public void RegisterTypes()
    {
      RegisterTypes(typeof(IDataObject), null, null);
    }
    

    // FieldType registration methods
    
    private bool RegisterFieldType(Type type)
    {
      if (!type.IsSubclassOf(typeof(ObjectModel.Field))) {
        if (type!=typeof(ObjectModel.Field))
          throw new InvalidOperationException("Type must be a Field descendant.");
      }

      // Todo: add additional checks here (f.e., access modifiers, visibility, etc...)

      if (registeredFieldTypes[type.FullName]!=null)
        return false;
      if (type!=typeof(ObjectModel.Field))
        RegisterFieldType(type.BaseType);
      if (type.IsAbstract)
        return false;

      registeredFieldTypes[type.FullName] = type;
      registeredFieldTypesList.Add(type);

      ConstructorInfo ci = type.GetConstructor(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic, null, new Type[0],null);
      object newObject = ci.Invoke(new Object[0]);
      ObjectModel.Field f = (ObjectModel.Field)newObject;
      Type[] lt = f.GetAssociatedTypes();
      if (lt.Length==0)
        throw new FieldTypeRegistrationException("Each Field class must be associated at least with one Type.");
      
      // And finally we register associated types
      bool bAbs = true;
      foreach (Type ct in lt) {
        if (ct==null) {
          bAbs = false;
          continue;
        }
        Hashtable ht = (Hashtable)registeredFieldSourceTypes[ct.FullName];
        if (ht==null) {
          ht = new Hashtable();
          registeredFieldSourceTypes[ct.FullName] = ht;
          ht[type.FullName] = type;
          if (bAbs)
            ht[""] = type;
        }
        else {
          if (bAbs) {
            if (ht[""]!=null)
              throw new FieldTypeRegistrationException("Two or more FieldTypes are associated with the same Type.");
            ht[""] = type;  
          }
          ht[type.FullName] = type;
        }
      }
      return true;
    }
    
    /// <summary>
    /// Register all <see cref="NET.ObjectModel.Field"/> types (<see cref="NET.ObjectModel.Field"/>
    /// descendants) from the specified <paramref name="assembly"/>
    /// in the <see cref="Domain"/>.
    /// </summary>
    /// <param name="assembly">Assembly to search for <see cref="NET.ObjectModel.Field"/>
    /// descendants.</param>
    public void RegisterFieldTypes(Assembly assembly)
    {
      Type type = typeof(ObjectModel.Field);

      RegisterFieldType(type);

      // Search through all classes
      Type[] mt = assembly.GetTypes();
      foreach (Type ct in mt) {
        if (ct.IsSubclassOf(type)) {
          try {
            RegisterFieldType(ct);
          }
          // TODO: Add throw?
          catch {};
        }
      }
    }
    
    /// <summary>
    /// Finds and creates <see cref="NET.ObjectModel.Field"/>, that corresponds to some type.
    /// </summary>
    /// <param name="type">Type, for which associated <see cref="NET.ObjectModel.Field"/> should be found.</param>
    /// <param name="proposed">Proposed type of Field.</param>
    /// <returns>Instance of associated <see cref="NET.ObjectModel.Field"/>.</returns>
    public ObjectModel.Field CreateAssociatedField(Type type, Type proposed)
    {
      if (type==null)
        throw new ArgumentNullException("type");

      if (type.IsSubclassOf(typeof(ObjectModel.Field)) || type==typeof(ObjectModel.Field))
        throw new FieldTypeRegistrationException(
          String.Format("Impossible to find associated Field class for type \"{0}\".",type)
          );
          
#if DOTNET20
      if (type.IsGenericType) {
        if (type.IsGenericTypeDefinition)
          throw new FieldTypeRegistrationException(
            String.Format("Impossible to find associated Field class for generic type \"{0}\".", type)
            );
        if (type.GetGenericTypeDefinition()==typeof(Nullable<>))
          type = System.Nullable.GetUnderlyingType(type);
      }
#endif

      Type atype = proposed;
      Type ctype = null;
      if (atype==null) {
        // No proposed type, so we have to search for associated Field type
        // for type or its base types.
        Type t = type;
        do {
          if (registeredFieldSourceTypes[t.FullName]!=null) {
            if (((Hashtable)registeredFieldSourceTypes[t.FullName])[""]!=null) {
              ctype = t;
              atype = (Type)((Hashtable)registeredFieldSourceTypes[t.FullName])[""];
              break;
            }
          }       
          if (t.IsInterface && typeof(IDataObject).IsAssignableFrom(t))
            t = (t != typeof(IDataObject)) ? typeof(IDataObject) : null;
          else if (t.IsValueType && !t.IsPrimitive && !t.IsEnum)
            t = (t != typeof(DataRecord)) ? typeof(DataRecord) : null;
          else
            t = t.BaseType;
        } while (t!=null);
        
        if (atype==null)
          throw new FieldTypeRegistrationException(
            String.Format("Can't find associated Field class for type \"{0}\".",type)
            );
      }
      else {
        // Well, we have proposed Field type. But in this case we have to
        // search though its associated types for best matching type.
        // Best matching type is most closest basetype from associated types
        // list.
        Type t = type;
        do {
          if (registeredFieldSourceTypes[t.FullName]!=null) {
            if (((Hashtable)registeredFieldSourceTypes[t.FullName])[atype.FullName]!=null) {
              ctype = (Type)(((Hashtable)registeredFieldSourceTypes[t.FullName])[atype.FullName]);
              break;
            }
          }  
          if (t.IsInterface && typeof(IDataObject).IsAssignableFrom(t))
            t = (t != typeof(IDataObject)) ? typeof(IDataObject) : null;
          else if (t.IsValueType && !t.IsPrimitive && !t.IsEnum)
            t = (t != typeof(DataRecord)) ? typeof(DataRecord) : null;
          else
            t = t.BaseType;
        } while (t!=null);
        
        if (ctype==null)
          throw new FieldTypeRegistrationException(
            String.Format("Can't find associated Type in \"{0}\" for type \"{1}\".",proposed,type)
            );
      }
      
      ConstructorInfo ci = atype.GetConstructor(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic, null, new Type[0],null);
      object newObject = ci.Invoke(new Object[0]);
      ObjectModel.Field f = (ObjectModel.Field)newObject;
      f.SourceType = type;
      return f;
    }
    
    /// <summary>
    /// Finds and creates <see cref="NET.ObjectModel.Field"/>, that corresponds to some type.
    /// </summary>
    /// <param name="type">Type, for which associated <see cref="NET.ObjectModel.Field"/> should be found.</param>
    /// <returns>Instance of associated <see cref="NET.ObjectModel.Field"/>.</returns>
    internal ObjectModel.Field CreateAssociatedField(Type type)
    {
      return CreateAssociatedField(type, null);
    }


    // Culture registration methods

    /// <summary>
    /// Invoke this method to register culture in the <see cref="Domain"/>.
    /// </summary>
    /// <param name="culture">Culture to register.</param>
    /// <returns><b>True</b>, if registration was successful, otherwise (E.g. if culture with the same name was registered before) it returns <b><see langword="false"/></b>.</returns>
    public bool RegisterCulture(Culture culture)
    {
      if (status!=DomainStatus.Created && status!=DomainStatus.Error)
        throw new InvalidOperationException("Attempt to register culture in the Domain with already called Build method.");

      if (culture==null)
        throw new ArgumentNullException("culture");

      if (Cultures[culture.Name]!=null)
        return false;

      Cultures.Add(culture);
      return true;
    }

    public static DataObjects.NET.ObjectModel.Builders.ObjectModelExtension ModelExtensions = new DataObjects.NET.ObjectModel.Builders.ObjectModelExtension();


    public void RebuildDatabase()
    {
        driver.RebuildDatabase();
    }

    public void RebuildAllTables()
    {
        driver.RebuildAllTables();
    }

    public void RebuildAllIndexes()
    {
        driver.RebuildAllIndexes();
    }

    // Data Services
    
    private Hashtable registeredServices = new Hashtable();
    private ArrayList registeredServicesList = new ArrayList();
    /// <summary>
    /// Returns <see cref="Array"/> containing all <see cref="DataService"/> descentdants registreded in 
    /// this Domain. 
    /// </summary>
    /// <remarks>
    /// <p>To use any <see cref="DataService"/> descendant, you should register
    /// it in one or more <see cref="Domain"/>s. Registration adds Service and
    /// all its base classes to list of Services, which operate on DataObjects in 
    /// this <b>Domain</b>.</p>
    /// <p>Note, that registration process should be finished before your
    /// call to <see cref="Domain.Build()"/>.</p>
    /// </remarks>
    public  Type[] GetRegisteredServices()
    {
      Type[] a = new Type[registeredServices.Count];
      registeredServicesList.CopyTo(a,0);
      return a;
    }
    
    internal bool IsServiceRegistered(Type service)
    {
      return registeredServices.ContainsKey(service.FullName);
    }

    /// <summary>
    /// Invoke this method to register <see cref="DataService"/> in the <see cref="Domain"/>.
    /// </summary>
    /// <param name="type">Service type to register.</param>
    /// <returns><b>True</b>, if registration was successful, otherwise (E.g. if type was registered before) it returns <b><see langword="false"/></b>.</returns>
    /// <remarks>
    /// This method can throw <see cref="InvalidOperationException"/> if you try to
    /// register a type, that isn't descendant of <see cref="DataService"/>.
    /// <seealso cref="RegisterServices"/>
    /// </remarks>
    public bool RegisterService(Type type)
    {
      if (status!=DomainStatus.Created && status!=DomainStatus.Error)
        throw new InvalidOperationException("Attempt to register Service in the Domain with already called Build method.");

      if (type==null)
        throw new ArgumentNullException("type");

      if (!type.IsSubclassOf(typeof(DataService))) {
        if (type!=typeof(DataService))
          throw new InvalidOperationException(
            String.Format("Type {0} must be a DataService descendant.", type.FullName));
      }

#if DOTNET20
      if (type.IsGenericTypeDefinition)
        throw new InvalidOperationException(String.Format(
          "Can not register service of generic type definition: \"{0}\".", type.FullName));
#endif

      if (registeredServices[type.FullName]!=null)
        return false;
      registeredServices[type.FullName] = type;
      registeredServicesList.Add(type);
      return true;
    }

    /// <summary>
    /// Invoke this method to register DataService and all its descendants
    /// in the <see cref="Domain"/>.
    /// Search is restricted by assembly and namespace.
    /// </summary>
    /// <param name="type">Service type to register.</param>
    /// <param name="assembly">Assembly to search for Services.</param>
    /// <param name="nameSpace">Namespace to search for Services.</param>
    public void RegisterServices(Type type, Assembly assembly, string nameSpace)
    {
      RegisterService(type);

      bool isNSR = !(nameSpace==null || nameSpace=="");
      string nsWithDot = nameSpace+".";
      
      int registeredObjectsCounter = 0;

            // Search through all classes
      Assembly[] ma = assembly==null 
                        ? AppDomain.CurrentDomain.GetAssemblies()
                        : new Assembly[] {assembly};
      foreach (Assembly a in ma) 
      {
        // It's better to skip some assemblies (like mscorlib)
        string[] fnParts = a.FullName.Split(new char[] {','});
        if (fnParts[0]=="mscorlib")
          continue;
          
        // OK :)  
        Type[] mt;
        try {
          mt = a.GetTypes();
        }
        catch (Exception e) {
          throw new DataObjectsDotNetException(String.Format("Coud not load types from assembly {0}", a.FullName), e);
        }
        foreach (Type ct in mt) {
#if DOTNET20
          if (ct.IsGenericType)
            continue;
#endif
          if (ct.IsSubclassOf(type)) {
            if (isNSR) {
              if (ct.FullName.IndexOf(nsWithDot,0)!=0)
                continue;
            } 
            try {
              RegisterService(ct);
              registeredObjectsCounter ++;
            } catch {};
          }
        }
      }
      if (isNSR && (registeredObjectsCounter == 0))
        throw  new InvalidOperationException(String.Format("There is no suitable services in {0} namespace.", nameSpace));

    }
    
    /// <summary>
    /// Invoke this method to register DataService and all its descendants
    /// in the <see cref="Domain"/>.
    /// Search is restricted by namespace.
    /// </summary>
    /// <param name="type">Service type to register.</param>
    /// <param name="nameSpace">Namespace to search for Services.</param>
    public void RegisterServices(Type type, string nameSpace)
    {
      RegisterServices(type, null, nameSpace);
    }
    
    /// <summary>
    /// Invoke this method to register DataService and all its descendants
    /// in the <see cref="Domain"/>.
    /// Search is restricted by assembly.
    /// </summary>
    /// <param name="type">Service type to register.</param>
    /// <param name="assembly">Assembly to search for Services.</param>
    public void RegisterServices(Type type, Assembly assembly)
    {
      RegisterServices(type, assembly, null);
    }
    
    /// <summary>
    /// Invoke this method to register DataServices in the <see cref="Domain"/>.
    /// Search is restricted by namespace.
    /// </summary>
    /// <param name="nameSpace">Namespace to search for types.</param>
    public void RegisterServices(string nameSpace)
    {
      RegisterServices(typeof(DataService), null, nameSpace);
    }
    
    /// <summary>
    /// Invoke this method to register DataServices in the <see cref="Domain"/>.
    /// Search is restricted by namespace and assembly.
    /// </summary>
    /// <param name="nameSpace">Namespace to search for types.</param>
    /// <param name="assembly">Assembly to search for types.</param>
    public void RegisterServices(string nameSpace, Assembly assembly)
    {
      RegisterServices(typeof(DataService), assembly, nameSpace);
    }

    /// <summary>
    /// Invoke this method to register DataServices in the <see cref="Domain"/>.
    /// Search is restricted by assembly.
    /// </summary>
    /// <param name="assembly">Assembly to search for types.</param>
    public void RegisterServices(Assembly assembly)
    {
      RegisterServices(typeof(DataService), assembly, null);
    }
    
    /// <summary>
    /// Invoke this method to register DataService and all its descendants
    /// in the <see cref="Domain"/>.
    /// </summary>
    /// <param name="type">Service type to register.</param>
    public void RegisterServices(Type type)
    {
      RegisterServices(type, null, null);
    }
    
    /// <summary>
    /// Invoke this method to register all DataServices
    /// in the <see cref="Domain"/>.
    /// </summary>
    public void RegisterServices()
    {
      RegisterServices(typeof(DataService), null, null);
    }
    

    // Runtime services
    
    private RuntimeServicePool runtimeServices;
    /// <summary>
    /// A pool of <see cref="RuntimeService"/>s.
    /// </summary>
    public RuntimeServicePool RuntimeServices {
      get {
        return runtimeServices;
      }
    }

    private Caching.GlobalCache globalCache; 
    /// <summary>
    /// Gets global (<see cref="Domain"/>-level) cache.
    /// </summary>
    public Caching.GlobalCache GlobalCache {
      get {return globalCache;}
    }
    
    private int globalCacheSize = 10240000;
    /// <summary>
    /// Gets or sets global cache size.
    /// Default value is 10240000.
    /// A value of <see langword="0"/> means that global cache is disabled.
    /// </summary>
    public int GlobalCacheSize {
      get {
        if (globalCache!=null)
          return globalCache.Size;
        return globalCacheSize;
      }
      set {
        if (status!=DomainStatus.Created && status!=DomainStatus.Error)
          throw new InvalidOperationException("Attempt to change GlobalCacheSize in the Domain with already called Build method.");
        globalCacheSize = value;
      }
    }
    
    private DomainPerformanceCounters performanceCounters = null;
    internal DomainPerformanceCounters PerformanceCounters {
      get { return performanceCounters; }
    }

    private bool enablePerformanceCounters = false;
    /// <summary>
    /// Enables or disables use of performance counters.
    /// Default value is <see langword="false"/>.
    /// </summary>
    public bool EnablePerformanceCounters
    {
      get { return enablePerformanceCounters; }
      set {
        #if MONO
          if (value)
            throw new NotImplementedException("Performance counters are not supported under Mono.");
        #else
          if (status!=DomainStatus.Created && status!=DomainStatus.Error)
            throw new InvalidOperationException("Attempt to change EnablePerformanceCounters in the Domain with already called Build method.");
          enablePerformanceCounters = value;
        #endif
      }
    }

    private bool threadedBuildExecution = false;
    /// <summary>
    /// Specifies whether independent sub-processes of
    /// <see cref="Build"/> methods can be executed in parallel with
    /// each other. This option may significantly improve
    /// <see cref="Build"/> performance, especially on the
    /// large databases, but its usage also makes difficult
    /// to read the contents of DomainBuildLog.txt file
    /// (see <see cref="DebugInfoOutputFolder"/>).
    /// Default value is <see langword="false"/>.
    /// </summary>
    public bool ThreadedBuildExecution
    {
      get { return threadedBuildExecution; }
      set {
        if (status!=DomainStatus.Created && status!=DomainStatus.Error)
          throw new InvalidOperationException("Attempt to change ThreadedBuildExecution in the Domain with already called Build method.");
        threadedBuildExecution = value;
      }
    }
//SM begin
    private bool transactionOnDemand = false;
    private int changeCacheSize = 0;
    private int connectionCleanInterval = 0;
    private int connectionLifeTime = 10 * 60;
    private bool enableCommandTrace = false;
    private static IDStyle styleID = IDStyle.Default;

    /// <summary>
    /// </summary>
    public bool TransactionOnDemand
      {
          get { return this.transactionOnDemand; }
          set
          {
              if (status != DomainStatus.Created && status != DomainStatus.Error)
                  throw new InvalidOperationException("Attempt to change ThreadedBuildExecution in the Domain with already called Build method.");
              transactionOnDemand = value;
          }
      }

    /// <summary>
    /// </summary>
    public int ChangeCacheSize
    {
        get { return changeCacheSize; }
        set
        {
            if (status != DomainStatus.Created && status != DomainStatus.Error)
                throw new InvalidOperationException("Attempt to change ThreadedBuildExecution in the Domain with already called Build method.");
            changeCacheSize = value;
        }
    }

      public bool EnableCommandTrace
      {
          get { return enableCommandTrace; }
          set
          {
              if (status != DomainStatus.Created && status != DomainStatus.Error)
                  throw new InvalidOperationException("Attempt to change ThreadedBuildExecution in the Domain with already called Build method.");
              enableCommandTrace = value;
          }
      }

      public static IDStyle StyleID
      {
          get { return styleID; }
          set
          {
              styleID = value;
          }
      }


      public int ConnectionCleanInterval
      {
          get { return connectionCleanInterval; }
          set
          {
              if (status != DomainStatus.Created && status != DomainStatus.Error)
                  throw new InvalidOperationException("Attempt to change ThreadedBuildExecution in the Domain with already called Build method.");
              connectionCleanInterval = value;
          }
      }

      public int ConnectionLifeTime
      {
          get { return connectionLifeTime; }
          set
          {
              if (status != DomainStatus.Created && status != DomainStatus.Error)
                  throw new InvalidOperationException("Attempt to change ThreadedBuildExecution in the Domain with already called Build method.");
              connectionLifeTime = value;
          }
      }


//SM end

    // CreateXXX methods

    internal void EnsureDomainIsBuilt()
    {
      if (status!=DomainStatus.Ready)
        throw new InvalidOperationException("Domain isn't built.");
    }

    /// <summary>
    /// Creates new <see cref="Session"/> instance.
    /// </summary>
    /// <param name="userName">User name to authenticate (use <see cref="String.Empty"/> to omit authentication).</param>
    /// <param name="authParams">Authentication params (e.g. password).</param>
    /// <returns>New session.</returns>
    public Session CreateSession(string userName, params object[] authParams)
    {
      EnsureDomainIsBuilt();

      return new Session(this, userName, authParams);
    }
    
    /// <summary>
    /// Creates new <see cref="Session"/> instance.
    /// </summary>
    /// <returns>New session.</returns>
    public Session CreateSession()
    {
      EnsureDomainIsBuilt();

      return new Session(this);
    }

    
    // Domain building methods
    
    /// <summary>
    /// Builds the <see cref="Domain"/> in <see cref="DefaultUpdateMode"/>.
    /// </summary>
    /// <remarks>
    /// Exactly this method does the following:
    /// <para>
    /// 1) Sets <see cref="Domain"/>'s <see cref="Status"/> to <see cref="DomainStatus.Building"/>;
    /// </para>
    /// <para>
    /// 2) Generates <see cref="ObjectModel"/>,
    /// invokes <see cref="ObjectModelBuilt"/> event;
    /// </para>
    /// <para>
    /// 3) Generates <see cref="DatabaseModel"/> by the <see cref="ObjectModel"/>;
    /// </para>
    /// <para>
    /// 4) Extracts <see cref="ExtractedDatabaseModel"/> (the model of existing database);
    /// </para>
    /// <para>
    /// 5) Compares <see cref="DatabaseModel"/> and <see cref="ExtractedDatabaseModel"/>, 
    ///    generates <see cref="UpdateActions"/> list;
    /// </para>
    /// <para>
    /// 6) Performs update of the underlying database by executing
    ///    <see cref="DataObjects.NET.DatabaseModel.UpdateAction.GetSqlCommands">SQL code</see> of
    ///    <see cref="UpdateActions"/> (this operation is performed
    ///    in a single or multiple transactions - this depends on
    ///    <see cref="DataObjects.NET.DatabaseModel.UpdateAction.CanBeExecutedInTransaction"/> value
    ///    of each <see cref="DataObjects.NET.DatabaseModel.UpdateAction"/>).
    /// </para>
    /// <para>
    /// 7) Generates and compiles the <see cref="Assembly"/> with proxy classes
    ///    (see <see cref="ProxyAssembly"/>, <see cref="ProxyBuilderResults"/>) 
    ///    and loads it;
    /// </para>
    /// <para>
    /// 8) <see cref="ILockable.Lock"/>s all models;
    /// </para>
    /// <para>
    /// 9) Sets <see cref="Domain"/>'s <see cref="Status"/> to <see cref="DomainStatus.InitializingSystemObjects"/>;
    /// </para>
    /// <para>
    /// 10) Creates first <see cref="Session"/> instance, 
    ///     performs default initialization of system objects, 
    ///     invokes <see cref="InitializeSystemObjects"/> event;
    /// </para>
    /// <para>
    /// 11) Sets <see cref="Domain"/>'s <see cref="Status"/> to <see cref="DomainStatus.Initializing"/>;
    /// </para>
    /// <para>
    /// 12) Impersonates (see <see cref="Session.Authenticate">Session.Authenticate</see>,
    ///     <see cref="Session.User">Session.User</see>) 
    ///     to <see cref="SystemObjects.SystemUser"/> in this <see cref="Session"/>,
    ///     invokes <see cref="Initialize"/> event;
    /// </para>
    /// <para>
    /// 13) Sets <see cref="Domain"/>'s <see cref="Status"/> to <see cref="DomainStatus.Ready"/>;
    /// </para>
    /// <para>
    /// 14) Starts <see cref="RuntimeServices"/> thread (first service will be
    ///     executed after 1 minute from domain creation time).
    /// </para>
    /// <para>
    /// After completion of this method <see cref="Domain"/> becomes operable.
    /// This means that it becomes possible to create <see cref="Session"/> 
    /// instances in this <see cref="Domain"/>.
    /// </para>
    /// <para>
    /// It's your responsibility to provide exclusive database access for the
    /// DataObjects.NET during the period of <see cref="Build"/> method execution.
    /// </para>
    /// </remarks>
    public void Build()
    {
      Build(DefaultUpdateMode);
    }
    
    /// <summary>
    /// Builds the <see cref="Domain"/>.
    /// </summary>
    /// <param name="updateMode">Domain update mode.</param>
    /// <remarks>
    /// Exactly this method does the following:
    /// <para>
    /// 1) Sets <see cref="Domain"/>'s <see cref="Status"/> to <see cref="DomainStatus.Building"/>;
    /// </para>
    /// <para>
    /// 2) Generates <see cref="ObjectModel"/>;
    /// </para>
    /// <para>
    /// 3) Generates <see cref="DatabaseModel"/> by the <see cref="ObjectModel"/>;
    /// </para>
    /// <para>
    /// 4) Extracts <see cref="ExtractedDatabaseModel"/> (the model of existing database);
    /// </para>
    /// <para>
    /// 5) Compares <see cref="DatabaseModel"/> and <see cref="ExtractedDatabaseModel"/>, 
    ///    generates <see cref="UpdateActions"/> list;
    /// </para>
    /// <para>
    /// 6) Performs update of the underlying database by executing
    ///    <see cref="DataObjects.NET.DatabaseModel.UpdateAction.GetSqlCommands">SQL code</see> of
    ///    <see cref="UpdateActions"/> (this operation is performed
    ///    in a single or multiple transactions - this depends on
    ///    <see cref="DataObjects.NET.DatabaseModel.UpdateAction.CanBeExecutedInTransaction"/> value
    ///    of each <see cref="DataObjects.NET.DatabaseModel.UpdateAction"/>).
    /// </para>
    /// <para>
    /// 7) Generates and compiles the <see cref="Assembly"/> with proxy classes
    ///    (see <see cref="ProxyAssembly"/>, <see cref="ProxyBuilderResults"/>) 
    ///    and loads it;
    /// </para>
    /// <para>
    /// 8) <see cref="ILockable.Lock"/>s all models;
    /// </para>
    /// <para>
    /// 9) Sets <see cref="Domain"/>'s <see cref="Status"/> to <see cref="DomainStatus.InitializingSystemObjects"/>;
    /// </para>
    /// <para>
    /// 10) Creates first <see cref="Session"/> instance, 
    ///     performs default initialization of system objects, 
    ///     invokes <see cref="InitializeSystemObjects"/> event;
    /// </para>
    /// <para>
    /// 11) Sets <see cref="Domain"/>'s <see cref="Status"/> to <see cref="DomainStatus.Initializing"/>;
    /// </para>
    /// <para>
    /// 12) Impersonates (see <see cref="Session.Authenticate">Session.Authenticate</see>,
    ///     <see cref="Session.User">Session.User</see>) 
    ///     to <see cref="SystemObjects.SystemUser"/> in this <see cref="Session"/>,
    ///     invokes <see cref="Initialize"/> event;
    /// </para>
    /// <para>
    /// 13) Sets <see cref="Domain"/>'s <see cref="Status"/> to <see cref="DomainStatus.Ready"/>;
    /// </para>
    /// <para>
    /// 14) Starts <see cref="RuntimeServices"/> thread (first service will be
    ///     executed after 1 minute from domain creation time).
    /// </para>
    /// <para>
    /// After completion of this method <see cref="Domain"/> becomes operable.
    /// This means that it becomes possible to create <see cref="Session"/> 
    /// instances in this <see cref="Domain"/>.
    /// </para>
    /// <para>
    /// Normally <paramref name="updateMode"/> should be <see cref="DomainUpdateMode.Perform"/>.
    /// </para>
    /// <para>
    /// It's your responsibility to provide exclusive database access for the
    /// DataObjects.NET during the period of <see cref="Build"/> method execution.
    /// </para>
    /// </remarks>
    public void Build(DomainUpdateMode updateMode)
    {
      if (status!=DomainStatus.Created && status!=DomainStatus.Error)
        throw new DomainConstructionException("Build method must be called once.", null);
      if ((databaseOptions & DomainDatabaseOptions.EnableVersionizing)!=0 && !driverInfo.SupportsVersionizing)
        throw new DomainConstructionException("Driver doesn't support versionizing.", null);

      if (!(FtsDriver is FullText.Drivers.Native.NativeFtsDriver) || (databaseOptions & DomainDatabaseOptions.EnableFullTextSearch)!=0) {
        RegisterService(typeof(FullText.FtsEventWatcher));
        RegisterService(typeof(FullText.FtIndexerService));
      }
      
      try {
        status = DomainStatus.Building;
        if (debugInfoOutputFolder!=null) {
          string sPathA = Path.Combine(_DebugInfoOutputFolder, "DomainBuildLog.txt");
          debugStreamWriter = new StreamWriter(sPathA);
          debugStreamWriter.WriteLine("DataObjects.NET Domain.Build log:");
          debugStreamWriter.WriteLine("");
          debugStreamWriter.WriteLine("   Time: Description:");
          buildStartTime = DateTime.Now;
        }
        LogDebugEvent("Build started...");
        LogDebugEvent("  Detecting version of the underlying RDBMS...");
        driver.DetectRdbmsVersion();
        LogDebugEvent("    Done.");

        LogDebugEvent("  Locking Domain.Cultures collection...");
        Cultures.Lock(true);
        LogDebugEvent("    Done.");

        LogDebugEvent("  Locking Domain.Environment...");
        if (Environment is ILockable) {
          (Environment as ILockable).Lock(true);
          LogDebugEvent("    Done.");
        }
        else
          LogDebugEvent("    Can't be locked (is not ILockable).");

        BuildActionDelegate buildDelegate = null;
        IAsyncResult        buildActionAsyncResult = null;
        WaitHandle          buildActionWaitHandle = null;

        if (threadedBuildExecution) {
          LogDebugEvent("  [Parallel schema extraction started]");
          buildDelegate = new BuildActionDelegate(ExtractDatabase);
          buildActionAsyncResult = buildDelegate.BeginInvoke(updateMode, null, null);
        }

        if (Cultures.Count==0)
          throw new InvalidOperationException("At least one culture should be registered in the domain.");
        if (Cultures.DefaultCulture==null)
          throw new InvalidOperationException("Default culture for Domain isn't specified.");

        LogDebugEvent("  Registering Field types (DataObjects.NET.ObjectModel.Field descendants)...");
        RegisterFieldTypes(Assembly.GetExecutingAssembly());
        LogDebugEvent("    Done.");

        LogDebugEvent("  Building Object model (see DataObjects.NET.ObjectModel.Model)...");
        objectModel = BuildObjectModel();
        LogDebugEvent("    Done.");
        LogDebugEvent("  Calling OnObjectModelBuilt...");
        OnObjectModelBuilt();
        LogDebugEvent("    Done.");
        LogDebugEvent("  Fixing possibly updated Object Model...");
        FixObjectModel();
        LogDebugEvent("    Done.");
        objectModelBuilder = null;

        LogDebugEvent("  Building Database model (see DataObjects.NET.DatabaseModel.Database)...");
        databaseModel = BuildDatabaseModel();
        LogDebugEvent("    Done.");

        if (objectModel.Types.Count<1)
          throw new DomainConstructionException("No types found in the domain.", null);
        if (databaseModel.Tables.Count<1)
          throw new DomainConstructionException("No tables found in the domain database.", null);
          
#if (EXPRESS)
        if (objectModel.Types.Count>50) {
          MessageBox.Show(
            "You are using more then 50 persistent types!",
            "Express Edition limitation",
            MessageBoxButtons.OK,
            MessageBoxIcon.Stop,
            MessageBoxDefaultButton.Button1,
            MessageBoxOptions.DefaultDesktopOnly);
          status = DomainStatus.Error;
          return;
        }
        if (databaseModel.Tables.Count>100) {
          MessageBox.Show(
            "You are using more then 100 tables.",
            "Express Edition limitation",
            MessageBoxButtons.OK,
            MessageBoxIcon.Stop,
            MessageBoxDefaultButton.Button1,
            MessageBoxOptions.DefaultDesktopOnly);
          status = DomainStatus.Error;
          return;
        }
        foreach (ObjectModel.Type type in objectModel.Types) {
          if (!type.IsInterface)
            continue;
          Type sourceType = type.SourceType;
          if (sourceType.Assembly==typeof(IDataObject).Assembly)
            continue;
          if (type.ShortName=="IPerson" || type.ShortName=="ITopLevelObject")
            continue;
          MessageBox.Show(
            String.Format("You are using custom persistent interface \"{0}\".", type.Name),
            "Express Edition limitation",
            MessageBoxButtons.OK,
            MessageBoxIcon.Stop,
            MessageBoxDefaultButton.Button1,
            MessageBoxOptions.DefaultDesktopOnly);
          status = DomainStatus.Error;
          return;
        }
#endif

        if (threadedBuildExecution) 
        {
          LogDebugEvent("  [Waiting for parallel schema extraction completion]");
          buildActionWaitHandle = buildActionAsyncResult.AsyncWaitHandle;
          buildActionWaitHandle.WaitOne();
          buildDelegate.EndInvoke(buildActionAsyncResult);
          LogDebugEvent("  [Parallel schema extraction completed]");

          LogDebugEvent("  [Parallel schema upgrade started]");
          buildDelegate = new BuildActionDelegate(UpdateDatabase);
          buildActionAsyncResult = buildDelegate.BeginInvoke(updateMode, null, null);
        }

        LogDebugEvent("  Building Proxy assembly...");
        BuildProxies(updateMode);
        LogDebugEvent("    Done.");

        if (debugInfoOutputFolder!=null) {
          LogDebugEvent("  Dumping models...");
          LogDebugEvent("    Dumping Object model...");
          string sPathA = Path.Combine(_DebugInfoOutputFolder, "DomainObjectModel.txt");
          using (StreamWriter sw = new StreamWriter(sPathA)) {
            objectModel.Dump(sw, "");
          }
          LogDebugEvent("    Dumping Database model...");
          string sPathB = Path.Combine(_DebugInfoOutputFolder, "DomainDatabaseModel.txt");
          using (StreamWriter sw = new StreamWriter(sPathB)) {
            databaseModel.Dump(sw, "");
          }
          LogDebugEvent("    Done.");
        }

        if (threadedBuildExecution) {
          LogDebugEvent("  [Waiting for parallel schema upgrade completion]");
          buildActionWaitHandle = buildActionAsyncResult.AsyncWaitHandle;
          buildActionWaitHandle.WaitOne();
          buildDelegate.EndInvoke(buildActionAsyncResult);
          LogDebugEvent("  [Parallel schema upgrade completed]");
        }
        else {
          LogDebugEvent("  Updating database...");
          ExtractDatabase(updateMode);
          UpdateDatabase(updateMode);
          LogDebugEvent("    Done.");
        }

        LogDebugEvent("  Updating full-text index...");
        UpdateFtIndex(updateMode);
        LogDebugEvent("    Done.");

        LogDebugEvent("  Locking Object and Database models...");
        objectModel.Lock(true);
        databaseModel.Lock(true);
        LogDebugEvent("    Done.");

        if (debugInfoOutputFolder!=null) {
          LogDebugEvent("  Dumping models...");
          LogDebugEvent("    Dumping Object model...");
          string sPathA = Path.Combine(_DebugInfoOutputFolder, "DomainObjectModel.txt");
          using (StreamWriter sw = new StreamWriter(sPathA)) {
            objectModel.Dump(sw, "");
          }
          LogDebugEvent("    Dumping Database model...");
          string sPathB = Path.Combine(_DebugInfoOutputFolder, "DomainDatabaseModel.txt");
          using (StreamWriter sw = new StreamWriter(sPathB)) {
            databaseModel.Dump(sw, "");
          }
          LogDebugEvent("    Done.");
        }

        LogDebugEvent("  Collecting garbage...");
        GC.Collect();
        LogDebugEvent("    Done.");

        status = DomainStatus.InitializingSystemObjects;

        LogDebugEvent("  Initializing...");
        globalCache = new Caching.GlobalCache(this, globalCacheSize);
//SM begin
        Caching.ChangeCache.maxSize = this.ChangeCacheSize;
        Caching.ConnectionCleaner.cleantime = this.ConnectionCleanInterval;
        Caching.ConnectionCleaner.connectionlifetime = this.ConnectionLifeTime;
        CommandMonitor.EnableLogging = this.EnableCommandTrace;
//SM end
        performanceCounters = new DomainPerformanceCounters(this, enablePerformanceCounters);
        LogDebugEvent("    Creating intitialization session...");
        Session session = new Session(this);
        session.securityOptions = SessionSecurityOptions.Minimal;
        LogDebugEvent("      Done.");
        LogDebugEvent("    Initializing system objects...");
        DoInitializeSystemObjects(session);
        LogDebugEvent("      Done.");
        session.systemObjects.InvalidateCachedSystemObjects();
        status = DomainStatus.Initializing;

        LogDebugEvent("    Switching to System User...");
        session.User = session.systemObjects.SystemUser;
        LogDebugEvent("      Done.");
        LogDebugEvent("    Initializing other objects...");
        DoInitialize(session);
        LogDebugEvent("      Done.");
        LogDebugEvent("    Done.");

        status = DomainStatus.Ready;

        lock (availableDomains) {
          availableDomains.RegisterDomain(this);
        }

        LogDebugEvent("  Starting runtime services...");
        runtimeServices.Start(session);
        LogDebugEvent("    Done.");

        LogDebugEvent("Domain building is completed.");
      }
      catch (DomainConstructionException e) {
        status = DomainStatus.Error;
        LogDebugEvent("  Exception: " + e.ToString());
        throw;
      }
      catch (DataObjectsDotNetException e) {
        status = DomainStatus.Error;
        if (e.Message=="Invalid product key.")
          throw new DataObjectsDotNetException("Invalid product key.");
        LogDebugEvent("  Exception: " + e.ToString());
        throw new DomainConstructionException("Domain construction error.", e);
      }
      catch (Exception e) {
        status = DomainStatus.Error;
        LogDebugEvent("  Exception: " + e.ToString());
        throw new DomainConstructionException("Domain construction error.", e);
      }
      finally {
        if (this.debugStreamWriter!=null) {
          this.debugStreamWriter.Flush();
          this.debugStreamWriter.Close();
        }
      }
    }

    /// <summary>
    /// Builds the Domain Object Model...
    /// </summary>
    /// <returns>Domain Object Model.</returns>
    private ObjectModel.Model BuildObjectModel()
    {
      objectModelBuilder = new ObjectModel.Builders.ObjectModelBuilder(this);
      return objectModelBuilder.BuildModel();
    }

    /// <summary>
    /// Occurs during execution of the <see cref="Build"/> method
    /// in the moment when <see cref="ObjectModel"/> is already built,
    /// but its <see cref="DatabaseModel"/> is not built yet.
    /// Allows you to extend <see cref="ObjectModel"/> at runtime.
    /// </summary>
    public event DomainEventHandler ObjectModelBuilt {
      add {
        if (status!=DomainStatus.Created && status!=DomainStatus.Error)
          throw new InvalidOperationException("Attempt to change event handler in the Domain with already called Build method.");
        objectModelBuilt += value;
      }
      remove {
        if (status!=DomainStatus.Created && status!=DomainStatus.Error)
          throw new InvalidOperationException("Attempt to change event handler in the Domain with already called Build method.");
        objectModelBuilt -= value;
      }
    }
    private void OnObjectModelBuilt()
    {
      if (objectModelBuilt!=null)
        objectModelBuilt(this, new DomainEventArgs(this));
    }
    private DomainEventHandler objectModelBuilt;

    private Hashtable hFixedTypes;
    private void FixObjectModel()
    {
      objectModel.Types.BuildLookups();

      // We have to ensure that any descendant of a parent type contains all parent fields.
      // The another task is to ensure that fields of any type are consistent with each other. 
      hFixedTypes = new Hashtable(objectModel.Types.Count);
      foreach(ObjectModel.Type type in objectModel.Types)
        FixTypeFields(type);
      hFixedTypes = null;
    }

    private void FixSourceTypes()
    {
      foreach(ObjectModel.Type type in objectModel.Types) {
        foreach(ObjectModel.Field f in type.Fields) {
          if (f.SourceType==null) {
            Type[] assocTypes =  f.GetAssociatedTypes();
            System.Diagnostics.Debug.Assert(assocTypes.Length >= 1);
            Type sourceType = null;
            int iTypeIndex = 0;
            while ( (sourceType==null) && (iTypeIndex<assocTypes.Length))
              sourceType = assocTypes[iTypeIndex++];
            System.Diagnostics.Debug.Assert(sourceType != null);
            f.SourceType = sourceType;
          }
          if (f.ExternalTypeInternal==null)
            f.ExternalType = f.SourceType;
        }
        if (type.OfflineSourceType==null)
          objectModelBuilder.CheckOfflineType(type);
      }
    }

    private void FixTypeFields(ObjectModel.Type type)
    {
      if (type == null)
        return;
      if (hFixedTypes.Contains(type))
        return;
      ArrayList baseTypes = new ArrayList();
      if (!type.IsInterface) {
        if (type.BaseType!=null)
          baseTypes.Add(type.BaseType);
      }
      else {
        Type[]  standardInterfaces = type.SourceType.FindInterfaces(new TypeFilter(InterfaceFilter), type);
        ICollection interfaces = GetOnlyDirectInterfaces(standardInterfaces);
        foreach (Type st in interfaces) {
          ObjectModel.Type ot = objectModel.Types[st];
          if (ot==null)
            throw new ObjectModelBuilderException(String.Format(
              "Supported interface \"{0}\" isn't registered in the domain. ", st.FullName));
          if (!ot.IsInterface)
            throw new ObjectModelBuilderException(String.Format(
              "Internal error - interface \"{0}\" was incorrectly described. "
              , st.FullName));
          if (ot!=null)
            baseTypes.Add(ot);
        }
      }
      foreach(ObjectModel.Type ot in baseTypes)
        FixTypeFields(ot);
      hFixedTypes.Add(type,"");
      // Now check that all fields from base classes are present in my class
      // and fix if not
      bool  typeChanged = false;
      foreach (ObjectModel.Type baseType in baseTypes)
        foreach(ObjectModel.Field f in baseType.Fields) {
          ObjectModel.Field inheritedField = type.Fields[f.Name];
          if (inheritedField == null) {
            // Create new field
            objectModelBuilder.BuildInheritedField(type,f);
            typeChanged = true;
          }
          else {
            // Check the field
            if (!type.IsInterface)
              if (inheritedField.AncestorField != f)
                throw new ObjectModelBuilderException(String.Format(
                  "Internal error - \"{0}:{1}\" is not a descendant of the field {2}:{3}.",
                  inheritedField.Type.Name, inheritedField.Name, f.Type.Name, f.Name));
          }
        }

      foreach(ObjectModel.Field f in type.Fields) {
        if (f.SourceType==null) {
          Type[] assocTypes =  f.GetAssociatedTypes();
          System.Diagnostics.Debug.Assert(assocTypes.Length >= 1);
          Type sourceType = null;
          int iTypeIndex = 0;
          while ( (sourceType==null) && (iTypeIndex<assocTypes.Length))
            sourceType = assocTypes[iTypeIndex++];
          System.Diagnostics.Debug.Assert(sourceType != null);
          f.SourceType = sourceType;
        }
        if (f.ExternalTypeInternal==null)
          f.ExternalType = f.SourceType;
      }
      if (type.OfflineSourceType==null || typeChanged)
        objectModelBuilder.CheckOfflineType(type);
      
      objectModelBuilder.EnsureFieldsConsistency(type);
    }

    private ICollection GetOnlyDirectInterfaces(Type[] interfaces)
    {
      int iLength = interfaces.Length;
      ArrayList result = new ArrayList(iLength);
      for (int i = 0; i<iLength; i++) {
        bool bHasNoDescendants = true;
        for (int j = 0; (j<iLength) && bHasNoDescendants; j++) {
          if (i==j)
            continue;
          if (interfaces[i].IsAssignableFrom(interfaces[j]))
            bHasNoDescendants = false;
        }
        if (bHasNoDescendants)
          result.Add(interfaces[i]);
      }
      return result;
    }

    /// <summary>
    /// Builds Domain Database Model...
    /// </summary>
    /// <returns>Domain Database Model.</returns>
    private DatabaseModel.Database BuildDatabaseModel()
    {
      DatabaseModel.Builders.DatabaseModelBuilder b = new DatabaseModel.Builders.DatabaseModelBuilder(this);
      return b.BuildModel();
    }

    /// <summary>
    /// Builds proxies for Domain <see cref="DataObject"/>s...
    /// </summary>
    /// <param name="updateMode">Database update mode.</param>
    private void BuildProxies(DomainUpdateMode updateMode)
    {
      ObjectModel.Builders.ProxyBuilder b = new ObjectModel.Builders.ProxyBuilder(this);
      proxyBuilderResults = b.BuildProxies(updateMode);
      proxyAssembly = proxyBuilderResults.Assembly;
      AssemblyResolver.AddAssembly(proxyAssembly.FullName, proxyAssembly);

      // Creating Activator
      Type activatorType = proxyAssembly.GetType(
        proxyBuilderResults.GetProxyName(
          typeof(ObjectModel.Activator).FullName));
      if (activatorType==null)
        throw new ProxyBuilderException("Activator type wasn't found.");
      objectModel.Activator = (ObjectModel.Activator)
        Activator.CreateInstance(activatorType);
        
      // Processing types and services
      foreach (ObjectModel.Type t in ObjectModel.Types) {
        foreach (ObjectModel.Field f in t.Fields) {
          ObjectModel.IHasProxyTypeField hpf = f as ObjectModel.IHasProxyTypeField;
          if (hpf!=null) {
            string proxyTypeName = proxyBuilderResults.GetProxyName(f.SourceType.FullName);
            if (proxyTypeName!=null)
              hpf.ProxyType = proxyAssembly.GetType(proxyTypeName);
            if (f.OfflineSourceType!=null) {
              string offlineProxyTypeName = proxyBuilderResults.GetProxyName(f.OfflineSourceType.FullName);
              if (offlineProxyTypeName!=null)
                hpf.OfflineProxyType = proxyAssembly.GetType(offlineProxyTypeName);
            }
          }
        }
        if (!t.IsAbstract) {
          t.ProxyType = proxyAssembly.GetType(proxyBuilderResults.GetProxyName(t.Name));
          if (t.ProxyType==null) {
            throw new ProxyBuilderException(String.Format(
              "A proxy for the \"{0}\" type wasn't found. " +
              "Most likely a cached proxy assembly is obsolete. " +
              "Please remove it and try again.", t.Name));
          }
        }
        if (t.OfflineSourceType!=null) {
          string offlineProxyTypeName = proxyBuilderResults.GetOfflineProxyName(t.OfflineSourceType.FullName);
          if (offlineProxyTypeName != null)
            t.OfflineProxyType = proxyAssembly.GetType(offlineProxyTypeName, true);
        }
      }
      foreach (ObjectModel.Service s in ObjectModel.Services) {
        if (!s.IsAbstract) {
          s.ProxyType = proxyAssembly.GetType(proxyBuilderResults.GetProxyName(s.Name), true);
          if (s.ProxyType==null) {
            throw new ProxyBuilderException(String.Format(
              "A proxy for the \"{0}\" service wasn't found. " +
              "Most likely a cached proxy assembly is obsolete. " +
              "Please remove it and try again.", s.Name));
          }
        }
      }
    }

    private delegate void BuildActionDelegate(DomainUpdateMode updateMode);

    private void ExtractDatabase(DomainUpdateMode updateMode)
    {
      LogDebugEvent("    Domain update mode: " + updateMode.ToString());
      using (IDbConnection  connection  = driver.OpenConnection())
      using (IDbTransaction transaction = connection.BeginTransaction(
        driver.TranslateIsolationLevel(IsolationLevel.Serializable))) 
      try {
        LogDebugEvent("    Extracting the model of existing database...");
        DatabaseModel.Extractors.DatabaseModelExtractor e = 
          new DatabaseModel.Extractors.DatabaseModelExtractor(this, connection, transaction);
        extractedDatabaseModel = e.ExtractModel(updateMode);
        extractedDatabaseModel.Lock(true);
        LogDebugEvent("      Done.");

        if (debugInfoOutputFolder!=null) {
          LogDebugEvent("    Dumping Extracted Database model...");
          string sPath = Path.Combine(_DebugInfoOutputFolder, "ExtractedDatabaseModel.txt");
          using (StreamWriter sw = new StreamWriter(sPath)) {
            extractedDatabaseModel.Dump(sw, "");
          }
          LogDebugEvent("      Done.");
        }
        transaction.Commit();
      }
      catch {
        try { transaction.Rollback(); } catch {}
        throw;
      }
    }

      private void InitializeDatabaseSchema()
      {
          using (IDbConnection connection = driver.OpenConnection())
          {
                  using (IDbCommand dbCmd = driver.CreateCommand(connection))
                  {
                      dbCmd.CommandTimeout = 300;
                      using (IDbTransaction transaction = connection.BeginTransaction(driver.TranslateIsolationLevel(IsolationLevel.Serializable)))
                      {
                          try
                          {
                              dbCmd.Transaction = transaction;
                              dbCmd.CommandText = "SELECT count(*) FROM INFORMATION_SCHEMA.TABLES where TABLE_NAME = 'SysFlatSequence'";
                              int resCount = Convert.ToInt32(dbCmd.ExecuteScalar());
                              if (resCount == 0)
                              {
                                  dbCmd.CommandText =
                                  @" CREATE TABLE [SysFlatSequence](
	                            [ID] [bigint] IDENTITY(1,1) NOT NULL,
	                            [Dummy] [bit] NULL
                                ) ON [PRIMARY]
                              ";
                                  dbCmd.ExecuteNonQuery();
                              }
                              transaction.Commit();
                          }
                          catch (Exception ex)
                          {
                              transaction.Rollback();
                              throw ex;
                          }
                      }
                  }

                  foreach (string command in ModelExtensions.DatabaseSchemaInitCommands)
                  {
                      if (!String.IsNullOrEmpty(command))
                      using (IDbCommand dbCmd = driver.CreateCommand(connection))
                      {
                          dbCmd.CommandTimeout = 300;
                          char transMode = command[0];
                          if (transMode == '+' || transMode == '-')
                          {
                              try
                              {
                                  dbCmd.CommandText = command.Substring(1);
                                  dbCmd.ExecuteNonQuery();
                              }
                              catch (Exception ex)
                              {
                                  if (transMode == '+')
                                    throw ex;
                              }
                          }
                          else
                          using (IDbTransaction transaction = connection.BeginTransaction(driver.TranslateIsolationLevel(IsolationLevel.Serializable)))
                          {
                              try
                              {
                                  dbCmd.Transaction = transaction;
                                  dbCmd.CommandText = command;
                                  dbCmd.ExecuteNonQuery();
                                  transaction.Commit();
                              }
                              catch (Exception ex)
                              {
                                  transaction.Rollback();
                                  throw ex;
                              }
                          }
                      }
                  }

          }
      }

    private void UpdateDatabase(DomainUpdateMode updateMode)
    {
      LogDebugEvent("    Domain update mode: " + updateMode.ToString());
      LogDebugEvent("    Comparing database models...");
      DatabaseModel.Comparers.DatabaseModelComparer c = new DatabaseModel.Comparers.DatabaseModelComparer(this);
      updateActions = c.Compare(extractedDatabaseModel, databaseModel, updateMode);
      LogDebugEvent("      Done.");

      if (updateMode==DomainUpdateMode.Skip ||
        updateMode==DomainUpdateMode.SkipButExtract) {
        if (updateActions.Count!=0)
          throw new DomainUpdateIsBlockedException(
            "Some types were added or deleted. " +
              "Continuing the operation may lead to data loss.");
        else
          return;
      }

      Driver.UpdateActionTranslator.Init();

      if (debugInfoOutputFolder!=null) {
        LogDebugEvent("    Dumping Schema Update SQL script...");
        string sPath = Path.Combine(_DebugInfoOutputFolder, "SchemaUpdateSQL.txt");
        using (StreamWriter sw = new StreamWriter(sPath)) {
          foreach (string s in updateActions.GetSqlCommands(driver.UpdateActionTranslator, true))
            sw.WriteLine(s + "\n");
        }
        LogDebugEvent("      Updating Database Done.");
      }

      if (updateMode==DomainUpdateMode.SkipButExtractAndCompare) {
        if (updateActions.Count!=0)
          throw new DomainUpdateIsBlockedException(
            "Some types were added or deleted. " +
              "Continuing the operation may lead to data loss.");
        else
          return;
      }

      if (updateActions.Count!=0) {
        if (updateMode==DomainUpdateMode.Block)
          throw new DomainUpdateIsBlockedException();

      if (updateMode == DomainUpdateMode.Recreate)
          InitializeDatabaseSchema();

        LogDebugEvent("    Executing Schema Update SQL script...");
        using (IDbConnection connection = driver.OpenConnection()) {
          IDbTransaction transaction = null;
          bool bAutoAssignTran = driver.Info.AutomaticallyAssignsTransactionToCommand;
          try {
            IDbCommand dbCmd = driver.CreateCommand(connection);
            dbCmd.CommandTimeout = 0;
            driver.UpdateActionTranslator.LazyFlatUpdate.Clear();
            driver.UpdateActionTranslator.ConvertedFlatTables.Clear();
            foreach (DatabaseModel.UpdateAction action in updateActions) {
              string[] aCmds = action.GetSqlCommands(driver.UpdateActionTranslator);
              bool bTran = TransactionalUpdate &&
                action.CanBeExecutedInTransaction(driver.UpdateActionTranslator);
              if (bTran && transaction==null) {
                LogDebugEvent("      [Begin transaction]");
                if (transaction!=null)
                  transaction.Dispose();
                transaction = connection.BeginTransaction(
                  driver.TranslateIsolationLevel(IsolationLevel.Serializable));
                if (!bAutoAssignTran)
                  dbCmd.Transaction = transaction;
              }
              else if (!bTran && transaction!=null) {
                LogDebugEvent("      [Commit transaction]");
                transaction.Commit();
                if (transaction!=null)
                  transaction.Dispose();
                transaction = null;
                if (dbCmd!=null)
                  dbCmd.Dispose();
                dbCmd = driver.CreateCommand(connection);
                dbCmd.CommandTimeout = 0;
              }
              LogDebugEvent("      " +action.CommentedDescription);
              foreach (string sCmd in aCmds) {
                dbCmd.CommandText = sCmd;
#if MONO
                  UpdateDatabase_FixSqlCommandForMono(dbCmd);
#endif
                LogDebugEvent("      " +sCmd);
                dbCmd.ExecuteNonQuery();
              }
            }
            if (transaction!=null) {
              transaction.Commit();
              transaction.Dispose();
              LogDebugEvent("      [Commit transaction]");
            }
            if (dbCmd!=null)
              dbCmd.Dispose();
          }
          catch {
            try {
              if (transaction!=null) {
                transaction.Rollback();
                transaction.Dispose();
                LogDebugEvent("      [Rollback transaction]");
              }
            }
            catch {}
            throw;
          }
        }
        LogDebugEvent("      Done.");
      }
    }
    
  #if MONO
    private void UpdateDatabase_FixSqlCommandForMono(IDbCommand cmd)
    {
      if (cmd is SqlCommand) {
        if (!TransactionalUpdate)
          cmd.CommandText += "\nIf @@trancount>0 then Commit\n--";
        else
          cmd.CommandText += "\n--";
      }
    }
  #endif

    private void UpdateFtIndex(DomainUpdateMode updateMode)
    {
      LogDebugEvent("    Domain update mode: "+updateMode.ToString());
      FtsDriver.UpdateIndex(updateMode);
      LogDebugEvent("      Done.");
    }
    
    private void DoInitializeSystemObjects(Session session)
    {
      TransactionController tc = session.CreateTransactionController( TransactionMode.TransactionRequired);
      try {
        // Let's locate already existing objects
        DataObject   root = (DataObject)session.SystemObjects.SecurityRoot;
        User   systemUser = session.SystemObjects.SystemUser;
        User    adminUser = session.SystemObjects.AdministratorUser;
        Role    adminRole = session.SystemObjects.AdministratorsRole;
        Role everyoneRole = session.SystemObjects.EveryoneRole;
        // And create all system objects that don't exist
        if (root==null)
          root = session.CreateObject(typeof(SecurityRoot));
        if (everyoneRole==null) {
          // You should never add Principals to this role manually
          everyoneRole = (Role)session.CreateObject(typeof(Role), SystemObjectNames.EveryoneRoleName);
        }
        if (adminRole==null) {
          adminRole = (Role)session.CreateObject(typeof(Role), SystemObjectNames.AdministratorsRoleName);
        }
        if (systemUser==null) {
          systemUser = (User)session.CreateObject(typeof(StdUser), SystemObjectNames.SystemUserName);
          (systemUser as StdUser).SetPassword("", HashingMethod.Plain); 
          // Actually it's not important - password is never used for
          // System user (because it's impossible to Authenticate as
          // System user, but nevertheless DataServices or DataObjects
          // can set Session.User property to a System user without
          // authentication).
        }
        if (adminUser==null) {
          adminUser = (User)session.CreateObject(typeof(StdUser), SystemObjectNames.AdministratorUserName);
          (adminUser as StdUser).SetPassword("", HashingMethod.Plain); 
          // This password should be changed by the real application!
        }
        root.Permissions.RemoveDenied(systemUser,AdministrationPermission.Value);
        root.Permissions.RemoveDenied(adminUser, AdministrationPermission.Value);
        root.Permissions.RemoveDenied(adminRole, AdministrationPermission.Value);
        root.Permissions.Allow(systemUser,AdministrationPermission.Value);
        root.Permissions.Allow(adminUser, AdministrationPermission.Value);
        root.Permissions.Allow(adminRole, AdministrationPermission.Value);
        root.Permissions.Allow(everyoneRole,ChangePasswordPermission.Value);
        if (!adminUser.Roles.Contains(adminRole))
          adminUser.Roles.Add(adminRole);
        session.systemObjects.InvalidateCachedSystemObjects();
        
        // Finally let's raise InitializeSystemObjects event
        OnInitializeSystemObjects(session, new SessionEventArgs(session, false));
        tc.Commit();
      }
      catch (Exception e) {
        tc.Rollback(e);
        throw;
      }
    }
    
    private void DoInitialize(Session session)
    {
      TransactionController tc = session.CreateTransactionController( TransactionMode.TransactionRequired);
      try {
        // Let's raise Initialize event
        OnInitialize(session, new SessionEventArgs(session, false));
        tc.Commit();
      }
      catch (Exception e) {
        tc.Rollback(e);
        throw;
      }
    }
    
    private DateTime buildStartTime;
    private Regex rLeadingSpaces = new Regex(@"^(?'leadingSpaces'[ ]*)[^ ]", RegexOptions.Compiled | RegexOptions.Multiline);
    private StreamWriter debugStreamWriter = null;
    
    internal void LogDebugEvent(string data)
    {
      if (debugInfoOutputFolder!=null) lock (this) {
        try {
          if (debugStreamWriter==null) {
            string sPathA = Path.Combine(_DebugInfoOutputFolder, "DomainBuildLog.txt");
            debugStreamWriter = new StreamWriter(sPathA, true);
          }
          Match match = rLeadingSpaces.Match(data);
          if (match.Success) {
            string leadingSpaces = match.Result("${leadingSpaces}");
            data = data.Replace("\n", "\n         " + leadingSpaces);
          }
          double diff = (DateTime.Now - buildStartTime).Ticks/10000000.0;
          debugStreamWriter.WriteLine("{0,7:F3}: {1}", diff, data);
        }
        catch {
        }
      }
    }

    private TimeSpan initialLeaseTime;
    private TimeSpan sponsorshipTimeout;
    private TimeSpan renewOnCallTime;
    /// <summary>
    /// Configures initial lease (see <see cref="ILease"/>) values for 
    /// this instance.
    /// </summary>
    /// <param name="initialLeaseTime">Initial lease time (default is <see cref="TimeSpan.Zero"/> that means infinite lease).</param>
    /// <param name="sponsorshipTimeout">Sponsorship timeout (default is 2 minutes, acquired from <see cref="LifetimeServices"/>).</param>
    /// <param name="renewOnCallTime">Renew on call time (default is 2 minutes, acquired from <see cref="LifetimeServices"/>).</param>
    /// <remarks>
    /// You should call this method before marshaling the instance to
    /// specify initial lease values. By default each domain instance
    /// is configured to have infinite initial lease lifetime.
    /// <seealso cref="ILease"/>
    /// <seealso cref="LifetimeServices"/>
    /// </remarks>
    public  void ConfigureInstanceLifetime(
      TimeSpan initialLeaseTime, 
      TimeSpan sponsorshipTimeout,
      TimeSpan renewOnCallTime) 
    {
      if (_marshaled)
        throw new InvalidOperationException("Instance is already marshalled.");
      this.initialLeaseTime   = initialLeaseTime;
      this.sponsorshipTimeout = sponsorshipTimeout;
      this.renewOnCallTime    = renewOnCallTime;
    }
    
    bool _marshaled = false;

    /// <summary>
    /// Obtains a lifetime service object to control the lifetime policy for this instance.
    /// </summary>
    /// <returns>An object of type <see cref="ILease"/> used to control the lifetime policy for this instance.</returns>
    /// <remarks>
    /// This method returns lease initialized by values that can be
    /// specified by calling <see cref="ConfigureInstanceLifetime"/> method.
    /// <seealso cref="ILease"/>
    /// <seealso cref="ConfigureInstanceLifetime"/>
    /// <seealso cref="LifetimeServices"/>
    /// </remarks>
    public override object InitializeLifetimeService()
    {
      ILease lease = (ILease)base.InitializeLifetimeService();
      if (lease.CurrentState==LeaseState.Initial) {
        _marshaled = true;
        lease.SponsorshipTimeout = sponsorshipTimeout;
        lease.RenewOnCallTime    = renewOnCallTime;
        lease.InitialLeaseTime   = initialLeaseTime;
      }
      return lease;
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="connectionUrl">Database connection URL for this <see cref="Domain"/>.</param>
    /// <param name="ftsConnectionUrl">Full-text search connection URL
    /// specifying the full-text search driver (<see cref="FtsDriver"/>)
    /// and its parameters.</param>
    /// <param name="productKey">Your Product Key.</param>
    public Domain(string connectionUrl, string ftsConnectionUrl, string productKey): this(new object[] {connectionUrl, productKey})
    {
      FtsConnectionUrl = ftsConnectionUrl;
    }
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="connectionUrl">Database connection URL for this <see cref="Domain"/>.</param>
    /// <param name="productKey">Your Product Key.</param>
    public Domain(string connectionUrl, string productKey): this(new object[] {connectionUrl, productKey})
    {
    }
    
    private Domain(object[] args): base()
    {
      if (!AssemblyResolver.EventHandlerRegistered)
        AssemblyResolver.RegisterEventHandler();

      guid = Guid.Empty;
      objectModelGuid = Guid.Empty;

      performanceCounters = new DomainPerformanceCounters(this, false);

      initialLeaseTime   = TimeSpan.Zero;
      sponsorshipTimeout = LifetimeServices.SponsorshipTimeout;
      renewOnCallTime    = LifetimeServices.RenewOnCallTime;
      serverSideCacheBackend = new Offline.Internals.ServerSideCacheBackend(this);
      systemObjectNames  = new SystemObjectNames(this);
      cultures           = new CultureCollection(this);
      runtimeServices    = new RuntimeServicePool(this);
      connectionInfo     = new ConnectionInfo("");
      ftsConnectionInfo  = new ConnectionInfo("");
      ftsConnectionInfo.Changed += new EventHandler(FtsConnectionInfoChanged);
      FtsConnectionInfo.Url = "native://localhost/";
      connectionInfo.Changed += new EventHandler(ConnectionInfoChanged);
      connectionInfo.Url = (string)args[0];
      InitializeTypesAndServices();
      #if !EXPRESS
        this.ProductKey = (string)args[1];
      #else
        combinedPrefix = identifierPrefix;
      #endif
      }
    
    private void InitializeTypesAndServices()
    {
      Assembly doAssembly = typeof (DataObject).Assembly;
      RegisterType    (typeof(DataObject));
      RegisterType    (typeof(Versionizing.TransactionInfo));
      RegisterTypes   ("DataObjects.NET.Security", doAssembly);
      RegisterTypes   ("DataObjects.NET.FullText", doAssembly);
      RegisterServices("DataObjects.NET.Offline", doAssembly);
      RegisterService (typeof(Services.ReferenceSearchService));      
      RegisterService (typeof(Services.TrackingService));      
    }
    
    // Events
    
    /// <summary>
    /// Occurs on <see cref="ConnectionInfo"/> property change.
    /// </summary>
    private void ConnectionInfoChanged(Object sender, EventArgs e)
    {
      if (status!=DomainStatus.Created && status!=DomainStatus.Error)
        throw new InvalidOperationException("Attempt to change ConnectionInfo in the Domain with already called Build method.");
      driver            = (new Database.DriverFactory()).CreateDriver(connectionInfo, this);
      driverInfo        = driver.Info;
      utils             = driver.Utils;
    }
    
    /// <summary>
    /// Occurs on <see cref="FtsConnectionInfo"/> property change.
    /// </summary>
    private void FtsConnectionInfoChanged(Object sender, EventArgs e)
    {
      if (status!=DomainStatus.Created && status!=DomainStatus.Error)
        throw new InvalidOperationException("Attempt to change ConnectionInfo in the Domain with already called Build method.");
      ftsDriver = (new FullText.FtsDriverFactory()).CreateDriver(ftsConnectionInfo, this);
    }

    /// <summary>
    /// Occurs before completion of the <see cref="Build"/> method.
    /// This event is raised before <see cref="Initialize"/> event.
    /// <seealso cref="SystemObjectNames"/>
    /// <seealso cref="Build"/>
    /// <seealso cref="Initialize"/>
    /// </summary>
    /// <remarks>
    /// <para>
    /// Use this event handler to initialize (create or update) your 
    /// <see cref="DataObjects.NET.SystemObjectNames">persistent system objects</see>.
    /// </para>
    /// <para>
    /// The minimal set of <see cref="DataObjects.NET.SystemObjectNames">system objects</see> 
    /// that should exist in any <see cref="Domain"/>:
    /// System <see cref="User"/>,
    /// Administrator <see cref="User"/>,
    /// Administrators <see cref="Role"/>,
    /// Everyone <see cref="Role"/>,
    /// <see cref="ISecurityRoot">Security root</see> object.
    /// </para>
    /// <para>
    /// Do not recreate existing system objects on <see langword="each"/>
    /// restart of the domain (their relations will be lost in this case).
    /// Except you should add new system objects required for your application 
    /// (generally this action should be performed once - you can check if all 
    /// necessary objects are alrady created to decide if you should do this), 
    /// or recreate some of initially created security objects (e.g. 
    /// Administartor <see cref="User"/>, System <see cref="User"/> and 
    /// <see cref="ISecurityRoot">Security root</see> object - again, 
    /// once - for example to change their types to the types required for 
    /// your application).
    /// </para>
    /// <para>
    /// Also you can update some properties of system objects in this event 
    /// handler (if this is necessary).
    /// </para>
    /// <para>
    /// Note that <see cref="Domain"/> will create default system 
    /// objects (the minimal system object set mentioned upper) before invoking
    /// this event handler. These objects will be created only if there is
    /// no existing objects with corresponding types (i.e. <see cref="User"/>, 
    /// <see cref="Role"/> or their descendants) and
    /// <see cref="SystemObjectNames">names</see> found.
    /// </para>
    /// <note type="note">You should apply all necessary permissions to 
    /// the system objects if you decided to create them manually.</note>
    /// <note type="note">Invoke <see cref="SystemObjects.InvalidateCachedSystemObjects"/>
    /// in this event handler after some security objects were added 
    /// or removed - to obtain correct <see cref="SystemObjects"/>' property 
    /// values further.</note>
    /// <note type="note">This event handler operates with <see cref="Session"/>
    /// having <see cref="DataObjects.NET.SessionSecurityOptions.Minimal"/>
    /// <see cref="Session.SecurityOptions"/>. Further this <see cref="Session"/> 
    /// will be used by the <see cref="RuntimeServicePool"/> object to 
    /// run the <see cref="RuntimeService"/>s.
    /// </note>
    /// </remarks>
    public event SessionEventHandler InitializeSystemObjects {
      add {
        if (status!=DomainStatus.Created && status!=DomainStatus.Error)
          throw new InvalidOperationException("Attempt to change event handler in the Domain with already called Build method.");
        initializeSystemObjects += value;
      }
      remove {
        if (status!=DomainStatus.Created && status!=DomainStatus.Error)
          throw new InvalidOperationException("Attempt to change event handler in the Domain with already called Build method.");
        initializeSystemObjects -= value;
      }
    }
    private void OnInitializeSystemObjects(object sender, SessionEventArgs e)
    {
      if (initializeSystemObjects!=null)
        initializeSystemObjects(sender, e);
    }
    private SessionEventHandler initializeSystemObjects;

    /// <summary>
    /// Occurs before completion of the <see cref="Build"/> method.
    /// This event is raised after <see cref="InitializeSystemObjects"/> event.
    /// <seealso cref="Build"/>
    /// <seealso cref="InitializeSystemObjects"/>
    /// </summary>
    /// <remarks>
    /// <para>
    /// Use this event handler to initialize (create or update) some of 
    /// persistent objects stored in the <see cref="Domain"/>.
    /// </para>
    /// <note type="note">This event handler operates with <see cref="Session"/>
    /// having <see cref="DataObjects.NET.SessionSecurityOptions.Minimal"/>
    /// <see cref="Session.SecurityOptions"/>. Further this <see cref="Session"/> 
    /// will be used by the <see cref="RuntimeServicePool"/> object to 
    /// run the <see cref="RuntimeService"/>s.
    /// </note>
    /// </remarks>
    public event SessionEventHandler Initialize {
      add {
        if (status!=DomainStatus.Created && status!=DomainStatus.Error)
          throw new InvalidOperationException("Attempt to change event handler in the Domain with already called Build method.");
        initialize += value;
      }
      remove {
        if (status!=DomainStatus.Created && status!=DomainStatus.Error)
          throw new InvalidOperationException("Attempt to change event handler in the Domain with already called Build method.");
        initialize -= value;
      }
    }
    private void OnInitialize(object sender, SessionEventArgs e)
    {
      if (initialize!=null)
        initialize(sender, e);
    }
    private SessionEventHandler initialize;

    /// <summary>
    /// Occurs on <see cref="Session"/> instance creation.
    /// <seealso cref="CreateSession"/>
    /// <seealso cref="Session"/>
    /// </summary>
    /// <remarks>
    /// <para>
    /// This event isn't raised before finishing the <see cref="Domain"/>
    /// initialization process (completion of <see cref="Build"/> method
    /// execution).
    /// </para>
    /// </remarks>
    public event SessionEventHandler SessionCreated {
      add {
        if (status!=DomainStatus.Created && status!=DomainStatus.Error)
          throw new InvalidOperationException("Attempt to change event handler in the Domain with already called Build method.");
        sessionCreated += value;
      }
      remove {
        if (status!=DomainStatus.Created && status!=DomainStatus.Error)
          throw new InvalidOperationException("Attempt to change event handler in the Domain with already called Build method.");
        sessionCreated -= value;
      }
    }
    internal void OnSessionCreated(object sender, SessionEventArgs e)
    {
      if (sessionCreated!=null && status==DomainStatus.Ready)
        sessionCreated(sender, e);
    }
    private SessionEventHandler sessionCreated;

    /// <summary>
    /// Occurs before user authentication in the <see cref="Session"/>.
    /// <seealso cref="UserAuthenticated"/>
    /// <seealso cref="UserAuthenticationFailed"/>
    /// <seealso cref="Session.Authenticate"/>
    /// <seealso cref="CreateSession"/>
    /// <seealso cref="Session"/>
    /// </summary>
    /// <remarks>
    /// <para>
    /// This event isn't raised before finishing the <see cref="Domain"/>
    /// initialization process (completion of <see cref="Build"/> method
    /// execution).
    /// </para>
    /// </remarks>
    public event AuthenticationEventHandler UserAuthenticate {
      add {
        if (status!=DomainStatus.Created && status!=DomainStatus.Error)
          throw new InvalidOperationException("Attempt to change event handler in the Domain with already called Build method.");
        userAuthenticate += value;
      }
      remove {
        if (status!=DomainStatus.Created && status!=DomainStatus.Error)
          throw new InvalidOperationException("Attempt to change event handler in the Domain with already called Build method.");
        userAuthenticate -= value;
      }
    }
    internal void OnUserAuthenticate(object sender, AuthenticationEventArgs e)
    {
      if (userAuthenticate!=null && status==DomainStatus.Ready)
        userAuthenticate(sender, e);
    }
    private AuthenticationEventHandler userAuthenticate;

    /// <summary>
    /// Occurs when successful user authentication in the <see cref="Session"/> 
    /// takes place.
    /// <seealso cref="UserAuthenticate"/>
    /// <seealso cref="UserAuthenticationFailed"/>
    /// <seealso cref="Session.Authenticate"/>
    /// <seealso cref="CreateSession"/>
    /// <seealso cref="Session"/>
    /// </summary>
    /// <remarks>
    /// <para>
    /// This event isn't raised before finishing the <see cref="Domain"/>
    /// initialization process (completion of <see cref="Build"/> method
    /// execution).
    /// </para>
    /// </remarks>
    public event AuthenticationEventHandler UserAuthenticated {
      add {
        if (status!=DomainStatus.Created && status!=DomainStatus.Error)
          throw new InvalidOperationException("Attempt to change event handler in the Domain with already called Build method.");
        userAuthenticated += value;
      }
      remove {
        if (status!=DomainStatus.Created && status!=DomainStatus.Error)
          throw new InvalidOperationException("Attempt to change event handler in the Domain with already called Build method.");
        userAuthenticated -= value;
      }
    }
    internal void OnUserAuthenticated(object sender, AuthenticationEventArgs e)
    {
      if (userAuthenticated!=null && status==DomainStatus.Ready)
        userAuthenticated(sender, e);
    }
    private AuthenticationEventHandler userAuthenticated;

    /// <summary>
    /// Occurs when unsuccessful user authentication in the <see cref="Session"/> 
    /// takes place.
    /// <seealso cref="UserAuthenticate"/>
    /// <seealso cref="UserAuthenticated"/>
    /// <seealso cref="Session.Authenticate"/>
    /// <seealso cref="CreateSession"/>
    /// <seealso cref="Session"/>
    /// </summary>
    /// <remarks>
    /// <para>
    /// This event isn't raised before finishing the <see cref="Domain"/>
    /// initialization process (completion of <see cref="Build"/> method
    /// execution).
    /// </para>
    /// </remarks>
    public event AuthenticationEventHandler UserAuthenticationFailed {
      add {
        if (status!=DomainStatus.Created && status!=DomainStatus.Error)
          throw new InvalidOperationException("Attempt to change event handler in the Domain with already called Build method.");
        userAuthenticationFailed += value;
      }
      remove {
        if (status!=DomainStatus.Created && status!=DomainStatus.Error)
          throw new InvalidOperationException("Attempt to change event handler in the Domain with already called Build method.");
        userAuthenticationFailed -= value;
      }
    }
    internal void OnUserAuthenticationFailed(object sender, AuthenticationEventArgs e)
    {
      if (userAuthenticationFailed!=null && status==DomainStatus.Ready)
        userAuthenticationFailed(sender, e);
    }
    private AuthenticationEventHandler userAuthenticationFailed;

    /// <summary>
    /// Occurs before changing active <see cref="Session.User"/> 
    /// in the <see cref="Session"/>.
    /// <seealso cref="Session.User"/>
    /// <seealso cref="Session.Authenticate"/>
    /// <seealso cref="CreateSession"/>
    /// <seealso cref="Session"/>
    /// </summary>
    /// <remarks>
    /// <para>
    /// The <see cref="UserEventArgs.User">e.User</see> property contains
    /// new <see cref="Session.User">e.Session.User</see> value 
    /// (so <see cref="Session.User">e.Session.User</see> contains old one).
    /// </para>
    /// <para>
    /// This event isn't raised before finishing the <see cref="Domain"/>
    /// initialization process (completion of <see cref="Build"/> method
    /// execution).
    /// </para>
    /// </remarks>
    public event UserEventHandler UserChange {
      add {
        if (status!=DomainStatus.Created && status!=DomainStatus.Error)
          throw new InvalidOperationException("Attempt to change event handler in the Domain with already called Build method.");
        userChange += value;
      }
      remove {
        if (status!=DomainStatus.Created && status!=DomainStatus.Error)
          throw new InvalidOperationException("Attempt to change event handler in the Domain with already called Build method.");
        userChange -= value;
      }
    }
    internal void OnUserChange(object sender, UserEventArgs e)
    {
      if (userChange!=null && status==DomainStatus.Ready)
        userChange(sender, e);
    }
    private UserEventHandler userChange;

    /// <summary>
    /// Occurs on successful change of <see cref="Session.User">Session.User</see>
    /// property value.
    /// <seealso cref="Session.User"/>
    /// <seealso cref="Session.Authenticate"/>
    /// <seealso cref="CreateSession"/>
    /// <seealso cref="Session"/>
    /// </summary>
    /// <remarks>
    /// <para>
    /// This event isn't raised before finishing the <see cref="Domain"/>
    /// initialization process (completion of <see cref="Build"/> method
    /// execution).
    /// </para>
    /// </remarks>
    public event UserEventHandler UserChanged {
      add {
        if (status!=DomainStatus.Created && status!=DomainStatus.Error)
          throw new InvalidOperationException("Attempt to change event handler in the Domain with already called Build method.");
        userChanged += value;
      }
      remove {
        if (status!=DomainStatus.Created && status!=DomainStatus.Error)
          throw new InvalidOperationException("Attempt to change event handler in the Domain with already called Build method.");
        userChanged -= value;
      }
    }
    internal void OnUserChanged(object sender, UserEventArgs e)
    {
      if (userChanged!=null && status==DomainStatus.Ready)
        userChanged(sender, e);
    }
    private UserEventHandler userChanged;

      private long lastID = -1;

      public long LastID
      {
          get { return lastID; }
          set { lastID = value; }
      }
  }
}
