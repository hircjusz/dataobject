// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using DataObjects.NET;

namespace DataObjects.NET.Data
{
  /// <summary>
  /// Represents a method that will handle the 
  /// <see cref="Adapter.VersionConflict"/> events.
  /// </summary>
  /// <param name="sender">The source of the event.</param>
  /// <param name="e">A <see cref="VersionConflictEventArgs"/> that contains the event data.</param>
  /// <remarks>
  /// This event is raised when <see cref="Adapter"/> detects version conflict.
  /// </remarks>
  public delegate void VersionConflictEventHandler(object sender, VersionConflictEventArgs e);
}
