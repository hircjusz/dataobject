// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Data;
using DataObjects.NET;
using DataObjects.NET.Data;

namespace DataObjects.NET.Data
{
  /// <summary>
  /// Provides information for <see cref="Adapter.CreateObject"/> event.
  /// </summary>
  public class CreateObjectEventArgs: EventArgs
  {
    private DataObject dataObject;
    private ObjectModel.Type type;
    private DataRow[] rows;
    private bool update;
    private bool delay;
    
    /// <summary>
    /// Gets or sets <see cref="DataObject"/> instance.
    /// </summary>
    public DataObject DataObject {
      get {
        return dataObject;
      }
      set {
        dataObject = value;
      }
    }
    
    /// <summary>
    /// Gets or sets <see cref="ObjectModel.Type"/> of the <see cref="DataObject"/>.
    /// </summary>
    public ObjectModel.Type SuggestedType {
      get {
        return type;
      }
      set {
        type = value;
      }
    }
    
    /// <summary>
    /// Gets an <see cref="Array"/> of <see cref="DataRow"/>s that contain data
    /// for the <see cref="DataObject"/>.
    /// </summary>
    public DataRow[] Rows {
      get {
        return rows;
      }
    }
    
    /// <summary>
    /// Gets or sets a value indicating whether <see cref="Adapter"/> should
    /// register newly created <see cref="DataObject"/> instance for update or not.
    /// </summary>
    public bool Update {
      get {
        return update;
      }
      set {
        update = value;
      }
    }
    
    /// <summary>
    /// Gets or sets a value indicating whether <see cref="Adapter"/> should
    /// delay creation of a <see cref="DataObject"/> instance.
    /// If <see cref="CreateObjectEventArgs.Delay"/> is <see langword="true"/>
    /// <see cref="Adapter"/> doesn't create an object but enqueues it's ID in
    /// <see cref="Adapter.UpdateQueue"/> for creation.
    /// </summary>
    /// <remarks>
    /// The value of this property is ignored by <see cref="Adapter"/> if
    /// <see cref="CreateObjectEventArgs.DataObject"/> is not null or
    /// <see cref="CreateObjectEventArgs.SuggestedType"/>. is null.
    /// </remarks>
    public bool Delay {
      get {
        return delay;
      }
      set {
        delay = value;
      }
    }
    
    /// <summary>
    /// Initializes a new instance of the <see cref="CreateObjectEventArgs"/> class.
    /// </summary>
    /// <param name="type">Suggested <see cref="ObjectModel.Type"/>.</param>
    /// <param name="rows">Rows, that contain data for the <see cref="DataObject"/> 
    /// that will be created.</param>
    /// <param name="update">Suggested <see cref="Adapter"/> behaviour. <see cref="Update"/>.</param>
    /// <param name="delay">Suggested <see cref="Adapter"/> behaviour. <see cref="Delay"/>.</param>
    internal CreateObjectEventArgs(ObjectModel.Type type, DataRow[] rows, bool update, bool delay)
    {
      if (type==null)
        throw new ArgumentNullException("type");
      if (rows==null)
        throw new ArgumentNullException("rows");
        
      this.type = type;
      this.rows = rows;
      this.update = update;
      this.delay = delay;
    }
    
    /// <summary>
    /// Initializes a new instance of the <see cref="CreateObjectEventArgs"/> class.
    /// </summary>
    /// <param name="type">Suggested <see cref="ObjectModel.Type"/>.</param>
    /// <param name="rows">Rows, that contains data for the <see cref="DataObject"/> 
    /// that will be created.</param>
    internal CreateObjectEventArgs(ObjectModel.Type type, DataRow[] rows): this(type, rows, true, false)
    {
    }
  }
}
