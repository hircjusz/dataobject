// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;

namespace DataObjects.NET.Attributes
{
  /// <summary>
  /// Indicates that property is collatable. This means that set of columns 
  /// with different collations (one per each culture) will be created in 
  /// the database to keep the value of single string to allow use different
  /// sorting rules for this property.
  /// </summary>
  /// <remarks>
  /// <note>This attribute can be applied to persistent properties
  /// of <see cref="String"/> type.</note>
  /// This attribute is a <see cref="DriverTypeSpecificAttribute">driver type-specific</see>,
  /// that means that it can be applied multiple times (with different parameters). 
  /// Each its application can be used or not - dependently on the current type 
  /// of the database driver. 
  /// See <see cref="DriverTypeSpecificAttribute.DriverTypes"/> property
  /// for further information.
  /// <para>
  /// <example>Example:
  /// <code lang="C#">
  ///  public abstract class Node: DataObject
  ///  {
  ///    [Length(128)]
  ///    [Collatable] // !!!
  ///    public abstract string Name {get; set;}
  ///    
  ///    ...
  ///  }
  /// </code>
  /// </example>
  /// </para>
  /// <seealso cref="TranslatableAttribute"/>
  /// </remarks>
  [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field, 
    AllowMultiple = true, Inherited = true)]
  [Serializable]
  public class CollatableAttribute: DriverTypeSpecificAttribute
  {
    private bool collatable = true;
    /// <summary>
    /// <see langword="True"/> if field value should have single collation.
    /// </summary>
    public  bool Collatable 
    {
      get {return collatable;}
      set {collatable = value;}
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    public CollatableAttribute() 
    {
    }
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="collatable"><see langword="True"/> if field value should have single collation.</param>
    public CollatableAttribute(bool collatable) 
    {
      this.collatable = collatable;
    }
  }
}
