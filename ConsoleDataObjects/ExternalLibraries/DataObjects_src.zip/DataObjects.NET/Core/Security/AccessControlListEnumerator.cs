// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Attributes;

namespace DataObjects.NET.Security
{
  /// <summary>
  /// Enumerator for <see cref="AccessControlList"/>.
  /// </summary>
  #if (!NoMBR)
  public class AccessControlListEnumerator : MarshalByRefObject, 
  #else
  public class AccessControlListEnumerator : Object, 
  #endif
    IEnumerator 
  {
    private AccessControlList baseCollection;
    private IEnumerator       baseEnumerator;
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="baseCollection">Base collection.</param>
    /// <param name="baseEnumerator">Base enumerator.</param>
    internal AccessControlListEnumerator(AccessControlList baseCollection, IEnumerator baseEnumerator) 
    {
      this.baseCollection = baseCollection;
      this.baseEnumerator = baseEnumerator;
    }
    
    /// <summary>
    /// Gets the current element in the collection.
    /// </summary>
    public object Current {
      get {
        long id = (long)baseEnumerator.Current;
        return baseCollection.owner.session[id];
      }
    }

    /// <summary>
    /// Advances the enumerator to the next element of the collection.
    /// </summary>
    /// <returns><see><see langword="true"/></see> if the enumerator was successfully 
    /// advanced to the next element; <see><see langword="false"/></see> if the enumerator 
    /// has passed the end of the collection.</returns>
    public bool MoveNext() {
      return baseEnumerator.MoveNext();
    }
    
    /// <summary>
    /// Sets the enumerator to its initial position, which is before the first element in the collection.
    /// </summary>
    public void Reset() {
      baseEnumerator.Reset();
    }
  }
}
