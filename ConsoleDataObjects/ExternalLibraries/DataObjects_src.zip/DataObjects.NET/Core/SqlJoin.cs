// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Text;
using DataObjects.NET;
using DataObjects.NET.ObjectModel;

namespace DataObjects.NET
{
  /// <summary>
  /// Represents single SQL join clause.
  /// The objects of this type are immutable - they can't be changed 
  /// after construction.
  /// <seealso cref="Query"/>
  /// <seealso cref="SqlQuery"/>
  /// <seealso cref="SqlJoinCollection"/>
  /// </summary>
  #if (!NoMBR)
  public sealed class SqlJoin: MarshalByRefObject, ICloneable
  #else
  public sealed class SqlJoin: ICloneable
  #endif
  {
    internal SqlJoinType joinType = SqlJoinType.Inner;
    /// <summary>
    /// Gets the type of join clause.
    /// </summary>
    public SqlJoinType JoinType {
      get {
        return joinType;
      }
    }

    internal string tableName = "";
    /// <summary>
    /// Gets the name of the table to join.
    /// </summary>
    public string TableName {
      get {
        return tableName;
      }
    }

    internal string alias = "";
    /// <summary>
    /// Gets the name of the join alias.
    /// </summary>
    public string Alias {
      get {
        return alias;
      }
    }

    internal string condition = "";
    /// <summary>
    /// Gets the join condition.
    /// </summary>
    public string Condition {
      get {
        return condition;
      }
    }

    /// <summary>
    /// Creates a copy of the <see cref="SqlJoin"/> object.
    /// </summary>
    /// <returns>Copy of the <see cref="SqlJoin"/> object.</returns>
    public SqlJoin Clone()
    {
      return new SqlJoin(joinType, tableName, alias, condition);
    }

    /// <summary>
    /// Creates a copy of the <see cref="SqlJoin"/> object.
    /// </summary>
    /// <returns>Copy of the <see cref="SqlJoin"/> object.</returns>
    object ICloneable.Clone()
    {
      return new SqlJoin(joinType, tableName, alias, condition);
    }


    // Constructors

    /// <summary>
    /// Initialize a new instance of the class.
    /// </summary>
    internal SqlJoin()
    {
    }

    /// <summary>
    /// Initialize a new instance of the class.
    /// </summary>
    /// <param name="joinType">Type of join.</param>
    /// <param name="tableName">The name of the table to join.</param>
    /// <param name="alias">The name of the join alias.</param>
    /// <param name="condition">Join condition.</param>
    public SqlJoin(SqlJoinType joinType, string tableName, string alias, string condition)
    {
      this.joinType  = joinType;
      this.tableName = tableName;
      this.alias     = alias;
      this.condition = condition;
    }
  }
}
