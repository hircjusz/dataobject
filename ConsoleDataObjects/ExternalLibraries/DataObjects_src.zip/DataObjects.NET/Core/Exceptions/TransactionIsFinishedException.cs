// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Runtime.Serialization;

namespace DataObjects.NET.Exceptions
{
  /// <summary>
  /// Thrown by <see cref="Transaction.Commit"/>\<see cref="Transaction.Rollback"/> 
  /// methods on attempt to commit or rollback the transaction that was already
  /// finished.
  /// <seealso cref="Session"/>
  /// <seealso cref="Transaction"/>
  /// <seealso cref="Savepoint"/>
  /// </summary>
  [Serializable]
  public class TransactionIsFinishedException: DataObjectsDotNetException
  {
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="innerException">Inner exception.</param>
    public TransactionIsFinishedException(Exception innerException): this("Transaction is already finished.",innerException) 
    {
    }
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="text">Text of message.</param>
    /// <param name="innerException">Inner exception.</param>
    public TransactionIsFinishedException(string text, Exception innerException): base(text,innerException) 
    {
    }
    
    /// <summary>
    /// Deserialization constructor.
    /// </summary>
    /// <param name="info"><see cref="SerializationInfo"/> object.</param>
    /// <param name="context"><see cref="StreamingContext"/> object.</param>
    protected TransactionIsFinishedException(SerializationInfo info, StreamingContext context):
      base(info, context)
    {
    }
  }
}
