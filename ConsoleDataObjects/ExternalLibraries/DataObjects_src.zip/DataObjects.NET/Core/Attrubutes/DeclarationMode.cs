// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;

namespace DataObjects.NET.Attributes
{
  /// <summary>
  /// Specifies <see cref="DataObjects.NET.DeclarationMode"/> for the class.
  /// <seealso cref="PersistentAttribute"/>
  /// <seealso cref="NotPersistentAttribute"/>
  /// </summary>
  /// <remarks>
  /// <note>This attribute can be applied to persistent types
  /// (<see cref="DataObject"/> descendants). 
  /// You can't apply this attribute to struct types.</note>
  /// <para>
  /// <example>Example:
  /// <code lang="C#">
  ///  [DeclarationMode(DeclarationMode.NonPersistentByDefault)] // !!!
  ///  public abstract class Animal: DataObject 
  ///  {
  ///    ...
  ///  
  ///    [Persistent] // !!!
  ///    [Indexed]
  ///    public abstract int Age {get; set;}
  ///  }
  /// </code>
  /// </example>
  /// </para>
  /// <seealso cref="PersistentAttribute"/>
  /// <seealso cref="NotPersistentAttribute"/>
  /// </remarks>
  [AttributeUsage(AttributeTargets.Class, 
    AllowMultiple = false, Inherited = false)]
  [Serializable]
  public class DeclarationModeAttribute: DataObjectAttribute
  {
    private DeclarationMode declarationMode = DeclarationMode.Default;
    /// <summary>
    /// Specifies <see cref="DataObjects.NET.DeclarationMode"/> for the class.
    /// </summary>
    public  DeclarationMode DeclarationMode 
    {
      get {return declarationMode ;}
      set {declarationMode  = value;}
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    public DeclarationModeAttribute() 
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="declarationMode">Declaration mode.</param>
    public DeclarationModeAttribute(DeclarationMode declarationMode) 
    {
      this.declarationMode = declarationMode;
    }
  }
}
