// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Runtime.Serialization;
using DataObjects.NET.Attributes;
using Offline=DataObjects.NET.Offline;

namespace DataObjects.NET.Exceptions
{
  /// <summary>
  /// Thrown on attempt to remove an object having
  /// reference with <see cref="AutoFixupAction.Block">AutoFixupAction.Block</see>
  /// option pointing to it.
  /// See <see cref="AutoFixupAttribute"/>.
  /// </summary>
  [Serializable]
  public class ReferentialIntegrityException: DataObjectsDotNetException
  {
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    public ReferentialIntegrityException(): base("Referential integrity violation.") {}
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="text">Text of message.</param>
    public ReferentialIntegrityException(string text): base(text) {}

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    public ReferentialIntegrityException(DataObject o): 
      this(String.Format("Referential integrity violation on attempt to remove {0}, ID={1}.",o.GetType().BaseType.FullName,o.ID)) {}
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    public ReferentialIntegrityException(Offline.DataObject o): 
      this(String.Format("Referential integrity violation on attempt to remove {0}, ID={1}.",o.GetType().BaseType.FullName,o.ID)) {}

    /// <summary>
    /// Deserialization constructor.
    /// </summary>
    /// <param name="info"><see cref="SerializationInfo"/> object.</param>
    /// <param name="context"><see cref="StreamingContext"/> object.</param>
    protected ReferentialIntegrityException(SerializationInfo info, StreamingContext context):
      base(info, context)
    {
    }
  }
}
