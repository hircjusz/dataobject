// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using DataObjects.NET;
using DataObjects.NET.Attributes;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Security.Permissions;

namespace DataObjects.NET.Security
{
  /// <summary>
  /// Desribes a single permission entry in the 
  /// <see cref="FlatPermissionEntryCollection"/>.
  /// <seealso cref="AccessControlList.GetFlatPermissions"/>
  /// <seealso cref="FlatPermissionEntryCollection"/>
  /// <seealso cref="IPermission"/>
  /// <seealso cref="Principal"/>
  /// <seealso cref="AccessControlList"/>
  /// </summary>
  /// <remarks>
  /// <para>
  /// This type is useful for GUI representation of object's permission
  /// inheritance hierarchy.
  /// See <see cref="AccessControlList.GetFlatPermissions">AccessControlList.GetFlatPermissions</see>
  /// for additional information.
  /// </para>
  /// <para>
  /// You can find more information about the whole DataObjects.NET
  /// security system <see cref="AccessControlList">here</see>.
  /// </para>
  /// </remarks>
  #if (!NoMBR)
  public class FlatPermissionEntry : MarshalByRefObject
  #else
  public class FlatPermissionEntry : Object
  #endif
  {
    private IPermission m_permission;
    private DataObject  m_owner;
    private Principal   m_principal;
    private bool        m_isAllowed;
    
    /// <summary>
    /// Gets <see cref="IPermission">permission</see> described 
    /// by this entry.
    /// </summary>
    public IPermission Permission {
      get {
        return m_permission;
      }
    }

    /// <summary>
    /// Gets <see cref="DataObject"/> instance to which a 
    /// <see cref="Permission"/> described by this entry was applied.
    /// </summary>
    public DataObject Owner {
      get {
        return m_owner;
      }
    }
    
    /// <summary>
    /// Gets <see cref="Principal"/> instance for which a
    /// <see cref="Permission"/> described by this entry was applied.
    /// </summary>
    public Principal Principal {
      get {
        return m_principal;
      }
    }
    
    /// <summary>
    /// Indicates whether <see cref="Permission"/> is allowed or denied. 
    /// </summary>
    public bool IsAllowed {
      get {
        return m_isAllowed;
      }
    }
    

    // Constructors
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="permission"><see cref="Permission"/> this entry should describe.</param>
    /// <param name="owner"><see cref="DataObject"/> instance to which a 
    /// <see cref="Permission"/> described by this entry was applied.</param>
    /// <param name="principal"><see cref="Principal"/> instance for which a
    /// <see cref="Permission"/> described by this entry was applied.</param>
    /// <param name="isAllowed">Indicates whether <see cref="Permission"/> is allowed or denied.</param>
    internal FlatPermissionEntry(IPermission permission, DataObject owner, Principal principal, bool isAllowed)
    {
      m_permission = permission;
      m_owner      = owner;
      m_principal  = principal;
      m_isAllowed  = isAllowed;    
    }
  }
}
