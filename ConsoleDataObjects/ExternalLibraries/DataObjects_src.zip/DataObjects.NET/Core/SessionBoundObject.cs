// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.IO;
using System.Text;
using System.Threading;
using System.Collections;
using System.Collections.Specialized;
using System.Data;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Attributes;
using DataObjects.NET.Security;
using DataObjects.NET.Security.Permissions;

namespace DataObjects.NET
{
  /// <summary>
  /// Base class for all objects that are bound to the <see cref="Session"/>
  /// instance.
  /// </summary>
  #if (!NoMBR)
  public abstract class SessionBoundObject: MarshalByRefObject,
  #else
  public abstract class SessionBoundObject: Object,
  #endif
    ISessionBoundObject
  {
    internal Session session;

    // Session-related methods

    /// <summary>
    /// Gets <see cref="DataObjects.NET.Session"/> to which current instance is bound.
    /// </summary>
    public Session Session {
      get {return session;}
    }
    
    /// <summary>
    /// Gets <see cref="DataObjects.NET.Domain"/> to which current instance is bound.
    /// </summary>
    public Domain Domain {
      get {return session.domain;}
    }

    // Security

    /// <summary>
    /// Temporarily disables security system. All permission 
    /// <see cref="DataObject.Demand"/>s will be successful and
    /// <see cref="DataObjects.NET.Session.SecurityOptions">Session.SecurityOptions</see>
    /// will be unchecked till the <see cref="EnableSecurity"/> call.
    /// <seealso cref="EnableSecurity"/>
    /// <seealso cref="DataObjects.NET.Session.IsSecurityEnabled"/>
    /// <seealso cref="DataObjects.NET.Security"/>
    /// <seealso cref="DataObjects.NET.Security.Permissions"/>
    /// </summary>
    /// <remarks>
    /// <para>
    /// Use this method to temporarily disable DataObjects.NET security 
    /// system. This method is <see langword="protected"/>, so it can be 
    /// called only from your business objects' code (<see cref="DataObject"/>s 
    /// or <see cref="DataService"/>s).
    /// </para>
    /// <para>
    /// When it's necessary to temporarily disable the security system?
    /// </para>
    /// <para>
    /// 1) When it's required to perform some operation, that normally demands 
    ///    high permissions. Example of such operation can be reading of 
    ///    <see cref="User"/> password during the authentication - 
    ///    normally no one can access this field, but it's required to read it
    ///    to authenticate the user.
    /// </para>
    /// <para>
    /// 2) When it's necessary to speed-up execution of a code block, that
    ///    can demand a lot of permissions. Example: you're decided to traverse
    ///    a set of objects, e.g. to perform some computational operation.
    ///    So you can try to evaluate maximal required permissions before such
    ///    an operation, demand all these permissions (or simply demand the 
    ///    <see cref="AdministrationPermission"/>), disable security system,
    ///    perform required operation and enable security system back.
    ///    This can be much more efficient, because you're made only one
    ///    permission demand "in the beginning", rather then demanding
    ///    multiple permissions (e.g. 1000 permission demands can occur easily -
    ///    almost any property access operation demands some permissions) 
    ///    during the operation. 
    ///    So this situation is similar to using 
    ///    <see cref="System.Security.CodeAccessPermission.Assert"/>
    ///    method with the <see cref="System.Security.CodeAccessPermission"/>s 
    ///    in the .NET Framework.
    /// </para>
    /// <para>
    /// As you may understood, all permission <see cref="DataObject.Demand"/>s 
    /// (and <see cref="DataObject.IsAllowed"/> checks) are successful when 
    /// the security system is disabled
    /// (in the <see cref="DataObjects.NET.Session"/> scope).
    /// </para>
    /// <note type="note">Use <see langword="try-finally"/> construction to
    /// enable the security system back safely.
    /// </note>
    /// <note type="note">You should call <see cref="EnableSecurity"/> the
    /// same number of times as <see cref="DisableSecurity"/> to really
    /// enable it.
    /// </note>
    /// <example>Example:
    /// <code lang="C#">
    ///   DisableSecurity();
    ///   try {
    ///     ... // Some full-trust operations
    ///   }
    ///   finally {
    ///     EnableSecurity();
    ///   }
    /// </code>
    /// </example>
    /// </remarks>
    [Transactional(TransactionMode.Disabled)]
    protected internal void DisableSecurity()
    {
      session.InternalDisableSecurity();
    }

    /// <summary>
    /// Enables DataObjects.NET security system after it was temporarily 
    /// disabled by the <see cref="DisableSecurity"/> method call. 
    /// <seealso cref="DisableSecurity"/>
    /// <seealso cref="DataObjects.NET.Session.IsSecurityEnabled"/>
    /// <seealso cref="DataObjects.NET.Security"/>
    /// <seealso cref="DataObjects.NET.Security.Permissions"/>
    /// </summary>
    /// <remarks>
    /// <para>
    /// Use this method to enable DataObjects.NET security system after
    /// it was temporarily disabled by the <see cref="DisableSecurity"/>
    /// method call. This method is <see langword="protected"/>, so it can be 
    /// called only from your business objects' code (<see cref="DataObject"/>s 
    /// or <see cref="DataService"/>s).
    /// </para>
    /// <para>
    /// When it's necessary to temporarily disable the security system?
    /// </para>
    /// <para>
    /// 1) When it's required to perform some operation, that normally demands 
    ///    high permissions. Example of such operation can be reading of 
    ///    <see cref="User"/> password during the authentication - 
    ///    normally no one can access this field, but it's required to read it
    ///    to authenticate the user.
    /// </para>
    /// <para>
    /// 2) When it's necessary to speed-up execution of a code block, that
    ///    can demand a lot of permissions. Example: you're decided to traverse
    ///    a set of objects, e.g. to perform some computational operation.
    ///    So you can try to evaluate maximal required permissions before such
    ///    an operation, demand all these permissions (or simply demand the 
    ///    <see cref="AdministrationPermission"/>), disable security system,
    ///    perform required operation and enable security system back.
    ///    This can be much more efficient, because you're made only one
    ///    permission demand "in the beginning", rather then demanding
    ///    multiple permissions (e.g. 1000 permission demands can occur easily -
    ///    almost any property access operation demands some permissions) 
    ///    during the operation. 
    ///    So this situation is similar to using 
    ///    <see cref="System.Security.CodeAccessPermission.Assert"/>
    ///    method with the <see cref="System.Security.CodeAccessPermission"/>s 
    ///    in the .NET Framework.
    /// </para>
    /// <para>
    /// As you may understood, all permission <see cref="DataObject.Demand"/>s 
    /// (and <see cref="DataObject.IsAllowed"/> checks) are successful when 
    /// the security system is disabled 
    /// (in the <see cref="DataObjects.NET.Session"/> scope).
    /// </para>
    /// <note type="note">Use <see langword="try-finally"/> construction to
    /// enable the security system back safely.
    /// </note>
    /// <note type="note">You should call <see cref="EnableSecurity"/> the
    /// same number of times as <see cref="DisableSecurity"/> to really
    /// enable it.
    /// </note>
    /// <example>Example:
    /// <code lang="C#">
    ///   DisableSecurity();
    ///   try {
    ///     ... // Some full-trust operations
    ///   }
    ///   finally {
    ///     EnableSecurity();
    ///   }
    /// </code>
    /// </example>
    /// </remarks>
    [Transactional(TransactionMode.Disabled)]
    protected internal void EnableSecurity()
    {
      session.InternalEnableSecurity();
    }


    /// <summary>
    /// Provides more convenient way of invoking <see cref="EnableSecurity"/> and 
    /// <see cref="DisableSecurity"/> methods by using the <see cref="IDisposable"/> pattern.
    /// </summary>
    /// <returns>An <see cref="IDisposable"/> descendant that enables and disables security automatically.</returns>
    /// <remarks>
    /// <para>
    /// <example>This example:
    /// <code lang="C#">
    ///   using (CreateSecurityDisabler())
    ///     ... // Some full-trust operations
    ///   }
    /// </code>
    /// is a shorter equivalent of:
    /// <code lang="C#">
    ///   DisableSecurity();
    ///   try {
    ///     ... // Some full-trust operations
    ///   }
    ///   finally {
    ///     EnableSecurity();
    ///   }
    /// </code>
    /// </example>
    /// </para>
    /// </remarks>
    [Transactional(TransactionMode.Disabled)]
    protected internal IDisposable CreateSecurityDisabler()
    {
      return new SecurityDisabler(false,this);
    }
    
    /// <summary>
    /// Represents a method that is executed by
    /// <see cref="SessionBoundObject.ExecTrustedOperation"/>.
    /// </summary>
    public delegate void TrustedOperation();
    
    /// <summary>
    /// Provides more convenient way of invoking <see cref="EnableSecurity"/> and 
    /// <see cref="DisableSecurity"/> methods by using the <see cref="TrustedOperation"/> delegate.
    /// </summary>
    /// <param name="operation">Operation delegate.</param>
    /// <remarks>
    /// <para>
    /// <example>This example:
    /// <code lang="C#">
    ///   ExecTrustedOperation(operation);
    /// </code>
    /// is a shorter equivalent of:
    /// <code lang="C#">
    ///   DisableSecurity();
    ///   try {
    ///     operation();
    ///   }
    ///   finally {
    ///     EnableSecurity();
    ///   }
    /// </code>
    /// </example>
    /// </para>
    /// </remarks>
    [Transactional(TransactionMode.Disabled)]
    protected void ExecTrustedOperation(TrustedOperation operation)
    {
      if (operation==null)
        throw new ArgumentNullException("operation");
        
      DisableSecurity();
      try {
        operation();
      } 
      finally {
        EnableSecurity();
      }
    }
    
    // Constructors

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    internal SessionBoundObject()
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="session">Session, to which current instance should be bound.</param>
    internal SessionBoundObject(Session session)
    {
      if (session==null)
        throw new ArgumentNullException("session");
      this.session = session;
    }
  }
}
