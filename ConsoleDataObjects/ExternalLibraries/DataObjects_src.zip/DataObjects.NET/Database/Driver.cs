// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;
using System.Data;
using System.Diagnostics;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Attributes;
using DataObjects.NET.DatabaseModel;

namespace DataObjects.NET.Database
{
  /// <summary>
  /// Base class for any DataObjects.NET database driver.
  /// </summary>
  #if (!NoMBR)
  public abstract class Driver: MarshalByRefObject
  #else
  public abstract class Driver: Object
  #endif
  {
    /// <summary>
    /// Collection of currently loaded drivers.
    /// Any database driver should register itself in DataObjects.NET by
    /// executing by executing <c>RegisteredDrivers.Add(typeof(XXXDriver))</c>
    /// in its static constructor.
    /// </summary>
    protected internal static Hashtable RegisteredDrivers = new Hashtable();
    static Driver()
    {
    }
    
    private ConnectionInfo connectionInfo;
    /// <summary>
    /// Information about this connection.
    /// </summary>
    public  ConnectionInfo ConnectionInfo {
      get {return connectionInfo;}
    }

    private Domain domain;
    /// <summary>
    /// <see cref="Domain"/> to which this driver belongs.
    /// </summary>
    public  Domain Domain {
      get {return domain;}
    }
    
    private Info info;
    /// <summary>
    /// Provides access to apropriate <see cref="DataObjects.NET.Database.Info"/> 
    /// descendant instance allowing to determine driver (or RDBMS) capabilities and limitations.
    /// </summary>
    public Info Info 
    {
      get {return info;}
    }
    /// <summary>
    /// Allows to set <see cref="Info"/> property value for descendants of this class.
    /// </summary>
    protected void SetInfo(Info info)
    {
      this.info = info;
    }
    
    /// <summary>
    /// Driver type (E.g. "MSSQL", "SAPDB").
    /// Always returns <see cref="Database.Info.Type">Info.Type</see> value.
    /// </summary>
    public string Type { get {return Info.Type;} }

    private Version rdbmsVersion;

    /// <summary>
    /// Underlying RDBMS version.
    /// </summary>
    public Version RdbmsVersion {
      get {
        if (rdbmsVersion==null)
          DetectRdbmsVersion();
        return rdbmsVersion;
      }
    }

    /// <summary>
    /// Sets version of the underlying database.
    /// </summary>
    protected void SetRdbmsVersion (Version rdbmsVersion)
    {
      this.rdbmsVersion = rdbmsVersion;
    }
      
    /// <summary>
    /// Driver description.
    /// Always returns <see cref="Database.Info.Description">Info.Description</see> value.
    /// </summary>
    public string Description { get {return Info.Description;} }

    /// <summary>
    /// Driver company (developer).
    /// Always returns <see cref="Database.Info.Company">Info.Company</see> value.
    /// </summary>
    public string Company { get {return Info.Company;} }

    private Utils utils;
    /// <summary>
    /// Provides access to apropriate <see cref="DataObjects.NET.Database.Utils"/> 
    /// descendant instance helping to solve across-DBMS compatibility issues.
    /// </summary>
    public Utils Utils 
    {
      get {return utils;}
    }
    /// <summary>
    /// Allows to set <see cref="Utils"/> property value for descendants of this class.
    /// </summary>
    protected void SetUtils(Utils utils)
    {
      this.utils = utils;
    }
    
    /// <summary>
    /// Determines whether specified <see cref="SqlType"/> is supported by the driver.
    /// </summary>
    /// <param name="type"><see cref="SqlType"/> to check supporting for.</param>
    /// <returns><see langword="true"/> if the driver supports specified <see cref="SqlType"/>;
    /// otherwise <see langword="false"/>.</returns>
    public abstract bool SupportsSqlType (SqlType type);
    
    /// <summary>
    /// Creates a new instance of <see cref="SysInfoManager"/>.
    /// </summary>
    /// <param name="connection">Connection it should be bound to.</param>
    /// <param name="transaction">Transaction it should operate in.</param>
    /// <returns>New <see cref="SysInfoManager"/> instance.</returns>
    public abstract SysInfoManager CreateSysInfoManager(IDbConnection connection, IDbTransaction transaction);

    /// <summary>
    /// Creates a new instance of <see cref="Extractor"/>.
    /// </summary>
    /// <param name="connection">Connection it should be bound to.</param>
    /// <param name="transaction">Transaction it should operate in.</param>
    /// <returns>New <see cref="Extractor"/> instance.</returns>
    public abstract Extractor CreateExtractor(IDbConnection connection, IDbTransaction transaction);

    /// <summary>
    /// Creates a new instance of <see cref="Persister"/>.
    /// </summary>
    /// <returns>New <see cref="Persister"/> instance.</returns>
    public abstract Persister CreatePersister(Session session);

      public virtual PartitionSet CreatePartitionSet(string partitionType, string primaryKey)
      {
          return null;
      }
    
    private NamingManager namingManager;
    /// <summary>
    /// Provides access to apropriate <see cref="DataObjects.NET.Database.NamingManager"/> 
    /// descendant instance that handles table\view\column-names generation.
    /// </summary>
    public NamingManager NamingManager {
      get {return namingManager;}
    }
    /// <summary>
    /// Allows to set <see cref="NamingManager"/> property value for descendants of this class.
    /// </summary>
    protected void SetNamingManager(NamingManager namingManager)
    {
      this.namingManager = namingManager;
    }

    private UpdateActionTranslator updateActionTranslator;
    /// <summary>
    /// Provides access to apropriate <see cref="DataObjects.NET.Database.UpdateActionTranslator"/> 
    /// descendant instance that handles translation of <see cref="UpdateAction"/>s to SQL.
    /// </summary>
    public UpdateActionTranslator UpdateActionTranslator {
      get {
        if (updateActionTranslator==null)
          updateActionTranslator = CreateUpdateActionTranslator();
        return updateActionTranslator;
      }
    }
    
    /// <summary>
    /// Creates a new instance of <see cref="UpdateActionTranslator"/>.
    /// </summary>
    /// <returns>New <see cref="UpdateActionTranslator"/> instance.</returns>
    protected abstract UpdateActionTranslator CreateUpdateActionTranslator();
    
    /// <summary>
    /// Returns <see langword="true"/> if this database driver can handle specified
    /// <see cref="ConnectionInfo"/>. It checks <see cref="RegisteredDrivers"/>
    /// to do this.
    /// </summary>
    /// <returns><see langword="True"/> if this database driver can handle specified
    /// <see cref="ConnectionInfo"/>.</returns>
    public bool CanHandle()
    {
      if (connectionInfo!=null && 
          RegisteredDrivers[connectionInfo.Protocol]==this.GetType())
        return true;
      return false;
    }

    /// <summary>
    /// Creates new <see cref="IDbConnection"/> instance.
    /// </summary>
    /// <returns>Connection instance.</returns>
    public abstract IDbConnection CreateConnection();

    /// <summary>
    /// Creates new <see cref="IDbCommand"/> instance.
    /// </summary>
    /// <param name="connection">Connection to create a command for.</param>
    /// <returns>Command instance.</returns>
    public virtual IDbCommand CreateCommand(IDbConnection connection)
    {
      return connection.CreateCommand();
    }

    /// <summary>
    /// Configures <see cref="IDbConnection"/>.
    /// </summary>
    /// <param name="connection">Connection to configure.</param>
    public abstract void ConfigureConnection(IDbConnection connection);

    /// <summary>
    /// Creates, opens and configures new <see cref="IDbConnection"/> instance.
    /// </summary>
    /// <returns>Connection instance.</returns>
    public IDbConnection OpenConnection()
    {
      IDbConnection c = CreateConnection();
      c.Open();
      ConfigureConnection(c);
      return c;
    }
    
    /// <summary>
    /// Translates isolation level to one supported by the
    /// underlying RDBMS.
    /// </summary>
    /// <param name="isolationLevel">Isolation level to translate.</param>
    /// <returns>Supported isolation level.</returns>
    protected internal virtual IsolationLevel TranslateIsolationLevel(IsolationLevel isolationLevel)
    {
      return isolationLevel;
    }

    public void RebuildDatabase()
    {
        RebuildAllTables();
        RebuildAllIndexes();
    }

    public void RebuildAllTables()
    {
        foreach (Domain domain in Domain.AvailableDomains)
        {
                foreach (Table table in domain.DatabaseModel.Tables)
                {
                    RebuildTable(table);
                }
        }
    }

    public void RebuildAllIndexes()
    {
        foreach (Domain domain in Domain.AvailableDomains)
        {
                foreach (Table table in domain.DatabaseModel.Tables)
                {
                    foreach (Index index in table.Indexes)
                    {
                        RebuildIndex(index);
                    }
                }
        }
    }


    public void RebuildTableWithIndexes(Table table)
    {
            RebuildTable(table);
            foreach (Index index in table.Indexes)
                RebuildIndex(index);
    }

    protected virtual void DoRebuildTable(Table table)
    {
    }

    protected virtual void DoRebuildIndex(string indexName)
    {
    }

    public void RebuildTable(Table table)
    {
        try
        {
            table.Database.Domain.IsRebuild = true;
            DoRebuildTable(table);
        }
        finally
        {
            table.Database.Domain.IsRebuild = false;
        }
    }

    public void RebuildIndex(Index index)
    {
        try
        {
            index.Table.Database.Domain.IsRebuild = true;
            DoRebuildIndex(index.Name);
        }
        finally
        {
            index.Table.Database.Domain.IsRebuild = false;
        }
    }

    /// <summary>
    /// Detects version of the underlying database.
    /// </summary>
    public abstract void DetectRdbmsVersion ();

    // Constructor

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="connectionInfo">Information about default connection.</param>
    /// <param name="domain"><see cref="Domain"/>, to which this driver belongs.</param>
    public Driver(ConnectionInfo connectionInfo, Domain domain): base()
    {
      if (connectionInfo==null)
        throw new DatabaseDriverException("ConnectionInfo is null.");
      
      this.connectionInfo = connectionInfo;
      this.domain         = domain;
    }
  }
}
