// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.IO;
using System.Text;
using System.Threading;
using System.Collections;
using System.Collections.Specialized;
using System.Data;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Attributes;

namespace DataObjects.NET
{
  /// <summary>
  /// Interface for all objects that are bound to the <see cref="Session"/>
  /// instance.
  /// </summary>
  public interface ISessionBoundObject
  {
    /// <summary>
    /// Gets <see cref="DataObjects.NET.Session"/> to which current instance is bound.
    /// </summary>
    Session Session {get;}

    /// <summary>
    /// Gets the <see cref="DataObjects.NET.Domain"/> to which this instance is bound.
    /// </summary>
    Domain Domain {get;}
  }
}
