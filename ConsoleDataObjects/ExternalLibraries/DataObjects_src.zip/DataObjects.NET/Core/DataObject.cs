// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.ComponentModel;
using System.IO;
using System.Text;
using System.Threading;
using System.Collections;
using System.Collections.Specialized;
using System.Data;
using System.Reflection;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.EnterpriseServices;
using DataObjects.NET.Attributes;
using DataObjects.NET.Caching;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Database;
using DataObjects.NET.Remoting;
using DataObjects.NET.ObjectModel;
using DataObjects.NET.DatabaseModel;
using DataObjects.NET.Offline;
using DataObjects.NET.Serialization;
using DataObjects.NET.FullText;
using DataObjects.NET.Security;
using DataObjects.NET.Security.Permissions;
using DataObjects.NET.Versionizing;
using Type = System.Type;

namespace DataObjects.NET
{
  /// <summary>
  /// Base class of any persistent object.
  /// <see langword="Persistent, Abstract"/>.
  /// </summary>
  /// <remarks>
  /// <para>
  /// Instances of this class can exist only within the <see cref="Session"/>.
  /// Every <see cref="DataObjects.NET.DataObject"/> instance has unique <see cref="ID"/> 
  /// in the database (<see cref="Domain"/>) scope.</para>
  /// <para>Different <see cref="DataObjects.NET.Session"/> instances associated with the same <see cref="Domain"/>
  /// can contain different <see cref="DataObjects.NET.DataObject"/> instances with the same <see cref="ID"/>.
  /// </para>
  /// <para>
  /// DataObjects.NET 2.0 introduces extremally powerful and extendable
  /// security system. <see cref="AccessControlList">Here</see> you can find 
  /// more information about it.
  /// </para>
  /// <seealso cref="DataObjects.NET.DataService"/>
  /// <seealso cref="DataObjects.NET.Domain"/>
  /// <seealso cref="DataObjects.NET.Session"/>
  /// <seealso cref="DataObjects.NET.Transaction"/>
  /// <seealso cref="DataObjects.NET.Query"/>
  /// <seealso cref="DataObjects.NET.SqlQuery"/>
  /// <seealso cref="Principal"/>
  /// <seealso cref="Permission"/>
  /// <seealso cref="PermissionSet"/>
  /// </remarks>
  [Abstract]
  [Serializable]
  [DeclarationMode(DeclarationMode.NotPersistentByDefault)]
  [TypeReference(typeof(IsolationLevel))] // Reference to System.Data assembly
  [TypeReference(typeof(ITransaction))]   // Reference to System.EnterpriseServices assembly
  //[IndexAttribute("IX_2", "ID, VersionID", Unique=true, Clustered=true)]
  //[IndexAttribute("IX_3", "ID, TypeID, VersionID", Unique=true, Clustered=true)]
  public abstract class DataObject: TransactionalObject, 
    IDataObject, ISecureObject,
    IDeserializationCallback,
    IConvertibleToOffline
  {


      internal class LazyInfo
      {
          public DataObjectCollection pcN;
          public DataObjectCollection pcO;
      }

    /// <summary>
    /// Holds information about property value location in properties array.
    /// </summary>
    /// 
    internal struct PropertyLocationInfo {
      public int      FieldIndex;
      public string   FieldName;
      public string   PartName;
      public string   ValueInBraces;
      public Field    Field;
      public int      CultureIndex;
      public int      CultureCount;
      public Culture  Culture;
      
      public string FieldNameWithCultureName {
        get { 
          if (Culture==null)
            return FieldName;
          else
            return FieldName + '-' + Culture.Name;
        }
      }

      public PropertyLocationInfo(params object[] args) {
        FieldIndex = 0;
        FieldName = null;
        PartName = null;
        ValueInBraces = null;
        Field = null;
        CultureIndex = 0;
        CultureCount = 0;
        Culture = null;
      }
    }

    internal const int cSysPropertiesCount = 5;
  
    /// <summary>
    /// Gets the ID (key) of the instance. ID is unique in the database (<see cref="Domain"/>) scope.
    /// </summary>
    [Persistent]
    [PropertyType(typeof(KeyField))]
    public long ID {
      get {
        return ((long)(this.GetProperty("ID", null)));
      }
    }
    
    /// <summary>
    /// Gets the instance's type ID. This field allows to determine the <see cref="System.Type"/> of the instance.
    /// </summary>
    [Persistent]
    [Indexed]
    public int TypeID {
      get {
        return ((int)(this.GetProperty("TypeID", null)));
      }
    }
    
    /// <summary>
    /// Gets the instance's version ID. This property is used for optimistic locking.
    /// </summary>
    [Persistent]
    [NotSerializable]
    public int VersionID {
      get {
        return ((int)(this.GetProperty("VersionID", null)));
      }
    }
    
    /// <summary>
    /// Gets the instance's <see cref="AccessControlList"/>.
    /// </summary>
    /// <remarks>
    /// <para>
    /// You can find more information about the whole DataObjects.NET
    /// security system <see cref="AccessControlList">here</see>.
    /// </para>
    /// </remarks>
    [Persistent]
    [Nullable]
    public AccessControlList Permissions {
      get {
        return (AccessControlList)(this.GetProperty("Permissions", null));
      }
    }

    /// <summary>
    /// Gets the instance's <see cref="AccessControlList"/>.
    /// This protected member returns this list without invoking
    /// <see cref="GetProperty"/> method, so it allows to get
    /// this list for any descendant.
    /// </summary>
    /// <remarks>
    /// <para>
    /// You can find more information about the whole DataObjects.NET
    /// security system <see cref="AccessControlList">here</see>.
    /// </para>
    /// </remarks>
    [NotPersistent]
    [Transactional(TransactionMode.Disabled)]
    protected AccessControlList ProtectedPermissions {
      get {
        return permissions;
      }
    }

    /// <summary>
    /// Holds serialized version of non-<see cref="LoadOnDemandAttribute">LoadOnDemand</see>
    /// object fields.
    /// This property is used to instantiate the object faster 
    /// (see "Fast fetches" description in the DataObjects.NET Manual).
    /// </summary>
    [Persistent]
    [Nullable]
    [NotSerializable]
    private byte[] FastLoadData {
      get {
        if (Assembly.GetCallingAssembly()!=session.doAssembly)
          throw new SecurityException(
            String.Format("Property \"{0}\" isn't accessible.","FastLoadData"));
        return ((byte[])(this.GetProperty("FastLoadData", null)));
      }
    }
    /// <summary>
    /// Holds serialized version of non-<see cref="LoadOnDemandAttribute">LoadOnDemand</see>
    /// object fields.
    /// This property is used to instantiate the object faster 
    /// (see "Fast fetches" description in the DataObjects.NET Manual).
    /// </summary>
    [NotPersistent]
    [Transactional(TransactionMode.Disabled)]
    byte[] IDataObject.FastLoadData {
      get {
        throw new SecurityException(
          String.Format("Property \"{0}\" isn't accessible.","FastLoadData"));
      }
    }
    
    // Private fields

    private const int IsCreatingMask = 1;
    private const int IsChangingMask = 2;
    private const int IsChangedMask  = 4;
    
    internal ObjectModel.Type   type;
    internal DataObjectState    state = DataObjectState.New;
    internal TransactionContext transactionContext;
    internal AccessControlList  permissions;
    private  DataObjectProperties properties;    
    internal BitVector32  stateFlags = new BitVector32(0);
    internal short        delayUpdateDepth;
    internal short        persistDepth;
    private  LockType     lastLockType = LockType.None;
    internal Helpers.EventSource permissionsChangedEventSource;
    private  EventHandler        permissionsChangedCallbackEventHandler;
    internal DataObjectValidationInfo    useableValidationInfo;
    internal DataObjectSerializationInfo serializationInfo;
   
    private bool canNotifyDependencyParent = true;
    private bool isDependencyChildChanged = false;

    private ArrayList lazyCollections;

    
    /// <summary>
    /// Locates ptoperty in DataObjectProperties.
    /// </summary>
    /// <param name="name">Property name.</param>
    /// <param name="culture">Property Culture.</param>
    /// <returns>Property location information.</returns>
    internal PropertyLocationInfo LocateProperty(string name, Culture culture) {
      PropertyLocationInfo pl = new PropertyLocationInfo();
      if (State==DataObjectState.Removed)
        throw new InstanceIsRemovedException();
      
      // TODO: refactor to use LocateProperty
      pl.FieldName = name;
      pl.ValueInBraces = null;
      pl.PartName = null;
      int dot = name.IndexOf('.');
      if (dot >= 0) {
        pl.FieldName = name.Substring(0, dot);
        pl.PartName = name.Substring(dot + 1);
      }

      int openBraceIndex = pl.FieldName.IndexOf('[');
      if (pl.FieldName.EndsWith("]") && (openBraceIndex>0)) {
        pl.ValueInBraces = pl.FieldName.Substring(openBraceIndex+1,pl.FieldName.Length-openBraceIndex-2);
        pl.FieldName = pl.FieldName.Substring(0, openBraceIndex);
      }

      int dashIndex = pl.FieldName.IndexOf('-');
      if (dashIndex>0) {
        if (culture != null)
          throw new InvalidOperationException(
            String.Format("You should specify culture only once."));
        string cultureName = pl.FieldName.Substring(dashIndex + 1);
        pl.FieldName = pl.FieldName.Substring(0, dashIndex);
        culture = Domain.Cultures[cultureName];
        if (culture==null)
          throw new InvalidOperationException(
            String.Format("Cannot find culture \"{0}\".",cultureName));
      }

      pl.Field = Type.Fields[pl.FieldName];
      if (pl.Field==null)
        throw new InvalidOperationException(
          String.Format("Unknown property: \"{0}\".", pl.FieldName));
          
      pl.FieldIndex = pl.Field.Index;
      if (!pl.Field.Translatable) {
        if (culture!=null)
          throw new InvalidOperationException(
            String.Format("Property \"{0}\" isn't translatable.", pl.FieldName));
      }
      else {
        pl.Culture      = (culture==null ? Session.Culture : culture);
        pl.CultureIndex = pl.Culture.Index;
      }

      pl.CultureCount = Domain.Cultures.Count;
      
      return pl;
    }
    
    // Getters and setters
        
    internal DataObjectProperties Properties {
      get {return properties;}
    }

    internal long GetInternalID()
    {
      return (long)properties.GetValue(0,0,1);
    }

    internal int GetInternalTypeID()
    {
      return (int)properties.GetValue(1,0,session.domain.cultures.Count);
    }

    internal int GetInternalVersionID()
    {
      return (int)properties.GetValue(2,0,session.domain.cultures.Count);
    }

    /// <summary>
    /// Gets object version code.
    /// Version code is a string identifying
    /// "UI version" of the current instance.
    /// <seealso cref="CompareVersionCode"/>
    /// <seealso cref="VersionID"/>
    /// </summary>
    /// <remarks>
    /// <para>
    /// Usually lots of types can be modified 
    /// by user (manually) and by some automatic 
    /// services, such as full-text indexer.
    /// Since both update types change <see cref="VersionID"/>
    /// property, it's impossible to use its value
    /// for detecting the "UI changes" (changes
    /// made to the same object by different persons - 
    /// e.g. to implement an optimistic locking
    /// behavior in the web application.
    /// </para>
    /// <para>
    /// <see cref="VersionCode"/> property provides a common
    /// way of doing this - by default any <see cref="DataObject"/>
    /// instance returns its <see cref="VersionID"/> value from
    /// this property, but you can override this behavior in your 
    /// own persistent types. E.g. you can return a value of your own
    /// <see langword="ModifyDate"/> property, that isn't changed
    /// by any service-made updates, and thus allows to detect the
    /// UI-made updates better (i.e. to separate both types of updates).
    /// </para>
    /// </remarks>
    [NotPersistent]
    public virtual string VersionCode {
      get {
        return VersionID.ToString();
      }
    }
    
    /// <summary>
    /// Return <see langword="true"/> if specified 
    /// <paramref name="versionCode"/> corresponds to the
    /// active "UI state" of instance;
    /// otherwise, <see langword="false"/>.
    /// See <see cref="VersionCode"/> property description for
    /// additional information.
    /// <seealso cref="VersionCode"/>
    /// <seealso cref="VersionID"/>
    /// </summary>
    /// <param name="versionCode">Version code to check.</param>
    /// <returns><see langword="True"/> if specified 
    /// <paramref name="versionCode"/> corresponds to the
    /// active "UI state" of instance;
    /// otherwise, <see langword="false"/>.</returns>
    /// <remarks>
    /// By default any <see cref="DataObject"/> instance returns 
    /// <see langword="true"/>, if specified <paramref name="versionCode"/>
    /// equals to its <see cref="VersionID"/>; otherwise it returns
    /// <see langword="false"/>.
    /// </remarks>
    public virtual bool CompareVersionCode(string versionCode)
    {
      return VersionID.ToString()==versionCode;
    }

    /// <summary>
    /// Gets or sets any persistent property of the instance by its name.
    /// <seealso cref="OnGetProperty"/>
    /// <seealso cref="OnSetProperty"/>
    /// <seealso cref="OnPropertyChanged"/>
    /// </summary>
    [NotPersistent]
    [Transactional(TransactionMode.Disabled)]
    public object this[string propertyName] {
      get {return GetProperty(propertyName,null);}
      set {SetProperty(propertyName,null,value);}
    }
    
    /// <summary>
    /// Gets or sets any persistent property of the instance by its name and culture.
    /// <seealso cref="OnGetProperty"/>
    /// <seealso cref="OnSetProperty"/>
    /// <seealso cref="OnPropertyChanged"/>
    /// </summary>
    [NotPersistent]
    [Transactional(TransactionMode.Disabled)]
    public object this[string propertyName, Culture culture] {
      get {return GetProperty(propertyName,culture);}
      set {SetProperty(propertyName,culture,value);}
    }
    
    /// <summary>
    /// Gets any persistent property of the instance by its name.
    /// <seealso cref="OnGetProperty"/>
    /// </summary>
    /// <param name="name">Property name.</param>
    /// <returns>Property value.</returns>
    [Transactional(TransactionMode.Disabled)]
    public object GetProperty(string name)
    {
      return GetProperty(name,null);
    }
    
    /// <summary>
    /// Gets any persistent property of the instance by its name and culture.
    /// <seealso cref="OnGetProperty"/>
    /// </summary>
    /// <param name="name">Property name.</param>
    /// <param name="culture">Property culture.</param>
    /// <returns>Property value.</returns>
    [Transactional(TransactionMode.Disabled)]
    public object GetProperty(string name, Culture culture)
    {
      return GetProperty(name, culture, false);
    }

    /// <summary>
    /// Gets any persistent property of the instance by its name and culture.
    /// Allows to get internal property value.
    /// <seealso cref="OnGetProperty"/>
    /// </summary>
    /// <param name="name">Property name.</param>
    /// <param name="culture">Property culture.</param>
    /// <param name="getInternalValue"><see langword="True"/>, if internal value is needed;
    /// otherwise, <see langword="false"/>.</param>
    /// <returns>Property value.</returns>
    [NotOverridable]
    [Transactional(TransactionMode.TransactionRequired | TransactionMode.SupportsOfflineMode)]
    internal protected virtual object GetProperty(string name, Culture culture, bool getInternalValue)
    {
      Culture originalCulture = culture;
      if (State==DataObjectState.Removed)
        throw new InstanceIsRemovedException();
      
      // TODO: refactor to use LocateProperty
      string fieldName = name;
      string valueInBraces = null;
      string partName = null;
      int dot = name.IndexOf('.');
      if (dot >= 0) {
        fieldName = name.Substring(0, dot);
        partName = name.Substring(dot + 1);
      }
      
      int openBraceIndex = fieldName.IndexOf('[');
      if (fieldName.EndsWith("]") && (openBraceIndex>0)) {
        valueInBraces = fieldName.Substring(openBraceIndex+1,fieldName.Length-openBraceIndex-2);
        fieldName = fieldName.Substring(0, openBraceIndex);
      }

      int dashIndex = fieldName.IndexOf('-');
      if (dashIndex>0) {
        if (culture != null)
          throw new InvalidOperationException(
            String.Format("You should specify culture only once."));
        string cultureName = fieldName.Substring(dashIndex + 1);
        fieldName = fieldName.Substring(0, dashIndex);
        culture = session.Domain.Cultures[cultureName];
        if (culture==null)
          throw new InvalidOperationException(
            String.Format("Cannot find culture \"{0}\".",cultureName));
      }

      Field f = type.Fields[fieldName];
      if (f==null)
        throw new InvalidOperationException(
          String.Format("Unknown property: \"{0}\".", fieldName));

    if (f.IsNonPersisted)
        return null;
//            return f.CreateDefaultInternalValue(this.Domain.Cultures.DefaultCulture, this);    
      int n1 = f.Index;
      int n2 = 0;
      if (!f.Translatable) {
        culture = null;
        //        if (culture!=null)
        //          throw new InvalidOperationException(
        //            String.Format("Property \"{0}\" isn't translatable.", fieldName));
        
      }
      else {
        if (culture==null)
          culture = session.culture;
        else if (culture.Domain!=session.domain)
          throw new InvalidOperationException("Culture should be registered in the domain.");
        n2 = culture.Index;
      }

      int cCnt = session.domain.cultures.Count;
      if (!properties.GetIsLoaded(n1,n2,cCnt)) 
      { 
        if (session.transaction==null &&
            session.IsOfflineMode)
        {
          DataObjects.NET.TransactionController transactionController = new DataObjects.NET.TransactionController(this.Session,TransactionMode.TransactionRequired, ((System.Data.IsolationLevel)(-1)));
          Reprocess:
          // Reprocessing point
          try {
            object result = this.GetProperty(name, originalCulture, getInternalValue);
            transactionController.Commit();
            return result;
          }
          catch (System.Exception e) {
            if (transactionController.Rollback(e, true)) {
              goto Reprocess;
            }
            throw;
          }
        }
        else {
          LoadProperty(f, culture);
        }
      }
      
      // System properties access?
      if (n1<cSysPropertiesCount) {
        // We should persist the instance if it's an attempt to read
        // any system property except TypeID and Permissions
        if (n1!=1 && n1!=3 && state==DataObjectState.New) 
          Persist();
        // FastLoadData properties access check
        if (n1==4)
          if (Assembly.GetCallingAssembly()!=session.doAssembly)
            throw new SecurityException(
              String.Format("Property \"{0}\" isn't accessible.",fieldName));
      }

      object fullValue = f.ConvertInternalToValue(this, culture, properties.GetValue(n1,n2,cCnt));
      if (fullValue!=null && !(f.SourceType.IsInstanceOfType(fullValue)))
        throw new InvalidCastException(
          String.Format("Value of property \"{0}\" should be of \"{1}\" type.", fieldName, f.SourceType.FullName));

      if (fullValue == null && ((partName != null) || (valueInBraces != null))) {
        throw new NullReferenceException(
          String.Format("\"{0}\" is null => {1} is not accessible.", fieldName, name));
      }

      object pValue = null;
      if ((partName!=null) || (valueInBraces!=null))
        pValue = (f as ISupportsIndexingField).GetContainedFieldValue(this, originalCulture, properties.GetValue(n1,n2,cCnt), valueInBraces, partName);
      else
        pValue = fullValue;

      if (!getInternalValue && f.TypeModifier!=null) {
        pValue = f.TypeModifier.ConvertFromInternalValue(this, name, culture, pValue);
        if (pValue!=null && !(f.ExternalType.IsInstanceOfType(pValue)))
          throw new InvalidCastException(
            String.Format("External value of property \"{0}\" should be of \"{1}\" type.", fieldName, f.ExternalType.FullName));
      }
      
      if (n1>=cSysPropertiesCount || n1==3) {
        pValue = OnGetProperty(f.Name, culture, pValue);
        session.OnDataObjectGetProperty(this,f.Name, culture, pValue);
      }

      return pValue;
    }

    /// <summary>
    /// Gets any persistent property of the instance by its name and culture.
    /// Allows to get internal property value.
    /// <seealso cref="OnGetProperty"/>
    /// </summary>
    /// <param name="names">Property names.</param>
    /// <param name="culture">Property culture.</param>
    /// <returns>Property value.</returns>
 //SM begin

      [Transactional(TransactionMode.Disabled)]
      public virtual long GetPreloadedID()
      {
          return GetInternalID();
      }

      [Transactional(TransactionMode.Disabled)]
      public virtual long GetPreloadedVersionID()
      {
          return GetInternalVersionID();
      }

      private object GetSimpleProperty(string name, Culture culture, bool getInternalValue)
      {
          Culture originalCulture = culture;
          if (State == DataObjectState.Removed)
              throw new InstanceIsRemovedException();

          // TODO: refactor to use LocateProperty
          string fieldName = name;
          string valueInBraces = null;
          string partName = null;


          Field f = type.Fields[fieldName];
          if (f == null)
              throw new InvalidOperationException(
                String.Format("Unknown property: \"{0}\".", fieldName));

          int n1 = f.Index;
          int n2 = 0;
          if (!f.Translatable)
          {
              culture = null;
              //        if (culture!=null)
              //          throw new InvalidOperationException(
              //            String.Format("Property \"{0}\" isn't translatable.", fieldName));

          }
          else
          {
              if (culture == null)
                  culture = session.culture;
              else if (culture.Domain != session.domain)
                  throw new InvalidOperationException("Culture should be registered in the domain.");
              n2 = culture.Index;
          }

          int cCnt = session.domain.cultures.Count;
          if (!properties.GetIsLoaded(n1, n2, cCnt))
          {
              return GetProperty(name, culture, getInternalValue);
          }

          // System properties access?
          if (n1 < cSysPropertiesCount)
          {
              // We should persist the instance if it's an attempt to read
              // any system property except TypeID and Permissions
              if (n1 != 1 && n1 != 3 && state == DataObjectState.New)
                  Persist();
              // FastLoadData properties access check
              if (n1 == 4)
                  if (Assembly.GetCallingAssembly() != session.doAssembly)
                      throw new SecurityException(
                        String.Format("Property \"{0}\" isn't accessible.", fieldName));
          }

          object fullValue = f.ConvertInternalToValue(this, culture, properties.GetValue(n1, n2, cCnt));
          if (fullValue != null && !(f.SourceType.IsInstanceOfType(fullValue)))
              throw new InvalidCastException(
                String.Format("Value of property \"{0}\" should be of \"{1}\" type.", fieldName, f.SourceType.FullName));

          if (fullValue == null && ((partName != null) || (valueInBraces != null)))
          {
              throw new NullReferenceException(
                String.Format("\"{0}\" is null => {1} is not accessible.", fieldName, name));
          }

          object pValue = null;
          if ((partName != null) || (valueInBraces != null))
              pValue = (f as ISupportsIndexingField).GetContainedFieldValue(this, originalCulture, properties.GetValue(n1, n2, cCnt), valueInBraces, partName);
          else
              pValue = fullValue;

          if (!getInternalValue && f.TypeModifier != null)
          {
              pValue = f.TypeModifier.ConvertFromInternalValue(this, name, culture, pValue);
              if (pValue != null && !(f.ExternalType.IsInstanceOfType(pValue)))
                  throw new InvalidCastException(
                    String.Format("External value of property \"{0}\" should be of \"{1}\" type.", fieldName, f.ExternalType.FullName));
          }

          if (n1 >= cSysPropertiesCount || n1 == 3)
          {
              pValue = OnGetProperty(f.Name, culture, pValue);
          }

          return pValue;
      }

      public virtual object[] GetSimpleProperties(string[] names, Culture culture, int count)
      {
          object[] res = new object[count];
          for (int idx = 0; idx < count; idx++)
          {
             res[idx] = GetSimpleProperty(names[idx], culture, false);
          }
          return res;
      }
//SM end

    /// <summary>
    /// Gets an <see cref="Array"/> of <see cref="DataObject.ID"/>s stored in any property
    /// of reference\collection\struct type. 
    /// This method doesn't lead to <see cref="OnGetProperty"/> invocation, 
    /// and primarily intended for use in combination with 
    /// <see cref="Session.Preload"/>.
    /// <seealso cref="OnGetProperty"/>
    /// </summary>
    /// <param name="name">Property name.</param>
    /// <returns>An <see cref="Array"/> of <see cref="DataObject.ID"/>s stored in any property
    /// of reference\collection\struct type. May return <see langword="null"/>
    /// except zero-length <see cref="Array"/>.</returns>
    [Transactional(TransactionMode.Disabled)]
    internal protected long[] GetIDs(string name)
    {
      return GetIDs(name, null);
    }
    
    /// <summary>
    /// Gets an <see cref="Array"/> of <see cref="DataObject.ID"/>s stored in any property
    /// of reference\collection\struct type. 
    /// This method doesn't lead to <see cref="OnGetProperty"/> invocation, 
    /// and primarily intended for use in combination with 
    /// <see cref="Session.Preload"/>.
    /// <seealso cref="OnGetProperty"/>
    /// </summary>
    /// <param name="name">Property name.</param>
    /// <param name="culture">Property culture.</param>
    /// <returns>An <see cref="Array"/> of <see cref="DataObject.ID"/>s stored in any property
    /// of reference\collection\struct type. May return <see langword="null"/>
    /// except zero-length <see cref="Array"/>.</returns>
    [NotOverridable]
    [Transactional(TransactionMode.TransactionRequired | TransactionMode.SupportsOfflineMode)]
    internal protected virtual long[] GetIDs(string name, Culture culture)
    {
      if (State==DataObjectState.Removed)
        throw new InstanceIsRemovedException();
      
      string fieldName = name;
      int dot = name.IndexOf('.');
      if (dot >= 0)
        throw new InvalidOperationException(
          String.Format("Only root fields are allowed here, while \"{0}\" isn't a root field.", fieldName));

      Field f = type.Fields[fieldName];
      if (f==null)
        throw new InvalidOperationException(
          String.Format("Unknown property: \"{0}\".", fieldName));

      IReferenceHolderFieldInt rfi = f as IReferenceHolderFieldInt;
      if (rfi==null)
        throw new InvalidOperationException(
          String.Format("Property \"{0}\" can't contain references.", fieldName));

      if (f.IsNonPersisted)
            return null;
      int n1 = f.Index;
      int n2 = 0;
      if (!f.Translatable) {
        culture = null;
        //        if (culture!=null)
        //          throw new InvalidOperationException(
        //            String.Format("Property \"{0}\" isn't translatable.", fieldName));
        
      }
      else {
        if (culture==null)
          culture = session.culture;
        else if (culture.Domain!=session.domain)
          throw new InvalidOperationException("Culture should be registered in the domain.");
        n2 = culture.Index;
      }

      int cCnt = session.domain.cultures.Count;
      if (!properties.GetIsLoaded(n1,n2,cCnt)) 
      { 
        if (session.transaction==null &&
            session.IsOfflineMode)
        {
          DataObjects.NET.TransactionController transactionController = new DataObjects.NET.TransactionController(this.Session,TransactionMode.TransactionRequired, ((System.Data.IsolationLevel)(-1)));
          Reprocess:
          // Reprocessing point
          try {
            long[] result = this.GetIDs(name, culture);
            transactionController.Commit();
            return result;
          }
          catch (System.Exception e) {
            if (transactionController.Rollback(e, true)) {
              goto Reprocess;
            }
            throw;
          }
        }
        else {
          LoadProperty(f, culture);
        }
      }
      
      // System properties access?
      if (n1<cSysPropertiesCount) {
        // We should persist the instance if it's an attempt to read
        // any system property except TypeID and Permissions
        if (n1!=1 && n1!=3 && state==DataObjectState.New) 
          Persist();
        // FastLoadData properties access check
        if (n1==4)
          if (Assembly.GetCallingAssembly()!=session.doAssembly)
            throw new SecurityException(
              String.Format("Property \"{0}\" isn't accessible.",fieldName));
      }
      
      return rfi.GetIDs(this, culture, properties.GetValue(n1,n2,cCnt));
    }

    /// <summary>
    /// Gets an <see cref="Array"/> of <see cref="ContainedAttribute">[Contained]</see>
    /// <see cref="DataObject.ID"/>s stored in any property
    /// of reference\collection\struct type. 
    /// This method doesn't lead to <see cref="OnGetProperty"/> invocation, 
    /// and primarily intended for use in combination with 
    /// <see cref="Session.Preload"/>.
    /// <seealso cref="OnGetProperty"/>
    /// </summary>
    /// <param name="name">Property name.</param>
    /// <returns>An <see cref="Array"/> of <see cref="DataObject.ID"/>s stored in any property
    /// of reference\collection\struct type. May return <see langword="null"/>
    /// except zero-length <see cref="Array"/>.</returns>
    [Transactional(TransactionMode.Disabled)]
    internal protected long[] GetContainedIDs(string name)
    {
      return GetContainedIDs(name, null);
    }

    /// <summary>
    /// Gets an <see cref="Array"/> of <see cref="ContainedAttribute">[Contained]</see>
    /// <see cref="DataObject.ID"/>s stored in any property
    /// of reference\collection\struct type. 
    /// This method doesn't lead to <see cref="OnGetProperty"/> invocation, 
    /// and primarily intended for use in combination with 
    /// <see cref="Session.Preload"/>.
    /// <seealso cref="OnGetProperty"/>
    /// </summary>
    /// <param name="name">Property name.</param>
    /// <param name="culture">Property culture.</param>
    /// <returns>An <see cref="Array"/> of <see cref="DataObject.ID"/>s stored in any property
    /// of reference\collection\struct type. May return <see langword="null"/>
    /// except zero-length <see cref="Array"/>.</returns>
    [NotOverridable]
    [Transactional(TransactionMode.TransactionRequired | TransactionMode.SupportsOfflineMode)]
    internal protected virtual long[] GetContainedIDs(string name, Culture culture)
    {
      if (State==DataObjectState.Removed)
        throw new InstanceIsRemovedException();
      
      string fieldName = name;
      int dot = name.IndexOf('.');
      if (dot >= 0)
        throw new InvalidOperationException(
          String.Format("Only root fields are allowed here, while \"{0}\" isn't a root field.", fieldName));

      Field f = type.Fields[fieldName];
      if (f==null)
        throw new InvalidOperationException(
          String.Format("Unknown property: \"{0}\".", fieldName));

      IReferenceHolderFieldInt rfi = f as IReferenceHolderFieldInt;
      if (rfi==null)
        throw new InvalidOperationException(
          String.Format("Property \"{0}\" can't contain references.", fieldName));
          
      int n1 = f.Index;
      int n2 = 0;
      if (!f.Translatable) {
        culture = null;
        //        if (culture!=null)
        //          throw new InvalidOperationException(
        //            String.Format("Property \"{0}\" isn't translatable.", fieldName));
        
      }
      else {
        if (culture==null)
          culture = session.culture;
        else if (culture.Domain!=session.domain)
          throw new InvalidOperationException("Culture should be registered in the domain.");
        n2 = culture.Index;
      }

      int cCnt = session.domain.cultures.Count;
      if (!properties.GetIsLoaded(n1,n2,cCnt)) 
      { 
        if (session.transaction==null &&
            session.IsOfflineMode)
        {
          DataObjects.NET.TransactionController transactionController = new DataObjects.NET.TransactionController(this.Session,TransactionMode.TransactionRequired, ((System.Data.IsolationLevel)(-1)));
          Reprocess:
          // Reprocessing point
          try {
            long[] result = this.GetContainedIDs(name, culture);
            transactionController.Commit();
            return result;
          }
          catch (System.Exception e) {
            if (transactionController.Rollback(e, true)) {
              goto Reprocess;
            }
            throw;
          }
        }
        else {
          LoadProperty(f, culture);
        }
      }
      
      // System properties access?
      if (n1<cSysPropertiesCount) {
        // We should persist the instance if it's an attempt to read
        // any system property except TypeID and Permissions
        if (n1!=1 && n1!=3 && state==DataObjectState.New) 
          Persist();
        // FastLoadData properties access check
        if (n1==4)
          if (Assembly.GetCallingAssembly()!=session.doAssembly)
            throw new SecurityException(
              String.Format("Property \"{0}\" isn't accessible.",fieldName));
      }
      
      return rfi.GetContainedIDs(this, culture, properties.GetValue(n1,n2,cCnt));
    }

    /// <summary>
    /// Sets any persistent property of the instance by its name.
    /// <seealso cref="OnSetProperty"/>
    /// <seealso cref="OnPropertyChanged"/>
    /// </summary>
    /// <param name="name">Property name.</param>
    /// <param name="value">New property value.</param>
    [Transactional(TransactionMode.Disabled)]
    public void SetProperty(string name, object value)
    {
      SetProperty(name, null, value);
    }
    
    /// <summary>
    /// Sets any persistent property of the instance by its name and culture.
    /// <seealso cref="OnSetProperty"/>
    /// <seealso cref="OnPropertyChanged"/>
    /// </summary>
    /// <param name="name">Property name.</param>
    /// <param name="culture">Property culture.</param>
    /// <param name="value">New property value.</param>
    [Transactional(TransactionMode.Disabled)]
    public void SetProperty(string name, Culture culture, object value)
    {
      SetProperty(name, culture, value, false, false, false);
    }

    /// <summary>
    /// Sets any persistent property of the instance by its name.
    /// Allows to set internal property value.
    /// <seealso cref="OnSetProperty"/>
    /// <seealso cref="OnPropertyChanged"/>
    /// </summary>
    /// <param name="name">Property name.</param>
    /// <param name="culture">Property culture.</param>
    /// <param name="value">New property value.</param>
    /// <param name="ignoreCorrector"><see langword="True"/>, 
    /// if <see cref="IPropertyValueCorrector"/> should be ignored;
    /// otherwise, <see langword="false"/>.</param>
    /// <param name="ignoreValidators"><see langword="True"/>, 
    /// if all <see cref="IPropertyValueValidator"/>s should be ignored;
    /// otherwise, <see langword="false"/>.</param>
    /// <param name="setInternalValue"><see langword="True"/>, if internal value should be set
    /// (both corrector and validators are ignored in this case);
    /// otherwise, <see langword="false"/>.</param>
    [Transactional(TransactionMode.Disabled)]
    internal protected void SetProperty(string name, Culture culture, object value,
                                        bool ignoreCorrector, bool ignoreValidators, bool setInternalValue) 
    {
      SetProperty(name, culture, value,
                  ignoreCorrector, ignoreValidators, setInternalValue, false);
    }
    
    /// <summary>
    /// Sets any persistent property of the instance by its name.
    /// Allows to set internal property value.
    /// <seealso cref="OnSetProperty"/>
    /// <seealso cref="OnPropertyChanged"/>
    /// </summary>
    /// <param name="name">Property name.</param>
    /// <param name="culture">Property culture.</param>
    /// <param name="value">New property value.</param>
    /// <param name="ignoreCorrector"><see langword="True"/>, 
    /// if <see cref="IPropertyValueCorrector"/> should be ignored;
    /// otherwise, <see langword="false"/>.</param>
    /// <param name="ignoreValidators"><see langword="True"/>, 
    /// if all <see cref="IPropertyValueValidator"/>s should be ignored;
    /// otherwise, <see langword="false"/>.</param>
    /// <param name="setInternalValue"><see langword="True"/>, if internal value should be set
    /// (both corrector and validators are ignored in this case);
    /// otherwise, <see langword="false"/>.</param>
    /// <param name="ignorePair">
    /// <see langword="True"/>, if value should be set, but paired property should not be updated.
    /// Works only for <see cref="ReferenceField"/>s that have <see cref="PairToAttribute"/> set.
    /// </param>
    [NotOverridable]
    [BusinessMethod]
    [Transactional(TransactionMode.TransactionRequired, typeof(ValidationException))]
    internal protected virtual void SetProperty(string name, Culture culture, object value,
                                                bool ignoreCorrector, bool ignoreValidators, bool setInternalValue,
                                                bool ignorePair)
    {
      Culture originalCulture = culture;
      bool oldIsChanging = IsChanging;
      IsChanging = true;
      try {
        if (State==DataObjectState.Removed)
          throw new InstanceIsRemovedException();
      }
      finally {
        IsChanging = oldIsChanging;
      }

      // TODO: refactor to use LocateProperty
      string fieldName = name;
      string valueInBraces = null;
      string partName = null;
      int dotPosition = name.IndexOf('.');
      if (dotPosition >= 0) {
        fieldName = name.Substring(0, dotPosition);
        partName = name.Substring(dotPosition + 1);
      }

      int openBraceIndex = fieldName.IndexOf('[');
      if (fieldName.EndsWith("]") && (openBraceIndex>0)) {
        valueInBraces = fieldName.Substring(openBraceIndex+1,fieldName.Length-openBraceIndex-2);
        fieldName = fieldName.Substring(0, openBraceIndex);
      }

      int dashIndex = fieldName.IndexOf('-');
      if (dashIndex>0) {
        if (culture != null)
          throw new InvalidOperationException(
            String.Format("You should specify culture only once."));
        string cultureName = fieldName.Substring(dashIndex + 1);
        fieldName = fieldName.Substring(0, dashIndex);
        culture = session.Domain.Cultures[cultureName];
        if (culture==null)
          throw new InvalidOperationException(
            String.Format("Cannot find culture \"{0}\".",cultureName));
      }

      Field f = type.Fields[fieldName];
      if (f==null)
        throw new InvalidOperationException(
          String.Format("Unknown property: \"{0}\".", fieldName));

        if (f.IsNonPersisted)
            return;

      int n1 = f.Index;
      int n2 = 0;
      if (!f.Translatable) {
        culture = null;
        //        if (culture!=null)
        //          throw new InvalidOperationException(
        //            String.Format("Property \"{0}\" isn't translatable.", fieldName));
      }
      else {
        if (culture==null)
          culture = session.culture;
        else if (culture.Domain!=session.domain)
          throw new InvalidOperationException("Culture should be registered in the domain.");
        n2 = culture.Index;
      }
      
      // DataObject properties access check
      if (n1<cSysPropertiesCount)
        if (Assembly.GetCallingAssembly()!=session.doAssembly)
          throw new InvalidOperationException(
            String.Format("Property \"{0}\" is read-only.",fieldName));

      ReferenceField  rf = f as ReferenceField;
      StructField     sf = f as StructField;
      ISupportsIndexingField cf = f as ISupportsIndexingField;

      if (valueInBraces==null && partName==null) {
        // Check the type of the specified value
        if (value!=null && !f.ExternalType.IsInstanceOfType(value)) {
          try {
            value = Internals.TypeUtils.ConvertValueToType(value, f.ExternalType);
          }
          catch (InvalidCastException) {
            throw new InvalidCastException(String.Format("The specified value of the \"{0}\" property " +
                                                         "is not convertible to the \"{1}\" type.",
                                                         fieldName, f.ExternalType.FullName));
          }
        }
        if (!setInternalValue) {
          // Perform validations and conversions
          if (!ignoreCorrector && f.Corrector != null)
            value = f.Corrector.CorrectValue(this, name, culture, value);
          if (!ignoreValidators)
            f.Validators.Validate(this, name, culture, value);
          if (f.TypeModifier != null) {
            value = f.TypeModifier.ConvertToInternalValue(this, name, culture, value);
            // Check whether the result of a type modification has valid type.
            if (value!=null && !f.SourceType.IsInstanceOfType(value))
              throw new InvalidCastException(
                String.Format("The result of a TypeModifier execution on the \"{0}\" property " +
                              "is not an instance of the \"{1}\" type.",
                              fieldName, f.SourceType.FullName));
          }
        }

        // Check whether the null value is allowed.
        if (value==null && !f.Nullable && rf==null)
          throw new ArgumentException(string.Format(
            "Value of property \"{0}\" cannot be null.", fieldName), "value");
      }

      object setValue = value;
      object iValue = null;

      int cCnt = session.domain.cultures.Count;
      
      if (sf!=null) {
        EnsurePropertyLoaded(f, culture);
        iValue = (properties.GetValue(n1,n2,cCnt) as StructHolder).Clone();
        if (partName==null)
          sf.SetStructValue(this, culture, iValue, value, ignorePair, false);
        else {
          if (cf.CheckContainedValuesEquality(this,culture, iValue, value, valueInBraces, partName))
            return;
          cf.SetContainedFieldValue(this, culture, iValue, value, valueInBraces, partName, ignorePair, false);
        }
        setValue = f.ConvertInternalToValue(this, culture, iValue);
      }
      else {
        if ((partName!=null) || (valueInBraces!=null)) {
          if (cf==null)
            throw new InvalidOperationException(
              String.Format("Unknown property: \"{0}\".", name));
          else {
            cf.SetContainedFieldValue(this,originalCulture,properties.GetValue(n1,n2,cCnt), value, valueInBraces, partName, ignorePair, false);
            return;
          }
        }
        iValue = f.ConvertValueToInternal(this, culture, setValue);

        if (properties.GetIsLoaded(n1,n2,cCnt)) {
          object oValue = properties.GetValue(n1,n2,cCnt);
          if (f.CheckValuesEquality(iValue,oValue))
            return;
        }
      }

      if (serializationInfo==null) {
        OnSetProperty(f.Name, culture, setValue);
        session.OnDataObjectSetProperty(this,f.Name,culture,setValue);
      }


      // References support
      DataObjectCollection pcO = null;
      DataObjectCollection pcN = null;
      Field pfO = null;
      Field pfN = null;

      if (rf!=null) {
        DataObject newValue = (DataObject)setValue;
        if (value==this && !rf.SelfRefAllowed)
          throw new SelfReferenceException(this);
        DataObject oldValue = (DataObject)GetProperty(name, originalCulture);
        DataObject newValueValue = null;

        if (rf.PairTo != null) {
          if (!ignorePair) {
            if (oldValue!=null && oldValue.State!=DataObjectState.Removed) {
              DataObject oldObject = (DataObject)oldValue.GetProperty(rf.PairTo.AbsoluteName,culture);
              if (oldObject != null)
                oldObject.SetProperty(rf.Name,culture,null,ignoreCorrector,ignoreValidators,setInternalValue,true);
              oldValue.SetProperty(rf.PairTo.AbsoluteName,culture,null,ignoreCorrector,ignoreValidators,setInternalValue,true);
            }
            if (newValue!=null && newValue.State!=DataObjectState.Removed) {
              DataObject oldObject = (DataObject)newValue.GetProperty(rf.PairTo.AbsoluteName,culture);
              if (oldObject != null)
                oldObject.SetProperty(rf.Name,culture,null,ignoreCorrector,ignoreValidators,setInternalValue,true);
              newValue.SetProperty(rf.PairTo.AbsoluteName,culture,this,ignoreCorrector,ignoreValidators,setInternalValue,true);
            }
          }
        }
        else {
          if (oldValue!=null && oldValue.State!=DataObjectState.Removed) {
            if (rf.HasPair) {
              Field pf = oldValue.Type.GetPairTo(f);
              if (pf!=null) {
                  if (pf is DataObjectCollectionField) {
                      pcO = (DataObjectCollection)oldValue.GetProperty(pf.Name, culture);
                      if (pcO.Owner.State == DataObjectState.New)
                          pcO.Owner.Persist();
                      if (pcO.ItemType != null && pcO.ItemType.IsInstanceOfType(this)) {
                          if (!pcO.Contains(this))
                              throw new DataObjectsDotNetException(
                                "Internal error: required object wasn't found in paired collection.");
                          pcO.ContentChanging();
                          pcO.OnRemove(this);
                      }
                  }
                  else if (pf is ReferenceField)
                      pfO = pf;
                  else
                      throw new InvalidOperationException("Unsupported paired field type.");
              }
            }
            oldValue.OnDereferenceEx(this, f, culture);
            if ((pfO != null) && !ignorePair)
              oldValue.SetProperty(pfO.Name, culture,null,ignoreCorrector,ignoreValidators,setInternalValue,true);

          }
          if (newValue!=null && newValue.State!=DataObjectState.Removed) {
            if (rf.HasPair) {
              Field pf = newValue.Type.GetPairTo(f);
              if (pf!=null) {
                if (pf is DataObjectCollectionField) {
                  pcN = (DataObjectCollection)newValue.GetProperty(pf.Name, culture);
                  if (pcN.Owner.State==DataObjectState.New)
                    pcN.Owner.Persist();
                  pcN.ContentChanging();
                  pcN.OnAdd(this);
                }
                else if (pf is ReferenceField) {
                  pfN = pf;
                  newValueValue = (DataObject)newValue.GetProperty(pf.Name, culture);
                }
                else
                  throw new InvalidOperationException("Unsupported paired field type.");
              }
            }
            newValue.OnReferenceEx(this, f, culture);
            if ((pfN != null) && !ignorePair) {
              newValue.SetProperty(pfN.Name, culture, this, ignoreCorrector, ignoreValidators, setInternalValue, true);
              if (newValueValue != null)
                newValueValue.SetProperty(f.Name, culture, null, ignoreCorrector, ignoreValidators, setInternalValue, true);
            }
          }
        }
        properties.SetValue(n1,n2,cCnt,iValue);
        SetIsChanged(true);
        properties.SetIsLoaded(n1,n2,cCnt,true);
        properties.SetIsChanged(n1,n2,cCnt,true);
        if (rf.HasPair)
        {
            if (IsCreating) // SM
                TryPersist(); // SM
            else
                Persist();
        }
        else
            TryPersist();
        if (pcO!=null) {
          pcO.InnerRemovePairedObject(this);
          pcO.OnRemoveComplete(this);
        }
        //SM
        if (IsCreating && (pcN != null || pcO != null))
        {
            if (lazyCollections == null)
                lazyCollections = new ArrayList();
            LazyInfo li = new LazyInfo();
            li.pcN = pcN;
            li.pcO = pcO;
            lazyCollections.Add(li);
        }
        // SM
        else
        {
            if (pcN != null)
            {
                pcN.InnerAddPairedObject(this);
                pcN.OnAddComplete(this);
            }
            if (pcO != null)
                pcO.ContentChanged();
            if (pcN != null)
                pcN.ContentChanged();
        }
        if (serializationInfo==null) {
          OnPropertyChanged(name, culture, setValue);
          session.OnDataObjectPropertyChanged(this, name, culture, setValue);
        }
        return;
      }

      IDataObjectFieldValue fOld = properties.GetValue(n1,n2,cCnt) as IDataObjectFieldValue;
      if (fOld!=null)
        fOld.Detach();
      IDataObjectFieldValue fNew = setValue as IDataObjectFieldValue;
      if (fNew!=null)
        fNew.Attach(this, f, culture);
      properties.SetValue(n1,n2,cCnt,iValue);

      SetIsChanged(true);
      properties.SetIsLoaded(n1,n2,cCnt,true);
      properties.SetIsChanged(n1,n2,cCnt,true);
      TryPersist();

      if (serializationInfo==null) {
        OnPropertyChanged(f.Name, culture, setValue);
        session.OnDataObjectPropertyChanged(this, f.Name, culture, setValue);
      }
    }

    //    internal void InternalSetReferenceProperty(string name, Culture culture, object value)
    //    {
    //      if (State==DataObjectState.Removed)
    //        throw new InstanceIsRemovedException();
    //      
    //      Field f = type.Fields[name];
    //      if (f==null)
    //        throw new DataObjectsDotNetException("Internal error: incorrect DataObject.InternalSetReferenceProperty arguments.");
    //          
    //      int n1 = f.Index;
    //      int n2 = 0;
    //      if (!f.Translatable) {
    //        if (culture!=null)
    //          throw new DataObjectsDotNetException("Internal error: incorrect DataObject.InternalSetReferenceProperty arguments.");
    //      }
    //      else {
    //        if (culture==null)
    //          culture = session.culture;
    //        else if (culture.Domain!=session.domain)
    //          throw new DataObjectsDotNetException("Internal error: incorrect DataObject.InternalSetReferenceProperty arguments.");
    //        n2 = culture.Index;
    //      }
    //      
    //      if (!(f is ReferenceField))
    //        throw new DataObjectsDotNetException("Internal error: incorrect DataObject.InternalSetReferenceProperty arguments.");
    //
    //      properties.SetValue(n1,n2,f.ConvertValueToInternal(this, culture, value));
    //    }
    
    /// <summary>
    /// Increases the value of <see cref="VersionID"/> property of the
    /// instance and persists it.
    /// </summary>
    [NotOverridable]
    [Transactional(TransactionMode.TransactionRequired)]
    protected virtual void IncreaseVersion()
    {
      bool oldIsChanging = IsChanging;
      IsChanging = true;
      try {
        if (State==DataObjectState.Removed)
          throw new InstanceIsRemovedException();
      }
      finally {
        IsChanging = oldIsChanging;
      }

      if (State==DataObjectState.New || IsChanged)
        Persist();
      else {
        try {
          int  cCnt      = session.domain.cultures.Count;
          long id        = (long)properties.GetValue(0,0,cCnt);
          int  versionID = (int)properties.GetValue(2,0,cCnt);
          session.OnDataObjectUpdated(this);
          session.persister.UpdateInstanceVersion(session.GetBaseTable(this.Type), id, versionID, ++versionID);
          useableValidationInfo = null;
          properties.SetValue(2,0,cCnt,versionID);
        }
        catch (Exception e) {
          throw session.utils.SubstituteException(e);
        }
      }
    }

    /// <summary>
    /// This method should be called by <see cref="IDataObjectFieldValue"/> instance
    /// to notify the <see cref="IDataObjectFieldValue.Owner"/> that content of
    /// the field is going to be changed.
    /// <seealso cref="FieldContentChanged"/>
    /// <seealso cref="OnPropertyContentChanging"/>
    /// <seealso cref="OnPropertyContentChanged"/>
    /// </summary>
    /// <param name="field">Property value that notifies about its changing.</param>
    [NotOverridable]
    [Transactional(TransactionMode.ExistingTransactionRequired)]
    public virtual void FieldContentChanging(IDataObjectFieldValue field)
    {
      if (field==null)
        throw new ArgumentNullException("field");

      bool oldIsChanging = IsChanging;
      IsChanging = true;
      try {
        if (State==DataObjectState.Removed)
          throw new InstanceIsRemovedException();
      }
      finally {
        IsChanging = oldIsChanging;
      }

      int  cCnt       = session.domain.cultures.Count;
      Field   f       = field.Field;
      Culture culture = field.Culture;
      string  name    = f.Name;
          
      int n1 = f.Index;
      int n2 = 0;
      if (!f.Translatable) {
        culture = null;
        //        if (culture!=null)
        //          throw new InvalidOperationException(
        //            String.Format("Property \"{0}\" isn't translatable.", name));
        
      }
      else {
        if (culture==null)
          culture = session.culture;
        else if (culture.Domain!=session.domain)
          throw new InvalidOperationException("Culture should be registered in the domain.");
        n2 = culture.Index;
      }
      
      object pValue = properties.GetValue(n1,n2,cCnt);
      if (pValue!=field)
        throw new InvalidOperationException("Invalid FieldContentChanging notification.");
      
      OnPropertyContentChanging(name, culture, pValue);
      session.OnDataObjectPropertyContentChanging(this, name, culture, pValue);
    }
    
    /// <summary>
    /// This method should be called by <see cref="IDataObjectFieldValue"/> instance
    /// to notify the <see cref="IDataObjectFieldValue.Owner"/> that content of
    /// the field was changed.
    /// <seealso cref="FieldContentChanging"/>
    /// <seealso cref="OnPropertyContentChanging"/>
    /// <seealso cref="OnPropertyContentChanged"/>
    /// </summary>
    /// <param name="field">Property value that notifies about its change.</param>
    [NotOverridable]
    [Transactional(TransactionMode.ExistingTransactionRequired)]
    public virtual void FieldContentChanged(IDataObjectFieldValue field)
    {
      if (field==null)
        throw new ArgumentNullException("field");
      if (State==DataObjectState.Removed)
        throw new InstanceIsRemovedException();

      Field   f       = field.Field;
      Culture culture = field.Culture;
      string  name    = f.Name;
          
      int n1 = f.Index;
      int n2 = 0;
      if (!f.Translatable) {
        culture = null;
        //        if (culture!=null)
        //          throw new InvalidOperationException(
        //            String.Format("Property \"{0}\" isn't translatable.", name));
        
      }
      else {
        if (culture==null)
          culture = session.culture;
        else if (culture.Domain!=session.domain)
          throw new InvalidOperationException("Culture should be registered in the domain.");
        n2 = culture.Index;
      }
      
      int cCnt = session.domain.cultures.Count;
      object pValue = properties.GetValue(n1,n2,cCnt);
      if (pValue!=field)
        throw new InvalidOperationException("Invalid FieldContentChanged notification.");
      
      if (n1==3)
        PermissionsChanged();
      OnPropertyContentChanged(name, culture, pValue);
      session.OnDataObjectPropertyContentChanged(this, name, culture, pValue);

      ExternalField ef = f as ExternalField;
      if (ef!=null) {
        IDataObjectExternalFieldValue efv = pValue as IDataObjectExternalFieldValue;
        if (efv!=null && efv.IsChanged) {
          SetIsChanged(true);
          if (f.ChangesTrackingMode==ChangesTrackingMode.ThroughOwner) {
            properties.SetIsLoaded(n1,n2,cCnt,true);
            properties.SetIsChanged(n1,n2,cCnt,true);
          }
          TryPersist();
        }
        else {
          if (f.ChangesTrackingMode==ChangesTrackingMode.ThroughOwner) {
            SetIsChanged(true);
            properties.SetIsLoaded(n1,n2,cCnt,true);
            properties.SetIsChanged(n1,n2,cCnt,true);
            TryPersist();
          }
        }
      }
      else {
        SetIsChanged(true);
        properties.SetIsLoaded(n1,n2,cCnt,true);
        properties.SetIsChanged(n1,n2,cCnt,true);
        TryPersist();
      }
    }
    
    // Other
    
    /// <summary>
    /// Gets the <see cref="DataObjectState">state</see> of the instance.
    /// This property getter always updates instance's 
    /// <see cref="TransactionContext"/> (makes it equal to 
    /// <see cref="Session.TransactionContext">Session.TransactionContext</see>)
    /// and <see cref="Reload"/>s the instance if necessary.
    /// </summary>
    [NotPersistent]
    [Transactional(TransactionMode.Disabled)]
    public DataObjectState State {
      get {
        if (state==DataObjectState.New)
          return state;
        if (transactionContext!=session.transactionContext)
          Reload(false);
        return state;
      }
    }

    /// <summary>
    /// Gets the <see cref="DataObjects.NET.ObjectModel.Type"/> of this instance.
    /// </summary>
    [NotPersistent]
    [Transactional(TransactionMode.Disabled)]
    public  ObjectModel.Type Type {
      get {return type;}
    }

    /// <summary>
    /// Gets the <see cref="DataObjects.NET.TransactionContext"/> 
    /// where instance data was retrieved (so this is the context
    /// where this data is definitely valid).
    /// <seealso cref="State"/>
    /// <seealso cref="Reload"/>
    /// <seealso cref="DataObjects.NET.TransactionContext"/>
    /// </summary>
    /// <remarks>
    /// Value of this property is automatically changed during
    /// the life of <see cref="DataObject"/> instance - it becomes
    /// equal to <see cref="DataObjects.NET.Session.TransactionContext">Session.TransactionContext</see>
    /// on almost any attempt to access the property of <see cref="DataObject"/>
    /// or invoke its method. It's possible that instance will be 
    /// <see cref="Reload"/>ed on such an operation.
    /// </remarks>
    [NotPersistent]
    [Transactional(TransactionMode.Disabled)]
    public  TransactionContext TransactionContext
    {
      get {return transactionContext;} 
    }
    
    /// <summary>
    /// Gets the <see cref="DataObjects.NET.Transaction"/> 
    /// where instance data was retrieved (so this is the transaction
    /// where this data is definitely valid).
    /// <seealso cref="State"/>
    /// <seealso cref="Reload"/>
    /// <seealso cref="DataObjects.NET.Transaction"/>
    /// <seealso cref="DataObjects.NET.TransactionContext"/>
    /// </summary>
    /// <remarks>
    /// Value of this property is automatically changed during
    /// the life of <see cref="DataObject"/> instance - it becomes
    /// equal to <see cref="DataObjects.NET.Session.Transaction">Session.Transaction</see>
    /// on almost any attempt to access the property of <see cref="DataObject"/>
    /// or invoke its method. It's possible that instance will be 
    /// <see cref="Reload"/>ed on such an operation.
    /// </remarks>
    [NotPersistent]
    [Transactional(TransactionMode.Disabled)]
    public  Transaction Transaction 
    {
      get {return transactionContext.transaction;} 
    }
    
    /// <summary>
    /// <see langword="True"/> if some <see cref="OnCreate"/> 
    /// or <see cref="OnCreateDeserializable"/> method of this
    /// instance is executing.
    /// <seealso cref="OnCreate"/>
    /// <seealso cref="OnCreated"/>
    /// <seealso cref="OnCreateDeserializable"/>
    /// </summary>
    [NotPersistent]
    [Transactional(TransactionMode.Disabled)]
    public bool IsCreating {
      get {return stateFlags[IsCreatingMask];}
    }
    internal void SetIsCreating(bool value)
    {
      stateFlags[IsCreatingMask] = value;
    }
    
    /// <summary>
    /// <see langword="True"/> if some persistent properties 
    /// of instance were changed, but not yet persisted - this means 
    /// that instance contains delayed updates.
    /// <seealso cref="Persist"/>
    /// </summary>
    [NotPersistent]
    [Transactional(TransactionMode.Disabled)]
    public bool IsChanged {
      get {return stateFlags[IsChangedMask];}
    }
    internal void SetIsChanged(bool value)
    {
      stateFlags[IsChangedMask] = value;
      if (value) {
        session.OnDataObjectUpdated(this);
#if (!EXPRESS && !STANDARD)
        if (canNotifyDependencyParent) {
          DataObject dependencyParent = DependencyParent;
          if (dependencyParent!=null && dependencyParent.State!=DataObjectState.Removed && !dependencyParent.IsRemoving) {
            dependencyParent.SetIsChanged(true);
            dependencyParent.SetIsDependencyChildChanged(true);
            dependencyParent.TryPersist();
          }
        }
#endif
      }
    }
    
    internal bool IsChanging {
      get {
        return stateFlags[IsChangingMask];
      }
      set {
        stateFlags[IsChangingMask]=value;
      }
    }    
    
    /// <summary>
    /// <see langword="True"/> if <see cref="Persist"/> method of this instance is executing now.
    /// </summary>
    [NotPersistent]
    [Transactional(TransactionMode.Disabled)]
    public bool IsPersisting {
      get {return persistDepth>0;}
    }

    /// <summary>
    /// Gets the count of recursive calls to <see cref="Persist"/> method of this instance.
    /// </summary>
    [NotPersistent]
    [Transactional(TransactionMode.Disabled)]
    public int PersistDepth {
      get {return persistDepth;}
    }

    /// <summary>
    /// <see langword="True"/> if <see cref="Remove"/> method of this 
    /// instance is executing now.
    /// <seealso cref="RemovalQueue"/>
    /// </summary>
    [NotPersistent]
    [Transactional(TransactionMode.Disabled)]
    public bool IsRemoving {
      get {
        if (session==null)
          return false;
        return session.removingInstances.Contains(GetInternalID());
      }
    }

    /// <summary>
    /// Gets <see cref="DataObjectRemovalQueue"/> instance in which
    /// current object is queued for removal. This property returns
    /// not <see langword="null"/> value only while
    /// <see cref="IsRemoving"/> is <see langword="true"/>.
    /// <seealso cref="IsRemoving"/>
    /// </summary>
    [NotPersistent]
    [Transactional(TransactionMode.Disabled)]
    protected internal DataObjectRemovalQueue RemovalQueue {
      get {
        if (session==null)
          return null;
        return (DataObjectRemovalQueue)session.removingInstances[GetInternalID()];
      }
    }
    internal void SetRemovalQueue(DataObjectRemovalQueue value)
    {
      if (value!=null) {
        long id = GetInternalID();
        if (session.removingInstances.Contains(id))
          throw new DataObjectsDotNetException(
            "Internal error: attempt to add an object to multiple removal queues.");
        session.removingInstances[id] = value;
      }
      else
        session.removingInstances.Remove(GetInternalID());
    }

    /// <summary>
    /// <see langword="True"/> if instance is deserializing now.
    /// </summary>
    [NotPersistent]
    [Transactional(TransactionMode.Disabled)]
    public bool IsDeserializing {
      get {return serializationInfo!=null;}
    }

    internal DataObjectInstantiationInfo UseableInstantiationInfo {
      get {
        if (useableValidationInfo==null)
          return null;
        DataObjectInstantiationInfo iInfo = 
          (DataObjectInstantiationInfo)session.Cache.GlobalCache[useableValidationInfo]; // Updates GlobalCache, if necessary!
        if (iInfo!=null)
          useableValidationInfo = iInfo;
        return iInfo;
      }
    }

    
    // Persistence support

    // Update locking
    
    /// <summary>
    /// This method can be called before updating set of properties.
    /// At the end of update <see cref="EndUpdate"/> should be called
    /// to persist the instance.
    /// </summary>
    /// <remarks>
    /// <note type="note">Invocation of this method doesn't guarants, that changes 
    /// wouldn't be persisted till the <see cref="EndUpdate"/> call.</note>
    /// <seealso cref="EndUpdate"/>
    /// <seealso cref="IsChanged"/>
    /// <seealso cref="DataObjects.NET.Session.SecurityOptions"/>
    /// <seealso cref="SessionSecurityOptions"/>
    /// </remarks>
    [Transactional(TransactionMode.Disabled)]
    protected void BeginUpdate()
    {
      if (session.transaction==null)
        throw new TransactionRequiredException();
      if (session.transaction.isFinished)
        throw new TransactionIsLockedException(session.transaction.RollbackException);
      delayUpdateDepth++;
    }
    
    /// <summary>
    /// This method should be called at the end of property set updating
    /// to persist the instance.
    /// <seealso cref="BeginUpdate"/>
    /// <seealso cref="IsChanged"/>
    /// <seealso cref="DataObjects.NET.Session.SecurityOptions"/>
    /// <seealso cref="SessionSecurityOptions"/>
    /// </summary>
    [Transactional(TransactionMode.Disabled)]
    protected void EndUpdate()
    {
      if (delayUpdateDepth<=0)
        throw new InvalidOperationException("Call to EndUpdate was issued before prior call to BeginUpdate.");
      if ((--delayUpdateDepth)==0 && persistDepth==0)
        TryPersist();
    }
    
    /// <summary>
    /// Persists the instance by calling the <see cref="Persist"/> method,
    /// or registers it as an instance having a delayed update in the 
    /// <see cref="Session"/>. Note, that <see cref="IsChanged"/> should be
    /// set to <see langword="true"/>, elsewise none of actions would be 
    /// performed.
    /// </summary>
    [Transactional(TransactionMode.Disabled)]
    internal void TryPersist()
    {
      if (IsChanged) {
        if (session.delayUpdates || delayUpdateDepth>0) {
          session.RegisterUpdatedInstanceWithoutPersist(this);
          if (session.transaction==null)
            throw new TransactionRequiredException();
          if (session.transaction.isFinished)
            throw new TransactionIsLockedException(session.transaction.RollbackException);
        }
        else {
          Persist();
        }
      }
    }

      private void PersistLazy()
      {
          if (lazyCollections != null)
          {
              for (int idx = 0; idx < lazyCollections.Count; idx++)
              {
                  LazyInfo li = (LazyInfo)lazyCollections[idx];
                  if (li.pcN != null)
                  {
                      li.pcN.InnerAddPairedObject(this);
                      li.pcN.OnAddComplete(this);
                  }
                  if (li.pcO != null)
                      li.pcO.ContentChanged();
                  if (li.pcN != null)
                      li.pcN.ContentChanged();
              }
              lazyCollections.Clear();
              lazyCollections = null;
          }
      }
    

    /// <summary>
    /// Persists instance to the database.
    /// </summary>
    /// <remarks>
    /// Normally you shouldn't call this method manually - DataObjects.NET
    /// persists instances transparently on any changes or delayes the call
    /// to this method before the moment then this will be absolutely
    /// necessary.
    /// <seealso cref="IsChanged"/>
    /// </remarks>
    /// 
    [NotOverridable]
    [Transactional(TransactionMode.ExistingTransactionRequired)]
    public virtual void Persist()
    {
      if (State==DataObjectState.Removed)
        throw new InstanceIsRemovedException();
      if (!IsChanged)
        return;
      if (persistDepth++ > 32)
        throw new InvalidOperationException(
          "Too many recursive calls to Persist method of the same instance.");
      try {
        OnPersist();
        if (state==DataObjectState.Removed)
          goto End;
        PackFastLoadData();
        SaveProperties();
        PersistLazy();
      }
      finally {
        persistDepth--;
      }
      End:
      OnPersisted();
      session.OnDataObjectPersisted(this);
    }
    
    /// <summary>
    /// Loads all properties of the instance including 
    /// properties marked by [<see cref="LoadOnDemandAttribute"/>].
    /// </summary>
    [NotOverridable]
    [Transactional(TransactionMode.TransactionRequired)]
    public virtual void LoadAll()
    {
      if (State!=DataObjectState.Persistent)
        throw new InvalidInstanceStateException(this);

      FieldCollection fields = type.Fields;
      CultureCollection cultures = session.domain.cultures;
      int cnt = fields.Count;
      int cCnt = cultures.Count;
      int k = 0;
      BitArray lp = new BitArray(cnt*cCnt, false);
      bool needLoad = false;
      for (int i = 0; i<cnt; i++) {
        int ccCnt = fields[i].Translatable ? cCnt : 1;
        for (int j = 0; j<ccCnt; j++) {
          lp[k]     = !properties.GetIsLoaded(k);
          needLoad |= !properties.GetIsLoaded(k);
          k++;
        }
        if (ccCnt==1)
          k += cCnt-1;
      }
      if (needLoad)
        LoadProperties(lp, true);
    }
    
    /// <summary>
    /// Reloads the instance from the database.
    /// </summary>
    /// <remarks>
    /// <para>
    /// Normally you should never call this method directly except
    /// if you're working on read committed <see cref="IsolationLevel"/>.
    /// </para>
    /// <para>
    /// This method first performs version check - it compares
    /// <see cref="VersionID"/> property value of instance with
    /// one stored in the database. If versions are equals, it does nothing,
    /// otherwise it refetches all instance properties without 
    /// <see cref="LoadOnDemandAttribute"/> applied (and marks all
    /// other properties as "should fetch on demand").
    /// </para>
    /// <para>
    /// This method is called automatically on almost any operation 
    /// with instance if DataObjects.NET notices that instance data isn't 
    /// valid in current <see cref="DataObjects.NET.Session.TransactionContext">Session.TransactionContext</see>.
    /// It compares instance's <see cref="TransactionContext"/> with 
    /// <see cref="DataObjects.NET.Session.TransactionContext">Session.TransactionContext</see>
    /// (reference comparison) to check this condition (equals
    /// means that instance data is valid).
    /// </para>
    /// <para>
    /// Instance's <see cref="TransactionContext"/> becomes equal to 
    /// <see cref="DataObjects.NET.Session.TransactionContext">Session.TransactionContext</see>
    /// after call to this method.
    /// </para>
    /// <seealso cref="TransactionContext"/>
    /// <seealso cref="DataObjects.NET.Session.TransactionContext"/>
    /// </remarks>
    [NotOverridable]
    [Transactional(TransactionMode.TransactionRequired)]
    public virtual void Reload()
    {
      Reload(true);
    }
    
    [Transactional(TransactionMode.Disabled)]
    internal void Reload(bool manual)
    {
      if (!manual && session.transaction==null && session.IsOfflineMode) {
        if (!transactionContext.isDirty)
          return;
        if ((session.Options & SessionOptions.DisableAutoReload)==SessionOptions.DisableAutoReload)
          throw new OfflineModeException(
            "Instance is dirty (contains changes that were rolled back), " +
            "but it's impossible to reload it in the OfflineMode (DisableAutoReload flag is on).");
      }

      // Automatic Transactions support code
      TransactionController tc = session.CreateTransactionController(TransactionMode.TransactionRequired);
      Reprocess:
      try {
        InnerReload(manual);
        tc.Commit();
      }
      catch (Exception e) {
        if (tc.Rollback(e, true))
          goto Reprocess;
        throw;
      }
    }


    private void InnerReload(bool manual)
    {
      // !!!!
      if (state==DataObjectState.New || persistDepth>0)
        return;

      bool disableReloading = !manual && session.IsOfflineMode &&
                              (IsChanging || (session.Options & SessionOptions.DisableAutoReload)==SessionOptions.DisableAutoReload);
      
      TransactionContext activeContext = session.transactionContext;
      
      bool bDirty = transactionContext.isDirty;
      Transaction tct = transactionContext.transaction;
      bool bOutermostTransactionChanged = tct==null ||
                                          (session.outermostTransaction!=tct.outermostTransaction);
      if (bOutermostTransactionChanged)
        lastLockType = LockType.None;
      
      if (!(bDirty || manual || (bOutermostTransactionChanged && session.IsOnlineMode))) {
        if (session.IsOnlineMode)
          transactionContext = activeContext;
        return;
      }

      //      if (persistDepth>0 && IsChanged) {
      //        if (bDirty)
      //          throw new InvalidOperationException(
      //            "Can't Reload instance: it contains dirty changed data. "+
      //            "Possible reason: rollback to the Savepoint during OnPersist execution.");
      //        else {
      //          if (state!=DataObjectState.Removed) {
      //            PackFastLoadData();
      //            SaveProperties();
      //          }
      //        }
      //      }
      
      CultureCollection cultures = session.domain.cultures;
      int cultureCount = cultures.Count;

      long id        = (long)properties.GetValue(0,0,cultureCount);
      int  typeId    = (int)properties.GetValue(1,0,cultureCount);
      int  versionId = (int)properties.GetValue(2,0,cultureCount);
      
      // Let's try to update the instance without additional queries
      DataObjectInstantiationInfo iInfo;
      try {
        if (manual) {
          // Manual reload
            iInfo = session.persister.FetchDataObject(session.GetBaseTable(this.Type), id);
          if (iInfo==null) {
            session.domain.PerformanceCounters.RegisterCacheHit(
              InstantiationInfoSource.Database, false);
            if (disableReloading)
              throw new OfflineModeException(
                "Instance is currently removed from the database, " +
                "but this change can't be accepted in the OfflineMode (DisableAutoReload flag is on or instance is modifying).");
            transactionContext = activeContext;
            ConvertToRemoved();
            OnLoad(true);
            session.OnDataObjectLoad(this,true);
            return;
          }
          transactionContext = activeContext;
        }
        else if (state==DataObjectState.Persistent && !IsChanged && !bDirty) {
          bool skipReload = false;
          OnBeforeReload(ref skipReload);
          session.OnDataObjectBeforeReload(this, ref skipReload);
          if (skipReload) {
            if (session.IsOnlineMode && transactionContext!=activeContext) {
              transactionContext = activeContext;
              // We should reload properties that track changes independently.
              MarkIndependentlyPersistedFieldsAsNotLoaded();
            }
            return;
          }
          // Instance isn't dirty 
          bool isUseableValidationInfoValid = false;
          if (useableValidationInfo!=null &&
              !useableValidationInfo.TransactionContext.isDirty &&
              useableValidationInfo.TransactionContext.OutermostTransaction
              ==session.outermostTransaction) {
            // And has usable validation info
            isUseableValidationInfoValid = true;
            if (useableValidationInfo.VersionID==versionId) {
              // With the same VersionID - so nothing additional should be done
              if (session.IsOnlineMode && transactionContext!=activeContext) {
                transactionContext = activeContext;
                // We should reload properties that track changes independently.
                MarkIndependentlyPersistedFieldsAsNotLoaded();
              }
              return;
            }
          }
          iInfo = UseableInstantiationInfo;
#if (!EXPRESS && !STANDARD)
          // let's make a check through dependency parent ...
          if (!isUseableValidationInfoValid && iInfo!=null) {
            if (session.IsInstantiationInfoValid(iInfo)) {
              // With the same VersionID - so nothing additional should be done
              if (session.IsOnlineMode && transactionContext!=activeContext) {
              transactionContext = activeContext;
              // We should reload properties that track changes independently.
              MarkIndependentlyPersistedFieldsAsNotLoaded();
            }
            return;
          }
        }
#endif
          if (isUseableValidationInfoValid && iInfo!=null) {
            // With another VersionID - so we can simply use it
            if (disableReloading)
              throw new OfflineModeException(
                "Instance is modified in the database (its VersionID is changed), " +
                "but this change can't be accepted in the OfflineMode (DisableAutoReload flag is on or instance is modifying).");
            transactionContext = activeContext;
          }
          else {
            // We have no useable instantiation info -
            // so we should check instance version
              iInfo = session.persister.FetchDataObjectIfVersionChanged(session.GetBaseTable(this.Type), id, versionId, this);
            if (iInfo==null) {
              session.domain.PerformanceCounters.RegisterCacheHit(
                InstantiationInfoSource.SessionCache, true);
              if (session.IsOnlineMode  && transactionContext!=activeContext) {
                transactionContext = activeContext;
                // We should reload properties that track changes independently.
                MarkIndependentlyPersistedFieldsAsNotLoaded();
              }
              return;
            }
            else if (iInfo.ID==0) {
              iInfo.RegisterUsage(session.domain.PerformanceCounters);
              if (disableReloading)
                throw new OfflineModeException(
                  "Instance is currently removed from the database, " +
                  "but this change can't be accepted in the OfflineMode (DisableAutoReload flag is on or instance is modifying).");
              transactionContext = activeContext;
              ConvertToRemoved();
              OnLoad(true);
              session.OnDataObjectLoad(this,true);
              return;
            }
          }
        }
        else {
          // Instance is dirty, so reload is anyway needed
          if (disableReloading)
            throw new OfflineModeException(
              "Instance is dirty (contains changes that were rolled back), " +
              "but it's impossible to reload it in the OfflineMode (DisableAutoReload flag is on or instance is modifying).");
          iInfo = UseableInstantiationInfo;
          if (iInfo!=null && !iInfo.TransactionContext.isDirty) {
            // But it has non-dirty instantiation info...
#if (!EXPRESS && !STANDARD)
            // let's make a check (possibly through dependency parent)
            if (session.IsInstantiationInfoValid(iInfo)) {
              // Instantiation info is completely usable - let's use it
              transactionContext = activeContext;
            }
#else
            if (iInfo.TransactionContext.OutermostTransaction==session.OutermostTransaction) {
              // Instantiation info is completely usable - let's use it
              transactionContext = activeContext;
            }
#endif
            else {
              // Instantiation info is usable, but requires a version check
              DataObjectInstantiationInfo newIInfo =
                session.persister.FetchDataObjectIfVersionChanged(session.GetBaseTable(this.Type), id, useableValidationInfo.VersionID, useableValidationInfo);
              transactionContext = activeContext;
              if (newIInfo==null) {
                // Version check passed
                iInfo.ValidatedByQuery = true;
                iInfo.TransactionContext = activeContext;
              }
              else if (newIInfo.ID==0) {
                newIInfo.RegisterUsage(session.domain.PerformanceCounters);
                // Version check failed - object is already removed
                ConvertToRemoved();
                OnLoad(true);
                session.OnDataObjectLoad(this,true);
                return;
              }
              else {
                // Version check failed - object was modified
                iInfo = newIInfo;
                useableValidationInfo = iInfo;
              }
            }
          }
          else {
            // It has no usable instantiation info - so we should fetch it
              iInfo = session.persister.FetchDataObject(session.GetBaseTable(this.Type), id);
            transactionContext = activeContext;
            if (iInfo==null) {
              session.domain.PerformanceCounters.RegisterCacheHit(
                InstantiationInfoSource.Database, false);
              ConvertToRemoved();
              OnLoad(true);
              session.OnDataObjectLoad(this,true);
              return;
            }
            else {
              useableValidationInfo = iInfo;
            }
          }
        }
      }
      catch (Exception e) {
        throw session.utils.SubstituteException(e);
      }

      DataObject lastSecurityParent = permissions==null ? null : permissions.securityParent;
      FieldCollection fields = type.Fields;
      int fieldCount = fields.Count;

      // Here we dispose all IDisposable properties
      int k = cSysPropertiesCount*cultureCount;
      for (int i = cSysPropertiesCount; i<fieldCount; i++) {
        int ccCnt = fields[i].Translatable ? cultureCount : 1;
        for (int j = 0; j<ccCnt; j++) {
          IRecyclableFieldValue ri = properties.GetValue(k) as IRecyclableFieldValue;
          if (ri!=null)
            if (ri.Recycle()) {
              k++;
              continue;
            }
          IDisposable dsi = properties.GetValue(k) as IDisposable;
          if (dsi!=null)
            dsi.Dispose();
          properties.SetValue(k,null);
          k++;
        }
        if (ccCnt==1)
          k += cultureCount-1;
      }

      // Let's temporary keep old properties
      DataObjectProperties oldProperties = properties;
      properties = new DataObjectProperties(fieldCount,cultureCount);

      SetIsChanged(false);
      session.UnregisterUpdatedInstance(this);

      // Fields init
      k = cSysPropertiesCount*cultureCount;
      for (int i = cSysPropertiesCount; i<fieldCount; i++) {
        Field f = fields[i];
        IChangesTrackingField ctf = f as IChangesTrackingField;
        bool rof = f is IReadOnlyField;
        if (f.Translatable) {
          if (rof) {
            for (int j = 0; j<cultureCount; j++) {
              Culture c = cultures[j];
              IDataObjectFieldValue pDefault = (IDataObjectFieldValue)oldProperties.GetValue(k);
              if (pDefault==null)
                pDefault = (IDataObjectFieldValue)f.CreateDefaultInternalValue(c, this);
              if (ctf!=null)
                ctf.ClearChanges(this, c, pDefault);
              properties.SetValue(k,pDefault);
              pDefault.Attach(this, f, c);
              properties.SetIsLoaded(k,true);
              k++;
            }
          }
          else
            k += cultureCount;
        }
        else {
          if (rof) {
            IDataObjectFieldValue pDefault = (IDataObjectFieldValue)oldProperties.GetValue(k);
            if (pDefault==null)
              pDefault = (IDataObjectFieldValue)f.CreateDefaultInternalValue(null, this);
            if (ctf!=null)
              ctf.MarkAsChanged(this, null, pDefault);
            properties.SetValue(k,pDefault);
            pDefault.Attach(this, f, null);
            properties.SetIsLoaded(k,true);
          }
          k += cultureCount;
        }
      }
      
      iInfo.RegisterUsage(session.domain.PerformanceCounters);
      properties.SetValue(0,0,cultureCount,id);
      properties.SetValue(1,0,cultureCount,typeId);
      properties.SetValue(2,0,cultureCount,iInfo.VersionID);
      properties.SetValue(3,0,cultureCount,oldProperties.GetValue(3,0,cultureCount));
      properties.SetValue(4,0,cultureCount,iInfo.FastLoadData);
      properties.SetIsLoaded(0,0,cultureCount,true);
      properties.SetIsLoaded(1,0,cultureCount,true);
      properties.SetIsLoaded(2,0,cultureCount,true);
      properties.SetIsLoaded(3,0,cultureCount,true);
      properties.SetIsLoaded(4,0,cultureCount,true);

      state = DataObjectState.Persistent;
      session.Cache[id] = this;
      
      try {
        UnpackPermissions(iInfo.Permissions);
        bool loadAll = !UnpackFastLoadData();
        BitArray lp = new BitArray(fieldCount*cultureCount, false);
        bool needLoad = false;
        k = cSysPropertiesCount*cultureCount;
        for (int i = cSysPropertiesCount; i<fieldCount; i++) {
          Field f = fields[i];
          if (f.LoadOnDemand || f.IsNonPersisted)
            k += cultureCount;
          else {
            int stepCount = f.Translatable ? cultureCount : 1;
            int stepSize  = stepCount==1 ? cultureCount : 1;
            for (int j=0; j<stepCount; j++, k+=stepSize)
              needLoad |= (lp[k] = loadAll || !properties.GetIsLoaded(k));
          }
        }
        if (needLoad)
          LoadProperties(lp, true);
        if (lastSecurityParent!=SecurityParent)
          SecurityParentChanged();
        else
          PermissionsChanged();
        OnLoad(true);
        session.OnDataObjectLoad(this,true);
        UpdateInconsistentData(session.inconsistentDataUpdateProbability);
      }
      catch {
        try {
          ConvertToRemoved();
        } catch {}
        throw;
      }
      
#if (!EXPRESS && !STANDARD)
      DataObject dependencyParent = this.DependencyParent;
      if (dependencyParent!=null) {
        iInfo.DependencyParentID = dependencyParent.ID;
        iInfo.DependencyParentVersionID = dependencyParent.VersionID;
      }
#endif

      session.Cache.GlobalCache.Add(iInfo);
    }

    /// <summary>
    /// Marks all properties that track their changes independently 
    /// from owner as not loaded.
    /// </summary>
    internal void MarkIndependentlyPersistedFieldsAsNotLoaded()
    {
      int cCnt = session.domain.cultures.Count;
      FieldCollection fields = type.Fields;
      int cnt  = fields.Count;

      int k = cSysPropertiesCount*cCnt;
      for (int i = cSysPropertiesCount; i<cnt; i++) {
        Field f = fields[i];
        if (f.ChangesTrackingMode==ChangesTrackingMode.Independently &&
            !(f is IReadOnlyField || f is IHasStableInternalValueField || f is IHasStableValueField)) {
          if (f.Translatable) {
            for (int j = 0; j<cCnt; j++) {
              properties.SetIsLoaded(k,false);
              k++;
            }
          }
          else {
            properties.SetIsLoaded(k,false);
            k += cCnt;
          }
        }
        else
          k += cCnt;                  
      }
    }
    
    internal void EnsurePropertyLoaded (Field field, Culture culture)
    {
      if (field==null)
        throw new ArgumentException("field");
      CultureCollection cultures = session.domain.cultures;
      int cCnt = cultures.Count;

      int fieldIndex = field.Index;
      int cultureIndex = culture==null ? 0 : culture.Index;
      if (!properties.GetIsLoaded(fieldIndex, cultureIndex, cCnt))
        LoadProperty(field, culture);
    }
    /// <summary>
    /// Loads any persistent property of the instance by its name and culture.
    /// </summary>
    /// <param name="field">Property name.</param>
    /// <param name="culture">Property culture.</param>
    private void LoadProperty(Field field, Culture culture)
    {
      if (field==null)
        throw new ArgumentException("field");
      if (field.IsNonPersisted)
         return;
      CultureCollection cultures = session.domain.cultures;
      int cnt = Type.Fields.Count;
      int cCnt = cultures.Count;

      int fieldIndex = field.Index;
      int cultureIndex = culture==null ? 0 : culture.Index;

      BitArray lp = new BitArray(cnt*cCnt, false);
      lp[fieldIndex*cCnt+cultureIndex] = true;
      
      LoadProperties(lp, true);
    }
    
    private void LoadProperties(BitArray loadMap, bool enableCheckVersions)
    {
      IDictionary r = new Hashtable();
      
      bool canCache = Session.Transaction==null ?
                      false : 
                      Session.Transaction.IsReadOnly;
        
      BitArray updatedLoadMap = loadMap;
      ArrayList requireCache = new ArrayList();
      
      updatedLoadMap = new BitArray(loadMap);
      
      FieldCollection fields = type.Fields;
      CultureCollection cultures = Domain.Cultures;
      int cnt = fields.Count;
      int cCnt = cultures.Count;
      int k = cSysPropertiesCount*cCnt;
      
      for (int i = cSysPropertiesCount; i<cnt; i++) {
        Field f = fields[i];
        {
            if (f.LoadOnDemand && f.ChangesTrackingMode == ChangesTrackingMode.ThroughOwner)
            {
                if (f.Translatable)
                {
                    for (int j = 0; j < cCnt; j++)
                        if (updatedLoadMap[k + j])
                        {
                            if (Inner_LoadFieldFromCache(f, cultures[j], r))
                                updatedLoadMap[k + j] = false;
                            else if (canCache)
                            {
                                requireCache.Add(f);
                                requireCache.Add(cultures[j]);
                            }
                        }
                }
                else
                {
                    if (updatedLoadMap[k])
                    {
                        if (Inner_LoadFieldFromCache(f, null, r))
                            updatedLoadMap[k] = false;
                        else if (canCache)
                        {
                            requireCache.Add(f);
                            requireCache.Add(null);
                        }
                    }
                }
            }
        }
        k += cCnt;
      }
      
      ArrayList lColumns = ConvertLoadMapToColumnList(updatedLoadMap, type, session.domain);
      if (lColumns.Count==0 && r.Count==0)
        return;
        
      if (lColumns.Count>0) {
        IDictionary fr = null;
        try {
          fr = session.persister.FetchInstanceColumns(type.RelatedView, lColumns, GetInternalID(), GetInternalVersionID(), enableCheckVersions);
        }
        catch (Exception e) {
          throw session.utils.SubstituteException(e);
        }
        for (int i=0; i<requireCache.Count; i+=2)
          Inner_CacheField((Field)requireCache[i], (Culture)requireCache[i+1], fr);
        if (r.Count==0)
          r = fr;
        else
          foreach (DictionaryEntry entry in fr)
            r[entry.Key] = entry.Value;
      }
      
      LoadProperties(loadMap, r);
    }
    
    internal bool Inner_LoadFieldFromCache(Field f, Culture c, IDictionary r)
    {
      string propertyName = f.Name + (f.Translatable ? "-"+c.Name : "");
      PropertyInstantiationInfo pInstInfo = (PropertyInstantiationInfo)
                                            Session.Cache.GlobalCache[new PropertyKey(ID, propertyName), VersionID];
        
      if (pInstInfo==null) {
        Domain.PerformanceCounters.RegisterCacheHit(
          InstantiationInfoSource.Database, false);
        return false;
      }
      
      object data = pInstInfo.GetValue();
      FieldViewColumnCollection fvc = f.RelatedViewColumns;
      
      if (f.Translatable) {
        int cIndex = c.Index;
        if (f is StructField) {
          int cCnt = Domain.Cultures.Count;
          int cnt = fvc.Count/cCnt;
          object[] a_data = (object[])data;
          for (int i = 0; i<cnt; i++)
            r[fvc[cIndex + i*cCnt].Name] = a_data[i];
        }
        else
          r[fvc[cIndex].Name] = data;
      }
      else {
        if (f is StructField) {
          int cnt = fvc.Count;
          object[] a_data = (object[])data;
          for (int i = 0; i<cnt; i++)
            r[fvc[i].Name] = a_data[i];
        }
        else
          r[fvc[0].Name] = data;
      }
      
      Domain.PerformanceCounters.RegisterCacheHit(
        InstantiationInfoSource.GlobalCache, false);
      return true;
    }
    
    internal void Inner_CacheField(Field f, Culture c, IDictionary r)
    {
      object data = null;
      FieldViewColumnCollection fvc = f.RelatedViewColumns;
      
      if (f.Translatable) {
        int cIndex = c.Index;
        if (f is StructField) {
          int cCnt = Domain.Cultures.Count;
          int cnt = fvc.Count/cCnt;
          object[] a_data = new object[cnt];
          for (int i = 0; i<cnt; i++)
            a_data[i] = r[fvc[cIndex + i*cCnt].Name];
          data = a_data;
        }
        else
          data = r[fvc[cIndex].Name];
      }
      else {
        if (f is StructField) {
          int cnt = fvc.Count;
          object[] a_data = new object[cnt];
          for (int i = 0; i<cnt; i++)
            a_data[i] = r[fvc[i].Name];
          data = a_data;
        }
        else
          data = r[fvc[0].Name];
      }
      
      string propertyName = f.Name + (f.Translatable ? "-"+c.Name : "");  
      PropertyInstantiationInfo pInstInfo = 
        new PropertyInstantiationInfo(GlobalCacheItemType.LoadOnDemandField, ID, propertyName, VersionID);
      pInstInfo.SetValue(data);
      Session.Cache.GlobalCache.Add(pInstInfo);
    }
    
    internal static ArrayList ConvertLoadMapToColumnList(BitArray loadMap, ObjectModel.Type type, Domain domain) 
    {
      ArrayList lColumns = new ArrayList();

      FieldCollection fields = type.Fields;
      CultureCollection cultures = domain.cultures;
      int cnt = fields.Count;
      int cCnt = cultures.Count;
      int k = cSysPropertiesCount*cCnt;

      for (int i = cSysPropertiesCount; i<cnt; i++) {
        Field f = fields[i];
        bool fIsStruct = f is StructField;
        if (!(f is ExternalField)) {
          FieldViewColumnCollection fvc = f.RelatedViewColumns;
          if (f.Translatable) {
            for (int j = 0; j<cCnt; j++) {
              if (loadMap[k]) {
                if (!fIsStruct)
                  lColumns.Add(fvc[j]);
                else
                  for (int l = j, lMax = fvc.Count; l<lMax; l+=cCnt)
                    lColumns.Add(fvc[l]);
              }
              k++;
            }
          }
          else {
            if (loadMap[k]) {
              if (!fIsStruct)
                lColumns.Add(fvc[0]);
              else
                for (int l = 0, lMax = fvc.Count; l<lMax; l++) {
                  ViewColumn fvcColumn = fvc[l];
                  if (fvcColumn.View == type.RelatedView)
                    lColumns.Add(fvcColumn);
                }
            }
            k += cCnt;
          }
        }
        else
          k += cCnt;
      }
      return lColumns;
    }
    
    internal void LoadProperties(BitArray loadMap, IDictionary r)
    {
      if (r==null)
        throw new InstanceVersionChangedException();
  
      FieldCollection fields = type.Fields;
      CultureCollection cultures = session.domain.cultures;
      int cnt = fields.Count;
      int cCnt = cultures.Count;
      int k = 0;
      
      for (int i = 0; i<cnt; i++) {
        Field f = fields[i];
        {
            if (f.Translatable)
            {
                for (int j = 0; j < cCnt; j++)
                {
                    Culture c = cultures[j];
                    if (loadMap[k])
                    {
                        object oldValue = properties.GetValue(k);
                        IDisposable dsi = oldValue as IDisposable;
                        if (dsi != null)
                            dsi.Dispose();
                        IDataObjectFieldValue fi = oldValue as IDataObjectFieldValue;
                        if (fi != null)
                            fi.Detach();
                        object iValue = f.InternalValueFromRecord(session, this, c, r);
                        properties.SetValue(k, iValue);
                        fi = iValue as IDataObjectFieldValue;
                        if (fi != null)
                            fi.Attach(this, f, c);
                        properties.SetIsLoaded(k, true);
                        properties.SetIsChanged(k, false);
                    }
                    k++;
                }
            }
            else
            {
                if (loadMap[k])
                {
                    object oldValue = properties.GetValue(k);
                    IDisposable dsi = oldValue as IDisposable;
                    if (dsi != null)
                        dsi.Dispose();
                    IDataObjectFieldValue fi = oldValue as IDataObjectFieldValue;
                    if (fi != null)
                        fi.Detach();
                    object iValue = f.InternalValueFromRecord(session, this, null, r);
                    properties.SetValue(k, iValue);
                    fi = iValue as IDataObjectFieldValue;
                    if (fi != null)
                        fi.Attach(this, f, null);
                    properties.SetIsLoaded(k, true);
                    properties.SetIsChanged(k, false);
                }
            }
            k += cCnt;
        }
      }
    }
    
    private void SaveProperties()
    {
      FieldCollection fields = type.Fields;
      CultureCollection cultures = session.domain.cultures;
      int cnt = fields.Count;
      int cCnt = cultures.Count;
      
      int originalVersionID = (int)properties.GetValue(2,0,cCnt);
      properties.SetValue(2,0,cCnt,originalVersionID+1);
      properties.SetIsChanged(2,0,cCnt,true);

      int k = 0;
      int versionIdColumnPos    = -1;
      try {
        ArrayList lData = new ArrayList();
        bool bVersionChangeRequired = false;
        for (int i = 0; i < cnt; i++)
        {
            Field f = fields[i];
            ExternalField ef = f as ExternalField;
            if (f.Translatable)
            {
                for (int j = 0; j < cCnt; j++)
                {
                    Culture c = cultures[j];
                    if (ef != null)
                    { // ExternalField
                        IDataObjectExternalFieldValue efv = properties.GetValue(k) as IDataObjectExternalFieldValue;
                        if (efv != null)
                            efv.Persist();
                        bVersionChangeRequired |= properties.GetIsChanged(k);
                    }
                    else if (properties.GetIsChanged(k))
                    {
                        f.InternalValueToRecord(session, this, c, properties.GetValue(k), lData);
                        bVersionChangeRequired |= (f.ChangesTrackingMode != ChangesTrackingMode.Independently);
                    }
                    k++;
                }
            }
            else
            {
                if (!f.IsNonPersisted)
                {
                    if (ef != null)
                    { // ExternalField
                        IDataObjectExternalFieldValue efv = properties.GetValue(k) as IDataObjectExternalFieldValue;
                        if (efv != null)
                            efv.Persist();
                        bVersionChangeRequired |= properties.GetIsChanged(k);
                    }
                    else if (properties.GetIsChanged(k))
                    {
                        if (i == 3)
                        {
                            if (permissions != null && permissions.principals.Count > 0)
                                f.InternalValueToRecord(session, this, null, permissions, lData);
                            else
                                f.InternalValueToRecord(session, this, null, null, lData);
                        }
                        else
                        {
                            f.InternalValueToRecord(session, this, null, properties.GetValue(k), lData);
                        }
                        if (i == 2)
                            versionIdColumnPos = lData.Count - 1;
                        else if (i != 4) // Non fastLoadData field
                            bVersionChangeRequired |= (f.ChangesTrackingMode != ChangesTrackingMode.Independently);
                    }
                }
                k += cCnt;
            }
        }
        
        if (IsDependencyChildChanged)
          bVersionChangeRequired = true;
        
        if (!bVersionChangeRequired) {
          // Let's fallback to an old VersionID
          properties.SetValue(2,0,cCnt,originalVersionID);
          properties.SetIsChanged(2,0,cCnt,false);
          if (versionIdColumnPos>=0)
            lData.RemoveAt(versionIdColumnPos);
          if (lData.Count==0)
            return;
        }

        switch (state) {
        case DataObjectState.New:
          long newID = session.persister.InsertInstanceColumns(type, lData, type.AllRelatedTables);
          useableValidationInfo = null;
          properties.SetValue(0,0,cCnt,newID);
          state = DataObjectState.Persistent;
          session.Cache[newID] = this;
          break;
        case DataObjectState.Persistent:
          session.persister.UpdateInstanceColumns(lData, type.AllRelatedTables, (long)properties.GetValue(0,0,cCnt), originalVersionID);
          useableValidationInfo = null;
          break;
        default:
          throw new InstanceIsRemovedException();
        }
      }
      catch (Exception e) {
        properties.SetValue(2,0,cCnt,originalVersionID);
        properties.SetIsChanged(2,0,cCnt,false);
        transactionContext = TransactionContext.CreateDirtyContext(session);
        throw session.utils.SubstituteException(e);
      }

      try {
        k = 0;
        for (int i = 0; i<cnt; i++) {
          Field f = fields[i];
          IChangesTrackingField ctf = f as IChangesTrackingField;
          if (f.Translatable) {
            for (int j = 0; j<cCnt; j++) {
              if (properties.GetIsChanged(k)) {
                properties.SetIsLoaded(k,true);
                properties.SetIsChanged(k,false);
              }
              // fixed 13.10.2004 19:05
              object propertyValue = properties.GetValue(k);
              if (ctf!=null && propertyValue!=null)
                ctf.ClearChanges(this, cultures[j], propertyValue);
              k++;
            }
          }
          else {
            if (properties.GetIsChanged(k)) {
              properties.SetIsLoaded(k,true);
              properties.SetIsChanged(k,false);
            }
            // fixed 13.10.2004 19:05
            object propertyValue = properties.GetValue(k);
            if (ctf!=null && propertyValue!=null)
              ctf.ClearChanges(this, null, propertyValue);
            k += cCnt;  
          }
        }
      }
      finally {
        SetIsChanged(false);
        SetIsDependencyChildChanged(false);
        session.UnregisterUpdatedInstance(this);
        transactionContext = session.transactionContext;
      }
    }
    
    // Permissions-related methods
    


    private void UnpackPermissions(byte[] data)
    {
      if (this is IHasNoAccessControlList) {
        permissions = null;
        properties.SetValue(3,0,session.domain.cultures.Count,permissions);
      }
      else {
        AccessControlList permissions = null;
        Field fPermissions = type.Fields[3];
        try {
          if (data!=null && data.Length!=0) {
            try {
              // test code
              using (MemoryStream ms = new MemoryStream(data)) {
                permissions = (AccessControlList) session.BinaryFormatter.Deserialize(ms);
              }
            }
            catch (SerializationException e) {
              if (!e.Message.ToLower().StartsWith("type is not resolved for "))
                throw;
              permissions = new AccessControlList();
              permissions.Inconsistent = true;
            }
          }
          if (permissions==null)
            permissions = new AccessControlList();
        }
        catch {
          permissions = new AccessControlList();
          throw;
        }
        if (this.permissions!=null)
          this.permissions.CopyFrom(permissions);
        else {
          permissions.owner  = this;
          permissions.field  = fPermissions;
          this.permissions   = permissions;
          properties.SetValue(3,0,session.domain.cultures.Count,permissions);
        }
      }
    }
    
    // FastLoadData-related methods

      public static byte[] PackFastLoadDataFromValues(DataObjects.NET.ObjectModel.Type type, string[] fieldNames, object[] values, Session session)
      {
          FieldCollection fields = type.Fields;
          CultureCollection cultures = session.domain.cultures;
          int fieldCount = fields.Count;
          int cultureCount = cultures.Count;


          try
          {
              MemoryStream ms = session.memoryStream;
              ms.Position = 0;
              BinaryWriter bw = new BinaryWriter(ms, Encoding.UTF8);

              // 121 : DataObjects.NET 2.3 comprehensive FastLoadData format
              // 221 : DataObjects.NET 2.3 compact FastLoadData format
              //SM begin 122 :  SM flat FastLoadData format SM end
              ms.WriteByte((byte)(121));
                  for (int fieldIndex = cSysPropertiesCount; fieldIndex < fieldCount; fieldIndex++)
                  {
                      Field f = fields[fieldIndex];
                      if (f.UsesFastLoadData)
                      {
                          int valueIdx = -1;
                          for (int rowIdx = 0; rowIdx < fieldNames.Length; rowIdx++)
                          {
                              if ((f.RelatedViewColumns.Field.Name == fieldNames[rowIdx]) || (f.RelatedViewColumns[0].Name == fieldNames[rowIdx]))
                              {
                                  valueIdx = rowIdx;
                                  break;
                              }
                          }
                          bool btr = f.Translatable;
                          int fieldCultureCount = btr ? cultureCount : 1;
                          bw.Write(f.Name);
                          bw.Write(f.FieldTypeID);
                          if (valueIdx != -1)
                          {
                              bw.Write((byte)fieldCultureCount);
                              int valueIndex = fieldIndex * cultureCount;
                              for (int cultureIndex = 0; cultureIndex < fieldCultureCount; cultureIndex++, valueIndex++)
                              {
                                  f.InternalValueToStream(session, null, btr ? cultures[cultureIndex] : null, values[valueIdx], bw);
                              }
                          }
                          else
                              bw.Write((byte)0);
                      }
                  }

              byte[] fastLoadData = new byte[ms.Position];
              ms.Position = 0;
              ms.Read(fastLoadData, 0, fastLoadData.Length);
              return fastLoadData;
          }
          catch
          {

          }
          return null;
      }
    

    /// <summary>
    /// Builds <see cref="FastLoadData"/> property value.
    /// </summary>
    private void PackFastLoadData()
    {


      FieldCollection fields = type.Fields;
      CultureCollection cultures = session.domain.cultures;
      int fieldCount = fields.Count;
      int cultureCount = cultures.Count;

//SM begin

      if ((Domain.DatabaseOptions & DomainDatabaseOptions.DisableFastLoadData) > 0)
      {
          properties.SetValue(4, 0, cultureCount, null);
//          SetIsChanged(true);
          properties.SetIsChanged(4, 0, cultureCount, false);
          properties.SetIsLoaded(4, 0, cultureCount, true);
          return;
      }
  
//SM end

      try {
        MemoryStream ms = session.memoryStream;
        ms.Position = 0;
        BinaryWriter bw = new BinaryWriter(ms, Encoding.UTF8);

        // 121 : DataObjects.NET 2.3 comprehensive FastLoadData format
        // 221 : DataObjects.NET 2.3 compact FastLoadData format
        //SM begin 122 :  SM flat FastLoadData format SM end
        bool comprehensiveFormat = (session.domain.fastLoadDataFormat == DomainFastLoadDataFormat.Comprehensive);
        bool compromiseFormat = (session.domain.fastLoadDataFormat == DomainFastLoadDataFormat.Compromise);
        if (compromiseFormat)
            ms.WriteByte((byte)122);
        else
            ms.WriteByte((byte)(comprehensiveFormat ? 121 : 221));
        if (compromiseFormat)
            bw.Write(type.FastLoadDataHash);
        for (int fieldIndex = cSysPropertiesCount; fieldIndex < fieldCount; fieldIndex++)
        {
          Field f = fields[fieldIndex];
          if (f.UsesFastLoadData) {
            bool btr = f.Translatable;
            int fieldCultureCount = btr ? cultureCount : 1;
            if (comprehensiveFormat)
            {
                bw.Write(f.Name);
                bw.Write(f.FieldTypeID);
                bw.Write((byte)fieldCultureCount);
            }
            int valueIndex = fieldIndex * cultureCount;
            for (int cultureIndex = 0; cultureIndex < fieldCultureCount; cultureIndex++, valueIndex++)
              f.InternalValueToStream(session, this, btr ? cultures[cultureIndex] : null, properties.GetValue(valueIndex), bw);
          }
        }
   
        byte[] fastLoadData = new byte[ms.Position];
        ms.Position = 0;
        ms.Read(fastLoadData, 0, fastLoadData.Length);
        properties.SetValue(4, 0, cultureCount, fastLoadData);
        SetIsChanged(true);
        properties.SetIsChanged(4, 0, cultureCount, true);
        properties.SetIsLoaded(4, 0, cultureCount, true);
      }
      catch {
        properties.SetValue(4, 0, cultureCount, null);
        SetIsChanged(true);
        properties.SetIsChanged(4, 0, cultureCount, true);
        properties.SetIsLoaded(4, 0, cultureCount, true);
      }
    }
    
      private static readonly log4net.ILog log = log4net.LogManager.GetLogger(typeof(DataObject));
    /// <summary>
    /// Extracts properties from <see cref="FastLoadData"/> value.
    /// </summary>
    private bool UnpackFastLoadData()
    {
      FieldCollection fields = type.Fields;
      CultureCollection cultures = session.domain.cultures;
      int fieldCount = fields.Count;
      int cultureCount = cultures.Count;

      byte[] data = properties.GetValue(4, 0, cultureCount) as byte[];
      if (data==null || data.Length==0) {
        // treat array of zero size just like null value
        properties.SetValue(4, 0, cultureCount, null);
        return false;
      }

      MemoryStream ms = new MemoryStream(data);
      BinaryReader br = new BinaryReader(ms, Encoding.UTF8);
      try {
        // 121 : DataObjects.NET 2.3 comprehensive FastLoadData format
        // 221 : DataObjects.NET 2.3 compact FastLoadData format
        //SM begin 122 :  SM flat FastLoadData format SM end
        int format = ms.ReadByte();
        if (format != 121 && format != 221 && format != 122)
        {
            log.Debug("Illegal FastLoadData value. Incorrect format.");
          throw new FastLoadDataException("Illegal FastLoadData value.");
        }
        if (format == 122)
        {
            if (br.ReadByte() != type.FastLoadDataHash)
            {
                log.Debug("Illegal FastLoadData value. Type " + type.Name + " was changed");
                throw new FastLoadDataException("Illegal FastLoadData value.");
            }
        }

        for (int fieldIndex = cSysPropertiesCount; fieldIndex < fieldCount; fieldIndex++)
        {
            Field f = fields[fieldIndex];
            if (f.UsesFastLoadData)
            {
                bool btr = f.Translatable;
                int fieldCultureCount = btr ? cultureCount : 1;
                if (format == 121)
                {
                    string fastName = br.ReadString();
                    byte fastType = br.ReadByte();
                    if (fastName != f.Name || fastType != f.FieldTypeID)
                    {
                        log.Debug("Illegal FastLoadData value. Expecting field " + f.Name + " but was different");
                        throw new FastLoadDataException("Illegal FastLoadData value.");
                    }
                    else
                    {
                        int readCulture = (int)br.ReadByte();
                        if (readCulture == 0)
                            continue;
                        if (readCulture != fieldCultureCount)
                        {
                            log.Debug("Illegal FastLoadData value. Expecting field " + f.Name + " but was different");
                            throw new FastLoadDataException("Illegal FastLoadData value.");
                        }
                    }
                }
                int valueIndex = fieldIndex * cultureCount;
                for (int cultureIndex = 0; cultureIndex < fieldCultureCount; cultureIndex++, valueIndex++)
                {
                    object iValue = f.InternalValueFromStream(session, this, btr ? cultures[cultureIndex] : null, br);
                    IDisposable dsi = properties.GetValue(valueIndex) as IDisposable;
                    if (dsi != null)
                        dsi.Dispose();
                    IHasStableInternalValueField sivField = f as IHasStableInternalValueField;
                    if (sivField != null)
                        sivField.UpdateInternalValue(properties.GetValue(valueIndex), iValue);
                    else
                        properties.SetValue(valueIndex, iValue);
                    IDataObjectFieldValue fi = iValue as IDataObjectFieldValue;
                    if (fi != null)
                        fi.Attach(this, f, btr ? cultures[cultureIndex] : null);
                    if (iValue != EmptyMarker.Value)
                    {
                        properties.SetIsLoaded(valueIndex, true);
                        properties.SetIsChanged(valueIndex, false);
                    }
                }
            }
        }
        return true;
      }
      catch {
        properties.SetValue(4, 0, cultureCount, null);
        return false;
      }
      finally {
        ms.Close();
      }
    }
    
    /// <summary>
    /// Updates inconsistent <see cref="FastLoadData"/> and <see cref="Permission"/> 
    /// data of the instance (e.g. when <see cref="FastLoadData"/> is empty or 
    /// <see cref="Permissions"/> contain some allow\deny <see cref="PermissionSet"/>s 
    /// for a <see cref="Principal"/> that currently doesn't exist).
    /// </summary>
    [NotOverridable]
    [Transactional(TransactionMode.ExistingTransactionRequired)]
    public virtual void UpdateInconsistentData()
    {
      if (Session.IsReadOnly)
        return;
      DisableSecurity();
      try {
        int cCnt = session.domain.cultures.Count;
//SM BEGIN
        if ((Domain.DatabaseOptions & DomainDatabaseOptions.DisableFastLoadData) == 0)
        {

            if (State == DataObjectState.Persistent)
            {
                if (!this.Type.IsFlat)
                {
                    byte[] fld = properties.GetValue(4, 0, cCnt) as byte[];
                    if (!(fld != null && fld.Length > 0 && (fld[0] == 221 || fld[0] == 121 || fld[0] == 122)))
                        SetIsChanged(true);
                }
            }
        }
//SM end
        if (permissions!=null && permissions.Inconsistent) {
          permissions.Inconsistent = false;
          SetIsChanged(true);
          properties.SetIsChanged(3,0,cCnt,true);
        }
        if (IsChanged)
          TryPersist();
      }
      finally {
        EnableSecurity();
      }
    }
    
    /// <summary>
    /// Updates inconsistent <see cref="FastLoadData"/> and <see cref="Permission"/> 
    /// data of the instance (e.g. when <see cref="FastLoadData"/> is empty or 
    /// <see cref="Permissions"/> contain some allow\deny <see cref="PermissionSet"/>s 
    /// for a <see cref="Principal"/> that currently doesn't exist) with
    /// the specified <paramref name="probability"/>.
    /// </summary>
    /// <param name="probability">A probability (in percents) of update. 
    /// Used only when update is necessary.</param>
    [NotOverridable]
    [Transactional(TransactionMode.Disabled)]
    public void UpdateInconsistentData(int probability)
    {
      if (probability>=100)
        UpdateInconsistentData();
      else if (probability<=0)
        return;
      else
        if (session.random.Next(100)<probability)
          UpdateInconsistentData();
    }
    

    /// <summary>
    /// Removes the instance and all 
    /// <see cref="ContainedAttribute">contained</see> instances.
    /// <seealso cref="Session.RemoveObjects"/>
    /// <seealso cref="RemovalQueue"/>
    /// <seealso cref="DataObjectRemovalQueue"/>
    /// <seealso cref="OnRemove"/>
    /// <seealso cref="OnRemoved"/>
    /// </summary>
    [NotOverridable]
    [Transactional(TransactionMode.TransactionRequired)]
    public virtual void Remove()
    {
      session.InnerRemoveObjects(new long[] {this.ID});
    }

    internal void ConvertToRemoved()
    {
      try { 
        SetIsChanged(false);
        session.UnregisterUpdatedInstance(this);
        state = DataObjectState.Removed;
        if (permissions!=null)
          permissions.ConvertToRemovedPermissionCache();

        FieldCollection fields = type.Fields;
        CultureCollection cultures = session.domain.cultures;
        int cnt = fields.Count;
        int cCnt = cultures.Count;
        int k = cSysPropertiesCount*cCnt;
        for (int i = cSysPropertiesCount; i<cnt; i++) {
          int ccCnt = fields[i].Translatable ? cCnt : 1;
          for (int j = 0; j < ccCnt; j++) {
            object o = properties.GetValue(k);
            IDisposable dsi = o as IDisposable;
            if (dsi!=null) 
              dsi.Dispose();
            properties.SetValue(k,null);
            properties.SetIsChanged(k,false);
            properties.SetIsLoaded(k,false);
            k++;
          }
          if (ccCnt==1)
            k += cCnt-1;
        }
      } 
      catch (Exception) {};
    }

    /// <summary>
    /// Tries to aquire a lock of <paramref name="lockType"/> on the instance.
    /// </summary>
    /// <param name="lockType">Type of lock to aquire.</param>
    [NotOverridable]
    [Transactional(TransactionMode.ExistingTransactionRequired)]
    public virtual void Lock(LockType lockType)
    {
      switch (State) {
      case DataObjectState.New:
        Persist();
        lastLockType = LockType.Exclusive;
        return;
      case DataObjectState.Removed:
        throw new InstanceIsRemovedException();
      }

      if (lastLockType>=lockType)
        return;
      lastLockType = lockType;
      
      int cCnt = session.domain.cultures.Count;
      
      long id        = (long)properties.GetValue(0,0,cCnt);
      int  versionID = (int)properties.GetValue(2,0,cCnt);
      try {
        session.persister.LockDataObject(type.RelatedView, id, versionID, lockType);
      }
      catch (Exception e) {
        throw session.utils.SubstituteException(e);
      }
    }
    
    /// <summary>
    /// Returns <see cref="String"/> representation of current instance.
    /// </summary>
    /// <returns>The <see cref="String"/> representation of this instance.</returns>
    /// <remarks>
    /// This method returns <see cref="String"/> in the following format:
    /// "[ShortenedTypeName], ID=[ID], VersionID=[VersionID]".
    /// </remarks>
    [Transactional(TransactionMode.Disabled)]
    public override string ToString()
    {
      return ToDebugString();
    }
    
    /// <summary>
    /// Returns debug <see cref="String"/> of current instance that is used for trace.
    /// </summary>
    /// <returns>Debug <see cref="String"/> of current instance.</returns>
    [Transactional(TransactionMode.Disabled)]
    protected internal virtual string ToDebugString()
    {
      return Type.ShortenedName +
             ", ID=" + GetInternalID() +
             ", VersionID=" + GetInternalVersionID();
    }

    
    // Serialization

    internal void GetDataObjectData(Serializer serializer, 
                                    SerializationInfo info, StreamingContext context)
    {
      switch (State) {
      case DataObjectState.New:
        Persist();
        break;
      case DataObjectState.Removed:
        if (serializer.pass==SerializerPass.Last) {
          info.SetType(typeof(DataObjectReference));
          info.AddValue("ID",0);
          info.AddValue("Type",type.Name);
          OnSerializeIdentity(serializer, info, context);
          session.OnDataObjectSerializeIdentity(this, serializer, info, context);
        }
        return;
      default:
        LoadAll();
        break;
      }
      
      FieldCollection fields = type.Fields;
      CultureCollection cultures = session.domain.cultures;
      int cnt = fields.Count;
      int cCnt = cultures.Count;

      long id = (long)properties.GetValue(0,0,cCnt);
      bool bIncR  = (serializer.serializationOptions & SerializationOptions.IncludeReferedInstances)!=0;
      bool bIncC  = (!bIncR) && ((serializer.serializationOptions & SerializationOptions.IncludeContainedInstances)!=0);
      bool bIncTO = !(bIncR || bIncC);
      bool bIncE  = (serializer.serializationOptions & SerializationOptions.IncludeExternalReferences)!=0;
      bool bUseR  = (serializer.serializationOptions & SerializationOptions.AlwaysUseReferences)!=0;
      bool bIncP  = (serializer.serializationOptions & SerializationOptions.IncludePermissions)!=0;
      Hashtable hInclude = serializer.hInclude;
      // long[] ids = null;

      if (serializer.pass==SerializerPass.Detect) {
        // Detection pass
        if (bIncR) return; // impossible

        // Top instance
        hInclude[id] = true;
        if (bIncTO) return;
        
        // Contained instances
        for (int i = 0; i<cnt; i++) {
          Field f = fields[i];
          IReferenceHolderFieldInt rhf = f as IReferenceHolderFieldInt;
          if (rhf!=null) {
            if (f.Translatable) {
              for (int j = 0; j<cCnt; j++) {
                Culture c = cultures[j];
                long[] ids = rhf.GetContainedIDs(this, c, properties.GetValue(i,j,cCnt));
                if (ids != null)
                  foreach (long curID in ids)
                    info.AddValue("Instance-"+curID, session[curID]);
              }
            }
            else {
              long[] ids = rhf.GetContainedIDs(this, null, properties.GetValue(i,0,cCnt));
              if (ids != null)
                foreach (long curID in ids)
                  info.AddValue("Instance-"+curID, session[curID]);
            }
          }
        }
        return;
      }

      // Serialization

      if (this is ISecurityRoot) {
        // ISecurityRoot is always serialized as reference
        info.SetType(typeof(DataObjectReference));
        info.AddValue("ID", id);
        info.AddValue("Type",type.Name);
        OnSerializeIdentity(serializer, info, context);
        session.OnDataObjectSerializeIdentity(this, serializer, info, context);
        if (serializer.hProcessed[id]==null) {
          serializer.lastOperationReferenceCount++;
          serializer.hProcessed[id] = this;
        }
        return;
      }
      if (!bIncR && hInclude[id]==null) {
        if (bIncE) {
          info.SetType(typeof(DataObjectReference));
          info.AddValue("ID", id);
          info.AddValue("Type",type.Name);
          OnSerializeIdentity(serializer, info, context);
          session.OnDataObjectSerializeIdentity(this, serializer, info, context);
          if (serializer.hProcessed[id]==null) {
            serializer.lastOperationReferenceCount++;
            serializer.hProcessed[id] = this;
          }
        }
        else {
          info.SetType(typeof(DataObjectReference));
          info.AddValue("ID", 0);
          info.AddValue("Type",type.Name);
          OnSerializeIdentity(serializer, info, context);
          session.OnDataObjectSerializeIdentity(this, serializer, info, context);
        }
        return;
      }
      else {
        if (bUseR) {
          info.SetType(typeof(DataObjectReference));
          info.AddValue("ID", id);
          info.AddValue("Type",type.Name);
          OnSerializeIdentity(serializer, info, context);
          session.OnDataObjectSerializeIdentity(this, serializer, info, context);
          if (serializer.hProcessed[id]==null) {
            serializer.lastOperationReferenceCount++;
            serializer.hProcessed[id] = this;
          }
          return;
        }
        else {
          //info.SetType(Type.SourceType);
          info.AddValue("ID", id);
          info.AddValue("Type",type.Name);
          if (serializer.hProcessed[id]==null) {
            serializer.lastOperationInstanceCount++;
            serializer.hProcessed[id] = this;
          }
        }
      }
      
      Hashtable hFields = new Hashtable();      
      for (int i = 0; i<cnt; i++) {
        Field f = fields[i];
        if ((i<cSysPropertiesCount && i!=3) || f.NotSerializable)
          continue;
        if (i==3 && !bIncP)
          continue;
        hFields[f.Name] = true;
      }

      OnSerializing(serializer,info,context,hFields);
      session.OnDataObjectSerializing(this,serializer,info,context,hFields);
      
      for (int i = 0; i<cnt; i++) {
        Field f = fields[i];
        if ((i<cSysPropertiesCount && i!=3) || f.NotSerializable || (!true.Equals(hFields[f.Name])))
          continue;
        ICustomSerializableField csf = f as ICustomSerializableField;

        if (f.Translatable) {
          for (int j = 0; j<cCnt; j++) {
            Culture c = cultures[j];
            object obj = properties.GetValue(i,j,cCnt);
            if (csf!=null)
              obj = csf.ConvertInternalToSerializable(this, c, obj);
            else
              obj = f.ConvertInternalToValue(this, c, obj);
            info.AddValue(f.Name+"-"+c.Name,obj);
          }
        }
        else {
          object obj = properties.GetValue(i,0,cCnt);
          if (csf!=null)
            obj = csf.ConvertInternalToSerializable(this, null, obj);
          else
            obj = f.ConvertInternalToValue(this, null, obj);
          info.AddValue(f.Name,obj);
        }
      }
    }

    internal void SetDataObjectData(Serializer serializer, 
                                    SerializationInfo info, StreamingContext context)
    {
      if (serializationInfo==null || serializationInfo.Serializer!=serializer)
        throw new SerializationException(
          "Attempt to deserialize an object second time - " + 
          "most likely its OnCreateDeserializable method initiates one more pass of deserialization.");
      serializationInfo.SerializationInfo = info;
      serializationInfo.StreamingContext  = context;
    }
    
    /// <summary>
    /// Runs when the entire object graph has been deserialized.
    /// </summary>
    /// <param name="sender">The object that initiated the callback. The functionality for the this parameter is not currently implemented.</param>
    void IDeserializationCallback.OnDeserialization(object sender)
    {
      if (serializationInfo==null || serializationInfo.SerializationInfo==null)
        throw new SerializationException("OnDeserialization method can't be called manually.");
      Serializer serializer    = serializationInfo.Serializer;
      SerializationInfo info   = serializationInfo.SerializationInfo;
      StreamingContext context = serializationInfo.StreamingContext;
      serializationInfo.SerializationInfo       = null;
      serializationInfo.DeserializedPermissions = null;

      delayUpdateDepth++;
      try {
        bool bIncP = (serializer.deserializationOptions & DeserializationOptions.DeserializePermissions)!=0;

        Hashtable hFields = new Hashtable();
        FieldCollection fields = type.Fields;
        CultureCollection cultures = session.domain.cultures;
        int cnt = fields.Count;
        int cCnt = cultures.Count;
        
        for (int i = 0; i<cnt; i++) {
          Field f = fields[i];
          if ((i<cSysPropertiesCount && i!=3) || f.NotSerializable)
            continue;
          if (i==3 && !bIncP)
            continue;
          hFields[f.Name] = true;
        }

        OnDeserializing(serializer,info,context,hFields);
        session.OnDataObjectDeserializing(this,serializer,info,context,hFields);

        for (int i = 0; i<cnt; i++) {
          Field f = fields[i];
          if ((i<cSysPropertiesCount && i!=3) || f.NotSerializable || (!true.Equals(hFields[f.Name])))
            continue;
          if (i==3) {
            // Permissions
            if (bIncP) try {
              bool found = false;
              foreach (SerializationEntry entry in info)
                if (entry.Name==f.Name) {
                  found = true;
                  break;
                }
              if (found)
                serializationInfo.DeserializedPermissions =
                  info.GetValue(f.Name,typeof(AccessControlList)) as AccessControlList;
              else
                serializationInfo.DeserializedPermissions = new AccessControlList();
            } 
            catch {
              serializationInfo.DeserializedPermissions = new AccessControlList();
              throw;
            }
            continue;
          }
          IReferenceHolderFieldInt rhf = f as IReferenceHolderFieldInt;
          ICustomSerializableField csf = f as ICustomSerializableField;
          IChangesTrackingField    ctf = f as IChangesTrackingField;
          if (rhf!=null)
            Persist();
          if (f.Translatable) {
            for (int j = 0; j<cCnt; j++) {
              Culture c = cultures[j];
              try {
                object oValue = properties.GetValue(i,j,cCnt);
                object sValue = info.GetValue(f.Name+"-"+c.Name, 
                                              csf!=null ? csf.GetSerializableType() : f.SourceType);
                object iValue;
                if (csf!=null)
                  iValue = csf.ConvertSerializableToInternal(this, c, sValue, oValue);
                else
                  iValue = f.ConvertValueToInternal(this, c, sValue);
                if (ctf!=null)
                  ctf.MarkAsChanged(this, c, iValue);
                properties.SetValue(i,j,cCnt,iValue);
                properties.SetIsLoaded(i,j,cCnt,true);
                if (ctf!=null) {
                  if (ctf.IsChanged(this, c, iValue)) {
                    properties.SetIsChanged(i,j,cCnt,true);
                    SetIsChanged(true);
                    session.RegisterUpdatedInstance(this);
                  }
                }
                else if (oValue!=iValue && !f.CheckValuesEquality(oValue, iValue)) {
                  properties.SetIsChanged(i,j,cCnt,true);
                  SetIsChanged(true);
                  session.RegisterUpdatedInstance(this);
                }
              }
              catch (SerializationException e) {
                OnPropertyDeserializationError(serializer,info,context,f.Name,c,e);
                session.OnDataObjectPropertyDeserializationError(this,serializer,info,context,f.Name,c,e);
              }
            }
          }
          else {
            try {
              object oValue = properties.GetValue(i,0,cCnt);
              object sValue = info.GetValue(f.Name, 
                                            csf!=null ? csf.GetSerializableType() : f.SourceType);
              object iValue;
              if (csf!=null)
                iValue = csf.ConvertSerializableToInternal(this, null, sValue, oValue);
              else
                iValue = f.ConvertValueToInternal(this, null, sValue);
              if (ctf!=null)
                ctf.MarkAsChanged(this, null, iValue);
              properties.SetValue(i,0,cCnt,iValue);
              properties.SetIsLoaded(i,0,cCnt,true);
              if (ctf!=null) {
                if (ctf.IsChanged(this, null, iValue)) {
                  properties.SetIsChanged(i,0,cCnt,true);
                  SetIsChanged(true);
                  session.RegisterUpdatedInstance(this);
                }
              }
              else if (oValue!=iValue && !f.CheckValuesEquality(oValue, iValue)) {
                properties.SetIsChanged(i,0,cCnt,true);
                SetIsChanged(true);
                session.RegisterUpdatedInstance(this);
              }
            }
            catch (SerializationException e) {
              OnPropertyDeserializationError(serializer,info,context,f.Name,null,e);
              session.OnDataObjectPropertyDeserializationError(this,serializer,info,context,f.Name,null,e);
            }
          }
        }
        OnDeserialized(serializer);
        session.OnDataObjectDeserialized(this, serializer);
      }
      finally {
        delayUpdateDepth--;
      }
    }
    
    // Security
    
    /// <summary>
    /// Gets the <see cref="Session.SecurityRoot"/> object.
    /// <seealso cref="ISecurityRoot"/>
    /// <seealso cref="SecurityRoot"/>
    /// </summary>
    /// <returns><see cref="Session.SecurityRoot"/> object.</returns>
    /// <remarks>
    /// <para>
    /// You can find more information about the whole DataObjects.NET
    /// security system <see cref="AccessControlList">here</see>.
    /// </para>
    /// </remarks>
    [NotPersistent]
    [NotOverridable]
    [Transactional(TransactionMode.Disabled)]
    public DataObject SecurityRoot {
      get {
        return session.systemObjects.SecurityRoot;
      }
    }

    /// <summary>
    /// Gets the security parent object for this <see cref="DataObject"/> instance.
    /// This property is used by the security system during permission
    /// demands.
    /// </summary>
    /// <returns>Security parent object for this <see cref="DataObject"/> instance.</returns>
    /// <remarks>
    /// <para>
    /// <see cref="DataObject"/>'s implementation of this property always
    /// returns <see cref="SecurityRoot"/> property value.
    /// </para>
    /// <para>
    /// Most probable that you'll implement <see cref="SecurityParent"/> 
    /// property as "mirror" of some persistent property. In this case you
    /// should override <see cref="OnPropertyChanged"/> event in this type, and
    /// overriding method should invoke <see cref="SecurityParentChanged"/> on 
    /// each change of corresponding persistent property.
    /// </para>
    /// <note type="note">It's strongly recommended to correctly override 
    /// this property!</note>
    /// <note type="note">Any <see cref="ISecurityRoot"/> object should return
    /// <see langword="null"/> from this property. Any other object shouldn't
    /// return <see langword="null"/> from this property.
    /// </note>
    /// <note type="note">DataObjects.NET can't track <see cref="SecurityParent"/> 
    /// property changes (because this is not a persistent property), so it's
    /// required to notify it about that by calling <see cref="SecurityParentChanged"/> 
    /// method.
    /// </note>
    /// <para>
    /// You can find more information about the whole DataObjects.NET
    /// security system <see cref="AccessControlList">here</see>.
    /// </para>
    /// </remarks>
    [NotPersistent]
    [Transactional(TransactionMode.Disabled)]
    public virtual DataObject SecurityParent {
      get {
        return SecurityRoot;
      }
    }

    /// <summary>
    /// Gets the collection (<see cref="QueryResult"/>) of children objects 
    /// for this <see cref="DataObject"/> instance.
    /// This property is used by the security system during changing child object
    /// permissions (see <see cref="AccessControlList.ResetChildrenPermissions"/>). 
    /// </summary>
    /// <remarks>
    /// <para>
    /// You should correctly override this property to allow the security
    /// system to change child object permissions properly.
    /// But you can omit this if you're going to never use this feature - 
    /// e.g. when you want to perform this action manually.
    /// </para>
    /// <para>
    /// This property can return <see langword="null"/> value (this should
    /// be considered as absence of any child objects).
    /// </para>
    /// <para>
    /// You can find more information about the whole DataObjects.NET
    /// security system <see cref="AccessControlList">here</see>.
    /// </para>
    /// </remarks>
    [NotPersistent]
    [Transactional(TransactionMode.Disabled)]
    public virtual QueryResult SecurityChildren {
      get {
        return null;
      }
    }

    /// <summary>
    /// This method should be invoked when <see cref="SecurityParent"/>
    /// value is changed. 
    /// </summary>
    /// <remarks>
    /// <note type="note">DataObjects.NET can't track <see cref="SecurityParent"/> 
    /// property changes (because this is not a persistent property), so it's
    /// required to notify it about that by calling this method.</note>
    /// <para>
    /// This method does the following:
    /// </para>
    /// <para>
    /// 1) Invokes <see cref="PermissionsChanged"/> method
    ///    to discard all cached permissions data of the current
    ///    instance and all dependent instances;
    /// </para>
    /// <para>
    /// 2) Invokes <see cref="OnSecurityParentChanged"/> method.
    /// </para>
    /// <para>
    /// E.g. most probable that you'll implement <see cref="SecurityParent"/> 
    /// property as "mirror" of some persistent property. In this case you
    /// should override <see cref="OnPropertyChanged"/> event in this type, and
    /// overriding method should invoke <see cref="SecurityParentChanged"/> on 
    /// each change of corresponding persistent property.
    /// </para>
    /// <para>
    /// You can find more information about the whole DataObjects.NET
    /// security system <see cref="AccessControlList">here</see>.
    /// </para>
    /// </remarks>
    [NotOverridable]
    [Transactional(TransactionMode.Disabled)]
    protected virtual void SecurityParentChanged()
    {
      // This method doesn't works during the instance deserialization
      if (IsDeserializing)
        return;
        
      if (permissions!=null)
        permissions.securityParent = null;
      PermissionsChanged();
      OnSecurityParentChanged();
    }

    [Transactional(TransactionMode.Disabled)]
    private void SecurityParentChangedOnDeserialization()
    {
      if (permissions!=null)
        permissions.securityParent = null;
      PermissionsChangedOnDeserialization();
      OnSecurityParentChanged();
    }
    
    // Permissions caching - related methods
    
    /// <summary>
    /// This method is invoked when any cached permissions data
    /// of the current instance (and all dependent instances) 
    /// should be discarded.
    /// Normally you shouldn't invoke it manually.
    /// </summary>
    /// <remarks>
    /// <para>
    /// You can find more information about the whole DataObjects.NET
    /// security system <see cref="AccessControlList">here</see>.
    /// </para>
    /// </remarks>
    [NotOverridable]
    [Transactional(TransactionMode.Disabled)]
    protected internal virtual void PermissionsChanged()
    {
      // This method doesn't works during the instance deserialization
      if ((permissions!=null && permissions.effectivePermissionsTransactionContext==null) || 
          IsDeserializing)
        return;
  
      if (permissions!=null)
        permissions.effectivePermissionsTransactionContext = null;
      if (permissionsChangedEventSource!=null)
        permissionsChangedEventSource.RaiseEvent(this, null); 
    }

    [Transactional(TransactionMode.Disabled)]
    private void PermissionsChangedOnDeserialization()
    {
      if (permissionsChangedEventSource==null ||
          permissions.effectivePermissionsTransactionContext==null)
        return;

      if (permissions!=null)
        permissions.effectivePermissionsTransactionContext = null;
      permissionsChangedEventSource.RaiseEvent(this, null); 
    }

    private void PermissionsChangedCallbackMethod(object sender, EventArgs e)
    {
      PermissionsChanged();
    }

    // Used to keep a strong reference to EventHandler(this.PermissionsChangedCallbackMethod)
    internal EventHandler PermissionsChangedCallbackEventHandler {
      get {
        if (permissionsChangedCallbackEventHandler==null)
          permissionsChangedCallbackEventHandler = new EventHandler(this.PermissionsChangedCallbackMethod);
        return permissionsChangedCallbackEventHandler;
      }
    }



    // Permission checking

    /// <summary>
    /// Demands the permission.
    /// You can override this method to perform custom actions
    /// on <see cref="IPermission">permission</see> demand.
    /// <seealso cref="SessionBoundObject.DisableSecurity"/>
    /// <seealso cref="SessionBoundObject.EnableSecurity"/>
    /// <seealso cref="DataObjects.NET.Security"/>
    /// <seealso cref="DataObjects.NET.Security.Permissions"/>
    /// </summary>
    /// <param name="permission">Permission that should be demanded.</param>
    /// <remarks>
    /// <para>
    /// This method throws <see cref="SecurityException"/> if the pemission
    /// isn't allowed.
    /// </para>
    /// <note type="note">It's not always required that checked permission
    /// should be directly allowed (i.e. contained in the effective permission 
    /// set. 
    /// E.g. <see cref="ReadPermission"/> will be allowed indirectly, if one 
    /// of the following permissions is allowed: <see cref="ChangePermission"/>, 
    /// <see cref="OwnerPermission"/>, <see cref="AdministrationPermission"/>. 
    /// See 
    /// <see cref="IPermission.GrantedIfGrantedAnyOf">IPermission.GrantedIfGrantedAnyOf</see> 
    /// property description for additional information.
    /// </note>
    /// <para>
    /// You can find more information about the whole DataObjects.NET
    /// security system <see cref="AccessControlList">here</see>.
    /// </para>
    /// </remarks>
    [Transactional(TransactionMode.Disabled)]
    public virtual void Demand(IPermission permission)
    {
      if (!IsAllowed(permission))
        throw new SecurityException(String.Format(
                                      "Permission Demand failed for: {0}.", permission.ToString()), permission);
    }

    /// <summary>
    /// Checks if the permission is allowed.
    /// You can override this method to perform custom actions
    /// on <see cref="IPermission">permission</see> check.
    /// <seealso cref="SessionBoundObject.DisableSecurity"/>
    /// <seealso cref="SessionBoundObject.EnableSecurity"/>
    /// <seealso cref="DataObjects.NET.Security"/>
    /// <seealso cref="DataObjects.NET.Security.Permissions"/>
    /// </summary>
    /// <param name="permission">Permission that should be checked.</param>
    /// <returns><see langword="True"/> if the permission is allowed; 
    /// otherwise, <see langword="false"/>.</returns>
    /// <remarks>
    /// <note type="note">It's not always required that checked permission
    /// should be directly allowed (i.e. contained in the effective permission 
    /// set. 
    /// E.g. <see cref="ReadPermission"/> will be allowed indirectly, if one 
    /// of the following permissions is allowed: <see cref="ChangePermission"/>, 
    /// <see cref="OwnerPermission"/>, <see cref="AdministrationPermission"/>. 
    /// See 
    /// <see cref="IPermission.GrantedIfGrantedAnyOf">IPermission.GrantedIfGrantedAnyOf</see> 
    /// property description for additional information.
    /// </note>
    /// <para>
    /// You can find more information about the whole DataObjects.NET
    /// security system <see cref="AccessControlList">here</see>.
    /// </para>
    /// </remarks>
    [Transactional(TransactionMode.Disabled)]
    public virtual bool IsAllowed(IPermission permission)
    {
      return ProtectedIsAllowed(permission);
    }
    
    /// <summary>
    /// Checks if the permission is allowed.
    /// This method isn't overrideable, so its behavior is always
    /// defined by the DataObjects.NET security system.
    /// <seealso cref="SessionBoundObject.DisableSecurity"/>
    /// <seealso cref="SessionBoundObject.EnableSecurity"/>
    /// <seealso cref="DataObjects.NET.Security"/>
    /// <seealso cref="DataObjects.NET.Security.Permissions"/>
    /// </summary>
    /// <param name="permission">Permission that should be checked.</param>
    /// <returns><see langword="True"/> if the permission is allowed; 
    /// otherwise, <see langword="false"/>.</returns>
    /// <remarks>
    /// <note type="note">It's not always required that checked permission
    /// should be directly allowed (i.e. contained in the effective permission 
    /// set. 
    /// E.g. <see cref="ReadPermission"/> will be allowed indirectly, if one 
    /// of the following permissions is allowed: <see cref="ChangePermission"/>, 
    /// <see cref="OwnerPermission"/>, <see cref="AdministrationPermission"/>. 
    /// See 
    /// <see cref="IPermission.GrantedIfGrantedAnyOf">IPermission.GrantedIfGrantedAnyOf</see> 
    /// property description for additional information.
    /// </note>
    /// <para>
    /// You can find more information about the whole DataObjects.NET
    /// security system <see cref="AccessControlList">here</see>.
    /// </para>
    /// </remarks>
    [Transactional(TransactionMode.Disabled)]
    protected bool ProtectedIsAllowed(IPermission permission)
    {
      Assembly asm = typeof(String).Assembly;
      string runtimeVersion = asm.ImageRuntimeVersion;
      if (runtimeVersion == "v2.0.50215")
      { 
        return true;
      }
      if (session.transaction!=null || session.IsOfflineMode)
        return InnerProtectedIsAllowed(permission);

      // Automatic Transactions support code
      TransactionController tc = session.CreateTransactionController( TransactionMode.TransactionRequired);
      Reprocess:
      try {
        bool r = InnerProtectedIsAllowed(permission);
        tc.Commit();
        return r;
      }
      catch (Exception e) {
        if (tc.Rollback(e, true))
          goto Reprocess;
        throw;
      }
    }
    private bool InnerProtectedIsAllowed(IPermission permission)
    {
      if (State==DataObjectState.Removed)
        throw new InstanceIsRemovedException();

      if (ProtectedPermissions!=null)
        return ProtectedPermissions.IsAllowed(permission);
      else
        return !session.IsSecurityEnabled || SecurityParent.IsAllowed(permission);
    }


    // IFtObject support code

    /// <summary>
    /// This method can be called only for <see cref="IFtObject"/>
    /// implementors.
    /// Invalidates full-text record associated with the current instance.
    /// </summary>
    /// <remarks>
    /// <para>
    /// Invalidates full-text record associated with the current 
    /// instance by setting its 
    /// <see cref="IFtObject.FtRecordIsUpToDate"/> property value to 
    /// <see langword="false"/> - to make full-text indexer to
    /// update associated <see cref="FtRecord"/> object further. 
    /// </para>
    /// <para>
    /// Normally you shouldn't invoke this method manually or override it 
    /// - it's automatically invoked in <see cref="OnPropertyChanged"/>, 
    /// <see cref="OnPropertyContentChanged"/> and similar methods.
    /// </para>
    /// </remarks>
    [Transactional(TransactionMode.Disabled)]
    protected virtual void InvalidateFtData()
    {
      if (!(this is IFtObject))
        throw new InvalidOperationException(
          "This method can be called on IFtObject instances only.");
      if (State==DataObjectState.Removed)
        return;
      DisableSecurity();
      try {
        SetProperty("FtRecordIsUpToDate", null, false);
      }
      finally {
        EnableSecurity();
      }
    }
    

    // Versionizing support
    
    /// <summary>
    /// Returns information about all stored versions
    /// of a this <see cref="DataObject"/> instance.
    /// <seealso cref="DataObjects.NET.Domain.DatabaseOptions"/>
    /// <seealso cref="DataObjects.NET.Session.BrowsePast"/>
    /// </summary>
    /// <returns><see cref="VersionInfo"/> objects describing
    /// versions of this instance.</returns>
    /// <remarks>
    /// Note that this method works only if 
    /// <see cref="DataObjects.NET.Domain.DatabaseOptions"/>
    /// property is set to <see langword="true"/>,
    /// otherwise it returns <see langword="null"/>.
    /// </remarks>
    [NotOverridable]
    [Transactional(TransactionMode.TransactionRequired)]
    public virtual VersionInfo[] GetVersionInfo()
    {
      if ((Domain.DatabaseOptions & DomainDatabaseOptions.EnableVersionizing)==0)
        return null;
      try {
        return session.persister.GetDataObjectVersionInfo(this.ID);
      } catch (Exception e) {
        throw session.utils.SubstituteException(e);
      }
    }

    // Initializers

    /// <summary>
    /// Initializes the instance (this method is called during construction).
    /// </summary>
    /// <param name="type">Type of the instance.</param>
    /// <param name="session">Session, to which this instance belongs.</param>
    /// <param name="instantiationInfo">Instantiation info - a set 
    /// <see cref="DataObject"/> properties fetched from 
    /// <see cref="DataObject"/>-related table by the ID of instance.</param>
    internal void LoadInstance(ObjectModel.Type type, Session session, DataObjectInstantiationInfo instantiationInfo)
    {
      this.type        = type;
      this.session     = session;
      this.transactionContext = instantiationInfo.TransactionContext;
      
      state            = DataObjectState.Removed;
      SetIsChanged(false);
      persistDepth     = 0;
      delayUpdateDepth = 0;

      FieldCollection fields = type.Fields;
      CultureCollection cultures = session.domain.cultures;
      int fieldCount  = fields.Count;
      int cultureCount = cultures.Count;
      this.properties  = new DataObjectProperties(fieldCount,cultureCount);

      // Fields init
      int k = cSysPropertiesCount*cultureCount;
      for (int i = cSysPropertiesCount; i<fieldCount; i++) {
        Field f  = fields[i];
        bool rof = f is IReadOnlyField;
        if (f.Translatable) {
          if (rof) {
            for (int j = 0; j<cultureCount; j++) {
              Culture c = cultures[j];
              IDataObjectFieldValue pDefault = (IDataObjectFieldValue)f.CreateDefaultInternalValue(c, this);
              properties.SetValue(k,pDefault);
              pDefault.Attach(this, f, c);
              properties.SetIsLoaded(k,true);
              k++;
            }
          }
          else
            k += cultureCount;
        }
        else {
          if (rof) {
            IDataObjectFieldValue pDefault = (IDataObjectFieldValue)f.CreateDefaultInternalValue(null, this);
            properties.SetValue(k,pDefault);
            pDefault.Attach(this, f, null);
            properties.SetIsLoaded(k,true);            
          }
          k += cultureCount;
        }
      }
      
      long id = instantiationInfo.ID;
      
      instantiationInfo.RegisterUsage(session.Domain.PerformanceCounters);
      properties.SetValue(0,0,cultureCount,id);
      properties.SetValue(1,0,cultureCount,instantiationInfo.TypeID);
      properties.SetValue(2,0,cultureCount,instantiationInfo.VersionID);
      properties.SetValue(4,0,cultureCount,instantiationInfo.FastLoadData);
      properties.SetIsLoaded(0,0,cultureCount,true);
      properties.SetIsLoaded(1,0,cultureCount,true);
      properties.SetIsLoaded(2,0,cultureCount,true);
      properties.SetIsLoaded(3,0,cultureCount,true);
      properties.SetIsLoaded(4,0,cultureCount,true);

      state = DataObjectState.Persistent;
      this.useableValidationInfo = instantiationInfo;
      session.Cache[id] = this;
      
      try {
        UnpackPermissions(instantiationInfo.Permissions);
        bool loadAll = !UnpackFastLoadData();
        BitArray lp = new BitArray(fieldCount*cultureCount, false);
        bool needLoad = false;
        k = cSysPropertiesCount*cultureCount;
        for (int i = cSysPropertiesCount; i<fieldCount; i++) {
          Field f = fields[i];
          if (f.LoadOnDemand || f.IsNonPersisted || (this.Type.IsFlat && !loadAll))
            k += cultureCount;
          else {
            int stepCount = f.Translatable ? cultureCount : 1;
            int stepSize  = stepCount==1 ? cultureCount : 1;
            for (int j=0; j<stepCount; j++, k+=stepSize)
              needLoad |= (lp[k] = loadAll || !properties.GetIsLoaded(k));
          }
        }
        if (needLoad && !instantiationInfo.LoadDenied)
          LoadProperties(lp, true);
        OnLoad(false);
        session.OnDataObjectLoad(this,false);
        UpdateInconsistentData(session.inconsistentDataUpdateProbability);
      }
      catch {
        try {
          ConvertToRemoved();
        } catch {}
        throw;
      }
      
#if (!EXPRESS && !STANDARD)
      DataObject dependencyParent = this.DependencyParent;
      if (dependencyParent!=null) {
        instantiationInfo.DependencyParentID = dependencyParent.ID;
        instantiationInfo.DependencyParentVersionID = dependencyParent.VersionID;
      }
#endif
      
      session.Cache.GlobalCache.Add(instantiationInfo);
    }

    /// <summary>
    /// Initializes the instance (this method is called during construction).
    /// </summary>
    /// <param name="type">Type of the instance.</param>
    /// <param name="session">Session, to which this instance belongs.</param>
    /// <param name="initParams">Init parameters.</param>
    [Transactional(TransactionMode.Disabled)]
    internal void InitInstance(ObjectModel.Type type, Session session, object[] initParams)
    {
      InitDummyInstance(type, session);
      try {
        delayUpdateDepth++;
        SetIsCreating(true);
        try {
          DisableSecurity();
          try {
            // OnCreate invocation
            if (initParams==null || initParams.Length==0)
              this.OnCreate();
            else
              GetType().InvokeMember("OnCreate",
                                     BindingFlags.Public | BindingFlags.NonPublic |
                                     BindingFlags.Instance | BindingFlags.InvokeMethod,
                                     null, this, initParams);
          }
          finally {
            EnableSecurity();
          }
          session.OnDataObjectCreated(this);
        }
        catch (TargetInvocationException te) {
          //throw te.InnerException;
            throw new Exception("Error during invocation of OnCreate", te.InnerException); //we want to preserve whole inner exception's stack trace
        }
        finally {
          SetIsCreating(false);
          delayUpdateDepth--;
        }
        Persist();
        this.OnCreated();
      }
      catch (Exception) {
        try {
          ConvertToRemoved();
        }catch {}
        throw;
      }
    }

    /// <summary>
    /// Initializes the instance before deserialization.
    /// </summary>
    /// <param name="type">Type of the instance.</param>
    /// <param name="session">Session, to which this instance belongs.</param>
    /// <param name="serializer">Serializer, that will deserialize the instance.</param>
    [Transactional(TransactionMode.Disabled)]
    internal void InitDeserializable(ObjectModel.Type type, Session session, Serializer serializer)
    {
      if (this.type==null)
        InitDummyInstance(type, session);
      serializationInfo = new DataObjectSerializationInfo(serializer);
      if (permissions!=null)
        permissions.ConvertToRemovedPermissionCache();
      try {
        delayUpdateDepth++;
        SetIsCreating(true);
        try {
          OnCreateDeserializable();
          session.OnDataObjectCreated(this);
        }
        finally {
          SetIsCreating(false);
          delayUpdateDepth--;
        }
        Persist();
      }
      catch (Exception) {
        try {
          ConvertToRemoved();
        } catch {}
        throw;
      }
    }
    
    internal void InitNullObject(ObjectModel.Type type, Session session)
    {
      InitDummyInstance(type, session);
      session.UnregisterUpdatedInstance(this);
      state = DataObjectState.Removed;
    }

    /// <summary>
    /// Initializes the instance.
    /// </summary>
    /// <param name="type">Type of the instance.</param>
    /// <param name="session">Session, to which this instance belongs.</param>
    [Transactional(TransactionMode.Disabled)]
    internal void InitDummyInstance(ObjectModel.Type type, Session session)
    {
      this.type        = type;
      this.session     = session;
      this.transactionContext = session.transactionContext;
      
      state            = DataObjectState.New;
      persistDepth     = 0;
      delayUpdateDepth = 0;
      
      bool oldCanNotifyDependencyParent = canNotifyDependencyParent;
      canNotifyDependencyParent = false;
      try {
        SetIsChanged(true);
      } finally {
        canNotifyDependencyParent = oldCanNotifyDependencyParent;
      }

      FieldCollection fields = type.Fields;
      CultureCollection cultures = session.domain.cultures;
      int cnt = fields.Count;
      int cCnt = cultures.Count;
      this.properties  = new DataObjectProperties(cnt,cCnt);

      // Fields init
      int k = 0;
      for (int i = 0; i<cnt; i++) {
        Field f = fields[i];
        bool nlb = f.Nullable;
        bool rof = f is IReadOnlyField;
        if (f.Translatable) {
          for (int j = 0; j<cCnt; j++) {
            Culture c = cultures[j];
            object iValue = nlb ? f.ConvertValueToInternal(this, c, null) : f.CreateDefaultInternalValue(c, this);
            properties.SetValue(k,iValue);
            IDataObjectFieldValue fi = iValue as IDataObjectFieldValue;
            if (fi!=null)
              fi.Attach(this, f, c);
            properties.SetIsLoaded(k,true);
            properties.SetIsChanged(k,!rof);
            k++;
          }
        }
        else {
          object iValue = nlb ? f.ConvertValueToInternal(this, null, null) : f.CreateDefaultInternalValue(null, this);
          properties.SetValue(k,iValue);
          IDataObjectFieldValue fi = iValue as IDataObjectFieldValue;
          if (fi!=null)
            fi.Attach(this, f, null);
          properties.SetIsLoaded(k,true);
          properties.SetIsChanged(k,!rof);
          k += cCnt;
        }
      }
      
      // Permissions
      if (!(this is IHasNoAccessControlList)) {
        permissions = new AccessControlList();
        permissions.owner = this;
        permissions.field = type.Fields[3];
      }
      
      // Initialization
      properties.SetValue(1,0,cCnt,type.ID);
      properties.SetValue(3,0,cCnt,permissions);
      properties.SetIsChanged(0,0,cCnt,false);
      session.RegisterUpdatedInstanceWithoutPersist(this);
    }
    
    /// <summary>
    /// Converts <see cref="DataObject"/> instance to its offline analogue.
    /// </summary>
    object IConvertibleToOffline.ToOffline()
    {
      return this.ToOffline();
    }
    
    /// <summary>
    /// Converts <see cref="DataObject"/> instance to its offline analogue.
    /// </summary>
    [Transactional(TransactionMode.Disabled)]
    public Offline.DataObject ToOffline()
    {
      return this.ToOffline(new FillDescriptor());
    }

    /// <summary>
    /// Converts <see cref="DataObject"/> instance to its offline analogue.
    /// </summary>
    /// <param name="fillExpression">Fill expression (textual
    /// <see cref="Offline.FillDescriptor"/> definition) describing 
    /// desired way of conversion.</param>
    [Transactional(TransactionMode.Disabled)]
    public Offline.DataObject ToOffline(string fillExpression)
    {
      return this.ToOffline(new FillDescriptor(Domain.ObjectModel, fillExpression));
    }

    /// <summary>
    /// Converts <see cref="DataObject"/> instance to its offline analogue.
    /// </summary>
    /// <param name="fillDescriptor"><see cref="Offline.FillDescriptor"/> 
    /// desired way of conversion.</param>
    [Transactional(TransactionMode.Disabled)]
    public Offline.DataObject ToOffline(Offline.FillDescriptor fillDescriptor)
    {
      Offline.Internals.ObjectSetProvider osProvider = 
        (Offline.Internals.ObjectSetProvider)Session.GetService(typeof(Offline.Internals.ObjectSetProvider));
      Offline.QueryResult qr = osProvider.CreateObjectSet(new long[] {ID}, fillDescriptor);
      return qr.ObjectSet[ID];
    }

    // Dependency parent

    /// <summary>
    /// Gets dependency parent for this <see cref="DataObject"/> 
    /// instance or <see langword="null"/> if dependency parent 
    /// doesn't exist.
    /// This property is used by <see cref="GlobalCache"/>.
    /// </summary>
    [NotPersistent]
    [Transactional(TransactionMode.Disabled)]
    protected virtual DataObject DependencyParent {
      get {
        return null;
      }
    }
    
    private bool IsDependencyChildChanged {
      get {
        return isDependencyChildChanged;
      }
    }
    private void SetIsDependencyChildChanged(bool changed)
    {
      isDependencyChildChanged = changed;
    }


    // Event handlers

    /// <summary>
    /// A constructor analogue. Called on instance initialization.
    /// Declare <see cref="OnCreate"/>(parameters ...) to use parameterized instance
    /// initialization (in this case appropriate <see cref="OnCreate"/> method
    /// will be choosed based on arguments passed to the 
    /// <see cref="Session.CreateObject">Session.CreateObject</see> method).
    /// Override this method (or declare a new virtual method with 
    /// <see cref="OnCreate"/> name) to perform custom actions after instance 
    /// creation.
    /// <seealso cref="IsCreating"/>
    /// <seealso cref="OnCreated"/>
    /// <seealso cref="OnCreateDeserializable"/>
    /// </summary>
    /// <remarks>
    /// <para>
    /// This method is executed prior to persisting the instance
    /// to the database, so some of instance's properties (e.g. <see cref="ID"/>, 
    /// <see cref="VersionID"/>) aren't initialized on this moment. An attempt
    /// to read the value of such property will lead to <see cref="Persist"/>
    /// method invocation.
    /// </para>
    /// <note type="note">Security system is <see cref="SessionBoundObject.DisableSecurity">disabled</see>
    /// during this method execution. Use <see cref="OnCreated"/> method
    /// for enforcing different security restrictions.</note>
    /// <note type="note"><see cref="IsCreating"/> is <see langword="true"/>
    /// during this method execution.</note>
    /// <note type="note">This method is always executed in the delayed 
    /// updates mode.</note>
    /// </remarks>
    [Transactional(TransactionMode.Disabled)]
    protected virtual void OnCreate()
    {
    }

    /// <summary>
    /// Override this method  to perform custom actions after instance 
    /// creation.
    /// Usually security permission <see cref="DataObject.Demand"/>s
    /// should be executed in it.
    /// <seealso cref="IsCreating"/>
    /// <seealso cref="OnCreate"/>
    /// <seealso cref="OnCreateDeserializable"/>
    /// </summary>
    /// <remarks>
    /// This method is executed right after persisting the instance
    /// to the database after instance creation.
    /// <note type="note">On contrary to <see cref="OnCreate"/>,
    /// security system is <see cref="SessionBoundObject.EnableSecurity">enabled</see>
    /// during this method execution. Use <see cref="OnCreated"/> method
    /// for enforcing different security restrictions.</note>
    /// <note type="note"><see cref="IsCreating"/> is <see langword="false"/>
    /// during this method execution.</note>
    /// </remarks>
    [Transactional(TransactionMode.Disabled)]
    protected virtual void OnCreated()
    {
    }

    /// <summary>
    /// This method is similar to <see cref="OnCreate"/> method, but it 
    /// is invoked on newly created instance before its deserialization.
    /// Override this method to perform custom actions before instance 
    /// deserialization.
    /// <seealso cref="IsCreating"/>
    /// <seealso cref="OnCreate"/>
    /// <seealso cref="OnCreated"/>
    /// <seealso cref="OnDeserializing"/>
    /// <seealso cref="OnPropertyDeserializationError"/>
    /// <seealso cref="OnDeserialized"/>
    /// <seealso cref="OnGraphDeserialized"/>
    /// <seealso cref="OnSerializing"/>
    /// <seealso cref="Serializer"/>
    /// <seealso cref="SerializationOptions"/>
    /// <seealso cref="DeserializationOptions"/>
    /// </summary>
    /// <remarks>
    /// <para>
    /// This method is executed prior to persisting the instance
    /// to the database, so some of instance's properties (e.g. <see cref="ID"/>, 
    /// <see cref="VersionID"/>) aren't initialized on this moment. An attempt
    /// to read the value of such property will lead to <see cref="Persist"/>
    /// method invocation.
    /// </para>
    /// <para>
    /// <note type="note"><see cref="IsCreating"/> (and <see cref="IsDeserializing"/>)
    /// is <see langword="true"/> during this method execution.</note>
    /// <note type="note">This method is always executed in the delayed 
    /// updates mode.</note>
    /// <note type="note"><see cref="OnSetProperty"/>, <see cref="OnPropertyChanged"/>
    /// <see cref="OnPropertyContentChanging"/> and <see cref="OnPropertyContentChanged"/>
    /// events aren't raised when this method is executing.</note>
    /// </para>
    /// </remarks>
    [Transactional(TransactionMode.Disabled)]
    protected virtual void OnCreateDeserializable()
    {
    }

    /// <summary>
    /// Called before changes are persisted (see <see cref="Persist"/> method) 
    /// to the database.
    /// Override this method to perform custom actions before persisting
    /// the instance.
    /// </summary>
    [Transactional(TransactionMode.Disabled)]
    protected virtual void OnPersist()
    {
    }

    /// <summary>
    /// Called after changes are persisted (see <see cref="Persist"/> method)
    /// to the database.
    /// Override this method to perform custom actions after persisting
    /// the instance.
    /// </summary>
    [Transactional(TransactionMode.Disabled)]
    protected virtual void OnPersisted()
    {
    }

    /// <summary>
    /// Called before instance is removed (see <see cref="Remove"/> method).
    /// Override this method to perform custom actions before the removal 
    /// of instance.
    /// <seealso cref="OnRemoved"/>
    /// <seealso cref="Remove"/>
    /// <seealso cref="Session.RemoveObjects"/>
    /// <seealso cref="RemovalQueue"/>
    /// <seealso cref="DataObjectRemovalQueue"/>
    /// </summary>
    /// <remarks>
    /// <para>
    /// This method demands the following permissions:
    /// <see cref="RemovePermission"/>.
    /// </para>
    /// <para>
    /// It's recommended to use <see cref="DataObjectRemovalQueue.Add">RemovalQueue.Add(...)</see>
    /// rather than <see cref="DataObject.Remove">DataObject.Remove</see> in this method.
    /// </para>
    /// </remarks>
    [Transactional(TransactionMode.Disabled)]
    protected internal virtual void OnRemove()
    {
      Demand(RemovePermission.Value);
    }

    /// <summary>
    /// Called after instance is removed (see <see cref="Remove"/> method).
    /// Override this method to perform custom actions after the removal 
    /// of instance.
    /// <seealso cref="OnRemove"/>
    /// <seealso cref="Remove"/>
    /// <seealso cref="Session.RemoveObjects"/>
    /// <seealso cref="RemovalQueue"/>
    /// <seealso cref="DataObjectRemovalQueue"/>
    /// </summary>
    [Transactional(TransactionMode.Disabled)]
    protected internal virtual void OnRemoved()
    {
    }

    /// <summary>
    /// Called before trying to reload the instance.
    /// You can override this method to disable instance reloading
    /// under certain circumstances (e.g. when it's well known that
    /// instance is never changing).
    /// </summary>
    /// <param name="skipReload">Caller always sets this 
    /// <see langword="false"/> parameter to false. You can set it to
    /// <see langword="true"/>, if reloading should be skipped.</param>
    /// <remarks>
    /// <note type="note">
    /// This method isn't called when it's impossible to skip reloading,
    /// e.g. when instance is dirty.
    /// </note>
    /// <note type="note">
    /// It isn't necessary that instance will be reloaded after execution
    /// of this method, even if <paramref name="skipReload"/> is set to
    /// <see langword="false"/>. For example, no reload will occur if
    /// instance will successfully pass version check further.
    /// </note>
    /// </remarks>
    [Transactional(TransactionMode.Disabled)]
    protected virtual void OnBeforeReload(ref bool skipReload)
    {
//SM Begin
        skipReload = !ChangeCache.getInstance().isChanged(GetInternalID(), transactionContext);
//SM End
    }

    /// <summary>
    /// Called after instance is loaded or reloaded.
    /// Override this method to perform custom actions after the instance is
    /// loaded (e.g. calculation of some computable properties).
    /// </summary>
    /// <param name="reload"><see langword="True"/>, if this method is
    /// invoked on reload; otherwise, <see langword="false"/>.</param>
    /// <remarks>
    /// <para>
    /// Parameter <paramref name="reload"/> is <see langword="false"/> during the
    /// instantiation, and <see langword="true"/> on its successive reloads
    /// (e.g. after rollbacks).
    /// </para>
    /// <note type="note">This method is also invoked when instance was removed 
    /// after reloading its data (so check <see cref="State"/> property
    /// to detect this situation).
    /// </note>
    /// </remarks>
    [Transactional(TransactionMode.Disabled)]
    protected virtual void OnLoad(bool reload)
    {
    }
    
    /// <summary>
    /// Serializes object identity, when object is serialized as reference.
    /// Override this method to add custom serializable identity to 
    /// your persistent type.
    /// <seealso cref="OnDeserializeIdentity"/>
    /// <seealso cref="Serializer"/>
    /// <seealso cref="SerializationOptions"/>
    /// <seealso cref="DeserializationOptions"/>
    /// </summary>
    /// <param name="serializer">Serializer that performs the serialization.</param>
    /// <param name="info">Serialization info.</param>
    /// <param name="context">Streaming context.</param>
    protected virtual void OnSerializeIdentity(Serializer serializer, 
                                               SerializationInfo info, StreamingContext context)
    {
    }

    /// <summary>
    /// Converts serialized object identity to real <see cref="DataObject"/>
    /// instance. This method always called on so-called "null object"
    /// (see <see cref="Session.GetNullObject">Session.GetNullObject</see>).
    /// Override this method to add custom serializable identity to 
    /// your persistent type.
    /// <seealso cref="OnSerializeIdentity"/>
    /// <seealso cref="Serializer"/>
    /// <seealso cref="SerializationOptions"/>
    /// <seealso cref="DeserializationOptions"/>
    /// </summary>
    /// <param name="serializer">Serializer that performs the deserialization.</param>
    /// <param name="info">Serialization info.</param>
    /// <param name="context">Streaming context.</param>
    /// <returns><see cref="DataObject"/> instance that corresponds to
    /// serialized object identity, or <see langword="null"/>.</returns>
    internal protected virtual DataObject OnDeserializeIdentity(Serializer serializer, 
                                                                SerializationInfo info, StreamingContext context)
    {
      long id = info.GetInt64("ID");
      return Session[id];
    }

    /// <summary>
    /// Called before instance is serialized (see <see cref="Serializer"/> class).
    /// Override this method to perform custom instance serialization.
    /// <seealso cref="OnCreateDeserializable"/>
    /// <seealso cref="OnDeserializing"/>
    /// <seealso cref="OnPropertyDeserializationError"/>
    /// <seealso cref="OnDeserialized"/>
    /// <seealso cref="OnGraphDeserialized"/>
    /// <seealso cref="Serializer"/>
    /// <seealso cref="SerializationOptions"/>
    /// <seealso cref="DeserializationOptions"/>
    /// </summary>
    /// <param name="serializer">Serializer that performs the serialization.</param>
    /// <param name="info">Serialization info.</param>
    /// <param name="context">Streaming context.</param>
    /// <param name="fields">A <see cref="Hashtable"/> initially containing pairs (Field name, <see langword="true"/>).
    /// You should set some values to <see langword="false"/> or <see langword="null"/> 
    /// in it to disable automatic serialization of corresponding field.
    /// E.g. you should clear it in case when you serialize all fields manually.</param>
    /// <remarks>
    /// <para>
    /// This method demands the following permissions:
    /// <see cref="SerializationPermission"/>.
    /// </para>
    /// <para>
    /// This method is called only when instance is truely 
    /// serialized (also instance can be "serialized"
    /// as "reference" - by simply serializing its ID). 
    /// See <see cref="SerializationOptions"/> and
    /// <see cref="DeserializationOptions"/> for details.
    /// </para>
    /// </remarks>
    [Transactional(TransactionMode.Disabled)]
    protected virtual void OnSerializing(Serializer serializer, 
                                         SerializationInfo info, StreamingContext context, Hashtable fields)
    {
      Demand(SerializationPermission.Value);
    }

    /// <summary>
    /// Called before instance is deserialized (see <see cref="Serializer"/> class).
    /// Override this method to perform custom actions before instance
    /// deserialization. 
    /// <seealso cref="OnCreateDeserializable"/>
    /// <seealso cref="OnPropertyDeserializationError"/>
    /// <seealso cref="OnDeserialized"/>
    /// <seealso cref="OnGraphDeserialized"/>
    /// <seealso cref="OnSerializing"/>
    /// <seealso cref="Serializer"/>
    /// <seealso cref="SerializationOptions"/>
    /// <seealso cref="DeserializationOptions"/>
    /// </summary>
    /// <param name="serializer">Serializer that performs the deserialization.</param>
    /// <param name="info">Serialization info.</param>
    /// <param name="context">Streaming context.</param>
    /// <param name="fields">A <see cref="Hashtable"/> initially containing pairs (Field name, <see langword="true"/>).
    /// You should set some values to <see langword="false"/> or <see langword="null"/> 
    /// in it to disable automatic deserialization of corresponding field.
    /// E.g. you should clear it in case when you deserialize all fields manually.</param>
    /// <remarks>
    /// <note type="note"><see cref="OnCreate"/>, <see cref="OnSetProperty"/> 
    /// <see cref="OnPropertyChanged"/>, <see cref="OnPropertyContentChanging"/> 
    /// and <see cref="OnPropertyContentChanged"/> methods aren't invoked during 
    /// the deserialization.
    /// </note>
    /// <para>
    /// This method is called only when instance is truely 
    /// deserialized (also instance can be "deserialized"
    /// as "reference" - by simply returning an instance with
    /// reference ID). 
    /// See <see cref="SerializationOptions"/> and
    /// <see cref="DeserializationOptions"/> for details.
    /// </para>
    /// <para>
    /// You shouldn't demand any permissions in this method,
    /// because permissions aren't deserialized on this moment.
    /// All permission demands passes for <see cref="IsDeserializing"/> 
    /// instances. Use <see cref="OnGraphDeserialized"/> event 
    /// handler for permission demands.
    /// </para>
    /// </remarks>
    [Transactional(TransactionMode.Disabled)]
    protected virtual void OnDeserializing(Serializer serializer, 
                                           SerializationInfo info, StreamingContext context, Hashtable fields)
    {
    }

    /// <summary>
    /// Called on any error during deserialization (see 
    /// <see cref="Serializer"/> class) of instance field.
    /// Override this method to handle deserialization
    /// errors. This can be very necessary if it's required 
    /// to deserialize another version of object - e.g. if
    /// this version was containing a field that doesn't
    /// exists in the current version.
    /// <seealso cref="OnCreateDeserializable"/>
    /// <seealso cref="OnDeserializing"/>
    /// <seealso cref="OnDeserialized"/>
    /// <seealso cref="OnGraphDeserialized"/>
    /// <seealso cref="OnSerializing"/>
    /// <seealso cref="Serializer"/>
    /// <seealso cref="SerializationOptions"/>
    /// <seealso cref="DeserializationOptions"/>
    /// </summary>
    /// <param name="serializer">Serializer that performs the deserialization.</param>
    /// <param name="info">Serialization info.</param>
    /// <param name="context">Streaming context.</param>
    /// <param name="propertyName">The name of the field that was 
    /// deserializing.</param>
    /// <param name="culture">The <see cref="Culture"/> of the field that was
    /// deserializing.</param>
    /// <param name="exception">Exception that was thrown during attempt
    /// to deserialize <paramref name="propertyName"/>.</param>
    /// <remarks>
    /// <note type="note"><see cref="OnCreate"/>, <see cref="OnSetProperty"/> 
    /// <see cref="OnPropertyChanged"/>, <see cref="OnPropertyContentChanging"/> 
    /// and <see cref="OnPropertyContentChanged"/> methods aren't invoked during 
    /// the deserialization.
    /// </note>
    /// <para>
    /// This method can be invoked only when instance is truely 
    /// deserialized (also instance can be "deserialized"
    /// as "reference" - by simply returning an instance with
    /// reference ID).
    /// See <see cref="SerializationOptions"/> and
    /// <see cref="DeserializationOptions"/> for details.
    /// </para>
    /// <note type="note">Default implementation of this method
    /// always throws passed <paremref name="exception"/>.
    /// Don't throw any exception if your implementation has successfully
    /// handled the situation.
    /// </note>
    /// <para>
    /// You shouldn't demand any permissions in this method,
    /// because permissions aren't deserialized on this moment.
    /// All permission demands passes for <see cref="IsDeserializing"/> 
    /// instances. Use <see cref="OnGraphDeserialized"/> event 
    /// handler for permission demands.
    /// </para>
    /// </remarks>
    [Transactional(TransactionMode.Disabled)]
    protected virtual void OnPropertyDeserializationError(Serializer serializer, 
                                                          SerializationInfo info, StreamingContext context, 
                                                          string propertyName, Culture culture, Exception exception)
    {
      throw exception;
    }

    /// <summary>
    /// Called after instance is deserialized.
    /// Override this method to perform custom actions after instance
    /// deserialization.
    /// <seealso cref="OnCreateDeserializable"/>
    /// <seealso cref="OnDeserializing"/>
    /// <seealso cref="OnPropertyDeserializationError"/>
    /// <seealso cref="OnGraphDeserialized"/>
    /// <seealso cref="OnSerializing"/>
    /// <seealso cref="Serializer"/>
    /// <seealso cref="SerializationOptions"/>
    /// <seealso cref="DeserializationOptions"/>
    /// </summary>
    /// <param name="serializer">Serializer that performs the deserialization.</param>
    /// <remarks>
    /// <note type="note"><see cref="OnCreate"/>, <see cref="OnSetProperty"/> 
    /// <see cref="OnPropertyChanged"/>, <see cref="OnPropertyContentChanging"/> 
    /// and <see cref="OnPropertyContentChanged"/> methods aren't invoked during 
    /// the deserialization.
    /// </note>
    /// <para>
    /// You can change some instance properties here, e.g.
    /// to set correct <see cref="SecurityParent"/> value.
    /// </para>
    /// <para>
    /// This method is called only when instance is truely 
    /// deserialized (also instance can be "deserialized"
    /// as "reference" - by simply returning an instance with
    /// reference ID). See <see cref="SerializationOptions"/> and
    /// <see cref="DeserializationOptions"/> for details.
    /// </para>
    /// <para>
    /// You shouldn't demand any permissions in this method,
    /// because permissions aren't deserialized on this moment.
    /// All permission demands passes for <see cref="IsDeserializing"/> 
    /// instances. Use <see cref="OnGraphDeserialized"/> event 
    /// handler for permission demands.
    /// </para>
    /// </remarks>
    [Transactional(TransactionMode.Disabled)]
    protected virtual void OnDeserialized(Serializer serializer)
    {
    }

    /// <summary>
    /// Called when the whole object graph is completely deserialized.
    /// Override this method to perform custom actions after complete graph 
    /// deserialization (e.g. permission demands).
    /// <seealso cref="OnCreateDeserializable"/>
    /// <seealso cref="OnDeserializing"/>
    /// <seealso cref="OnPropertyDeserializationError"/>
    /// <seealso cref="OnDeserialized"/>
    /// <seealso cref="OnSerializing"/>
    /// <seealso cref="Serializer"/>
    /// <seealso cref="SerializationOptions"/>
    /// <seealso cref="DeserializationOptions"/>
    /// </summary>
    /// <param name="serializer">Serializer that performs the deserialization.</param>
    /// <remarks>
    /// <note type="note"><see cref="OnCreate"/>, <see cref="OnSetProperty"/> 
    /// <see cref="OnPropertyChanged"/>, <see cref="OnPropertyContentChanging"/> 
    /// and <see cref="OnPropertyContentChanged"/> methods are invoked during 
    /// the execution of this method.
    /// </note>
    /// <para>
    /// This method demands the following permissions:
    /// <see cref="ChildrenDeserializationPermission"/> (on <see cref="SecurityParent"/> object),
    /// <see cref="ChildrenPermissionsDeserializationPermission"/> (on <see cref="SecurityParent"/> object, but
    /// only when <paramref name="serializer"/>.<see cref="Serializer.DeserializationOptions"/>
    /// includes <see cref="DeserializationOptions.DeserializePermissions"/> option).
    /// </para>
    /// <para>
    /// This method is called only when instance is truely 
    /// deserialized (also instance can be "deserialized"
    /// as "reference" - by simply returning an instance with
    /// reference ID). See <see cref="SerializationOptions"/> and
    /// <see cref="DeserializationOptions"/> for details.
    /// </para>
    /// </remarks>
    [Transactional(TransactionMode.Disabled)]
    protected virtual void OnGraphDeserialized(Serializer serializer)
    {
      SecurityParent.Demand(ChildrenDeserializationPermission.Value);
      if ((serializer.DeserializationOptions & DeserializationOptions.DeserializePermissions)!=0)
        SecurityParent.Demand(ChildrenPermissionsDeserializationPermission.Value);
      if (this is IFtObject)
        InvalidateFtData();
    }
    
    [Transactional(TransactionMode.Disabled)]
    internal void GraphPreDeserialized(Serializer serializer)
    {
      if (serializationInfo!=null && serializationInfo.DeserializedPermissions!=null) {
        if (permissions!=null)
          permissions.CopyFrom(serializationInfo.DeserializedPermissions);
        serializationInfo.DeserializedPermissions = null;
        int cCnt = session.domain.cultures.Count;
        properties.SetIsLoaded(3,0,cCnt,true);
        properties.SetIsChanged(3,0,cCnt,true);
        SetIsChanged(true);
        TryPersist();
      } 
      SecurityParentChangedOnDeserialization();
    }

    [Transactional(TransactionMode.Disabled)]
    internal void GraphDeserialized(Serializer serializer)
    {
      OnGraphDeserialized(serializer);
      session.OnDataObjectGraphDeserialized(this,serializer);
    }

    /// <summary>
    /// Extended version of <see cref="OnReference"/> event.
    /// Called before establishing a reference to the instance.
    /// Override this method to perform custom actions before reference to the
    /// current instance is established.
    /// </summary>
    /// <param name="referer">An object that is establishing reference to this instance.</param>
    /// <param name="field"><see cref="Field"/> instance describing property where reference is stored</param>
    /// <param name="culture">Culture of referer property.</param>
    [Transactional(TransactionMode.Disabled)]
    protected internal virtual void OnReferenceEx(DataObject referer, Field field, Culture culture)
    {
      // if (referer!=this)
      OnReference(referer, field.RootField.Name, culture);
    }

    /// <summary>
    /// Called before establishing a reference to the instance.
    /// Override this method to perform custom actions before reference to the
    /// current instance is established.
    /// </summary>
    /// <param name="referer">An object that is establishing reference to this instance.</param>
    /// <param name="propertyName">Name of referer property where reference is stored.</param>
    /// <param name="culture">Culture of referer property.</param>
    [Transactional(TransactionMode.Disabled)]
    protected internal virtual void OnReference(DataObject referer, string propertyName, Culture culture)
    {
    }

    /// <summary>
    /// Extended version of <see cref="OnDereference"/> event.
    /// Called before removing a reference to the instance.
    /// Override this method to perform custom actions before reference to the
    /// current instance is removed.
    /// </summary>
    /// <param name="referer">An object that is removing a reference to this instance.</param>
    /// <param name="field"><see cref="Field"/> instance describing property where reference is stored</param>
    /// <param name="culture">Culture of referer property.</param>
    [Transactional(TransactionMode.Disabled)]
    protected internal virtual void OnDereferenceEx(DataObject referer, Field field, Culture culture)
    {
      // if (referer!=this)
      OnDereference(referer, field.RootField.Name, culture);
    }

    /// <summary>
    /// Called before removing a reference to the instance.
    /// Override this method to perform custom actions before reference to the
    /// current instance is removed.
    /// </summary>
    /// <param name="referer">An object that is removing a reference to this instance.</param>
    /// <param name="propertyName">Name of referer property where reference is stored.</param>
    /// <param name="culture">Culture of referer property.</param>
    [Transactional(TransactionMode.Disabled)]
    protected internal virtual void OnDereference(DataObject referer, string propertyName, Culture culture)
    {
    }

    /// <summary>
    /// Called during <see cref="GetProperty"/> method execution.
    /// Override this method to perform custom actions before property reading.
    /// </summary>
    /// <param name="name">Property name.</param>
    /// <param name="culture">Property culture.</param>
    /// <param name="value">Stored property value.</param>
    /// <returns>Property value to return.</returns>
    /// <remarks>
    /// <para>
    /// This method demands the following permissions:
    /// <see cref="ReadPermission"/>, or
    /// <see cref="ReadPermissionsPermission"/> 
    /// (when <paramref name="name"/>=="Permissions").
    /// </para>
    /// </remarks>
    [Transactional(TransactionMode.Disabled)]
    protected virtual object OnGetProperty(string name, Culture culture, object value)
    {
      if (name=="Permissions")
        Demand(ReadPermissionsPermission.Value);
      else
        Demand(ReadPermission.Value);
      PermissionSet ps = this.Type.Fields[name].ReadPermissions;
      if (ps!=null)
        ps.Demand(this);
      return value;
    }

    /// <summary>
    /// Called during <see cref="SetProperty"/> method execution.
    /// Override this method to perform custom actions before property changing.
    /// Note that this method isn't invoked during the deserialization.
    /// </summary>
    /// <param name="name">Property name.</param>
    /// <param name="culture">Property culture.</param>
    /// <param name="value">New property value.</param>
    /// <remarks>
    /// <para>
    /// This method demands the following permissions:
    /// <see cref="ChangePermission"/>.
    /// </para>
    /// </remarks>
    [Transactional(TransactionMode.Disabled)]
    protected virtual void OnSetProperty(string name, Culture culture, object value)
    {
      if ((this is IFtObject) && name=="FtRecordIsUpToDate") {
        Demand(ChangeFullTextDataPermission.Value);
        return;
      }
      Demand(ChangePermission.Value);
      PermissionSet ps = this.Type.Fields[name].ChangePermissions;
      if (ps!=null)
        ps.Demand(this);
    }

    /// <summary>
    /// Called when some property was changed.
    /// Override this method to perform custom actions after property changes.
    /// Note that this method isn't invoked during the deserialization.
    /// </summary>
    /// <param name="name">Property name.</param>
    /// <param name="culture">Property culture.</param>
    /// <param name="value">New property value.</param>
    [Transactional(TransactionMode.Disabled)]
    protected virtual void OnPropertyChanged(string name, Culture culture, object value)
    {
      if ((this is IFtObject) && name!="FtRecordIsUpToDate")
        InvalidateFtData();
    }

    /// <summary>
    /// Called before inner content of some non-<see cref="ValueType"/> 
    /// property is changed.
    /// Override this method to perform custom actions before contents of 
    /// collection or non-<see cref="ValueType"/> property is changed.
    /// </summary>
    /// <param name="name">Property name.</param>
    /// <param name="culture">Property culture.</param>
    /// <param name="value">Old property value.</param>
    /// <remarks>
    /// <para>
    /// This method demands the following permissions:
    /// <see cref="ChangePermission"/>, or
    /// <see cref="ChangePermissionsPermission"/> 
    /// (when <paramref name="name"/>=="Permissions").
    /// </para>
    /// </remarks>
    [Transactional(TransactionMode.Disabled)]
    protected virtual void OnPropertyContentChanging(string name, Culture culture, object value)
    {
      if (name=="Permissions")
        Demand(ChangePermissionsPermission.Value);
      else
        Demand(ChangePermission.Value);
      PermissionSet ps = this.Type.Fields[name].ChangePermissions;
      if (ps!=null)
        ps.Demand(this);
      if (this is IFtObject)
        InvalidateFtData();
    }

    /// <summary>
    /// Called when inner content of some non-<see cref="ValueType"/> 
    /// property was changed.
    /// Override this method to perform custom actions after property changing.
    /// Note that this method isn't invoked during the deserialization.
    /// </summary>
    /// <param name="name">Property name.</param>
    /// <param name="culture">Property culture.</param>
    /// <param name="value">New property value.</param>
    [Transactional(TransactionMode.Disabled)]
    protected virtual void OnPropertyContentChanged(string name, Culture culture, object value)
    {
    }

    /// <summary>
    /// Called when <see cref="SecurityParent"/> was changed.
    /// Override this method to perform custom actions on this event.
    /// </summary>
    /// <remarks>
    /// <note type="note">DataObjects.NET can't track <see cref="SecurityParent"/> 
    /// property changes (because this is not a persistent property), so this
    /// event isn't raised by DataObjects.NET automatically.
    /// </note>
    /// <para>
    /// Exactly, this event is raised during <see cref="SecurityParentChanged"/> 
    /// execution, but invocation of <see cref="SecurityParentChanged"/> is under
    /// complete responsibility of persistent class developer.
    /// </para>
    /// <para>
    /// E.g. most probable that you'll implement <see cref="SecurityParent"/> 
    /// property as "mirror" of some persistent property. In this case you
    /// should override <see cref="OnPropertyChanged"/> event in this type, and
    /// overriding method should invoke <see cref="SecurityParentChanged"/> on 
    /// each change of corresponding persistent property.
    /// </para>
    /// </remarks>
    [Transactional(TransactionMode.Disabled)]
    protected virtual void OnSecurityParentChanged()
    {
    }
  }
}
