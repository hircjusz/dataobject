// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.IO;
using System.Globalization;
using System.Runtime.Serialization;
using System.Text.RegularExpressions;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Attributes;

namespace DataObjects.NET
{
  /// <summary>
  /// Holds information about single culture in the <see cref="Domain"/>.
  /// </summary>
  /// <remarks>
  /// Each persistent <see cref="TranslatableAttribute">[Translatable]</see> property 
  /// can contain a version of its value for every <see cref="Culture"/> registered 
  /// in the <see cref="Domain"/>.
  /// <example>Example:
  /// <code lang="C#">
  ///  d = new Domain("mssql://localhost/DataObjectsDotNetDemos", myProductKey);
  ///  d.RegisterCulture(new Culture("En",  "U.S. English", new CultureInfo("en-us", false)));
  ///  d.RegisterCulture(new Culture("Ru",  "Russian", new CultureInfo("ru-ru", false)));
  ///  d.RegisterCulture(new Culture("DeCh","Switzerland", new CultureInfo("de-CH", false)));
  ///  d.Cultures["En"].Default = true;
  ///  d.RegisterTypes("MyApp.PersistentModel");
  ///  d.RegisterServices("MyApp.PersistentModel");
  ///  d.Build(DomainUpdateMode.Perform);
  /// </code>
  /// </example>
  /// <seealso cref="DataObjects.NET.Domain.RegisterCulture"/>
  /// <seealso cref="CultureCollection"/>
  /// </remarks>
  [Serializable]
  #if (!NoMBR)
  public sealed class Culture: MarshalByRefObject, 
  #else
  public sealed class Culture: Object, 
  #endif
    ICulture, ILockable, IDebugDump, ISerializable, IDeserializationCallback,
    IConvertibleToOffline
  {
    private Domain domain = null;
    /// <summary>
    /// <see cref="Domain"/> to which this <see cref="Culture"/> belongs.
    /// </summary>
    public Domain Domain {
      get {return domain;}
      set {
        if (!isLocked) {
          if (domain==value) return;
          if (domain!=null)
            domain.Cultures.Remove(this);
          if (value!=null)
            value.Cultures.Add(this);
          domain = value;
        }
        else
          throw new InstanceIsLockedException("Instance is locked.");
      }
    }
    
    /// <summary>
    /// This internal method allows container to set Domain property without
    /// spawning a set of recursive calls to its Add\Remove methods.
    /// </summary>
    /// <param name="value">New <see cref="Domain"/> value.</param>
    internal void SetDomainFromContainer(Domain value)
    {
      if (!isLocked)
        domain = value;
      else
        throw new InstanceIsLockedException("Instance is locked.");
    }
    
    private int index = -1;
    /// <summary>
    /// Gets the index of this <see cref="Culture"/> in the
    /// <see cref="DataObjects.NET.Domain.Cultures">Domain.Cultures</see> 
    /// collection.
    /// </summary>
    public int Index {
      get {
        if (index>=0 || domain==null)
          return index;
        return domain.Cultures.IndexOf(this);
      }
    }
    
    private string name;
    /// <summary>
    /// Name of the culture (E.g. "En"). 
    /// This property can be defined only during construstion.
    /// </summary>
    public  string Name {
      get {return name;}
    }
    
    private string title;
    /// <summary>
    /// Title of the culture (E.g. "German").
    /// </summary>
    public string  Title {
      get {return title;}
      set {
        if (!isLocked)
          title = value;
        else
          throw new InstanceIsLockedException("Instance is locked.");
      }
    }
    
    private bool _default = false;
    /// <summary>
    /// <see langword="True"/> if this <see cref="Culture"/> is the default 
    /// culture in the <see cref="Domain"/>.
    /// </summary>
    public  bool Default {
      get {return _default;}
      set {
        if (!isLocked) {
          if (value==_default) return;
          if (value) {
            if (domain!=null && domain.Cultures.DefaultCulture!=null && domain.Cultures.DefaultCulture!=this)
              throw new InvalidOperationException("Only one default culture is allowed.");
            if (domain!=null)
              domain.Cultures.SetDefaultCultureInternally(this);
          }
          else {
            if (domain!=null)
              domain.Cultures.SetDefaultCultureInternally(null);
          }
          _default = value;
        }
        else
          throw new InstanceIsLockedException("Instance is locked.");
      }
    }

    private CultureInfo info;
    /// <summary>
    /// <see cref="CultureInfo"/> object associated with this culture.
    /// This property can be defined only during construstion.
    /// </summary>
    public  CultureInfo Info {
      get {return info;}
    }
    
    private CompareOptions compareOptions;
    /// <summary>
    /// <see cref="CompareOptions"/> object associated with this culture.
    /// This property can be defined only during construstion.
    /// </summary>
    public  CompareOptions CompareOptions {
      get {return compareOptions;}
    }
    
    private SqlCollation sqlCollation;
    /// <summary>
    /// Gets <see cref="SqlCollation"/> for this instance.
    /// </summary>
    public SqlCollation SqlCollation {
      get {return sqlCollation;}
    }
    
    /// <summary>
    /// Determines whether the instance of this class
    /// is immutable (locked, read-only). 
    /// </summary>
    /// <remarks>
    /// There is no way to unlock locked instance.
    /// </remarks>
    public bool IsLocked {
      get {
        return isLocked;
      }
    }
    private bool isLocked;
    private bool serializedIsLocked;
    
    /// <summary>
    /// Locks the instance.
    /// </summary>
    public void Lock() 
    {
      Lock(false);
    }
    
    /// <summary>
    /// Locks the instance and (possible) all dependent objects.
    /// </summary>
    /// <param name="recursive"><see langword="True"/> if all dependent objects should be locked too.</param>
    public void Lock(bool recursive) 
    {
      isLocked = true;
      if (domain!=null)
        index = domain.Cultures.IndexOf(this);
    }
    
    /// <summary>
    /// Converts <see cref="Culture"/> instance to its offline analogue.
    /// </summary>
    object IConvertibleToOffline.ToOffline()
    {
      return this.ToOffline();
    }
    
    /// <summary>
    /// Converts <see cref="Culture"/> instance to its offline analogue.
    /// </summary>
    public Offline.Culture ToOffline()
    {
      Offline.CultureCollection offlineCultures = new Offline.CultureCollection(Domain.Cultures);
      if (Domain.Cultures.IsLocked)
        offlineCultures.Lock();
      return offlineCultures[Index];
    }
    
    private void InitSqlCollation()
    {
      if (info.Equals(CultureInfo.InvariantCulture)) {
        sqlCollation = SqlCollation.Neutral;
        return;
      }
        
      string pfx = "";
      switch (info.LCID) {
      case 1025:
        pfx = "Arabic";
        break;
      case 1028:
        pfx = "Chinese_Taiwan_Stroke";
        break;
      case 1029:
        pfx = "Czech";
        break;
      case 1030:
        pfx = "Danish_Norwegian";
        break;
      case 1032:
        pfx = "Greek";
        break;
      case 1033:
        pfx = "Latin1_General";
        break;
      case 1034:
        pfx = "Traditional_Spanish";
        break;
      case 1035:
        pfx = "Finnish_Swedish";
        break;
      case 1036:
        pfx = "French";
        break;
      case 1037:
        pfx = "Hebrew";
        break;
      case 1038:
        pfx = "Hungarian";
        break;
      case 1039:
        pfx = "Icelandic";
        break;
      case 1041:
        pfx = "Japanese";
        break;
      case 1042:
        pfx = "Korean_Wansung";
        break;
      case 1045:
        pfx = "Polish";
        break;
      case 1048:
        pfx = "Romanian";
        break;
      case 1049:
        pfx = "Cyrillic_General";
        break;
      case 1050:
        pfx = "Croatian";
        break;
      case 1051:
        pfx = "Slovak";
        break;
      case 1052:
        pfx = "Albanian";
        break;
      case 1054:
        pfx = "Thai";
        break;
      case 1055:
        pfx = "Turkish";
        break;
      case 1058:
        pfx = "Ukrainian";
        break;
      case 1060:
        pfx = "Slovenian";
        break;
      case 1061:
        pfx = "Estonian";
        break;
      case 1062:
        pfx = "Latvian";
        break;
      case 1063:
        pfx = "Lithuanian";
        break;
      case 1066:
        pfx = "Vietnamese";
        break;
      case 1071:
        pfx = "Macedonian";
        break;
      case 1081:
        pfx = "Hindi";
        break;
      case 2052:
        pfx = "Chinese_PRC";
        break;
      case 2087:
        pfx = "Lithuanian_Classic";
        break;
      case 3082:
        pfx = "Modern_Spanish";
        break;
      case 66567:
        pfx = "German_PhoneBook";
        break;
      case 66574:
        pfx = "Hungarian_Technical";
        break;
      case 66577:
        pfx = "Japanese_Unicode";
        break;
      case 66578:
        pfx = "Korean_Wansung_Unicode";
        break;
      case 66615:
        pfx = "Georgian_Modern_sort";
        break;
      case 133124:
        pfx = "Chinese_PRC_Stroke";
        break;
      case 197636:
        pfx = "Chinese_Taiwan_Bopomofo";
        break;

      // Additional
      case 0x403:
        pfx="Latin1_General";
        break;
      case 0x407:
        pfx="Latin1_General";
        break;
      case 0x410:
        pfx="Latin1_General";
        break;
      case 0x413:
        pfx="Latin1_General";
        break;
      case 0x416:
        pfx="Latin1_General";
        break;
      case 0x421:
        pfx="Latin1_General";
        break;
      case 0x42D:
        pfx="Latin1_General";
        break;
      case 0x436:
        pfx="Latin1_General";
        break;
      case 0x438:
        pfx="Latin1_General";
        break;
      case 0x807:
        pfx="Latin1_General";
        break;
      case 0x809:
        pfx="Latin1_General";
        break;
      case 0x810:
        pfx="Latin1_General";
        break;
      case 0x813:
        pfx="Latin1_General";
        break;
      case 0x816:
        pfx="Latin1_General";
        break;
      case 0xC07:
        pfx="Latin1_General";
        break;
      case 0xC09:
        pfx="Latin1_General";
        break;
      case 0x1007:
        pfx="Latin1_General";
        break;
      case 0x1009:
        pfx="Latin1_General";
        break;
      case 0x1407:
        pfx="Latin1_General";
        break;
      case 0x1409:
        pfx="Latin1_General";
        break;
      case 0x1809:
        pfx="Latin1_General";
        break;
      case 0x1C09:
        pfx="Latin1_General";
        break;
      case 0x2009:
        pfx="Latin1_General";
        break;
      case 0x2409:
        pfx="Latin1_General";
        break;

      case 0x420:
        pfx="Arabic";
        break;
      case 0x429:
        pfx="Arabic";
        break;
      case 0x801:
        pfx="Arabic";
        break;
      case 0xC01:
        pfx="Arabic";
        break;
      case 0x1001:
        pfx="Arabic";
        break;
      case 0x1401:
        pfx="Arabic";
        break;
      case 0x1801:
        pfx="Arabic";
        break;
      case 0x1C01:
        pfx="Arabic";
        break;
      case 0x2001:
        pfx="Arabic";
        break;
      case 0x2401:
        pfx="Arabic";
        break;
      case 0x2801:
        pfx="Arabic";
        break;
      case 0x2C01:
        pfx="Arabic";
        break;
      case 0x3001:
        pfx="Arabic";
        break;
      case 0x3401:
        pfx="Arabic";
        break;
      case 0x3801:
        pfx="Arabic";
        break;
      case 0x3C01:
        pfx="Arabic";
        break;
      case 0x4001:
        pfx="Arabic";
        break;

      case 0x423:
        pfx="Cyrillic_General";
        break;
      case 0x402:
        pfx="Cyrillic_General";
        break;
      case 0x81A:
        pfx="Cyrillic_General";
        break;
      case 0xC1A:
        pfx="Cyrillic_General";
        break;

      case 0x1004:
        pfx="Chinese_PRC";
        break;

      case 0x80C:
        pfx="French";
        break;
      case 0x100C:
        pfx="French";
        break;
      case 0xC0C:
        pfx="French";
        break;
      case 0x140C:
        pfx="French";
        break;

      case 0x104E:
        pfx="Hungarian_Technical";
        break;

      case 0x414:
        pfx="Danish_Norwegian";
        break;
      case 0x814:
        pfx="Danish_Norwegian";
        break;

      case 0x80A:
        pfx="Traditional_Spanish";
        break;

      case 0x100A:
        pfx="Modern_Spanish";
        break;
      case 0x140A:
        pfx="Modern_Spanish";
        break;
      case 0x180A:
        pfx="Modern_Spanish";
        break;
      case 0x1C0A:
        pfx="Modern_Spanish";
        break;
      case 0x200A:
        pfx="Modern_Spanish";
        break;
      case 0x240A:
        pfx="Modern_Spanish";
        break;
      case 0x280A:
        pfx="Modern_Spanish";
        break;
      case 0x2C0A:
        pfx="Modern_Spanish";
        break;
      case 0x300A:
        pfx="Modern_Spanish";
        break;
      case 0x340A:
        pfx="Modern_Spanish";
        break;
      case 0x380A:
        pfx="Modern_Spanish";
        break;
      case 0x3C0A:
        pfx="Modern_Spanish";
        break;
      case 0x400A:
        pfx="Modern_Spanish";
        break;

      case 0x41D:
        pfx="Finnish_Swedish";
        break;
      }
      
      string sfx = "";
      
      // Binary ?
      if ((compareOptions & System.Globalization.CompareOptions.Ordinal)!=0)
        sfx = "BIN";
      else {
        if ((compareOptions & System.Globalization.CompareOptions.IgnoreCase)!=0)
          sfx = "CI";
        else
          sfx = "CS";
        sfx = sfx + "_AI";
        if ((compareOptions & System.Globalization.CompareOptions.IgnoreKanaType)==0)
          sfx = sfx + "_KS";
        if ((compareOptions & System.Globalization.CompareOptions.IgnoreWidth)==0)
          sfx = sfx + "_WS";
      }
      
      string cname = pfx+"_"+sfx;
      
      try {
        sqlCollation = (SqlCollation)Enum.Parse(typeof(SqlCollation),cname);
      }
      catch (Exception) {
        sqlCollation = SqlCollation.Unknown;
      }
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="name">Name of this culture. Format of the name is <c>[A-Za-z][A-Za-z0-9_\-]*</c>.</param>
    /// <param name="title">Title of the culture.</param>
    /// <param name="info">Associated <see cref="CultureInfo"/> object.</param>
    /// <param name="compareOptions">Associated <see cref="CompareOptions"/>.</param>
    /// <param name="sqlCollation"><see cref="SqlCollation"/> to use use with this <see cref="Culture"/>.
    /// <see langword="SqlCollation.Unknown"/>, if it should be derived from the specified
    /// <paramref name="info"/> and <paramref name="compareOptions"/>.</param>
    /// <remarks>
    /// Only <see cref="Title"/> property of <see cref="Culture"/> is mutable. Other
    /// properties (e.g. <see cref="Name"/>) are defined only once during
    /// construstion of the instance.
    /// </remarks>
    public Culture(string name, string title, CultureInfo info, CompareOptions compareOptions,
      SqlCollation sqlCollation)
    {
      Regex rName = new Regex(@"^[A-Z][_0-9A-Z\-]*$", RegexOptions.IgnoreCase | RegexOptions.Multiline);
      if (!rName.IsMatch(name))
        throw new InvalidOperationException("Illegal culture name.");
      this.name  = name;
      this.info  = info;
      this.compareOptions = compareOptions;
      this.title = title;
      if (sqlCollation!=SqlCollation.Unknown)
        this.sqlCollation = sqlCollation;
      else
        InitSqlCollation();
    }
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="name">Name of this culture. Format of the name is <c>[A-Za-z][A-Za-z0-9_\-]*</c>.</param>
    /// <param name="title">Title of the culture.</param>
    /// <param name="info">Associated <see cref="CultureInfo"/> object.</param>
    /// <param name="compareOptions">Associated <see cref="CompareOptions"/>.</param>
    /// <remarks>
    /// Only <see cref="Title"/> property of <see cref="Culture"/> is mutable. Other
    /// properties (e.g. <see cref="Name"/>) are defined only once during
    /// construstion of the instance.
    /// </remarks>
    public Culture(string name, string title, CultureInfo info, CompareOptions compareOptions):
      this(name, title, info, compareOptions, SqlCollation.Unknown)
    {
    }
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="name">Name of the culture. Format of the name is <c>[A-Za-z][A-Za-z0-9_\-]*</c>.</param>
    /// <param name="info">Associated <see cref="CultureInfo"/> object.</param>
    /// <param name="compareOptions">Associated <see cref="CompareOptions"/>.</param>
    /// <param name="sqlCollation"><see cref="SqlCollation"/> to use use with this <see cref="Culture"/>.
    /// <see langword="SqlCollation.Unknown"/>, if it should be derived from the specified
    /// <paramref name="info"/> and <paramref name="compareOptions"/>.</param>
    /// <remarks>
    /// Only <see cref="Title"/> property of <see cref="Culture"/> is mutable. Other
    /// properties (e.g. <see cref="Name"/>) are defined only once during
    /// construstion of the instance.
    /// </remarks>
    public Culture(string name, CultureInfo info, CompareOptions compareOptions, SqlCollation sqlCollation):
      this(name, info.EnglishName, info, compareOptions, sqlCollation)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="name">Name of the culture. Format of the name is <c>[A-Za-z][A-Za-z0-9_\-]*</c>.</param>
    /// <param name="info">Associated <see cref="CultureInfo"/> object.</param>
    /// <param name="compareOptions">Associated <see cref="CompareOptions"/>.</param>
    /// <remarks>
    /// Only <see cref="Title"/> property of <see cref="Culture"/> is mutable. Other
    /// properties (e.g. <see cref="Name"/>) are defined only once during
    /// construstion of the instance.
    /// </remarks>
    public Culture(string name, CultureInfo info, CompareOptions compareOptions):
      this(name, info.EnglishName, info, compareOptions, SqlCollation.Unknown)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="name">Name of the culture. Format of the name is <c>[A-Za-z][A-Za-z0-9_\-]*</c>.</param>
    /// <param name="title">Title of the culture.</param>
    /// <param name="info">Associated <see cref="CultureInfo"/> object.</param>
    /// <param name="sqlCollation"><see cref="SqlCollation"/> to use use with this <see cref="Culture"/>.
    /// <see langword="SqlCollation.Unknown"/>, if it should be derived from the specified
    /// <paramref name="info"/> and <paramref name="compareOptions"/>.</param>
    /// <remarks>
    /// Only <see cref="Title"/> property of <see cref="Culture"/> is mutable. Other
    /// properties (e.g. <see cref="Name"/>) are defined only once during
    /// construstion of the instance.
    /// </remarks>
    public Culture(string name, string title, CultureInfo info, SqlCollation sqlCollation):
      this(name, title, info, CompareOptions.IgnoreCase | CompareOptions.IgnoreKanaType | CompareOptions.IgnoreWidth, sqlCollation)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="name">Name of the culture. Format of the name is <c>[A-Za-z][A-Za-z0-9_\-]*</c>.</param>
    /// <param name="title">Title of the culture.</param>
    /// <param name="info">Associated <see cref="CultureInfo"/> object.</param>
    /// <remarks>
    /// Only <see cref="Title"/> property of <see cref="Culture"/> is mutable. Other
    /// properties (e.g. <see cref="Name"/>) are defined only once during
    /// construstion of the instance.
    /// </remarks>
    public Culture(string name, string title, CultureInfo info):
      this(name, title, info, CompareOptions.IgnoreCase | CompareOptions.IgnoreKanaType | CompareOptions.IgnoreWidth, SqlCollation.Unknown)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="name">Name of this culture. Format of the name is <c>[A-Za-z][A-Za-z0-9_\-]*</c>.</param>
    /// <param name="info">Associated <see cref="CultureInfo"/> object.</param>
    /// <param name="sqlCollation"><see cref="SqlCollation"/> to use use with this <see cref="Culture"/>.
    /// <see langword="SqlCollation.Unknown"/>, if it should be derived from the specified
    /// <paramref name="info"/> and <paramref name="compareOptions"/>.</param>
    /// <remarks>
    /// Only <see cref="Title"/> property of <see cref="Culture"/> is mutable. Other
    /// properties (e.g. <see cref="Name"/>) are defined only once during
    /// construstion of the instance.
    /// </remarks>
    public Culture(string name, CultureInfo info, SqlCollation sqlCollation):
      this(name, info, CompareOptions.IgnoreCase | CompareOptions.IgnoreKanaType | CompareOptions.IgnoreWidth, sqlCollation)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="name">Name of this culture. Format of the name is <c>[A-Za-z][A-Za-z0-9_\-]*</c>.</param>
    /// <param name="info">Associated <see cref="CultureInfo"/> object.</param>
    /// <remarks>
    /// Only <see cref="Title"/> property of <see cref="Culture"/> is mutable. Other
    /// properties (e.g. <see cref="Name"/>) are defined only once during
    /// construstion of the instance.
    /// </remarks>
    public Culture(string name, CultureInfo info):
      this(name, info, CompareOptions.IgnoreCase | CompareOptions.IgnoreKanaType | CompareOptions.IgnoreWidth, SqlCollation.Unknown)
    {
    }

    // Serializer/deserializer.

    /// <summary>
    /// Serializer.
    /// </summary>
    /// <param name="info"><see cref="SerializationInfo"/> object.</param>
    /// <param name="context"><see cref="StreamingContext"/> object.</param>
    public void GetObjectData(SerializationInfo info, StreamingContext context)
    {
      info.AddValue("Name",name);
      info.AddValue("Title",title);
      info.AddValue("Default",_default);
      info.AddValue("Info",this.info);
      info.AddValue("CompareOptions",compareOptions);
      info.AddValue("IsLocked",isLocked);
    }

    /// <summary>
    /// Deserialization constructor.
    /// </summary>
    /// <param name="info"><see cref="SerializationInfo"/> object.</param>
    /// <param name="context"><see cref="StreamingContext"/> object.</param>
    private Culture(SerializationInfo info, StreamingContext context)
    {
      name           = info.GetString("Name");
      title          = info.GetString("Title");
      _default       = info.GetBoolean("Default");
      this.info      = (CultureInfo)info.GetValue("Info",typeof(CultureInfo));
      compareOptions = (CompareOptions)info.GetValue("CompareOptions",typeof(CompareOptions));
      serializedIsLocked = info.GetBoolean("IsLocked");
    }

    /// <summary>
    /// Deserialization callback.
    /// </summary>
    /// <param name="sender">Object, that initiated deserialization. Currently unused.</param>
    public void OnDeserialization(object sender)
    {
      isLocked = serializedIsLocked;
    }

    /// <summary>
    /// Dumps the content of the instance.
    /// </summary>
    /// <param name="output">Writer to output to.</param>
    /// <param name="indent">Indent.</param>
    public void Dump(TextWriter output, string indent)
    {
      output.WriteLine(indent+Name+" ("+GetType().Name+"):");
      DumpMembers(output, indent+" ");
    }

    /// <summary>
    /// Dumps all member properties of the instance.
    /// </summary>
    /// <param name="output">Writer to output to.</param>
    /// <param name="indent">Indent.</param>
    public void DumpMembers(TextWriter output, string indent)
    {
      output.WriteLine(indent+"Title:        "+Title);
      if (Default)
        output.WriteLine(indent+"Default:      "+Default.ToString());
      output.WriteLine(indent+"CultureInfo:  {0} (LCID: {1})",Info.Name,Info.LCID);
      output.WriteLine(indent+"SqlCollation: "+SqlCollation);
    }
  }
}
