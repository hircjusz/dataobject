// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using DataObjects.NET;

namespace DataObjects.NET.Caching
{
  /// <summary>
  /// This interface should be implemented by any class
  /// that holds the information required to validate a
  /// particular cached <see cref="IGlobalCacheItem"/> without additional
  /// queries.
  /// </summary>
  public interface IGlobalCacheItemValidationInfo
  {
    /// <summary>
    /// Gets a key that is used as a global cache key.
    /// </summary>
    object Key {get;}
    
    /// <summary>
    /// Gets estimated size of this object in bytes.
    /// </summary>
    int Size {get;}
    
    /// <summary>
    /// <see cref="DataObject.VersionID"/> property value.
    /// </summary>
    int VersionID {get; set;}
  }
}
