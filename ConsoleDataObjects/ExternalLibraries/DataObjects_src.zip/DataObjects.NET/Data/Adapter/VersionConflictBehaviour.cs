// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using DataObjects.NET;
using DataObjects.NET.Data;

namespace DataObjects.NET.Data
{
  /// <summary>
  /// Enumerates possible <see cref="Adapter"/>'s version conflict behaviour.
  /// </summary>
  public enum VersionConflictBehaviour
  {
    /// <summary>
    /// Default version conflict behaviour. The same as <see cref="Abort"/>.
    /// Value is <see langword="0x0"/>.
    /// </summary>
    Default = 0x0,
    
    /// <summary>
    /// <see cref="Adapter"/> throws an exception on version conflict. Current <see cref="DataObject"/> will
    /// not be updated. If <see cref="UpdateOptions.IgnoreErrors"/> is set the exception will be ignored.
    /// Default behaviour.
    /// Value is <see langword="0x0"/>.
    /// </summary>
    Abort = 0x0,
    
    /// <summary>
    /// <see cref="Adapter"/> skips current <see cref="DataObject"/> update.
    /// Value is <see langword="0x1"/>.
    /// </summary>
    Skip = 0x1,
    
    /// <summary>
    /// <see cref="Adapter"/> ignores version conflict and updates current <see cref="DataObject"/>.
    /// Value is <see langword="0x2"/>.
    /// </summary>
    Ignore = 0x2
  }
}
