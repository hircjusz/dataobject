// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.IO;
using System.Collections;
using System.Threading;
using System.Data;
using System.Reflection;
using System.Diagnostics;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.EnterpriseServices;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Attributes;
using Database = DataObjects.NET.Database;
using Versionizing = DataObjects.NET.Versionizing;

namespace DataObjects.NET
{
  /// <summary>
  /// Represents a transaction (outermost or nested).
  /// </summary>
  /// <remarks>
  /// <para>
  /// DataObjects.NET supports nested transactions, <see cref="Savepoint"/>s and
  /// all isolation levels starting from <see cref="IsolationLevel">IsolationLevel.ReadCommitted</see>
  /// (and higher).
  /// </para>
  /// <seealso cref="DataObjects.NET.Session.BeginTransaction"/>
  /// <seealso cref="DataObjects.NET.Session.Commit"/>
  /// <seealso cref="DataObjects.NET.Session.Rollback"/>
  /// <seealso cref="DataObjects.NET.Session.CommitOrRollback"/>
  /// <seealso cref="TransactionContext"/>
  /// <seealso cref="TransactionalAttribute"/>
  /// <seealso cref="Savepoint"/>
  /// <seealso cref="TransactionController"/>
  /// </remarks>
  public sealed class Transaction: SessionBoundObject
  {
    /// <summary>
    /// Maximal number of attempts may be performed 
    /// to <see cref="Unlock"/> the locked transaction.
    /// </summary>
    public   const int      MaxNumberOfUnlockAttempts = 3;

    internal IsolationLevel               isolationLevel;
    internal int                          nestingLevel;
    internal Transaction                  outerTransaction;
    internal Transaction                  outermostTransaction;
    internal Transaction                  innerTransaction;
    internal TransactionContext           transactionContext;
    internal IDbTransaction               _realTransaction;
    internal TransactionController        controller;
    private  Savepoint                    startSavepoint;
    internal int                          unlockCode;
    internal int                          unlockAttemptNumber;
    internal bool                         isEnlisted;
    internal bool                         isFinished;
    internal bool                         isCommitted;
    internal bool                         isReadOnly = true;
    internal Exception                    rollbackException;
    private  DateTime                     startTime = DateTime.Now;
    private  Versionizing.TransactionInfo transactionInfo;
    
    /// <summary>
    /// Gets or sets <see cref="DataObjects.NET.Versionizing.TransactionInfo"/> 
    /// corresponding to the  <see cref="Transaction"/> instance.
    /// </summary>
    internal Versionizing.TransactionInfo TransactionInfo {
      get {
        if ((Domain.DatabaseOptions & DomainDatabaseOptions.EnableVersionizing)==0)
          return null;
        if (transactionInfo==null) {
          if (InnerTransaction!=null)
            return InnerTransaction.TransactionInfo;
          else {
            bool oldAllowModifyTransactionInfo = session.allowModifyTransactionInfo;
            session.allowModifyTransactionInfo = true;
            try {
              transactionInfo = (Versionizing.TransactionInfo)Session.CreateObject(
                typeof(Versionizing.TransactionInfo), new object[] {startTime});
            }
            finally {
              session.allowModifyTransactionInfo = oldAllowModifyTransactionInfo;
            }
          }
        }
        return transactionInfo;
      }
      set {
        transactionInfo = value;
      }
    }
    
    internal bool TransactionInfoExists()
    {
      if ((Domain.DatabaseOptions & DomainDatabaseOptions.EnableVersionizing)==0)
        return false;
      if (transactionInfo!=null)
        return true;
      if (InnerTransaction!=null)
        return InnerTransaction.TransactionInfoExists();
      return false;
    }
    
    /// <summary>
    /// Isolation level of the transaction.
    /// </summary>
    public   IsolationLevel IsolationLevel {
      get {
        return isolationLevel;
      }
    }
    
    /// <summary>
    /// Gets outer transaction for this transaction.
    /// </summary>
    public   Transaction OuterTransaction {
      get {
        return outerTransaction;
      }
    }

      public DateTime StartedOn
      {
          get { return startTime; }
      }
    /// <summary>
    /// Gets outermost transaction for this transaction.
    /// </summary>
    public   Transaction OutermostTransaction {
      get {
        return outermostTransaction;
      }
    }

    /// <summary>
    /// Gets inner transaction for this transaction.
    /// <see langword="Null"/> if inner transacttion is already finished.
    /// </summary>
    public   Transaction InnerTransaction {
      get {
        return innerTransaction;
      }
    }
    
    /// <summary>
    /// Gets the <see cref="DataObjects.NET.TransactionContext"/> related
    /// to this transaction.
    /// </summary>
    /// <remarks>
    /// <note type="note">
    /// Value of this property changes only on rollback to 
    /// <see cref="Savepoint"/> created in this transaction.
    /// Otherwise it's always returns the same object.
    /// </note>
    /// </remarks>
    public   TransactionContext TransactionContext {
      get {
        return transactionContext;
      }
    }
    internal void InvalidateTransactionContext()
    {
      transactionContext.MarkAsDirty();
      transactionContext = new TransactionContext(this);
      session.UpdateTransactionContext();
    }
    
    /// <summary>
    /// Gets transaction nesting level (<see langword="0"/> if 
    /// transaction is outermost).
    /// </summary>
    public int NestingLevel {
      get {
        return nestingLevel;
      }
    }

    /// <summary>
    /// <see langword="True"/> if transaction is outermost.
    /// In safe mode transaction can be committed only on the
    /// same stack level where it was created.
    /// <seealso cref="DataObjects.NET.Session.OutermostTransaction"/>
    /// </summary>
    public bool IsOutermost {
      get {
        return nestingLevel==0;
      }
    }
    
    /// <summary>
    /// Real (underlying) transaction.
    /// </summary>
    /// <remarks>
    /// <note type="note">You're allowed to invoke this property only when
    /// <see cref="DataObjects.NET.Session.SecurityOptions">Session.SecurityOptions</see>
    /// contains <see cref="SessionSecurityOptions.AllowAccessRealObjects"/> option.</note>
    /// </remarks>
    public IDbTransaction RealTransaction {
      get {
        if (session.disableSecurityThreads[Thread.CurrentThread]==null)
          if ((session.securityOptions & SessionSecurityOptions.AllowAccessRealObjects)==0)
            throw new SecurityException("Access to RealTransaction isn't allowed.");
        return PhysicalTransaction;
      }
    }


      public IDbTransaction PhysicalTransaction
      {
          get
          {
              if (_realTransaction is IDBTransactionProxy)
                  return (_realTransaction as IDBTransactionProxy).PhysicalTransaction;
              else
                  return _realTransaction;
          }
      }

    /// <summary>
    /// <see langword="True"/> if this transaction is a part of the distributed transaction.
    /// <seealso cref="DataObjects.NET.Session.EnlistDistributedTransaction"/>
    /// </summary>
    public bool IsEnlisted
    {
      get {
        return isEnlisted;
      }
    }
    
    /// <summary>
    /// <see langword="True"/> if transaction is already finished (committed or rolled back).
    /// </summary>
    public bool IsFinished {
      get {
        return isFinished;
      }
    }
    
    /// <summary>
    /// <see langword="True"/> if transaction is committed.
    /// </summary>
    public bool IsCommitted {
      get {
        return isCommitted;
      }
    }
    
    /// <summary>
    /// <see langword="True"/> if transaction is rolled back.
    /// </summary>
    public bool IsRolledBack {
      get {
        return isFinished && !isCommitted;
      }
    }
    
    /// <summary>
    /// Gets the <see cref="Exception"/> that caused rollback
    /// of the transaction.
    /// </summary>
    public Exception RollbackException {
      get {
        return rollbackException;
      }
    }
    
    /// <summary>
    /// <see langword="True"/> if this transaction is a read-only
    /// transaction until now. 
    /// Indicates whether some changes were 
    /// already persisted to the database in this 
    /// or nested transaction.
    /// </summary>
    public bool IsReadOnly {
      get {
        if (innerTransaction!=null)
          return innerTransaction.IsReadOnly;
        else
          return isReadOnly;
      }
    }
    
    // Transaction locking
    
    /// <summary>
    /// <see langword="True"/> if the transaction is locked.
    /// </summary>
    /// <remarks>
    /// <para>
    /// Locked transaction can be finished only after specifying 
    /// an unlock code. Nevertheless it can be rolled back on any
    /// point of time, but in this case it will be impossible to
    /// perform any type of activity before finishing such a transaction
    /// (you should pass an unlock code to do this or finish an outer 
    /// transaction to do the same implicitly).
    /// </para>
    /// <para>
    /// See <see cref="Lock"/> and <see cref="Unlock"/> methods
    /// description for the further information.
    /// </para>
    /// <seealso cref="Lock"/>
    /// <seealso cref="Unlock"/>
    /// <seealso cref="Commit"/>
    /// <seealso cref="Rollback"/>
    /// <seealso cref="CommitOrRollback"/>
    /// </remarks>
    public bool IsLocked {
      get {
        return unlockCode!=0;
      }
    }
    
    /// <summary>
    /// Locks the transaction.
    /// </summary>
    /// <returns>Unlock code.</returns>
    /// <remarks>
    /// <para>
    /// Locked transaction can be finished only after specifying 
    /// an unlock code. Nevertheless it can be rolled back on any
    /// point of time, but in this case it will be impossible to
    /// perform any type of activity before finishing such a transaction
    /// (you should pass an unlock code to do this or finish an outer 
    /// transaction to do the same implicitly).
    /// </para>
    /// <para>
    /// See <see cref="Unlock"/> method and <see cref="IsLocked"/> property
    /// description for the further information.
    /// </para>
    /// <seealso cref="Unlock"/>
    /// <seealso cref="IsLocked"/>
    /// <seealso cref="Commit"/>
    /// <seealso cref="Rollback"/>
    /// </remarks>
    public int Lock()
    {
      if (unlockCode!=0)
        throw new InvalidOperationException("Transaction is already locked.");
      if (isFinished)
        throw new TransactionIsFinishedException(rollbackException);
      unlockCode = 1+session.random.Next(0x7F000000);
      unlockAttemptNumber = 0;
      return unlockCode;
    }
    
    /// <summary>
    /// Unlocks the transaction.
    /// </summary>
    /// <remarks>
    /// <para>
    /// Locked transaction can be finished only after specifying 
    /// an unlock code. Nevertheless it can be rolled back on any
    /// point of time, but in this case it will be impossible to
    /// perform any type of activity before finishing such a transaction
    /// (you should pass an unlock code to do this or finish an outer 
    /// transaction to do the same implicitly).
    /// </para>
    /// <para>
    /// You can pass <paramref name="unlockCode"/>=<see langword="0"/>
    /// to this method - in this case no exception will be thrown if 
    /// the transaction wasn't locked, but it will be thrown otherwise.
    /// </para>
    /// <para>
    /// See <see cref="Lock"/> method and <see cref="IsLocked"/> property
    /// description for the further information.
    /// </para>
    /// <seealso cref="Lock"/>
    /// <seealso cref="IsLocked"/>
    /// <seealso cref="Commit"/>
    /// <seealso cref="Rollback"/>
    /// </remarks>
    public void Unlock(int unlockCode)
    {
      if (this.unlockCode==0) {
        if (unlockCode!=0)
          throw new InvalidOperationException("Transaction wasn't locked.");
        else
          return;
      }
      if (unlockAttemptNumber>=MaxNumberOfUnlockAttempts)
        throw new SecurityException("Too many attempts to unlock the transaction were made.");
      if (unlockCode==this.unlockCode) {
        this.unlockCode = 0;
        if (this.isFinished)
          Unbind();
        return;
      }
      else {
        unlockAttemptNumber++;
        if (unlockAttemptNumber>=MaxNumberOfUnlockAttempts)
          throw new SecurityException("Too many attempts to unlock the transaction were made.");
        throw new SecurityException("Incorrect unlock code.");
      }
    }
    
    // Commit methods
    
    /// <summary>
    /// Commits the transaction.
    /// <seealso cref="Rollback"/>
    /// <seealso cref="CommitOrRollback"/>
    /// <seealso cref="DataObjects.NET.Session.Commit"/>
    /// <seealso cref="DataObjects.NET.Session.Rollback"/>
    /// <seealso cref="DataObjects.NET.Session.CommitOrRollback"/>
    /// </summary>
    public void Commit()
    {
      session.OnBeforeTransactionCommit(this);
      
      if (isEnlisted)
        throw new InvalidOperationException("Transaction participates in distributed transaction.");
      if (isFinished) {
        if (unlockCode!=0)
          throw new TransactionIsLockedException(rollbackException);
        else
          throw new TransactionIsFinishedException(rollbackException);
      }
      if (unlockCode!=0)
        throw new TransactionIsLockedException(rollbackException);

      try {
        if (outerTransaction==null && TransactionInfoExists()) {
          bool oldAllowModifyTransactionInfo = session.allowModifyTransactionInfo;
          session.allowModifyTransactionInfo = true;
          try {
            TransactionInfo.SetProperty("User", Session.User);
          }
          finally {
            session.allowModifyTransactionInfo = oldAllowModifyTransactionInfo;
          }
        }
        session.Persist();
      }
      catch (TransactionAbortedException e) {
        rollbackException = e;
        if (!IsFinished)
          Rollback();
        throw rollbackException;
      }
      catch (Exception e) {
        rollbackException = new TransactionAbortedException(e);
        if (!IsFinished)
          Rollback();
        throw rollbackException;
      }
      
      Exception firstException = null;
      try {
        if (innerTransaction!=null)
          innerTransaction.Commit();
        if (nestingLevel==0) {
          try {
            _realTransaction.Commit();
          }
          finally {
            try { _realTransaction.Dispose(); } catch {}
          }
        }
        else
          startSavepoint.Dispose();
        isCommitted = true;
      }
      catch (Exception e) {
        firstException = e;
      }

      isFinished      = true;
      _realTransaction = null;
      startSavepoint  = null;
      if (!isCommitted)
        transactionContext.MarkAsDirty();
      else {
        if (outerTransaction!=null)
          outerTransaction.isReadOnly &= isReadOnly;
      }
      if (unlockCode==0) {
        try {
          Unbind();
        }
        catch (Exception e) {
          if (firstException==null)
            firstException = e;
        }
      }

      if (firstException!=null) {
        if (firstException is TransactionAbortedException)
          rollbackException = firstException;
        else
          rollbackException = new TransactionAbortedException(firstException);
        throw firstException;
      }
      
      if (outerTransaction!=null) {
        if (outerTransaction.transactionInfo==null && transactionInfo!=null)
          outerTransaction.transactionInfo = transactionInfo;
      }
      
      if (outerTransaction==null)
        Domain.PerformanceCounters.RegisterTransaction(this);
      
      session.OnTransactionCommit(this);
    }
    
    /// <summary>
    /// <see cref="Unlock"/>s and <see cref="Commit">commit</see>s 
    /// the transaction.
    /// </summary>
    /// <param name="unlockCode">Unlock code.</param>
    /// <remarks>
    /// <para>
    /// You can pass <paramref name="unlockCode"/>=<see langword="0"/>
    /// to this method - in this case no exception will be thrown if 
    /// the transaction wasn't locked, but it will be thrown otherwise.
    /// </para>
    /// <para>
    /// See <see cref="Lock"/> and <see cref="Unlock"/> methods
    /// description for the further information.
    /// </para>
    /// <seealso cref="Lock"/>
    /// <seealso cref="Unlock"/>
    /// <seealso cref="IsLocked"/>
    /// <seealso cref="Rollback"/>
    /// <seealso cref="CommitOrRollback"/>
    /// <seealso cref="DataObjects.NET.Session.Commit"/>
    /// <seealso cref="DataObjects.NET.Session.Rollback"/>
    /// <seealso cref="DataObjects.NET.Session.CommitOrRollback"/>
    /// </remarks>
    public void Commit(int unlockCode)
    {
      Unlock(unlockCode);
      Commit();
    }
    
    // Rollback methods
    
    /// <summary>
    /// Rolls back the transaction.
    /// <seealso cref="Commit"/>
    /// <seealso cref="CommitOrRollback"/>
    /// <seealso cref="DataObjects.NET.Session.Rollback"/>
    /// <seealso cref="DataObjects.NET.Session.Commit"/>
    /// <seealso cref="DataObjects.NET.Session.CommitOrRollback"/>
    /// </summary>
    public void Rollback()
    {
      session.OnBeforeTransactionRollback(this);

      if (isEnlisted)
        throw new InvalidOperationException("Transaction participates in distributed transaction.");
      if (isFinished) {
        if (unlockCode!=0)
          throw new TransactionIsLockedException(rollbackException);
        else
          throw new TransactionIsFinishedException(rollbackException);
      }
      if (nestingLevel!=0 && ContainsDeadlockException(rollbackException)) {
         outermostTransaction.Rollback(rollbackException);
        return;
      }

      Exception firstException = null;
      try {
        session.PersistOnRollback();
      }
      catch (Exception e) {
        firstException = e;
      }

      try {
        if (innerTransaction!=null)
          innerTransaction.FastRollback();
        if (nestingLevel==0) {
          try {
            _realTransaction.Rollback();
          }
          finally {
            try { _realTransaction.Dispose(); } catch {}
          }
        }
        else
          startSavepoint.RollbackWithoutInvalidatingTransactionContext();
      }
      catch {}

      isFinished      = true;
      _realTransaction = null;
      startSavepoint  = null;
      transactionContext.MarkAsDirty();
      if (unlockCode==0) {
        try {
          Unbind();
        }
        catch (Exception e) {
          if (firstException==null)
            firstException = e;
        }
      }

      if (firstException!=null) {
        if (rollbackException==null) {
          if (firstException is TransactionAbortedException)
            rollbackException = firstException;
          else
            rollbackException = new TransactionAbortedException(firstException);
        }
      }
      
      if (outerTransaction==null)
        Domain.PerformanceCounters.RegisterTransaction(this);
      
      session.OnTransactionRollback(this);
    }

    private bool ContainsDeadlockException(Exception e)
    {
      while (true) {
        if (e==null)
          return false;
        if (e is DeadlockException)
          return true;
        e = e.InnerException;
      }
    }

    /// <summary>
    /// <see cref="Unlock"/>s and <see cref="Rollback">rolls back</see>
    /// the transaction.
    /// </summary>
    /// <param name="unlockCode">Unlock code.</param>
    /// <remarks>
    /// <para>
    /// You can pass <paramref name="unlockCode"/>=<see langword="0"/>
    /// to this method - in this case no exception will be thrown if 
    /// the transaction wasn't locked, but it will be thrown otherwise.
    /// </para>
    /// <para>
    /// See <see cref="Lock"/> and <see cref="Unlock"/> methods
    /// description for the further information.
    /// </para>
    /// <seealso cref="Lock"/>
    /// <seealso cref="Unlock"/>
    /// <seealso cref="IsLocked"/>
    /// <seealso cref="Commit"/>
    /// <seealso cref="CommitOrRollback"/>
    /// <seealso cref="DataObjects.NET.Session.Commit"/>
    /// <seealso cref="DataObjects.NET.Session.Rollback"/>
    /// <seealso cref="DataObjects.NET.Session.CommitOrRollback"/>
    /// </remarks>
    public void Rollback(int unlockCode)
    {
      try {
        Unlock(unlockCode);
      }
      finally {
        Rollback(); // Rollback should occur anyway!
      }
    }
    
    /// <summary>
    /// Rolls back the transaction.
    /// <param name="rollbackException">Exception that caused the rollback.</param>
    /// <seealso cref="RollbackException"/>
    /// <seealso cref="Commit"/>
    /// <seealso cref="CommitOrRollback"/>
    /// <seealso cref="DataObjects.NET.Session.Rollback"/>
    /// <seealso cref="DataObjects.NET.Session.Commit"/>
    /// <seealso cref="DataObjects.NET.Session.CommitOrRollback"/>
    /// </summary>
    public void Rollback(Exception rollbackException)
    {
      if (!isFinished)
        this.rollbackException = rollbackException;
      Rollback();
    }
    
    /// <summary>
    /// <see cref="Unlock"/>s and <see cref="Rollback">rolls back</see>
    /// the transaction.
    /// </summary>
    /// <param name="rollbackException">Exception that caused the rollback.</param>
    /// <param name="unlockCode">Unlock code.</param>
    /// <remarks>
    /// <para>
    /// You can pass <paramref name="unlockCode"/>=<see langword="0"/>
    /// to this method - in this case no exception will be thrown if 
    /// the transaction wasn't locked, but it will be thrown otherwise.
    /// </para>
    /// <para>
    /// See <see cref="Lock"/> and <see cref="Unlock"/> methods
    /// description for the further information.
    /// </para>
    /// <seealso cref="RollbackException"/>
    /// <seealso cref="Lock"/>
    /// <seealso cref="Unlock"/>
    /// <seealso cref="IsLocked"/>
    /// <seealso cref="Commit"/>
    /// <seealso cref="CommitOrRollback"/>
    /// <seealso cref="DataObjects.NET.Session.Rollback"/>
    /// <seealso cref="DataObjects.NET.Session.Commit"/>
    /// <seealso cref="DataObjects.NET.Session.CommitOrRollback"/>
    /// </remarks>
    public void Rollback(Exception rollbackException, int unlockCode)
    {
      if (!isFinished)
        this.rollbackException = rollbackException;
      try {
        Unlock(unlockCode);
      }
      finally {
        Rollback(); // Rollback should occur anyway!
      }
    }
    
    private void FastRollback()
    {
      if (innerTransaction!=null)
        innerTransaction.FastRollback();

      isFinished       = true;
      _realTransaction  = null;
      if (startSavepoint!=null) {
        startSavepoint.FastRollback();
        startSavepoint = null;
      }
      transactionContext.MarkAsDirty();
      // unlockCode       = 0;
      if (nestingLevel!=0)
        outerTransaction.innerTransaction = null;
    }
    
    // CommitOrRollback methods
    
    /// <summary>
    /// <see cref="Commit"/>s \ <see cref="Rollback">rolls back</see> 
    /// the transaction depending on the value of 
    /// <paramref name="rollbackException"/> parameter.
    /// </summary>
    /// <param name="rollbackException">Exception that caused the rollback, or
    /// <see langword="null"/>, if no exception occured (in this case
    /// transaction will be <see cref="Commit"/>ted.</param>
    /// <remarks>
    /// <para>
    /// See <see cref="Commit"/> and <see cref="Rollback"/> methods
    /// description for the further information.
    /// </para>
    /// <seealso cref="Commit"/>
    /// <seealso cref="Rollback"/>
    /// <seealso cref="RollbackException"/>
    /// <seealso cref="DataObjects.NET.Session.Commit"/>
    /// <seealso cref="DataObjects.NET.Session.Rollback"/>
    /// <seealso cref="DataObjects.NET.Session.CommitOrRollback"/>
    /// </remarks>
    public void CommitOrRollback(Exception rollbackException)
    {
      if (rollbackException==null)
        Commit();
      else
        Rollback(rollbackException);
    }
    
    /// <summary>
    /// <see cref="Unlock"/>s the transaction and <see cref="Commit"/>s \
    /// <see cref="Rollback">rolls back</see> it depending on the value 
    /// of <paramref name="rollbackException"/> parameter.
    /// </summary>
    /// <param name="rollbackException">Exception that caused the rollback, or
    /// <see langword="null"/>, if no exception occured (in this case
    /// transaction will be <see cref="Commit"/>ted.</param>
    /// <param name="unlockCode">Unlock code.</param>
    /// <remarks>
    /// <para>
    /// You can pass <paramref name="unlockCode"/>=<see langword="0"/>
    /// to this method - in this case no exception will be thrown if 
    /// the transaction wasn't locked, but it will be thrown otherwise.
    /// </para>
    /// <para>
    /// See <see cref="Commit"/>, <see cref="Rollback"/>, 
    /// <see cref="Lock"/> and <see cref="Unlock"/> methods
    /// description for the further information.
    /// </para>
    /// <seealso cref="Commit"/>
    /// <seealso cref="Rollback"/>
    /// <seealso cref="RollbackException"/>
    /// <seealso cref="Lock"/>
    /// <seealso cref="Unlock"/>
    /// <seealso cref="IsLocked"/>
    /// <seealso cref="DataObjects.NET.Session.Commit"/>
    /// <seealso cref="DataObjects.NET.Session.Rollback"/>
    /// <seealso cref="DataObjects.NET.Session.CommitOrRollback"/>
    /// </remarks>
    public void CommitOrRollback(Exception rollbackException, int unlockCode)
    {
      if (rollbackException==null)
        Commit(unlockCode);
      else
        Rollback(rollbackException, unlockCode);
    }
    
    // Private\internal methods
    
    private void Unbind()
    {
      if (nestingLevel==0) {
        session.InternalSetOutermostTransaction(null);
        if ((session.Options & SessionOptions.DisableAutoDisconnect) == 0)
        {
            session.CloseConnection();
        }
//SM begin
        else
        {
            DataObjects.NET.Caching.ConnectionCleaner.getInstance().register(session, session.RealConnection);
        }
//SM end
      }
      else {
        outerTransaction.innerTransaction = null;
        session.InternalSetTransaction(outerTransaction);
        if (isolationLevel!=outerTransaction.IsolationLevel) {
          try {
            session.persister.ChangeIsolationLevel(outerTransaction.IsolationLevel);
          }
          catch (Exception e) {
            throw session.utils.SubstituteException(e);
          }
        }
      }
    }
    
    // Savepoints

    /// <summary>
    /// Rolls back the transaction to the specified savepoint.
    /// <seealso cref="DataObjects.NET.Savepoint.Rollback"/>
    /// </summary>
    public  void Rollback(Savepoint savepoint)
    {
      savepoint.Rollback();
    }
    
    /// <summary>
    /// Creates a new savepoint in the transaction.
    /// <seealso cref="DataObjects.NET.Session.CreateSavepoint"/>
    /// </summary>
    /// <returns>New savepoint.</returns>
    public Savepoint CreateSavepoint()
    {
      return new Savepoint(this);
    }
    
    
    // Constructors
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// <seealso cref="DataObjects.NET.Session.BeginTransaction"/>
    /// </summary>
    /// <remarks>
    /// In safe mode transaction can be committed\rolled back only on the
    /// same stack level where it was created.
    /// </remarks>
    /// <param name="session">Session where transaction executes.</param>
    /// <param name="isolationLevel">Isolation level.</param>
    public Transaction(Session session, IsolationLevel isolationLevel):
      base(session)
    {
      Transaction sTransaction = session.transaction;
      if (sTransaction==null) {
        // Outermost transaction creation
        if (isolationLevel==IsolationLevel.Unspecified)
          isolationLevel = session.DefaultIsolationLevel;
        if (isolationLevel<IsolationLevel.ReadCommitted)
          throw new InvalidOperationException("Isolation level should be ReadCommitted or higher.");
        if (session.disableSecurityThreads[Thread.CurrentThread]==null) {
          if (isolationLevel==IsolationLevel.ReadCommitted) {
            if ((session.securityOptions & SessionSecurityOptions.AllowIsolationLevelReadCommitted)==0)
              throw new SecurityException("ReadCommitted isolation level isn't allowed.");
          }
          else if (isolationLevel==IsolationLevel.RepeatableRead) {
            if ((session.securityOptions & SessionSecurityOptions.AllowIsolationLevelRepeatableRead)==0)
              throw new SecurityException("RepeatableRead isolation level isn't allowed.");
          }
          else if (isolationLevel==IsolationLevel.Serializable) {
            if ((session.securityOptions & SessionSecurityOptions.AllowIsolationLevelSerializable)==0)
              throw new SecurityException("Serializable isolation level isn't allowed.");
          }
        }
        this.isolationLevel  = isolationLevel;
        this.nestingLevel    = 0;
          
        try {
          if (!session.IsConnectionOpened)
            session.OpenConnection();
          _realTransaction = session.persister.BeginTransaction(isolationLevel);
        }
        catch (Exception e) {
          isFinished      = true;
          _realTransaction = null;
          throw new TransactionAbortedException(session.utils.SubstituteException(e));
        }

        outermostTransaction = this;
        transactionContext   = new TransactionContext(this);
        session.InternalSetOutermostTransaction(this);
      }
      else {
        if (sTransaction.isFinished)
          throw new TransactionIsLockedException(
            "Can't begin new transaction - outer transaction is locked.", sTransaction.RollbackException);
        // Inner transaction creation
        session.Persist();
        if (isolationLevel==IsolationLevel.Unspecified)
          isolationLevel = sTransaction.IsolationLevel;
        else if (isolationLevel!=sTransaction.IsolationLevel)
          session.persister.ChangeIsolationLevel(isolationLevel);
        this.session          = session;
        this.outerTransaction = session.transaction;
        this.outermostTransaction = session.outermostTransaction;
        this.isolationLevel   = isolationLevel;
        this.nestingLevel     = outerTransaction.nestingLevel+1;
        this._realTransaction  = outerTransaction._realTransaction;
        this.isReadOnly       = outerTransaction.isReadOnly;

        try {
          this.startSavepoint = new Savepoint(this, true);
        }
        catch (Exception e) {
          isFinished      = true;
          _realTransaction = null;
          throw new TransactionAbortedException(session.utils.SubstituteException(e));
        }

        outerTransaction.innerTransaction = this;
        transactionContext = new TransactionContext(this);
        session.InternalSetTransaction(this);
      }
      session.OnTransactionBegin(this);
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// <seealso cref="DataObjects.NET.Session.BeginTransaction"/>
    /// </summary>
    /// <remarks>
    /// This constructor enlists session in distributed transaction.
    /// </remarks>
    /// <param name="session">Session where transaction executes.</param>
    /// <param name="isolationLevel">Isolation level.</param>
    /// <param name="transaction">A reference to an existing transaction in which to enlist.</param>
    public Transaction(Session session, IsolationLevel isolationLevel, ITransaction transaction):
      base(session)
    {
      bool bSessionSecurityEnabled = session.disableSecurityThreads[Thread.CurrentThread]==null;
      if (bSessionSecurityEnabled)
        if ((session.securityOptions & SessionSecurityOptions.AllowEnlistDistributedTransaction)==0)
          throw new SecurityException("Participation in distributed transaction isn't allowed.");
      if (session.transaction!=null)
        throw new InvalidOperationException("Running transaction exists.");

      if (isolationLevel==IsolationLevel.Unspecified)
        isolationLevel = session.DefaultIsolationLevel;
      if (isolationLevel<IsolationLevel.ReadCommitted)
        throw new InvalidOperationException("Isolation level should be ReadCommitted or higher.");
      if (bSessionSecurityEnabled) {
        if (isolationLevel==IsolationLevel.ReadCommitted) {
          if ((session.securityOptions & SessionSecurityOptions.AllowIsolationLevelReadCommitted)==0)
            throw new SecurityException("ReadCommitted isolation level isn't allowed.");
        }
        else if (isolationLevel==IsolationLevel.RepeatableRead) {
          if ((session.securityOptions & SessionSecurityOptions.AllowIsolationLevelRepeatableRead)==0)
            throw new SecurityException("RepeatableRead isolation level isn't allowed.");
        }
        else if (isolationLevel==IsolationLevel.Serializable) {
          if ((session.securityOptions & SessionSecurityOptions.AllowIsolationLevelSerializable)==0)
            throw new SecurityException("Serializable isolation level isn't allowed.");
        }
      }
      if (!session.IsConnectionOpened)
        session.OpenConnection();

      this.session         = session;
      this.isolationLevel  = isolationLevel;
      this.nestingLevel    = 0;
        
      isEnlisted           = true;
      _realTransaction      = null;
      outermostTransaction = this;
      session.persister.EnlistDistributedTansaction(transaction, isolationLevel);
      transactionContext   = new TransactionContext(this);
      session.InternalSetOutermostTransaction(this);
      session.OnTransactionBegin(this);
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// <seealso cref="DataObjects.NET.Session.BeginTransaction"/>
    /// </summary>
    /// <remarks>
    /// This constructor enlists session in distributed transaction.
    /// </remarks>
    /// <param name="session">Session where transaction executes.</param>
    /// <param name="transaction">A reference to an existing transaction in which to enlist.</param>
    public Transaction(Session session, ITransaction transaction): this(session, IsolationLevel.Unspecified, transaction)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// <seealso cref="DataObjects.NET.Session.BeginTransaction"/>
    /// </summary>
    /// <param name="session">Session where transaction executes.</param>
    public Transaction(Session session): this(session, IsolationLevel.Unspecified)
    {
    }
  }

  // SM BEGIN

  public interface IDBTransactionProxy
  {
      IDbTransaction PhysicalTransaction { get;}
  }

  public class TransactionOnDemand : IDbTransaction, IDBTransactionProxy
  {
      #region IDbTransaction Members

      private IDbConnection connection;
      private IsolationLevel isolationLevel;
      private IDbTransaction physicalTransaction;

      public TransactionOnDemand(IsolationLevel level, IDbConnection connection)
      {
          this.connection = connection;
          this.isolationLevel = level;
          this.physicalTransaction = null;
      }

      void IDbTransaction.Commit()
      {
          if (physicalTransaction != null)
              physicalTransaction.Commit();
      }

      public IDbTransaction PhysicalTransaction
      {
          get
          {
              if (connection != null)
              {
                  if (physicalTransaction == null)
                      physicalTransaction = connection.BeginTransaction(isolationLevel);
                  return physicalTransaction;
              }
              return null;
          }
      }


      IDbConnection IDbTransaction.Connection
      {
          get
          {
              if (physicalTransaction == null && connection != null)
              {
              }
              return this.connection;
          }
      }

      IsolationLevel IDbTransaction.IsolationLevel
      {
          get { return this.isolationLevel; }
      }

      void IDbTransaction.Rollback()
      {
          if (physicalTransaction != null)
              physicalTransaction.Rollback();
      }

      #endregion

      #region IDisposable Members

      void IDisposable.Dispose()
      {
          if (this.physicalTransaction != null)
          {
              this.physicalTransaction.Dispose();
              this.physicalTransaction = null;
          }
          this.connection = null;
      }

      #endregion
  }
  // SM END
}
