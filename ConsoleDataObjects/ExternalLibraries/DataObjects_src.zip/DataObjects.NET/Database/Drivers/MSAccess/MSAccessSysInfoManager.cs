// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;
using System.Data;
using System.Data.OleDb;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Attributes;

namespace DataObjects.NET.Database.Drivers.MSAccess
{
  /// <summary>
  /// Microsoft Access implementation of <see cref="SysInfoManager"/>.
  /// </summary>
  public class MSAccessSysInfoManager: SysInfoManager
  {
    /// <summary>
    /// Fetches the value for the given key.
    /// </summary>
    /// <param name="name">The key.</param>
    /// <returns>The value for the given key, or <see langword="null"/>.</returns>
    public override string GetSysInfoValue(string name)
    {
      string RetVal = null;
      try {
        using (OleDbCommand Ucmd = (OleDbCommand)CreateCommand()) {
          Ucmd.CommandText = "SELECT top 1 * from @tablename where Name='@wantedname'";
          Ucmd.Parameters.Add("@wantedname",OleDbType.VarChar,name.Length).Value=name;
          Ucmd.Parameters.Add("@tablename",OleDbType.VarChar,127).Value=Driver.Domain.DatabaseModel.SysInfoTable.Name;
          using (IDataReader Usr = Ucmd.ExecuteReader()) {
            IDataRecord Urd = (IDataRecord)Usr;
            if (Usr.Read())
              RetVal = Urd.GetString(1); 
            Usr.Close();
          }
        }
      }
      catch (Exception e) {
        throw new DatabaseDriverException("Couldn't get System Info ("+e.Message+").");
      }
      return RetVal;
    }
    
    /// <summary>
    /// Sets the value for the given key.
    /// </summary>
    /// <remarks>This method adds or replaces key\value pair.</remarks>
    /// <param name="name">The key.</param>
    /// <param name="value">The value of the key.</param>
    public override void SetSysInfoValue(string name, string value)
    {
      try {
        using (OleDbCommand Ucmd = (OleDbCommand)CreateCommand()) {
          if (GetSysInfoValue(name) != null)
            Ucmd.CommandText = "INSERT into @tablename values ('@key','@value')";
          else 
            Ucmd.CommandText = "UPDATE @tablename set Value='@value' where Name='@key'";

          Ucmd.Parameters.Add("@key",OleDbType.VarChar,name.Length).Value=name;
          Ucmd.Parameters.Add("@value",OleDbType.LongVarChar,value.Length).Value=value;
          Ucmd.Parameters.Add("@tablename",OleDbType.VarChar,127).Value=Driver.Domain.DatabaseModel.SysInfoTable.Name;
          Ucmd.ExecuteNonQuery();
        }
      }
      catch (Exception e) {
        throw new DatabaseDriverException("Couldn't grab System Info ("+e.Message+").");
      }
    }
    
    /// <summary>
    /// Fetches all key\value pairs from the SysInfo table.
    /// </summary>
    /// <returns>Hashtable containing all key\value pairs.</returns>
    public override Hashtable GetAllSysInfo()
    {
      Hashtable RetVal =  new Hashtable();
      try {
        using (OleDbCommand Ucmd =   (OleDbCommand)CreateCommand()) {
          Ucmd.CommandText =  "SELECT * from @tablename";
          Ucmd.Parameters.Add("@tablename",OleDbType.VarChar,127).Value=Driver.Domain.DatabaseModel.SysInfoTable.Name;
          using (IDataReader Usr = Ucmd.ExecuteReader()) {
            IDataRecord Urd = (IDataRecord)Usr;
            while (Usr.Read())
              RetVal.Add(Urd.GetString(0),Urd.GetString(1)); 
            Usr.Close();
          }
        }
      }
      catch (Exception e) {
        throw new DatabaseDriverException("Couldn't grab System Info ("+e.Message+").");
      }
      return RetVal;
    }
    
    
    // Constructor

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="driver">Driver to which this instance will be bound.</param>
    /// <param name="connection">Connection through which this instance should operate.</param>
    /// <param name="transaction">Transaction, in which this utility works.</param>
    public MSAccessSysInfoManager(Driver driver, IDbConnection connection, IDbTransaction transaction):
      base(driver, connection, transaction)
    {
    }
  }
}
