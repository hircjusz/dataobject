// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;

namespace DataObjects.NET.Attributes
{
  /// <summary>
  /// Enumerates possible types of property accessors 
  /// for <see cref="DemandAttribute"/> attribute.
  /// </summary>
  [Flags]
  public enum AccessorType
  {
    /// <summary>
    /// Indicates that attribute is applied on both 
    /// property accessors (getter and setter) or on the method.
    /// Default value.
    /// Value is <see langword="0x3"/>
    /// </summary>
    All = 0x3, 

    /// <summary>
    /// Indicates that attribute is applied on property getter.
    /// Value is <see langword="0x1"/>
    /// </summary>
    Get = 0x1,
    
    /// <summary>
    /// Indicates that attribute is applied on property setter.
    /// Value is <see langword="0x1"/>
    /// </summary>
    Set = 0x2
  }
}
