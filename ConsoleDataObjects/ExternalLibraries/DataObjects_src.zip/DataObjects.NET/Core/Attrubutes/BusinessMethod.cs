// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using DataObjects.NET.Remoting;

namespace DataObjects.NET.Attributes
{
  /// <summary>
  /// Indicates that internal or protected online method 
  /// is safe for calling from the offline layer (i.e. it
  /// can be invoked via <see cref="IMethodCallTarget.Invoke"/>) 
  /// method.
  /// </summary>
  /// <remarks>
  /// <note>Any public method is always considered as business method.</note>
  /// </remarks>
  [AttributeUsage(AttributeTargets.Method, AllowMultiple = false, Inherited = true)]
  [Serializable]
  public class BusinessMethodAttribute: DataObjectAttribute
  {
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    public BusinessMethodAttribute() 
    {
    }
  }
}
