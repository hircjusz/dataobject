// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.IO;
using System.Collections;
using System.Reflection;
using System.Runtime.Serialization;
using System.Security.Cryptography;

namespace DataObjects.NET
{
  /// <summary>
  /// Base class for any DataObjects.NET exception.
  /// </summary>
  [Serializable]
  public class DataObjectsDotNetException: Exception
  {
  #if !EXPRESS
    internal void SetDomainInternally(Domain domain)
    {
      Hashtable ht = domain.GetRegisteredFieldTypesHash();
      if (ht==null)
        goto HeHe;
        
      // Strong name check
      Assembly a = Assembly.GetExecutingAssembly();
      string ptk = a.FullName.Substring(a.FullName.LastIndexOf("=")+1);
      ulong  lptk = unchecked((ulong)-104091625606292379L);
      if (ptk!=(lptk-2).ToString("x"))
        goto HeHe;
      
      byte[] buffer = new byte[ht.Count];
      for (int i = 0; i<ht.Count; i++)
        buffer[i] = (byte)(ht[i]);
      
      // Product Key validation
      try {
        using (MemoryStream ms = new MemoryStream(buffer, false)) {
          int hashLen = 8;
          byte[] nHash = new byte[hashLen];
          ms.Read(nHash,0,nHash.Length);
          RijndaelManaged rm = new RijndaelManaged();
          // Visual Studio 2005 beta 2 bug workaround, see 
          // http://www.x-tensive.com/Forum/viewtopic.php?t=700
          rm.Padding = PaddingMode.Zeros;
          byte[] cKey = new byte[rm.KeySize/8];
          for (int i = 0; i<(rm.KeySize/8); i++)
            cKey[i] = nHash[i%8];
          byte[] cIV = new byte[rm.BlockSize/8];
          for (int i = 0; i<(rm.BlockSize/8); i++)
            cIV[i] = nHash[i%8];

          int signatureLen = 48;
          int headLen = buffer.Length-signatureLen;
          byte[] head      = new byte[headLen];
          byte[] signature = new byte[signatureLen];

          int pfxLen = 0; 
          byte[] pfx = null;
          using (CryptoStream cs = new CryptoStream(ms,rm.CreateDecryptor(cKey,cIV),CryptoStreamMode.Read)) {
            pfxLen = cs.ReadByte();
            pfx = new byte[pfxLen];
            cs.Read(pfx,0,pfx.Length);
            ms.Position = 0;
            ms.Read(head,0,head.Length);
            ms.Read(signature,0,signature.Length);
          }
          // MONO: memory stream will be disposed here during CryptoStream disposing.
          // So we should perform all needed operations with MemoryStream before we leave preceding 
          // block 'using' for CryptoStream
          string[] keyData = new string[] {
            "<","R","SA","Key","Value",">",
              "<","Mod","ulus",">",
                "m6","Dc","Iw","fs","8s","Nt","1y","Ol","Yn","Us","a4","qOD","mc","Q6","ZJ","0o","yCb","l0","SZ","Vf","A6","GB","QZ","Jc","rA","1WG","Os","7l","H7","Wf","L",
              "</","Mod","ulus",">",
              "<","Exp","on","e","nt",">",
                "AQ","AB",
              "</","Exp","on","en","t",">",
            "</","R","SA","Key","Value",">"
            };
          CspParameters cspParams = new CspParameters();
          cspParams.Flags = CspProviderFlags.UseMachineKeyStore;
          RSACryptoServiceProvider rsa = new RSACryptoServiceProvider(cspParams);
          rsa.FromXmlString(String.Join("",keyData));
          if (!rsa.VerifyData(head,String.Join("",new string[] {"SH","A1"}),signature))
            goto HeHe;
        }
      }
      catch (Exception) {
        goto HeHe;
      }
      return;
      
      HeHe:
      if (domain.ObjectModel!=null)
        if (!domain.ObjectModel.IsLocked)
          domain.ObjectModel.Types.Clear();
      if (domain.DatabaseModel!=null)
        if (!domain.DatabaseModel.IsLocked) {
          domain.DatabaseModel.Views.Clear();
          domain.DatabaseModel.Tables.Clear();
        }
    }
  #endif
    
    /// <summary>
    /// Gets the innermost exception of the current exception.
    /// </summary>
    public Exception InnermostException {
      get {
        Exception e = this;
        while (true) {
          Exception innerE = e.InnerException;
          if (innerE==null)
            break;
          e = innerE;
        }
        return e;
      }
    }
    

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    public DataObjectsDotNetException(): this("DataObjects.NET error.") 
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="text">Text of message.</param>
    public DataObjectsDotNetException(string text): base(text) 
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="text">Text of message.</param>
    /// <param name="innerException">Inner exception.</param>
    public DataObjectsDotNetException(string text, Exception innerException): 
      base(
        (innerException!=null ?
         String.Format("{0} Inner exception: {1}: {2}",text,innerException.GetType().FullName,innerException.Message) :
         text
        ),innerException) 
    {
    }
    
    /// <summary>
    /// Deserialization constructor.
    /// </summary>
    /// <param name="info"><see cref="SerializationInfo"/> object.</param>
    /// <param name="context"><see cref="StreamingContext"/> object.</param>
    protected DataObjectsDotNetException(SerializationInfo info, StreamingContext context):
      base(info, context)
    {
    }
  }
}
