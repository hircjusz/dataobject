// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.IO;
using System.Data;
using System.Threading;
using System.Configuration;
using System.Diagnostics;
using System.Globalization;
using System.Collections;
using DataObjects.NET;
using DataObjects.NET.Attributes;
using DataObjects.NET.Exceptions;

namespace DataObjects.NET.Security
{
  /// <summary>
  /// Collection of <see cref="Role"/>s.
  /// </summary>
  public abstract class RoleCollection: DataObjectCollection
  {
    /// <summary>
    /// Adds new element to the collection.
    /// </summary>
    /// <param name="item">Item to add.</param>
    /// <returns>Index of newly added item.</returns>
    [Transactional(TransactionMode.Disabled)]
    public int Add(Role item) 
    {
      return List.Add(item);
    }

    /// <summary>
    /// Gets or sets the element of collection by its index.
    /// </summary>
    [Transactional(TransactionMode.Disabled)]
    public new Role this[int n] {
      get {
        return (Role)List[n];
      }
      set {
        List[n] = value;
      }
    }

    /// <summary>
    /// Performs additional custom processes when validating a value.
    /// </summary>
    /// <param name="value">The object to validate.</param>
    /// <remarks>
    /// The default Implementation of this method determines whether value is a <see langword="null"/> 
    /// reference (Nothing in Visual Basic), and, if so, throws <see cref="ArgumentNullException"/>. 
    /// It is intended to be overridden by a derived class to perform additional action 
    /// when the specified element is validated.
    /// </remarks>
    [Transactional(TransactionMode.Disabled)]
    protected override void OnValidate(DataObject value)
    {
      base.OnValidate(value);
      Role roleToAdd = value as Role;
      if (roleToAdd==null)
        throw new ArgumentException("An attempt to add null or non Role instance to RoleCollection.");
      Role currentRole = this.Owner as Role;
      if (currentRole!=null) {
        Role[] roles = roleToAdd.AllRoles;
        for (int i=0, count=roles.Length; i<count; i++) {
          if (roles[i]==currentRole)
            throw new InvalidOperationException("Operation causes a cycle in the Roles graph.");
        }
      }
    }

    // Contrsuctors
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="itemType">Type of collection items.</param>
    public RoleCollection(System.Type itemType): base(itemType)
    {
      if (!(itemType==typeof(Role) || itemType.IsSubclassOf(typeof(Role))))
        throw new ObjectModelBuilderException(
          String.Format("Illegal ItemType value: \"{0}\".",itemType)
          );
    }
  }
}
