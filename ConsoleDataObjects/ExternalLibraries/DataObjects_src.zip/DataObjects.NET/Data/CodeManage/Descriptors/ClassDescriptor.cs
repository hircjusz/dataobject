// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;
using System.Reflection;
#if !MONO
using EnvDTE;
#endif

namespace DataObjects.NET.Data.CodeManage
{
  /// <summary>
  /// Describes an object.
  /// </summary>
  internal class ClassDescriptor: IClassDescriptor
  {
    private CodeManagerBase codeManager;
    private string name;
    private string dbName;
    private IClassDescriptor baseType;
    private ICollectionDescriptor[] collections;
    private IFieldDescriptor[] fields;
    private IClassDescriptor[] derivedObjects;
    private IInterfaceDescriptor[] implements;

    /// <summary>
    /// Code manager.
    /// </summary>
    public CodeManagerBase CodeManager {
      get {
        return codeManager;
      }
    }
  
    /// <summary>
    /// Gets base type descriptor.
    /// </summary>
    public IClassDescriptor BaseType
    {
      get {
        return baseType;
      }
    }
    
    /// <summary>
    /// Gets child collections.
    /// </summary>
    public ICollectionDescriptor[] Collections {
      get {
        return collections;
      }
    }

    /// <summary>
    /// Gets child fields.
    /// </summary>
    public IFieldDescriptor[] Fields {
      get {
        return fields;
      }
    }
    
    /// <summary>
    /// Gets derived classes.
    /// </summary>
    public IClassDescriptor[] DerivedClasses {
      get {
        return derivedObjects;
      }
    }
    
    /// <summary>
    /// Gets implemented interfaces.
    /// </summary>
    public IInterfaceDescriptor[] Implements {
      get {
        return implements;
      }
    }

    /// <summary>
    /// Gets class name.
    /// </summary>
    public string Name {
      get {
        return name;
      }
    }

    /// <summary>
    /// Gets class full name.
    /// </summary>
    public string FullName {
      get {
        return name;
      }
    }
    
    /// <summary>
    /// Element database name.
    /// </summary>
    /// <remarks>May be null.</remarks>
    public string DbName {
      get {
        return dbName;
      }
    }
    
    /// <summary>
    /// Initializes a new instance of the <see cref="ClassDescriptor"/> class.
    /// </summary>
    /// <param name="baseType">Base type descriptor. Value can be null.</param>
    /// <param name="thisClass"><see cref="ObjectModel.Type"/> of class.</param>
    /// <param name="codeManager"><see cref="RuntimeCodeManager"/>.</param>
    internal ClassDescriptor(IClassDescriptor baseType, ObjectModel.Type thisClass, RuntimeCodeManager codeManager)
    {
      if (thisClass==null)
        throw new ArgumentNullException("thisClass");
      if (codeManager==null)
        throw new ArgumentNullException("codeManager");
        
      this.codeManager = codeManager;
      this.name = thisClass.SourceType.FullName;
      this.baseType = baseType;
      this.dbName = thisClass.DbName;
      
      ArrayList collectionsList = new ArrayList();
      ArrayList fieldsList = new ArrayList();
      Hashtable propertyByName = new Hashtable();
      PropertyInfo[] properties = thisClass.SourceType.GetProperties(BindingFlags.Public | BindingFlags.Instance);
      foreach (PropertyInfo property in properties) {
        if (!propertyByName.ContainsKey(property.Name)) {
          System.Type propertyType = property.PropertyType;
          if (propertyType==typeof(DataObjectCollection) || propertyType.IsSubclassOf(typeof(DataObjectCollection))) {
            CollectionDescriptor cd = new CollectionDescriptor(this, property);
            collectionsList.Add(cd);
          } else if (propertyType==typeof(ValueTypeCollection) || propertyType.IsSubclassOf(typeof(ValueTypeCollection))) {
            ValueTypeCollectionDescriptor vtcd = new ValueTypeCollectionDescriptor(this, property);
            collectionsList.Add(vtcd);
          } else {
            FieldDescriptor fd = new FieldDescriptor(this, property);
            fieldsList.Add(fd);
          }
          propertyByName[property.Name] = property;
        }
      }
      collections = (ICollectionDescriptor[])collectionsList.ToArray(typeof(ICollectionDescriptor));
      fields = (IFieldDescriptor[])fieldsList.ToArray(typeof(IFieldDescriptor));
      
      ArrayList implementsList = new ArrayList();
      foreach (ObjectModel.Type it in thisClass.Interfaces) {
        IInterfaceDescriptor id = codeManager.GetInterface(it.SourceType.FullName);
        if (id!=null)
          implementsList.Add(id);
      }
      implements = (IInterfaceDescriptor[])implementsList.ToArray(typeof(IInterfaceDescriptor));
      
      ArrayList derivedObjectsList = new ArrayList();
      ArrayList derivedTypes = codeManager.GetDerivedClasses(this.FullName);
      if (derivedTypes!=null) {
        foreach (ObjectModel.Type derivedType in derivedTypes) {
          derivedObjectsList.Add(new ClassDescriptor(this, derivedType, codeManager));
        }
      }
      derivedObjects = (IClassDescriptor[])derivedObjectsList.ToArray(typeof(IClassDescriptor));
    }

    #if !MONO
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="baseType">Base type descriptor. Value can be null.</param>
    /// <param name="thisClass"><see cref="CodeClass"/>.</param>
    /// <param name="codeManager"><see cref="DesigntimeCodeManager"/>.</param>
    internal ClassDescriptor(IClassDescriptor baseType, CodeClass thisClass, DesigntimeCodeManager codeManager)
    {
      if (thisClass==null)
        throw new ArgumentNullException("thisClass");
      if (codeManager==null)
        throw new ArgumentNullException("codeManager");
    
      this.codeManager = codeManager;
      this.name = thisClass.FullName;
      this.baseType = baseType;
      
      int attributesCount = 0;
      try {
        attributesCount = thisClass.Attributes.Count;
      } catch {}
      for (int i = 0; i < attributesCount; i++) {
        CodeElement attrElement = thisClass.Attributes.Item(i + 1);
        if (attrElement.Kind==vsCMElement.vsCMElementAttribute) {
          CodeAttribute attr = (CodeAttribute)attrElement;
          if (attr.FullName=="DataObjects.NET.Attributes.DbNameAttribute") {
            string val = attr.Value;
            if (val.StartsWith("\"") && val.EndsWith("\"")) {
              dbName = val.Substring(1, val.Length - 2);
              break;
            }
          }
        }
      }
      
      ArrayList implementsList = new ArrayList();
      codeManager.FillImplementedInterfaces(implementsList, thisClass);
      implements = (IInterfaceDescriptor[])implementsList.ToArray(typeof(IInterfaceDescriptor));
      
      ArrayList collectionsList = new ArrayList();
      ArrayList fieldsList = new ArrayList();
      Hashtable descriptorByName = new Hashtable();
      int membersCount = 0;
      try {
        membersCount = thisClass.Members.Count;
      } catch {}
      for (int i = 0; i < membersCount; i++) {
        CodeElement element = thisClass.Members.Item(i + 1);
        if (element.Kind==vsCMElement.vsCMElementProperty) {
          CodeProperty codeProperty = (CodeProperty)element;
          if (codeProperty.Access==vsCMAccess.vsCMAccessPublic) {
            CodeType propertyType = null;
            if (codeProperty.Type.TypeKind==vsCMTypeRef.vsCMTypeRefCodeType)
              propertyType = codeProperty.Type.CodeType;
            if (propertyType!=null && DesigntimeCodeManager.IsTypeOrDescendantOf((CodeElement)propertyType, "DataObjects.NET.DataObjectCollection")) {
              if (!descriptorByName.ContainsKey(codeProperty.Name)) {
                ICollectionDescriptor collectionDescr = new CollectionDescriptor(this, codeProperty);
                collectionsList.Add(collectionDescr);
                descriptorByName[codeProperty.Name] = collectionDescr;
              }
            } else if (propertyType!=null && DesigntimeCodeManager.IsTypeOrDescendantOf((CodeElement)propertyType, "DataObjects.NET.ValueTypeCollection")) {
              if (!descriptorByName.ContainsKey(codeProperty.Name)) {
                IValueTypeCollectionDescriptor vtColDescr = new ValueTypeCollectionDescriptor(this, codeProperty);
                collectionsList.Add(vtColDescr);
                descriptorByName[codeProperty.Name] = vtColDescr;
              }
            } else {
              if (!descriptorByName.ContainsKey(codeProperty.Name)) {
                IFieldDescriptor fieldDescr = new FieldDescriptor(codeProperty.Name, this, propertyType, codeProperty.Attributes);
                fieldsList.Add(fieldDescr);
                descriptorByName[codeProperty.Name] = fieldDescr;
              }
            }
          }
        }
      }
      if (baseType!=null && (baseType as IClassDescriptor)!=null) {
        IClassDescriptor baseClass = (IClassDescriptor)baseType;
        foreach (IFieldDescriptor field in baseClass.Fields) {
          if (!descriptorByName.ContainsKey(field.Name)) {
            FieldDescriptor childField = (FieldDescriptor)((ICloneable)field).Clone();
            childField.SetParentFromContainer(this);
            fieldsList.Add(childField);
            descriptorByName[childField.Name] = childField;
          }
        }
        foreach (ICollectionDescriptor colDesc in baseClass.Collections) {
          if (!descriptorByName.ContainsKey(colDesc.Name)) {
            if (colDesc is ValueTypeCollectionDescriptor) {
              ValueTypeCollectionDescriptor vtcd = (ValueTypeCollectionDescriptor)colDesc;
              ValueTypeCollectionDescriptor vtcdClone = (ValueTypeCollectionDescriptor)((ICloneable)vtcd).Clone();
              vtcdClone.SetParentFromContainer(this);
              collectionsList.Add(vtcdClone);
              descriptorByName[vtcdClone.Name] = vtcdClone;
            } else if (colDesc is CollectionDescriptor) {
              CollectionDescriptor cd = (CollectionDescriptor)colDesc;
              CollectionDescriptor cdClone = (CollectionDescriptor)((ICloneable)cd).Clone();
              cdClone.SetParentFromContainer(this);
              collectionsList.Add(cdClone);
              descriptorByName[cdClone.Name] = cdClone;
            }
          }
        }
      }
      collections = (ICollectionDescriptor[])collectionsList.ToArray(typeof(ICollectionDescriptor));
      fields = (IFieldDescriptor[])fieldsList.ToArray(typeof(IFieldDescriptor));
      
      object[] derivedClasses = codeManager.GetDerivedClasses(thisClass.FullName);
      derivedObjects = new IClassDescriptor[derivedClasses.Length];
      for (int i = 0; i < derivedClasses.Length; i++)
        derivedObjects[i] = new ClassDescriptor(this, (CodeClass)derivedClasses[i], codeManager);
    }
    #endif
  }
}
