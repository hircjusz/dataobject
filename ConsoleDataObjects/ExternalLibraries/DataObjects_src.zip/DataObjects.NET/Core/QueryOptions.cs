// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Attributes;

namespace DataObjects.NET
{
  /// <summary>
  /// Enumeration of possible options for the <see cref="Query"/> or <see cref="SqlQuery"/>.
  /// </summary>
  /// <remarks>
  /// Note that some of the following options could be omitted\rejected by some
  /// DataObjects.NET database <see cref="Database.Driver">Driver</see>s.
  /// </remarks>
  [Flags]
  public enum QueryOptions
  {
    /// <summary>
    /// Default query options.
    /// Value is <see langword="0x0"/>. 
    /// </summary>
    Default = 0x0,
    /// <summary>
    /// Only count selected rows (instances).
    /// Value is <see langword="0x1"/>. 
    /// </summary>
    Count = 0x1,
    /// <summary>
    /// <para>
    /// Specifies that <see cref="QueryResult"/> should contain
    /// only distinct <see cref="DataObject"/>s.
    /// </para>
    /// <para>
    /// This option should be used when <see cref="Query"/> contains
    /// joins with <see cref="DataObjectCollection"/>s and only distinct
    /// objects are required.
    /// Value is <see langword="0x2"/>.
    /// </para>
    /// </summary>
    Distinct = 0x2,
    /// <summary>
    /// This option allows to skip locked rows (instances), so query wouldn't be blocked anyway.
    /// Value is <see langword="0x10"/>. 
    /// </summary>
    SkipLocked = 0x10,
    /// <summary>
    /// Query should be optimized to fetch first instance as fast as possible.
    /// Value is <see langword="0x20"/>. 
    /// </summary>
    FastFirst = 0x20,
    /// <summary>
    /// Query should be performed on Read Uncommitted isolation level.
    /// This option also affects locking mode.
    /// With DataObjects.NET you can't use this option -
    /// an exception will be thrown if you'll try to do this.
    /// Value is <see langword="0x100"/>. 
    /// </summary>
    OnReadUncommitted = 0x100,
    /// <summary>
    /// Query should be performed on Read Committed isolation level.
    /// This option also affects locking mode.
    /// Value is <see langword="0x200"/>. 
    /// </summary>
    OnReadCommitted = 0x200,
    /// <summary>
    /// Query should be performed on Repeatable Read isolation level.
    /// This option also affects locking mode.
    /// Value is <see langword="0x400"/>. 
    /// </summary>
    OnRepeatableRead = 0x400,
    /// <summary>
    /// Query should be performed on Serializable isolation level.
    /// This option also affects locking mode.
    /// Value is <see langword="0x800"/>. 
    /// </summary>
    OnSerializable = 0x800,
    /// <summary>
    /// Specifies that update locks instead of shared locks are taken 
    /// while reading the table, and that they are held until the end-of-statement 
    /// or end-of-transaction.
    /// Value is <see langword="0x1000"/>. 
    /// </summary>
    ForUpdate = 0x1000,
    /// <summary>
    /// Specifies that exclusive locks should be taken and held until 
    /// the end of transaction on all data processed by the statement.
    /// Value is <see langword="0x2000"/>. 
    /// </summary>
    ForExclusive = 0x2000,
    /// <summary>
    /// Specifies that a shared row lock is taken when a single shared page 
    /// or table lock is normally taken.
    /// Value is <see langword="0x10000"/>. 
    /// </summary>
    LockRows = 0x10000,
    /// <summary>
    /// Takes shared page locks where a single shared table lock is normally taken.
    /// Value is <see langword="0x20000"/>. 
    /// </summary>
    LockPages = 0x20000,
    /// <summary>
    /// Specifies that a shared lock is taken on the table held until the end-of-statement. 
    /// If <see cref="OnSerializable"/> is also specified, the shared table lock is 
    /// held until the end of the transaction.
    /// Value is <see langword="0x40000"/>. 
    /// </summary>
    LockTables = 0x40000,
    /// <summary>
    /// <para>
    /// Specifies that <see cref="QueryResult"/> should hold
    /// references to the <see cref="DataObject"/> instances to 
    /// prevent them from the garbage collection. 
    /// If this options isn't specified, <see cref="QueryResult"/> 
    /// will hold only <see cref="DataObject.ID"/>s of instances.
    /// </para>
    /// <para>
    /// Note that a reference to the persistent instance is created 
    /// on the first attempt to access it, but not on the result set 
    /// creation. This means that anyway persistent objects are 
    /// instantiated on the first access attempt - this feature doesn't 
    /// decrease the overall performance, but guaranties that only
    /// required instances will be held in memory.
    /// </para>
    /// <para>
    /// This option should be used when almost all 
    /// <see cref="DataObject"/>s contained in the <see cref="QueryResult"/>
    /// are planned to be processed more then once.
    /// Value is <see langword="0x100000"/>.
    /// </para>
    /// </summary>
    HoldInMemory = 0x100000,
    /// <summary>
    /// The same as <see cref="HoldInMemory"/>.
    /// Value is <see langword="0x100000"/>.
    /// </summary>
    HoldInstancesInMemory = 0x100000,
    /// <summary>
    /// <para>
    /// Specifies that <see cref="QueryResult"/> should contain
    /// only <see cref="DataObject.ID"/>s of instances rather
    /// then all other data required to give a reference to any 
    /// <see cref="DataObject"/> instance without any additional 
    /// queries to the database (i.e. to instantiate a real 
    /// <see cref="DataObject"/> instance). So it's possible that
    /// one additional query will be performed on each attempt
    /// to get an object from the <see cref="QueryResult"/> if
    /// this option is turned on.
    /// </para>
    /// <para>
    /// Note that instantiation with additional query is performed 
    /// only when it's necessary - e.g. when there is no
    /// cached instance with the required <see cref="DataObject.ID"/> and
    /// there is no cached instantiation data for object
    /// with the required <see cref="DataObject.ID"/>.
    /// </para>
    /// <para>
    /// This option should be used when only a small part of the
    /// <see cref="QueryResult"/> is planned to be processed.
    /// Value is <see langword="0x200000"/>.
    /// </para>
    /// </summary>
    LoadOnDemand = 0x200000,
  }

  public class PageInfo
  {
      int pageNum;
      int pageSize;
      public PageInfo(int pageNum, int pageSize)
      {
          this.pageNum = pageNum;
          this.pageSize = pageSize;
      }

      public PageInfo(int pageSize)
      {
          this.pageNum = 0;
          this.pageSize = pageSize;
      }


      public int PageNum
      {
          get
          {
              return pageNum;
          }
          set
          {
              pageNum = value;
          }
      }

      public int PageSize
      {
          get
          {
              return pageSize;
          }
          set
          {
              pageSize = value;
          }
      }


  }
}
