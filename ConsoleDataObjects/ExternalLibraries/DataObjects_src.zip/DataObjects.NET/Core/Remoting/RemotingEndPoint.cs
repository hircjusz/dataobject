// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Collections;
using System.Collections.Specialized;
using System.Runtime.Remoting;

namespace DataObjects.NET
{
  /// <summary>
  /// Allows to marshal a set of named objects via .NET Remoting.
  /// It eliminates the need to �ping� a remote application hosted in 
  /// IIS by HTTP request before accessing its <see cref="Domain"/> object 
  /// (to ensure that application is running now), plus simplifies remoting 
  /// configuration (e.g. now this can be done completely on application 
  /// configuration file level). See DoPetShop and DoPetShop Remoting Client 
  /// as example.
  /// </summary>
  /// <remarks>
  /// <para>
  /// The main feature of this class is that it stores name-object
  /// pairs in its static members and allows to manage them via static
  /// members, but provides access to contained objects via its instance
  /// members.
  /// </para>
  /// <para>
  /// Any two instances of this type work absolutely the same, since
  /// they use the same static name-value mapping table. So this
  /// type can be configured (in the remoting configuration section of
  /// your application) as well-known object operating in single-call
  /// or singleton mode. It will provide remote access to instances, 
  /// that can't be used neither in single-call nor in singleton
  /// mode (e.g. <see cref="Domain"/> instances).
  /// </para>
  /// <note type="note">
  /// All methods of this type are safe for multithreaded operations.
  /// </note>
  /// </remarks>
  public class RemotingEndPoint: MarshalByRefObject
  {
    private static Hashtable map = new Hashtable();

    /// <summary>
    /// Registers a new named object.
    /// <seealso cref="UnregisterObject"/>
    /// <seealso cref="GetObject"/>
    /// </summary>
    /// <param name="name">Object name. Format of the name is <c>[A-Za-z][A-Za-z0-9_\-]*</c>.</param>
    /// <param name="value">An object to register under the specified name.</param>
    public static void RegisterObject(string name, MarshalByRefObject value)
    {
      Regex rName = new Regex(@"^[A-Z][_0-9A-Z\-]*$", RegexOptions.IgnoreCase | RegexOptions.Multiline);
      if (!rName.IsMatch(name))
        throw new ArgumentException("Invalid object name.", "name");
      lock (map) {
        map[name] = value;
      }
    }

    /// <summary>
    /// Unregisters named object.
    /// <seealso cref="RegisterObject"/>
    /// <seealso cref="GetObject"/>
    /// </summary>
    /// <param name="name">Name of the object to unregister.</param>
    public static void UnregisterObject(string name)
    {
      lock (map) {
        map.Remove(name);
      }
    }
    
    /// <summary>
    /// Gets registered object by its name.
    /// <seealso cref="RegisterObject"/>
    /// <seealso cref="UnregisterObject"/>
    /// </summary>
    /// <param name="name">Name of the object to get.</param>
    /// <returns>Named object or <see langword="null"/>.</returns>
    public MarshalByRefObject GetObject(string name)
    {
      lock (map) {
        return (MarshalByRefObject)map[name];
      }
    }
    
    /// <summary>
    /// Gets registered object by its name (similar to <see cref="GetObject"/>).
    /// <seealso cref="RegisterObject"/>
    /// <seealso cref="UnregisterObject"/>
    /// <seealso cref="GetObject"/>
    /// </summary>
    /// <param name="name">Name of the object to get.</param>
    public MarshalByRefObject this[string name] {
      get {
        return GetObject(name);
      }
    }
    
    /// <summary>
    /// Gets registered remote object by its URL.
    /// <seealso cref="RegisterObject"/>
    /// <seealso cref="UnregisterObject"/>
    /// <seealso cref="GetObject"/>
    /// </summary>
    /// <param name="url">Remote object URL in the following form: 
    /// &lt;RemoteEndPointUrl&gt;/&lt;ObjectName&gt;.</param>
    /// <returns>Named remote object or <see langword="null"/>.</returns>
    public static MarshalByRefObject GetRemoteObject(string url)
    {
      int lastSlash = url.LastIndexOf("/");
      if (lastSlash<0)
        throw new ArgumentException("Invalid object Url.", "url");
      string endPointUrl = url.Substring(0,lastSlash);
      string objectName  = url.Substring(lastSlash+1);
      RemotingEndPoint remoteEndPoint = 
        (RemotingEndPoint)RemotingServices.Connect(typeof(RemotingEndPoint), endPointUrl);
      return remoteEndPoint.GetObject(objectName);
    }


    // Constructors
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    public RemotingEndPoint()
    {
    }
  }
}
