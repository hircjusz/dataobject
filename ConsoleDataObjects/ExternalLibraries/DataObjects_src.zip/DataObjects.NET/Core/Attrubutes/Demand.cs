// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Reflection;
using System.Collections;
using DataObjects.NET.Security;
using DataObjects.NET.Exceptions;

namespace DataObjects.NET.Attributes
{
  /// <summary>
  /// Provides declarative support for permission demands.
  /// </summary>
  /// <remarks>
  /// <para>
  /// <example>Example:
  /// <code lang="C#">
  ///    public abstract class Book: DataObject
  ///    {
  ///      [Demand(typeof(BookReadPermission),   AccessorType = AccessorType.Get)]
  ///      [Demand(typeof(BookModifyPermission), AccessorType = AccessorType.Set)]
  ///      public abstract string Title { get; set; }
  ///      
  ///      [Demand(typeof(AdministrationPermission))] // AccessorType.All is used (by default)
  ///      public abstract Author Author { get; set; }
  ///    ...
  ///    }  
  /// </code>
  /// </example>
  /// </para>
  /// </remarks>
  [AttributeUsage(AttributeTargets.Property | AttributeTargets.Method, AllowMultiple = true, Inherited = false)]
  [Serializable]
  public class DemandAttribute: DataObjectAttribute
  {
    private Type[]       permissionTypes = new Type[0];
    private AccessorType accessorType    = Attributes.AccessorType.All;
    
    /// <summary>
    /// Gets or sets the <see cref="Type"/> of the permission. 
    /// This <see cref="Type"/> can be only <see cref="DataObjects.NET.Security.Permission"/> descendant. 
    /// Tries to assign types other than <see cref="DataObjects.NET.Security.Permission"/> descendant
    /// will be ignored.
    /// </summary>
    public Type[] PermissionTypes 
    {
      get { return permissionTypes; }
      set { 
        permissionTypes = value;
      }
    }

    /// <summary>
    /// Gets or sets the type of property accessors the <see cref="DataObjects.NET.Security.Permission"/> should be applied to.
    /// </summary>
    public AccessorType AccessorType {
      get { return accessorType; }
      set { accessorType = value; }  
    }
    
    /// <summary>
    /// Gets or sets the <see cref="DataObjects.NET.Security.Permission"/> for this attribute. 
    /// Permissions can be only <see cref="DataObjects.NET.Security.Permission"/> descendant.
    /// Tries to assign objects other than <see cref="DataObjects.NET.Security.Permission"/> descendant
    /// will be ignored.
    /// </summary>
    public PermissionSet Permissions 
    {
      get {
        ValidatePermissionTypes();
        PermissionSet result = new PermissionSet();
        foreach (Type t in permissionTypes) {
          PropertyInfo pi = t.GetProperty("Value", BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic);
          if (pi!=null)
            result.Union(pi.GetValue(null,null) as IPermission);
          else
            result.Union(Activator.CreateInstance(t) as IPermission);
        }  
        return result;
      }
      set {
        permissionTypes = new Type[value.Count];
        int i = 0;
        foreach (Type permissionType in value)
          permissionTypes[i++] = permissionType;
        ValidatePermissionTypes();
      }  
    }
    
    private void ValidatePermissionTypes()
    {
      foreach (Type permissionType in permissionTypes) {
        if (!typeof(IPermission).IsAssignableFrom(permissionType))
          throw new InvalidOperationException(
            "At least one type in PermissionTypes array is invalid "+
              "(is not a type of IPermission descendant).");
      }
    }
    
    
    // Constructors

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="permissionType"><see cref="Type"/> of the permission to demand.</param>
    public DemandAttribute(Type permissionType)
    {
      PermissionTypes = new Type[1] {permissionType};
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="permissionType1"><see cref="Type"/> of the first permission to demand.</param>
    /// <param name="permissionType2"><see cref="Type"/> of the second permission to demand.</param>
    public DemandAttribute(Type permissionType1, Type permissionType2)
    {
      PermissionTypes = new Type[2] {permissionType1, permissionType2};
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="permissionType1"><see cref="Type"/> of the first permission to demand.</param>
    /// <param name="permissionType2"><see cref="Type"/> of the second permission to demand.</param>
    /// <param name="permissionType3"><see cref="Type"/> of the third permission to demand.</param>
    public DemandAttribute(Type permissionType1, Type permissionType2,
      Type permissionType3)
    {
      PermissionTypes = new Type[3] {permissionType1, permissionType2, permissionType3};
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="permissionType1"><see cref="Type"/> of the first permission to demand.</param>
    /// <param name="permissionType2"><see cref="Type"/> of the second permission to demand.</param>
    /// <param name="permissionType3"><see cref="Type"/> of the third permission to demand.</param>
    /// <param name="permissionType4"><see cref="Type"/> of the fourth permission to demand.</param>
    public DemandAttribute(Type permissionType1, Type permissionType2,
      Type permissionType3, Type permissionType4)
    {
      PermissionTypes = new Type[4] {permissionType1, permissionType2, 
        permissionType3, permissionType4};
    }
  }
}