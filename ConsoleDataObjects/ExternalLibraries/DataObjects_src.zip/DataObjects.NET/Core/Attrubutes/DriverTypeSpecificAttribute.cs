// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Text.RegularExpressions;
using DataObjects.NET.Exceptions;
using DataObjects.NET.FullText;
using DataObjects.NET.Internals;

namespace DataObjects.NET.Attributes
{
  /// <summary>
  /// This attribute can't be applied directly (so only it's descendants
  /// can be used), but it allows to specify a set of database driver
  /// <see cref="DataObjects.NET.Database.Info.Type"/>s
  /// for which current attribute is relevant.
  /// </summary>
  /// <remarks>
  /// <para>
  /// <example>Example (part of <see cref="FtRecord"/>'s code):
  /// <code lang="C#">
  ///  [Sealed]
  ///  public abstract class FtRecord : DataObject
  ///  {
  ///    ...
  ///    
  ///    [Translatable]
  ///    [SqlType(SqlType.Text)] // Default declaration of SqlType
  ///    [SqlType(SqlType.AnsiText, DriverTypes="Oracle, NativeOracle")] // Oracle-specific declaration
  ///    [SqlType(SqlType.VarChar,  DriverTypes="SAPDB")] // SAP DB - specific declaration
  ///    [Length(1000,              DriverTypes="SAPDB")] // SAP DB - specific declaration
  ///    [LoadOnDemand]
  ///    [NotSerializable]
  ///    [Indexed(FullText=true)]
  ///    public string FtData {get;}
  ///    
  ///    ...
  ///  }
  /// </code>
  /// </example>
  /// </para>
  /// </remarks>
  [Serializable]
  public class DriverTypeSpecificAttribute: DataObjectAttribute
  {
    private static Regex reDriverType = 
      new Regex(@"^(\w+)(?:[ \t]+((?:(?:\d+|\*)\.){1,3}(?:\d+|\*)(?:-(?:(?:\d+|\*)\.){1,3}(?:\d+|\*))?))?$", RegexOptions.Compiled);

    private string driverTypes;
    /// <summary>
    /// The <see cref="DataObjects.NET.Database.Info.Type"/> 
    /// of the driver for which this attribute is relevant.
    /// </summary>
    /// <remarks>
    /// <note type="note">
    /// Use ',' to define a set of acceptable \ unacceptable driver types.
    /// "!" in the beginning of the <see cref="DriverTypes"/>
    /// means that any driver except specified is valid. 
    /// <see langword="Null"/> or <see cref="String.Empty"/> mean that
    /// any driver is relevant. 
    /// </note>
    /// <para>
    /// Example expressions:
    /// <list type="table">
    ///  <listheader>
    ///    <term>DriverTypes value</term>
    ///    <description>Description</description>
    ///  </listheader>
    ///  <item>
    ///    <term>"MSSQL"</term>
    ///    <description>"MSSQL" is valid driver type.</description>
    ///  </item>
    ///  <item>
    ///    <term>"MSSQL,Oracle"</term>
    ///    <description>Both "MSSQL" and "Oracle" are valid driver types.</description>
    ///  </item>
    ///  <item>
    ///    <term>"!MSSQL,Oracle"</term>
    ///    <description>Any driver type except "MSSQL" and "Oracle" is valid.</description>
    ///  </item>
    ///  <item>
    ///    <term>""</term>
    ///    <description>Any driver type is valid.</description>
    ///  </item>
    /// </list>
    /// </para>
    /// </remarks>
    public  string DriverTypes
    {
      get {return driverTypes;}
      set {driverTypes = value;}
    }

    internal bool IsApplicableTo (string curDriverType, Version version)
    {
      if (DriverTypes==null || DriverTypes=="")
        return true;
      else {
        bool bInvert = driverTypes[0]=='!';
        string[] allDriverTypes = driverTypes.Substring(bInvert?1:0).Split(',',';','|');
        bool bFound = false;
        foreach (string driverType in allDriverTypes) {
          Match match = reDriverType.Match(driverType.Trim());
          if (match.Success) {
            if (match.Groups[1].Value.Trim()==curDriverType) {
              if (!match.Groups[2].Success)
                bFound = true;
              else {
                VersionRange range = VersionRange.Parse(match.Groups[2].Value);
                bFound = range.Contains(version);
              }
              if (bFound)
                break;
            }
          }
          else 
            throw new ObjectModelBuilderException("Invalid driver type format." +
              "Use \"driverName\", \"driverName n.n[.n[.n]]\" or \"driverName n.n[.n[.n]]-n.n[.n[.n]]\" pattern instead. " +
              "Where 'n' is an integer from 0 to 65535 or the '*' character.");
        }
        return bFound ^ bInvert;
      }
    }
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    public DriverTypeSpecificAttribute() 
    {
    }
  }
}
