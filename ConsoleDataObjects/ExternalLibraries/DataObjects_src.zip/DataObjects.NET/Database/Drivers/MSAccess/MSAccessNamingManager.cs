// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Attributes;

namespace DataObjects.NET.Database.Drivers.MSAccess
{
  /// <summary>
  /// Microsoft Access implementation of <see cref="NamingManager"/>.
  /// </summary>
  public class MSAccessNamingManager: NamingManager
  {
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="driver">Database driver.</param>
    public MSAccessNamingManager(Driver driver): base(driver)
    {
    }
  }
}
