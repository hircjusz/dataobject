// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using DataObjects.NET;

namespace DataObjects.NET.Versionizing
{
  /// <summary>
  /// Provides information about <see cref="DataObject"/> version
  /// in the <see cref="DomainDatabaseOptions.EnableVersionizing">versionizing</see> mode.
  /// </summary>
  public class VersionInfo: SessionBoundObject
  {
    private long ctid;
    private long rtid;
    
    /// <summary>
    /// Gets ID of a transaction that created current
    /// <see cref="DataObject"/> version.
    /// </summary>
    public long CreatedInTransactionID {
      get {
        return ctid;
      }
    }
    
    /// <summary>
    /// Gets ID of a transaction that removed current
    /// <see cref="DataObject"/> version.
    /// Returns <see langword="0"/> if current <see cref="DataObject"/> 
    /// version was not removed yet.
    /// </summary>
    public long RemovedInTransactionID {
      get {
        return rtid;
      }
    }
    
    /// <summary>
    /// Gets transaction that created current
    /// <see cref="DataObject"/> version.
    /// </summary>
    public TransactionInfo CreatedInTransaction {
      get {
        return (TransactionInfo)Session[ctid];
      }
    }
    
    /// <summary>
    /// Gets transaction that removed current
    /// <see cref="DataObject"/> version.
    /// Returns <see langword="Null"/> if current <see cref="DataObject"/> 
    /// version was not removed yet.
    /// </summary>
    public TransactionInfo RemovedInTransaction {
      get {
        if (rtid==0)
          return null;
        return (TransactionInfo)Session[rtid];
      }
    }

    
    // Constructors
    
    /// <summary>
    /// Initializes a new instance of the <see cref="VersionInfo"/> struct.
    /// </summary>
    /// <param name="session">session.</param>
    /// <param name="ctid">ID of transaction that created current generation.</param>
    /// <param name="rtid">ID of transaction that created removed generation.</param>
    internal VersionInfo(Session session, long ctid, long rtid): base(session)
    {
      this.ctid = ctid;
      this.rtid = rtid;
    }
  }
}
