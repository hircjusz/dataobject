// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;

namespace DataObjects.NET.Remoting.ArgumentContainers
{
  /// <summary>
  /// Describes a <see cref="Domain"/>-type argument pointing to the <see cref="Domain"/> 
  /// of the current invocation context.
  /// </summary>
  [Serializable]
  public class ContextDomainArgumentContainer : ArgumentContainer
  {
    /// <summary>
    /// Creates a new object that is a copy of a curent instance.
    /// </summary>
    public override object Clone()
    {
      return new ContextDomainArgumentContainer();
    }

    /// <summary>
    /// Gets parameter value.
    /// </summary>
    public override object GetValue(CallContext context)
    {
      return context.Domain;
    }

    /// <summary>
    /// Sets parameter value.
    /// </summary>
    /// <param name="value"></param>
    protected internal override void SetValue(object value)
    {
      // Does nothing
    }

    // Constructors

    internal ContextDomainArgumentContainer()
    {
    }
  }
}
