// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.IO;
using System.Threading;
using System.Configuration;
using System.Diagnostics;
using System.Globalization;
using System.Collections;
using DataObjects.NET;
using DataObjects.NET.Attributes;
using DataObjects.NET.Exceptions;

namespace DataObjects.NET.Security
{
  /// <summary>
  /// An interface that should be implemented by any parameterized 
  /// security permission.
  /// Note that any parameterized permission instance should be
  /// immutable (i.e. it should be impossible to change it after
  /// the creation).
  /// <seealso cref="IPermission"/>
  /// </summary>
  public interface IParameterizedPermission: IPermission
  {
    /// <summary>
    /// Determines whether the current permission is an "empty" permission 
    /// in this permission type.
    /// </summary>
    /// <returns><see langword="True"/> if the current permission is an "empty" permission; otherwise, <see langword="false"/>.</returns>
    bool IsEmpty {get;}

    /// <summary>
    /// Determines whether the current permission is a maximal permission 
    /// in this permission type.
    /// </summary>
    /// <returns><see langword="True"/> if the current permission is a meximal permission; otherwise, <see langword="false"/>.</returns>
    bool IsMaximal {get;}

    /// <summary>
    /// Creates and returns a permission of the same type, but with the maximal
    /// set of allowed actions.
    /// </summary>
    /// <returns>A copy of the current permission.</returns>
    IParameterizedPermission Maximize();

    /// <summary>
    /// Creates a permission that is the union of the current permission and the specified permission.
    /// </summary>
    /// <param name="target">A permission to combine with the current permission. 
    /// It must be of the same type as the current permission.</param>
    /// <returns>A new permission that represents the union of the current permission and the specified permission.</returns>
    IParameterizedPermission Union(IParameterizedPermission target);
    
    /// <summary>
    /// Creates a permission that is the subtraction of the current permission and the specified permission.
    /// </summary>
    /// <param name="target">A permission to subtract from the current permission. 
    /// It must be of the same type as the current permission.</param>
    /// <returns>A new permission that represents the subtraction of the current permission and the specified permission.</returns>
    /// <remarks>
    /// This method should return <see langword="null"/> if resulting permission
    /// is "empty".
    /// </remarks>
    IParameterizedPermission Subtract(IParameterizedPermission target);

    /// <summary>
    /// Determines whether the current permission is a subset of the specified permission.
    /// </summary>
    /// <param name="target">A permission that is to be tested for the subset relationship.
    /// It must be of the same type as the current permission.</param>
    /// <returns><see langword="True"/> if the current permission is a subset of the specified permission; otherwise, <see langword="false"/>.</returns>
    bool IsSubsetOf(IParameterizedPermission target);
  }
}
