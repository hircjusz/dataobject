// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.IO;
using System.Text;
using System.Collections;
using System.Collections.Specialized;
using System.Threading;
using System.Data;
using System.Reflection;
using System.Diagnostics;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization.Formatters.Soap;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Messaging;
using System.EnterpriseServices;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Attributes;
using DataObjects.NET.Database;
using DataObjects.NET.Offline.Internals;
using DataObjects.NET.Remoting;
using DataObjects.NET.Offline;
using DataObjects.NET.Serialization;
using DataObjects.NET.ObjectModel;
using DataObjects.NET.DatabaseModel;
using DataObjects.NET.Security;
using DataObjects.NET.Security.Permissions;
using DataObjects.NET.Caching;
using DataObjects.NET.Versionizing;

#if MONO
  using System.Data.SqlClient;
#endif

namespace DataObjects.NET
{
  /// <summary>
  /// Session is analogue of <see cref="IDbConnection"/> in DataObjects.NET.
  /// </summary>
  /// <remarks>
  /// <para>Each <see cref="DataObjects.NET.Session"/> instance is associated with
  /// single <see cref="IDbConnection"/>. It uses this connection
  /// to access the database.</para>
  /// <para><see cref="DataObjects.NET.Session"/> instances aren't
  /// safe for the multithreaded operations. To work with the database
  /// using multiple threads you should use separate <see cref="DataObjects.NET.Session"/> 
  /// instance in each thread.</para>
  /// <para>Each <see cref="DataObjects.NET.Session"/> maintains its own cache
  /// of fetched <see cref="DataObject"/> instances.</para>
  /// <para>Note that you can access the database (work with the instances of <see cref="DataObject"/>)
  /// only during a <see cref="Transaction"/>.</para>
  /// <example>Example:
  /// <code lang="C#">
  ///  d = new Domain("mssql://localhost/DataObjectsDotNetDemos", myProductKey);
  ///  d.RegisterCulture(new Culture("En",  "U.S. English", new CultureInfo("en-us", false)));
  ///  d.Cultures["En"].Default = true;
  ///  d.RegisterTypes("MyApp.PersistentModel");
  ///  d.RegisterServices("MyApp.PersistentModel");
  ///  d.Build(DomainUpdateMode.Perform);
  ///  using (Session s = d.CreateSession()) {
  ///    s.BeginTransaction();
  ///      
  ///    Author a  = (Author)s.CreateObject(typeof(Author));
  ///    a.Name    = "John";
  ///    a.Surname = "Smith";
  ///      
  ///    s.Commit();
  ///  }
  /// </code>
  /// </example>
  /// <seealso cref="DataObjects.NET.Domain.CreateSession"/>
  /// <seealso cref="Transaction"/>
  /// <seealso cref="BeginTransaction"/>
  /// <seealso cref="Commit"/>
  /// <seealso cref="Rollback"/>
  /// <seealso cref="DefaultIsolationLevel"/>
  /// <seealso cref="EnlistDistributedTransaction"/>
  /// <seealso cref="Savepoint"/>
  /// <seealso cref="Options"/>
  /// <seealso cref="SecurityOptions"/>
  /// <seealso cref="Principal"/>
  /// <seealso cref="Permission"/>
  /// <seealso cref="PermissionSet"/>
  /// </remarks>
  #if (!NoMBR)
  public sealed class Session: MarshalByRefObject, 
  #else
  public sealed class Session: Object, 
  #endif
    ISecureObject, IDisposable,
    IMethodCallTarget,
    IConvertibleToOffline
  {
    // Constants
    // const int InstanceCacheOptimizationLowerLimit = 16384;
    const int MemoryStreamLengthLowerLimit        = 8192;
    // Core properties
    private  string                name;
    internal readonly Domain       domain;
    internal SessionSecurityOptions securityOptions;
    private  SessionOptions        options;
    internal IsolationLevel        defaultIsolationLevel = IsolationLevel.RepeatableRead;
    private  bool                  isRemote;
    internal int                   reprocessingAttemptsCount = 10;
    internal int                   reprocessingDelay = 200;
    internal int                   inconsistentDataUpdateProbability = 50;
    internal int                   commandTimeout = 30;
    // Access options
    internal Culture               culture;
//    internal bool                  useFastLoadData = true;
    internal bool                  delayUpdates    = true;
    // Security-related objects
    internal User                  user;
    internal Hashtable             disableSecurityThreads = new Hashtable();
    internal bool                  allowModifyTransactionInfo;
    // Connection, Transactions, Savepoints support
    private  IDbConnection         realConnection;
    internal TransactionContext    transactionContext;
    internal Transaction           outermostTransaction;
    internal Transaction           transaction;
    internal int                   savepointNumber = 0;
    private  Hashtable             sharedServices = new Hashtable();
    // Instance cache support
    private  SessionCache          cache;
    internal Hashtable             updatedInstances = new Hashtable();
    internal Hashtable             removingInstances = new Hashtable();
    private  Hashtable             nullObjects = new Hashtable();
    private Hashtable              customProperties = new Hashtable();
    internal int persistDepth = 0;
    
    // To speedup access
    internal readonly Assembly     doAssembly;
    internal readonly Assembly     proxyAssembly;
    internal readonly Assembly     sysAssembly;
    internal readonly Assembly     remotingAssembly;
    internal readonly Assembly     soapAssembly;
    internal readonly TypeCollection types;
    internal readonly ServiceCollection services;
    internal readonly Driver       driver;
    internal readonly Info         driverInfo;
    internal readonly Utils        utils;
    internal readonly Persister    persister;
    internal readonly SqlQuery     sqlQuery;
    internal readonly string       sqlQuotedID;
    internal readonly string       sqlQuotedTypeID;
    internal readonly string       sqlQuotedVersionID;
    internal readonly MemoryStream memoryStream;
    internal readonly IFormatter   fastLoadDataFormatter;
    internal readonly ObjectModel.Type dataObjectType;
    internal readonly Table        dataObjectTable;
    internal readonly Column       dataObjectIDColumn;
    internal readonly Column       dataObjectTypeIDColumn;
    internal readonly Column       dataObjectVersionIDColumn;
    internal Random                random;
    internal long                  counter;
    // private  static readonly System.Type[] cdoConstructorTypes = new System.Type[0];
    // private  static readonly object[]      cdoConstructorArgs  = new object[0];


    // Core methods
    
    /// <summary>
    /// Gets or sets session name.
    /// </summary>
    /// <remarks>This property is write-once.</remarks>
    public string Name {
      get {
        return name;
      }
      set {
        if (name!=null)
          throw new InvalidOperationException("A set operation was requested, and the Name property has already been set.");
        name = value;
      }
    }

    /// <summary>
    /// Gets the <see cref="DataObjects.NET.Domain"/> to which this <see cref="Session"/> belongs.
    /// </summary>
    public  Domain Domain {
      get {return domain;}
    }
    
    /// <summary>
    /// Indicates whether this session is a remote (created via .NET Remoting) or not.
    /// </summary>
    public bool IsRemote {
      get {
        return isRemote;
      }
    }
    
    /// <summary>
    /// Gets or sets session security options.
    /// <seealso cref="DataObjects.NET.Domain.SessionSecurityOptions"/>
    /// <seealso cref="SessionBoundObject.DisableSecurity"/>
    /// <seealso cref="SessionBoundObject.EnableSecurity"/>
    /// <seealso cref="DataObjects.NET.Security"/>
    /// <seealso cref="DataObjects.NET.Security.Permissions"/>
    /// </summary>
    public  SessionSecurityOptions SecurityOptions {
      get {
        return securityOptions;
      }
      set {
        if (transaction!=null)
          throw new InvalidOperationException("Property can't be changed during transaction.");
        if (disableSecurityThreads[Thread.CurrentThread]==null)
          if (((uint)value & (0xFFFFFFFF ^ (uint)securityOptions))>0)
            throw new SecurityException("SecurityOptions can't be increased.");
        securityOptions = value;
        EnforceSecurityOptions();
      }
    }
    internal void EnforceSecurityOptions()
    {
//      if ((securityOptions & SessionSecurityOptions.AllowUseFastLoadDataOff)==0)
//        UseFastLoadData = true;
    }

      public Hashtable CustomProperties
      {
          get
          {
              return this.customProperties;
          }
      }

    /// <summary>
    /// Gets or sets the <see cref="DataObjects.NET.Culture"/> of the session.
    /// </summary>
    public  Culture Culture 
    {
      get {
        return culture;
      }
      set {
        if (!domain.Cultures.Contains(value))
          throw new InvalidOperationException("Culture should be registered in the domain.");
        culture = value;
      }
    }

    /// <summary>
    /// Gets or sets session operation options.
    /// </summary>
    public SessionOptions Options
    {
      get {
        return options;
      }
      set {
        if (value==options)
          return;
        if (transaction!=null)
          throw new InvalidOperationException("Options can't be changed while transaction is running.");
        if ((value & SessionOptions.OfflineMode)!=0)
          if ((securityOptions & SessionSecurityOptions.AllowOfflineMode)==0)
            throw new SecurityException("Use of OfflineMode isn't allowed.");
        if ((value & SessionOptions.DisableAutoDisconnect)!=
            (options & SessionOptions.DisableAutoDisconnect))
          if (disableSecurityThreads[Thread.CurrentThread]==null)
            if ((securityOptions & SessionSecurityOptions.AllowChangeAutoDisconnect)==0)
              throw new SecurityException("DisableAutoDisconnect change isn't allowed.");
        options = value;
      }
    }
    
    /// <summary>
    /// Gets a value indicating that <see cref="Session"/>
    /// is in online operation mode (<see cref="Options"/> does not have 
    /// <see cref="SessionOptions.OfflineMode"/> flag set).
    /// <seealso cref="SessionOptions.OfflineMode"/>.
    /// <seealso cref="SessionOptions.OnlineMode"/>.
    /// <seealso cref="Session.Options"/>.
    /// </summary>
    public bool IsOnlineMode
    {
      get { return ((Options & SessionOptions.OfflineMode) == 0); }
    }


    public static long GetBaseFlatID(DataObjects.NET.ObjectModel.Type otype)
    {
        if (Domain.StyleID == IDStyle.Minimal)
            return (((long)otype.ID) << 1) + 1;
        else
            return ((long)otype.ID) << 48;
    }

    public static int GetTypeIDFromFlatID(long ID)
    {
        if (Domain.StyleID == IDStyle.Minimal)
        {
            long res = ID & (((long)0x7FE));
            return (int)(res >> 1);
        }
        else
        {
            long res = ID & (((long)0xFFFF) << 48);
            return (int)(res >> 48);
        }
    }

    public static bool IsFlat(long ID)
    {
        if (Domain.StyleID == IDStyle.Minimal)
        {
            return (ID & ((long)0x01)) == 1;
        }
        else
            return GetTypeIDFromFlatID(ID) > 0;
    }

    public DataObjects.NET.ObjectModel.Type GetTypeFromFlatID(long ID)
    {
        if (Session.IsFlat(ID))
            return this.Types.FindByID(GetTypeIDFromFlatID(ID));
        else
            return null;
    }

    /// <summary>
    /// Gets a value indicating that <see cref="Session"/>
    /// is in offline operation mode (<see cref="Options"/> has 
    /// <see cref="SessionOptions.OfflineMode"/> flag set).
    /// <seealso cref="SessionOptions.OfflineMode"/>.
    /// <seealso cref="SessionOptions.OnlineMode"/>.
    /// <seealso cref="Session.Options"/>.
    /// </summary>
    public bool IsOfflineMode
    {
      get { return ((Options & SessionOptions.OfflineMode) != 0); }
    }
  
    internal readonly SystemObjects systemObjects;
    /// <summary>
    /// Gets the <see cref="DataObjects.NET.SystemObjects"/> object.
    /// It provides set of properties allowing to simplify access to the
    /// system objects in the <see cref="Session"/>.
    /// <seealso cref="DataObjects.NET.Domain.SystemObjectNames"/>
    /// <seealso cref="DataObjects.NET.Domain.InitializeSystemObjects"/>
    /// </summary>
    public  SystemObjects SystemObjects {
      get {
        return systemObjects;
      }
    }
    
    /// <summary>
    /// Gets or sets <see cref="Session"/>'s current <see cref="DataObjects.NET.Security.User"/>.
    /// The value of this property affects on all permission checks
    /// (see <see cref="Demand"/>, <see cref="IsAllowed"/> methods).
    /// <seealso cref="Authenticate"/>
    /// <seealso cref="DataObjects.NET.Domain.OnUserChange"/>
    /// <seealso cref="DataObjects.NET.Domain.OnUserChanged"/>
    /// <seealso cref="SessionBoundObject.DisableSecurity"/>
    /// <seealso cref="SessionBoundObject.EnableSecurity"/>
    /// <seealso cref="DataObjects.NET.Security"/>
    /// <seealso cref="DataObjects.NET.Security.Permissions"/>
    /// </summary>
    /// <remarks>
    /// <para>
    /// The value of this property can be <see langword="null"/> - this means
    /// that there is no active user. All permission checks will
    /// complete successfully in this case.
    /// </para>
    /// <para>
    /// Only the <see cref="DataObject"/> and <see cref="DataService"/>
    /// descendants can change the value of this property. Setting its value
    /// directly (without the <see cref="Authenticate">authentication</see>)
    /// is called "impersonation". All other callers should
    /// use the <see cref="Authenticate"/> method to change the current 
    /// <see cref="User"/>.
    /// </para>
    /// <para>
    /// Normally impersonation should be used by persistent types or 
    /// <see cref="DataService"/>s when it's necessary to perform some
    /// action that isn't normally permitted for the current <see cref="User"/>
    /// (the other way of doing the same is to use 
    /// <see cref="SessionBoundObject.DisableSecurity"/>\<see cref="SessionBoundObject.EnableSecurity"/>
    /// blocks).
    /// </para>
    /// <note type="note">Use <see langword="try-catch"/> blocks in all cases
    /// when temporary impersonation (e.g. to the 
    /// <see cref="DataObjects.NET.SystemObjects.SystemUser"/>)
    /// is required - read the current <see cref="User"/> value before
    /// <see langword="try"/>, and restore it back in the <see langword="finally"/>
    /// block.
    /// </note>
    /// <para>
    /// The following events can be raised in the <see cref="Domain"/> on attempt
    /// to change this property:
    /// <see cref="DataObjects.NET.Domain.OnUserChange">Domain.OnUserChange</see>,
    /// <see cref="DataObjects.NET.Domain.OnUserChanged">Domain.OnUserChanged</see>.
    /// </para>
    /// </remarks>
    public  User User {
      get {
        return user;
      }
      set {
        CheckCaller();
        SwitchUser(value);
      }
    }
    
    /// <summary>
    /// Determines whether the security system is enabled in this
    /// <see cref="Session"/>.
    /// <seealso cref="SessionBoundObject.DisableSecurity"/>
    /// <seealso cref="SessionBoundObject.EnableSecurity"/>
    /// <seealso cref="DataObjects.NET.Security"/>
    /// <seealso cref="DataObjects.NET.Security.Permissions"/>
    /// </summary>
    /// <remarks>
    /// <para>
    /// Security system is disabled when either <see cref="User"/>==<see langword="null"/>,
    /// or <see cref="SessionBoundObject.DisableSecurity"/> was called
    /// more times, then <see cref="SessionBoundObject.EnableSecurity"/>.
    /// </para>
    /// <para>
    /// As you may understood, all permission <see cref="DataObject.Demand"/>s 
    /// in the scope of this <see cref="Session"/>
    /// (and <see cref="DataObject.IsAllowed"/> checks) are successful when 
    /// the security system is disabled.
    /// </para>
    /// </remarks>
    public bool IsSecurityEnabled {
      get {
        return disableSecurityThreads[Thread.CurrentThread]==null && user!=null;
      }
    }
    
    /// <summary>
    /// Shortcut to <see cref="TypeCollection">Domain.ObjectModel.Types</see>.
    /// </summary>
    public  TypeCollection Types {
      get {return types;}
    }

    /// <summary>
    /// Shortcut to <see cref="ServiceCollection">Domain.ObjectModel.Services</see>.
    /// </summary>
    public  ServiceCollection Services {
      get {return services;}
    }

    /// <summary>
    /// Shortcut to <see cref="DataObjects.NET.Database.Info">Domain.Driver.Info</see>.
    /// </summary>
    public  Info DriverInfo {
      get {return driverInfo;}
    }

    /// <summary>
    /// Shortcut to <see cref="DataObjects.NET.Database.Utils">Domain.Driver.Utils</see>.
    /// </summary>
    public  Utils Utils {
      get {return utils;}
    }

    internal bool IsTypeTransactional (System.Type type) 
    {
      return (types[type] != null || services[type] != null);
    }

//    /// <summary>
//    /// Enables or disables FastLoadData usage.
//    /// <seealso cref="SecurityOptions"/>
//    /// <seealso cref="SessionSecurityOptions"/>
//    /// </summary>
//    public bool UseFastLoadData {
//      get {
//        return useFastLoadData;
//      }
//      set {
//        if (transaction!=null)
//          throw new InvalidOperationException("Property can't be changed during transaction.");
//        if (disableSecurityThreads[Thread.CurrentThread]==null)
//          if (value==false && (securityOptions & SessionSecurityOptions.AllowUseFastLoadDataOff)==0)
//            throw new SecurityException("UseFastLoadData can't be turned off.");
//        useFastLoadData = value;
//      }
//    }

    /// <summary>
    /// Gets or sets the wait time before terminating the attempt to execute an any command and generating an error.
    /// <seealso cref="IDbCommand.CommandTimeout"/>
    /// </summary>
    public int CommandTimeout {
      get {
        return commandTimeout;
      }
      set {
        if (disableSecurityThreads[Thread.CurrentThread]==null)
          if ((securityOptions & SessionSecurityOptions.AllowChangeCommandTimeout)==0)
            throw new SecurityException("CommandTimeout change isn't allowed.");
        if (value < 0)
          throw new ArgumentOutOfRangeException("CommandTimeout", "Value of CommandTimeout should be greater or equal to zero.");
        commandTimeout = value;
        persister.SetCommandTimeout(value);
      }
    }

    /// <summary>
    /// Gets <see cref="Session"/>-level cache object.
    /// </summary>
    public SessionCache Cache {
      get {return cache;}
    }

    /// <summary>
    /// This method actually does nothing and is used 
    /// to check the remote <see cref="Session"/> existance
    /// as well as to prolong its .NET Remoting lease.
    /// </summary>
    public void Ping()
    {
    }

    // Connection support
    
    /// <summary>
    /// Opens underlying database connection.
    /// </summary>
    public void OpenConnection()
    {
      #if MONO
        if (realConnection!=null && (realConnection is SqlConnection)) {
          try {
            realConnection.Dispose();
          }
          finally {
            realConnection = null;
          }
        }
      #endif
      IDbConnection rc = InternalRealConnection;
      rc.Open();
      if (!IsConnectionOpened)
        throw new DatabaseDriverException("Can't open connection.");
      driver.ConfigureConnection(rc);
    }
    
    
//SM begin
      public void ClearCache()
      {
          Cache.Clear();
      }
//SM end

    /// <summary>
    /// Closes underlying database connection.
    /// </summary>
    public void CloseConnection()
    {
//SM begin
        ConnectionCleaner.getInstance().unregister(this);
//SM end

      if (outermostTransaction!=null)
        outermostTransaction.Rollback();
      try {
        if (realConnection!=null)
          realConnection.Close();
      }
      catch {
        try {
          realConnection.Dispose();
        } 
        catch {}
        finally {
          realConnection = null;
        }
      }
    }
    
    /// <summary>
    /// Gets the state of underlying database connection.
    /// <seealso cref="IDbConnection.State"/>
    /// </summary>
    public ConnectionState ConnectionState {
      get {
        return realConnection==null ? ConnectionState.Closed : realConnection.State;
      }
    }
    
    /// <summary>
    /// <see langword="True"/> if underlying database connection is opened.
    /// <seealso cref="IDbConnection.State"/>
    /// </summary>
    public bool IsConnectionOpened {
      get {
        if (nullObjects==null)
          throw new InvalidOperationException("Session is disposed.");
//SM begin
       ConnectionCleaner.getInstance().unregister(this);
//SM end
        return (realConnection!=null && (realConnection.State & ConnectionState.Open)!=0);
      }
    }
    
    /// <summary>
    /// Gets real (underlying) connection object associated with the session.
    /// <seealso cref="SecurityOptions"/>
    /// <seealso cref="SessionSecurityOptions"/>
    /// </summary>
    /// <remarks>
    /// <note type="note">You're allowed to invoke this property only when
    /// <see cref="DataObjects.NET.Session.SecurityOptions">Session.SecurityOptions</see>
    /// contains <see cref="SessionSecurityOptions.AllowAccessRealObjects"/> option.</note>
    /// </remarks>
    public IDbConnection RealConnection {
      get {
        if (disableSecurityThreads[Thread.CurrentThread]==null)
          if ((securityOptions & SessionSecurityOptions.AllowAccessRealObjects)==0)
            throw new SecurityException("Access to RealConnection isn't allowed.");
        return InternalRealConnection;
      }
    }

    internal IDbConnection InternalRealConnection {
      get {
        try {
          if (realConnection==null)
            realConnection = driver.CreateConnection();
          return realConnection;
        }
        catch (Exception e) {
          throw new DatabaseDriverException("Can't create connection.", e);
        }
      }
    }

    /// <summary>
    /// Creates a new command to execute on a <see cref="RealConnection"/>.
    /// </summary>
    /// <returns>New command to execute on a <see cref="RealConnection"/></returns>
    /// <remarks>
    /// <note type="note">You're allowed to invoke this method only when
    /// <see cref="DataObjects.NET.Session.SecurityOptions">Session.SecurityOptions</see>
    /// contains <see cref="SessionSecurityOptions.AllowAccessRealObjects"/> option.</note>
    /// </remarks>
    public IDbCommand CreateRealCommand()
    {
      if (disableSecurityThreads[Thread.CurrentThread]==null)
        if ((securityOptions & SessionSecurityOptions.AllowAccessRealObjects)==0)
          throw new SecurityException("Access to CreateRealCommand isn't allowed.");
      IDbCommand cmd = driver.CreateCommand(InternalRealConnection);
      if (transaction!=null)
        if (cmd.Transaction!=transaction.PhysicalTransaction)
            cmd.Transaction = transaction.PhysicalTransaction;
      cmd.CommandTimeout = commandTimeout;
      return cmd;
    }
    internal IDbCommand InternalCreateRealCommand()
    {
      IDbCommand cmd = driver.CreateCommand(InternalRealConnection);
      if (transaction!=null)
          if (cmd.Transaction != transaction.PhysicalTransaction)
              cmd.Transaction = transaction.PhysicalTransaction;
      cmd.CommandTimeout = commandTimeout;
      return cmd;
    }
    
    // Security
    
    internal void InternalDisableSecurity()
    {
      Thread currentThread = Thread.CurrentThread;
      object threadDepth = disableSecurityThreads[currentThread];
      if (threadDepth==null)
        disableSecurityThreads[currentThread] = 1;
      else
        disableSecurityThreads[currentThread] = ((int)threadDepth)+1;
    }

    internal void InternalEnableSecurity()
    {
      Thread currentThread = Thread.CurrentThread;
      object threadDepth = disableSecurityThreads[currentThread];
      if (threadDepth==null) {
        throw new SecurityException(
          "EnableSecurity was called more times then DisableSecurity in the current thread.");
      }
      else {
        int threadDepthI = ((int)threadDepth)-1;
        if (threadDepthI<0)
          throw new SecurityException(
            "EnableSecurity was called more times then DisableSecurity in the current thread.");
        if (threadDepthI==0)
          disableSecurityThreads.Remove(currentThread);
        else
          disableSecurityThreads[currentThread] = threadDepthI;
      }
    }

    // Transactions support

    /// <summary>
    /// Gets or sets default <see cref="IsolationLevel"/> for the transactions 
    /// in this session.
    /// </summary>
    /// <remarks>
    /// The value of this property is used when <see cref="BeginTransaction"/>
    /// is called without arguments or on start of an implicit transaction.
    /// <seealso cref="SecurityOptions"/>
    /// <seealso cref="SessionSecurityOptions"/>
    /// </remarks>
    public IsolationLevel DefaultIsolationLevel {
      get {
        return defaultIsolationLevel;
      }
      set {
        defaultIsolationLevel = value;
      }
    }
    
    /// <summary>
    /// Gets or sets number of attempts to reprocess method execution
    /// on <see cref="TransactionCanBeReprocessedException"/>.
    /// Default value is <see langword="10"/>.
    /// </summary>
    /// <remarks>
    /// This rule (reprocessing) applies only to methods where
    /// new outermost transaction was created (in automatic 
    /// transactions mode).
    /// <seealso cref="ReprocessingDelay"/>
    /// <seealso cref="SecurityOptions"/>
    /// <seealso cref="SessionSecurityOptions"/>
    /// </remarks>
    public int ReprocessingAttemptsCount {
      get {
        return reprocessingAttemptsCount;
      }
      set {
        if (disableSecurityThreads[Thread.CurrentThread]==null)
          if ((securityOptions & SessionSecurityOptions.AllowChangeReprocessingSettings)==0)
            throw new SecurityException("ReprocessingAttemptsCount change isn't allowed.");
        reprocessingAttemptsCount = value;
      }
    }
    
    /// <summary>
    /// Gets or sets number of milliseconds to sleep before performing
    /// next reprocessing attempt.
    /// Default value is <see langword="200"/>.
    /// <seealso cref="ReprocessingAttemptsCount"/>
    /// <seealso cref="SecurityOptions"/>
    /// <seealso cref="SessionSecurityOptions"/>
    /// </summary>
    public int ReprocessingDelay {
      get {
        return reprocessingDelay;
      }
      set {
        if (disableSecurityThreads[Thread.CurrentThread]==null)
          if ((securityOptions & SessionSecurityOptions.AllowChangeReprocessingSettings)==0)
            throw new SecurityException("ReprocessingDelay change isn't allowed.");
        if (value<0)
          throw new ArgumentException("ReprocessingDelay should be greater then or equal to zero.");
        reprocessingDelay = value;
      }
    }
    
    /// <summary>
    /// Gets or sets the probability (percentage) of inconsistent instance data update
    /// (see <see cref="DataObject.UpdateInconsistentData">DataObject.UpdateInconsistentData</see>).
    /// Such an update can occur on instance loading if this is necessary and
    /// with the specified probability.
    /// Default value is <see langword="50"/> (50%).
    /// <seealso cref="DataObject.UpdateInconsistentData"/>
    /// <seealso cref="SecurityOptions"/>
    /// <seealso cref="SessionSecurityOptions"/>
    /// </summary>
    public int InconsistentDataUpdateProbability {
      get {
        return inconsistentDataUpdateProbability;
      }
      set {
        if (disableSecurityThreads[Thread.CurrentThread]==null)
          if ((securityOptions & SessionSecurityOptions.AllowChangeInconsistentDataUpdateProbability)==0)
            throw new SecurityException("InconsistentDataUpdateProbability change isn't allowed.");
        if (value<0)
          throw new ArgumentException("InconsistentDataUpdateProbability should be greater then or equal to zero.");
        if (value>100)
          throw new ArgumentException("InconsistentDataUpdateProbability should be less then or equal to 100.");
        inconsistentDataUpdateProbability = value;
      }
    }
    
    /// <summary>
    /// Gets active <see cref="TransactionContext"/>.
    /// </summary>
    public TransactionContext TransactionContext {
      get {
        return transactionContext;
      }
    }
    internal void UpdateTransactionContext()
    {
      if (transaction==null)
        transactionContext = TransactionContext.CreateDirtyContext(this);
      else
        transactionContext = transaction.TransactionContext;
    }
    
    /// <summary>
    /// Gets current transaction.
    /// </summary>
    public Transaction Transaction {
      get {
        return transaction;
      }
    }
    internal void InternalSetTransaction(Transaction newTran)
    {
      transaction = newTran;
      UpdateTransactionContext();
    }

    /// <summary>
    /// Gets outermost transaction.
    /// </summary>
    public Transaction OutermostTransaction {
      get {
        return outermostTransaction;
      }
    }
    internal void InternalSetOutermostTransaction(Transaction newTran)
    {
      transaction          = newTran;
      outermostTransaction = newTran;
      UpdateTransactionContext();
      try {
        if (newTran==null)
          persister.SetTransaction(null);
        else
          persister.SetTransaction(newTran._realTransaction);
      }
      catch (Exception e) {
        throw utils.SubstituteException(e);
      }
    }

    /// <summary>
    /// Gets current transaction nesting level.
    /// </summary>
    public int TransactionNestingLevel {
      get {
        if (transaction==null)
          return 0;
        else
          return transaction.NestingLevel;
      }
    }
    
    /// <summary>
    /// <see langword="True"/> if this session is a part of the distributed transaction.
    /// <seealso cref="EnlistDistributedTransaction"/>
    /// </summary>
    public bool IsEnlisted {
      get {
        return outermostTransaction==null ? false : 
               outermostTransaction.IsEnlisted;
      }
    }
    
    /// <summary>
    /// Begins the transaction.
    /// </summary>
    /// <param name="isolationLevel">Isolation level.</param>
    /// <returns>New transaction.</returns>
    public Transaction BeginTransaction(IsolationLevel isolationLevel)
    {
      transaction = new Transaction(this, isolationLevel);
      return transaction;
    }
    
    /// <summary>
    /// Begins the transaction on the default isolation level.
    /// </summary>
    /// <returns>New transaction.</returns>
    public Transaction BeginTransaction()
    {
      transaction = new Transaction(this, IsolationLevel.Unspecified);
      return transaction;
    }
    
    /// <summary>
    /// Enlists the connection in the distributed transaction.
    /// <seealso cref="IsEnlisted"/>
    /// <seealso cref="DataObjects.NET.Transaction.IsEnlisted"/>
    /// </summary>
    /// <param name="transaction">A reference to an existing transaction in which to enlist.</param>
    /// <returns>New transaction.</returns>
    public Transaction EnlistDistributedTransaction(ITransaction transaction)
    {
      this.transaction = new Transaction(this, defaultIsolationLevel, transaction);
      return this.transaction;
    }
    
    /// <summary>
    /// Enlists the connection in the distributed transaction.
    /// <seealso cref="IsEnlisted"/>
    /// <seealso cref="DataObjects.NET.Transaction.IsEnlisted"/>
    /// </summary>
    /// <param name="isolationLevel">Isolation level.</param>
    /// <param name="transaction">A reference to an existing transaction in which to enlist.</param>
    /// <returns>New transaction.</returns>
    public Transaction EnlistDistributedTransaction(IsolationLevel isolationLevel, ITransaction transaction)
    {
      this.transaction = new Transaction(this, isolationLevel, transaction);
      return this.transaction;
    }
    
    /// <summary>
    /// Commits the innermost transaction.
    /// <seealso cref="DataObjects.NET.Transaction"/>
    /// </summary>
    public void Commit()
    {
      if (transaction==null)
        throw new TransactionRequiredException();
      transaction.Commit();
    }
    
    /// <summary>
    /// <see cref="DataObjects.NET.Transaction.Unlock"/>s and 
    /// <see cref="Commit">commit</see>s the innermost transaction.
    /// </summary>
    /// <param name="unlockCode">Unlock code.</param>
    /// <remarks>
    /// <para>
    /// You can pass <paramref name="unlockCode"/>=<see langword="0"/>
    /// to this method - in this case no exception will be thrown if 
    /// the transaction wasn't locked, but it will be thrown otherwise.
    /// </para>
    /// <para>
    /// See <see cref="LockTransaction"/> and <see cref="UnlockTransaction"/> methods
    /// description for the further information.
    /// </para>
    /// <seealso cref="DataObjects.NET.Transaction"/>
    /// <seealso cref="DataObjects.NET.Transaction.Lock"/>
    /// <seealso cref="DataObjects.NET.Transaction.Unlock"/>
    /// <seealso cref="DataObjects.NET.Transaction.IsLocked"/>
    /// </remarks>
    public void Commit(int unlockCode)
    {
      if (transaction==null)
        throw new TransactionRequiredException();
      transaction.Unlock(unlockCode);
      transaction.Commit();
    }
    
    /// <summary>
    /// Rolls back the innermost transaction.
    /// <seealso cref="DataObjects.NET.Transaction"/>
    /// </summary>
    public void Rollback()
    {
      if (transaction==null)
        throw new TransactionRequiredException();
      transaction.Rollback();
    }
    
    /// <summary>
    /// <see cref="DataObjects.NET.Transaction.Unlock"/>s and 
    /// <see cref="Rollback">rolls back</see> the innermost transaction.
    /// </summary>
    /// <param name="unlockCode">Unlock code.</param>
    /// <remarks>
    /// <para>
    /// You can pass <paramref name="unlockCode"/>=<see langword="0"/>
    /// to this method - in this case no exception will be thrown if 
    /// the transaction wasn't locked, but it will be thrown otherwise.
    /// </para>
    /// <para>
    /// See <see cref="LockTransaction"/> and <see cref="UnlockTransaction"/> methods
    /// description for the further information.
    /// </para>
    /// <seealso cref="DataObjects.NET.Transaction"/>
    /// <seealso cref="DataObjects.NET.Transaction.Lock"/>
    /// <seealso cref="DataObjects.NET.Transaction.Unlock"/>
    /// <seealso cref="DataObjects.NET.Transaction.IsLocked"/>
    /// </remarks>
    public void Rollback(int unlockCode)
    {
      if (transaction==null)
        throw new TransactionRequiredException();
      try {
        transaction.Unlock(unlockCode);
      }
      finally {
        transaction.Rollback(); // Rollback should occur anyway!
      }
    }
    
    /// <summary>
    /// Rolls back the innermost transaction.
    /// <seealso cref="DataObjects.NET.Transaction"/>
    /// </summary>
    /// <param name="rollbackException">Exception that caused the rollback.</param>
    public void Rollback(Exception rollbackException)
    {
      if (transaction==null)
        throw new TransactionRequiredException();
      transaction.Rollback(rollbackException);
    }
    
    /// <summary>
    /// <see cref="DataObjects.NET.Transaction.Unlock"/>s and 
    /// <see cref="Rollback">rolls back</see> the innermost transaction.
    /// </summary>
    /// <param name="unlockCode">Unlock code.</param>
    /// <param name="rollbackException">Exception that caused the rollback.</param>
    /// <remarks>
    /// <para>
    /// You can pass <paramref name="unlockCode"/>=<see langword="0"/>
    /// to this method - in this case no exception will be thrown if 
    /// the transaction wasn't locked, but it will be thrown otherwise.
    /// </para>
    /// <para>
    /// See <see cref="LockTransaction"/> and <see cref="UnlockTransaction"/> methods
    /// description for the further information.
    /// </para>
    /// <seealso cref="DataObjects.NET.Transaction"/>
    /// <seealso cref="DataObjects.NET.Transaction.Lock"/>
    /// <seealso cref="DataObjects.NET.Transaction.Unlock"/>
    /// <seealso cref="DataObjects.NET.Transaction.IsLocked"/>
    /// </remarks>
    public void Rollback(Exception rollbackException, int unlockCode)
    {
      if (transaction==null)
        throw new TransactionRequiredException();
      try {
        transaction.Unlock(unlockCode);
      }
      finally {
        transaction.Rollback(rollbackException); // Rollback should occur anyway!
      }
    }
    

    /// <summary>
    /// <see cref="Commit"/>s \ <see cref="Rollback">rolls back</see> 
    /// the innermost transaction depending on the value of 
    /// <paramref name="rollbackException"/> parameter.
    /// </summary>
    /// <param name="rollbackException">Exception that caused the rollback, or
    /// <see langword="null"/>, if no exception occured (in this case
    /// transaction will be <see cref="Commit"/>ted.</param>
    /// <remarks>
    /// <para>
    /// See <see cref="Commit"/> and <see cref="Rollback"/> methods
    /// description for the further information.
    /// </para>
    /// <seealso cref="Commit"/>
    /// <seealso cref="Rollback"/>
    /// <seealso cref="DataObjects.NET.Transaction"/>
    /// <seealso cref="DataObjects.NET.Transaction.Lock"/>
    /// <seealso cref="DataObjects.NET.Transaction.Unlock"/>
    /// <seealso cref="DataObjects.NET.Transaction.IsLocked"/>
    /// </remarks>
    public void CommitOrRollback(Exception rollbackException)
    {
      if (transaction==null)
        throw new TransactionRequiredException();
      if (rollbackException==null)
        transaction.Commit();
      else
        transaction.Rollback(rollbackException);
    }
    
    /// <summary>
    /// <see cref="DataObjects.NET.Transaction.Unlock"/>s the innermost 
    /// transaction and 
    /// <see cref="Commit"/>s \ <see cref="Rollback">rolls back</see> 
    /// it depending on the value 
    /// of <paramref name="rollbackException"/> parameter.
    /// </summary>
    /// <param name="rollbackException">Exception that caused the rollback, or
    /// <see langword="null"/>, if no exception occured (in this case
    /// transaction will be <see cref="Commit"/>ted.</param>
    /// <param name="unlockCode">Unlock code.</param>
    /// <remarks>
    /// <para>
    /// You can pass <paramref name="unlockCode"/>=<see langword="0"/>
    /// to this method - in this case no exception will be thrown if 
    /// the transaction wasn't locked, but it will be thrown otherwise.
    /// </para>
    /// <para>
    /// See <see cref="Commit"/>, <see cref="Rollback"/>, 
    /// <see cref="LockTransaction"/> and <see cref="UnlockTransaction"/> methods
    /// description for the further information.
    /// </para>
    /// <seealso cref="Commit"/>
    /// <seealso cref="Rollback"/>
    /// <seealso cref="DataObjects.NET.Transaction"/>
    /// <seealso cref="DataObjects.NET.Transaction.Lock"/>
    /// <seealso cref="DataObjects.NET.Transaction.Unlock"/>
    /// <seealso cref="DataObjects.NET.Transaction.IsLocked"/>
    /// </remarks>
    public void CommitOrRollback(Exception rollbackException, int unlockCode)
    {
      if (transaction==null)
        throw new TransactionRequiredException();
      if (rollbackException==null)
        transaction.Commit(unlockCode);
      else
        transaction.Rollback(rollbackException, unlockCode);
    }
    
    /// <summary>
    /// <see langword="True"/> if the inntermost transaction is locked.
    /// </summary>
    /// <remarks>
    /// <para>
    /// Locked transaction can be finished only after specifying 
    /// an unlock code. Nevertheless it can be rolled back on any
    /// point of time, but in this case it will be impossible to
    /// perform any type of activity before finishing such a transaction
    /// (you should pass an unlock code to do this or finish an outer 
    /// transaction to do the same implicitly).
    /// </para>
    /// <para>
    /// See <see cref="LockTransaction"/> and 
    /// <see cref="UnlockTransaction"/> methods
    /// description for the further information.
    /// </para>
    /// <seealso cref="LockTransaction"/>
    /// <seealso cref="UnlockTransaction"/>
    /// <seealso cref="Commit"/>
    /// <seealso cref="Rollback"/>
    /// <seealso cref="CommitOrRollback"/>
    /// <seealso cref="DataObjects.NET.Transaction"/>
    /// <seealso cref="DataObjects.NET.Transaction.Lock"/>
    /// <seealso cref="DataObjects.NET.Transaction.Unlock"/>
    /// <seealso cref="DataObjects.NET.Transaction.IsLocked"/>
    /// </remarks>
    public bool IsTransactionLocked {
      get {
        if (transaction==null)
          return false;
        return transaction.IsLocked;
      }
    }
    
    /// <summary>
    /// Locks the innermost transaction.
    /// </summary>
    /// <remarks>
    /// <para>
    /// Locked transaction can be finished only after specifying 
    /// an unlock code. Nevertheless it can be rolled back on any
    /// point of time, but in this case it will be impossible to
    /// perform any type of activity before finishing such a transaction
    /// (you should pass an unlock code to do this or finish an outer 
    /// transaction to do the same implicitly).
    /// </para>
    /// <para>
    /// See <see cref="UnlockTransaction"/> method and 
    /// <see cref="IsTransactionLocked"/> property
    /// description for the further information.
    /// </para>
    /// <seealso cref="IsTransactionLocked"/>
    /// <seealso cref="UnlockTransaction"/>
    /// <seealso cref="DataObjects.NET.Transaction"/>
    /// <seealso cref="DataObjects.NET.Transaction.Lock"/>
    /// <seealso cref="DataObjects.NET.Transaction.Unlock"/>
    /// <seealso cref="DataObjects.NET.Transaction.IsLocked"/>
    /// </remarks>
    public int LockTransaction()
    {
      if (transaction==null)
        throw new TransactionRequiredException();
      return transaction.Lock();
    }

    /// <summary>
    /// Unlocks the innermost transaction.
    /// </summary>
    /// <remarks>
    /// <para>
    /// Locked transaction can be finished only after specifying 
    /// an unlock code. Nevertheless it can be rolled back on any
    /// point of time, but in this case it will be impossible to
    /// perform any type of activity before finishing such a transaction
    /// (you should pass an unlock code to do this or finish an outer 
    /// transaction to do the same implicitly).
    /// </para>
    /// <para>
    /// You can pass <paramref name="unlockCode"/>=<see langword="0"/>
    /// to this method - in this case no exception will be thrown if 
    /// the transaction wasn't locked, but it will be thrown otherwise.
    /// </para>
    /// <para>
    /// See <see cref="LockTransaction"/> method and 
    /// <seealso cref="IsTransactionLocked"/>
    /// description for the further information.
    /// </para>
    /// <seealso cref="LockTransaction"/>
    /// <seealso cref="DataObjects.NET.Transaction"/>
    /// <seealso cref="DataObjects.NET.Transaction.Lock"/>
    /// <seealso cref="DataObjects.NET.Transaction.Unlock"/>
    /// <seealso cref="DataObjects.NET.Transaction.IsLocked"/>
    /// </remarks>
    public void UnlockTransaction(int unlockCode)
    {
      if (transaction==null)
        throw new TransactionRequiredException();
      transaction.Unlock(unlockCode);
    }


    // Savepoints support
    
    /// <summary>
    /// Creates a new savepoint in the transaction.
    /// <seealso cref="DataObjects.NET.Transaction.CreateSavepoint"/>
    /// </summary>
    /// <returns>New savepoint.</returns>
    /// <remarks>
    /// <note type="note">You can create an instance of <see cref="Savepoint"/> 
    /// only when <see cref="SecurityOptions"/> contains 
    /// <see cref="SessionSecurityOptions.AllowUseSavepoints"/> option.</note>
    /// </remarks>
    public Savepoint CreateSavepoint()
    {
      if (transaction==null)
        throw new TransactionRequiredException();
      return new Savepoint(transaction);
    }
    
    /// <summary>
    /// Rollback to the <see cref="Savepoint"/>.
    /// <seealso cref="DataObjects.NET.Savepoint.Rollback"/>
    /// </summary>
    public void Rollback(Savepoint savepoint)
    {
      if (savepoint.transaction.session!=this)
        throw new InvalidOperationException("Savepoint belongs to another session.");
      savepoint.Rollback();
    }

    
    // Delayed updates support

    /// <summary>
    /// Persists all updated instances immediately.
    /// <seealso cref="DataObject.Persist"/>
    /// </summary>
    /// <remarks>
    /// This method should be called to ensure that all delayed
    /// updates are flushed to the database. Note, that DataObjects.NET
    /// automatically call this method when it's necessary - e.g.
    /// before beginning\comitting\rolling back a transaction,
    /// establishing a savepoint or rolling back to it, performing a
    /// query and so further. So generally you shouldn't worry
    /// about calling this method.
    /// </remarks>
    [Transactional(TransactionMode.ExistingTransactionRequired)]
    public void Persist()
    {
      if (updatedInstances.Count==0)
        return;

//SM begin
    if (transactionContext != null)
    {
        if (transactionContext.IsReadOnly)
            return;
    }
//SM end

      // Automatic Transactions support code
      TransactionController tc = CreateTransactionController(TransactionMode.ExistingTransactionRequired);
    Reprocess:
      try {
        InnerPersist();
        tc.Commit();
      }
      catch (Exception e) {
        if (tc.Rollback(e, true))
          goto Reprocess;             
        throw;
      }
    }
    private void InnerPersist()
    {
      if (persistDepth++ > 32)
        throw new InvalidOperationException(
          "Too many recursive calls to Persist method of the same session.");
      try {
        Hashtable prevUpdatedInstances = updatedInstances;
        updatedInstances = new Hashtable();
        Exception firstException = null;
        foreach (object o in prevUpdatedInstances.Keys) {
          DataObject _do = o as DataObject;
          if (_do!=null) {
            if (!_do.transactionContext.isDirty) {
              if (firstException!=null)
                _do.transactionContext = transactionContext;
              else {
                try {
                  _do.Persist();
                }
                catch (Exception e) {
                  firstException = e;
                  if (!_do.transactionContext.isDirty)
                    _do.transactionContext = transactionContext;
                }
              }
            }
          }
          else
            throw new DataObjectsDotNetException(String.Format(
              "Internal error: instance with unknown type \"{0}\" "+
              "found during delayed update.",o.GetType()));
        }
        // We should ensure that all updates are flushed
        if (updatedInstances.Count>0) {
          try {
            InnerPersist();
          }
          catch (Exception e) {
            if (firstException==null)
              firstException = e;
          }
        }
        if (firstException!=null)
          throw firstException;
      }
      finally {
        persistDepth--;
      }
    }
    
    internal void PersistOnRollback()
    {
      Hashtable prevUpdatedInstances = updatedInstances;
      updatedInstances = new Hashtable();
      foreach (object o in prevUpdatedInstances.Keys) {
        DataObject _do = o as DataObject;
        if (_do!=null)
          _do.transactionContext = transactionContext;
        else
          throw new DataObjectsDotNetException(String.Format(
            "Internal error: instance with unknown type \"{0}\" "+
            "found during delayed update.",o.GetType()));
      }
    }
    
    /// <summary>
    /// <see langword="True"/> if <see cref="Persist"/> method of this session is executing now.
    /// </summary>
    public bool Persisting {
      get {
        return persistDepth>0;
      }
    }
    
    /// <summary>
    /// Gets the count of recursive calls to <see cref="Persist"/> method of this session.
    /// </summary>
    public int PersistDepth {
      get {
        return persistDepth;
      }
    }

    // Other internal methods

    /// <summary>
    /// Gets the <see cref="DataObjects.NET.Database.Persister"/> instance.
    /// </summary>
    internal Persister Persister {
      get {return persister;}
    }
    
    /// <summary>
    /// Gets the <see cref="IFormatter"/> that formats the content of FastLoadData.
    /// </summary>
    internal IFormatter FastLoadDataFormatter {
      get {return fastLoadDataFormatter;}
    }
    
    /// <summary>
    /// Gets the <see cref="IFormatter"/> that can be used
    /// to format <see cref="DataObject"/> fields into the binary
    /// stream.
    /// </summary>
    internal IFormatter BinaryFormatter {
      get {return fastLoadDataFormatter;}
    }
    

    // DataObject instance creation\access methods
    
    /// <summary>
    /// Creates new DataObject's descendant instance.
    /// </summary>
    /// <param name="type">Type of instance to create.</param>
    /// <param name="initParams">Init parameters.</param>
    /// <returns>Created instance.</returns>
    [Transactional(TransactionMode.TransactionRequired)]
    public DataObject CreateObject(System.Type type, params object[] initParams)
    {
      // Automatic Transactions support code
      TransactionController tc = CreateTransactionController(TransactionMode.TransactionRequired);
    Reprocess:
      try {
        DataObject r = InnerCreateObject(type, initParams);
        tc.Commit();
        return r;
      }
      catch (Exception e) {
        if (tc.Rollback(e, true))
          goto Reprocess;             
        throw;
      }
    }

      public Table GetBaseTable(DataObjects.NET.ObjectModel.Type type)
      {
          if (type.IsFlat)
          {
              return type.HostedIn != null ? type.HostedIn.RelatedTable : type.RelatedTable;
          }
          else
              return dataObjectTable;
      }

      public Table GetBaseTable(long ID)
      {
          if (Session.IsFlat(ID))
          {
              DataObjects.NET.ObjectModel.Type type = this.GetTypeFromFlatID(ID);
              return type.HostedIn != null ? type.HostedIn.RelatedTable : type.RelatedTable;
          }
          else
              return dataObjectTable;
      }


    private DataObject InnerCreateObject(System.Type type, object[] initParams)
    {
      ObjectModel.Type oType = types[type];
      if (oType==null)
        throw new InvalidOperationException(
          String.Format("Type \"{0}\" isn't registered in the domain.",type.FullName));
      if (oType.IsInterface || oType.IsAbstract)
        throw new InvalidOperationException(
          String.Format("Type \"{0}\" is an interface or an abstract type.",type.FullName));
      DataObject o = oType.Model.Activator.CreateDataObjectInstance(oType.Name);
      o.InitInstance(oType, this, initParams);
      return o;
    }

    /// <summary>
    /// Creates new <see cref="DataObject"/>'s descendant instance.
    /// If business method call registration disabled associates newly created 
    /// instance with the specified name.
    /// </summary>
    /// <param name="name">Unique name to identify this new object at the server side.</param>
    /// <param name="type">Type of instance to create.</param>
    /// <param name="initParams">Init parameters.</param>
    /// <returns>Created instance.</returns>
    [Transactional(TransactionMode.TransactionRequired)]
    public DataObject CreateObject(string name, System.Type type, params object[] initParams)
    {
      // Automatic Transactions support code
      TransactionController tc = CreateTransactionController(TransactionMode.TransactionRequired);
    Reprocess:
      try {
        DataObject dataObject = InnerCreateObject(type, initParams);
        RegisterObjectName(name, dataObject);
        tc.Commit();
        return dataObject;
      }
      catch (Exception e) {
        if (tc.Rollback(e, true))
          goto Reprocess;             
        throw;
      }
    }
    
#if DOTNET20

    /// <summary>
    /// Creates new DataObject's descendant instance.
    /// </summary>
    /// <param name="initParams">Init parameters.</param>
    /// <typeparam name="T">Type of instance to create.</typeparam>
    /// <returns>Created instance.</returns>
    [Transactional(TransactionMode.TransactionRequired)]
    public T CreateObject<T>(params object[] initParams) where T: DataObject
    {
      return (T)CreateObject(typeof(T), initParams);
    }

    /// <summary>
    /// Creates new <see cref="DataObject"/>'s descendant instance.
    /// If business method call registration disabled associates newly created 
    /// instance with the specified name.
    /// </summary>
    /// <param name="name">Unique name to identify this new object at the server side.</param>
    /// <param name="initParams">Init parameters.</param>
    /// <typeparam name="T">Type of instance to create.</typeparam>
    /// <returns>Created instance.</returns>
    [Transactional(TransactionMode.TransactionRequired)]
    public T CreateNamedObject<T>(string name, params object[] initParams) where T: DataObject
    {
      return (T)CreateObject(name, typeof(T), initParams);
    }
    
#endif
    
    /// <summary>
    /// Associates a temporary name with specified <see cref="DataObject"/> instance.
    /// This name will be used in the offline layer to get its offline analogue.
    /// </summary>
    /// <param name="name">Unique name to identify specified instance in the offline layer.</param>
    /// <param name="dataObject"><see cref="DataObject"/> instance to associate name with.</param>
    public void RegisterObjectName(string name, DataObject dataObject)
    {
      ObjectSetRequestProcessor requestProcessor = (ObjectSetRequestProcessor)GetServiceInternal(typeof(ObjectSetRequestProcessor));
      requestProcessor.RegisterObjectName(name, dataObject);
    }

    /// <summary>
    /// Returns <see cref="DataObject"/> instance with specified ID or <see langword="null"/> (if not found).
    /// </summary>
    [Transactional(TransactionMode.Disabled)]
    public DataObject this[long id] {
      get {
        DataObject obj = GetObject(id);
        if (obj==null && (options & SessionOptions.DisableInvalidObjectIdentifiers)!=0)
          throw new InvalidOperationException(
            "An object with specified ID doesn't exist.");
        return obj;
      }
    }
    
    // Cache improvements - not implemented yet.
    
    private DataObject GetObject(long id)
    {
      if (id==0)
        return null;
        
      object obj = Cache[id];
      DataObject dObj = obj as DataObject;
      if (dObj!=null) {
        if (dObj.State!=DataObjectState.Persistent)
          return null;
        return dObj;
      }
      
      DataObjectInstantiationInfo iInfo = (DataObjectInstantiationInfo)obj;
      if (iInfo!=null)
        return InstantiateObject((DataObjectInstantiationInfo)obj, false);
        
#if (!EXPRESS && !STANDARD)
      obj = GetValidatedCachedObject(id);
      
      dObj = obj as DataObject;
      if (dObj!=null) {
        if (dObj.State!=DataObjectState.Persistent)
          return null;
        return dObj;
      }
      
      iInfo = (DataObjectInstantiationInfo)obj;
      if (iInfo!=null)
        return InstantiateObject((DataObjectInstantiationInfo)obj, false);
#endif
      
      return FetchObject(id);
    }

#if (!EXPRESS && !STANDARD)
    internal object GetValidatedObject(long id)
    {
      object obj = GetValidatedCachedObject(id);
      if (obj is DataObject)
        return obj;
      if (obj is DataObjectInstantiationInfo)
        return obj;
      if (obj is DataObjectValidationInfo)
        return obj;
      return FetchObject(id);
    }
    
    internal object GetValidatedCachedObject(long id)
    {
      if ((options & SessionOptions.DisableAutoLoad)==SessionOptions.DisableAutoLoad)
        throw new OfflineModeException(String.Format(
          "Can't load instance with ID={0} in the OfflineMode (DisableAutoLoad flag is on).", id));
    
      // Automatic Transactions support code
      TransactionController tc = CreateTransactionController(TransactionMode.TransactionRequired);
    Reprocess:
      try {
        object r = InnerGetValidatedCachedObject(id);
        tc.Commit();
        return r;
      } catch (Exception e) {
        if (tc.Rollback(e, true))
          goto Reprocess;             
        throw;
      }
    }

    internal object InnerGetValidatedCachedObject(long id)
    {
      object obj = Cache.GetInnerValue(id);
      
      DataObjectInstantiationInfo iInfo = null;
      
      try {
      
        if (obj is DataObject) {
        
          DataObject dObj = (DataObject)obj;
          if (!dObj.TransactionContext.IsDirty) {
            if (dObj.TransactionContext.OutermostTransaction==outermostTransaction)
              return dObj;
            iInfo = (DataObjectInstantiationInfo)Cache.GlobalCache[id];
            if (iInfo==null || iInfo.DependencyParentID==0) {
              if (iInfo == null)
                  iInfo = persister.FetchDataObjectIfVersionChanged(GetBaseTable(dObj.Type), id, dObj.GetInternalVersionID(), null);
              else
                  iInfo = persister.FetchDataObjectIfVersionChanged(GetBaseTable(dObj.Type), id, dObj.GetInternalVersionID(), iInfo);
            if (iInfo != null)
            {
                Cache[id] = iInfo;
                Cache.GlobalCache[id] = iInfo;
                return iInfo;
              }
              dObj.transactionContext = transactionContext;
              dObj.MarkIndependentlyPersistedFieldsAsNotLoaded();
              return dObj;
            }
          } else {
            iInfo = (DataObjectInstantiationInfo)Cache.GlobalCache[id];
          }
          
        } else if (obj is DataObjectInstantiationInfo) {
          
          iInfo = (DataObjectInstantiationInfo)obj;
          if (!iInfo.TransactionContext.IsDirty) {
            if (iInfo.TransactionContext.OutermostTransaction==outermostTransaction)
              return iInfo;
            if (iInfo.DependencyParentID==0) {
              DataObjectInstantiationInfo newIInfo =
                persister.FetchDataObjectIfVersionChanged(GetBaseTable(this.Types.FindByID(iInfo.TypeID)), id, iInfo.VersionID, iInfo);
              if (newIInfo!=null) {
                Cache[id] = newIInfo;
                Cache.GlobalCache[id] = newIInfo;
                return newIInfo;
              }
              iInfo.TransactionContext = transactionContext;
              return iInfo;
            }
          } else {
            iInfo = (DataObjectInstantiationInfo)Cache.GlobalCache[id];
          }
          
        } else if (obj is DataObjectValidationInfo) {
        
          DataObjectValidationInfo vInfo = (DataObjectValidationInfo)obj;
          if (!vInfo.TransactionContext.IsDirty){
            if (vInfo.TransactionContext.OutermostTransaction==outermostTransaction) {
              iInfo = (DataObjectInstantiationInfo)Cache.GlobalCache[id];
              if (iInfo!=null && iInfo.VersionID==vInfo.VersionID) {
                iInfo.TransactionContext = transactionContext;
                return iInfo;
              } else {
                return vInfo;
              }
            }
          } else {
            iInfo = (DataObjectInstantiationInfo)Cache.GlobalCache[id];
          }
          
        } else {
        
          iInfo = (DataObjectInstantiationInfo)Cache.GlobalCache[id];
          
        }
        
      } catch (Exception e) {
        throw utils.SubstituteException(e);
      }
      
      if (iInfo==null)
        return null;
      
      long dependencyParentID = iInfo.DependencyParentID;
      int dependencyParentVersionID = iInfo.DependencyParentVersionID;
      
      if (dependencyParentID==0) {
        try {
            DataObjectInstantiationInfo fetchedInstInfo = persister.FetchDataObjectIfVersionChanged(GetBaseTable(this.Types.FindByID(iInfo.TypeID)), id, iInfo.VersionID, iInfo);
                if (fetchedInstInfo != null)
                    return fetchedInstInfo;
        }
        catch (Exception e)
        {
          throw utils.SubstituteException(e);
        }
        iInfo.TransactionContext = transactionContext;
        return iInfo;
      }
        
      object dpObj = GetValidatedObject(dependencyParentID);
      
      if (dpObj is DataObject) {
      
        DataObject dependencyParent = (DataObject)dpObj;
        if (dependencyParent.State == DataObjectState.Removed ||  (dependencyParent.State != DataObjectState.Removed && dependencyParent.VersionID!=dependencyParentVersionID))
          return null;
        iInfo.TransactionContext = transactionContext;
        return iInfo;
        
      } else if (dpObj is DataObjectInstantiationInfo) {
        
        DataObjectInstantiationInfo dpInstantiationInfo = (DataObjectInstantiationInfo)dpObj;
        if (dpInstantiationInfo.VersionID!=dependencyParentVersionID)
          return null;
        iInfo.TransactionContext = transactionContext;
        return iInfo;
        
      } else if (dpObj is DataObjectValidationInfo) {
        
        DataObjectValidationInfo dpValidationInfo = (DataObjectValidationInfo)dpObj;
        if (dpValidationInfo.VersionID!=dependencyParentVersionID)
          return null;
        iInfo.TransactionContext = transactionContext;
        return iInfo;
        
      }
      
      return null;
    }
    
    internal bool IsInstantiationInfoValid(DataObjectInstantiationInfo iInfo)
    {
      if (iInfo.TransactionContext.IsDirty)
        return false;
      if (iInfo.TransactionContext.OutermostTransaction==outermostTransaction)
        return true;
      long dependencyParentID = iInfo.DependencyParentID;
      if (dependencyParentID==0)
        return false;
      object dpObj = GetValidatedObject(dependencyParentID);
      if (dpObj is DataObject)
        return iInfo.DependencyParentVersionID==((DataObject)dpObj).VersionID;
      if (dpObj is DataObjectValidationInfo)
        return iInfo.DependencyParentVersionID==((DataObjectValidationInfo)dpObj).VersionID;
      return false;
    }
#endif

    [Transactional(TransactionMode.TransactionRequired)]
    private DataObject FetchObject(long id)
    {
      if ((options & SessionOptions.DisableAutoLoad)==SessionOptions.DisableAutoLoad)
        throw new OfflineModeException(String.Format(
          "Can't load instance with ID={0} in the OfflineMode (DisableAutoLoad flag is on).", id));
    
      // Automatic Transactions support code
      TransactionController tc = CreateTransactionController(TransactionMode.TransactionRequired);
    Reprocess:
      try {
        DataObject r = null;
        try {
            DataObjectInstantiationInfo iInfo = Persister.FetchDataObject(this.GetBaseTable(id), id);
          if (iInfo!=null)
            r = InnerInstantiateObject(iInfo, false);
        } catch (Exception e) {
          throw utils.SubstituteException(e);
        }
        tc.Commit();
        return r;
      }
      catch (Exception e) {
        if (tc.Rollback(e, true))
          goto Reprocess;             
        throw;
      }
    }
    
    [Transactional(TransactionMode.TransactionRequired)]
    internal DataObject InstantiateObject(DataObjectInstantiationInfo iInfo, bool checkCache)
    {
      if (transaction!=null)
        return InnerInstantiateObject(iInfo, checkCache);
        
      // Automatic Transactions support code
      TransactionController tc = CreateTransactionController(TransactionMode.TransactionRequired);
    Reprocess:
      try {
        DataObject r = InnerInstantiateObject(iInfo, checkCache);
        tc.Commit();
        return r;
      }
      catch (Exception e) {
        if (tc.Rollback(e, true))
          goto Reprocess;             
        throw;
      }
    }
    internal DataObject InnerInstantiateObject(DataObjectInstantiationInfo iInfo, bool checkCache)
    {
      if (iInfo==null || iInfo.ID==0) 
        return null;

      long id = iInfo.ID;
      if (checkCache) {
        object     obj  = Cache[iInfo.ID];
        DataObject dObj = obj as DataObject;
        if (dObj!=null) {
          dObj.useableValidationInfo = iInfo;
          Cache.GlobalCache.Add(iInfo);
          if (dObj.State!=DataObjectState.Persistent)
            return null;
          else
            return dObj;
        }
      }
      
      if ((options & SessionOptions.DisableAutoLoad)==SessionOptions.DisableAutoLoad)
        throw new OfflineModeException(String.Format(
          "Can't load instance with ID={0} in the OfflineMode (DisableAutoLoad flag is on).", id));

      if (iInfo.TransactionContext!=transactionContext) {
        bool bDirty = iInfo.TransactionContext.isDirty;
        Transaction tct = iInfo.TransactionContext.transaction;
        if (!bDirty && tct!=null && outermostTransaction==tct.OutermostTransaction) {
          iInfo.TransactionContext = transactionContext;
          goto Instantiate;
        }
        
        try {
          // Instantiation info requires version check
          if (!bDirty) {
            DataObjectInstantiationInfo newIInfo =
              Persister.FetchDataObjectIfVersionChanged(GetBaseTable(this.Types.FindByID(iInfo.TypeID)), id, iInfo.VersionID, iInfo);
            if (newIInfo==null) {
              iInfo.TransactionContext = transactionContext;
              iInfo.ValidatedByQuery = true;
              goto Instantiate;
            }
            else if (newIInfo.ID==0) {
              newIInfo.RegisterUsage(domain.PerformanceCounters);
              iInfo.Permissions  = null; // Cleanup
              iInfo.FastLoadData = null; // Cleanup
              Cache.Remove(id);
              return null;
            }
            else {
              iInfo.TransactionContext = transactionContext;
              iInfo.TypeID             = newIInfo.TypeID;
              iInfo.VersionID          = newIInfo.VersionID;
              iInfo.Permissions        = newIInfo.Permissions;
              iInfo.FastLoadData       = newIInfo.FastLoadData;
              iInfo.Source             = newIInfo.Source;
              iInfo.ValidatedByQuery   = newIInfo.ValidatedByQuery;
              goto Instantiate;
            }
          }
          else {
            DataObjectInstantiationInfo newIInfo = 
              Persister.FetchDataObject(GetBaseTable(id), id);
            if (newIInfo==null) {
              domain.PerformanceCounters.RegisterCacheHit(
                InstantiationInfoSource.Database, false);
              iInfo.Permissions  = null; // Cleanup
              iInfo.FastLoadData = null; // Cleanup
              Cache.Remove(id);
              return null;
            }
            iInfo.TransactionContext = transactionContext;
            iInfo.TypeID             = newIInfo.TypeID;
            iInfo.VersionID          = newIInfo.VersionID;
            iInfo.Permissions        = newIInfo.Permissions;
            iInfo.FastLoadData       = newIInfo.FastLoadData;
            iInfo.Source             = newIInfo.Source;
            iInfo.ValidatedByQuery   = newIInfo.ValidatedByQuery;
            goto Instantiate;
          }
        }
        catch (Exception e) {
          throw utils.SubstituteException(e);
        }
      }

    Instantiate:
      ObjectModel.Type oType = types.FindByID(iInfo.TypeID);
      if (oType==null)
        throw new InvalidOperationException(
          String.Format("Can't find type for TypeID={0}.",iInfo.TypeID));

      DataObject o = oType.Model.Activator.CreateDataObjectInstance(oType.Name);
      o.LoadInstance(oType, this, iInfo);
      return o;
    }

    #region Preload methods
    
    /// <summary>
    /// Preloads a list of <see cref="DataObject"/> instances with the 
    /// specified <see cref="DataObject.ID"/>s.
    /// </summary>
    /// <param name="ids">List of instance <see cref="DataObject.ID"/>s to 
    /// preload.</param>
    /// <remarks>
    /// <para>
    /// This method preloads a set of <see cref="DataObject"/> instances. 
    /// The <see cref="SessionCache.GetObjectCachingState">caching state</see> 
    /// of any instance from this set will be <see cref="DataObjectCachingState.Cached"/>
    /// on the completion of this operation (of course, in the current outermost 
    /// transaction, and till the moment when this data will be released).
    /// </para>
    /// <para>
    /// This method executes minimal amount of queries needed to checks and 
    /// possibly update versions of instances from the specified set. Usually
    /// the amount of queries is less then 2.
    /// </para>
    /// </remarks>
    [Transactional(TransactionMode.TransactionRequired)]
    public Helpers.StrongReferenceHolder Preload(long[] ids)
    {
      // Automatic Transactions support code
      TransactionController tc = CreateTransactionController(TransactionMode.TransactionRequired);
    Reprocess:
      try {
        Helpers.StrongReferenceHolder r = InnerPreload(ids);
        tc.Commit();
        return r;
      }
      catch (Exception e) {
        if (tc.Rollback(e, true))
          goto Reprocess;             
        throw;
      }
    }


      internal Helpers.StrongReferenceHolder InnerPreload(long[] ids)
      {
          Hashtable typeIDs = null;
          ArrayList doIDs = new ArrayList();
          for (int idx = 0; idx < ids.Length; idx++)
          {
              long id = ids[idx];
              if (Session.IsFlat(id))
              {
                  int typeID = Session.GetTypeIDFromFlatID(id);
                  if (typeIDs == null)
                      typeIDs = new Hashtable();
                  ArrayList flatIDs;
                  if (!typeIDs.ContainsKey(typeID))
                  {
                      flatIDs = new ArrayList();
                      typeIDs.Add(typeID, flatIDs);
                  }
                  else
                      flatIDs = (ArrayList)typeIDs[typeID];
                  flatIDs.Add(id);
              }
              else
                  doIDs.Add(id);
          }
          if (typeIDs == null)
              return _InnerPreload(ids);
          else
          {
              //savaoriginal qury type
              DataObjects.NET.ObjectModel.Type doType = this.sqlQuery.ObjectModelType;
              Helpers.StrongReferenceHolder result = new Helpers.StrongReferenceHolder();
              long[] inIDs;
              if (doIDs.Count > 0)
              {
                  inIDs = (long[])doIDs.ToArray(typeof(long));
                  result.Union(_InnerPreload(inIDs));
              }
              foreach (object key in typeIDs.Keys)
              {
                  int typeID = (int)key;
                  ArrayList flatIDs = (ArrayList)typeIDs[key];
                  inIDs = (long[])flatIDs.ToArray(typeof(long));
                  this.sqlQuery.ObjectModelType = this.Types.FindByID(typeID);
                  result.Union(_InnerPreload(inIDs));
              }
              //restore original type
              this.sqlQuery.ObjectModelType = doType;
              return result;
          }
      }

    internal Helpers.StrongReferenceHolder _InnerPreload(long[] ids)
    {
      int idCount = (ids==null ? 0 : ids.Length);
      if (idCount==0)
        return null;
      
      Helpers.StrongReferenceHolder srh = new Helpers.StrongReferenceHolder();
      StringBuilder sToCheckListPart1 = new StringBuilder(64);
      StringBuilder sToCheckListPart2 = new StringBuilder(64);
      StringBuilder sToLoadList  = new StringBuilder(64);
      ArrayList lToCheckList     = new ArrayList();
      ArrayList lToCheckListVIDs = new ArrayList();
      int ql = driver.Info.QueryLength - 1000;
      // ql = 4; // For testing purposes only
      int cn = driver.Info.QueryComparisonsLimit / 2 - 8;
      //cn = 2; // For testing purposes onlys
      int ccn = 0; // current comparisons number

      int cachedVersionID = 0;
      object cachedData = null;
      
      string checkCondition = "";
      for (int i = 0; i<idCount; i++) {
        long id = ids[i];
        switch (Cache.GetObjectCachingState(id, ref cachedVersionID, ref cachedData)) {
        case DataObjectCachingState.NotCached:
        case DataObjectCachingState.CachedButDirty:
          sToLoadList.Append(","+id.ToString());
          ccn ++;
          break;
        case DataObjectCachingState.CachedButRequiresVersionCheck:
//SM Begin
            if ((cachedData != null) && (cachedData is DataObject))
            {
                DataObject obj = cachedData as DataObject;
                if ((!obj.TransactionContext.IsDirty) &&
                    (obj.TransactionContext.OutermostTransaction != null) &&
                   (!ChangeCache.getInstance().isChanged(id, obj)))
                {
                    obj.transactionContext = transactionContext;
                    srh.AddReference(id, obj);
                    break;
                }
            }
//SM End
          srh.AddReference(id, cachedData);
          lToCheckList.Add(id);
          lToCheckListVIDs.Add(cachedVersionID);
          sToCheckListPart1.Append(","+id.ToString());
          sToCheckListPart2.Append(
            " or ("+sqlQuotedID+"="+id.ToString()+
                  " and "+sqlQuotedVersionID+"<>"+cachedVersionID.ToString()+")");
          ccn += 3;
          break;
        case DataObjectCachingState.Cached:
        default:
          srh.AddReference(id, this[id]);
          break;
        }
        if (ql<(sToLoadList.Length+sToCheckListPart1.Length+sToCheckListPart2.Length)
          || (cn < ccn)) 
        {
          if (sToCheckListPart1.Length>0)
            checkCondition = "(("+sqlQuotedID+" in ("+sToCheckListPart1.ToString().Substring(1)+")) and (" + sToCheckListPart2.ToString().Substring(4) + "))";

          if (sToLoadList.Length!=0) {
            sqlQuery.Condition = 
              "("+sqlQuotedID+" in ("+sToLoadList.ToString().Substring(1)+"))";
            srh.Union(sqlQuery.Preload());
            if (sToCheckListPart1.Length>0)
            {
                sqlQuery.Condition = checkCondition;
            srh.Union(sqlQuery.Preload());
            }
            sToCheckListPart1.Length = 0;
            sToCheckListPart2.Length = 0;
            sToLoadList.Length = 0;
            ccn = 0;
          }
          else {
            sqlQuery.Condition = checkCondition;
            srh.Union(sqlQuery.Preload());
            sToCheckListPart1.Length = 0;
            sToCheckListPart2.Length = 0;
            ccn = 0;
          }
        }
      }
      if (sToCheckListPart1.Length>0)
        checkCondition = "(("+sqlQuotedID+" in ("+sToCheckListPart1.ToString().Substring(1)+")) and (" + sToCheckListPart2.ToString().Substring(4) + "))";
      if (sToLoadList.Length!=0) {
        sqlQuery.Condition = 
          "("+sqlQuotedID+" in ("+sToLoadList.ToString().Substring(1)+"))";
		srh.Union(sqlQuery.Preload());
        if (sToCheckListPart1.Length>0)
		{
			sqlQuery.Condition = checkCondition;
        srh.Union(sqlQuery.Preload());
      }
      }
      else if (sToCheckListPart1.Length!=0) {
        sqlQuery.Condition = checkCondition;
        srh.Union(sqlQuery.Preload());
      }

      for (int i = 0, iMax = lToCheckList.Count; i<iMax; i++) {
        long id = (long)lToCheckList[i];
        long versionId = (int)lToCheckListVIDs[i];
        object obj = Cache[id];
        DataObject dObj = obj as DataObject;
        if (dObj!=null) {
          if (dObj.GetInternalVersionID()==versionId &&
              dObj.TransactionContext.State==TransactionContextState.RequiresVersionCheck)
            dObj.transactionContext = transactionContext;
          else {
            DataObjectInstantiationInfo dInfo = dObj.UseableInstantiationInfo;
            if (dInfo!=null && dInfo.VersionID==versionId &&
                dInfo.TransactionContext.State==TransactionContextState.RequiresVersionCheck)
              dInfo.TransactionContext = transactionContext;
          }
        }
        else {
          DataObjectInstantiationInfo dInfo = obj as DataObjectInstantiationInfo;
          if (dInfo!=null && dInfo.VersionID==versionId &&
              dInfo.TransactionContext.State==TransactionContextState.RequiresVersionCheck)
            dInfo.TransactionContext = transactionContext;
        }
        srh.AddReference(id, this[id]);
      }
      return srh;
    }
    
    /// <summary>
    /// Preloads a contents of <see cref="QueryResult"/>.
    /// </summary>
    /// <param name="queryResult"><see cref="QueryResult"/> to preload.</param>
    /// <remarks>
    /// <para>
    /// This method preloads a set of <see cref="DataObject"/> instances. 
    /// The <see cref="SessionCache.GetObjectCachingState">caching state</see> 
    /// of any instance from this set will be <see cref="DataObjectCachingState.Cached"/>
    /// on the completion of this operation (of course, in the current outermost 
    /// transaction, and till the moment when this data will be released).
    /// </para>
    /// <para>
    /// This method executes minimal amount of queries needed to checks and 
    /// possibly update versions of instances from the specified set. Usually
    /// the amount of queries is less then 2.
    /// </para>
    /// </remarks>
    [Transactional(TransactionMode.TransactionRequired)]
    public Helpers.StrongReferenceHolder Preload(QueryResult queryResult)
    {
      return Preload(queryResult.GetIDs());
    }

    /// <summary>
    /// Preloads a <see cref="ICollection">collection</see> of 
    /// <see cref="DataObject"/> instances.
    /// </summary>
    /// <param name="collection"><see cref="ICollection"/> to preload.</param>
    /// <remarks>
    /// <para>
    /// This method preloads a set of <see cref="DataObject"/> instances. 
    /// The <see cref="SessionCache.GetObjectCachingState">caching state</see> 
    /// of any instance from this set will be <see cref="DataObjectCachingState.Cached"/>
    /// on the completion of this operation (of course, in the current outermost 
    /// transaction, and till the moment when this data will be released).
    /// </para>
    /// <para>
    /// This method executes minimal amount of queries needed to checks and 
    /// possibly update versions of instances from the specified set. Usually
    /// the amount of queries is less then 2.
    /// </para>
    /// </remarks>
    [Transactional(TransactionMode.TransactionRequired)]
    public Helpers.StrongReferenceHolder Preload(ICollection collection)
    {
      ArrayList idList = new ArrayList();
      foreach (object obj in collection) {
        if (obj is Int64) {
          long id = (long)obj;
          if (id>0)
            idList.Add(id);
        }
        else {
          DataObject dobj = (DataObject)obj;
          long id = dobj.GetInternalID();
          if (id>0)
            idList.Add(id);
        }
      }
      long[] ids = (long[])idList.ToArray(typeof(long));
      return Preload(ids);
    }

    /// <summary>
    /// Preloads a list of <see cref="DataObject"/> instances with the 
    /// specified <see cref="DataObject.ID"/>s, as well as a set of
    /// additional fields (<see cref="LoadOnDemandAttribute">load-on-demand</see>,
    /// <see cref="DataObjectCollection"/> or <see cref="ValueTypeCollection"/>
    /// fields).
    /// </summary>
    /// <param name="ids">List of instance <see cref="DataObject.ID"/>s to 
    /// preload.</param>
    /// <param name="fields">List of fields to preload additionally.</param>
    /// <param name="cultures">List of <see cref="DataObjects.NET.Culture"/>s to 
    /// preload field values for. <see langword="Null"/>, if values for 
    /// just current <see cref="Culture"/> should be preloaded.</param>
    /// <remarks>
    /// <para>
    /// This method preloads a set of <see cref="DataObject"/> instances. 
    /// The <see cref="SessionCache.GetObjectCachingState">caching state</see> 
    /// of any instance from this set will be <see cref="DataObjectCachingState.Cached"/>
    /// on the completion of this operation (of course, in the current outermost 
    /// transaction, and till the moment when this data will be released).
    /// </para>
    /// <para>
    /// A set of specified fields will also be preloaded (for
    /// all specified <paramref name="cultures"/>).
    /// </para>
    /// </remarks>
    [Transactional(TransactionMode.TransactionRequired)]
    public Helpers.StrongReferenceHolder Preload(long[] ids, string[] fields, Culture[] cultures)
    {
      // Automatic Transactions support code
      TransactionController tc = CreateTransactionController(TransactionMode.TransactionRequired);
    Reprocess:
      try {
        Helpers.StrongReferenceHolder r = InnerPreload(ids, fields, cultures);
        tc.Commit();
        return r;
      }
      catch (Exception e) {
        if (tc.Rollback(e, true))
          goto Reprocess;             
        throw;
      }
    }
    private Helpers.StrongReferenceHolder InnerPreload(long[] ids, string[] fields, Culture[] cultures)
    {
      if (cultures==null)
        cultures = new Culture[] {culture};
      else {
        foreach (Culture c in cultures)
          if (c.Domain!=domain)
            throw new InvalidOperationException(String.Format(
              "Culture \"{0}\" belongs to another domain.", c.Name));
      }
      Helpers.StrongReferenceHolder srh = Preload(ids);
      if (srh==null)
        return null;
      DataObject[] dataObjects = new DataObject[srh.items.Count];
      int i = 0;
      foreach (long id in srh.items.Keys)
        dataObjects[i++] = this[id];
      PreloadFields(dataObjects, fields, cultures);
      return srh;
    }
    
    /// <summary>
    /// Preloads a list of <see cref="DataObject"/> instances with the 
    /// specified <see cref="DataObject.ID"/>s, as well as a set of
    /// additional fields (<see cref="LoadOnDemandAttribute">load-on-demand</see>,
    /// <see cref="DataObjectCollection"/> or <see cref="ValueTypeCollection"/>
    /// fields).
    /// </summary>
    /// <param name="ids">List of instance <see cref="DataObject.ID"/>s to 
    /// preload.</param>
    /// <param name="fields">List of fields to preload additionally.</param>
    /// <remarks>
    /// <para>
    /// This method preloads a set of <see cref="DataObject"/> instances. 
    /// The <see cref="SessionCache.GetObjectCachingState">caching state</see> 
    /// of any instance from this set will be <see cref="DataObjectCachingState.Cached"/>
    /// on the completion of this operation (of course, in the current outermost 
    /// transaction, and till the moment when this data will be released).
    /// </para>
    /// <para>
    /// A set of specified fields will also be preloaded (for the
    /// current <see cref="Culture"/>).
    /// </para>
    /// </remarks>
    [Transactional(TransactionMode.TransactionRequired)]
    public Helpers.StrongReferenceHolder Preload(long[] ids, string[] fields)
    {
      return Preload(ids, fields, null);
    }
    
    /// <summary>
    /// Preloads a contents of <see cref="QueryResult"/>, as well as a set of
    /// additional fields (<see cref="LoadOnDemandAttribute">load-on-demand</see>,
    /// <see cref="DataObjectCollection"/> or <see cref="ValueTypeCollection"/>
    /// fields).
    /// </summary>
    /// <param name="queryResult"><see cref="QueryResult"/> to preload.</param>
    /// <param name="fields">List of fields to preload additionally.</param>
    /// <param name="cultures">List of <see cref="DataObjects.NET.Culture"/>s to 
    /// preload field values for. <see langword="Null"/>, if values for 
    /// just current <see cref="Culture"/> should be preloaded.</param>
    /// <remarks>
    /// <para>
    /// This method preloads a set of <see cref="DataObject"/> instances. 
    /// The <see cref="SessionCache.GetObjectCachingState">caching state</see> 
    /// of any instance from this set will be <see cref="DataObjectCachingState.Cached"/>
    /// on the completion of this operation (of course, in the current outermost 
    /// transaction, and till the moment when this data will be released).
    /// </para>
    /// <para>
    /// A set of specified fields will also be preloaded (for
    /// all specified <paramref name="cultures"/>).
    /// </para>
    /// </remarks>
    [Transactional(TransactionMode.TransactionRequired)]
    public Helpers.StrongReferenceHolder Preload(QueryResult queryResult, string[] fields, Culture[] cultures)
    {
      return Preload(queryResult.GetIDs(), fields, cultures);
    }

    /// <summary>
    /// Preloads a contents of <see cref="QueryResult"/>, as well as a set of
    /// additional fields (<see cref="LoadOnDemandAttribute">load-on-demand</see>,
    /// <see cref="DataObjectCollection"/> or <see cref="ValueTypeCollection"/>
    /// fields).
    /// </summary>
    /// <param name="queryResult"><see cref="QueryResult"/> to preload.</param>
    /// <param name="fields">List of fields to preload additionally.</param>
    /// <remarks>
    /// <para>
    /// This method preloads a set of <see cref="DataObject"/> instances. 
    /// The <see cref="SessionCache.GetObjectCachingState">caching state</see> 
    /// of any instance from this set will be <see cref="DataObjectCachingState.Cached"/>
    /// on the completion of this operation (of course, in the current outermost 
    /// transaction, and till the moment when this data will be released).
    /// </para>
    /// <para>
    /// A set of specified fields will also be preloaded (for the
    /// current <see cref="Culture"/>).
    /// </para>
    /// </remarks>
    [Transactional(TransactionMode.TransactionRequired)]
    public Helpers.StrongReferenceHolder Preload(QueryResult queryResult, string[] fields)
    {
      return Preload(queryResult.GetIDs(), fields, null);
    }

    /// <summary>
    /// Preloads a <see cref="ICollection">collection</see> of 
    /// <see cref="DataObject"/> instances.
    /// </summary>
    /// <param name="collection"><see cref="ICollection"/> to preload.</param>
    /// <param name="fields">List of fields to preload additionally.</param>
    /// <param name="cultures">List of <see cref="DataObjects.NET.Culture"/>s to 
    /// preload field values for. <see langword="Null"/>, if values for 
    /// just current <see cref="Culture"/> should be preloaded.</param>
    /// <remarks>
    /// <para>
    /// This method preloads a set of <see cref="DataObject"/> instances. 
    /// The <see cref="SessionCache.GetObjectCachingState">caching state</see> 
    /// of any instance from this set will be <see cref="DataObjectCachingState.Cached"/>
    /// on the completion of this operation (of course, in the current outermost 
    /// transaction, and till the moment when this data will be released).
    /// </para>
    /// <para>
    /// A set of specified fields will also be preloaded (for
    /// all specified <paramref name="cultures"/>).
    /// </para>
    /// </remarks>
    [Transactional(TransactionMode.TransactionRequired)]
    public Helpers.StrongReferenceHolder Preload(ICollection collection, string[] fields, Culture[] cultures)
    {
      ArrayList idList = new ArrayList();
      foreach (object obj in collection) {
        if (obj is Int64) {
          long id = (long)obj;
          if (id>0)
            idList.Add(id);
        }
        else {
          DataObject dobj = (DataObject)obj;
          long id = dobj.GetInternalID();
          if (id>0)
            idList.Add(id);
        }
      }
      long[] ids = (long[])idList.ToArray(typeof(long));
      return Preload(ids, fields, cultures);
    }

    /// <summary>
    /// Preloads a <see cref="ICollection">collection</see> of 
    /// <see cref="DataObject"/> instances.
    /// </summary>
    /// <param name="collection"><see cref="ICollection"/> to preload.</param>
    /// <param name="fields">List of fields to preload additionally.</param>
    /// <remarks>
    /// <para>
    /// This method preloads a set of <see cref="DataObject"/> instances. 
    /// The <see cref="SessionCache.GetObjectCachingState">caching state</see> 
    /// of any instance from this set will be <see cref="DataObjectCachingState.Cached"/>
    /// on the completion of this operation (of course, in the current outermost 
    /// transaction, and till the moment when this data will be released).
    /// </para>
    /// <para>
    /// A set of specified fields will also be preloaded (for the
    /// current <see cref="Culture"/>).
    /// </para>
    /// </remarks>
    [Transactional(TransactionMode.TransactionRequired)]
    public Helpers.StrongReferenceHolder Preload(ICollection collection, string[] fields)
    {
      ArrayList idList = new ArrayList();
      foreach (object obj in collection) {
        if (obj is Int64) {
          long id = (long)obj;
          if (id>0)
            idList.Add(id);
        }
        else {
          DataObject dobj = (DataObject)obj;
          long id = dobj.GetInternalID();
          if (id>0)
            idList.Add(id);
        }
      }
      long[] ids = (long[])idList.ToArray(typeof(long));
      return Preload(ids, fields, null);
    }

    private void PreloadFields(DataObject[] dataObjects, string[] fieldNames, Culture[] cultures)
    {
      IDictionary hshField2Objects    = new HybridDictionary();
      IDictionary hshField2objectIDsH = new HybridDictionary();
      IDictionary hshType2Objects     = new HybridDictionary();
      IDictionary hshType2objectIDsH  = new HybridDictionary();

      // Preparing fields
      for (int i = 0, cnt = dataObjects.Length; i<cnt; i++) {
        DataObject obj = dataObjects[i];
        foreach (string fieldName in fieldNames) {
          ObjectModel.Type t = obj.Type;
          Field f = obj.Type.Fields[fieldName];
          if (f==null)
            continue;
          Field df = f.DeclaredField;
          if (df is ICollectionField) {
            ArrayList objs = (ArrayList)hshField2Objects[df];
            IDictionary objIDsH = (IDictionary)hshField2objectIDsH[df];
            if (objs==null) {
              objs = new ArrayList();
              objIDsH = new HybridDictionary();
              hshField2Objects[df] = objs;
              hshField2objectIDsH[df] = objIDsH;
            }
            if (!objIDsH.Contains(obj.ID)) {
              objs.Add(obj);
              objIDsH[obj.ID] = obj.ID;
            }
          }
          else if (df.LoadOnDemand) {
            ArrayList objs = (ArrayList)hshType2Objects[t];
            IDictionary objIDsH = (IDictionary)hshType2objectIDsH[t];
            if (objs==null) {
              objs = new ArrayList();
              objIDsH = new HybridDictionary();
              hshType2Objects[t] = objs;
              hshType2objectIDsH[t] = objIDsH;
            }
            if (!objIDsH.Contains(obj.ID)) {
              objs.Add(obj);
              objIDsH[obj.ID] = obj.ID;
            }
          }
        }
      }

      // Preloading collections
      foreach (Field f in hshField2Objects.Keys) {
        ArrayList objs   = (ArrayList)hshField2Objects[f];
        // Tables representing collections for different cultures are different,
        // so we have to run separate sql queries for each of such tables.
        if (f.Translatable) {
          foreach (Culture c in cultures) {
            if (f is DataObjectCollectionField)
              PreloadCollectionField(objs, f, c, true);
            else if (f is ValueTypeCollectionField)
              PreloadCollectionField(objs, f, c, false);
          }
        }
        else {
          if (f is DataObjectCollectionField)
            PreloadCollectionField(objs, f, null, true);
          else if (f is ValueTypeCollectionField)
            PreloadCollectionField(objs, f, null, false);
        }
      }
      
      // Preloading LOD fields
      foreach (ObjectModel.Type  t in hshType2Objects.Keys) {
        ArrayList objs = (ArrayList)hshType2Objects[t];
        ArrayList fields = new ArrayList();
        foreach (string s in fieldNames) {
          Field f = t.Fields[s];
          if (f==null)
            continue;
          if (f is ICollectionField)
            continue;
          if (!f.LoadOnDemand)
            continue;
          fields.Add(f);
        }
        PreloadLodFields(t, objs, fields, cultures);
      }
    }

    private void PreloadCollectionField(ArrayList dataObjects, Field field, Culture culture, bool isDocField) 
    {
      // int maxObjectsToProcessAtOnce = 1; // For testing purposes only
      int maxObjectsToProcessAtOnce = driver.Info.QueryComparisonsLimit-16;
      
      int cnt = dataObjects.Count;
      if (cnt==0)
        return;
        
      bool canCache = Transaction==null ? false : Transaction.IsReadOnly;
        
      ICollectionField icField = (ICollectionField)field;
      ArrayList emptyList = new ArrayList();

      ArrayList columns = null;
      if (!isDocField)
        columns = icField.GetDataColumnNames(culture);

      string ownerIdFieldName = icField.GetOwnerIdColumnName(culture);
      string itemIdFieldName  = icField.GetItemIdColumnName(culture);
      
      long[] ids  = new long[maxObjectsToProcessAtOnce+1];
      HybridDictionary hFetchedIds = new HybridDictionary();
      // int [] vids = new int [maxObjectsToProcessAtOnce+1];
      for (int i = 0, j = 0; i<cnt;) {
        DataObject obj = (DataObject)dataObjects[i++];
        IDataObjectExternalFieldValue col = (IDataObjectExternalFieldValue)obj.GetProperty(field.Name, culture);
        if (!col.IsLoaded) {
          if (isDocField) {
            DataObjectCollection doc = (DataObjectCollection)col;
            if (doc.ChangesTrackingMode==ChangesTrackingMode.ThroughOwner) {
              long[] cIds = doc.implementation.LoadItemsFromGlobalCache();
              if (cIds!=null) {
                doc.Preload(cIds, cIds.Length);
                continue;
              }
            }
          } else {
            ValueTypeCollection vtc = (ValueTypeCollection)col;
            if (vtc.ChangesTrackingMode==ChangesTrackingMode.ThroughOwner) {
              object[] sHolders = null;
              long[] cIds = vtc.implementation.LoadItemsFromGlobalCache(out sHolders);
              if (cIds!=null) {
                vtc.Preload(cIds, sHolders, cIds.Length);
                continue;
              }
            }
          }
          ids[j]  = obj.GetInternalID();
          // vids[j] = obj.GetInternalVersionID();
          j++;
        }
        if (j>=maxObjectsToProcessAtOnce || (i>=cnt && j>0)) {
          ids[j]  = 0;
          // vids[j] = 0;
          j = 0;
          hFetchedIds.Clear();
          ArrayList dbItems;
          try {
            ISchemaNode schemaNode = icField.GetSchemaNode(culture);
            if (isDocField) {
              DataObjectCollection collection = (DataObjectCollection)col;
              if (collection.PairTo is ReferenceField) {
                ObjectModel.Type type = collection.PairTo.Type;
                if (type.ShareDescendantTable || type.ShareAncestorTable)
                  schemaNode = type.RelatedView;
              }
            }
            dbItems = persister.PersisterForCollections.LoadRange(schemaNode,
              ownerIdFieldName,itemIdFieldName,ids,columns);
          }
          catch (Exception e) {
            throw utils.SubstituteException(e);
          }
          if (dbItems.Count>0) {
            long lastId = Convert.ToInt64(((IDictionary)dbItems[0])[ownerIdFieldName]);
            int  lastIdIndex = 0;
            for (int l = 0, lMax = dbItems.Count; l<=lMax; l++) {
              long id = l==lMax ? 0 :
                Convert.ToInt64(((IDictionary)dbItems[l])[ownerIdFieldName]);
              if (id!=lastId) {
                DataObject curObj = this[lastId];
                hFetchedIds[lastId] = hFetchedIds;
                if (isDocField) {
                  DataObjectCollection curCol = ((DataObjectCollection)curObj.GetProperty(field.Name,culture));
                  curCol.Preload(dbItems,lastIdIndex,l-lastIdIndex);
                  if (canCache && curCol.ChangesTrackingMode==ChangesTrackingMode.ThroughOwner)
                    curCol.implementation.SaveItemsToGlobalCache();
                }
                else {
                  ValueTypeCollection curCol = ((ValueTypeCollection)curObj.GetProperty(field.Name,culture));
                  curCol.Preload(dbItems,lastIdIndex,l-lastIdIndex);
                  if (canCache && curCol.ChangesTrackingMode==ChangesTrackingMode.ThroughOwner)
                    curCol.implementation.SaveItemsToGlobalCache();
                }
                lastId = id;
                lastIdIndex = l;
              }
            }
          }
          // Making "empties" to preload
          for (int l = 0, lMax = ids.Length; l<lMax; l++) {
            long id = ids[l];
            if (id==0)
              break;
            if (!hFetchedIds.Contains(id)) {
              DataObject curObj = this[id];
              if (isDocField) {
                DataObjectCollection curCol = ((DataObjectCollection)curObj.GetProperty(field.Name,culture));
                curCol.Preload(emptyList,0,0);
                if (canCache && curCol.ChangesTrackingMode==ChangesTrackingMode.ThroughOwner)
                  curCol.implementation.SaveItemsToGlobalCache();
              }
              else {
                ValueTypeCollection curCol = ((ValueTypeCollection)curObj.GetProperty(field.Name,culture));
                curCol.Preload(emptyList,0,0);
                if (canCache && curCol.ChangesTrackingMode==ChangesTrackingMode.ThroughOwner)
                  curCol.implementation.SaveItemsToGlobalCache();
              }
            }
          }
        }
      }
    }

    private void PreloadLodFields(ObjectModel.Type type, ArrayList dataObjects, ArrayList fields, Culture[] cultures) 
    {
      // TODO: Optimize loading of cached fields
      
      // int maxObjectsToProcessAtOnce = 1; // For testing purposes only
      int maxObjectsToProcessAtOnce = driver.Info.QueryComparisonsLimit-16;
      
      int cnt = dataObjects.Count;
      if (cnt==0)
        return;
      
      CultureCollection domainCultures = domain.cultures;
      int fCnt = type.Fields.Count;
      int cCnt = domainCultures.Count;

      BitArray loadMap = new BitArray(fCnt * cCnt);
      for (int i = 0, iMax = fields.Count; i<iMax; i++) {
        Field f = (Field)fields[i];
        int n1 = f.Index;
        if (f.Translatable) {
          foreach (Culture culture in cultures)
            loadMap[n1*cCnt+culture.Index] = true;
        }
        else
          loadMap[n1*cCnt+0] = true;
      }

      ArrayList lColumns  = DataObject.ConvertLoadMapToColumnList(loadMap,type,domain);
      if (lColumns.Count==0)
        return;

      ViewColumn idColumn = type.Fields["ID"].RelatedViewColumns[0];
      lColumns.Insert(0, idColumn);
      
      bool canCache = Transaction==null ? false : Transaction.IsReadOnly;

      long[] ids  = new long[maxObjectsToProcessAtOnce+1];
      int [] vids = new int [maxObjectsToProcessAtOnce+1];
      for (int i = 0, j = 0;;) {
        DataObject obj = (DataObject)dataObjects[i++];
        if (obj.Properties.CheckIfLoadMapRequiresLoading(loadMap)) {
          ids[j]  = obj.GetInternalID();
          vids[j] = obj.GetInternalVersionID();
          j++;
        }
        if (j>=maxObjectsToProcessAtOnce || (i>=cnt && j>0)) {
          ids[j]  = 0;
          vids[j] = 0;
          j = 0;
          ArrayList dbData;
          try {
            dbData = persister.FetchInstanceColumns(type.RelatedView,lColumns,ids,vids,true);
          }
          catch (Exception e) {
            throw utils.SubstituteException(e);
          }
          foreach (IDictionary record in dbData) {
            long id = Convert.ToInt64(record[idColumn.Name]);
            DataObject curObj = this[id];
            if (canCache)
              foreach (Field f in fields) {
                if (f.ChangesTrackingMode==ChangesTrackingMode.ThroughOwner) {
                  if (f.Translatable)
                    foreach (Culture c in cultures)
                      curObj.Inner_CacheField(f, c, record);
                  else
                    curObj.Inner_CacheField(f, null, record);
                }
              }
            curObj.LoadProperties(loadMap, record);
          }
        }
        if (i>=cnt)
          return;
      }
    }

    #endregion

    /// <summary>
    /// <see cref="DataObject.Remove"/>s a set of <see cref="DataObject"/> instances with the 
    /// specified <see cref="DataObject.ID"/>s in a single (bulk) removal
    /// operation.
    /// <seealso cref="DataObject.Remove"/>
    /// <seealso cref="DataObjectRemovalQueue"/>
    /// </summary>
    /// <param name="ids">List of instance <see cref="DataObject.ID"/>s to 
    /// remove.</param>
    /// <remarks>
    /// <para>
    /// This method doesn't execute a single query removing 
    /// specified set of objects, but runs optimized reference search and 
    /// removal process (this is even better then removing all objects
    /// by a single bulk query, since reference removal part usually requires
    /// more time).
    /// </para>
    /// </remarks>
    [Transactional(TransactionMode.TransactionRequired)]
    public void RemoveObjects(long[] ids) 
    {
      // Automatic Transactions support code
      TransactionController tc = CreateTransactionController(TransactionMode.TransactionRequired);
    Reprocess:
      try {
        InnerRemoveObjects(ids);
        tc.Commit();
      }
      catch (Exception e) {
        if (tc.Rollback(e, true))
          goto Reprocess;             
        throw;
      }
    }

    internal void InnerRemoveObjects(long[] ids) 
    { 
      if (ids==null)
        throw new ArgumentNullException("ids");
      if (ids.Length==0)
        return;

      const int toPreLoadCnt = 1024;
      object holder = null;

      // Filling removal queue with initial object set
      DataObjectRemovalQueue removalQueue = new DataObjectRemovalQueue(this);
      for (int i = 0, cnt = ids.Length; i<cnt; i++) {
        if ((i%toPreLoadCnt)==0) { // Preloading...
          int j = (i/toPreLoadCnt + 1)*toPreLoadCnt;
          if (j>cnt)
            j = cnt;
          long[] toPreLoad = new long[j-i];
          Array.Copy(ids, i, toPreLoad, 0, j-i);
          holder = Preload(toPreLoad);
        }
        DataObject currentObj = this[ids[i]];
        if (currentObj.IsRemoving)
          throw new InvalidOperationException(
            "Recursive call to Remove method of the same instance - " +
            "an attempt to execute a Remove on object that is already put to " +
            "one of removal queues, but isn't removed yet.");
        bool oldIsChanging = currentObj.IsChanging;
        currentObj.IsChanging = true;
        try {
          if (currentObj.State==DataObjectState.Removed)
            throw new InstanceIsRemovedException();
        }
        finally {
          currentObj.IsChanging = oldIsChanging;
        }
        removalQueue.Add(currentObj);
      }
      if (holder!=null)
        holder = null;

      CultureCollection cultures = domain.cultures;
      int cCnt = cultures.Count;
      int processedCount = 0;
      Hashtable hProcessed = new Hashtable();

      try {
        // Invoking SetIsRemoving & OnRemove,
        // adding contained objects to removal queue
        while (processedCount<removalQueue.Count) {
          int nextProcessedCount = removalQueue.Count;
          for (int i = processedCount; i<nextProcessedCount; i++) {
            if (i==processedCount || (i%toPreLoadCnt)==0) { // Preloading...
              int j = (i/toPreLoadCnt + 1)*toPreLoadCnt;
              if (j>nextProcessedCount)
                j = nextProcessedCount;
              long[] toPreLoad = new long[j-i];
              for (int k = i; k<j; k++)
                toPreLoad[k-i] = removalQueue.GetID(k);
              holder = Preload(toPreLoad);
            }
            DataObject currentObj = removalQueue[i];
            if (currentObj.IsRemoving)
              throw new InvalidOperationException(
                "Recursive call to Remove method of the same instance - " +
                "an attempt to execute a Remove on object that is already put to " +
                "one of removal queues, but isn't removed yet.");
            bool oldIsChanging = currentObj.IsChanging;
            currentObj.IsChanging = true;
            try {
              if (currentObj.State==DataObjectState.Removed)
                continue;
            }
            finally {
              currentObj.IsChanging = oldIsChanging;
            }
            if (currentObj.State==DataObjectState.New)
              currentObj.Persist();
        
            currentObj.SetRemovalQueue(removalQueue);
            hProcessed[currentObj.GetInternalID()] = hProcessed;
            currentObj.OnRemove();
            OnDataObjectRemove(currentObj);

            // Let's locate all [Contained] instances, and add them
            // to removal queue
            FieldCollection fields = currentObj.Type.Fields;
            for (int j = 0, fCnt = fields.Count; j<fCnt; j++) {
              Field f = fields[j];
              IReferenceHolderFieldInt rhf = f as IReferenceHolderFieldInt;
              if (rhf!=null) {
                if (f.Translatable) {
                  for (int cultureIndex = 0; cultureIndex<cCnt; cultureIndex++) {
                    Culture currentCulture = cultures[cultureIndex];
                    currentObj.EnsurePropertyLoaded(f, currentCulture);
                    object val = currentObj.Properties.GetValue(j, cultureIndex, cCnt);
                    if (val!=null)
                      removalQueue.Add(rhf.GetContainedIDs(currentObj, currentCulture, val));
                  }
                }
                else {
                  currentObj.EnsurePropertyLoaded(f, null);
                  object val = currentObj.Properties.GetValue(j,0,cCnt);
                  if (val!=null)
                    removalQueue.Add(rhf.GetContainedIDs(currentObj, null, val));
                }
              }
            }
          }
          processedCount = nextProcessedCount;
        }

        // Here we should ensure that all delayed updates are flushed now.
        Persist();
          
        InternalDisableSecurity();
        try {
          // Clearing collection\reference fields
          for (int index = 0, cnt = removalQueue.Count; index<cnt; index++) {
            if ((index%toPreLoadCnt)==0) { // Preloading...
              int j = (index/toPreLoadCnt + 1)*toPreLoadCnt;
              if (j>cnt)
                j = cnt;
              long[] toPreLoad = new long[j-index];
              for (int k = index; k<j; k++)
                toPreLoad[k-index] = removalQueue.GetID(k);
              holder = Preload(toPreLoad);
            }
            DataObject currentObj = removalQueue[index];
            FieldCollection fields = currentObj.type.Fields;
            int fCnt = fields.Count;

            // Clear all collections...
            for (int i = 0; i<fCnt; i++) {
              Field f = fields[i];
              ICollectionFieldInt cfi = f as ICollectionFieldInt;
              if (cfi==null)
                continue;
              if (f.Translatable) {
                for (int j = 0; j<cCnt; j++) {
                  object val = currentObj.Properties.GetValue(i,j,cCnt);
                  if (val!=null)
                    cfi.Clear(currentObj, cultures[j], val);
                }
              } else {
                object val = currentObj.Properties.GetValue(i,0,cCnt);
                if (val!=null)
                  cfi.Clear(currentObj, null, val);
              }
            }
            
            // Then clear all reference fields...
            for (int i = 0; i<fCnt; i++) {
              Field f = fields[i];
              if (f is ICollectionFieldInt)
                continue; // Already cleared...
              IReferenceHolderFieldInt rhf = f as IReferenceHolderFieldInt;
              if (rhf!=null) {
                if (f.Translatable) {
                  for (int j = 0; j<cCnt; j++) {
                    object val = currentObj.Properties.GetValue(i,j,cCnt);
                    if (val!=null)
                      rhf.Clear(currentObj, cultures[j], val);
                  }
                } else {
                  object val = currentObj.Properties.GetValue(i,0,cCnt);
                  if (val!=null)
                    rhf.Clear(currentObj, null, val);
                }
              }
            }
          }

          // Notify all IRemovableFieldValue properties
          for (int index = 0, cnt = removalQueue.Count; index<cnt; index++) {
            if ((index%toPreLoadCnt)==0) { // Preloading...
              int j = (index/toPreLoadCnt + 1)*toPreLoadCnt;
              if (j>cnt)
                j = cnt;
              long[] toPreLoad = new long[j-index];
              for (int k = index; k<j; k++)
                toPreLoad[k-index] = removalQueue.GetID(k);
              holder = Preload(toPreLoad);
            }
            DataObject currentObj = removalQueue[index];
            for (int i = 0; i<currentObj.Type.Fields.Count; i++) {
              int ccCnt = currentObj.Type.Fields[i].Translatable ? cCnt : 1;
              for (int j = 0; j < ccCnt; j++) {
                object o = currentObj.Properties.GetValue(i,j,cCnt);
                IRemovableFieldValue rmi = o as IRemovableFieldValue;
                if (rmi!=null) 
                  rmi.Remove();
              }
            }
          }
          
          // And finally - remove all references to all 
          // objects in queue
          foreach (ObjectModel.Type objectType in removalQueue.GetAllTypes()) {
            long[] targetIDs = removalQueue.GetInstancesOfType(objectType);
            ReferingFieldCollection rFields = objectType.ReferingFields;
            int rCnt = rFields.Count;
            for (int i = 0; i<rCnt; i++) {
              Field f = rFields[i];
              IReferenceHolderFieldInt rhf = f as IReferenceHolderFieldInt;
              if (rhf!=null)
                rhf.RemoveReferencesTo(this, targetIDs);
            }
          }
        }
        finally {
          InternalEnableSecurity();
        }

        if ((domain.DatabaseOptions & DomainDatabaseOptions.CreateForeignKeys)!=0)
          Persist();

        try {
          for (int index = 0, cnt = removalQueue.Count; index<cnt; index++) {
            if ((index%toPreLoadCnt)==0) { // Preloading...
              int j = (index/toPreLoadCnt + 1)*toPreLoadCnt;
              if (j>cnt)
                j = cnt;
              long[] toPreLoad = new long[j-index];
              for (int k = index; k<j; k++)
                toPreLoad[k-index] = removalQueue.GetID(k);
              holder = Preload(toPreLoad);
            }
            DataObject currentObj = removalQueue[index];
            long id = currentObj.GetInternalID();
            persister.DeleteDataObject(
              currentObj.Type.AllRelatedTables,
              id, currentObj.GetInternalVersionID());
            currentObj.useableValidationInfo = null;
            currentObj.ConvertToRemoved();
            if (!hProcessed.Contains(id))
              throw new DataObjectsDotNetException(
                "Internal error: incorrect attempt to remove an object from a removal queue.");
            if (removingInstances[id]!=removalQueue)
              throw new DataObjectsDotNetException(
                "Internal error: incorrect attempt to remove an object from a removal queue.");
            hProcessed.Remove(id);
            removingInstances.Remove(id);
            currentObj.OnRemoved();
          }
        }
        catch (Exception e) {
          throw utils.SubstituteException(e);
        }
      }
      finally {
        foreach (long id in hProcessed.Keys) {
          if (removingInstances[id]!=removalQueue)
            throw new DataObjectsDotNetException(
              "Internal error: incorrect attempt to remove an object from a removal queue.");
          removingInstances.Remove(id);
        }
      }
    }
    
    /// <summary>
    /// Returns "<see langword="Null"/> Object" - removed <see cref="DataObject"/> 
    /// instance of the specified type, or one of its descendants (if the specified 
    /// type is an abstract or interface type).
    /// </summary>
    /// <param name="type">Type of isntance to return.</param>
    [Transactional(TransactionMode.Disabled)]
    public DataObject GetNullObject(System.Type type) 
    {
      DataObject nullObject = (DataObject)nullObjects[type];
      if (nullObject==null) {
        ObjectModel.Type oType = types[type];
        if (oType==null)
          throw new InvalidOperationException(
            String.Format("Type \"{0}\" isn't registered in the domain.", type.FullName));
        if (oType.IsInterface) {
          foreach (ObjectModel.Type oType2 in oType.ImplementedBy) {
            nullObject = GetNullObject(oType2.SourceType);
            if (nullObject != null)
              break;
          }
        }
        else if (oType.IsAbstract) {
          foreach (ObjectModel.Type oType2 in types) {
            if (oType2.BaseType == oType) {
              nullObject = GetNullObject(oType2.SourceType);
              if (nullObject != null)
                break;
            }
          }
        }
        else {
          nullObject = oType.Model.Activator.CreateDataObjectInstance(oType.Name);
          nullObject.InitNullObject(dataObjectType, this);
        }
        if (nullObject != null)
          nullObjects[type] = nullObject;
      }
      return nullObject;
    }

// Unnecessary from post v3.3.3, since persisters
// cache everything internally in this version
//
//    internal void CacheQueryResultData(ArrayList data)
//    {
//      if ((options & SessionOptions.DisableAutoLoad)==SessionOptions.DisableAutoLoad)
//        return;
//        
//      int c = data.Count;
//      for (int i = 0; i<c; i++) {
//        DataObjectValidationInfo validationInfo = 
//          data[i] as DataObjectValidationInfo;
//        if (validationInfo==null)
//          continue;
//        long id = validationInfo.ID;
//        Cache[id] = validationInfo;
//      }
//    }
    
    internal void RegisterUpdatedInstanceWithoutPersist(DataObject obj)
    {
      OnDataObjectUpdated(obj);
      updatedInstances[obj] = this;
    }

    internal void RegisterUpdatedInstance(DataObject obj)
    {
      OnDataObjectUpdated(obj);
      updatedInstances[obj] = this;
//      if (updatedInstances.Count>=256)
//        Persist();
    }

    internal void UnregisterUpdatedInstance(DataObject obj)
    {
      updatedInstances.Remove(obj);
    }

    // DataServices
    
    /// <summary>
    /// Creates new DataService's descendant instance of
    /// the specified type. This method can only be used to 
    /// create <see cref="DataServiceType.NonShared"/>
    /// services (see <see cref="ServiceTypeAttribute"/>).
    /// <seealso cref="ServiceTypeAttribute"/>
    /// <seealso cref="DataServiceType"/>
    /// </summary>
    /// <param name="type">Type of instance to create.</param>
    /// <param name="initParams">Init parameters.</param>
    /// <returns>Created instance.</returns>
    [Transactional(TransactionMode.TransactionRequired)]
    public DataService CreateService(System.Type type, params object[] initParams)
    {
      DataService result = CreateServiceInternal(type,initParams);
      CheckServiceVisibilityType(result,type);
      return result;
    }
    
#if DOTNET20

    /// <summary>
    /// Creates new DataService's descendant instance of
    /// the specified type. This method can only be used to 
    /// create <see cref="DataServiceType.NonShared"/>
    /// services (see <see cref="ServiceTypeAttribute"/>).
    /// <seealso cref="ServiceTypeAttribute"/>
    /// <seealso cref="DataServiceType"/>
    /// </summary>
    /// <param name="initParams">Init parameters.</param>
    /// <typeparam name="T">Type of instance to create.</typeparam>
    /// <returns>Created instance.</returns>
    [Transactional(TransactionMode.TransactionRequired)]
    public T CreateService<T>(params object[] initParams) where T: DataService
    {
      return (T)CreateService(typeof(T), initParams);
    }

#endif

    internal DataService CreateServiceInternal(System.Type type, params object[] initParams)
    {
      // Automatic Transactions support code
      TransactionController tc = CreateTransactionController(TransactionMode.TransactionRequired);
    Reprocess:
      try {
        DataService r = InnerCreateService(type, initParams);
        tc.Commit();
        return r;
      }
      catch (Exception e) {
        if (tc.Rollback(e, true))
          goto Reprocess;             
        throw;
      }
    }
    private DataService InnerCreateService(System.Type type, object[] initParams)
    {
      Service oService = services[type];
      if (oService==null)
        throw new InvalidOperationException(
          String.Format("Service {0} isn't registered in the domain.", type.FullName));
      if (oService.IsAbstract)
        throw new InvalidOperationException(
          String.Format("Type \"{0}\" is an abstract type.", type.FullName));
      if (oService.ServiceType!=DataServiceType.NonShared)
        throw new InvalidOperationException(
          String.Format("Service {0} isn't NonShared, use GetService(...) instead.", type.FullName));
      DataService s = oService.Model.Activator.CreateDataServiceInstance(oService.Name);
      s.InitInstance(oService, this, initParams);
      return s;
    }

    /// <summary>
    /// Creates new DataService's descendant instance of
    /// the specified type or returns an instance of the
    /// same type that was created during the former calls
    /// to this method (of the same session - this means that only
    /// one instance of any type of service can exist in the
    /// single session). This method can only be used to 
    /// create <see cref="DataServiceType.Shared"/>
    /// services (see <see cref="ServiceTypeAttribute"/>).
    /// <seealso cref="ServiceTypeAttribute"/>
    /// <seealso cref="DataServiceType"/>
    /// </summary>
    /// <param name="type">Type of instance to create.</param>
    /// <returns>Created instance.</returns>
    [Transactional(TransactionMode.TransactionRequired)]
    public DataService GetService(System.Type type)
    {
      DataService result = GetServiceInternal(type);
      CheckServiceVisibilityType(result,type);
      return result;
    }
    
#if DOTNET20

    /// <summary>
    /// Creates new DataService's descendant instance of
    /// the specified type or returns an instance of the
    /// same type that was created during the former calls
    /// to this method (of the same session - this means that only
    /// one instance of any type of service can exist in the
    /// single session). This method can only be used to 
    /// create <see cref="DataServiceType.Shared"/>
    /// services (see <see cref="ServiceTypeAttribute"/>).
    /// <seealso cref="ServiceTypeAttribute"/>
    /// <seealso cref="DataServiceType"/>
    /// </summary>
    /// <typeparam name="T">Type of instance to create.</typeparam>
    /// <returns>Created instance.</returns>
    [Transactional(TransactionMode.TransactionRequired)]
    public T GetService<T>() where T: DataService
    {
      return (T)GetService(typeof(T));
    }

#endif
    
    internal DataService GetServiceInternal(System.Type type)
    {
      DataService r = (DataService)sharedServices[type];
      if (r!=null)
        return r;
        
      // Automatic Transactions support code
      TransactionController tc = CreateTransactionController(TransactionMode.TransactionRequired);
    Reprocess:
      try {
        r = InnerGetService(type);
        tc.Commit();
        return r;
      }
      catch (Exception e) {
        if (tc.Rollback(e, true))
          goto Reprocess;             
        throw;
      }
    }

    private DataService InnerGetService(System.Type type)
    {
      Service oService = services[type];
      if (oService==null)
        throw new InvalidOperationException(
          String.Format("Service {0} isn't registered in the domain.",type.FullName));
      if (oService.IsAbstract)
        throw new InvalidOperationException(
          String.Format("Type \"{0}\" is an abstract type.",type.FullName));
      if (oService.ServiceType!=DataServiceType.Shared)
        throw new InvalidOperationException(
          String.Format("Service {0} isn't Shared, use CreateService(...) instead.",type.FullName));
      DataService s = oService.Model.Activator.CreateDataServiceInstance(oService.Name);
      sharedServices[type] = s;
      s.InitInstance(oService, this, new object[0]);
      return s;
    }

    private DataService[] transactionEventsWatcherServices = null;
    internal DataService[] TransactionEventsWatcherServices {
      get {
        if (transactionEventsWatcherServices==null)
          transactionEventsWatcherServices = GetServices(typeof(ITransactionEventWatcher));
        return transactionEventsWatcherServices;
      }
    }

    private DataService[] dataObjectEventsWatcherServices = null;
    internal DataService[] DataObjectEventsWatcherServices {
      get {
        if (dataObjectEventsWatcherServices==null)
          dataObjectEventsWatcherServices = GetServices(typeof(IDataObjectEventWatcher));
        return dataObjectEventsWatcherServices;
      }
    }

    private DataService[] queryEventsWatcherServices = null;
    internal DataService[] QueryEventsWatcherServices {
      get {
        if (queryEventsWatcherServices==null)
          queryEventsWatcherServices = GetServices(typeof(IQueryEventWatcher));
        return queryEventsWatcherServices;
      }
    }
    
    private DataService[] runtimeServiceEventsWatcherServices = null;
    internal DataService[] RuntimeServiceEventsWatcherServices {
      get {
        if (runtimeServiceEventsWatcherServices==null)
          runtimeServiceEventsWatcherServices = GetServices(typeof(IRuntimeServiceEventWatcher));
        return runtimeServiceEventsWatcherServices;
      }
    }

    private DataService[] GetServices(System.Type t)
    {
      Debug.Assert(t.IsInterface);
      Hashtable result = new Hashtable();
      ArrayList services = new ArrayList();
      System.Type[] registeredServices = domain.GetRegisteredServices();
      for (int i = 0; i<registeredServices.Length; i++) {
        System.Type t1 = registeredServices[i];
        if (t.IsAssignableFrom(t1)) {
          DataService service = GetServiceInternal(t1);
          if (!result.Contains(service)) {
            services.Add(service);
            result.Add(service,service);
          }
        }
      }
      return (DataService[])services.ToArray(typeof(DataService));
    }

    private void CheckServiceVisibilityType(DataService service, System.Type type) {
      // checking visibility type.
      switch(service.Service.ServiceVisibilityLevel){
        case DataServiceVisibilityLevel.Public:
          break; // all ok
        case DataServiceVisibilityLevel.Internal:
          if (IsSecurityEnabled)
            throw new SecurityException(String.Format("Service {0} is Internal so you cannot use it "+
              "when security is enabled, call SessionBoundObject.DisableSecurity().",type.FullName));
          break;
        case DataServiceVisibilityLevel.Private:
          throw new SecurityException(String.Format("Service {0} is Private so you cannot use it.",
            type.FullName));
          //break;
      }
    }

    // Global events
    internal void OnDataObjectCreated(DataObject dataObject)
    {
      DataService[] srvs = DataObjectEventsWatcherServices;
      for (int i = 0; i<srvs.Length; i++)
        ((IDataObjectEventWatcher)srvs[i]).OnDataObjectCreated(dataObject);
    }

    internal void OnDataObjectPersisted(DataObject dataObject)
    {
//SM change begin
        ChangeCache.getInstance().register(dataObject.GetInternalID());
//SM change end

      DataService[] srvs = DataObjectEventsWatcherServices;
      for (int i = 0; i<srvs.Length; i++)
        ((IDataObjectEventWatcher)srvs[i]).OnDataObjectPersisted(dataObject);
    }

    internal void OnDataObjectRemove(DataObject dataObject)
    {
//SM change begin
ChangeCache.getInstance().register(dataObject.GetInternalID());
//SM change end
      DataService[] srvs = DataObjectEventsWatcherServices;
      for (int i = 0; i<srvs.Length; i++)
        ((IDataObjectEventWatcher)srvs[i]).OnDataObjectRemove(dataObject);
    }

    internal void OnDataObjectBeforeReload(DataObject dataObject, ref bool skipReload)
    {
      DataService[] srvs = DataObjectEventsWatcherServices;
      for (int i = 0; i<srvs.Length; i++)
        ((IDataObjectEventWatcher)srvs[i]).OnDataObjectBeforeReload(dataObject, ref skipReload);
    }

    internal void OnDataObjectLoad(DataObject dataObject, bool reload)
    {
      DataService[] srvs = DataObjectEventsWatcherServices;
      for (int i = 0; i<srvs.Length; i++)
        ((IDataObjectEventWatcher)srvs[i]).OnDataObjectLoad(dataObject, reload);
    }

    internal void OnDataObjectSerializeIdentity(DataObject dataObject, Serializer serializer, 
      SerializationInfo info, StreamingContext context)
    {
      DataService[] srvs = DataObjectEventsWatcherServices;
      for (int i = 0; i<srvs.Length; i++)
        ((IDataObjectEventWatcher)srvs[i]).OnDataObjectSerializeIdentity(dataObject, serializer, info, context);
    }
    
    internal void OnDataObjectSerializing(DataObject dataObject, Serializer serializer, 
      SerializationInfo info, StreamingContext context, Hashtable fields)
    {
      DataService[] srvs = DataObjectEventsWatcherServices;
      for (int i = 0; i<srvs.Length; i++)
        ((IDataObjectEventWatcher)srvs[i]).OnDataObjectSerializing(dataObject, serializer, info, context, fields);
    }

    internal void OnDataObjectDeserializeIdentity(DataObject dataObject, ref DataObject deserializationResult,
      Serializer serializer, SerializationInfo info, StreamingContext context)
    {
      DataService[] srvs = DataObjectEventsWatcherServices;
      for (int i = 0; i<srvs.Length; i++)
        ((IDataObjectEventWatcher)srvs[i]).OnDataObjectDeserializeIdentity(dataObject, ref deserializationResult, serializer, info, context);
    }

    internal void OnDataObjectDeserializing(DataObject dataObject, Serializer serializer, 
      SerializationInfo info, StreamingContext context, Hashtable fields)
    {
      DataService[] srvs = DataObjectEventsWatcherServices;
      for (int i = 0; i<srvs.Length; i++)
        ((IDataObjectEventWatcher)srvs[i]).OnDataObjectDeserializing(dataObject, serializer, info, context, fields);
    }
    
    internal void OnDataObjectPropertyDeserializationError(DataObject dataObject, Serializer serializer, 
      SerializationInfo info, StreamingContext context, 
      string propertyName, Culture culture, Exception exception)
    {
      DataService[] srvs = DataObjectEventsWatcherServices;
      for (int i = 0; i<srvs.Length; i++)
        ((IDataObjectEventWatcher)srvs[i]).OnDataObjectPropertyDeserializationError(dataObject, serializer, info, context, 
          propertyName, culture, exception);
    }

    internal void OnDataObjectDeserialized(DataObject dataObject, Serializer serializer)
    {
      DataService[] srvs = DataObjectEventsWatcherServices;
      for (int i = 0; i<srvs.Length; i++)
        ((IDataObjectEventWatcher)srvs[i]).OnDataObjectDeserialized(dataObject, serializer);
    }
    
    internal void OnDataObjectGraphDeserialized(DataObject dataObject, Serializer serializer)
    {
      DataService[] srvs = DataObjectEventsWatcherServices;
      for (int i = 0; i<srvs.Length; i++)
        ((IDataObjectEventWatcher)srvs[i]).OnDataObjectGraphDeserialized(dataObject, serializer);
    }
    
    internal void OnDataObjectGetProperty(DataObject dataObject, string name, Culture culture, object value)
    {
      DataService[] srvs = DataObjectEventsWatcherServices;
      for (int i = 0; i<srvs.Length; i++)
        ((IDataObjectEventWatcher)srvs[i]).OnDataObjectGetProperty(dataObject, name, culture, value);
    }

    internal void OnDataObjectSetProperty(DataObject dataObject, string name, Culture culture, object value)
    {
      DataService[] srvs = DataObjectEventsWatcherServices;
      for (int i = 0; i<srvs.Length; i++)
        ((IDataObjectEventWatcher)srvs[i]).OnDataObjectSetProperty(dataObject, name, culture, value);
    }

    internal void OnDataObjectPropertyChanged(DataObject dataObject, string name, Culture culture, object value)
    {
      DataService[] srvs = DataObjectEventsWatcherServices;
      for (int i = 0; i<srvs.Length; i++)
        ((IDataObjectEventWatcher)srvs[i]).OnDataObjectPropertyChanged(dataObject, name, culture, value);
    }

    internal void OnDataObjectPropertyContentChanging(DataObject dataObject, string name, Culture culture, object value)
    {
      DataService[] srvs = DataObjectEventsWatcherServices;
      for (int i = 0; i<srvs.Length; i++)
        ((IDataObjectEventWatcher)srvs[i]).OnDataObjectPropertyContentChanging(dataObject, name, culture, value);
    }

    internal void OnDataObjectPropertyContentChanged(DataObject dataObject, string name, Culture culture, object value)
    {
      DataService[] srvs = DataObjectEventsWatcherServices;
      for (int i = 0; i<srvs.Length; i++)
        ((IDataObjectEventWatcher)srvs[i]).OnDataObjectPropertyContentChanged(dataObject, name, culture, value);
    }
    
    internal void OnDataObjectUpdated(DataObject obj)
    {
        if (transaction != null)
        transaction.isReadOnly = false;
    //SM change begin
    if (obj.state != DataObjectState.New)
        ChangeCache.getInstance().register(obj.GetInternalID());
    //SM change end
}

    internal void OnTransactionBegin(Transaction transaction)
    {
      DataService[] srvs = TransactionEventsWatcherServices;
      for (int i = 0; i<srvs.Length; i++)
        ((ITransactionEventWatcher)srvs[i]).OnTransactionBegin(transaction);
    }

    internal void OnBeforeTransactionCommit(Transaction transaction)
    {
      DataService[] srvs = TransactionEventsWatcherServices;
      for (int i = 0; i<srvs.Length; i++)
        ((ITransactionEventWatcher)srvs[i]).OnBeforeTransactionCommit(transaction);
    }

    internal void OnTransactionCommit(Transaction transaction)
    {
      DataService[] srvs = TransactionEventsWatcherServices;
      for (int i = 0; i<srvs.Length; i++)
        ((ITransactionEventWatcher)srvs[i]).OnTransactionCommit(transaction);
    }

    internal void OnBeforeTransactionRollback(Transaction transaction)
    {
      DataService[] srvs = TransactionEventsWatcherServices;
      for (int i = 0; i<srvs.Length; i++)
        ((ITransactionEventWatcher)srvs[i]).OnBeforeTransactionRollback(transaction);
    }

    internal void OnTransactionRollback(Transaction transaction)
    {
      DataService[] srvs = TransactionEventsWatcherServices;
      for (int i = 0; i<srvs.Length; i++)
        ((ITransactionEventWatcher)srvs[i]).OnTransactionRollback(transaction);
    }

    internal void OnQueryBeforeExecute(QueryBase queryBase, ref string additionalWhereOperators)
    {
      DataService[] srvs = QueryEventsWatcherServices;
      for (int i = 0; i<srvs.Length; i++)
        ((IQueryEventWatcher)srvs[i]).OnQueryExecute(queryBase, ref additionalWhereOperators);
    }
    
    internal void OnRuntimeServiceBeforeExecute(RuntimeService runtimeService)
    {
      DataService[] srvs = RuntimeServiceEventsWatcherServices;
      for (int i = 0; i<srvs.Length; i++)
        ((IRuntimeServiceEventWatcher)srvs[i]).OnBeforeExecute(runtimeService);
    }
    
    internal void OnRuntimeServiceAfterExecute(RuntimeService runtimeService, Exception exception)
    {
      DataService[] srvs = RuntimeServiceEventsWatcherServices;
      for (int i = 0; i<srvs.Length; i++)
        ((IRuntimeServiceEventWatcher)srvs[i]).OnAfterExecute(runtimeService, exception);
    }


    // Query creation methods
    
    /// <summary>
    /// Creates new <see cref="Query"/> instance.
    /// </summary>
    /// <param name="text">Query text (see <see cref="Query.Text"/> property description).</param>
    /// <returns><see cref="Query"/> instance.</returns>
    public Query CreateQuery(string text)
    {
      return new Query(this, text);
    }

    /// <summary>
    /// Creates new <see cref="Query"/> instance.
    /// </summary>
    /// <returns><see cref="Query"/> instance.</returns>
    public Query CreateQuery()
    {
      return new Query(this);
    }

    /// <summary>
    /// Creates new <see cref="SqlQuery"/> instance.
    /// </summary>
    /// <param name="instanceType">The type of object (including its descendants) to search.</param>
    /// <returns><see cref="SqlQuery"/> instance.</returns>
    public SqlQuery CreateSqlQuery(System.Type instanceType)
    {
      return new SqlQuery(this, instanceType);
    }

    /// <summary>
    /// Creates new <see cref="SqlQuery"/> instance.
    /// </summary>
    /// <returns><see cref="SqlQuery"/> instance.</returns>
    public SqlQuery CreateSqlQuery()
    {
      return new SqlQuery(this);
    }
    
    /// <summary>
    /// Creates new <see cref="QueryResult"/> instance.
    /// </summary>
    /// <returns><see cref="QueryResult"/> instance.</returns>
    public QueryResult CreateQueryResult()
    {
      return new QueryResult(this);
    }

    /// <summary>
    /// Creates new <see cref="QueryResult"/> instance.
    /// </summary>
    /// <param name="options">Options describing internal behavior of
    /// the <see cref="QueryResult"/>.</param>
    /// <returns><see cref="QueryResult"/> instance.</returns>
    public QueryResult CreateQueryResult(QueryOptions options)
    {
      return new QueryResult(this, options);
    }
    
    /// <summary>
    /// Creates new <see cref="QueryResult"/> instance.
    /// </summary>
    /// <param name="options">Options describing internal behavior of
    /// the <see cref="QueryResult"/>.</param>
    /// <param name="src"><see cref="QueryResult"/> that content should be copied.</param>
    /// <returns><see cref="QueryResult"/> instance.</returns>
    public QueryResult CreateQueryResult(QueryOptions options, QueryResult src)
    {
      return new QueryResult(this, options, src);
    }
    
    /// <summary>
    /// Creates new <see cref="QueryResult"/> instance.
    /// </summary>
    /// <param name="src"><see cref="QueryResult"/> that content should be copied.</param>
    /// <returns><see cref="QueryResult"/> instance.</returns>
    public QueryResult CreateQueryResult(QueryResult src)
    {
      return new QueryResult(this, src);
    }
    
    /// <summary>
    /// Creates new <see cref="QueryResult"/> instance.
    /// </summary>
    /// <param name="options">Options describing internal behavior of
    /// the <see cref="QueryResult"/>.</param>
    /// <param name="src">Array of <see cref="DataObject"/>s that content should be copied.</param>
    /// <returns><see cref="QueryResult"/> instance.</returns>
    public QueryResult CreateQueryResult(QueryOptions options, DataObject[] src)
    {
      return new QueryResult(this, options, src);
    }
    
    /// <summary>
    /// Creates new <see cref="QueryResult"/> instance.
    /// </summary>
    /// <param name="src">Array of <see cref="DataObject"/>s that content should be copied.</param>
    /// <returns><see cref="QueryResult"/> instance.</returns>
    public QueryResult CreateQueryResult(DataObject[] src)
    {
      return new QueryResult(this, src);
    }

    /// <summary>
    /// Creates new <see cref="QueryResult"/> instance.
    /// </summary>
    /// <param name="options">Options describing internal behavior of
    /// the <see cref="QueryResult"/>.</param>
    /// <param name="src">Array of <see cref="DataObject.ID"/> values that 
    /// content should be copied.</param>
    /// <returns><see cref="QueryResult"/> instance.</returns>
    public QueryResult CreateQueryResult(QueryOptions options, long[] src)
    {
      return new QueryResult(this, options, src);
    }
    
    /// <summary>
    /// Creates new <see cref="QueryResult"/> instance.
    /// </summary>
    /// <param name="src">Array of <see cref="DataObject.ID"/> values that 
    /// content should be copied.</param>
    /// <returns><see cref="QueryResult"/> instance.</returns>
    public QueryResult CreateQueryResult(long[] src)
    {
      return new QueryResult(this, src);
    }
    
    
    // TransactionController creation

    /// <summary>
    /// Creates new <see cref="TransactionController"/> instance.
    /// </summary>
    /// <param name="transactionMode">Transaction mode.</param>
    /// <param name="isolationLevel">Isolation level.</param>
    public TransactionController CreateTransactionController(TransactionMode transactionMode,
      IsolationLevel isolationLevel)
    {
      return new TransactionController(this, transactionMode, isolationLevel);
    }
    
    /// <summary>
    /// Creates new <see cref="TransactionController"/> instance.
    /// </summary>
    /// <param name="transactionMode">Transaction mode.</param>
    public TransactionController CreateTransactionController(TransactionMode transactionMode)
    {
      return new TransactionController(this, transactionMode);
    }
    
    /// <summary>
    /// Creates new <see cref="TransactionController"/> instance.
    /// </summary>
    /// <param name="isolationLevel">Isolation level.</param>
    public TransactionController CreateTransactionController(IsolationLevel isolationLevel)
    {
      return new TransactionController(this, isolationLevel);
    }
    
    /// <summary>
    /// Creates new <see cref="TransactionController"/> instance.
    /// </summary>
    public TransactionController CreateTransactionController()
    {
      return new TransactionController(this);
    }
    
    
    // Serializer creation
    
    /// <summary>
    /// Creates new <see cref="Serializer"/> 
    /// instance.
    /// </summary>
    /// <returns>Serializer instance.</returns>
    /// <remarks>
    /// <note type="note">You can create an instance of <see cref="Serializer"/> 
    /// only when <see cref="SecurityOptions"/> contains 
    /// <see cref="SessionSecurityOptions.AllowUseSerializer"/> option.</note>
    /// </remarks>
    public Serializer CreateSerializer()
    {
      return new Serializer(this);
    }
    
    
    // Security
    
    /// <summary>
    /// Authenticates the user in the session.
    /// </summary>
    /// <param name="userName">User name to authenticate (use <see cref="String.Empty"/> to omit authentication).</param>
    /// <param name="authParams">Authentication params (e.g. password).</param>
    /// <remarks>
    /// <para>This method locates the <see cref="DataObjects.NET.Security.User"/>
    /// user with specified <paramfer name="userName"/> and authenticates it
    /// (see <see cref="DataObjects.NET.Security.User.Authenticate">User.Authenticate</see>
    /// method). If authentication was successful, <see cref="User">current user</see>
    /// in this <see cref="Session"/> will be changed.
    /// </para>
    /// <para>
    /// This method can raise the following events on the <see cref="Domain"/>:
    /// <see cref="DataObjects.NET.Domain.OnUserAuthenticate"/>,
    /// <see cref="DataObjects.NET.Domain.OnUserAuthenticated"/>,
    /// <see cref="DataObjects.NET.Domain.OnUserAuthenticationFailed"/>,
    /// <see cref="DataObjects.NET.Domain.OnUserChange"/>,
    /// <see cref="DataObjects.NET.Domain.OnUserChanged"/>.
    /// </para>
    /// <para>
    /// You can find more information about the whole DataObjects.NET
    /// security system <see cref="AccessControlList">here</see>.
    /// </para>
    /// </remarks>
    [Transactional(TransactionMode.TransactionRequired)]
    public void Authenticate(string userName, params object[] authParams)
    {
      // Automatic Transactions support code
      TransactionController tc = CreateTransactionController(TransactionMode.TransactionRequired);
    Reprocess:
      try {
        InnerAuthenticate(userName, authParams);
        tc.Commit();
      }
      catch (Exception e) {
        if (tc.Rollback(e, true))
          goto Reprocess;             
        throw;
      }
    }
    private void InnerAuthenticate(string userName, params object[] authParams)
    {
      if (userName==null)
        throw new ArgumentNullException("userName");
      if (userName=="")
        throw new ArgumentException("UserName is an empty string.");
      if (userName==domain.systemObjectNames.systemUserName)
        throw new SecurityException(String.Format(
          "Can't authenticate user \"{0}\" - this is the System Account. " +
          "Set User property to make it active instead.", userName));

      // Let's raise the event
      AuthenticationEventArgs ae = new AuthenticationEventArgs(this, true, userName, authParams);

      User oldUser = user;
      Exception lastError = null;
      SwitchUser(null);
      try {
        ae.isLocked = false;
        ae.isRetryLocked = true;
        domain.OnUserAuthenticate(this, ae);
        userName   = ae.UserName;
        authParams = ae.AuthParams;
      Retry:
        Query q = new Query(this, 
          "Select "+typeof(User).FullName+" instances where {Name}=" +
          utils.QuoteString(userName));
        DataObject[] r = q.ExecuteArray();
        foreach (User u in r) {
          if (u.Authenticate(authParams)) {
            SwitchUser(u);
            try {
              ae.isLocked = true;
              domain.OnUserAuthenticated(this, ae);
              return;
            }
            catch {
              SwitchUser(null);
              throw;
            }
          }
        }
        ae.isLocked = false;
        ae.isRetryLocked = false;
        domain.OnUserAuthenticationFailed(this, ae);
        if (ae.Retry) {
          userName   = ae.UserName;
          authParams = ae.AuthParams;
          goto Retry;
        }
      }
      catch (Exception e) {
        lastError = e;
      }
      finally {
        if (user==null) {
          SwitchUser(oldUser);
          throw new SecurityException(String.Format(
            "Authentication failed for user \"{0}\".", userName), lastError);
        }
      }
    }

    [Transactional(TransactionMode.TransactionRequired)]
    private void SwitchUser(User user)
    {
      if (this.user==user)
        return;

      // Automatic Transactions support code
      TransactionController tc = CreateTransactionController(TransactionMode.TransactionRequired);
    Reprocess:
      try {
        InnerSwitchUser(user);
        tc.Commit();
      }
      catch (Exception e) {
        if (tc.Rollback(e, true))
          goto Reprocess;             
        throw;
      }
    }
    private void InnerSwitchUser(User user)
    {
      if (user!=null) {
        if (user.session!=this)
          throw new InvalidOperationException("User belongs to the different Session.");
        if (user.State!=DataObjectState.Persistent)
          throw new InvalidInstanceStateException(user);
      }
      User oldUser = this.user;
      try {
        domain.OnUserChange(this, new UserEventArgs(this, true, user));
        if (this.user!=null)
          this.user.OnDetachFromSession();
        this.user = user;
        systemObjects.SecurityRoot.PermissionsChanged();
        if (this.user!=null)
          this.user.OnAttachToSession();
        domain.OnUserChanged(this, new UserEventArgs(this, true, user));
      }
      catch {
        try {
          if (this.user!=null)
            this.user.OnDetachFromSession();
          this.user = oldUser;
          systemObjects.SecurityRoot.PermissionsChanged();
          if (this.user!=null)
            this.user.OnAttachToSession();
        } catch {}
        throw;
      }
    }

    /// <summary>
    /// Gets the security root object (see <see cref="ISecurityRoot"/>).
    /// The same as <see cref="DataObjects.NET.SystemObjects.SecurityRoot">Session.SystemObjects.SecurityRoot</see>.
    /// </summary>
    /// <remarks>
    /// <para>
    /// You can find more information about the whole DataObjects.NET
    /// security system <see cref="AccessControlList">here</see>.
    /// </para>
    /// </remarks>
    [Transactional(TransactionMode.Disabled)]
    public  DataObject SecurityRoot {
      get {
        return systemObjects.SecurityRoot;
      }
    }

    /// <summary>
    /// Demands the permission on the <see cref="SecurityRoot"/> instance.
    /// <seealso cref="SessionBoundObject.DisableSecurity"/>
    /// <seealso cref="SessionBoundObject.EnableSecurity"/>
    /// <seealso cref="DataObjects.NET.Security"/>
    /// <seealso cref="DataObjects.NET.Security.Permissions"/>
    /// </summary>
    /// <param name="permission">Permission that should be demanded.</param>
    /// <remarks>
    /// <para>
    /// This method throws <see cref="SecurityException"/> if the pemission
    /// isn't allowed.
    /// </para>
    /// <note type="note">It's not always required that checked permission
    /// should be directly allowed (i.e. contained in the effective permission 
    /// set. 
    /// E.g. <see cref="ReadPermission"/> will be allowed indirectly, if one 
    /// of the following permissions is allowed: <see cref="ChangePermission"/>, 
    /// <see cref="OwnerPermission"/>, <see cref="AdministrationPermission"/>. 
    /// See 
    /// <see cref="IPermission.GrantedIfGrantedAnyOf">IPermission.GrantedIfGrantedAnyOf</see> 
    /// property description for additional information.
    /// </note>
    /// <para>
    /// You can find more information about the whole DataObjects.NET
    /// security system <see cref="AccessControlList">here</see>.
    /// </para>
    /// </remarks>
    [Transactional(TransactionMode.Disabled)]
    public void Demand(IPermission permission)
    {
      systemObjects.SecurityRoot.Demand(permission);
    }

    /// <summary>
    /// Checks if the permission is allowed on the <see cref="SecurityRoot"/> 
    /// instance.
    /// <seealso cref="SessionBoundObject.DisableSecurity"/>
    /// <seealso cref="SessionBoundObject.EnableSecurity"/>
    /// <seealso cref="DataObjects.NET.Security"/>
    /// <seealso cref="DataObjects.NET.Security.Permissions"/>
    /// </summary>
    /// <param name="permission">Permission that should be checked.</param>
    /// <returns><see langword="True"/> if the permission is allowed; 
    /// otherwise, <see langword="false"/>.</returns>
    /// <remarks>
    /// <note type="note">It's not always required that checked permission
    /// should be directly allowed (i.e. contained in the effective permission 
    /// set. 
    /// E.g. <see cref="ReadPermission"/> will be allowed indirectly, if one 
    /// of the following permissions is allowed: <see cref="ChangePermission"/>, 
    /// <see cref="OwnerPermission"/>, <see cref="AdministrationPermission"/>. 
    /// See 
    /// <see cref="IPermission.GrantedIfGrantedAnyOf">IPermission.GrantedIfGrantedAnyOf</see> 
    /// property description for additional information.
    /// </note>
    /// <para>
    /// You can find more information about the whole DataObjects.NET
    /// security system <see cref="AccessControlList">here</see>.
    /// </para>
    /// </remarks>
    [Transactional(TransactionMode.TransactionRequired)]
    public bool IsAllowed(IPermission permission)
    {
      return systemObjects.SecurityRoot.IsAllowed(permission);
    }

    private void CheckCaller()
    {
      StackTrace st = new StackTrace(0, false);
      StackFrame sf = null;
      MethodBase mb = null;
      System.Type t = null;
      Assembly   a  = null;

      int cnt = st.FrameCount;
      int skipFrames = -1;
      for (int i = 0; i<cnt; i++) {
        sf = st.GetFrame(i);
        mb = sf.GetMethod();
        t  = mb.ReflectedType;
        if (t!=typeof(Session)) {
          a  = t.Assembly;
          skipFrames = i;
          break;
        }
      }

      if (skipFrames<0)
        throw new SecurityException("Stack check error.");
      
      if (a!=proxyAssembly && a!=doAssembly && !IsTypeTransactional(t))
        throw new SecurityException(
          "This method\\property can be invoked only from DataObjects.NET assembly, " +
          "proxy assembly and DataObject\\DataService methods.");
    }

    private bool CheckIfCallerIsRemoteClient()
    {
      StackTrace st = new StackTrace(0, false);
      StackFrame sf = null;
      MethodBase mb = null;
      System.Type t = null;
      // Assembly   a  = null;

      int cnt = st.FrameCount;
      int skipFrames = -1;
      for (int i = 0; i<cnt; i++) {
        sf = st.GetFrame(i);
        mb = sf.GetMethod();
        t  = mb.ReflectedType;
        if (t!=typeof(Session) && t!=typeof(Domain)) {
          // a  = t.Assembly;
          skipFrames = i;
          break;
        }
      }

      if (skipFrames<0)
        throw new SecurityException("Stack check error.");
        
      if (typeof(IMessageSink).IsAssignableFrom(t))
        return true;
      else
        return false;
    }
    
    
    // Versionizing support
    
    /// <summary>
    /// Switches session to browse the database until the moment
    /// of time when specified transaction was started. Session
    /// works in <see cref="IsReadOnly">read-only</see> mode
    /// while browsing past. 
    /// <seealso cref="BrowseCurrent"/>
    /// <seealso cref="GetBrowsePastRange"/>
    /// <seealso cref="IsBrowsingPast"/>
    /// <seealso cref="IsReadOnly"/>
    /// <seealso cref="DataObjects.NET.DataObject.GetVersionInfo"/>
    /// <seealso cref="DataObjects.NET.Domain.DatabaseOptions"/>
    /// </summary>
    /// <param name="untilTransaction">A descriptor for
    /// transaction, until which we want to see the changes. 
    /// <see langword="Null"/>, if <see cref="BrowsePast"/> 
    /// mode should be turned off.
    /// </param>
    /// <remarks>
    /// Note that this method works only if 
    /// <see cref="DataObjects.NET.Domain.DatabaseOptions"/>
    /// property is set to <see langword="true"/>,
    /// otherwise it throws an exception.
    /// </remarks>
    public void BrowsePast(TransactionInfo untilTransaction)
    {
      if (untilTransaction!=null && untilTransaction.Session!=this)
        throw new InvalidOperationException("TransactionInfo object belongs to different session.");

      long tid = 0;
      if (untilTransaction!=null) {
        // Automatic Transactions support code
        TransactionController tc = CreateTransactionController(TransactionMode.TransactionRequired);
      Reprocess:
        try {
          tid = untilTransaction.ID;
          Persist();
          tc.Commit();
        } catch (Exception e) {
          if (tc.Rollback(e, true))
            goto Reprocess;             
          throw;
        }
      }
      if (persister.GetBrowsePastRange()==tid)
        return;
      if ((Domain.DatabaseOptions & DomainDatabaseOptions.EnableVersionizing)==0)
        throw new InvalidOperationException("Versionizing mode is off.");

      persister.BrowsePast(tid);
      InternalDisableSecurity();
      try {
        Cache.Invalidate(false);
      }
      finally {
        InternalEnableSecurity();
      }
      if (transaction!=null)
        transaction.InvalidateTransactionContext();
    }
    
    /// <summary>
    /// Turns off <see cref="BrowsePast"/> mode.
    /// <seealso cref="BrowsePast"/>
    /// <seealso cref="GetBrowsePastRange"/>
    /// <seealso cref="IsBrowsingPast"/>
    /// <seealso cref="IsReadOnly"/>
    /// <seealso cref="DataObjects.NET.DataObject.GetVersionInfo"/>
    /// <seealso cref="DataObjects.NET.Domain.DatabaseOptions"/>
    /// </summary>
    public void BrowseCurrent()
    {
      BrowsePast(null);
    }
    
    /// <summary>
    /// Gets <see cref="DataObjects.NET.Versionizing.TransactionInfo"/> 
    /// object that was specified in the last <see cref="BrowsePast"/>
    /// call.
    /// <seealso cref="BrowsePast"/>
    /// <seealso cref="BrowseCurrent"/>
    /// <seealso cref="IsBrowsingPast"/>
    /// <seealso cref="IsReadOnly"/>
    /// <seealso cref="DataObjects.NET.DataObject.GetVersionInfo"/>
    /// <seealso cref="DataObjects.NET.Domain.DatabaseOptions"/>
    /// </summary>
    public TransactionInfo GetBrowsePastRange()
    {
      if ((Domain.DatabaseOptions & DomainDatabaseOptions.EnableVersionizing)==0)
        return null;
      long tid = persister.GetBrowsePastRange();
      if (tid!=0)
        return (TransactionInfo)this[tid];
      else
        return null;
    }
    
    /// <summary>
    /// Gets a value indicating whether a session browses past
    /// (see <see cref="BrowsePast"/>) or not.
    /// <seealso cref="BrowsePast"/>
    /// <seealso cref="BrowseCurrent"/>
    /// <seealso cref="GetBrowsePastRange"/>
    /// <seealso cref="IsReadOnly"/>
    /// <seealso cref="DataObjects.NET.DataObject.GetVersionInfo"/>
    /// <seealso cref="DataObjects.NET.Domain.DatabaseOptions"/>
    /// </summary>
    public bool IsBrowsingPast {
      get {
        if ((Domain.DatabaseOptions & DomainDatabaseOptions.EnableVersionizing)==0)
          return false;
        long tid = persister.GetBrowsePastRange();
        return tid!=0;
      }
    }
    
    /// <summary>
    /// Gets a value indicating whether a session works
    /// in read-only mode or not.
    /// Currently session becomes read-only
    /// while it enters <see cref="BrowsePast"/> mode.
    /// <seealso cref="BrowsePast"/>
    /// <seealso cref="BrowseCurrent"/>
    /// <seealso cref="GetBrowsePastRange"/>
    /// <seealso cref="IsBrowsingPast"/>
    /// <seealso cref="IsReadOnly"/>
    /// <seealso cref="DataObjects.NET.Domain.DatabaseOptions"/>
    /// </summary>
    public bool IsReadOnly {
      get {
        return IsBrowsingPast;
      }
    }
    
    /// <summary>
    /// Creates an empty <see cref="Offline.ObjectSet"/> 
    /// bound to the current <see cref="Session"/>.
    /// </summary>
    object IConvertibleToOffline.ToOffline()
    {
      return this.ToOffline();
    }
    
    /// <summary>
    /// Creates an empty <see cref="Offline.ObjectSet"/> 
    /// bound to the current <see cref="Session"/>.
    /// </summary>
    [Transactional(TransactionMode.Disabled)]
    public ObjectSet ToOffline()
    {
      return new ObjectSet(this);
    }

    /// <summary>
    /// Creates an empty <see cref="Offline.ObjectSet"/> bound
    /// to the current <see cref="Session"/>.
    /// </summary>
    /// <param name="fillExpression">Fill expression (textual
    /// <see cref="Offline.FillDescriptor"/> definition) describing initial
    /// <see cref="Offline.ObjectSet.FillDescriptor">ObjectSet.FillDescriptor</see> 
    /// value.</param>
    [Transactional(TransactionMode.Disabled)]
    public ObjectSet ToOffline(string fillExpression)
    {
      return this.ToOffline(new FillDescriptor(Domain.ObjectModel, fillExpression));
    }

    /// <summary>
    /// Creates an empty <see cref="Offline.ObjectSet"/> bounded to the current <see cref="Session"/>.
    /// </summary>
    /// <param name="fillDescriptor">Initial <see cref="ObjectSet.FillDescriptor"/> value.</param>
    [Transactional(TransactionMode.Disabled)]
    public ObjectSet ToOffline(FillDescriptor fillDescriptor)
    {
      return new ObjectSet(this, fillDescriptor);
    }

    /// <summary>
    /// Invokes the method described by the <paramref name="methodCallDescriptor"/>.
    /// </summary>
    /// <param name="methodCallDescriptor"><see cref="MethodCallDescriptor"/> instance.</param>
    public object Invoke(MethodCallDescriptor methodCallDescriptor)
    {
      if (methodCallDescriptor.MethodName=="CreateObject") {
        object[] arguments = methodCallDescriptor.Arguments.ToValuesArray(methodCallDescriptor.CallContext);
        object[] initParams;
        if (arguments[0] is string) {
          initParams = new object[arguments.Length-2];
          Array.Copy(arguments, 2, initParams, 0, arguments.Length-2);
          return CreateObject((string)arguments[0], (System.Type)arguments[1], initParams);
        } else {
          initParams = new object[arguments.Length-1];
          Array.Copy(arguments, 1, initParams, 0, arguments.Length-1);
          return CreateObject((System.Type)arguments[0], initParams);
        }
      } else if (methodCallDescriptor.MethodName=="RemoveObjects") {
        object[] arguments = methodCallDescriptor.Arguments.ToValuesArray(methodCallDescriptor.CallContext);
        RemoveObjects(arguments[0] as long[]);
        return true;
      }
      else
        throw new InvalidOperationException("Call for the method impossible to invocation.");
    }
    
    // Helper methods
    
    /// <summary>
    /// Represents a method that is executed by
    /// <see cref="Session.ExecTransactionally"/>.
    /// </summary>
    public delegate void TransactionalOperation();
    
    /// <summary>
    /// Runs an operation inside the <see cref="TransactionController"/> wrapper.
    /// </summary>
    /// <param name="transactionMode">Transaction mode.</param>
    /// <param name="operation">Operation delegate.</param>
    /// <remarks>
    /// <para>
    /// <example>This example:
    /// <code lang="C#">
    ///   ExecTransactionally(transactionMode, operation)
    /// </code>
    /// is a shorter equivalent of:
    /// <code lang="C#">
    ///   TransactionController tc = session.CreateTransactionController(transactionMode);
    /// Reproduce:
    ///   try {
    ///     operation();
    ///     tc.Commit();
    ///   }
    ///   catch (Exception e) {
    ///     if (tc.Rollback(e, true))
    ///       goto Reprocess;
    ///     throw;
    ///   }
    /// </code>
    /// </example>
    /// </para>
    /// <para>
    /// Use static method Session.ExecTransactionally(session, transactionMode, operation) instead of 
    /// instance method session.ExecTransactionally(transactionMode, operation) when working over Remoting.
    /// </para>
    /// </remarks>
    public void ExecTransactionally(TransactionMode transactionMode, TransactionalOperation operation)
    {
      if (operation==null)
        throw new ArgumentNullException("operation");
      
      TransactionController tc = CreateTransactionController(transactionMode);
    Reproduce:
      try {
        operation();
        tc.Commit();
      }
      catch (Exception e) {
        if (tc.Rollback(e, true))
          goto Reproduce;
        throw;
      }
    }

    /// <summary>
    /// Runs an operation inside the <see cref="TransactionController"/> wrapper.
    /// </summary>
    /// <param name="session"><see cref="Session"/>.</param>
    /// <param name="transactionMode">Transaction mode.</param>
    /// <param name="operation">Operation delegate.</param>
    /// <remarks>
    /// <para>
    /// Use static method Session.ExecTransactionally(session, transactionMode, operation) instead of 
    /// instance method session.ExecTransactionally(transactionMode, operation) when working over Remoting.
    /// </para>
    /// </remarks>
    public static void ExecTransactionally(Session session, TransactionMode transactionMode, TransactionalOperation operation)
    {
      if (session == null)
        throw new ArgumentNullException("session");

      TransactionController tc = session.CreateTransactionController(transactionMode);
    Reproduce:
      try {
        operation();
        tc.Commit();
      }
      catch (Exception e) {
        if (tc.Rollback(e, true))
          goto Reproduce;
        throw;
      }
    }

    // Constructors

    /// <summary>
    /// Initializes a new instance of this class.
    /// <seealso cref="DataObjects.NET.Domain.CreateSession"/>
    /// </summary>
    /// <param name="domain"><see cref="Domain"/> to which this session should be bound.</param>
    /// <param name="userName">User name to authenticate (use <see cref="String.Empty"/> to omit authentication).</param>
    /// <param name="authParams">Authentication params (e.g. password).</param>
    public Session(Domain domain, string userName, params object[] authParams)
    {
      // To speedup access
      doAssembly = GetType().Assembly;

      if (!(domain.status==DomainStatus.Ready ||
            ((domain.status==DomainStatus.InitializingSystemObjects || 
              domain.status==DomainStatus.Initializing) && 
             Assembly.GetCallingAssembly()==doAssembly)))
        throw new InvalidOperationException("Domain isn't built.");
      
      // Core settings
      this.domain    = domain;
      this.culture   = domain.Cultures.DefaultCulture;
      this.random    = new Random();
      this.options   = SessionOptions.Default;
      this.systemObjects = new SystemObjects(this);
      // Let's detect whether this session is remote.
      isRemote = CheckIfCallerIsRemoteClient();
      if (isRemote)
        this.securityOptions = domain.RemoteSessionSecurityOptions;
      else
        this.securityOptions = domain.SessionSecurityOptions;

      // To speedup access
      proxyAssembly    = domain.ProxyAssembly;
      sysAssembly      = typeof(Object).Assembly;
      remotingAssembly = typeof(ObjRef).Assembly;
      soapAssembly     = typeof(SoapFormatter).Assembly;
      types       = domain.Types;
      services    = domain.Services;
      dataObjectType            = types[typeof(DataObject)];
      dataObjectTable           = dataObjectType.RelatedTable;
      dataObjectIDColumn        = dataObjectType.Fields["ID"].RelatedColumns[0];
      dataObjectTypeIDColumn    = dataObjectType.Fields["TypeID"].RelatedColumns[0];
      dataObjectVersionIDColumn = dataObjectType.Fields["VersionID"].RelatedColumns[0];
      driver      = domain.InternalDriver;
      driverInfo  = domain.DriverInfo;
      utils       = domain.Utils;
      memoryStream = new MemoryStream(MemoryStreamLengthLowerLimit);
      cache = new SessionCache(this);
      
      // Initialization
      EnforceSecurityOptions();
      UpdateTransactionContext();

      // Connection
      try {
        realConnection = driver.CreateConnection();
      }
      catch (NullReferenceException) {
        throw new DatabaseDriverException("Can't create connection.");
      };

      // Persister
      persister = driver.CreatePersister(this);
      persister.SetCommandTimeout(commandTimeout);
      
      // Formatter
      BinaryFormatter bf = new BinaryFormatter();
      bf.AssemblyFormat = FormatterAssemblyStyle.Simple;
      //bf.TypeFormat = FormatterTypeStyle.TypesAlways;
      fastLoadDataFormatter = bf;
      SurrogateSelector ss = new SurrogateSelector();
      SessionalSerializationSurrogate s = 
        new SessionalSerializationSurrogate(this);
      ss.AddSurrogate(typeof(DataObjectReference), 
        new StreamingContext(StreamingContextStates.All), s);
      ss.AddSurrogate(typeof(FastLoadDataSubstitution), 
        new StreamingContext(StreamingContextStates.All), s);
      ss.AddSurrogate(typeof(AccessControlList), 
        new StreamingContext(StreamingContextStates.All), s);
      foreach (ObjectModel.Type t in Types) {
        ss.AddSurrogate(t.SourceType, 
          new StreamingContext(StreamingContextStates.All), s);
        if (!t.IsAbstract)
          ss.AddSurrogate(t.ProxyType,
            new StreamingContext(StreamingContextStates.All), s);
      }
      fastLoadDataFormatter.SurrogateSelector = ss;
      fastLoadDataFormatter.Binder = new SessionalBinder(this);
      
      // Let's create a set of objects that should speed-up some
      // internal queries
      sqlQuery = new SqlQuery(this, typeof(DataObject));
      sqlQuotedID = utils.QuoteIdentifier(dataObjectIDColumn.Name);
      sqlQuotedTypeID = utils.QuoteIdentifier(dataObjectTypeIDColumn.Name);
      sqlQuotedVersionID = utils.QuoteIdentifier(dataObjectVersionIDColumn.Name);

      // Let's raise the event
      SessionEventArgs se = new SessionEventArgs(this, true);
      domain.OnSessionCreated(this, se);
      
      // And finally - let's perform authentication
      if (userName!="")
        Authenticate(userName, authParams);
      else {
        if (domain.status==DomainStatus.InitializingSystemObjects ||
            domain.status==DomainStatus.Initializing)
          return;
        if ((domain.SecurityOptions & DomainSecurityOptions.AllowCreateUnauthenticatedSessions)==0)
          throw new SecurityException("Anonymous sessions aren't allowed.");
        if (isRemote) {
          if ((domain.SecurityOptions & DomainSecurityOptions.AllowCreateUnauthenticatedSessionsRemotely)==0)
            throw new SecurityException("Remote anonymous sessions aren't allowed.");
        }
      }
    }
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// <seealso cref="DataObjects.NET.Domain.CreateSession"/>
    /// </summary>
    /// <param name="domain"><see cref="Domain"/> to which this session should be bound.</param>
    public Session(Domain domain): this(domain, "")
    {
    }
    
    // Destructors

    /// <summary>
    /// Gracefully closes session.
    /// </summary>
    public void Dispose() 
    {
      Dispose(true);
      GC.SuppressFinalize(this); 
    }

    private void Dispose(bool disposing) 
    {
      if (disposing) {
        if (realConnection!=null && IsConnectionOpened) {
          if (outermostTransaction!=null && !outermostTransaction.IsEnlisted)
            CloseConnection();
        }
        realConnection = null;
      }
      transactionContext   = null;
      outermostTransaction = null;
      transaction          = null;
      sharedServices       = null;
      cache                = null;
      updatedInstances     = null;
      nullObjects          = null;
    }

    /// <summary>
    /// Finalizer.
    /// </summary>
    ~Session()
    {
      Dispose(false);
    }
  }
}
