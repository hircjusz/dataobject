// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.ComponentModel;
using DataObjects.NET.Data.Design;

namespace DataObjects.NET.Data
{
  /// <summary>
  /// <see cref="ValueTypeCollection"/> mapping item.
  /// </summary>
  [TypeConverter(typeof(VtcMappingItemConverter))]
  public class VtcMappingItem: FieldContainerMappingItem
  {
    private string vtcName;
    
    /// <summary>
    /// Gets item name.
    /// </summary>
    public override string Name {
      get {
        if (vtcName!=null)
          return vtcName;
        return "Vtc Mapping Item";
      }
    }
    
    /// <summary>
    /// Gets or sets ValueTypeCollection name.
    /// </summary>
    [Category("Mapping")]
    [TypeConverter(typeof(VtcNameConverter))]
    public string CollectionName {
      get {
        return vtcName;
      }
      set {
        vtcName = value;
      }
    }
    
    /// <summary>
    /// Initializes a new instance of the <see cref="VtcMappingItem"/> class.
    /// </summary>
    public VtcMappingItem(): this(null, null)
    {
    }
    
    /// <summary>
    /// Initializes a new instance of the <see cref="VtcMappingItem"/> class.
    /// </summary>
    /// <param name="vtcName">ValueTypeCollection name.</param>
    /// <param name="tableName">Database table name.</param>
    public VtcMappingItem(string vtcName, string tableName): base(tableName)
    {
      this.vtcName = vtcName;
    }
  }
}
