// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Collections;
using System.Collections.Specialized;
using System.Data;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Attributes;
using DataObjects.NET.Database;
using DataObjects.NET.ObjectModel;
using DataObjects.NET.DatabaseModel;
using DataObjects.NET.FullText;
using DataObjects.NET.FullText.Drivers.Native;

namespace DataObjects.NET
{
  /// <summary>
  /// Allows to select a set of <see cref="DataObject"/> instances
  /// from the database by OQL-like criteria.
  /// </summary>
  /// <remarks>
  /// <para>
  /// This class provides more simple way to query a database.
  /// The background idea is simple: <see cref="Query"/> provides query 
  /// language that allows to define all properties of <see cref="SqlQuery"/>
  /// using the single string (see <see cref="Text"/> property). E.g.
  /// it even allows to define a full-text search criteria by this
  /// way.
  /// </para>
  /// <para>
  /// Additionally this class provides much simpler way
  /// to reference properties and collections in the <see langword="where"/>
  /// and <see langword="order by"/> clauses-it pre-processes these clauses
  /// replacing XPath-like expressions in figure brackets ({...}) to their
  /// SQL equivalents. See <see cref="Text"/> property description
  /// for further information.
  /// </para>
  /// <note type="note">If <see cref="Culture"/> is omitted for some
  /// <see cref="TranslatableAttribute">[Translatable]</see> or 
  /// <see cref="CollatableAttribute">[Collatable]</see> field, a current
  /// <see cref="Session"/>'s <see cref="Culture"/> (see
  /// <see cref="Session.Culture">Session.Culture</see>) will be used.
  /// The same rule works when <see langword="within"/> clause is
  /// omitted in the <see langword="textsearch"/> clause.</note>
  /// <example>Example:
  /// <code lang="C#">
  ///  d = new Domain("mssql://localhost/DataObjectsDotNetDemos", myProductKey);
  ///  d.RegisterCulture(new Culture("En", "U.S. English", new CultureInfo("en-us", false)));
  ///  d.Cultures["En"].Default = true;
  ///  d.RegisterTypes("MyApp.PersistentModel");
  ///  d.RegisterServices("MyApp.PersistentModel");
  ///  d.Build(DomainUpdateMode.Perform);
  ///  using (Session s = d.CreateSession()) {
  ///    s.BeginTransaction();
  ///      
  ///    Query q = new Query(s,
  ///      "Select Author instances where 'Jungle Book' in {Books.item.Name-En}");
  ///    QueryResult authors = q.Execute();
  ///    foreach (Author a in authors)
  ///      Console.WriteLine(a.Name);
  ///
  ///    s.Commit();
  ///  }
  /// </code>
  /// </example>
  /// <seealso cref="CreateSqlQuery"/>
  /// <seealso cref="DataObjects.NET.Session.CreateQuery"/>
  /// </remarks>
  public sealed class Query: QueryBase
  {
    const  string   rootNamePfx = "root";
    const  string   aliasPfx    = "oqlAlias";
    const  string   itemToken   = "item";
    static string[] parseSubqueryExpressionStopTokens = new string[] {"]"};
    static string[] parseJoinExpressionStopTokens     = new string[] {")"};
    static string[] parseWhereStopTokens = new string[] {" ","textsearch","order"};

    private int     nestingCnt   = 0;
    private string  text         = "";
    private string  sqlCondition = "";
    private string  sqlOrderBy   = "";
    private bool    initialized  = false;
    private Culture translationCulture = null;
    private QueryRestrictionCollection queryRestrictions = null;
    private QueryCompilerRefContext    rootContext;
    private QueryCompilerJoinContext   joinContext;
    private int nextAliasNumber  = 0;
    
    private Query parentQuery = null;
    
    enum TokenType 
    {
      Identifier,
      QuotedIdentifier,
      String,
      Number,
      Char,
      EOF
    }


    /// <summary>
    /// Gets or sets query text.
    /// </summary>
    /// <remarks>
    /// <para>
    /// The form of the OQL-like query text is: 
    /// <code>
    /// Select [count] [distinct] [top N] (TypeName | FieldName) [(instances | objects | values)] 
    ///   [with [options] (OptionsExpression)] 
    ///   [joins]
    ///   [where WhereExpression] 
    ///   [textsearch SearchExpression] 
    ///   [order by OrderByExpression]
    /// </code>
    /// </para>
    /// <para>
    /// Comprehensive format description: 
    /// <code>
    /// QUERY = 'Select' ['distinct'] [top Integer] (INSTANCES | VALUES) ['as' Alias]
    ///         ['with' ['options'] '(' QUERYOPTIONS ')']
    ///         {JOINEXPRESSION}
    ///         ['where' EXPRESSION] 
    ///         ['textsearch' [top N] 
    ///           ['freetext' | 'condition' | 'likeexpression'] 
    ///           TEXTSEARCHEXPRESSION
    ///           ['within' ['any' | CultureName] 'culture'] ] 
    ///         ['order by' '(' EXPRESSION ')' [('asc' | 'desc')] 
    ///                  {, '(' EXPRESSION ')' [('asc' | 'desc')]}]
    ///
    /// INSTANCES = [CASTEXPRESSION] (TYPEREFERENCE | FIELDREFERENCE) ['instances' | 'objects']
    /// VALUES    = FIELDREFERENCE ['values']
    /// TYPEREFERENCE  = {NamespaceName '.'}TypeName // You can use quoted identifiers here
    /// FIELDREFERENCE = {NamespaceName '.'}TypeName '.' FieldName['-' CultureName]{'.' FieldName}
    /// QUERYOPTIONS   = [OptionName {',' OptionName}]
    ///
    /// JOINEXPRESSION = (TYPEJOINEXPRESSION | FIELDJOINEXPRESSION) 
    /// TYPEJOINEXPRESSION  = (('inner join' | 'require') | ('left' ['outer'] 'join' | 'let')) 
    ///                       [CASTEXPRESSION] TYPEREFERENCE [as] Alias on '(' EXPRESSION ')'
    /// FIELDJOINEXPRESSION = (('inner join' | 'require') | ('left' ['outer'] 'join' | 'let')) 
    ///                       [Alias '.'] FIELDJOINPATH [[as] Alias] on '(' EXPRESSION ')'
    /// FIELDJOINPATH = [CASTEXPRESSION] (
    ///                   (REFERENCEFIELD  ['[' EXPRESSION ']'] {'.' FIELDJOINPATH } ) |
    ///                   (COLLECTIONFIELD ['[' EXPRESSION ']'] {'.' FIELDJOINPATH } ) 
    ///                 )
    /// CASTEXPRESSION = '(' TYPEREFERENCE ')'
    /// EXPRESSION = {(AnySqlCode | REFERENCE | SUBQUERY)}  // Any SQL code is any character 
    ///                                                     // content that isn't classified 
    ///                                                     // as REFERENCE or SUBQUERY
    ///
    /// SUBQUERY  = '{' QUERY '}' // Remember, double open\closing figure brackets
    ///                           // is an escape sequence that is substituted to
    ///                           // single figure bracket of the same type
    /// 
    /// REFERENCE = '{' [('this.' | 'root.' | 'parent.' | Alias '.')] PATH '}'
    /// PATH = (FIELD) | 
    ///        ([CASTEXPRESSION] REFERENCEFIELD  ['[' EXPRESSION ']'] {'.' PATH } ) |
    ///        ([CASTEXPRESSION] COLLECTIONFIELD ['[' EXPRESSION ']'] (
    ///          ('.item') {'.' PATH } |
    ///          '.count' | 
    ///          '.' ('expression' | 'expr') '[' EXPRESSION ']'
    ///        )))
    /// FIELD            = ROOTFIELD | CONTAINEDFIELD       // You can use quoted identifiers here,
    /// ROOTFIELD        = FieldName['-' CultureName]       // e.g. Name, Name-En
    /// CONTAINEDFIELD   = ROOTFIELD {'.' FieldName}        // "Name", "Name"-"En"
    ///                                                     // are allowed.
    /// REFERENCEFIELD   = FIELD     // But of DataObject type
    /// COLLECTIONFIELD  = ROOTFIELD // But of DataObjectCollection or
    ///                              // ValueTypeCollection type
    ///
    /// TextSearchExpression = QuotedString     // e.g. 'cats', '"Elvis"', '''Elvis''', 'computer*'
    /// NamespaceName    = QuotedIdentifier     // e.g. MyModel, "MyModel"
    /// TypeName         = QuotedIdentifier     // e.g. Animal, "Animal"
    /// FieldName        = QuotedIdentifier     // e.g. Age, "Age"
    /// CultureName      = QuotedIdentifier     // e.g. En, "De"
    /// OptionName       = Identifier           // e.g. LoadOnDemand
    /// Alias            = '$' QuotedIdentifier // e.g. $Parent, $"Parent"
    ///
    /// AnySqlCode       = Regex: ([^\]|[\{]|[\}]|[\\])* // Approximately, e.g. query syntax constructs
    ///                                                  // aren't classified as AnySqlCode
    /// Identifier       = Regex: [_A-Za-z0-9]+
    /// QuotedIdentifier = Regex: [_A-Za-z0-9]+  // Regular Identifier
    ///                    Regex: "([^"]|[""])+" // "" means "
    /// QuotedString     = Regex: '([^']|[''])+' // '' means '
    /// Integer          = Regex: [-]?[0-9]+
    /// </code>
    /// </para>
    /// <note type="note">If <see cref="Culture"/> is omitted for some
    /// <see cref="TranslatableAttribute">[Translatable]</see> or 
    /// <see cref="CollatableAttribute">[Collatable]</see> field, a current
    /// <see cref="Session"/>'s <see cref="Culture"/> (see
    /// <see cref="Session.Culture">Session.Culture</see>) will be used.
    /// The same rule works when <see langword="within"/> clause is
    /// omitted in the <see langword="textsearch"/> clause.</note>
    /// </remarks>
    public string Text 
    {
      get {return text;}
      set {
        if (value==null)
          throw new ArgumentNullException("Text");
        text       = value;
        translated = false;
        Translate();
      }
    }



    /// <summary>
    /// Gets the <see cref="System.Type"/> of objects to search. 
    /// Note that descendants participate in search too.
    /// Use <see cref="Text"/> property instead of changing this property.
    /// </summary>
    public override System.Type InstanceType {
      get {return base.InstanceType;}
      set {
        if (!initialized)
          base.InstanceType = value;
        else
          throw new InvalidOperationException("This property can't be changed directly-use Text property instead.");
      }
    }

    /// <summary>
    /// Gets the <see cref="ObjectModel.Type"/> of objects to search. 
    /// Note that descendants participate in search too.
    /// Use <see cref="Text"/> property instead of changing this property.
    /// </summary>
    public override ObjectModel.Type ObjectModelType {
      get {return base.ObjectModelType;}
      set {
        if (!initialized)
          base.ObjectModelType = value;
        else
          throw new InvalidOperationException("This property can't be changed directly-use Text property instead.");
      }
    }

    /// <summary>
    /// Gets or sets the <see cref="ObjectModel.Field"/> the query is
    /// targeted to.
    /// </summary>
    public override ObjectModel.Field Field {
      get {return base.Field;}
      set {
        throw new InvalidOperationException("This property can't be changed directly-use Text property instead.");
      }
    }

    /// <summary>
    /// Gets or sets the <see cref="Culture"/> of the 
    /// <see cref="Field"/> the query is targeted to.
    /// </summary>
    public override Culture FieldCulture {
      get {return base.FieldCulture;}
      set {
        throw new InvalidOperationException("This property can't be changed directly-use Text property instead.");
      }
    }

    /// <summary>
    /// Gets "top n" expression in the underlying select statement.
    /// Use <see cref="Text"/> property instead of accessing this property.
    /// </summary>
    public override long Top 
    {
      get {return base.Top;}
      set {
        throw new InvalidOperationException("This property can't be changed directly-use Text property instead.");
      }
    }
    
    /// <summary>
    /// Gets query options.
    /// </summary>
    public override QueryOptions Options {
      get {return base.Options;}
      set {
        throw new InvalidOperationException("This property can't be changed directly-use Text property instead.");
      }
    }
    
    /// <summary>
    /// Gets full-text search condition in the underlying select statement.
    /// Use <see cref="Text"/> property instead of changing this property.
    /// </summary>
    public FtsCondition FtsCondition {
      get {return ftsCondition;}
      set {
        throw new InvalidOperationException("This property can't be changed directly-use Text property instead.");
      }
    }

    /// <summary>
    /// Gets <see cref="SqlJoinCollection"/> containing a list of joins for 
    /// this query.
    /// Always throws <see cref="InvalidOperationException"/>.
    /// </summary>
    public override SqlJoinCollection Joins {
      get {
        throw new InvalidOperationException("This property can't be accessed directly-use Text property instead.");
      }
    }

    /// <summary>
    /// Gets the collection of <see cref="QueryRestriction"/> objects.
    /// This property describes additional restrictions. Currently it is
    /// used to define collection-restricted queries only.
    /// </summary>
    public QueryRestrictionCollection QueryRestrictions {
      get {
        return queryRestrictions;
      }
    }
    
    /// <summary>
    /// Gets root name. Root name is used in sql queries.
    /// </summary>
    internal override string RootName {
      get {
        if (nestingCnt==0)
          return rootNamePfx;
        return rootNamePfx + nestingCnt.ToString();
      }
    }

    /// <summary>
    /// Translates the query.
    /// </summary>
    protected override void Translate()
    {
      if (session.Culture==translationCulture && translated)
        return;
      
      translated   = false;
      sqlCondition = "";
      ftsCondition = null;
      sqlOrderBy   = "";
      base.Joins.Clear();
      rootContext  = new QueryCompilerRefContext();
      joinContext  = new QueryCompilerJoinContext();
      nextAliasNumber = 1;
      translationCulture = session.Culture;
      try {
        Tokenize();
        int i = 0;
        ParseSelect(ref i);
        if (tokenTypes[i]!=TokenType.EOF)
          throw NewInvalidOqlException(new string[] {" "},i+1);
        BuildCommand(sqlCondition, ftsCondition, sqlOrderBy, pageInformation);
      }
      finally {
        tokens     = null;
        csTokens   = null;
        parts      = null;
        tokenTypes = null;
        tokensLength = 0;
        rootContext= null;
        joinContext= null;
      }
    }
    
    /// <summary>
    /// Updates the text of the command (basically to
    /// reflect changes in the Options collection).
    /// </summary>
    protected override void UpdateTranslation()
    {
      UpdateCommand(sqlCondition, ftsCondition, sqlOrderBy, pageInformation);
    }

    /// <summary>
    /// Creates <see cref="SqlQuery"/> that performs the
    /// same query as this instance.
    /// </summary>
    /// <returns><see cref="SqlQuery"/> that performs the
    /// same query as this instance.</returns>
    public SqlQuery CreateSqlQuery()
    {
      Translate();
      SqlQuery q = new SqlQuery(session);
      q.FieldCulture = FieldCulture;
      if (Field!=null)
        q.Field = Field;
      else
        q.InstanceType = InstanceType;
      q.Top       = base.Top;
      q.Condition = sqlCondition;
      if (ftsCondition!=null)
        q.FtsCondition = ftsCondition;
      q.OrderBy   = sqlOrderBy;
      foreach (SqlJoin join in base.Joins)
        q.Joins.Add(join.Clone());
      q.Options = base.Options;
      foreach (QueryParameter p in Parameters)
        q.Parameters.Add(p.Clone());
      return q;
    }
    

    // Parser

    private string[]    tokens;
    private string[]    csTokens;
    private string[]    parts;
    private TokenType[] tokenTypes;
    int                 tokensLength;
    
    private Exception NewInvalidOqlException(string message, int badPart)
    {
      StringBuilder sb = new StringBuilder();
      sb.Append("Invalid OQL expression ("+message+"): \"");
      int i = 0; 
      int l = parts.Length-1;
      for (; (i<badPart && i<l); i++)
        sb.Append(parts[i]);
      sb.Append("[Error]");
      for (; i<l; i++)
        sb.Append(parts[i]);
      sb.Append("\".");
      return new InvalidOqlException(sb.ToString());
    }

    private Exception NewInvalidOqlException(string[] stopTokens, int badPart)
    {
      string text = "";
      foreach (string s in stopTokens) {
        if (s==" ")
          text += " \\ EOF";
        else
          text += " \\ '"+s+"'";
      }
      text += " expected";
      return NewInvalidOqlException(text.Substring(3), badPart);
    }

    private void Tokenize()
    {
      int i = 0, j, m;
      int l = text.Length;
      string    token;
      ArrayList aTokens   = new ArrayList();
      ArrayList aCsTokens = new ArrayList();
      ArrayList aParts    = new ArrayList();
      ArrayList aTT       = new ArrayList();
//      bool bSquareBrackets = session.driverInfo.SupportsSquareBrackets;
      
      while (i<text.Length) {
        m = i;
        while (i<l && Char.IsWhiteSpace(text, i))
          i++;
        if (i>=l)
          break;
        if (text[i]=='\'') {
          j = i;
          while (true) {
            if (++i>=l)
              throw new InvalidOqlException("' expected", text, i);
            if (text[i]=='\'') {
              if (++i>=l)
                break;
              if (text[i]!='\'')
                break;
            }
          }
          token = text.Substring(j, i-j);
          aTT.Add(TokenType.String);
          aCsTokens.Add(token);
          aTokens.Add(token.ToLower());
          aParts.Add(text.Substring(m, i-m));
          continue;
        }
        else if (text[i]=='"') {
          j = i;
          while (true) {
            if (++i>=l)
              throw new InvalidOqlException("\" expected", text, i);
            if (text[i]=='"') {
              i++;
              break;
            }
          }
          token = text.Substring(j, i-j);
          aTT.Add(TokenType.QuotedIdentifier);
          aCsTokens.Add(token);
          aTokens.Add(token.ToLower());
          aParts.Add(text.Substring(m, i-m));
          continue;
        }
//        else if (bSquareBrackets && text[i]=='[' ) {
//          j = i;
//          while (true) {
//            if (++i>=l)
//              throw new InvalidOqlException("']' expected", text, i);
//            if (text[i]==']') {
//              i++;
//              break;
//            }
//          }
//          token = text.Substring(j, i-j);
//          aTT.Add(TokenType.QuotedIdentifier);
//          aCsTokens.Add(token);
//          aTokens.Add(token.ToLower());
//          aParts.Add(text.Substring(m, i-m));
//          continue;
//        }
        else if (Char.IsLetter(text, i) || text[i]=='_') {
          j = i;
          while (i<l && (Char.IsLetterOrDigit(text, i) || text[i]=='_'))
            i++;
          token = text.Substring(j, i-j);
          aTT.Add(TokenType.Identifier);
          aCsTokens.Add(token);
          aTokens.Add(token.ToLower());
          aParts.Add(text.Substring(m, i-m));
          continue;
        }
        else if (Char.IsDigit(text, i)) {
          j = i;
          while (i<l && (Char.IsDigit(text, i)))
            i++;
          token = text.Substring(j, i-j);
          aTT.Add(TokenType.Number);
          aCsTokens.Add(token);
          aTokens.Add(token.ToLower());
          aParts.Add(text.Substring(m, i-m));
          continue;
        }
        else {
          j = i;
          i++;
          if (i<l) {
            if (text[j]=='{' && text[i]=='{')
              i++;
            if (text[j]=='}' && text[i]=='}')
              i++;
          }
          token = text.Substring(j, i-j);
          aTT.Add(TokenType.Char);
          aCsTokens.Add(token.Substring(0,1));
          aTokens.Add(token.ToLower());
          aParts.Add(text.Substring(m, j+1-m));
          continue;
        }
      }
      aTokens.Add(" ");
      aCsTokens.Add(" ");
      aParts.Add(" ");
      aTT.Add(TokenType.EOF);
      tokens     = (string[])aTokens.ToArray(typeof(string));
      csTokens   = (string[])aCsTokens.ToArray(typeof(string));
      parts      = (string[])aParts.ToArray(typeof(string));
      tokenTypes = (TokenType[])aTT.ToArray(typeof(TokenType));
      tokensLength = tokens.Length;
    }

    private void ParseSelect(ref int i)
    {
      int lastI = i;
      if (tokens[i]!="select")
        throw NewInvalidOqlException(new string[] {"Select"}, i);
      i++;

      bool bDistinct = false;
      bool bCount    = false;

      if (tokens[i]=="count")
      {
        bCount = true;
        i++;
      }

      if (tokens[i]=="distinct")
      {
        bDistinct = true;
        i++;
      }

      if (tokens[i]=="top") 
      {
        i++;
        try {
          base.Top = long.Parse(csTokens[i]);
        }
        catch {
          throw NewInvalidOqlException("positive integer number expected", i);
        }
        if (base.Top<=0)
          throw NewInvalidOqlException("positive integer number expected", i);
        i++;
      }
      else
        base.Top = 0;

      ObjectModel.Type castType = null;
      if (tokens[i]=="(")
        castType = ParseCast(ref i);

      ObjectModel.Type oType = null;
      ICollectionField cField = null;
      Field   field = null;
      Culture fieldCulture = null;
      Utils   utils = session.utils;
      SqlJoin join1 = null;
      SqlJoin join2 = null;

      int typeI = i;
      string fullName = ParseTypeAndFieldName(ref i);

      switch (tokens[i])
      {
        case "objects":
        case "instances": 
      CaseObjects:
        {
          oType = session.types.FindByShortName(fullName);
          if (oType==null) {
            GetTypeAndField(fullName, typeI, ref oType, ref field, ref fieldCulture);
            if (field==null)
              throw NewInvalidOqlException(String.Format(
                "unknown type\field: {0}", fullName), typeI);
            if (!field.IsRootField && field.ContainerField is DataObjectCollectionField)
              field = field.ContainerField;
            if (!(field is ReferenceField) &&
                !(field is DataObjectCollectionField))
              throw NewInvalidOqlException(String.Format(
                "{0} isn't allowed here, allowed field types are " + 
                "ReferenceField and DataObjectCollectionField", field.GetType().Name), typeI);
            IReferenceHolderField rhf = field as IReferenceHolderField;
            oType = session.types[rhf.ReferedType];
          }
          
          if (castType!=null)
            base.ObjectModelType = CheckCast(oType, castType, typeI);
          else
            base.ObjectModelType = oType;
            
          if (field!=null) {
            Field rf = field.RootField;
            if (field is DataObjectCollectionField) {
              cField = field as ICollectionField;
              if ((field as DataObjectCollectionField).PairTo is ReferenceField) {
                // Joining collection table
                ObjectModel.TypeCollection types = Domain.ObjectModel.Types;
                ObjectModel.Type iType = types[((DataObjectCollectionField)field).ItemType];
                join1           = new SqlJoin();
                join1.joinType  = SqlJoinType.Inner;
                join1.tableName = iType.RelatedView.Name;
                join1.alias     = GetNextAlias();
                join1.condition = utils.QuoteDoubleIdentifier(RootName, session.dataObjectIDColumn.Name)+"="+
                                  utils.QuoteDoubleIdentifier(join1.alias, cField.GetItemIdColumnName(fieldCulture));
                base.Joins.Add(join1);
                join2 = join1; // Owners already joined
              } else {
                // Joining collection table
                join1           = new SqlJoin();
                join1.joinType  = SqlJoinType.Inner;
                join1.tableName = cField.GetTableName(fieldCulture);
                join1.alias     = GetNextAlias();
                join1.condition = utils.QuoteDoubleIdentifier(RootName, session.dataObjectIDColumn.Name)+"="+
                                  utils.QuoteDoubleIdentifier(join1.alias, cField.GetItemIdColumnName(fieldCulture));
                base.Joins.Add(join1);
                // Joining collection owners
                join2           = new SqlJoin();
                join2.joinType  = SqlJoinType.Inner;
                join2.tableName = field.Type.RelatedView.Name;
                join2.alias     = GetNextAlias();
                join2.condition = utils.QuoteDoubleIdentifier(join1.alias, cField.GetOwnerIdColumnName(fieldCulture))+"="+
                                  utils.QuoteDoubleIdentifier(join2.alias, session.dataObjectIDColumn.Name);
                base.Joins.Add(join2);
              }
              JoinContext_Add("rootOwner", new QueryCompilerRefLayer(field.Type, join2.alias));
              JoinContext_Add("root",      new QueryCompilerRefLayer(base.ObjectModelType, RootName));
              rootContext.Push(JoinContext_Get("rootOwner"));
              rootContext.Push(JoinContext_Get("root"));
            }
            else if (rf is ValueTypeCollectionField) {
              cField = rf as ICollectionField;
              // Joining collection table
              join1           = new SqlJoin();
              join1.joinType  = SqlJoinType.Inner;
              join1.tableName = cField.GetTableName(fieldCulture);
              join1.alias     = GetNextAlias();
              join1.condition = utils.QuoteDoubleIdentifier(RootName, session.dataObjectIDColumn.Name)+"="+
                                utils.QuoteDoubleIdentifier(join1.alias, field.AbsoluteDbName);
              base.Joins.Add(join1);
              // Joining collection owners
              join2           = new SqlJoin();
              join2.joinType  = SqlJoinType.Inner;
              join2.tableName = rf.Type.RelatedView.Name;
              join2.alias     = GetNextAlias();
              join2.condition = utils.QuoteDoubleIdentifier(join1.alias, cField.GetOwnerIdColumnName(fieldCulture))+"="+
                                utils.QuoteDoubleIdentifier(join2.alias, session.dataObjectIDColumn.Name);
              base.Joins.Add(join2);
              JoinContext_Add("rootItemOwner", new QueryCompilerRefLayer(rf.Type, join2.alias));
              JoinContext_Add("rootOwner",     new QueryCompilerRefLayer(rf.Type, join2.alias));
              JoinContext_Add("rootItem",      new QueryCompilerRefLayer(rf, fieldCulture, join1.alias));
              JoinContext_Add("root",          new QueryCompilerRefLayer(base.ObjectModelType, RootName));
              rootContext.Push(JoinContext_Get("rootItemOwner"));
              rootContext.Push(JoinContext_Get("rootItem"));
              rootContext.Push(JoinContext_Get("root"));
            }
            else { // field is ReferenceField
              // Joining reference owners
              int fieldCultureIndex = ((field.Translatable || field.Collatable) && fieldCulture!=null) ? fieldCulture.Index : 0;
              join1           = new SqlJoin();
              join1.joinType  = SqlJoinType.Inner;
              join1.tableName = field.Type.RelatedView.Name;
              join1.alias     = GetNextAlias();
              join1.condition = utils.QuoteDoubleIdentifier(RootName, session.dataObjectIDColumn.Name)+"="+
                                utils.QuoteDoubleIdentifier(join1.alias, field.RelatedColumns[fieldCultureIndex].Name);
              base.Joins.Add(join1);
              JoinContext_Add("rootOwner", new QueryCompilerRefLayer(field.Type, join1.alias));
              JoinContext_Add("root",      new QueryCompilerRefLayer(base.ObjectModelType, RootName));
              rootContext.Push(JoinContext_Get("rootOwner"));
              rootContext.Push(JoinContext_Get("root"));
            }
          }
          else {
            JoinContext_Add("root", new QueryCompilerRefLayer(base.ObjectModelType, RootName));
            rootContext.Push(JoinContext_Get("root"));
          }
          break;
        }

        case "values": 
        {
          GetTypeAndField(fullName, typeI, ref oType, ref field, ref fieldCulture);
          if (!field.IsRootField && field.ContainerField is DataObjectCollectionField)
            field = field.ContainerField;
          if (!field.IsRootField && field.ContainerField is ValueTypeCollectionField)
            field = field.ContainerField;
          
          ObjectModel.Field rf = field.RootField;
          cField = rf as ICollectionField;

          oType = ObjectModelType; // Required!
          if (castType!=null)
            throw NewInvalidOqlException("cast is not allowed for QueryResultType.Values queries", typeI);

          base.Field = field;
          base.FieldCulture = fieldCulture;

          if (rf is DataObjectCollectionField) {
            IReferenceHolderField rhf = rf as IReferenceHolderField;
            ObjectModel.Type rType = session.types[rhf.ReferedType];
            // Joining collection items
            join1           = new SqlJoin();
            join1.joinType  = SqlJoinType.Inner;
            join1.tableName = rType.RelatedView.Name;
            join1.alias     = GetNextAlias();
            join1.condition = utils.QuoteDoubleIdentifier(RootName, cField.GetItemIdColumnName(fieldCulture))+"="+
                              utils.QuoteDoubleIdentifier(join1.alias, session.dataObjectIDColumn.Name);
            base.Joins.Add(join1);
            // Joining collection owners
            join2           = new SqlJoin();
            join2.joinType  = SqlJoinType.Inner;
            join2.tableName = rf.Type.RelatedView.Name;
            join2.alias     = GetNextAlias();
            join2.condition = utils.QuoteDoubleIdentifier(RootName, cField.GetOwnerIdColumnName(fieldCulture))+"="+
                              utils.QuoteDoubleIdentifier(join2.alias, session.dataObjectIDColumn.Name);
            base.Joins.Add(join2);
            JoinContext_Add("rootOwner", new QueryCompilerRefLayer(rf.Type, join2.alias));
            JoinContext_Add("root",      new QueryCompilerRefLayer(rType,   join1.alias));
            rootContext.Push(JoinContext_Get("rootOwner"));
            rootContext.Push(JoinContext_Get("root"));
          }
          else if (rf is ValueTypeCollectionField) {
            // Joining collection owners
            join1           = new SqlJoin();
            join1.joinType  = SqlJoinType.Inner;
            join1.tableName = rf.Type.RelatedView.Name;
            join1.alias     = GetNextAlias();
            join1.condition = utils.QuoteDoubleIdentifier(RootName, cField.GetOwnerIdColumnName(fieldCulture))+"="+
                              utils.QuoteDoubleIdentifier(join1.alias, session.dataObjectIDColumn.Name);
            base.Joins.Add(join1);
            JoinContext_Add("rootItemOwner", new QueryCompilerRefLayer(rf.Type, join1.alias));
            JoinContext_Add("rootOwner",     new QueryCompilerRefLayer(rf.Type, join1.alias));
            JoinContext_Add("rootItem",      new QueryCompilerRefLayer(rf, fieldCulture, RootName));
            JoinContext_Add("root",          new QueryCompilerRefLayer(rf, fieldCulture, RootName));
            rootContext.Push(JoinContext_Get("rootItemOwner"));
            rootContext.Push(JoinContext_Get("root"));
          }
          else { // rf is any other field
            JoinContext_Add("root", new QueryCompilerRefLayer(base.ObjectModelType, RootName));
            rootContext.Push(JoinContext_Get("root"));
          }
          break;
        }

        default:
          i--;
          goto CaseObjects;
      }
      i++;
      
      if (tokens[i]=="as" || tokens[i]=="$") {
        if (tokens[i]!="$") {
          i++;
          if (tokens[i]!="$")
            throw NewInvalidOqlException(new string[] {"$"}, i);
        }
        i++;
        string aliasName = csTokens[i];
        if (tokenTypes[i]==TokenType.QuotedIdentifier)
          aliasName = GetUnquotedIdentifier(aliasName);
        if (aliasName=="")
          throw NewInvalidOqlException("invalid alias name", i);
        if (JoinContext_Get(aliasName)!=null)
          throw NewInvalidOqlException(String.Format(
            "alias name already in use: {0}", aliasName), i);
        i++;
        JoinContext_Add(aliasName, JoinContext_Get("root"));
      }

      ApplyRestrictions();

      if (tokens[i]=="with") {
        lastI = i;
        i++;
        if (tokens[i]=="options")
          i++;
        string freeOpt = "";
        base.Options = ParseWithOptions(ref i, ref freeOpt);
        base.FreeOptions = freeOpt;

      }
      else
        base.Options = QueryOptions.Default;

      if (bCount)
        base.Options |= QueryOptions.Count;
      if (bDistinct)
        base.Options |= QueryOptions.Distinct;

      ParseJoins(ref i);

      if (tokens[i]=="where")
      {
        lastI = i;
        i++;
        sqlCondition = ParseWhere(ref i).Trim();
        if (sqlCondition=="")
          throw NewInvalidOqlException("empty 'where' clause", i);
      }
      else
        sqlCondition = "";

      if (tokens[i]=="textsearch") {
        lastI = i;
        i++;
        ftsCondition = ParseTextSearch(ref i, oType);
      }
      else
        ftsCondition = null;

      if (tokens[i]=="order") {
        lastI = i;
        i++;
        if (tokens[i]!="by")
          throw NewInvalidOqlException(new string[] {"by"}, i);
        i++;
        sqlOrderBy = ParseOrderBy(ref i).Trim();
        if (sqlOrderBy=="" && (ftsCondition==null || !ftsCondition.OrderByRank))
          throw NewInvalidOqlException("empty 'order by' clause", i);
      }
      else
        sqlOrderBy = "";

      if (tokens[i]!=" ") {
        // Simply an extended error info
        if (tokens[lastI]=="select")
          throw NewInvalidOqlException(
            new string[] {"with","inner join","left join","require","let","where","textsearch","order by"," "}, i);
        if (tokens[lastI]=="with")
          throw NewInvalidOqlException(
            new string[] {"inner join","left join","require","let","where","textsearch","order by"," "}, i);
        if (tokens[lastI]=="require" ||
            tokens[lastI]=="inner" ||
            tokens[lastI]=="let" ||
            tokens[lastI]=="left")
          throw NewInvalidOqlException(
            new string[] {"inner join","left join","require","let","where","textsearch","order by"," "}, i);
        if (tokens[lastI]=="where")
          throw NewInvalidOqlException(
            new string[] {"textsearch","order by"," "}, i);
        if (tokens[lastI]=="textsearch")
          throw NewInvalidOqlException(
            new string[] {"order by"," "}, i);
        if (tokens[lastI]=="order")
          throw NewInvalidOqlException(
            new string[] {" "}, i);
        throw NewInvalidOqlException(
          new string[] {" "}, i);
      }
    }
    
    private void ApplyRestrictions()
    {
      Utils utils = session.utils;

      int cnt = QueryRestrictions.Count;
      for (int i = 0; i<cnt; i++) {
        QueryRestriction r = QueryRestrictions[i];
        if (r is DataObjectCollectionQueryRestriction) {
          DataObjectCollectionQueryRestriction cr = 
            r as DataObjectCollectionQueryRestriction;

//          ObjectModel.Type cType = cr.CollectionField.Type;
//          if (cType!=type) {
//            if (cType.IsInterface) {
//              if (!type.Interfaces.Contains(cType))
//                continue;
//            }
//            else {
//              if (!type.BaseTypes.Contains(cType))
//                continue;
//            }
//          }

          string cOwner = (cr.CollectionField as ICollectionField).GetOwnerIdColumnName(cr.Culture);
          string cItem  = (cr.CollectionField as ICollectionField).GetItemIdColumnName(cr.Culture);
          string aliasName = GetNextAlias();
          
          ISchemaNode table = (cr.CollectionField as ICollectionField).GetSchemaNode(cr.Culture);
          if (table is Table && ((Table)table).RelatedType!=null)
            table = ((Table)table).RelatedType.RelatedView;

          SqlJoin join   = new SqlJoin();
          join.joinType  = SqlJoinType.Inner;
          join.tableName = table.Name;
          join.alias     = aliasName;
          if (cr.DataObject!=null && cr.DataObject.State!=DataObjectState.Removed) {
            join.condition =
              utils.QuoteDoubleIdentifier(aliasName, cOwner)+"="+cr.DataObject.ID.ToString() +
              " and "+utils.QuoteDoubleIdentifier(aliasName, cItem)+"=" +
              utils.QuoteDoubleIdentifier(RootName, session.dataObjectIDColumn.Name);
          }
          else {
            join.condition =
              utils.QuoteDoubleIdentifier(aliasName, cItem)+"="+utils.QuoteDoubleIdentifier(RootName, session.dataObjectIDColumn.Name);
          }
          base.Joins.Add(join);
        }
        else
          throw new NotImplementedException(String.Format(
            "Inknown type of QueryRestriction: {0}.", r.GetType().FullName));
      }
    }

    private QueryOptions ParseWithOptions(ref int i, ref string freeOptions)
    {
      int initialI = i;
      if (tokens[i]!="(")
        throw NewInvalidOqlException(new string[] {"("}, i);
      i++;
      StringBuilder sb = new StringBuilder();
      while (true) {
        string token = tokens[i];
        if (token==")") {
          i++;
          if (sb.Length > 0)
          {
              try
              {
                  return (QueryOptions)Enum.Parse(typeof(QueryOptions), sb.ToString(), true);
              }
              catch
              {
                  throw NewInvalidOqlException("options expected", initialI + 1);
              }
          }
          else
              return QueryOptions.Default;
        }
        else if (token=="(")
          throw NewInvalidOqlException("'(' isn't allowed here", i);
        else if (token==" ")
          throw NewInvalidOqlException(new string[] {")"}, i);
        if (token.Length > 2 && token[0] == '\'' && token[token.Length - 1] == '\'') // free option
        {
            if (sb.Length > 0)
                sb.Remove(sb.Length - 1, 1);
            freeOptions = token.Substring(1, token.Length - 2);
        }
        else
            sb.Append(token);
        i++;
      }
    }

    private void ParseJoins(ref int i)
    {
      while (true) 
      {
        SqlJoinType joinType = SqlJoinType.Inner;
        switch (tokens[i])
        {
          case "inner":
            i++;
            if (tokens[i]!="join")
              throw NewInvalidOqlException(new string[] {"join"}, i);
            break;
          case "require":
            break;

          case "left":
            i++;
            if (tokens[i]=="outer")
              i++;
            if (tokens[i]!="join")
              throw NewInvalidOqlException(new string[] {"join"}, i);
            joinType = SqlJoinType.LeftOuter;
            break;
          case "let":
            joinType = SqlJoinType.LeftOuter;
            break;

          default:
            return;
        }
        i++;

        int joinI = i;
        ObjectModel.Type castType = null;
        if (tokens[i]=="(")
          castType = ParseCast(ref i);
        string fullName = ParseTypeAndFieldName(ref i);
        i = joinI;
        
        if (session.types.FindByShortName(fullName)!=null)
          ParseJoinType(ref i, rootContext.Clone(), joinType);
        else
          ParseJoinReference(ref i, rootContext.Clone(), joinType);
      }
    }

    private void ParseJoinType(ref int i, QueryCompilerRefContext context, SqlJoinType joinType)
    {
      Utils utils = session.utils;

      int typeI = i;
      ObjectModel.Type castType = null;
      if (tokens[i]=="(")
        castType = ParseCast(ref i);
        
      string joinName = null;
      string fullName = ParseTypeAndFieldName(ref i);
      ObjectModel.Type oType = GetType(fullName, i);
      oType = CheckCast(oType, castType, typeI);

      if (tokens[i]=="as" || tokens[i]=="$") {
        if (tokens[i]!="$") {
          i++;
          if (tokens[i]!="$")
            throw NewInvalidOqlException(new string[] {"$"}, i);
        }
        i++;
        joinName = csTokens[i];
        if (tokenTypes[i]==TokenType.QuotedIdentifier)
          joinName = GetUnquotedIdentifier(joinName);
        if (joinName=="")
          throw NewInvalidOqlException("invalid join name", i);
        if (JoinContext_Get(joinName)!=null)
          throw NewInvalidOqlException(String.Format(
            "join name already in use: {0}", joinName), i);
        i++;
      }
      else 
        throw NewInvalidOqlException(new string[] {"as","$"}, i);

      if (tokens[i]!="on")
        throw NewInvalidOqlException(new string[] {"on"}, i);
      i++;
      if (tokens[i]!="(")
        throw NewInvalidOqlException(new string[] {"("}, i);
      i++;

      QueryCompilerRefLayer joinLayer = new QueryCompilerRefLayer(oType, GetNextAlias());
      JoinContext_Add(joinName, joinLayer);

      SqlJoin join   = new SqlJoin();
      join.joinType  = joinType;
      join.tableName = oType.RelatedView.Name;
      join.alias     = joinLayer.Alias;
      join.condition = ParseExpression(ref i, parseJoinExpressionStopTokens, context);
      base.Joins.Add(join);

      i++; // To skip ')'
    }
    
    private void ParseJoinReference(ref int i, QueryCompilerRefContext context, SqlJoinType joinType)
    {
      Utils utils = session.utils;

      ObjectModel.Type castType = null;
      if (tokens[i]=="(")
        castType = ParseCast(ref i);

      if (tokens[i-1]!="." && tokens[i]=="$") 
      { // Alias
        if (castType!=null)
          throw NewInvalidOqlException("alias cast is not allowed", i);

        i++;
        string joinAliasName = csTokens[i];
        if (tokenTypes[i]==TokenType.QuotedIdentifier)
          joinAliasName = GetUnquotedIdentifier(joinAliasName);
        i++;
          
        QueryCompilerRefLayer joinLayer = JoinContext_Get(joinAliasName);
        if (joinLayer==null)
          throw NewInvalidOqlException(String.Format("unknow alias: ${0}", joinAliasName), i-1);

        if (tokens[i]!=".")
          throw NewInvalidOqlException(new string[] {"."}, i);
        i++;

        context.Push(joinLayer);
        ParseJoinReference(ref i, context, joinType);
        return;
      }

      Field           field = null;
      Culture  fieldCulture = null; 
      ParseFieldReference(ref i, context.TopEntry, ref field, ref fieldCulture);

      IReferenceHolderField rhf = field as IReferenceHolderField;
      ICollectionField   cField = field as ICollectionField;
      SqlJoin join1 = null;
      SqlJoin join2 = null;
      string tmpLayerName = null;

      if (field is ReferenceField)
      {
        ObjectModel.Type rType = CheckCast(session.types[rhf.ReferedType], castType, i);
        
        int fieldCultureIndex = ((field.Translatable || field.Collatable) && fieldCulture!=null) ? fieldCulture.Index : 0;
        join1           = new SqlJoin();
        join1.joinType  = joinType;
        join1.tableName = rType.RelatedView.Name;
        join1.alias     = GetNextAlias();
        join1.condition = GetEntryColumnName(context.TopEntry, field.RelatedColumns[fieldCultureIndex].Name)+"="+
                          utils.QuoteDoubleIdentifier(join1.alias, session.dataObjectIDColumn.Name);
        base.Joins.Add(join1);

        QueryCompilerRefLayer joinLayer = new QueryCompilerRefLayer(rType, join1.Alias);
        tmpLayerName = JoinContext_Add(joinLayer);
        context.Push(joinLayer);

        if (tokens[i]=="[") 
        { // Expression
          i++;
          join1.condition += 
            " and ("+ParseExpression(ref i, parseSubqueryExpressionStopTokens, context)+")";
          i++; // To skip stopToken "]"
        }

        if (tokens[i]==".") { // Drill down to item
          i++;
          ParseJoinReference(ref i, context, joinType);
          return;
        }
      }
      else if (field is DataObjectCollectionField) 
      {
        ObjectModel.Type rType = CheckCast(session.types[rhf.ReferedType], castType, i);

        if (castType==null && 
           ((field as DataObjectCollectionField).PairTo is ReferenceField)) {
          // Joining instances table
          ObjectModel.TypeCollection types = Domain.ObjectModel.Types;
          ObjectModel.Type iType = types[((DataObjectCollectionField)field).ItemType];
          join1           = new SqlJoin();
          join1.joinType  = joinType;
          join1.tableName = iType.RelatedView.Name;
          //join1.tableName = field.Type.RelatedView.Name;
          join1.alias     = GetNextAlias();
          join1.condition = GetEntryIDColumnName(context.TopEntry)+"="+
            utils.QuoteDoubleIdentifier(join1.alias, cField.GetOwnerIdColumnName(fieldCulture));
          base.Joins.Add(join1);
          join2 = join1;
          QueryCompilerRefLayer joinLayer = new QueryCompilerRefLayer(rType, join2.Alias);
          tmpLayerName = JoinContext_Add(joinLayer);
          context.Push(joinLayer);
        } else {
          // Joining instances table
          join1           = new SqlJoin();
          join1.joinType  = joinType;
          join1.tableName = cField.GetTableName(fieldCulture);
          join1.alias     = GetNextAlias();
          join1.condition = GetEntryIDColumnName(context.TopEntry)+"="+
            utils.QuoteDoubleIdentifier(join1.alias, cField.GetOwnerIdColumnName(fieldCulture));
          base.Joins.Add(join1);
          // Joining collection items
          join2           = new SqlJoin();
          join2.joinType  = SqlJoinType.LeftOuter;
          join2.tableName = rType.RelatedView.Name;
          join2.alias     = GetNextAlias();
          join2.condition = utils.QuoteDoubleIdentifier(join1.alias, cField.GetItemIdColumnName(fieldCulture))+"="+
                            utils.QuoteDoubleIdentifier(join2.alias, session.dataObjectIDColumn.Name);
          base.Joins.Add(join2);
          QueryCompilerRefLayer joinLayer = new QueryCompilerRefLayer(rType, join2.Alias, join1.Alias, field as DataObjectCollectionField);
          tmpLayerName = JoinContext_Add(joinLayer);
          context.Push(joinLayer);
        }


        if (tokens[i]=="[")
        { // Expression
          i++;
          join2.condition += 
            " and ("+ParseExpression(ref i, parseSubqueryExpressionStopTokens, context)+")";
          i++; // To skip stopToken "]"
        }

        if (tokens[i]==".") { // Drill down to item
          i++;
          if (tokens[i]!=itemToken)
            throw NewInvalidOqlException(new string[] {itemToken}, i);
          i++;
          if (tokens[i]==".") { // Drill down more
            i++;
            ParseJoinReference(ref i, context, joinType);
            return;
          }
        }
      }
      else if (field is ValueTypeCollectionField) 
      {
        if (castType!=null)
          throw NewInvalidOqlException("ValueTypeCollection cast is not allowed", i);

        // Joining collection table
        join1           = new SqlJoin();
        join1.joinType  = joinType;
        join1.tableName = cField.GetTableName(fieldCulture);
        join1.alias     = GetNextAlias();
        join1.condition = GetEntryIDColumnName(context.TopEntry)+"="+
                          utils.QuoteDoubleIdentifier(join1.alias, cField.GetOwnerIdColumnName(fieldCulture));
        base.Joins.Add(join1);

        QueryCompilerRefLayer joinLayer = new QueryCompilerRefLayer(field, fieldCulture, join1.Alias);
        tmpLayerName = JoinContext_Add(joinLayer);
        context.Push(joinLayer);

        if (tokens[i]=="[")
        { // Expression
          i++;
          join1.condition += 
            " and ("+ParseExpression(ref i, parseSubqueryExpressionStopTokens, context)+")";
          i++; // To skip stopToken "]"
        }

        if (tokens[i]==".") { // Drill down to item
          i++;
          if (tokens[i]!=itemToken)
            throw NewInvalidOqlException(new string[] {itemToken}, i);
          i++;
          if (tokens[i]==".") { // Drill down more
            i++;
            ParseJoinReference(ref i, context, joinType);
            return;
          }
        }
      }
      else
        throw NewInvalidOqlException("unsupported join type", i);

      if (tokens[i]=="as" || tokens[i]=="$") {
        if (tokens[i]!="$") {
          i++;
          if (tokens[i]!="$")
            throw NewInvalidOqlException(new string[] {"$"}, i);
        }
        i++;
        string joinName = csTokens[i];
        if (tokenTypes[i]==TokenType.QuotedIdentifier)
          joinName = GetUnquotedIdentifier(joinName);
        if (joinName=="")
          throw NewInvalidOqlException("invalid join name", i);
        if (JoinContext_Get(joinName)!=null)
          throw NewInvalidOqlException(String.Format(
            "join name already in use: {0}", joinName), i);
        i++;
        JoinContext_Rename(tmpLayerName, joinName);
      }
      
      if (tokens[i]=="on") {
        i++;
        if (tokens[i]!="(")
          throw NewInvalidOqlException(new string[] {"("}, i);
        i++;

        if (join2!=null)
          join2.condition += 
            " and ("+ParseExpression(ref i, parseJoinExpressionStopTokens, rootContext.Clone())+")";
        else if (join1!=null)
          join1.condition += 
            " and ("+ParseExpression(ref i, parseJoinExpressionStopTokens, rootContext.Clone())+")";
        else
          throw NewInvalidOqlException("'on' is not allowed for this type of join", i-2);

        i++; // To skip ')'
      }
    }

    private string ParseWhere(ref int i)
    {
      return ParseExpression(ref i, parseWhereStopTokens, rootContext.Clone());
    }
    
    private string ParseExpression(ref int i, string[] stopTokens, QueryCompilerRefContext context)
    {
      StringBuilder sb = new StringBuilder(64);
      StringCollection brStack = new StringCollection();
      Utils utils = session.utils;
      while (true) {
        string token = tokens[i];
        if (brStack.Count==0)
          for (int j = 0; j<stopTokens.Length; j++)
            if (token==stopTokens[j])
              return sb.ToString();
        switch (token) {
        case " ":
          if (brStack.Count>0)
            throw NewInvalidOqlException(new string[] {brStack[brStack.Count-1]}, i);
          else
            throw NewInvalidOqlException(stopTokens, i);
        case "{":
          sb.Append(parts[i].Substring(0,parts[i].Length-1));
          sb.Append("(");
          QueryCompilerRefContext newContext = new QueryCompilerRefContext(context);

          i++;
          bool bProcess = true;
          if (tokens[i]=="this") {
            i++;
            if (newContext.TopEntry.Type==null)
              newContext.Pop();
            if (tokens[i]!=".") {
              sb.Append(GetEntryIDColumnName(newContext.TopEntry));
              bProcess = false;
            }
            else {
              i++;
              while (tokens[i]=="parent") {
                if (newContext.Count<=1)
                  throw NewInvalidOqlException("parent isn't available in this context", i);
                i++;
                newContext.Pop();
                if (tokens[i]!=".") {
                  sb.Append(GetEntryIDColumnName(newContext.TopEntry));
                  bProcess = false;
                  break;
                }
                else
                  i++;
              }
            }
          }
          else if (tokens[i]=="root") {
            i++;
            newContext.PopToLevel(rootContext.Count);
            if (tokens[i]!=".") {
              sb.Append(GetEntryIDColumnName(newContext.TopEntry));
              bProcess = false;
            }
            else {
              i++;
              while (tokens[i]=="parent") {
                if (newContext.Count<=1)
                  throw NewInvalidOqlException("parent isn't available in this context", i);
                i++;
                newContext.Pop();
                if (tokens[i]!=".") {
                  sb.Append(GetEntryIDColumnName(newContext.TopEntry));
                  bProcess = false;
                  break;
                }
                else
                  i++;
              }
            }
          }
          else if (tokens[i]=="fulltextrank") {
            sb.Append("{FullTextRank}");
            bProcess = false;
            i++;
          }
          else {
            while (tokens[i]=="parent") {
              if (newContext.Count<=1)
                throw NewInvalidOqlException("parent isn't available in this context", i);
              i++;
              newContext.Pop();
              if (tokens[i]!=".") {
                sb.Append(GetEntryIDColumnName(newContext.TopEntry));
                bProcess = false;
                break;
              }
              else
                i++;
            }
          }
          if (bProcess)
            sb.Append(ParseSubquery(ref i, newContext, true));
          sb.Append(")");
          if (tokens[i]!="}")
            throw NewInvalidOqlException(new string[] {"}"},i);
          break;
//        case "[":
//          // Skip
//          int sbrCnt = 1;
//          while (sbrCnt!=0) {
//            sb.Append(parts[i]);
//            i++;
//            switch (tokens[i]) {
//            case "[":
//              sbrCnt++;
//              break;
//            case "]":
//              sbrCnt--;
//              break;
//            case " ":
//              throw NewInvalidOqlException(new string[] {"}"},i);
//            }
//          }
//          sb.Append(parts[i]);
//          break;
        case "(":
          brStack.Add(")");
          sb.Append(parts[i]);
          break;
        case "[":
          brStack.Add("]");
          sb.Append(parts[i]);
          break;
        case ")":
        case "]":
          int brLast = brStack.Count-1;
          if (brLast<0 || brStack[brLast]!=token)
            throw NewInvalidOqlException("'"+token+"' isn't allowed here",i);
          brStack.RemoveAt(brLast);
          sb.Append(parts[i]);
          break;
        default:
          sb.Append(parts[i]);
          break;
        }
        i++;
      }
    }
    
    private string ParseSubquery(ref int i, QueryCompilerRefContext context, bool isFirst)
    {
      int initialI = i;
      Utils utils = session.utils;

      ObjectModel.Type castType = null;
      if (tokens[i]=="(")
        castType = ParseCast(ref i);
        
      if (isFirst && tokens[i]=="select") {
        StringBuilder sb = new StringBuilder();
        sb.Append("select");
        int cnt = 1;
        i++;
        while (i<tokens.Length && cnt>0) {
          if (tokens[i]=="}")
            cnt--;
          if (tokens[i]=="{")
            cnt++;
          if (cnt>0) {
            sb.Append(parts[i]);
            i++;
          }
        }
        
        if (cnt!=0) 
          throw NewInvalidOqlException(new string[] {"}"}, i);
        
        Query subQuery = new Query(session, sb.ToString(), true, this);
        string result = subQuery.GetCommandText();
        if (result.Length == 0 && subQuery.ftsCondition != null)
          result = ExecuteFtsQuery(subQuery.ftsCondition).ConvertToSqlInExpression(); 
      
                  
        context.Pop();
        return result;
      }

      if (isFirst && tokens[i]=="$")
      { // Alias
        if (castType!=null)
          throw NewInvalidOqlException("alias cast is not allowed", i);

        i++;
        string joinAliasName = csTokens[i];
        if (tokenTypes[i]==TokenType.QuotedIdentifier)
          joinAliasName = GetUnquotedIdentifier(joinAliasName);
        QueryCompilerRefLayer joinLayer = JoinContext_Get(joinAliasName);
        if (joinLayer==null)
          throw NewInvalidOqlException(String.Format("unknow alias: ${0}", joinAliasName), i-1);
        i++;

        context.Push(joinLayer);

        if (tokens[i]=="[") 
          throw NewInvalidOqlException("'[' is not allowed after alias", i);

        string result;
        if (tokens[i]==".") {
          i++;
          result = ParseSubquery(ref i, context, true);
        }
        else
          result = GetEntryIDColumnName(context.TopEntry);

        context.Pop();
        return result;
      }

      ObjectModel.Type type = context.TopEntry.Type;
      string          alias = context.TopEntry.Alias;
      Field           field = context.TopEntry.Field;
      Culture  fieldCulture = context.TopEntry.FieldCulture;
      int fieldCultureIndex = (field!=null && (field.Translatable || field.Collatable) && fieldCulture!=null) ? fieldCulture.Index : 0;
      string       aliasDef = utils.QuoteIdentifier(type!=null ? 
                                type.RelatedView.Name : 
                                field.RelatedViews[fieldCultureIndex].Name)+" "+
                              utils.QuoteIdentifier(alias);

      Field        curField   = null;
      Culture curFieldCulture = null;
      ParseFieldReference(ref i, context.TopEntry, ref curField, ref curFieldCulture);
      IReferenceHolderField curRhf = curField as IReferenceHolderField;
      ICollectionField       curCf = curField as ICollectionField;
      
      if (curField is ReferenceField) 
      { // ReferenceField
        ObjectModel.Type curFieldType = CheckCast(session.types[curRhf.ReferedType], castType, i);
        context.Push(new QueryCompilerRefLayer(curFieldType, GetNextAlias()));

        string condition = "";
        if (tokens[i]=="[") {
          i++;
          condition = ParseExpression(ref i, parseSubqueryExpressionStopTokens, context);
          i++; // To skip stopToken "]"
        }
        
        int curFieldCultureIndex = ((curField.Translatable || curField.Collatable) && curFieldCulture!=null) ? curFieldCulture.Index : 0;

        string result;
        
        if (isFirst && tokens[i]!="." && condition.Trim()=="") {
          result = 
            utils.QuoteDoubleIdentifier(alias, curField.RelatedColumns[curFieldCultureIndex].Name);
          context.Pop();
          return result;
        }
        
        if (tokens[i]==".") {
          i++;
          result = ParseSubquery(ref i, context, false);
        }
        else
          result = 
            "Select "+GetEntryIDColumnName(context.TopEntry)+
            " from "+utils.QuoteIdentifier(curFieldType.RelatedView.Name) +
            " "+utils.QuoteIdentifier(context.TopEntry.Alias);

        if (isFirst)
          result += " where ";
        else
          result += " inner join "+aliasDef+" on ";
        result += GetEntryIDColumnName(context.TopEntry)+"=" + 
                  utils.QuoteDoubleIdentifier(alias, curField.RelatedColumns[curFieldCultureIndex].Name);

        if (condition.Trim()!="")
          result += " and ("+condition+")";
        
        string qf = session.persister.CreateQueryFilter(utils.QuoteIdentifier(context.TopEntry.Alias));
        if (qf!=null && qf.Trim()!="")
          result += " and "+qf;

        context.Pop();
        return result;
      }
      else if (curField is DataObjectCollectionField) 
      { // DataObjectCollectionField
        ObjectModel.Type curFieldType = CheckCast(session.types[curRhf.ReferedType], castType, i);
        context.Push(new QueryCompilerRefLayer(curFieldType, GetNextAlias()));

        string condition = "";
        if (tokens[i]=="[") {
          i++;
          condition = ParseExpression(ref i, parseSubqueryExpressionStopTokens, context);
          i++; // To skip stopToken "]"
        }
        
        string result;
        if (tokens[i]==".") {
          i++;
          if (tokens[i]==itemToken) {
            i++;
            if (tokens[i]!=".")
              throw NewInvalidOqlException(new string[] {"."}, i);
            i++;
            result = ParseSubquery(ref i, context, false);
          }
          else if (tokens[i]=="count") {
            i++;
            result = "Select count(*) from " + 
                     utils.QuoteIdentifier(curFieldType.RelatedView.Name)+" "+
                     utils.QuoteIdentifier(context.TopEntry.Alias);
          }
          else if (tokens[i]=="expression" || tokens[i]=="expr") {
            i++;
            if (tokens[i]!="[")
              throw NewInvalidOqlException(new string[] {"["}, i);
            i++;
            string expression = ParseExpression(ref i, parseSubqueryExpressionStopTokens, context);
            i++; // To skip stopToken "]"
            result = "Select ("+expression+") from " +
                     utils.QuoteIdentifier(curFieldType.RelatedView.Name)+" "+
                     utils.QuoteIdentifier(context.TopEntry.Alias);
          }
          else
            throw NewInvalidOqlException(new string[] {itemToken,"count","expression"}, i);
        }
        else
          result = "Select "+GetEntryIDColumnName(context.TopEntry)+" from " +
                   utils.QuoteIdentifier(curFieldType.RelatedView.Name)+" "+
                   utils.QuoteIdentifier(context.TopEntry.Alias);

        if (!((curField as DataObjectCollectionField).PairTo is ReferenceField))
        { // Two tables\views
          string linkAlias = GetNextAlias();
          // See http://www.x-tensive.com/Forum/viewtopic.php?t=688
          // http://server:8888/DataObjects.NET/Lists/Tasks/DispForm.aspx?ID=75
          if (castType==null)
            result += " right join ";
          else
            result += " inner join ";
          result +=
            utils.QuoteIdentifier(curCf.GetTableName(curFieldCulture))+" " + 
            utils.QuoteIdentifier(linkAlias) +
            " on " +
            utils.QuoteDoubleIdentifier(linkAlias, curCf.GetItemIdColumnName(curFieldCulture))+"=" +
            GetEntryIDColumnName(context.TopEntry);
          
          string qf = session.persister.CreateQueryFilter(utils.QuoteIdentifier(linkAlias));
          if (qf!=null && qf.Trim()!="")
            result += " and "+qf;
          
          if (isFirst)
            result += " where ";
          else
            result += " inner join "+aliasDef+" on ";
          result += 
            GetEntryIDColumnName(context.PreTopEntry)+"=" + 
            utils.QuoteDoubleIdentifier(linkAlias, curCf.GetOwnerIdColumnName(curFieldCulture));
        }
        else
        { // Single table
          if (isFirst)
            result += " where ";
          else
            result += " inner join "+aliasDef+" on ";
          result += 
            GetEntryIDColumnName(context.PreTopEntry)+"=" + 
            utils.QuoteDoubleIdentifier(context.TopEntry.Alias, curCf.GetOwnerIdColumnName(curFieldCulture));
        }
        if (condition.Trim()!="")
          result += " and ("+condition+")";
          
        string qf1 = session.persister.CreateQueryFilter(utils.QuoteIdentifier(context.TopEntry.Alias));
        if (qf1!=null && qf1.Trim()!="")
          result += " and "+qf1;
          
        context.Pop();
        return result;
      }
      else if (curField is ValueTypeCollectionField)
      { // ValueTypeCollectionField
        if (castType!=null)
          throw NewInvalidOqlException("can't cast ValueTypeCollectionField", i);
        context.Push(new QueryCompilerRefLayer(curField, curFieldCulture, GetNextAlias()));

        string condition = "";
        if (tokens[i]=="[") 
        {
          i++;
          condition = ParseExpression(ref i, parseSubqueryExpressionStopTokens, context);
          i++; // To skip stopToken "]"
        }
        
        string result;
        if (tokens[i]==".") 
        {
          i++;
          if (tokens[i]==itemToken) {
            i++;
            if (tokens[i]!=".")
              throw NewInvalidOqlException(new string[] {"."}, i);
            i++;
            result = ParseSubquery(ref i, context, false);
          }
          else if (tokens[i]=="count") {
            i++;
            result = "Select count(*) from " +
                   utils.QuoteIdentifier(curCf.GetTableName(curFieldCulture))+" " + 
                   utils.QuoteIdentifier(context.TopEntry.Alias);
          }
          else if (tokens[i]=="expression" || tokens[i]=="expr") {
            i++;
            if (tokens[i]!="[")
              throw NewInvalidOqlException(new string[] {"["}, i);
            i++;
            string expression = ParseExpression(ref i, parseSubqueryExpressionStopTokens, context);
            i++; // To skip stopToken "]"
            result = "Select ("+expression+") from " +
                   utils.QuoteIdentifier(curCf.GetTableName(curFieldCulture))+" " + 
                   utils.QuoteIdentifier(context.TopEntry.Alias);
          }
          else
            throw NewInvalidOqlException(new string[] {itemToken,"count","expression"}, i);
        }
        else
          result = "Select "+
                     utils.QuoteDoubleIdentifier(context.TopEntry.Alias, curCf.GetItemIdColumnName(curFieldCulture))+" from " +
                   utils.QuoteIdentifier(curCf.GetTableName(curFieldCulture))+" " + 
                   utils.QuoteIdentifier(context.TopEntry.Alias);

        if (isFirst)
          result += " where ";
        else
          result += " inner join "+aliasDef+" on ";
        result += GetEntryIDColumnName(context.PreTopEntry)+"=" +
                  utils.QuoteDoubleIdentifier(context.TopEntry.Alias, curCf.GetOwnerIdColumnName(curFieldCulture));
        if (condition.Trim()!="")
          result += " and ("+condition+")";
          
        string qf = session.persister.CreateQueryFilter(utils.QuoteIdentifier(context.TopEntry.Alias));
        if (qf!=null && qf.Trim()!="")
          result += " and "+qf;

        context.Pop();
        return result;
      }
      else if (curField is PrimitiveField) 
      { // PrimitiveField
        if (castType!=null)
          throw NewInvalidOqlException("can't cast PrimitiveField", i);
        int curFieldCultureIndex = ((curField.Translatable || curField.Collatable) && curFieldCulture!=null) ? curFieldCulture.Index : 0;
        string columnName = utils.QuoteDoubleIdentifier(context.TopEntry.Alias, 
          curField.RelatedColumns[curFieldCultureIndex].Name);
        if (curField.Name == "ID" && context.TopEntry.CollectionField != null)
          columnName = utils.QuoteDoubleIdentifier(
            context.TopEntry.OwnerAlias, 
            context.TopEntry.CollectionField.GetItemIdColumnName(null));
        if (isFirst)
          return columnName;
        else
          return "Select "+columnName+" from "+aliasDef;
      }
      throw NewInvalidOqlException(
        "this type of field isn't supported here", initialI);
    }

    static string[] parseOrderByStopTokens = new string[] {" "};
    static string[] parseOrderByExpressionStopTokens = new string[] {",", "desc", "asc", ";", " "};
    private string ParseOrderBy(ref int i)
    {
      StringBuilder sb = new StringBuilder();
      string[] stopTokens = parseOrderByStopTokens;
      bool isFirst = true;
      while (true) {
        string token = tokens[i];
        for (int j = 0; j<stopTokens.Length; j++)
          if (token==stopTokens[j])
            return sb.ToString();
        if (token==" ")
          throw NewInvalidOqlException(stopTokens, i);
        if (token==",") {
          if (!isFirst) {
            if (sb.Length>0)
              sb.Append(parts[i]+" ");
            i++;
            token = tokens[i];
          }
          else
            throw NewInvalidOqlException("',' isn't allowed here", i);
        }
        string orderExpression = ParseExpression(ref i, parseOrderByExpressionStopTokens, rootContext.Clone()).Trim();
        string reducedOe = orderExpression.Trim();
        while (reducedOe.Length>=2) {
          if (reducedOe[0]=='(' && reducedOe[reducedOe.Length-1]==')')
            reducedOe = reducedOe.Substring(1,reducedOe.Length-2).Trim();
          else
            break;
        }
        if (reducedOe=="{FullTextRank}") {
          if (ftsCondition==null)
            throw NewInvalidOqlException("{FullTextRank} can be used only in combination with 'textsearch' clause", i);
          if (!isFirst)
            throw NewInvalidOqlException("{FullTextRank} can be used only on the first place in the 'order by' clause", i);
          if (tokens[i]=="asc")
            throw NewInvalidOqlException("only descending order is supported for {FullTextRank} expression", i);
          if (tokens[i]=="desc")
            i++;
          ftsCondition.orderByRank = true;
        }
        else {
          sb.Append("(");
          sb.Append(orderExpression);
          sb.Append(")");
          if (tokens[i]=="desc" || tokens[i]=="asc") {
            sb.Append(parts[i]);
            i++;
          }
        }
        isFirst = false;
      }
    }
    
    private FtsCondition ParseTextSearch(ref int i, ObjectModel.Type oType)
    {
      FtsMode mode = FtsMode.FreeText;
      Culture culture   = session.culture;
      string  condition = null;
      int     topByRank = 0;

      if (tokens[i]=="top") {
        i++;
        try {
          topByRank = int.Parse(csTokens[i]);
        }
        catch {
          throw NewInvalidOqlException("positive integer number expected", i);
        }
        if (topByRank<=0)
          throw NewInvalidOqlException("positive integer number expected", i);
        i++;
      }

      switch (tokens[i]) {
      case "freetext":
        mode = FtsMode.FreeText;
        i++;
        break;
      case "condition":
        mode = FtsMode.Condition;
        i++;
        break;
      case "likeexpression":
        mode = FtsMode.LikeExpression;
        i++;
        break;
      }

      if (tokenTypes[i]!=TokenType.String)
        throw NewInvalidOqlException("string constant (search expression) expected", i);
      condition = csTokens[i].Substring(1,csTokens[i].Length-2).Replace("''","'");
      i++;
      
      if (tokens[i]=="within") {
        i++;
        if (tokens[i]=="any") {
          i++;
          culture = null;
        }
        else if (tokenTypes[i]==TokenType.String) {
          string cultureName = csTokens[i].Substring(1,csTokens[i].Length-2).Replace("''","'");
          culture = session.domain.cultures[cultureName];
          if (culture==null)
            throw NewInvalidOqlException(String.Format(
              "unknown culture: {0}", cultureName), i);
          i++;
        }
        else
          throw NewInvalidOqlException("'any' or string constant (culture name) expected", i);
        if (tokens[i]!="culture")
          throw NewInvalidOqlException(
            new string[] {"culture"}, i);
        i++;
      }

      FtsCondition ftsc = new FtsCondition(oType, culture, mode, condition, topByRank);
      ftsc.session   = session;
      return ftsc;
    }

    private string ParseTypeAndFieldName(ref int i)
    {
      string typeName = csTokens[i];
      if (tokenTypes[i]==TokenType.QuotedIdentifier)
        typeName = GetUnquotedIdentifier(typeName);
      while (true) {
        char c = parts[++i][0];
#if DOTNET20
        if (c=='`') {
          typeName += parts[i];
          c = parts[++i][0];
          if (Char.IsLetterOrDigit(c)) {
            typeName += parts[i];
            c = parts[++i][0];
            if (c=='[') {
              typeName += parts[i];
              int cnt = 1;
              while (cnt>0) {
                c = parts[++i][0];
                if (parts[i]==" ")
                  break;
                if (c=='[')
                  cnt++;
                if (c==']')
                  cnt--;
                typeName += parts[i];
              }
              i++;
              break;
            }
          }
        }
#endif
        if (!Char.IsLetterOrDigit(c) && c!='_' && c!='-' && c!='.' && c!='"')
          break;
        if (tokenTypes[i]==TokenType.QuotedIdentifier)
          typeName += GetUnquotedIdentifier(csTokens[i]);
        else
          typeName += csTokens[i];
      }
      return typeName;
    }

    private void ParseFieldReference(ref int i, QueryCompilerRefLayer contextEntry, ref Field field, ref Culture culture)
    {
      string fieldName = csTokens[i];
      if (tokenTypes[i]==TokenType.QuotedIdentifier)
        fieldName = GetUnquotedIdentifier(fieldName);
      if (contextEntry.Type!=null)
        field = contextEntry.Type.Fields[fieldName];
      else {
        if (contextEntry.Field is ValueTypeCollectionField)
          field = contextEntry.Field.ContainedFields[0].ContainedFields[fieldName];
        else
          field = contextEntry.Field.ContainedFields[fieldName];
      }

      if (field==null)
        throw NewInvalidOqlException(String.Format(
          "unknown field: {0}", fieldName), i);
      i++;
      
      culture = null;
      ParseCulture(ref i, ref culture);
      if (contextEntry.Type==null && culture!=null)
        throw NewInvalidOqlException(String.Format(
          "field {0} isn't [Translatable] or [Collatable]", field.AbsoluteName), i);
      if (culture==null)
        culture = translationCulture;

      if (field is StructField)
        ParseStructFieldReference(ref i, ref field);
    }
    
    private void ParseStructFieldReference(ref int i, ref Field field)
    {
      while (field is StructField) {
        if (tokens[i]=="-")
          throw NewInvalidOqlException(
            "culture can be specified for root fields only", i);
        if (tokens[i]!=".")
          throw NewInvalidOqlException(new string[] {"."}, i);
        i++;
        string fieldName = csTokens[i];
        if (tokenTypes[i] == TokenType.QuotedIdentifier)
          fieldName = GetUnquotedIdentifier(fieldName);
        field = field.ContainedFields[fieldName];
        if (field==null)
          throw NewInvalidOqlException(String.Format(
            "unknown contained field: {0}", csTokens[i]), i);
        i++;
      }
      if (tokens[i]=="-")
        throw NewInvalidOqlException(
          "culture can be specified for root fields only", i);
      if (tokens[i]==".")
        throw NewInvalidOqlException(
          "'.' can't be used here", i);
    }

    private Culture ParseCulture(ref int i, ref Culture culture)
    {
      culture = null;
      if (tokens[i]=="-") {
        i++;
        string cultureName = csTokens[i];
        if (tokenTypes[i]==TokenType.QuotedIdentifier)
          cultureName = GetUnquotedIdentifier(cultureName);
        if (cultureName=="")
          throw NewInvalidOqlException("invalid culture name", i);
        culture = session.domain.Cultures[cultureName];
        if (culture==null)
          throw NewInvalidOqlException(String.Format(
            "unknown culture: {0}", cultureName), i);
        i++;
      }
      return culture;
    }
    
    private ObjectModel.Type ParseCast(ref int i)
    {
      if (tokens[i]!="(")
        throw NewInvalidOqlException(new string[] {"("}, i);
      i++;
      string castTypeName = "";
      while (tokens[i]!=")")
      {
        if (tokens[i]==" ")
          throw NewInvalidOqlException(new string[] {")"}, i);
        string namePart = csTokens[i];
        if (tokenTypes[i]==TokenType.QuotedIdentifier)
          namePart = GetUnquotedIdentifier(namePart);
        castTypeName += namePart;
        i++;
      }
      i++;

      ObjectModel.Type castType = session.types.FindByShortName(castTypeName);
      if (castType==null)
        castType = session.types.FindByShortName(castTypeName);
      if (castType==null)
        throw NewInvalidOqlException(String.Format(
          "unknown type: {0}", castTypeName), i);
      return castType;
    }

    
    // Utilitary methods

    private ObjectModel.Type GetType(string typeName, int i)
    {
      ObjectModel.Type type = session.types.FindByShortName(typeName);
      if (type==null)
        throw NewInvalidOqlException(String.Format(
          "unknown type: {0}", typeName), i);
      return type;
    }
    
    private void GetTypeAndField(string fullName, int i, ref ObjectModel.Type type, ref Field field, ref Culture culture)
    {
      int fullNameLen = fullName.Length;
      int dotPos = fullName.IndexOf('.');
      if (dotPos<0)
        throw NewInvalidOqlException("{NamespaceName '.'}TypeName '.' FieldName['-' CultureName]{'.' FieldName} expected", i);
      
      while ((type = session.types.FindByShortName(fullName.Substring(0,dotPos)))==null) {
        if ((dotPos+1)>=fullNameLen)
          throw NewInvalidOqlException("{NamespaceName '.'}TypeName '.' FieldName['-' CultureName]{'.' FieldName} expected", i);
        dotPos = fullName.IndexOf('.',dotPos+1);
        if (dotPos<0)
          throw NewInvalidOqlException("{NamespaceName '.'}TypeName '.' FieldName['-' CultureName]{'.' FieldName} expected", i);
      }

      string fieldName = fullName.Substring(dotPos+1);
      int    fieldNameLen = fieldName.Length;
      string cultureName = null;
      int dashPos = fieldName.IndexOfAny(new char[] {'-'});
      if (dashPos>=0) {
        if ((dashPos+1)>=fieldNameLen)
          throw NewInvalidOqlException("{NamespaceName '.'}TypeName '.' FieldName['-' CultureName]{'.' FieldName} expected", i);
        dotPos = fieldName.IndexOf('.',dashPos+1);
        if (dotPos<0) {
          fieldName = fieldName.Substring(0, dashPos);
          cultureName = fieldName.Substring(dashPos+1);
        }
        else {
          if ((dotPos+1)>=fieldNameLen)
            throw NewInvalidOqlException("{NamespaceName '.'}TypeName '.' FieldName['-' CultureName]{'.' FieldName} expected", i);
          fieldName = fieldName.Substring(0, dashPos) +
                      fieldName.Substring(dotPos+1);
          cultureName = fieldName.Substring(dashPos+1, dotPos-dashPos-1);
        }
      }

      field = type.Fields[fieldName];
      if (field==null)
        throw NewInvalidOqlException(String.Format(
          "unknown field: {0}", fieldName), i);

      Field rf = field.RootField;
      culture = null;
      if (rf.Translatable || rf.Collatable)
        culture = translationCulture;
      if (cultureName!=null) 
      {
        if (!(rf.Translatable || rf.Collatable))
          throw NewInvalidOqlException(String.Format(
            "field {0} isn't [Translatable] or [Collatable]", rf.AbsoluteName), i);
        if (cultureName=="")
          throw NewInvalidOqlException("invalid culture name", i);
        culture = session.domain.Cultures[cultureName];
        if (culture==null)
          throw NewInvalidOqlException(String.Format(
            "unknown culture: {0}", cultureName), i);
      }
    }
    
    private ObjectModel.Type CheckCast(ObjectModel.Type fromType, ObjectModel.Type toType, int castPlace)
    {
      if (toType==null)
        return fromType;
      if (fromType.IsInterface) {
        if (toType.Interfaces.Contains(fromType))
          return toType;
      }
      else {
        int j;
        for (j = 0; j < toType.BaseTypes.Length && toType.BaseTypes[j]!=fromType; j++);
        if (j < toType.BaseTypes.Length)
          return toType;
      }
      throw NewInvalidOqlException("invalid cast", castPlace);
    }

    private string GetEntryIDColumnName(QueryCompilerRefLayer layer)
    {
      ICollectionField cf = layer.Field as ICollectionField;
      if (cf!=null) {
        return session.utils.QuoteDoubleIdentifier(
          layer.Alias, cf.GetOwnerIdColumnName(null));
      }
      else {
        if (layer.Type!=null)
          return session.utils.QuoteDoubleIdentifier(
            layer.Alias, session.dataObjectIDColumn.Name);
        else
          throw new DataObjectsDotNetException(
            "Internal error: invalid QueryCompilerRefLayer.");
      }
    }

    private string GetEntryColumnName(QueryCompilerRefLayer layer, string name)
    {
      return session.utils.QuoteDoubleIdentifier(layer.Alias, name);
    }
    
    private string GetNextAlias()
    {
      if (parentQuery!=null)
        return parentQuery.GetNextAlias();
      return aliasPfx + (nextAliasNumber++).ToString();
    }
    
    private static string GetUnquotedIdentifier(string quotedIdentifier)
    {
      int l = quotedIdentifier.Length;
      if (l<2)
        return quotedIdentifier;
      if (quotedIdentifier[0]=='"')
        return quotedIdentifier.Substring(1, l-2).Replace("\"\"","\"");
      else
        return quotedIdentifier.Substring(1, l-2);
    }
    
    private string GetCommandText()
    {
      Translate();
      return this.GetCommand().CommandText;
    }
    
    private string JoinContext_Add(string name, QueryCompilerRefLayer layer)
    {
      return joinContext.Add(name, layer);
    }
    
    private string JoinContext_Add(QueryCompilerRefLayer layer)
    {
      return joinContext.Add(layer);
    }
    
    private void JoinContext_Rename(string oldName, string newName)
    {
      joinContext.Rename(oldName, newName);
    }
    
    private QueryCompilerRefLayer JoinContext_Get(string name)
    {
      QueryCompilerRefLayer layer = joinContext[name];
      if (layer==null && parentQuery!=null)
        layer = parentQuery.JoinContext_Get(name);
      return layer;
    }

    /// <summary>
    /// Returns <see langword="true"/> when this query is a nested query.
    /// </summary>
    protected override bool IsSubQuery() 
    {
      return parentQuery!=null;
    }

    /// <summary>
    /// Returns <see langword="true"/> when query contains dynamic part
    /// and should be rebuilt on each execution.
    /// </summary>
    /// <returns><see langword="True"/> when query contains dynamic part
    /// and should be rebuilt on each execution.</returns>
    protected override bool HasDynamicRestriction()
    {
      return 
        ftsCondition!=null && 
        !(Domain.FtsDriver is NativeFtsDriver);
    }

    // Constructors
    
    /// <summary>
    /// Initializes an instance of this class.
    /// <seealso cref="DataObjects.NET.Session.CreateQuery"/>
    /// </summary>
    /// <param name="session">Session, to which this query belongs.</param>
    /// <param name="text">Query text (see <see cref="Text"/> property description).</param>
    public Query(Session session, string text): 
      base(session, typeof(DataObject))
    {
      queryRestrictions = new QueryRestrictionCollection(this);
      initialized = true;
      Text = text;
    }
    
    /// <summary>
    /// Initializes an instance of this class.
    /// <seealso cref="DataObjects.NET.Session.CreateQuery"/>
    /// </summary>
    /// <param name="session">Session, to which this query belongs.</param>
    public Query(Session session): 
      base(session, typeof(DataObject))
    {
      queryRestrictions = new QueryRestrictionCollection(this);
      initialized = true;
      translated  = false;
    }
    
    private Query(Session session, string text, bool idOnly, Query parentQuery): 
      base(session, typeof(DataObject))
    {
      this.IdOnly = idOnly;
      this.parentQuery = parentQuery;
      this.nestingCnt = parentQuery.nestingCnt + 1;
      queryRestrictions = new QueryRestrictionCollection(this);
      initialized = true;
      Text = text;
    }
  }
}
