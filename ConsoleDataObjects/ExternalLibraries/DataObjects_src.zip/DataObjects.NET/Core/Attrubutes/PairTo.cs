// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;

namespace DataObjects.NET.Attributes
{
  /// <summary>
  /// Indicates that persistent collection (see <see cref="DataObjectCollection"/>)
  /// is a "reflection" of another ("master") collection or reference field.
  /// </summary>
  /// <remarks>
  /// <note>This attribute can be applied to persistent properties
  /// of <see cref="DataObject"/>, <see cref="DataObjectCollection"/> and 
  /// <see cref="ValueTypeCollection"/> types.</note>
  /// A collection marked by this attribute doesn't allocate any space in the database,
  /// except it transparently uses a table allocated for master collection, but
  /// flipped horisontally. Moreover, paired and master collections are always
  /// synchronized with each other, so when you change a paired
  /// collection, its master collection changes too, and vice versa. 
  /// Each master collection can have only one paired collection.
  /// <para>
  /// See the example below to understand its behavior better.
  /// </para>
  /// <para>
  /// <example>Example (for <see cref="DataObjectCollection"/>):
  /// <code lang="C#">
  ///  public abstract class Principal: FtObject
  ///  {
  ///    [ItemType(typeof(Role))]
  ///    public abstract RoleCollection Roles {get;}
  ///    // RoleCollection is "typed" DataObjectCollection descendant, see below
  ///
  ///    ...
  ///  }
  ///
  ///  public abstract class Role: Principal
  ///  {
  ///    [ItemType(typeof(Principal))]
  ///    [PairTo(typeof(Principal),"Roles")] // !!!
  ///    public abstract PrincipalCollection Principals {get;}
  ///    // PrincipalCollection is "typed" DataObjectCollection descendant, see below
  ///
  ///    ...
  ///  }
  ///
  ///  // This is an example of typed collection
  ///  public abstract class PrincipalCollection: DataObjectCollection
  ///  {
  ///    public int Add(Principal item) 
  ///    {
  ///      return List.Add(item);
  ///    }
  ///
  ///    public new Principal this[int n] {
  ///      get {
  ///        return (Principal)List[n];
  ///      }
  ///      set {
  ///        List[n] = value;
  ///      }
  ///    }
  ///    
  ///    public PrincipalCollection(System.Type itemType): base(itemType)
  ///    {
  ///      if (!(itemType==typeof(Principal) || itemType.IsSubclassOf(typeof(Principal))))
  ///        throw new ObjectModelBuilderException(
  ///          String.Format("Illegal ItemType value: \"{0}\".",itemType)
  ///          );
  ///    }
  ///  }
  ///
  ///  public abstract class RoleCollection: DataObjectCollection
  ///  {
  ///    public int Add(Role item) 
  ///    {
  ///      return List.Add(item);
  ///    }
  ///
  ///    public new Role this[int n] {
  ///      get {
  ///        return (Role)List[n];
  ///      }
  ///      set {
  ///        List[n] = value;
  ///      }
  ///    }
  ///
  ///    public RoleCollection(System.Type itemType): base(itemType)
  ///    {
  ///      if (!(itemType==typeof(Role) || itemType.IsSubclassOf(typeof(Role))))
  ///        throw new ObjectModelBuilderException(
  ///          String.Format("Illegal ItemType value: \"{0}\".",itemType)
  ///          );
  ///    }
  ///  }
  /// </code>
  /// </example>
  /// </para>
  /// <para>
  /// <example>Example (for <see cref="ValueTypeCollection"/>):
  /// <code lang="C#">
  ///  public struct Order
  ///  {
  ///    public Seller Seller; 
  ///    public Customer Customer; 
  ///    ....
  ///  }
  ///  public abstract class Person: DataObject
  ///  {
  ///    ...
  ///  }
  ///    
  ///  public abstract class Seller: Person
  ///  {
  ///    [ItemType(typeof(Order), OwnerField = "Seller")]
  ///    public abstract ValueTypeCollection Orders {get;}
  ///
  ///    ...
  ///  }
  ///
  ///  public abstract class Customer: Person
  ///  {
  ///    [ItemType(typeof(Order), OwnerField = "Customer")]
  ///    [PairTo(typeof(Seller), "Orders")] // !!!
  ///    public abstract ValueTypeCollection Orders {get;}
  ///
  ///    ...
  ///  }
  /// </code>
  /// </example>
  /// </para>
  /// <seealso cref="ContainedAttribute"/>
  /// <seealso cref="SelfReferenceAllowedAttribute"/>
  /// <seealso cref="SymmetricAttribute"/>
  /// </remarks>
  [AttributeUsage(AttributeTargets.Property, AllowMultiple = false, Inherited = true)]
  [Serializable]
  public class PairToAttribute: DataObjectAttribute
  {
    private System.Type type;
    /// <summary>
    /// Type where master property is declared.
    /// </summary>
    public  System.Type Type {
      get {return type;}
      set {type = value;}
    }
    
    private string field;
    /// <summary>
    /// Master property name.
    /// </summary>
    public  string Field
    {
      get {return field;}
      set {field = value;}
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type">Type where master property is declared.</param>
    /// <param name="field">Master property name.</param>
    public PairToAttribute(System.Type type, string field) 
    {
      this.type  = type;
      this.field = field;
    }
  }
}
