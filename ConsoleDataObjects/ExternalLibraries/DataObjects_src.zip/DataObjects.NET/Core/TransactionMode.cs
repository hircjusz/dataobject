// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Attributes;

namespace DataObjects.NET
{
  /// <summary>
  /// Determines automatic transactions mode for the method or property.
  /// <seealso cref="TransactionalAttribute"/>
  /// <seealso cref="Transaction"/>
  /// <seealso cref="Session"/>
  /// <seealso cref="SessionOptions"/>
  /// </summary>
  [Flags]
  public enum TransactionMode
  {
    /// <summary>
    /// Automatic transactions are disabled for specified method or property.
    /// Note that you can use <see cref="Unsafe"/> flag with this transaction
    /// mode - this means that method doesn't require a transaction itself,
    /// but contains unsafe exception handlers (so any transactional method
    /// called by it should be executed in the new transaction).
    /// Value is <see langword="0x0"/>. 
    /// </summary>
    Disabled = 0x0,
    /// <summary>
    /// Method\property requires a transaction during its execution.
    /// This means that if a transaction wasn't started and locked by 
    /// the upper caller,
    /// or upper caller is marked as <see cref="Unsafe"/>, 
    /// or upper caller is a non-transactional method,
    /// a new transaction should be started on the method invocation. 
    /// In this case this transaction should be committed on successful execution, 
    /// or rolled back if any exception is thrown.
    /// Note that if a transaction wasn't started on the method invocation
    /// (so existing transaction was running and all other mentioned conditions
    /// were satisfied), it will be rolled back on any thrown exception also,
    /// but it won't be comitted on successful invocation.
    /// Value is <see langword="0x1"/>. 
    /// </summary>
    TransactionRequired = 0x1,
    /// <summary>
    /// Method\property requires a new transaction during its execution.
    /// Note that normally you shouldn't use this mode - its behavior can
    /// be completely reproduced by use of <see cref="TransactionRequired"/>
    /// option and <see cref="Unsafe"/> flag - in this case the
    /// number of inner transactions tends to be significantly lower and 
    /// consequently the performance will be higher (each inner transaction 
    /// requires delayed updates to be flushed before its beginning and 
    /// completion).
    /// Value is <see langword="0x3"/>. 
    /// </summary>
    NewTransactionRequired = 0x3,
    /// <summary>
    /// Method\property requires an existing transaction during its execution.
    /// This means that if a transaction wasn't started by the upper caller,
    /// <see cref="TransactionRequiredException"/> will be thrown.
    /// Value is <see langword="0x5"/>. 
    /// </summary>
    ExistingTransactionRequired = 0x5,
    /// <summary>
    /// Method is unsafe - this means that it contains unsafe exception handlers
    /// catching exceptions from transactional methods. This exactly means
    /// that any of transactional methods invoked by it and marked with
    /// <see cref="TransactionMode.TransactionRequired"/> option should 
    /// be executed in the new transaction (to make it possible to rollback
    /// any of such methods). Note that you shouldn't use this flag with
    /// methods that contain no exception handlers or use only safe exception
    /// handlers.
    /// See the <see cref="TransactionController"/> type
    /// description for examples of transaction-safe exception handling code.
    /// Value is <see langword="0x100"/>. 
    /// </summary>
    Unsafe = 0x100,
    /// <summary>
    /// Method supports offline mode.
    /// This flag means that a new transaction shouldn't be created automatically 
    /// for in the <see cref="SessionOptions.OfflineMode"/>, if there 
    /// is no already running transaction.
    /// Practically this means that this method is capable of
    /// returning cached property values in the 
    /// <see cref="SessionOptions.OfflineMode"/>.
    /// Value is <see langword="0x200"/>. 
    /// </summary>
    SupportsOfflineMode = 0x200,
  }
}
