// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Attributes;
using DataObjects.NET.Serialization;

namespace DataObjects.NET
{
  /// <summary>
  /// Enumeration of possible security options for a <see cref="Session"/>.
  /// <seealso cref="Session.SecurityOptions"/>
  /// <seealso cref="Domain.SessionSecurityOptions"/>
  /// <seealso cref="DataObjects.NET.Security"/>
  /// <seealso cref="DataObjects.NET.Security"/>
  /// </summary>
  [Flags]
  public enum SessionSecurityOptions
  {
    /// <summary>
    /// Maximal security level.
    /// Value is <see langword="0x100 | 0x200"/>. 
    /// </summary>
    Maximal = 0x100 | 0x200,
    
    /// <summary>
    /// <see cref="SessionOptions.DisableAutoDisconnect"/> option 
    /// change is allowed.
    /// Value is <see langword="0x1"/>. 
    /// </summary>
    AllowChangeAutoDisconnect         = 0x1,
    /// <summary>
    /// <see cref="Session.CommandTimeout"/> change is allowed.
    /// Value is <see langword="0x2"/>. 
    /// </summary>
    AllowChangeCommandTimeout         = 0x2,
    /// <summary>
    /// Request re-processing settings change is allowed.
    /// See <see cref="Session.ReprocessingAttemptsCount"/> and
    /// <see cref="Session.ReprocessingDelay"/>.
    /// Value is <see langword="0x4"/>. 
    /// </summary>
    AllowChangeReprocessingSettings   = 0x4,
    
    /// <summary>
    /// Inconsistenct data update probability change is allowed
    /// See <see cref="Session.InconsistentDataUpdateProbability"/>.
    /// Value is <see langword="0x8"/>. 
    /// </summary>
    AllowChangeInconsistentDataUpdateProbability = 0x8,
    
    /// <summary>
    /// Participation in distributed transaction is allowed.
    /// See <see cref="Session.EnlistDistributedTransaction"/>.
    /// Value is <see langword="0x10"/>. 
    /// </summary>
    AllowEnlistDistributedTransaction = 0x10,
    /// <summary>
    /// Use of <see cref="Savepoint"/> is allowed.
    /// Value is <see langword="0x20"/>. 
    /// </summary>
    AllowUseSavepoints = 0x20,
    /// <summary>
    /// Use of <see cref="Serializer"/> is allowed.
    /// Value is <see langword="0x40"/>. 
    /// </summary>
    AllowUseSerializer = 0x40,
    
    /// <summary>
    /// Serializable isolation level allowed.
    /// Value is <see langword="0x100"/>. 
    /// </summary>
    AllowIsolationLevelSerializable   = 0x100,
    /// <summary>
    /// Repeatable read isolation level allowed.
    /// Value is <see langword="0x200"/>. 
    /// </summary>
    AllowIsolationLevelRepeatableRead = 0x200,
    /// <summary>
    /// Read committed isolation level allowed.
    /// Value is <see langword="0x400"/>. 
    /// </summary>
    AllowIsolationLevelReadCommitted  = 0x400,
    
    /// <summary>
    /// Access to real objects (like <see cref="Session.RealConnection"/>) allowed.
    /// Value is <see langword="0x100000"/>. 
    /// </summary>
    AllowAccessRealObjects            = 0x10000,
    /// <summary>
    /// Use of <see cref="SessionOptions">SessionOptions.OfflineMode</see> is allowed.
    /// Value is <see langword="0x20000"/>. 
    /// </summary>
    AllowOfflineMode                  = 0x20000,
    
    /// <summary>
    /// Standard security level.
    /// Value is         <see langword="0x1 | 0x2 | 0x4 | 0x8 | 0x10 | 0x20 | 0x40 | 0x100 | 0x200 | 0x20000"/>. 
    /// </summary>
    Standard                          = 0x1 | 0x2 | 0x4 | 0x8 | 0x10 | 0x20 | 0x40 | 0x100 | 0x200 | 0x20000,

    /// <summary>
    /// Standard remote security level.
    /// The same as <see cref="Maximal"/> session security level.
    /// Value is <see langword="0x100 | 0x200"/>. 
    /// </summary>
    Remote = 0x100 | 0x200,

    /// <summary>
    /// Anything is allowed.
    /// Value is <see langword="0x1FFFFFFF"/>. 
    /// </summary>
    Minimal = 0x1FFFFFFF,
  }
}
