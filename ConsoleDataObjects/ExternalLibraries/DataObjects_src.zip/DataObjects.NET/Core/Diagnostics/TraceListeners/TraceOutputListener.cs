// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;

namespace DataObjects.NET.Diagnostics
{
  /// <summary>
  /// Default trace listener that posts messages to the trace listeners
  /// in the <see cref="System.Diagnostics.Trace.Listeners"/> collection.
  /// </summary>
  public class TraceOutputListener: ITraceListener
  {
    private static string cCategory = "DataObjects.NET diagnostic trace";
    
    /// <summary>
    /// Writes an entry to the event log.
    /// </summary>
    /// <param name="context">Trace context.</param>
    public void LogEvent(TraceContext context)
    {
      System.Diagnostics.Trace.WriteLine(context.Message, cCategory);
    }
    
    // Constructors
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    public TraceOutputListener()
    {
    }
  }
}
