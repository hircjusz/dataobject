// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.IO;
using System.Reflection;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using DataObjects.NET.ObjectModel.TypeConversion;

namespace DataObjects.NET.Remoting.ArgumentContainers
{
  /// <summary>
  /// Describes an argument of non Array and not primitive types.
  /// </summary>
  [Serializable]
  public class ObjectArgumentContainer : ArgumentContainer
  {
    private static BinaryFormatter formatter = new BinaryFormatter();
    private static MemoryStream    ms        = new MemoryStream();
    private System.Type argumentType;
    private ArgumentContainer[] innerValues;
    private byte[] data;

    private object processingValue = null;

    internal override void FixValue(CallContext context)
    {
      if (processingValue==null)
        try {
          if (innerValues!=null)
            foreach (ArgumentContainer argContainer in innerValues)
              argContainer.FixValue(context);
        }
        finally {
          processingValue=null;
        }
    }

    /// <summary>
    /// Creates a new object that is a copy of a curent instance.
    /// </summary>
    public override object Clone()
    {
      if (processingValue==null)
        try {
          ObjectArgumentContainer clone = new ObjectArgumentContainer();
          processingValue = clone;
          if (data!=null) {
            clone.data = new byte[data.Length];
            data.CopyTo(clone.data, 0);
          }
          else {
            clone.argumentType = argumentType;
            clone.innerValues = new ArgumentContainer[innerValues.Length];
            for (int i = 0, count=innerValues.Length; i<count; i++)
              clone.innerValues[i] = (ArgumentContainer) innerValues[i].Clone();
          }
          return clone;
        }
        finally {
          processingValue=null;
        }
      return processingValue;
    }

    /// <summary>
    /// Gets parameter value.
    /// </summary>
    public override object GetValue (CallContext context)
    {
      if (processingValue==null)
        try {
          if (data!=null)
            lock(ms) {
              ms.SetLength(0);
              ms.Write(data, 0, data.Length);
              ms.Seek(0, SeekOrigin.Begin);
              return formatter.Deserialize(ms);
            }
          else {
            processingValue = FormatterServices.GetUninitializedObject(argumentType);
            FieldInfo[] fieldInfos = argumentType.GetFields(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
            object[] values = new object[fieldInfos.Length];
            for (int i = 0, count=values.Length; i<count; i++)
              values[i] = innerValues[i].GetValue(context);
            FormatterServices.PopulateObjectMembers(processingValue, fieldInfos, values);
            return processingValue;
          }
        }
        finally {
          processingValue=null;
        }
      return processingValue;
    }

    /// <summary>
    /// Sets parameter value.
    /// </summary>
    /// <param name="value"></param>
    protected internal override void SetValue(object value)
    {
      if (value==null)
        throw new ArgumentNullException("value");
      argumentType = value.GetType();
      System.Type onlineArgumentType = TypeConverter.ConvertToOnline(argumentType);
      if (argumentType==onlineArgumentType)
        lock(ms) {
          ms.SetLength(0);
          formatter.Serialize(ms, value);
          data = new byte[ms.Length];
          ms.Seek(0, SeekOrigin.Begin);
          ms.Read(data, 0, data.Length);
        }
      else {
        FieldInfo[] fieldInfos = argumentType.GetFields(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
        object[] values = FormatterServices.GetObjectData(value, fieldInfos);
        innerValues = new ArgumentContainer[values.Length];
        for (int i=0, count=values.Length; i<count; i++)
          innerValues[i] = ArgumentConverter.Convert(values[i]);
        argumentType = onlineArgumentType;
      }
    }

    // Constructors

    internal ObjectArgumentContainer()
    {
    }
  }
}
