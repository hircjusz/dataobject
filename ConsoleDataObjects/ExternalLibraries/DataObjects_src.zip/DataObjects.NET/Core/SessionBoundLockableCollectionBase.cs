// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;
using System.Runtime.Serialization;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Attributes;

namespace DataObjects.NET
{
  /// <summary>
  /// Base class for any lockable collection that should be bound to the 
  /// <see cref="Session"/> object.
  /// </summary>
  [Serializable]
  public abstract class SessionBoundLockableCollectionBase: SessionBoundCollectionBase, ILockable, ISerializable, IDeserializationCallback
  {
    /// <summary>
    /// Determines whether the collection is immutable (locked, read-only). 
    /// </summary>
    /// <remarks>
    /// There is no way to unlock locked collection.
    /// </remarks>
    public bool IsLocked {
      get {
        return List.IsReadOnly;
      }
    }
    private bool serializedIsLocked;
    
    /// <summary>
    /// Locks the collection.
    /// </summary>
    public void Lock() 
    {
      Lock(false);
    }
    
    /// <summary>
    /// Locks the collection and (possible) all dependent objects.
    /// </summary>
    /// <param name="recursive"><see langword="True"/> if all dependent objects should be locked too.</param>
    public virtual void Lock(bool recursive) 
    {
      InnerList = ArrayList.ReadOnly(InnerList);
      if (recursive) {
        foreach (Object o in InnerList)
          if (o is ILockable)
            ((ILockable)o).Lock(recursive);
      }
    }
    
    /// <summary>
    /// Serializer.
    /// </summary>
    /// <param name="info"><see cref="SerializationInfo"/> object.</param>
    /// <param name="context"><see cref="StreamingContext"/> object.</param>
    public virtual void GetObjectData(SerializationInfo info, StreamingContext context)
    {
      info.AddValue("InnerList",InnerList);
      info.AddValue("IsLocked",IsLocked);
    }

    /// <summary>
    /// Deserialization callback.
    /// </summary>
    /// <param name="sender">Object, that initiated deserialization. Currently unused.</param>
    public virtual void OnDeserialization(object sender)
    {
      if (serializedIsLocked)
        Lock();
    }


    // Constructors
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <remarks>
    /// This constructor is called by derived class constructors to initialize state in this type.
    /// </remarks>
    internal SessionBoundLockableCollectionBase(): base()
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="session">Session, to which current instance should be bound.</param>
    /// <remarks>
    /// This constructor is called by derived class constructors to initialize state in this type.
    /// </remarks>
    internal SessionBoundLockableCollectionBase(Session session): base(session)
    {
    }

    /// <summary>
    /// Deserialization constructor.
    /// </summary>
    /// <param name="info"><see cref="SerializationInfo"/> object.</param>
    /// <param name="context"><see cref="StreamingContext"/> object.</param>
    protected SessionBoundLockableCollectionBase(SerializationInfo info, StreamingContext context)
    {
      InnerList = (ArrayList)info.GetValue("InnerList",typeof(ArrayList));
      serializedIsLocked = info.GetBoolean("IsLocked");
    }
  }
}
