// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.ComponentModel;
using DataObjects.NET.Data.Design;

namespace DataObjects.NET.Data
{
  /// <summary>
  /// <see cref="DataObjectCollection"/> mapping item.
  /// </summary>
  [TypeConverter(typeof(DocMappingItemConverter))]
  public class DocMappingItem: MappingToTableItem
  {
    private string docName;
    
    /// <summary>
    /// Gets item name.
    /// </summary>
    public override string Name {
      get {
        if (docName!=null)
          return docName;
        return "Doc Mapping Item";
      }
    }
    
    /// <summary>
    /// Gets or sets DataObjectCollection name.
    /// </summary>
    [Category("Mapping")]
    [TypeConverter(typeof(DocNameConverter))]
    public string CollectionName {
      get {
        return docName;
      }
      set {
        docName = value;
      }
    }
    
    /// <summary>
    /// Initializes a new instance of the <see cref="DocMappingItem"/> class.
    /// </summary>
    public DocMappingItem(): this(null, null)
    {
    }
    
    /// <summary>
    /// Initializes a new instance of the <see cref="DocMappingItem"/> class.
    /// </summary>
    /// <param name="docName">DataObjectCollection name.</param>
    /// <param name="tableName">Database table name.</param>
    public DocMappingItem(string docName, string tableName): base(tableName)
    {
      this.docName = docName;
    }
  }
}
