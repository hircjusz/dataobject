// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.IO;
using System.Text;
using System.Threading;
using System.Collections;
using System.Collections.Specialized;
using System.Data;
using System.Reflection;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.EnterpriseServices;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Attributes;
using DataObjects.NET.ObjectModel;
using DataObjects.NET.DatabaseModel;
using DataObjects.NET.Serialization;
using DataObjects.NET.Security;
using DataObjects.NET.Security.Permissions;

namespace DataObjects.NET
{
  /// <summary>
  /// Base class for any service class working with persistent objects
  /// (<see cref="DataObject"/> descendants).
  /// <see langword="Abstract"/>.
  /// </summary>
  /// <remarks>
  /// Instances of this class can exist only within the <see cref="Session"/>.
  /// By default <see cref="DataService"/> is <see cref="DataServiceType.Shared"/>,
  /// use <see cref="ServiceTypeAttribute"/> to override this option.
  /// <seealso cref="DataObjects.NET.DataObject"/>
  /// <seealso cref="DataObjects.NET.Domain"/>
  /// <seealso cref="DataObjects.NET.Session"/>
  /// <seealso cref="DataObjects.NET.Transaction"/>
  /// <seealso cref="Principal"/>
  /// <seealso cref="Permission"/>
  /// <seealso cref="PermissionSet"/>
  /// </remarks>
  public abstract class DataService: TransactionalObject
  {
    private  ObjectModel.Service service;
    /// <summary>
    /// Gets the <see cref="DataObjects.NET.ObjectModel.Service"/> of this instance.
    /// </summary>
    [Transactional(TransactionMode.Disabled)]
    public  ObjectModel.Service Service {
      get {return service;}
    }
    
    // ToString implementation
    
    /// <summary>
    /// Returns <see cref="String"/> representation of current service.
    /// </summary>
    /// <returns>The <see cref="String"/> representation of this service.</returns>
    /// <remarks>
    /// This method returns <see cref="String"/> in the following format:
    /// "[ShortenedServiceName]".
    /// </remarks>
    [Transactional(TransactionMode.Disabled)]
    public override string ToString()
    {
      return ToDebugString();
    }
    
    /// <summary>
    /// Returns debug <see cref="String"/> of current service that is used for trace.
    /// </summary>
    /// <returns>Debug <see cref="String"/> of current collection.</returns>
    [Transactional(TransactionMode.Disabled)]
    protected internal virtual string ToDebugString()
    {
      return Service.ShortenedName;
    }


    // Constructors

    /// <summary>
    /// Initializes the instance (this method is called during construction).
    /// </summary>
    /// <param name="service">Service of the instance.</param>
    /// <param name="session">Session, to which this instance belongs.</param>
    /// <param name="initParams">Init parameters.</param>
    [Transactional(TransactionMode.Disabled)]
    internal void InitInstance(ObjectModel.Service service, Session session, object[] initParams)
    {
      this.service = service;
      this.session = session;

      // OnCreate invocation
      if (initParams==null || initParams.Length==0)
        this.OnCreate();
      else
        GetType().InvokeMember("OnCreate", 
          BindingFlags.Public | BindingFlags.NonPublic | 
          BindingFlags.Instance | BindingFlags.InvokeMethod, 
          null, this, initParams);
    }

    /// <summary>
    /// A constructor analogue. Called on instance initialization.
    /// Declare <see cref="OnCreate"/>(parameters ...) to use parameterized instance
    /// initialization (in this case appropriate <see cref="OnCreate"/> method
    /// will be choosed based on arguments passed to the 
    /// <see cref="Session.CreateService">Session.CreateService</see> method).
    /// Override this method (or declare a new virtual method with 
    /// <see cref="OnCreate"/> name) to perform custom actions after instance 
    /// creation.
    /// </summary>
    [Transactional(TransactionMode.Disabled)]
    protected virtual void OnCreate()
    {
    }
  }
}
