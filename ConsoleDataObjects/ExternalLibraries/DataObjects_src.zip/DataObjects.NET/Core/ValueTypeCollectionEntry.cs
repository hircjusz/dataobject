// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;

namespace DataObjects.NET
{
  /// <summary>
  /// Represents an entry in <see cref="ValueTypeCollection"/>.
  /// </summary>
  #if (!NoMBR)
  public sealed class ValueTypeCollectionEntry: MarshalByRefObject
  #else
  public sealed class ValueTypeCollectionEntry: Object
  #endif
  {
    /// <summary>
    /// The value that denotes that <see cref="ItemID"/> 
    /// isn't specified.
    /// </summary>
    public const long UndefinedItemID = Int64.MinValue;
    
    private ValueTypeCollection collection;
    private long   itemId = UndefinedItemID;
    private object iValue;

    /// <summary>
    /// Gets the collection to which this entry belongs.
    /// </summary>
    public ValueTypeCollection Collection {
      get {
        return collection;
      }
    }

    /// <summary>
    /// Gets the owner (<see cref="DataObject"/> instance) of this entry.
    /// </summary>
    public DataObject Owner {
      get {
        return collection.Owner;
      }
    }

    /// <summary>
    /// Gets the ItemID (key) of the collection item.
    /// </summary>
    public long ItemID {
      get {
        if (itemId<0 && collection!=null)
          collection.Persist();
        return itemId;
      }
    }
    
    /// <summary>
    /// Gets the internal ItemID (key) of the collection item.
    /// This property may return negative ItemID in case when
    /// current item wasn't persisted yet.
    /// </summary>
    internal long InternalItemID {
      get {
        return itemId;
      }
      set {
        this.itemId = value;
      }
    }

    /// <summary>
    /// Gets the value of the collection item.
    /// </summary>
    public object Value {
      get {
        return collection.GetValue(itemId);
      }
      set {
        collection.SetValue(itemId, value);
      }
    }

    internal object GetContainedValue(string containedValueName)
    {
      return collection.InternalGetStructFieldValue(this, containedValueName);
    }

    /// <summary>
    /// Internal value of the collection item.
    /// </summary>
    internal object InternalValue {
      get {
        return iValue;
      }
      set {
        iValue = value;
      }
    }
    
    /// <summary>
    /// Indicates whether an entry is unbound
    /// (doesn't belong to any collection).
    /// </summary>
    public bool IsUnbound {
      get {
        return collection==null;
      }
    }
        

    // Constructor

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="collection">Collection of this entry.</param>
    /// <param name="itemId">ItemID (key) of the collection item.</param>
    /// <param name="iValue">Internal value of the collection item.</param>
    internal ValueTypeCollectionEntry(ValueTypeCollection collection, long itemId, object iValue)
    {
      this.collection = collection;
      this.itemId     = itemId;
      this.iValue     = iValue;
    }
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="collection">Collection of this entry.</param>
    /// <param name="value">Value of the collection item.</param>
    private ValueTypeCollectionEntry(ValueTypeCollection collection, object value)
    {
      ObjectModel.Field containedField = collection.Field.ContainedFields[0];
      this.collection = null;
      this.itemId     = UndefinedItemID;
      this.iValue     = containedField.ConvertValueToInternal(collection.Owner, collection.Culture, value);
    }
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="source">An entry to clone.</param>
    private ValueTypeCollectionEntry(ValueTypeCollectionEntry source)
    {
      this.collection = null;
      this.itemId     = UndefinedItemID;
      this.iValue     = source.InternalValue;
      if (iValue is StructHolder)
        iValue = (iValue as StructHolder).Clone();
    }
    
    
    // Static menthods

    /// <summary>
    /// Initializes a new instance of this class.
    /// An instance created by this method can be used only as parameter of 
    /// <see cref="ValueTypeCollection.Contains">ValueTypeCollection.Contains</see> and
    /// <see cref="ValueTypeCollection.IndexOf">ValueTypeCollection.IndexOf</see> methods. 
    /// </summary>
    /// <param name="collection">Collection of this entry.</param>
    /// <param name="value">Value of the collection item.</param>
    public static ValueTypeCollectionEntry CreateUnbound(ValueTypeCollection collection, object value)
    {
      return new ValueTypeCollectionEntry(collection, value);
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// An instance created by this method can be used only as parameter of 
    /// <see cref="ValueTypeCollection.Contains">ValueTypeCollection.Contains</see> and
    /// <see cref="ValueTypeCollection.IndexOf">ValueTypeCollection.IndexOf</see> methods. 
    /// </summary>
    /// <param name="source">An entry to clone.</param>
    public static ValueTypeCollectionEntry CreateUnbound(ValueTypeCollectionEntry source)
    {
      return new ValueTypeCollectionEntry(source);
    }
  }
}
