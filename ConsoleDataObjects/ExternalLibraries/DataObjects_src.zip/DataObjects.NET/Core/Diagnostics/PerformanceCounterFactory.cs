// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;
using System.ComponentModel;
using System.Diagnostics;
using System.Reflection;

namespace DataObjects.NET.Diagnostics
{
  // TODO: Add exceptions trace via trace switch
  internal class PerformanceCounterFactory
  {
    private static Hashtable categoriesDescriptors = new Hashtable();

    internal static IPerformanceCounter[] CreateCounters(string categoryName, string counterName, string instanceName)
    {
      PerformanceCounterCategoryDescriptor descriptor = (PerformanceCounterCategoryDescriptor) categoriesDescriptors[categoryName];
      if (descriptor==null)
        throw new InvalidOperationException(String.Format("Category{0} not registered.", categoryName));
      PerformanceCounterFactoryCounterDescriptor counter = (PerformanceCounterFactoryCounterDescriptor) descriptor.counterDescriptors[counterName];
      if (counter==null)
        throw new InvalidOperationException(String.Format("Counter {0}.{1} not registered.", categoryName, counterName));
      CheckCategory(descriptor);
      // Now categories are ok
      if (descriptor.delayUsingCategory)
        return PerformanceCounterDummy.InstanceArray;
      else {
        try {
          IPerformanceCounter[] result = new IPerformanceCounter[counter.HasBaseCounter ? 2 : 1];
          result[0] = new PerformanceCounterWrapper(categoryName, counter.counterName, instanceName);
          if (counter.HasBaseCounter)
            result[1] = new PerformanceCounterWrapper(categoryName, counter.baseCounterName, instanceName);
          return result;
        }
        catch (Win32Exception e) {
          if (e.NativeErrorCode == 5) {
            descriptor.delayUsingCategory = true;
            return PerformanceCounterDummy.InstanceArray;
          }
          else
            // TODO: log exception
            throw;
        }
        catch (InvalidOperationException e) {
          int hresult = (int)typeof(Exception).GetProperty("HResult",BindingFlags.Instance | BindingFlags.NonPublic).GetValue(e,null);
           if (hresult == -2146233079) {
            descriptor.delayUsingCategory = true;
            return PerformanceCounterDummy.InstanceArray;
           }
           else
            throw;
        }
        
      }
    }

    internal static string GetBaseCounterName(string counterName)
    {
      return counterName + "Base";
    }

    internal static void RegisterCounterCategory(string categoryName, string categoryHelp)
    {
      lock (typeof (PerformanceCounterFactory)) {
        PerformanceCounterCategoryDescriptor descriptor = (PerformanceCounterCategoryDescriptor) categoriesDescriptors[categoryName];
        if (descriptor==null) {
          descriptor = new PerformanceCounterCategoryDescriptor(categoryName);
          categoriesDescriptors[categoryName] = descriptor;
        }
        descriptor.categoryHelp = categoryHelp;
      }
    }

    internal static void RegisterCounter(string categoryName, string counterName, string counterHelp, PerformanceCounterType counterType)
    {
      lock (typeof (PerformanceCounterFactory)) {
        PerformanceCounterCategoryDescriptor descriptor = (PerformanceCounterCategoryDescriptor) categoriesDescriptors[categoryName];
        if (descriptor==null) {
          descriptor = new PerformanceCounterCategoryDescriptor(categoryName);
          categoriesDescriptors[categoryName] = descriptor;
        }
        descriptor.counterDescriptors[counterName] = new PerformanceCounterFactoryCounterDescriptor(counterName, counterHelp, counterType);
      }
    }

    internal static void InstallCategory(string categoryName)
    {
      lock (typeof (PerformanceCounterFactory)) {
        PerformanceCounterCategoryDescriptor descriptor = (PerformanceCounterCategoryDescriptor) categoriesDescriptors[categoryName];
        if (descriptor==null)
          throw new InvalidOperationException(String.Format("Category{0} not registered.", categoryName));
        CheckCategory(descriptor);
      }
    }

    internal static void UnInstallCategory(string categoryName)
    {
      lock (typeof (PerformanceCounterFactory)) {
        if (PerformanceCounterCategory.Exists(categoryName))
          PerformanceCounterCategory.Delete(categoryName);
      }
    }

    private static void CheckCategory(PerformanceCounterCategoryDescriptor descriptor)
    {
      try {
        if (!descriptor.categoryChecked)
          lock (typeof (PerformanceCounterFactory)) {
            if (!descriptor.categoryChecked) {
              // comparing existing category counters and registered
              try {
                if (PerformanceCounterCategory.Exists(descriptor.categoryName)) {
                  ArrayList registeredCounterNames = new ArrayList();
                  PerformanceCounterCategory cat = new PerformanceCounterCategory(descriptor.categoryName);
                  bool allCountersExist = true;
                  foreach (PerformanceCounterFactoryCounterDescriptor desc in descriptor) {
                    if (!cat.CounterExists(desc.counterName)) {
                      allCountersExist = false;
                      break;
                    }
                    if ((desc.HasBaseCounter) && (!cat.CounterExists(desc.counterName))) {
                      allCountersExist = false;
                      break;
                    }
                  }
                  if (!allCountersExist) {
                    PerformanceCounterCategory.Delete(descriptor.categoryName);
                    descriptor.CreatePerformanceCategory();
                    descriptor.delayUsingCategory = true;
                  }
                }
                else {
                  descriptor.CreatePerformanceCategory();
                  descriptor.delayUsingCategory = true;
                }
              }
              catch (Win32Exception  e) {
                if (e.NativeErrorCode  != 5)
                  throw;
              }
              finally {
                descriptor.categoryChecked = true;
              }
            }
          }
      }
      catch (Exception) {
//      // TODO: trace exceptions
//      catch (Exception e) {
//#if DEBUG
//        Console.Error.WriteLine("Exception \n\t{0}\n occured while creating performance counter category {1}", e, descriptor.categoryName);
//#else
//        Console.Error.WriteLine("Exception \n\t{0}:{1}\n occured while creating performance counter category {2}", e.GetType().FullName, e.Message, descriptor.categoryName);
//#endif
        descriptor.categoryChecked = true;
        descriptor.delayUsingCategory = true;
        throw;
      }
    }
  }
}
