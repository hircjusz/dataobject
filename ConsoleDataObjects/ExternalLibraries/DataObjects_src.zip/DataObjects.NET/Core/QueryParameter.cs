// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Collections;
using System.Collections.Specialized;
using System.Data;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Attributes;

namespace DataObjects.NET
{
  /// <summary>
  /// A parameter of the <see cref="Query"/>.
  /// </summary>
  #if (!NoMBR)
  public sealed class QueryParameter: MarshalByRefObject,
  #else
  public sealed class QueryParameter: Object,
  #endif
    IDataParameter, IDbDataParameter, ICloneable
  {
    /// <summary>
    /// Enumeration of changeable <see cref="QueryParameter"/> properties.
    /// </summary>
    [Flags]
    public enum Properties {
      /// <summary>
      /// <see cref="QueryParameter.DbType"/>-related member.
      /// </summary>
      DbType     = 1,
      /// <summary>
      /// <see cref="QueryParameter.Value"/>-related member.
      /// </summary>
      Value      = 2,
      /// <summary>
      /// <see cref="QueryParameter.IsNullable"/>-related member.
      /// </summary>
      IsNullable = 4,
      /// <summary>
      /// <see cref="QueryParameter.Precision"/>-related member.
      /// </summary>
      Precision  = 8,
      /// <summary>
      /// <see cref="QueryParameter.Scale"/>-related member.
      /// </summary>
      Scale      = 16,
      /// <summary>
      /// <see cref="QueryParameter.Size"/>-related member.
      /// </summary>
      Size       = 32
    }

    private  string parameterName;
    private  Properties changedProperties;
    private  DbType dbType;
    private  object value = DBNull.Value;
    private  bool   isNullable = false;
    private  byte   precision  = 0;
    private  byte   scale      = 0;
    private  int    size       = 0;
    internal QueryParameterCollection owner = null;
    private static Regex rParameterName;
    
    
    /// <summary>
    /// Gets or sets the name of the parameter.
    /// </summary>
    public string ParameterName {
      get {
        return parameterName;
      }
      set {
        if (value!="")
          if (!rParameterName.IsMatch(value))
            throw new InvalidOperationException("Invalid parameter name (required: \"@[A-Za-z][A-Za-z0-9]*\")");
        parameterName = value;
        if (owner!=null)
          owner.translated = false;
      }
    }
    
    /// <summary>
    /// Gets the enumeration of properties that was changed
    /// during the existence of instance.
    /// </summary>
    public Properties ChangedProperties {
      get {
        return changedProperties;
      }
    }
    
    /// <summary>
    /// Gets or sets the value of the parameter.
    /// </summary>
    public object Value {
      get {
        return this.value;
      }
      set {
        if (value==null) {
          this.value = DBNull.Value;
        } else {
          IDataObject doValue = value as IDataObject;
          this.value = (doValue==null ? value : doValue.ID);
        }

        changedProperties |= Properties.Value;
        if ((changedProperties & Properties.IsNullable)==0) {
          if (this.value==DBNull.Value)
            isNullable = true;
          else
            isNullable = false;
        }
        if ((changedProperties & Properties.DbType)==0) {
          Type t = this.value.GetType();
          if (t==typeof(String)) 
            dbType = System.Data.DbType.String;
          else if (t==typeof(Int32)) 
            dbType = System.Data.DbType.Int32;
          else if (t==typeof(UInt32)) 
            dbType = System.Data.DbType.UInt32;
          else if (t==typeof(Int64)) 
            dbType = System.Data.DbType.Int64;
          else if (t==typeof(UInt64)) 
            dbType = System.Data.DbType.UInt64;
          else if (t==typeof(DateTime)) 
            dbType = System.Data.DbType.DateTime;
          else if (t==typeof(Double)) 
            dbType = System.Data.DbType.Double;
          else if (t==typeof(Single)) 
            dbType = System.Data.DbType.Single;
          else if (t==typeof(Decimal)) 
            dbType = System.Data.DbType.Decimal;
          else if (t==typeof(Boolean)) 
            dbType = System.Data.DbType.Boolean;
          else if (this.value is Enum) 
            dbType = System.Data.DbType.Int32;
          else if (t==typeof(byte[])) 
            dbType = System.Data.DbType.Binary;
          else if (t==typeof(Byte)) 
            dbType = System.Data.DbType.Byte;
          else if (t==typeof(SByte)) 
            dbType = System.Data.DbType.SByte;
          else if (t==typeof(Int16)) 
            dbType = System.Data.DbType.Int16;
          else if (t==typeof(UInt16)) 
            dbType = System.Data.DbType.UInt16;
          else if (t==typeof(Guid)) 
            dbType = System.Data.DbType.Guid;
        }
        if (owner!=null)
          owner.translated = false;
      }
    }
    
    /// <summary>
    /// Gets or sets a value indicating whether 
    /// the parameter accepts null values.
    /// </summary>
    /// <remarks>
    /// The default is <see langword="true"/>.
    /// </remarks>
    public bool IsNullable {
      get {
        return isNullable;
      }
      set {
        isNullable = value;
        changedProperties |= Properties.IsNullable;
        if (owner!=null)
          owner.translated = false;
      }
    }
    
    /// <summary>
    /// Gets or sets the <see cref="System.Data.DbType"/> of 
    /// the parameter.
    /// </summary>
    /// <remarks>
    /// The default is <see cref="System.Data.DbType">String</see>.
    /// </remarks>
    public DbType DbType {
      get {
        return dbType;
      }
      set {
        dbType = value;
        changedProperties |= Properties.DbType;
        if (owner!=null)
          owner.translated = false;
      }
    }
    
    /// <summary>
    /// Gets or sets a value indicating whether the parameter 
    /// is input-only, output-only, bidirectional, or a stored 
    /// procedure return value parameter.
    /// </summary>
    /// <remarks>
    /// The value of this property can't be changed, it is
    /// always <see cref="ParameterDirection">ParameterDirection.Input</see>.
    /// </remarks>
    public ParameterDirection Direction {
      get {
        return ParameterDirection.Input;
      }
      set {
        throw new InvalidOperationException("Direction property can't be set.");
      }
    }
    
    /// <summary>
    /// Indicates the precision of numeric parameters.
    /// </summary>
    /// <remarks>
    /// The maximum number of digits used to represent the 
    /// <see cref="Value"/> property of a <see cref="QueryParameter"/> 
    /// object. 
    /// The default value is <see langword="0"/>, which indicates that a 
    /// data provider sets the precision for <see cref="Value"/>.
    /// </remarks>
    public byte Precision {
      get {
        return precision;
      }
      set {
        precision = value;
        changedProperties |= Properties.Precision;
        if (owner!=null)
          owner.translated = false;
      }
    }
    
    /// <summary>
    /// Indicates the scale of numeric parameters.
    /// </summary>
    /// <remarks>
    /// The number of decimal places to which <see cref="Value"/> is 
    /// resolved. 
    /// The default is <see langword="0"/>.
    /// </remarks>
    public byte Scale {
      get {
        return scale;
      }
      set {
        scale = value;
        changedProperties |= Properties.Scale;
        if (owner!=null)
          owner.translated = false;
      }
    }
    
    /// <summary>
    /// The size of the parameter.
    /// </summary>
    /// <remarks>
    /// The maximum size, in bytes, of the data within the column. 
    /// The default is <see langword="0"/>.
    /// </remarks>
    public int Size {
      get {
        return size;
      }
      set {
        size = value;
        changedProperties |= Properties.Size;
        if (owner!=null)
          owner.translated = false;
      }
    }
    
    /// <summary>
    /// Gets or sets the name of the source column 
    /// that is mapped to the <see cref="DataSet"/> and used for 
    /// loading or returning the <see cref="Value"/>.
    /// </summary>
    /// <remarks>
    /// The value of this property can't be changed, it is
    /// always <see cref="String.Empty"/>.
    /// </remarks>
    public string SourceColumn {
      get {
        return "";
      }
      set {
        throw new InvalidOperationException("SourceColumn property can't be set.");
      }
    }
    
    /// <summary>
    /// Gets or sets the <see cref="DataRowVersion"/> to 
    /// use when loading <see cref="Value"/>.
    /// </summary>
    /// <remarks>
    /// The value of this property can't be changed, it is
    /// always <see cref="DataRowVersion">DataRowVersion.Default</see>.
    /// </remarks>
    public DataRowVersion SourceVersion {
      get {
        return DataRowVersion.Default;
      }
      set {
        throw new InvalidOperationException("DataRowVersion property can't be set.");
      }
    }
    
    object ICloneable.Clone()
    {
      QueryParameter p = new QueryParameter();
      p.parameterName = parameterName;
      p.value      = value;
      p.isNullable = isNullable;
      p.dbType     = dbType;
      p.precision  = precision;
      p.scale      = scale;
      p.size       = size;
      p.changedProperties = changedProperties;
      return p;
    }
    
    /// <summary>
    /// Creates a new object that is a copy of the current instance.
    /// </summary>
    /// <returns>A clone of the instance.</returns>
    public QueryParameter Clone()
    {
      return (QueryParameter)((ICloneable)this).Clone();
    }
    
    // Internal methods
    
    internal void InternalBind(QueryParameterCollection owner)
    {
      QueryParameterCollection oldHolder = this.owner;
      if (oldHolder!=null && owner!=null)
        throw new InvalidOperationException("Each QueryParameter can be added to only one QueryParameterCollection. You can use Clone() to solve the problem.");
      this.owner = owner;
      if (oldHolder!=null)
        oldHolder.translated = true;;
      if (owner!=null)
        owner.translated = false;
    }
    
    // Constructors
    
    /// <summary>
    /// Initializes a new instance of this type.
    /// </summary>
    /// <param name="name">Parameter name.</param>
    /// <param name="dbType">Parameter type.</param>
    /// <param name="value">Parameter value.</param>
    public QueryParameter(string name, DbType dbType, object value)
    {
      this.ParameterName = name;
      this.DbType = dbType;
      this.Value = value;
    }
    
    /// <summary>
    /// Initializes a new instance of this type.
    /// </summary>
    /// <param name="name">Parameter name.</param>
    /// <param name="value">Parameter value.</param>
    public QueryParameter(string name, object value)
    {
      this.ParameterName = name;
      this.Value = value;
    }
    
    /// <summary>
    /// Initializes a new instance of this type.
    /// </summary>
    /// <param name="name">Parameter name.</param>
    /// <param name="dbType">Parameter type.</param>
    public QueryParameter(string name, DbType dbType)
    {
      this.ParameterName = name;
      this.DbType = dbType;
    }
    
    /// <summary>
    /// Initializes a new instance of this type.
    /// </summary>
    /// <param name="name">Parameter name.</param>
    public QueryParameter(string name)
    {
      this.ParameterName = name;
    }
    
    /// <summary>
    /// Initializes a new instance of this type.
    /// </summary>
    public QueryParameter()
    {
    }

    static QueryParameter() 
    {
      rParameterName = new Regex(@"^@[A-Z][A-Z0-9]*$", RegexOptions.IgnoreCase | RegexOptions.Multiline | RegexOptions.Compiled);
    }
  }
}
