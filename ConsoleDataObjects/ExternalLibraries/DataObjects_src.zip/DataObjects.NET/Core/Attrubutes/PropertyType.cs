// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;

namespace DataObjects.NET.Attributes
{
  /// <summary>
  /// Specifies the type of the <see cref="ObjectModel.Field"/> descendant 
  /// that should  be used to handle (manage persistence of) the property.
  /// Normally you shouldn't use this attribute.
  /// </summary>
  [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field, 
    AllowMultiple = false, Inherited = true)]
  [Serializable]
  public class PropertyTypeAttribute: DataObjectAttribute
  {
    private Type type;
    /// <summary>
    /// The type of the <see cref="ObjectModel.Field"/> descendant that should be used to 
    /// handle (manage persistence of) the property.
    /// </summary>
    public  Type Type 
    {
      get {return type;}
      set {type = value;}
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type">The type of the <see cref="ObjectModel.Field"/> descendant that should be used to 
    /// handle (manage persistence of) the property.</param>
    public PropertyTypeAttribute(Type type) 
    {
      this.type = type;
    }
  }
}
