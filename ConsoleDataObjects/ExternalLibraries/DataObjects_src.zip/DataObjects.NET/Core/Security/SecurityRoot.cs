// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.IO;
using System.Threading;
using System.Configuration;
using System.Diagnostics;
using System.Globalization;
using System.Collections;
using System.Runtime.Serialization;
using DataObjects.NET;
using DataObjects.NET.Attributes;
using DataObjects.NET.Exceptions;
using DataObjects.NET.FullText;
using DataObjects.NET.Serialization;
using DataObjects.NET.Security.Permissions;

namespace DataObjects.NET.Security
{
  /// <summary>
  /// Default security root object implementation.
  /// <see langword="Persistent"/>.
  /// </summary>
  /// <remarks>
  /// <para>
  /// You can find more information about the whole DataObjects.NET
  /// security system <see cref="AccessControlList">here</see>.
  /// </para>
  /// </remarks>
  public abstract class SecurityRoot: DataObject, ISecurityRoot
  {
    /// <summary>
    /// Gets the parent object for this <see cref="DataObject"/> instance.
    /// Always returns <see langword="null"/>.
    /// </summary>
    /// <returns><see langword="Null"/>.</returns>
    /// <remarks>
    /// <note type="note">Any <see cref="ISecurityRoot"/> object should return
    /// <see langword="null"/> from this property. Any other object shouldn't
    /// return <see langword="null"/> from this property.</note>
    /// </remarks>
    [NotPersistent]
    [Transactional(TransactionMode.Disabled)]
    public override DataObject SecurityParent {
      get {
        return null;
      }
    }


    // Constructors

    /// <summary>
    /// A constructor analogue. Called on instance initialization.
    /// </summary>
    /// <remarks>
    /// <para>
    /// This method demands the following permissions:
    /// <see cref="AdministrationPermission"/>.
    /// It doesn't calls its base method.
    /// Additionaly it checks <see cref="Domain.Status"/> and throws a
    /// <see cref="SecurityException"/> if it doesn't equal to 
    /// <see cref="DomainStatus.InitializingSystemObjects"/>.
    /// </para>
    /// <para>
    /// See <see cref="DataObject.OnCreate"/> method description
    /// for additional information.
    /// </para>
    /// </remarks>
    protected override void OnCreate()
    {
      if (session.domain.status!=DomainStatus.InitializingSystemObjects)
        throw new SecurityException(
          "Instance of this type can be created only during the system " +
          "objects initialization period.");
      base.OnCreate();
    }

    /// <summary>
    /// Perform custom actions after instance creation.
    /// Usually security permission <see cref="DataObject.Demand"/>s
    /// should be executed in it.
    /// </summary>
    [Transactional(TransactionMode.Disabled)]
    protected override void OnCreated()
    {
      Demand(AdministrationPermission.Value);
      base.OnCreated();
    }

    // Event handlers
    
    /// <summary>
    /// Called during <see cref="DataObject.SetProperty"/> method execution.
    /// Note that this method isn't invoked during the deserialization.
    /// </summary>
    /// <param name="name">Property name.</param>
    /// <param name="culture">Property culture.</param>
    /// <param name="value">New property value.</param>
    /// <remarks>
    /// <para>
    /// This method demands the following permissions:
    /// <see cref="AdministrationPermission"/>.
    /// It doesn't calls its base method.
    /// </para>
    /// <para>
    /// See <see cref="DataObject.OnSetProperty"/> method description
    /// for additional information.
    /// </para>
    /// </remarks>
    protected override void OnSetProperty(string name, Culture culture, object value)
    {
      Demand(AdministrationPermission.Value);
      base.OnSetProperty(name, culture, value);
    }

    /// <summary>
    /// Called when inner content of some non-<see cref="ValueType"/> 
    /// property was changed.
    /// </summary>
    /// <param name="name">Property name.</param>
    /// <param name="culture">Property culture.</param>
    /// <param name="value">Old property value.</param>
    /// <remarks>
    /// <para>
    /// This method demands the following permissions:
    /// <see cref="AdministrationPermission"/>.
    /// It doesn't calls its base method.
    /// </para>
    /// <para>
    /// See <see cref="DataObject.OnSetProperty"/> method description
    /// for additional information.
    /// </para>
    /// </remarks>
    protected override void OnPropertyContentChanging(string name, Culture culture, object value)
    {
      if (name!="Permissions")
        Demand(AdministrationPermission.Value);
      base.OnPropertyContentChanging(name, culture, value);
    }

    /// <summary>
    /// Called before instance is serialized (see <see cref="Serializer"/> class).
    /// <seealso cref="Serializer"/>
    /// <seealso cref="SerializationOptions"/>
    /// <seealso cref="DeserializationOptions"/>
    /// </summary>
    /// <param name="serializer">Serializer that performs the serialization.</param>
    /// <param name="info">Serialization info.</param>
    /// <param name="context">Streaming context.</param>
    /// <param name="fields">A <see cref="Hashtable"/> initially containing pairs (Field name, <see langword="true"/>).
    /// You should set some values to <see langword="false"/> or <see langword="null"/> 
    /// in it to disable automatic serialization of corresponding field.
    /// E.g. you should clear it in case when you serialize all fields manually.</param>
    /// <remarks>
    /// <para>
    /// This method demands the following permissions:
    /// <see cref="AdministrationPermission"/>.
    /// It doesn't calls its base method.
    /// </para>
    /// <para>
    /// See <see cref="DataObject.OnSerializing"/> method description
    /// for additional information.
    /// </para>
    /// </remarks>
    protected override void OnSerializing(Serializer serializer, 
      SerializationInfo info, StreamingContext context, Hashtable fields)
    {
      Demand(AdministrationPermission.Value);
    }

    /// <summary>
    /// Called when the whole object graph is completely deserialized.
    /// <seealso cref="Serializer"/>
    /// <seealso cref="SerializationOptions"/>
    /// <seealso cref="DeserializationOptions"/>
    /// </summary>
    /// <param name="serializer">Serializer that performs the deserialization.</param>
    /// <remarks>
    /// <para>
    /// This method demands the following permissions:
    /// <see cref="AdministrationPermission"/>.
    /// It doesn't calls its base method.
    /// Additionaly it checks <see cref="Domain.Status"/> and throws a
    /// <see cref="SecurityException"/> if it doesn't equal to 
    /// <see cref="DomainStatus.InitializingSystemObjects"/>.
    /// </para>
    /// <para>
    /// See <see cref="DataObject.OnGraphDeserialized"/> method description
    /// for additional information.
    /// </para>
    /// </remarks>
    protected override void OnGraphDeserialized(Serializer serializer)
    {
      if (session.domain.status!=DomainStatus.InitializingSystemObjects)
        throw new SecurityException(
          "Instance of this type can be created only during the system " +
          "objects initialization period.");
      Demand(AdministrationPermission.Value);
    }

    /// <summary>
    /// Called before instance is removed (see <see cref="DataObject.Remove"/> method).
    /// Override this method to perform custom actions before the removal 
    /// of instance.
    /// </summary>
    /// <remarks>
    /// <para>
    /// This method demands the following permissions:
    /// <see cref="AdministrationPermission"/>.
    /// It doesn't calls its base method.
    /// Additionaly it checks <see cref="Domain.Status"/> and throws a
    /// <see cref="SecurityException"/> if it doesn't equal to 
    /// <see cref="DomainStatus.InitializingSystemObjects"/>.
    /// </para>
    /// <para>
    /// See <see cref="DataObject.OnRemove"/> method description
    /// for additional information.
    /// </para>
    /// </remarks>
    protected internal override void OnRemove()
    {
      if (session.domain.status!=DomainStatus.InitializingSystemObjects)
        throw new SecurityException(
          "Instance of this type can be removed only during the system " +
          "objects initialization period.");
      Demand(AdministrationPermission.Value);
    }
  }
}
