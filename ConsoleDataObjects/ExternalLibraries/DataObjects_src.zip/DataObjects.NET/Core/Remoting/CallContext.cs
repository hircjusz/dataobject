// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

namespace DataObjects.NET.Remoting
{
  /// <summary>
  /// Contains all information required for succesfull method invocation.
  /// </summary>
  public abstract class CallContext 
    : ISessionBoundObject
  {
    /// <summary>
    /// Gets <see cref="DataObjects.NET.Session"/> to which current instance is bound.
    /// </summary>
    public abstract Session Session {get;}
    
    /// <summary>
    /// Gets <see cref="DataObjects.NET.Domain"/> to which current instance is bound.
    /// </summary>
    public abstract Domain Domain {get;}
  }
}
