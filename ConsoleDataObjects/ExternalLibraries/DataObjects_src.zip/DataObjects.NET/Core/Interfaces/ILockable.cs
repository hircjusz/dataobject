// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Attributes;

namespace DataObjects.NET
{
  /// <summary>
  /// ILockable interface should be implemented by classes, that can
  /// became immutable at some point of time.
  /// </summary>
  public interface ILockable
  {
    /// <summary>
    /// Determines whether the instance of class implementing this interface
    /// is immutable (locked). 
    /// </summary>
    /// <remarks>
    /// The implementor of setter of this property should consider, that this
    /// property shouldn't change its value from true to <see langword="false"/>.
    /// </remarks>
    bool IsLocked {
      get;
    }
    
    /// <summary>
    /// Locks the instance (non-recursive).
    /// </summary>
    void Lock();
    
    /// <summary>
    /// Locks the instance and (possible) all dependent objects.
    /// </summary>
    /// <param name="recursive"><see langword="True"/> if all dependent objects should be locked too.</param>
    void Lock(bool recursive);
  }
}
