// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;

namespace DataObjects.NET.Attributes
{
  /// <summary>
  /// Indicates property\method can't be overriden.
  /// </summary>
  /// <remarks>
  /// <note>This attribute can be applied to virtual methods of persistent types
  /// (<see cref="DataObject"/> descendants) or services
  /// (<see cref="DataService"/> descendants).</note>
  /// <para>
  /// You should use this attribute when it's necessary
  /// to disable possible override of some virtual 
  /// method\property in descendants. 
  /// </para>
  /// <para>
  /// Some methods\properties of your classes should be virtual
  /// because they require automatic transactions service, that
  /// can be provided by DataObjects.NET. DataObjects.NET overrides
  /// these methods\properties in proxy classes to provide
  /// desired services.
  /// </para>
  /// <para>
  /// So if you should declare method as virtual (to provide
  /// automatic transactions support for it), but don't want
  /// to give opportunity to override it in descendants (for
  /// any descendant except proxy class), you should use
  /// this attribute. In this case DataObjects.NET will throw
  /// an exception during  <see cref="Domain.Build"/> execution
  /// if it discover this method was overriden.
  /// </para>
  /// <para>
  /// <example>Example:
  /// <code lang="C#">
  ///  public abstract class Article: DataObject
  ///  {
  ///    ...
  ///
  ///    [NotOverridable] // !!!
  ///    [Transactional(TransactionMode.TransactionRequired)]
  ///    public virtual Book ConvertToBook()
  ///    {
  ///      ...
  ///    }
  ///    
  ///    ...
  ///  }
  /// </code>
  /// </example>
  /// </para>
  /// <seealso cref="AbstractAttribute"/>
  /// <seealso cref="SealedAttribute"/>
  /// <seealso cref="TransactionalAttribute"/>
  /// </remarks>
  [AttributeUsage(AttributeTargets.Property | AttributeTargets.Method, AllowMultiple = false, Inherited = true)]
  [Serializable]
  public class NotOverridableAttribute: DataObjectAttribute
  {
    /// <summary>
    /// Always <see langword="true"/>.
    /// </summary>
    public  bool NotOverridable 
    {
      get {return true;}
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    public NotOverridableAttribute() 
    {
    }
  }
}
