// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using DataObjects.NET;
using DataObjects.NET.Caching;
using DataObjects.NET.Diagnostics;

namespace DataObjects.NET.Database
{
  /// <summary>
  /// Holds the information required to instantiate a particular
  /// <see cref="DataObject"/> without additional queries.
  /// Exactly this is the set of <see cref="DataObject"/> properties 
  /// fetched from <see cref="DataObject"/>-related table by the 
  /// ID of instance.
  /// </summary>
  public sealed class DataObjectInstantiationInfo
    : DataObjectValidationInfo,
      IGlobalCacheItem
  {
    private static TransactionContext dummyTransactionContext = 
      TransactionContext.CreateGlobalRequireVersionCheckContext();
      
    /// <summary>
    /// <see cref="DataObject.TypeID"/> property value.
    /// </summary>
    public int    TypeID;

    /// <summary>
    /// Permissions data.
    /// </summary>
    public byte[] Permissions;
    
    /// <summary>
    /// FastLoadData.
    /// </summary>
    public byte[] FastLoadData;
    
#if (!EXPRESS && !STANDARD)    
    /// <summary>
    /// Dependency parent <see cref="DataObject.ID"/> or 0 if
    /// dependency parent isn't used.
    /// </summary>
    public long DependencyParentID;
    
    /// <summary>
    /// Dependency parent <see cref="DataObject.VersionID"/> or 0 if
    /// dependency parent isn't used.
    /// </summary>
    public int DependencyParentVersionID;
#endif

    /// <summary>
    /// Gets information about the source of this object.
    /// This value is used by e.g. classes from <see cref="DataObjects.NET.Diagnostics"/>
    /// namespace.
    /// </summary>
    public InstantiationInfoSource Source = 
      InstantiationInfoSource.Database;

    /// <summary>
    /// <see langword="True"/>, if this instantiation info 
    /// was validated with an additional query.
    /// </summary>
    public bool ValidatedByQuery = false;

    /// <summary>
    /// <see langword="True"/>, if this instantiation info 
    /// was loaded with an additional query.
    /// </summary>
    public bool LoadDenied = false;

    /// <summary>
    /// Returns estimated size of this object in bytes.
    /// </summary>
    public override int Size {
      get {
        return 12 + 8 + 20 +
          (Permissions==null  ? 0 : 8+Permissions.Length) + 
          (FastLoadData==null ? 0 : 8+FastLoadData.Length);
      }
    }

//SM begin
      private DateTime startedOn;
      public DateTime StartedOn
      {
          get { return startedOn; }
      }
//SM end

    internal void RegisterUsage(DomainPerformanceCounters performanceCounters)
    {
      if (Source==InstantiationInfoSource.SessionCache &&
          ValidatedByQuery==false)
        return; // There is nothing to register in this case

      performanceCounters.RegisterCacheHit(Source, ValidatedByQuery);
      Source = InstantiationInfoSource.SessionCache;
      ValidatedByQuery = false;
    }
    
    /// <summary>
    /// Gets item type.
    /// </summary>
    GlobalCacheItemType IGlobalCacheItem.ItemType {
      get {
        return GlobalCacheItemType.DataObjectInstance;
      }
    }
    
    /// <summary>
    /// Gets a value indicating whether current item can be cached.
    /// </summary>
    bool IGlobalCacheItem.CanCache {
      get {
        if (TransactionContext!=null) {
          Transaction t = TransactionContext.Transaction;
          if (t!=null && t.IsReadOnly && TransactionContext.State==TransactionContextState.Valid)
            return true;
        }
        return false;
      }
    }
    
    /// <summary>
    /// This method is called when item is placed into global cache.
    /// </summary>
    void IGlobalCacheItem.OnCached()
    {
      this.TransactionContext = dummyTransactionContext;
      this.Source             = InstantiationInfoSource.GlobalCache;
      this.ValidatedByQuery   = false;
    }
    
    /// <summary>
    /// This method is called when item is validated by validation info.
    /// </summary>
    /// <param name="vInfo">Validation info.</param>
    void IGlobalCacheItem.OnValidated(IGlobalCacheItemValidationInfo vInfo)
    {
      this.TransactionContext = ((DataObjectValidationInfo)vInfo).TransactionContext;
    }
    
    /// <summary>
    /// Creates a new object that is a copy of the current instance.
    /// </summary>
    /// <returns>A new object that is a copy of this instance.</returns>
    object ICloneable.Clone()
    {
      DataObjectInstantiationInfo clone = new DataObjectInstantiationInfo();
      clone.ID                          = this.ID;
      clone.TypeID                      = this.TypeID;
      clone.VersionID                   = this.VersionID;
      clone.Permissions                 = this.Permissions;
      clone.FastLoadData                = this.FastLoadData;
      clone.TransactionContext          = this.TransactionContext;
      clone.Source                      = this.Source;
      clone.ValidatedByQuery            = this.ValidatedByQuery;
#if (!EXPRESS && !STANDARD)
      clone.DependencyParentID          = this.DependencyParentID;
      clone.DependencyParentVersionID   = this.DependencyParentVersionID;
#endif
      //SM begin
      clone.startedOn = this.startedOn;
      //SM end
      return clone;
    }


    // Constructors
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    public DataObjectInstantiationInfo()
    {
        //SM begin
        this.startedOn = DateTime.Now;
        //SM end
    }
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="ID">Initial <see cref="DataObjectIdentificationInfo.ID"/> value.</param>
    /// <param name="TypeID">Initial <see cref="TypeID"/> value.</param>
    /// <param name="VersionID">Initial <see cref="DataObjectValidationInfo.VersionID"/> value.</param>
    /// <param name="Permissions">Initial <see cref="Permissions"/> value.</param>
    /// <param name="FastLoadData">Initial <see cref="FastLoadData"/> value.</param>
    /// <param name="TransactionContext">Initial <see cref="TransactionContext"/> value.</param>
    public DataObjectInstantiationInfo(
      long   ID,
      int    TypeID,
      int    VersionID,
      byte[] Permissions,
      byte[] FastLoadData,
      TransactionContext TransactionContext
        ): base(ID, VersionID, TransactionContext)
    {
      this.ID                        = ID;
      this.TypeID                    = TypeID;
      this.VersionID                 = VersionID;
      this.Permissions               = Permissions;
      this.FastLoadData              = FastLoadData;
      //SM begin
      this.startedOn = DateTime.Now;
      //SM end
#if (!EXPRESS && !STANDARD)
      this.DependencyParentID        = 0;
      this.DependencyParentVersionID = 0;
#endif
    }
  }
}
