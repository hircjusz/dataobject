// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;
using System.Data;
using System.Reflection;
using DataObjects.NET.Exceptions;
using DataObjects.NET.ObjectModel;

namespace DataObjects.NET.Data
{
  /// <summary>
  /// <see cref="FieldTranslator"/> is used to get and set 
  /// subfields of the structure, subfields of subfields and so on.
  /// The target field of this translator is established using dotted path:
  /// "FieldName[.FieldName[.FieldName[...]]]".
  /// </summary>
  internal class FieldTranslator
  {
    private VtCollectionTranslator vtcTranslator;
    private string path;
    private FieldInfo[] preFieldInfos;
    private FieldInfo targetFieldInfo;
    private DataColumn dataColumn;
    private System.Type targetType;
    
    /// <summary>
    /// Gets path associated with the translator.
    /// </summary>
    public string Path {
      get {
        return path;
      }
    }
    
    /// <summary>
    /// Gets <see cref="DataColumn"/> associated with the translator.
    /// </summary>
    public DataColumn DataColumn {
      get {
        return dataColumn;
      }
    }
    
    /// <summary>
    /// Fills specified <see cref="Object"/> into the <see cref="DataRow"/>.
    /// </summary>
    /// <param name="obj"><see cref="Object"/> to fill.</param>
    /// <param name="dataRow">Target <see cref="DataRow"/>.</param>
    public void Fill(object obj, DataRow dataRow)
    {
      object value = GetValue(obj);
      if (value is DataObject) {
        DataObject doVal = (DataObject)value;
        if (vtcTranslator.Adapter.FillQueue.GetObjectFillState(doVal)==DataObjectFillState.NotQueued) {
          EnqueueObjectEventArgs e = new EnqueueObjectEventArgs(vtcTranslator.Adapter, doVal.ID);
          vtcTranslator.Adapter.Internal_OnEnqueueObject(e);
          if (e.Enqueue)
            vtcTranslator.Adapter.FillQueue.Enqueue(doVal);
        }
        value = doVal.ID;
      }
      dataRow[dataColumn] = (value==null) ? System.DBNull.Value : value;
    }
    
    /// <summary>
    /// Updates specified <see cref="ValueTypeCollectionEntry"/> from the <see cref="DataRow"/>.
    /// </summary>
    /// <param name="entry"><see cref="ValueTypeCollectionEntry"/> to update.</param>
    /// <param name="dataRow">Source <see cref="DataRow"/>.</param>
    public void Update(ValueTypeCollectionEntry entry, DataRow dataRow)
    {
      entry.Value = Update(entry.Value, dataRow);
    }
    
    /// <summary>
    /// Updates specified <see cref="Object"/> from the <see cref="DataRow"/>.
    /// </summary>
    /// <param name="obj"><see cref="Object"/> to update.</param>
    /// <param name="dataRow">Source <see cref="DataRow"/>.</param>
    /// <returns>Updated <see cref="Object"/>.</returns>
    public object Update(object obj, DataRow dataRow)
    {
      object value = dataRow[dataColumn];
      if (System.DBNull.Value.Equals(value))
        value = null;
      if (typeof(DataObject).IsAssignableFrom(targetType)) {
        if (value!=null) {
          long id = (long)value;
          value = null;
          if (id!=0) {
            value = (id>0) ? 
              vtcTranslator.Adapter.Session[id] : 
              vtcTranslator.Adapter.UpdateQueue.GetCreatedObject(id);
            if (value==null)
              throw new AdapterException(
                String.Format("DataObject with ID=\"{0}\" is not found.", id));
          }
        }
      }
      
      SetValue(obj, value);
      
      return obj;
    }
    
    /// <summary>
    /// Returns a value of a target field 
    /// this <see cref="FieldTranslator"/> represents.
    /// </summary>
    /// <param name="obj"><see cref="Object"/> from which to extract value.</param>
    /// <returns>A value of a target field this <see cref="FieldTranslator"/> represents.</returns>
    private object GetValue(object obj)
    {
      if (obj==null)
        throw new ArgumentNullException("obj");
        
      if (preFieldInfos!=null) {
        TypedReference tr = TypedReference.MakeTypedReference(obj, preFieldInfos);
        return targetFieldInfo.GetValueDirect(tr);
      }
      return targetFieldInfo.GetValue(obj);
    }
    
    /// <summary>
    /// Sets a value of a target field 
    /// this <see cref="FieldTranslator"/> represents.
    /// </summary>
    /// <param name="obj"><see cref="Object"/> whose field to set.</param>
    /// <param name="value">A value of a field.</param>
    private void SetValue(object obj, object value)
    {
      if (obj==null)
        throw new ArgumentNullException("obj");
        
      if (preFieldInfos!=null) {
        TypedReference tr = TypedReference.MakeTypedReference(obj, preFieldInfos);
        targetFieldInfo.SetValueDirect(tr, value);
      } else {
        targetFieldInfo.SetValue(obj, value);
      }
    }
    
    /// <summary>
    /// Initializes a new instance of the <see cref="FieldTranslator"/> class.
    /// </summary>
    /// <param name="vtcTranslator">Parent <see cref="ValueTypeCollection"/> translator.</param>
    /// <param name="mappingItem">Field mapping item.</param>
    internal FieldTranslator(VtCollectionTranslator vtcTranslator, FieldMappingItem mappingItem)
    {
      if (vtcTranslator==null)
        throw new ArgumentNullException("vtcTranslator");
      if (mappingItem==null)
        throw new ArgumentNullException("mappingItem");
      if (mappingItem.FieldName==null)
        throw new NullReferenceException("mappingItem.FieldName is null.");
      if (mappingItem.ColumnName==null)
        throw new NullReferenceException("mappingItem.ColumnName is null.");
        
      if (mappingItem.ColumnName=="ID" || mappingItem.ColumnName==ValueTypeCollectionField.DefaultOwnerName)
        throw new AdapterException(
          String.Format("Column \"{0}\" is reserved and can not be used.", mappingItem.ColumnName));

      this.vtcTranslator = vtcTranslator;        
      this.path = mappingItem.FieldName;
      
      if (!vtcTranslator.DataTable.Columns.Contains(mappingItem.ColumnName))
        throw new AdapterException(
          String.Format("Column \"{0}\" does not exists.", mappingItem.ColumnName));
      dataColumn = vtcTranslator.DataTable.Columns[mappingItem.ColumnName];
      
      string[] pathPart = path.Split(new char[] {'.'});
      
      int cnt = pathPart.Length - 1;
      
      targetType = vtcTranslator.ItemType;
      if (cnt>0) {
        preFieldInfos = new FieldInfo[cnt];
        for (int i = 0; i < cnt; i++) {
          FieldInfo fieldInfo = targetType.GetField(pathPart[i]);
          if (fieldInfo==null)
            throw new AdapterException(
              String.Format("Field \"{0}\" does not exists.", pathPart[i]));
          preFieldInfos[i] = fieldInfo;
          targetType = fieldInfo.FieldType;
        }
      }
      targetFieldInfo = targetType.GetField(pathPart[cnt]);
      if (targetFieldInfo==null)
        throw new AdapterException(
          String.Format("Field \"{0}\" does not exists.", pathPart[cnt]));
      targetType = targetFieldInfo.FieldType;
    }
  }
}
