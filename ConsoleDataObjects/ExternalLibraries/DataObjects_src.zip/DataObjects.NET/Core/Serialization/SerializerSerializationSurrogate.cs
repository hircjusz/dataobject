// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;
using System.Runtime.Serialization;
using DataObjects.NET.Security;

namespace DataObjects.NET.Serialization
{
  /// <summary>
  /// This is an implementation of <see cref="ISerializationSurrogate"/> 
  /// that provides serialization of the <see cref="DataObject"/> 
  /// instances.
  /// Used internally by <see cref="Serializer"/>.
  /// </summary>
  public sealed class SerializerSerializationSurrogate: ISerializationSurrogate
  {
    private  Serializer serializer;
    /// <summary>
    /// Serializer of the surrogate.
    /// </summary>
    public   Serializer Serializer {
      get {
        return serializer;
      }
    }
    
    /// <summary>
    /// Session of the surrogate.
    /// </summary>
    public  Session Session {
      get {
        return serializer.session;
      }
    }
    
    /// <summary>
    /// Serializes the <see cref="DataObject"/> instance.
    /// </summary>
    /// <param name="obj">Instance to serialize.</param>
    /// <param name="info">The <see cref="SerializationInfo"/> to populate with data. </param>
    /// <param name="context">The destination (see <see cref="StreamingContext"/>) for this serialization.</param>
    public void GetObjectData(object obj, SerializationInfo info, StreamingContext context)
    {
      DataObject dObj = (DataObject)obj;
      dObj.GetDataObjectData(serializer, info, context);
    }
    
    /// <summary>
    /// Deserializes <see cref="DataObject"/> and <see cref="DataObjectReference"/> 
    /// instances.
    /// </summary>
    /// <param name="obj">Unititialized object to deserialize.</param>
    /// <param name="info">The information to populate the object.</param>
    /// <param name="context">The source from which the object is deserialized.</param>
    /// <param name="selector">The surrogate selector where the search for a compatible surrogate begins.</param>
    /// <returns>Deserialized <see cref="DataObject"/> or <see cref="DataObjectReference"/> instance.</returns>
    public object SetObjectData(object obj, SerializationInfo info, StreamingContext context, ISurrogateSelector selector)
    {
      Session session      = serializer.session;
      Hashtable hProcessed = serializer.hProcessed;
      bool bExtRefsAllowed = (serializer.deserializationOptions & DeserializationOptions.EnableExternalReferences)!=0;
      bool bOverwriteMode  = (serializer.deserializationOptions & DeserializationOptions.EnableOverwrite)!=0;
      
      long               id = info.GetInt64("ID");
      string       typeName = info.GetString("Type");
      ObjectModel.Type type = session.Types[typeName];

      if (type==null)
        throw new SerializationException("Unknown type: "+typeName);
      if (type.IsAbstract)
        throw new SerializationException(
          String.Format("Type \"{0}\" is an interface or an abstract type.",typeName));

      if (obj.GetType()==typeof(DataObjectReference)) {
        DataObjectReference rObj = (DataObjectReference)obj;
        DataObject dObj = null;
        if (type.Interfaces[typeof(ISecurityRoot)]!=null) {
          // ISecurityRoot is deserialized by a special way - 
          // its ID is ignored.
          dObj = session.SecurityRoot;
          rObj.realObject = dObj;
          return rObj;
        }
        dObj = session.GetNullObject(type.SourceType);
        if (bExtRefsAllowed) {
          DataObject deserializationResult = dObj.OnDeserializeIdentity(serializer, info, context);
          session.OnDataObjectDeserializeIdentity(dObj, ref deserializationResult, serializer, info, context);
          dObj = deserializationResult;
          if (dObj==null)
            dObj = session.GetNullObject(type.SourceType);
          else {
            if (hProcessed[id]!=null)
              dObj = session.GetNullObject(type.SourceType);
            else
              serializer.lastOperationReferenceCount++;
          }
        }
        rObj.realObject = dObj;
        return rObj;
      }
      else {
        DataObject dObj = (DataObject)obj;
        if (dObj is ISecurityRoot)
          throw new SerializationException("ISecurityRoot object can't be deserialized.");
        DataObject oldObj = null;
        if (bOverwriteMode && serializer.hProcessed[id]==null) {
          DataObject nullObj = session.GetNullObject(obj.GetType().BaseType);
          oldObj = nullObj.OnDeserializeIdentity(serializer, info, context);
          session.OnDataObjectDeserializeIdentity(nullObj, ref oldObj, serializer, info, context);
        }
        if (oldObj!=null)
          oldObj.Remove();
        dObj.InitDeserializable(type, session, serializer);
        hProcessed[dObj.ID] = dObj;
        dObj.SetDataObjectData(serializer, info, context);
        serializer.lastOperationInstanceCount++;
        return dObj;
      }
    }
    
    /// <summary>
    /// Initializes an instance of this class.
    /// </summary>
    /// <param name="serializer">Serializer of the surrogate.</param>
    public SerializerSerializationSurrogate(Serializer serializer)
    {
      if (serializer==null)
        throw new ArgumentNullException("serializer");
      this.serializer = serializer;
    }
  }
}
