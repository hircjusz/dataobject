// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Data;
using DataObjects.NET;
using DataObjects.NET.Data;

namespace DataObjects.NET.Data
{
  /// <summary>
  /// Provides information for <see cref="Adapter.CreateVtcItem"/> event.
  /// </summary>
  public class CreateVtcItemEventArgs: EventArgs
  {
    private System.Type type;
    private DataRow dataRow;
    private object value;
    
    /// <summary>
    /// Gets a target <see cref="ValueTypeCollection"/> item type.
    /// </summary>
    public System.Type Type {
      get {
        return type;
      }
    }
    
    /// <summary>
    /// Gets <see cref="DataRow"/> that contains data for further item update.
    /// </summary>
    public DataRow DataRow {
      get {
        return dataRow;
      }
    }
    
    /// <summary>
    /// Gets or set newly created item.
    /// </summary>
    public object Value {
      get {
        return this.value;
      }
      set {
        this.value = value;
      }
    }
  
    /// <summary>
    /// Initializes a new instance of the <see cref="CreateVtcItemEventArgs"/> class.
    /// </summary>
    /// <param name="type"></param>
    /// <param name="dataRow"></param>
    internal CreateVtcItemEventArgs(System.Type type, DataRow dataRow)
    {
      if (type==null)
        throw new ArgumentNullException("type");
      if (dataRow==null)
        throw new ArgumentNullException("dataRow");
        
      this.type = type;
      this.dataRow = dataRow;
    }
  }
}
