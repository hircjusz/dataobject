// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Data;
using DataObjects.NET;
using DataObjects.NET.Data;

namespace DataObjects.NET.Data
{
  /// <summary>
  /// Provides information for <see cref="Adapter.EnqueueObject"/> event.
  /// </summary>
  public class EnqueueObjectEventArgs
  {
    private Adapter adapter;
    private long id;
    private bool enqueue;
    
    /// <summary>
    /// Gets the <see cref="DataObject"/> which will be enqueued.
    /// </summary>
    public DataObject DataObject {
      get {
        return adapter.Session[id];
      }
    }
    
    /// <summary>
    /// Gets the ID of a <see cref="DataObject"/> which will be enqueued.
    /// </summary>
    public long DataObjectID {
      get {
        return id;
      }
    }
 
    /// <summary>
    /// Gets or sets a value indicating whether <see cref="Adapter"/> should enqueue 
    /// the <see cref="DataObject"/> to the <see cref="Adapter"/>' fill queue for
    /// further filling or not.
    /// </summary>
    public bool Enqueue {
      get {
        return enqueue;
      }
      set {
        enqueue = value;
      }
    }
    
    /// <summary>
    /// Initializes a new instance of the <see cref="EnqueueObjectEventArgs"/> class.
    /// </summary>
    /// <param name="adapter"><see cref="Adapter"/> which is used to fill the object.</param>
    /// <param name="id"><see cref="DataObject"/>'s ID.</param>
    /// <param name="enqueue">Suggested <see cref="Adapter"/> behaviour. <seealso cref="Enqueue"/>.</param>
    internal EnqueueObjectEventArgs(Adapter adapter, long id, bool enqueue)
    {
      if (adapter==null)
        throw new ArgumentNullException("adapter");
        
      this.adapter = adapter;
      this.id = id;
      this.enqueue = enqueue;
    }

    /// <summary>
    /// Initializes a new instance of the <see cref="EnqueueObjectEventArgs"/> class.
    /// </summary>
    /// <param name="adapter"><see cref="Adapter"/> which is used to fill the object.</param>
    /// <param name="id"><see cref="DataObject"/>'s ID.</param>    
    internal EnqueueObjectEventArgs(Adapter adapter, long id): this(adapter, id, true) 
    {
    }
  }
}
