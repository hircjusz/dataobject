// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;
using DataObjects.NET.Attributes;
using DataObjects.NET.Internals;
using DataObjects.NET.ObjectModel;
using Type = System.Type;

namespace DataObjects.NET.Services
{
  /// <summary>
  /// Provides reference search services.
  /// </summary>
  [ServiceType(DataServiceType.Shared)]
  public abstract class ReferenceSearchService: DataService
  {
    /// <summary>
    /// Locates <see cref="DataObject"/> instances that contain
    /// references to the specified target.
    /// </summary>
    /// <param name="target"><see cref="DataObject"/> which is reference target.</param>
    /// <returns>
    /// Returns an <see cref="QueryResult"/> populated with 
    /// <see cref="DataObject"/> instances containing references
    /// to the specified target.
    /// </returns>
    [Transactional(TransactionMode.Disabled)]
    public QueryResult FindReferers(DataObject target)
    {
      return FindReferers(typeof(DataObject), target, null);
    }
    
    /// <summary> 
    /// Locates <see cref="DataObject"/> instances that contain 
    /// references to the specified target. 
    /// </summary> 
    /// <param name="target"><see cref="DataObject"/> which is reference target.</param> 
    /// <param name="byFields">An <see cref="Array"/> of <see cref="Field"/>s to check for references on.</param> 
    /// <returns> 
    /// Returns an <see cref="QueryResult"/> populated with 
    /// <see cref="DataObject"/> instances containing references 
    /// to the specified target. 
    /// </returns> 
    [Transactional(TransactionMode.Disabled)] 
    public QueryResult FindReferers(DataObject target, Field[] byFields) 
    { 
      return FindReferers(typeof(DataObject), target, byFields); 
    } 
     
    /// <summary> 
    /// Locates <see cref="DataObject"/> instances that contain
    /// references to the specified target.
    /// </summary>
    /// <param name="refererType"><see cref="Type"/> of referes.</param>
    /// <param name="target"><see cref="DataObject"/> which is reference target.</param>
    /// <returns>
    /// Returns an <see cref="QueryResult"/> populated with 
    /// <see cref="DataObject"/> instances containing references
    /// to the specified target.
    /// </returns>
    [Transactional(TransactionMode.Disabled)]
    public QueryResult FindReferers(Type refererType, DataObject target)
    {
      return FindReferers(refererType, target, null);
    }
    
    /// <summary> 
    /// Locates <see cref="DataObject"/> instances that contain 
    /// references to the specified target. 
    /// </summary> 
    /// <param name="refererType"><see cref="Type"/> of referes.</param> 
    /// <param name="target"><see cref="DataObject"/> which is reference target.</param> 
    /// <param name="byFields">An <see cref="Array"/> of <see cref="Field"/>s to check for references on.</param> 
    /// <returns> 
    /// Returns an <see cref="QueryResult"/> populated with 
    /// <see cref="DataObject"/> instances containing references 
    /// to the specified target. 
    /// </returns> 
    [Transactional(TransactionMode.Disabled)] 
    public QueryResult FindReferers(Type refererType, DataObject target, Field[] byFields) 
    { 
      if (refererType==null)
        throw new ArgumentNullException("refererType");
      if (target==null) 
        throw new ArgumentNullException("target"); 
      ObjectModel.Type omRefererType = Domain.objectModel.Types[refererType]; 
      return FindReferers(omRefererType, target.Type, new long[] {target.ID}, byFields); 
    } 
    
    /// <summary> 
    /// Locates <see cref="DataObject"/> instances that contain
    /// references to the specified targets.
    /// </summary>
    /// <param name="targets"><see cref="Array"/> of reference targets.</param>
    /// <returns>
    /// Returns an <see cref="QueryResult"/> populated with 
    /// <see cref="DataObject"/> instances containing references
    /// to the specified targets.
    /// </returns>
    [Transactional(TransactionMode.Disabled)]
    public QueryResult FindReferers(DataObject[] targets)
    {
      return FindReferers(typeof(DataObject), targets, null);
    }

    /// <summary> 
    /// Locates <see cref="DataObject"/> instances that contain 
    /// references to the specified target. 
    /// </summary> 
    /// <param name="targets"><see cref="Array"/> of reference targets.</param>
    /// <param name="byFields">An <see cref="Array"/> of <see cref="Field"/>s to check for references on.</param> 
    /// <returns> 
    /// Returns an <see cref="QueryResult"/> populated with 
    /// <see cref="DataObject"/> instances containing references 
    /// to the specified target. 
    /// </returns> 
    [Transactional(TransactionMode.Disabled)] 
    public QueryResult FindReferers(DataObject[] targets, Field[] byFields) 
    { 
      return FindReferers(typeof(DataObject), targets, byFields); 
    } 

    /// <summary>
    /// Locates <see cref="DataObject"/> instances that contain
    /// references to the specified targets.
    /// </summary>
    /// <param name="refererType"><see cref="Type"/> of referes.</param>
    /// <param name="targets"><see cref="Array"/> of reference targets.</param>
    /// <returns>
    /// Returns an <see cref="QueryResult"/> populated with 
    /// <see cref="DataObject"/> instances containing references
    /// to the specified targets.
    /// </returns>
    [Transactional(TransactionMode.Disabled)]
    public QueryResult FindReferers(Type refererType, DataObject[] targets)
    {
      return FindReferers(refererType, targets, null); 
    }

    /// <summary>
    /// Locates <see cref="DataObject"/> instances that contain
    /// references to the specified targets.
    /// </summary>
    /// <param name="refererType"><see cref="Type"/> of referes.</param>
    /// <param name="targets"><see cref="Array"/> of reference targets.</param>
    /// <param name="byFields">An <see cref="Array"/> of <see cref="Field"/>s to check for references on.</param> 
    /// <returns>
    /// Returns an <see cref="QueryResult"/> populated with 
    /// <see cref="DataObject"/> instances containing references
    /// to the specified targets.
    /// </returns>
    [Transactional(TransactionMode.Disabled)]
    public QueryResult FindReferers(Type refererType, DataObject[] targets, Field[] byFields)
    {
      if (targets==null)
        throw new ArgumentNullException("targets");
      ArrayList idList  = new ArrayList();
      Hashtable hsTypes = new Hashtable();
      for (int targetIndex=0, targetCount=targets.Length; targetIndex<targetCount; targetIndex++) {
        DataObject target = targets[targetIndex];
        if (target!=null) {
          hsTypes[target.GetType()] = hsTypes;
          idList.Add(target.ID);
        }
      }
      Type[] types = new Type[hsTypes.Count];
      hsTypes.Keys.CopyTo(types, 0);
      Type referencedType = TypeUtils.FindCommonAncestor(types);
      
      long[] ids = new long[idList.Count];
      idList.CopyTo(ids);
      return FindReferers(refererType, referencedType, ids, byFields);
    }

    /// <summary>
    /// Locates <see cref="DataObject"/> instances that contain
    /// references to the specified targets.
    /// </summary>
    /// <param name="refererType"><see cref="Type"/> of referes.</param>
    /// <param name="referencedType"><see cref="Type"/> of reference targets.</param>
    /// <param name="targets"><see cref="Array"/> of reference targets.</param>
    /// <returns>
    /// Returns an <see cref="QueryResult"/> populated with 
    /// <see cref="DataObject"/> instances containing references
    /// to the specified targets.
    /// </returns>
    [Transactional(TransactionMode.Disabled)]
    public QueryResult FindReferers(Type refererType, Type referencedType, DataObject[] targets)
    {
      return FindReferers(refererType, referencedType, targets, null);
    }

    /// <summary>
    /// Locates <see cref="DataObject"/> instances that contain
    /// references to the specified targets.
    /// </summary>
    /// <param name="refererType"><see cref="Type"/> of referes.</param>
    /// <param name="referencedType"><see cref="Type"/> of reference targets.</param>
    /// <param name="targets"><see cref="Array"/> of reference targets.</param>
    /// <param name="byFields">An <see cref="Array"/> of <see cref="Field"/>s to check for references on.</param> 
    /// <returns>
    /// Returns an <see cref="QueryResult"/> populated with 
    /// <see cref="DataObject"/> instances containing references
    /// to the specified targets.
    /// </returns>
    [Transactional(TransactionMode.Disabled)]
    public QueryResult FindReferers(Type refererType, Type referencedType, DataObject[] targets, Field[] byFields)
    {
      if (targets==null)
        throw new ArgumentNullException("targets");
      ArrayList idList = new ArrayList();
      for (int targetIndex=0, targetCount=targets.Length; targetIndex<targetCount; targetIndex++) {
        DataObject target = targets[targetIndex];
        if (target!=null)
          idList.Add(target.ID);
      }
      long[] ids = new long[idList.Count];
      idList.CopyTo(ids);
      return FindReferers(refererType, referencedType, ids, byFields);
    }

    /// <summary>
    /// Locates <see cref="DataObject"/> instances that contain
    /// references to the specified targets.
    /// </summary>
    /// <param name="refererType"><see cref="Type"/> of referes.</param>
    /// <param name="referencedType"><see cref="Type"/> of reference targets.</param>
    /// <param name="queryResult"><see cref="QueryResult"/> populated with reference targets.</param>
    /// <returns>
    /// Returns an <see cref="QueryResult"/> populated with 
    /// <see cref="DataObject"/> instances containing references
    /// to the specified targets.
    /// </returns>
    [Transactional(TransactionMode.Disabled)]
    public QueryResult FindReferers(Type refererType, Type referencedType, QueryResult queryResult)
    {
      return FindReferers(refererType, referencedType, queryResult, null);
    }

    /// <summary>
    /// Locates <see cref="DataObject"/> instances that contain
    /// references to the specified targets.
    /// </summary>
    /// <param name="refererType"><see cref="Type"/> of referes.</param>
    /// <param name="referencedType"><see cref="Type"/> of reference targets.</param>
    /// <param name="queryResult"><see cref="QueryResult"/> populated with reference targets.</param>
    /// <param name="byFields">An <see cref="Array"/> of <see cref="Field"/>s to check for references on.</param> 
    /// <returns>
    /// Returns an <see cref="QueryResult"/> populated with 
    /// <see cref="DataObject"/> instances containing references
    /// to the specified targets.
    /// </returns>
    [Transactional(TransactionMode.Disabled)]
    public QueryResult FindReferers(Type refererType, Type referencedType, QueryResult queryResult, Field[] byFields)
    {
      if (queryResult==null)
        throw new ArgumentNullException("queryResult");
      return FindReferers(refererType, referencedType, queryResult.GetIDs(), byFields);
    }

    /// <summary>
    /// Locates <see cref="DataObject"/> instances that contain
    /// references to the specified target.
    /// </summary>
    /// <param name="refererType"><see cref="Type"/> of referes.</param>
    /// <param name="referencedType"><see cref="Type"/> of reference targets.</param>
    /// <param name="targetId">Identifier of reference target.</param>
    /// <returns>
    /// Returns an <see cref="QueryResult"/> populated with 
    /// <see cref="DataObject"/> instances containing references
    /// to the specified target.
    /// </returns>
    [Transactional(TransactionMode.Disabled)]
    public QueryResult FindReferers(Type refererType, Type referencedType, long targetId)
    {
      return FindReferers(refererType, referencedType, new long[] {targetId});
    }
    
    /// <summary>
    /// Locates <see cref="DataObject"/> instances that contain
    /// references to the specified target.
    /// </summary>
    /// <param name="refererType"><see cref="Type"/> of referes.</param>
    /// <param name="referencedType"><see cref="Type"/> of reference targets.</param>
    /// <param name="targetId">Identifier of reference target.</param>
    /// <param name="byFields">An <see cref="Array"/> of <see cref="Field"/>s to check for references on.</param> 
    /// <returns>
    /// Returns an <see cref="QueryResult"/> populated with 
    /// <see cref="DataObject"/> instances containing references
    /// to the specified target.
    /// </returns>
    [Transactional(TransactionMode.Disabled)]
    public QueryResult FindReferers(Type refererType, Type referencedType, long targetId, Field[] byFields)
    {
      return FindReferers(refererType, referencedType, new long[] {targetId}, byFields);
    }

    /// <summary>
    /// Locates <see cref="DataObject"/> instances that contain
    /// references to the specified targets.
    /// </summary>
    /// <param name="refererType"><see cref="Type"/> of referes.</param>
    /// <param name="referencedType"><see cref="Type"/> of reference targets.</param>
    /// <param name="targetIds"><see cref="Array"/> of reference target identifiers.</param>
    /// <returns>
    /// Returns an <see cref="QueryResult"/> populated with 
    /// <see cref="DataObject"/> instances containing references
    /// to the specified targets.
    /// </returns>
    [Transactional(TransactionMode.Disabled)]
    public QueryResult FindReferers(Type refererType, Type referencedType, long[] targetIds)
    {
      return FindReferers(refererType, referencedType, targetIds, null);
    }
    
    /// <summary>
    /// Locates <see cref="DataObject"/> instances that contain
    /// references to the specified targets.
    /// </summary>
    /// <param name="refererType"><see cref="Type"/> of referes.</param>
    /// <param name="referencedType"><see cref="Type"/> of reference targets.</param>
    /// <param name="targetIds"><see cref="Array"/> of reference target identifiers.</param>
    /// <param name="byFields">An <see cref="Array"/> of <see cref="Field"/>s to check for references on.</param> 
    /// <returns>
    /// Returns an <see cref="QueryResult"/> populated with 
    /// <see cref="DataObject"/> instances containing references
    /// to the specified targets.
    /// </returns>
    [Transactional(TransactionMode.Disabled)]
    public QueryResult FindReferers(Type refererType, Type referencedType, long[] targetIds, Field[] byFields)
    {
      if (refererType==null)
        throw new ArgumentNullException("refererType");
      if (referencedType==null)
        throw new ArgumentNullException("referencedType");
      if (targetIds==null)
        throw new ArgumentNullException("targetIds");
      ObjectModel.Type omRefererType = Domain.objectModel.Types[refererType];
      ObjectModel.Type omReferencedType = Domain.objectModel.Types[referencedType];
      return FindReferers(omRefererType, omReferencedType, targetIds, byFields);
    }

    /// <summary>
    /// Locates <see cref="DataObject"/> instances that contain
    /// references to the specified targets.
    /// </summary>
    /// <param name="omRefererType"><see cref="ObjectModel.Type"/> of referes.</param>
    /// <param name="omReferencedType"><see cref="ObjectModel.Type"/> of reference targets.</param>
    /// <param name="targetIds"><see cref="Array"/> of reference target identifiers.</param>
    /// <returns>
    /// Returns an <see cref="QueryResult"/> populated with 
    /// <see cref="DataObject"/> instances containing references
    /// to the specified targets.
    /// </returns>
    [Transactional(TransactionMode.NewTransactionRequired)]
    protected virtual QueryResult FindReferers(ObjectModel.Type omRefererType, ObjectModel.Type omReferencedType, long[] targetIds)
    {
      return FindReferers(omRefererType, omReferencedType, targetIds, null); 
    }

    /// <summary> 
    /// Locates <see cref="DataObject"/> instances that contain 
    /// references to the specified targets. 
    /// </summary> 
    /// <param name="omRefererType"><see cref="ObjectModel.Type"/> of referes.</param> 
    /// <param name="omReferencedType"><see cref="ObjectModel.Type"/> of reference targets.</param> 
    /// <param name="targetIds"><see cref="Array"/> of reference target identifiers.</param> 
    /// <param name="byFields">An <see cref="Array"/> of <see cref="Field"/>s to check for references on.</param> 
    /// <returns> 
    /// Returns an <see cref="QueryResult"/> populated with 
    /// <see cref="DataObject"/> instances containing references 
    /// to the specified targets. 
    /// </returns> 
    protected virtual QueryResult FindReferers(ObjectModel.Type omRefererType, ObjectModel.Type omReferencedType, long[] targetIds, Field[] byFields) 
    { 
      Field[] fields = (byFields==null ? GetFieldsForSearch(omRefererType, omReferencedType) : byFields);
      Hashtable hsIds = new Hashtable(); 
      long[] ids = null; 
      foreach (IReferenceHolderFieldInt field in fields) {
        if (field==null)
          throw new ArgumentException("Specified fields array contains null values.");
        ids = field.FindReferencesTo(session, targetIds); 
        for (int idIndex=0, idCount=ids.Length; idIndex<idCount; idIndex++) 
          hsIds[ids[idIndex]] = hsIds; 
      } 
      ids = new long[hsIds.Count]; 
      hsIds.Keys.CopyTo(ids, 0); 
      return new QueryResult(session, ids); 
    } 

    private Field[] GetFieldsForSearch(ObjectModel.Type omRefererType, ObjectModel.Type omReferencedType)
    {
      ArrayList fields = new ArrayList();
      foreach (Field f in omReferencedType.ReferingFields) { 
        if (f.Type==omRefererType || f.Type.IsDescendantOf(omRefererType))
          fields.Add(f);
      }
      return (Field[])fields.ToArray(typeof(Field));
    }
  }
}
