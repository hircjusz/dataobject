// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.ComponentModel;
using System.ComponentModel.Design.Serialization;
using System.Globalization;
using System.Reflection;
using DataObjects.NET.Data;

namespace DataObjects.NET.Data.Design
{
  /// <summary>
  /// Type converter for DataObjectCollection mapping item.
  /// </summary>
  public class DocMappingItemConverter: TypeConverter
  {
    /// <summary>
    /// Returns whether this converter can convert the object to the specified type, using the specified context.
    /// </summary>
    /// <param name="context">An <see cref="ITypeDescriptorContext"/> that provides a format context.</param>
    /// <param name="destinationType">A <see cref="Type"/> that represents the type you want to convert to.</param>
    /// <returns><see langword="True"/> if this converter can perform the conversion; otherwise, <see langword="false"/>.</returns>
    public override bool CanConvertTo(ITypeDescriptorContext context, Type destinationType)
    {
      if (destinationType==typeof(InstanceDescriptor))
        return true;
      return base.CanConvertTo(context, destinationType);
    }

    /// <summary>
    /// Converts the given value object to the specified type, using the specified context and culture information.
    /// </summary>
    /// <param name="context">An <see cref="ITypeDescriptorContext"/> that provides a format context.</param>
    /// <param name="culture">A <see cref="CultureInfo"/> object. If a null reference is passed, the current culture is assumed.</param>
    /// <param name="value">The <see cref="Object"/> to convert.</param>
    /// <param name="destinationType">The <see cref="Type"/> to convert the value parameter to.</param>
    /// <returns>An <see cref="Object"/> that represents the converted value.</returns>
    public override object ConvertTo(ITypeDescriptorContext context, CultureInfo culture, object value, Type destinationType)
    {
      if (destinationType==null)
        throw new ArgumentNullException("destinationType");
      if (destinationType==typeof(InstanceDescriptor) && (value is DocMappingItem)) {
        DocMappingItem item = (DocMappingItem)value;
        Type[] types = new Type[] {typeof(string), typeof(string)};
        ConstructorInfo ctor = typeof(DocMappingItem).GetConstructor(types);
        if (ctor!=null) {
          object[] values = new object[] {item.CollectionName, item.TableName};
          return new InstanceDescriptor(ctor, values);
        }
      }
      return base.ConvertTo (context, culture, value, destinationType);
    }

  }
}
