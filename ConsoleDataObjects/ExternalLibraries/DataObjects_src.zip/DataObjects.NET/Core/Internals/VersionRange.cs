// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using DataObjects.NET.Database;

namespace DataObjects.NET.Internals
{
  internal class VersionRange
  {
    private Version leftBound;
    private Version rightBound;

    public bool Contains (Version version)
    {
      return leftBound.CompareTo(version)<=0 && rightBound.CompareTo(version)>=0;
    }
 
    public static VersionRange Parse (string version)
    {
      if (version==null || version.Length==0)
        throw new ArgumentOutOfRangeException("version", "Argument value is null or empty string.");
      VersionRange range = new VersionRange();
      int dashIndex = version.IndexOf('-');
      if (dashIndex<0) {
        range.leftBound = new Version(version.Replace("*", "0"));
        range.rightBound = new Version(version.Replace("*", "65535"));
      }
      else {
        range.leftBound = new Version(version.Substring(0, dashIndex).Replace("*", "0"));
        range.rightBound = new Version(version.Substring(dashIndex+1).Replace("*", "65535"));
      }
      return range;
    }

    // Constructors
    
    private VersionRange ()
    {
    }
  }
}
