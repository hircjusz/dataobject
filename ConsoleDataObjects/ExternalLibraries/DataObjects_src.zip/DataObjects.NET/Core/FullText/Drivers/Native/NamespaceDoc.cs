// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;

namespace DataObjects.NET.FullText.Drivers.Native
{
  /// <summary>
  /// Conatins native full-text indexing and search driver implementation.
  /// <see cref="NativeFtsDriver"/> class is mainly a stub, since most of 
  /// native full-text search tasks are executed by the underlying database 
  /// driver.
  /// </summary>
  internal class NamespaceDoc {}
}
