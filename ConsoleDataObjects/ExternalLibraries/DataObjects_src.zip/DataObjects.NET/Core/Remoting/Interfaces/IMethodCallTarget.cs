// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

namespace DataObjects.NET.Remoting
{
  /// <summary>
  /// This interface should be implemented by any object allowing
  /// to invoke its methods with use of <see cref="MethodCallDescriptor"/>s.
  /// </summary>
  public interface IMethodCallTarget
  {
    /// <summary>
    /// Invokes the method described by the <paramref name="methodCallDescriptor"/>.
    /// </summary>
    /// <param name="methodCallDescriptor">Method invocation descriptor.</param>
    object Invoke(MethodCallDescriptor methodCallDescriptor);
  }
}
