// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Collections;
using System.Data;
using DataObjects.NET;
using DataObjects.NET.ObjectModel;
using DataObjects.NET.Data.CodeManage;

namespace DataObjects.NET.Data
{
  /// <summary>
  /// Exports <see cref="DataObject"/> graphs to <see cref="DataSet"/>
  /// and imports it back.
  /// </summary>
  /// <remarks>
  /// <note type="note">Remember that you can't import\export <see cref="DataObject"/>
  /// instances sharing different <see cref="Session"/>s during a single
  /// <see cref="Fill"/> or <see cref="Update"/> operation.</note>
  /// </remarks>
  [Designer("DataObjects.NET.Data.Design.AdapterDesigner, DataObjects.NET")]
  public class Adapter: Component
  {
    #if !MONO
    private class __util
    {
      public static CodeManagerBase CreateDesignTimeCodeManager(IDesignerHost vshost)
      {
        EnvDTE.DTE dte = (EnvDTE.DTE)vshost.GetService(typeof(EnvDTE.DTE));
        EnvDTE.Project currentProject = dte.ActiveDocument.ProjectItem.ContainingProject;
        return new DesigntimeCodeManager(currentProject.CodeModel);
      }
    }
    #endif
    
    private Container components = null;
    private CodeManagerBase codeManager;
    private AdapterState state = AdapterState.Ready;
    internal DataSet dataSource = null;
    private InterfaceMappingCollection interfaceMapping;
    private ClassMappingCollection classMapping;
    private Domain domain;
    private Session session;
    private AdapterFillQueue fillQueue;
    private AdapterUpdateQueue updateQueue;
    private Translator translator;
    private FillOptions fillOptions = FillOptions.Default;
    private UpdateOptions updateOptions = UpdateOptions.Default;
    
    /// <summary>
    /// In design mode gets <see cref="CodeManager"/> instance. Otherwise returns <see langword="null"/>.
    /// </summary>
    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    internal CodeManagerBase CodeManager {
      get {
      #if !MONO
        if (codeManager==null) {
          if (this.DesignMode) {
            IDesignerHost vshost = (IDesignerHost)((IServiceProvider)this.Container).GetService(typeof(IDesignerHost));
            if (vshost!=null)
              codeManager = __util.CreateDesignTimeCodeManager(vshost);
          } else {
            codeManager = new RuntimeCodeManager(domain.ObjectModel);
          }
        }
        return codeManager;
      #else
        if (codeManager==null) {
          codeManager = new RuntimeCodeManager(domain.ObjectModel);
        }
        return codeManager;
      #endif
      }
    }
    
    /// <summary>
    /// Gets the state of the <see cref="Adapter"/>.
    /// </summary>
    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public AdapterState State {
      get {
        return state;
      }
    }
    
    /// <summary>
    /// Gets or sets the <see cref="Domain"/> the <see cref="Adapter"/>
    /// works with.
    /// </summary>
    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public Domain Domain {
      get {
        return domain;
      }
      set {
        if (State!=AdapterState.Ready)
          throw new InvalidOperationException(
            "Invalid Adapter State (expected state: \"Ready\").");
        domain = value;
        codeManager = null;
      }
    }
    
    /// <summary>
    /// Gets the <see cref="DataObjects.NET.Session"/> instance that is currently
    /// used. This property isn't available when <see cref="State"/> 
    /// is <see cref="AdapterState.Ready"/> (an exception will be
    /// thrown on attempt to read this property in this case).
    /// </summary>
    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public Session Session {
      get {
        if (State==AdapterState.Ready)
          throw new InvalidOperationException(
            "Invalid Adapter State (expected state: \"Filling\" or \"Updating\").");
        return session;
      }
    }
    
    /// <summary>
    /// Gets or sets the data source <see cref="DataSet"/> the 
    /// <see cref="Adapter"/> works with.
    /// </summary>
    /// <remarks>
    /// <para>
    /// The <see cref="DataSource"/> schema (tables, columns) should be 
    /// defined manually by user prior to execution of <see cref="Fill"/>
    /// or <see cref="Update"/> methods.
    /// </para>
    /// </remarks>
    [Category("Data")]
    [TypeConverter(typeof(AdapterDataSourceConverter))]
    [Browsable(true)]
    [Bindable(true)]
    public object DataSource {
      get {
        return dataSource;
      }
      set {
        if (State!=AdapterState.Ready)
          throw new InvalidOperationException(
            "Invalid Adapter State (expected state: \"Ready\").");
        if (!(value==null || value is DataSet))
          throw new InvalidOperationException("DataSource must be of type \"DataSet\".");
        dataSource = (DataSet)value;
      }
    }

    /// <summary>
    /// Gets or sets <see cref="FillOptions"/> which specify <see cref="Adapter"/> fill behaviour.
    /// </summary>
    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public FillOptions FillOptions {
      get {
        return fillOptions;
      }
      set {
        if (State!=AdapterState.Ready)
          throw new InvalidOperationException(
            "Invalid Adapter State (expected state: \"Ready\").");
        fillOptions = value;
      }
    }
    
    /// <summary>
    /// Gets or sets <see cref="UpdateOptions"/> which specify <see cref="Adapter"/> update behaviour.
    /// </summary>
    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public UpdateOptions UpdateOptions 
    {
      get {
        return updateOptions;
      }
      set {
        if (State!=AdapterState.Ready)
          throw new InvalidOperationException(
            "Invalid Adapter State (expected state: \"Ready\").");
        updateOptions = value;
      }
    }
    
    /// <summary>
    /// Gets <see cref="Adapter"/>'s <see cref="Translator"/>.
    /// </summary>
    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    internal Translator Translator {
      get {
        return translator;
      }
    }
    
    #region Mapping-related methods and properties
    
    /// <summary>
    /// Gets a collection of "interface-table" mappings.
    /// </summary>
    [Category("Mapping")]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    public InterfaceMappingCollection InterfaceMapping {
      get {
        if (interfaceMapping==null)
          interfaceMapping = new InterfaceMappingCollection(this);
        return interfaceMapping;
      }
    }
    
    /// <summary>
    /// Gets a collection of "class-table" mappings.
    /// </summary>
    [Category("Mapping")]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    public ClassMappingCollection ClassMapping {
      get {
        if (classMapping==null)
          classMapping = new ClassMappingCollection(this);
        return classMapping;
      }
    }
    
    /// <summary>
    /// Clears interface and class mappings.
    /// </summary>
    public void ClearMapping()
    {
      if (State!=AdapterState.Ready)
        throw new InvalidOperationException(
          "Invalid Adapter State (expected state: \"Ready\").");
      MappingGenerator mapGen = new MappingGenerator(this);
      mapGen.ClearMappings();
    }
    
    /// <summary>
    /// Automatically generates interface and class mappings.
    /// Returns <see cref="MappingLog"/> containing records about removed and
    /// newly created mapping items.
    /// </summary>
    /// <remarks>
    /// First all existent mapping items are checked and if mapping item is correct
    /// it will be saved otherwise it will be removed.
    /// New mapping items are generated then.
    /// </remarks>
    /// <returns><see cref="MappingLog"/> containing records about removed and
    /// newly created mapping items.</returns>
    public MappingLog GenerateMappings()
    {
      if (State!=AdapterState.Ready)
        throw new InvalidOperationException(
          "Invalid Adapter State (expected state: \"Ready\").");
      MappingGenerator mapGen = this.DesignMode ? new DesigntimeMappingGenerator(this) : new MappingGenerator(this);
      mapGen.CreateMappings();
      return mapGen.Log;
    }
    
    #endregion
    
    #region DataSource utilities
    
    /// <summary>
    /// Prepares <see cref="Adapter.DataSource"/> before fill or update.
    /// </summary>
    /// <remarks>
    /// <see cref="Adapter"/> will create all necessary columns:
    /// ID - in tables that are mapped to <see cref="DataObject"/>s;
    /// ID-1, ID-2 - in tables that are mapped to <see cref="DataObjectCollection"/>s;
    /// ID, Owner - in tables that are mapped to <see cref="ValueTypeCollection"/>s.
    /// Also primary keys will be created.
    /// </remarks>
    public void PrepareDataSource()
    {
      if (State!=AdapterState.Ready)
        throw new InvalidOperationException(
          "Invalid Adapter State (expected state: \"Ready\").");
      if (dataSource==null)
        throw new InvalidOperationException(
          "DataSource is null.");
      
      ClassMappingCollection cmc = this.ClassMapping;
      foreach (ClassMappingItem cmi in cmc) {
        PrepareDataObjectTable(cmi.TableName);
        foreach (DocMappingItem dmi in cmi.DoCollections) {
          PrepareDataObjectCollectionTable(dmi.TableName);
        }
        foreach (VtcMappingItem vmi in cmi.VtCollections) {
          PrepareValueTypeCollectionTable(vmi.TableName);
        }
      }
      
      InterfaceMappingCollection imc = this.InterfaceMapping;
      foreach (InterfaceMappingItem imi in imc) {
        PrepareDataObjectTable(imi.TableName);
        foreach (DocMappingItem dmi in imi.DoCollections) {
          PrepareDataObjectCollectionTable(dmi.TableName);
        }
        foreach (VtcMappingItem vmi in imi.VtCollections) {
          PrepareValueTypeCollectionTable(vmi.TableName);
        }
      }
    }
    
    private void PrepareDataObjectTable(string tableName)
    {
      if (tableName==null || !dataSource.Tables.Contains(tableName))
        return;
        
      DataTable table = dataSource.Tables[tableName];
      
      if (!table.Columns.Contains("ID"))
        table.Columns.Add("ID", typeof(long));
      
      DataColumn idColumn = table.Columns["ID"];
      
      if (this.DesignMode) {
        dataSource.Site.Container.Add(idColumn);
      }
      
      if (idColumn.DataType!=typeof(long))
        idColumn.DataType = typeof(long);
        
      DataColumn[] pk = table.PrimaryKey;
      if (pk==null || pk.Length!=1 || pk[0]!=idColumn)
        table.PrimaryKey = new DataColumn[] {idColumn};
    }
    
    private void PrepareDataObjectCollectionTable(string tableName)
    {
      if (tableName==null || !dataSource.Tables.Contains(tableName))
        return;
        
      DataTable table = dataSource.Tables[tableName];
      
      if (!table.Columns.Contains(DataObjectCollectionField.DefaultID1Name))
        table.Columns.Add(DataObjectCollectionField.DefaultID1Name, typeof(long));
      if (!table.Columns.Contains(DataObjectCollectionField.DefaultID2Name))
        table.Columns.Add(DataObjectCollectionField.DefaultID2Name, typeof(long));
        
      DataColumn id1Column = table.Columns[DataObjectCollectionField.DefaultID1Name];
      DataColumn id2Column = table.Columns[DataObjectCollectionField.DefaultID2Name];
      
      if (this.DesignMode) {
        dataSource.Site.Container.Add(id1Column);
        dataSource.Site.Container.Add(id2Column);
      }
      
      if (id1Column.DataType!=typeof(long))
        id1Column.DataType = typeof(long);
      if (id2Column.DataType!=typeof(long))
        id2Column.DataType = typeof(long);
        
      DataColumn[] pk = table.PrimaryKey;
      if (pk==null || pk.Length!=2 || pk[0]!=id1Column || pk[1]!=id2Column)
        table.PrimaryKey = new DataColumn[] {id1Column, id2Column};
    }
    
    private void PrepareValueTypeCollectionTable(string tableName)
    {
      if (tableName==null || !dataSource.Tables.Contains(tableName))
        return;
        
      DataTable table = dataSource.Tables[tableName];
      
      if (!table.Columns.Contains("ID"))
        table.Columns.Add("ID", typeof(long));
      if (!table.Columns.Contains(ValueTypeCollectionField.DefaultOwnerName))
        table.Columns.Add(ValueTypeCollectionField.DefaultOwnerName, typeof(long));
        
      DataColumn idColumn = table.Columns["ID"];
      DataColumn ownerColumn = table.Columns[ValueTypeCollectionField.DefaultOwnerName];
      
      if (this.DesignMode) {
        dataSource.Site.Container.Add(idColumn);
        dataSource.Site.Container.Add(ownerColumn);
      }
      
      if (idColumn.DataType!=typeof(long))
        idColumn.DataType = typeof(long);
      if (ownerColumn.DataType!=typeof(long))
        ownerColumn.DataType = typeof(long);
        
      DataColumn[] pk = table.PrimaryKey;
      if (pk==null || pk.Length!=1 || pk[0]!=idColumn)
        table.PrimaryKey = new DataColumn[] {idColumn};
    }
    
    private bool oldEnforceConstraints;
    private DataSet changes;
    
    private void BeginDataSourceChange()
    {
      oldEnforceConstraints = dataSource.EnforceConstraints;
      dataSource.EnforceConstraints = false;
      
      changes = dataSource.GetChanges();
    }
    
    private void EndDataSourceChange(bool commit)
    {
      if (commit) {
        dataSource.AcceptChanges();
      } else {
        dataSource.RejectChanges();
        if (changes!=null)
          dataSource.Merge(changes);
      }
      
      dataSource.EnforceConstraints = oldEnforceConstraints;
    }
    
    #endregion
    
    #region Fill-related methods and properties
    
    /// <summary>
    /// Gets the <see cref="AdapterFillQueue"/> instance.
    /// </summary>
    /// <remarks>
    /// This property isn't available when <see cref="State"/> 
    /// isn't <see cref="AdapterState.Filling"/> or 
    /// <see cref="AdapterState.Updating"/> (an exception will be
    /// thrown on attempt to read this property in this case).
    /// </remarks>
    [Browsable(false)]
    public AdapterFillQueue FillQueue {
      get {
        if (State!=AdapterState.Filling && State!=AdapterState.Updating)
          throw new InvalidOperationException(
            "Invalid Adapter State.");
        return fillQueue;
      }
    }
    
    /// <summary>
    /// Fills all <see cref="DataObject"/> instances 
    /// contained in the specified <see cref="IEnumerable"/> collection 
    /// into the <see cref="DataSource"/>.
    /// </summary>
    /// <param name="collection"><see cref="IEnumerable"/> collection 
    /// containing <see cref="DataObject"/> instances to fill; 
    /// all objects should be from the same <see cref="DataObjects.NET.Session"/>.</param>
    public void Fill(IEnumerable collection)
    {
      DataObject firstObj = null;
      foreach (DataObject o in collection) {
        if (o!=null) {
          firstObj = o;
          break;
        }
      }
      if (firstObj==null)
        return;
      Fill_Begin(firstObj.Session);
      try {
        FillQueue.Enqueue(collection);
        Fill_FillQueue();
      } finally {
        Fill_End();
      }
    }
    
    /// <summary>
    /// Fills all <see cref="DataObject"/> instances 
    /// contained in the specified <see cref="QueryResult"/>
    /// into the <see cref="DataSource"/>.
    /// </summary>
    /// <param name="queryResult"><see cref="QueryResult"/>
    /// containing <see cref="DataObject"/> instances to fill.</param>
    public void Fill(QueryResult queryResult)
    {
      Fill_Begin(queryResult.Session);
      try {
        FillQueue.Enqueue(queryResult);
        Fill_FillQueue();
      } finally {
        Fill_End();
      }
    }
    
    /// <summary>
    /// Fills all <see cref="DataObject"/> instances 
    /// contained in the specified <see cref="DataObjectCollection"/>
    /// into the <see cref="DataSource"/>.
    /// </summary>
    /// <param name="collection"><see cref="DataObjectCollection"/>
    /// containing <see cref="DataObject"/> instances to fill.</param>
    public void Fill(DataObjectCollection collection)
    {
      Fill_Begin(collection.Session);
      try {
        FillQueue.Enqueue(collection);
        Fill_FillQueue();
      } finally {
        Fill_End();
      }
    }
    
    /// <summary>
    /// Fills all <see cref="DataObject"/> instances which
    /// <see cref="DataObject.ID"/>s are 
    /// contained in the specified <see cref="Array"/>
    /// into the <see cref="DataSource"/>.
    /// </summary>
    /// <param name="session">Session to use.</param>
    /// <param name="ids">An <see cref="Array"/>
    /// containing <see cref="DataObject.ID"/>s of instances to fill.</param>
    public void Fill(Session session, long[] ids)
    {
      Fill_Begin(session);
      try {
        FillQueue.Enqueue(ids);
        Fill_FillQueue();
      } finally {
        Fill_End();
      }
    }
    
    private void Fill_Begin(Session session)
    {
      if (session==null)
        throw new ArgumentNullException("session");
    
      if (State!=AdapterState.Ready)
        throw new InvalidOperationException(
          "Invalid Adapter State (expected state: \"Ready\").");
          
      this.session = session;
      translator = new Translator(this);
      fillQueue = new AdapterFillQueue(this);
      
      state = AdapterState.Filling;
      
      OnBeginFill();
    }
    
    private void Fill_End()
    {
      session = null;
      translator = null;
      fillQueue = null;

      state = AdapterState.Ready;
      
      OnEndFill();
    }
    
    private void Fill_FillQueue()
    {
      FillQueue.SetGenerationMark();
     
      BeginDataSourceChange();
      TransactionController tc = session.CreateTransactionController( TransactionMode.NewTransactionRequired);
      try {
        // MAIN FILL LOOP!!!
        while (fillQueue.Count>0) {
          Fill_CurrentObject();
          fillQueue.Dequeue();
        }
        tc.Commit();
        EndDataSourceChange(true);
      } catch (Exception e) {
        tc.Rollback(e);
        EndDataSourceChange(false);
        throw;
      }
    }
    
    private void Fill_CurrentObject()
    {
      TransactionController tc = session.CreateTransactionController( TransactionMode.NewTransactionRequired);
      try {
        OnBeginFillObject();
        translator.Fill(fillQueue.CurrentObject);
        OnEndFillObject();
        tc.Commit();
      } catch (Exception e) {
        tc.Rollback(e);
        if ((fillOptions & FillOptions.IgnoreErrors)==0)
          throw;
      }
    }
    
    #endregion
    
    #region Fill-related events
    
    /// <summary>
    /// Raises the <see cref="BeginFill"/> event.
    /// </summary>
    protected virtual void OnBeginFill()
    {
      if (BeginFill!=null)
        BeginFill(this, null);
    }
    
    /// <summary>
    /// Occurs before beginning to process <see cref="Fill"/> method.
    /// </summary>
    public event EventHandler BeginFill;
    
    /// <summary>
    /// Raises the <see cref="EndFill"/> event.
    /// </summary>
    protected virtual void OnEndFill()
    {
      if (EndFill!=null)
        EndFill(this, null);
    }
    
    /// <summary>
    /// Occurs after completing execution of <see cref="Fill"/> method.
    /// </summary>
    public event EventHandler EndFill;
    
    /// <summary>
    /// Raises the <see cref="BeginFillObject"/> event.
    /// </summary>
    protected virtual void OnBeginFillObject()
    {
      if (BeginFillObject!=null)
        BeginFillObject(this, null);
    }
    
    /// <summary>
    /// Occurs before beginning to fill <see cref="AdapterFillQueue.CurrentObject"/>
    /// in the <see cref="FillQueue"/>.
    /// </summary>
    public event EventHandler BeginFillObject;
    
    /// <summary>
    /// Raises the <see cref="EndFillObject"/> event.
    /// </summary>
    protected virtual void OnEndFillObject()
    {
      if (EndFillObject!=null)
        EndFillObject(this, null);
    }
    
    /// <summary>
    /// Occurs after completion of filling <see cref="AdapterFillQueue.CurrentObject"/>
    /// in the <see cref="FillQueue"/>.
    /// </summary>
    public event EventHandler EndFillObject;
    
    internal void Internal_OnGetProperty(PropertyEventArgs e)
    {
      OnGetProperty(e);
    }
    
    /// <summary>
    /// Raises the <see cref="GetProperty"/> event.
    /// </summary>
    /// <param name="e">Provides information for <see cref="Adapter.GetProperty"/> event.</param>
    protected virtual void OnGetProperty(PropertyEventArgs e)
    {
      if (GetProperty!=null)
        GetProperty(this, e);
    }
    
    /// <summary>
    /// Occurs when <see cref="Adapter"/> is getting <see cref="DataObject"/>'s property value.
    /// </summary>
    public event GetPropertyEventHandler GetProperty;
    
    internal void Internal_OnEnqueueObject(EnqueueObjectEventArgs e)
    {
      OnEnqueueObject(e);
    }
    
    /// <summary>
    /// Raises the <see cref="EnqueueObject"/> event.
    /// </summary>
    protected virtual void OnEnqueueObject(EnqueueObjectEventArgs e)
    {
      if (EnqueueObject!=null)
        EnqueueObject(this, e);
    }
    
    /// <summary>
    /// Occurs when <see cref="Adapter"/> is going to enqueue the <see cref="DataObject"/>
    /// for further filling.
    /// </summary>
    public event EnqueueObjectEventHandler EnqueueObject;
    
    #endregion
    
    #region Update-related methods and properties

    /// <summary>
    /// Gets the <see cref="AdapterUpdateQueue"/> instance.
    /// This property isn't available when <see cref="State"/> 
    /// isn't <see cref="AdapterState.Updating"/> (an exception will be
    /// thrown on attempt to read this property in this case).
    /// </summary>
    [Browsable(false)]    
    public AdapterUpdateQueue UpdateQueue {
      get {
        if (State!=AdapterState.Updating)
          throw new InvalidOperationException(
            "Invalid Adapter State (expected state: \"Updating\").");
        return updateQueue;
      }
    }

    /// <summary>
    /// Updates all <see cref="DataObject"/> instances from
    /// the <see cref="DataSource"/>.
    /// </summary>
    /// <param name="session">Session to use.</param>
    public void Update(Session session)
    {
      Update_Begin(session);
      BeginDataSourceChange();
      TransactionController tc = session.CreateTransactionController( TransactionMode.NewTransactionRequired);
      try {
        translator.RegisterIds();
        Update_PerformCreation();
        Update_PerformUpdate();
        Update_PerformRemoval();
        Update_PerformFill();
        tc.Commit();
        EndDataSourceChange(true);
      } catch (Exception e) {
        tc.Rollback(e);
        EndDataSourceChange(false);
        throw;
      } finally {
        Update_End();
      }
    }
    
    private void Update_Begin(Session session)
    {
      if (session==null)
        throw new ArgumentNullException("session");
    
      if (State!=AdapterState.Ready)
        throw new InvalidOperationException(
          "Invalid Adapter State (expected state: \"Ready\").");
      
      this.session = session;
      translator = new Translator(this);
      updateQueue = new AdapterUpdateQueue(this);
      fillQueue = new AdapterFillQueue(this);
      
      state = AdapterState.Updating;
      
      OnBeginUpdate();
    }
    
    private void Update_End()
    {
      session = null;
      translator = null;
      updateQueue = null;
      fillQueue = null;
      
      state = AdapterState.Ready;
      
      OnEndUpdate();
    }
    
    private void Update_PerformRemoval()
    {
      while (UpdateQueue.State==AdapterUpdateQueueState.Remove) {
        DataObject dataObject = UpdateQueue.CurrentObject;
        if (dataObject!=null) {
          TransactionController tc = session.CreateTransactionController( TransactionMode.NewTransactionRequired);
          try {
            OnBeforeRemoveObject(new BeforeRemoveObjectEventArgs(dataObject));
            dataObject.Remove();
            tc.Commit();
          } catch (Exception e) {
            tc.Rollback(e);
            if ((updateOptions & UpdateOptions.IgnoreErrors)==0)
              throw;
          } 
        }
        UpdateQueue.Dequeue();
      }
    }
    
    private void Update_PerformCreation()
    {
      while (UpdateQueue.State==AdapterUpdateQueueState.Create) {
        long id = UpdateQueue.CurrentObjectID;
        TransactionController tc = session.CreateTransactionController( TransactionMode.NewTransactionRequired);
        try {
          CreateObjectEventArgs coe = new CreateObjectEventArgs(translator.SuggestType(id), translator.GetCorrespondingRows(id));
          OnCreateObject(coe);
          DataObject newObject = coe.DataObject;
          if (newObject==null) {
            if (coe.SuggestedType!=null) {
              if (coe.Delay) 
                UpdateQueue.ReEnqueueObjectForCreate(id);
              else
                newObject = session.CreateObject(coe.SuggestedType.SourceType, null);
            }
          }
          if (newObject!=null) {
            UpdateQueue.SetCreatedObjectID(id, newObject.ID);
            translator.UpdateSystemColumns(id, newObject.ID, newObject.VersionCode);
            if (coe.Update)
              UpdateQueue.EnqueueObjectForUpdate(newObject.ID);
          }
          tc.Commit();
        } catch (Exception e) {
          tc.Rollback(e);
          if ((updateOptions & UpdateOptions.IgnoreErrors)==0)
            throw;
        }
        UpdateQueue.Dequeue();
      }
    }
    
    private void Update_PerformUpdate()
    {
      while (UpdateQueue.State==AdapterUpdateQueueState.Update) {
        DataObject dataObject = UpdateQueue.CurrentObject;
        if (dataObject!=null) {
          TransactionController tc = session.CreateTransactionController( TransactionMode.NewTransactionRequired);
          try {
            OnBeginUpdateObject();
            translator.Update(dataObject);
            OnEndUpdateObject();
            fillQueue.Enqueue(dataObject);
            tc.Commit();
          } catch (Exception e) {
            tc.Rollback(e);
            if ((updateOptions & UpdateOptions.IgnoreErrors)==0)
              throw;
          }
        }
        UpdateQueue.Dequeue();
      }
      translator.UpdateCollections();
    }
    
    private void Update_PerformFill()
    {
      while (fillQueue.Count>0) {
        DataObject dataObject = fillQueue.CurrentObject;
        if (dataObject!=null) {
          TransactionController tc = session.CreateTransactionController( TransactionMode.NewTransactionRequired);
          try {
            OnBeginFillObject();
            translator.FillAfterUpdate(dataObject);
            OnEndFillObject();
            tc.Commit();
          } catch (Exception e) {
            tc.Rollback(e);
            if ((updateOptions & UpdateOptions.IgnoreErrors)==0)
              throw;
          }
        }
        fillQueue.Dequeue();
      }
    }
    
    #endregion
    
    #region Update-related events
    
    /// <summary>
    /// Raises the <see cref="BeginUpdate"/> event.
    /// </summary>
    protected virtual void OnBeginUpdate()
    {
      if (BeginUpdate!=null)
        BeginUpdate(this, null);
    }
    
    /// <summary>
    /// Occurs before beginning to process <see cref="Update"/> method.
    /// </summary>
    public event EventHandler BeginUpdate;
    
    /// <summary>
    /// Raises the <see cref="EndUpdate"/> event.
    /// </summary>
    protected virtual void OnEndUpdate()
    {
      if (EndUpdate!=null)
        EndUpdate(this, null);
    }
    
    /// <summary>
    /// Occurs after completing execution of <see cref="Update"/> method.
    /// </summary>
    public event EventHandler EndUpdate;
    
    /// <summary>
    /// Raises the <see cref="BeforeRemoveObject"/> event.
    /// </summary>    
    protected virtual void OnBeforeRemoveObject(BeforeRemoveObjectEventArgs e)
    {
      if (BeforeRemoveObject!=null)
        BeforeRemoveObject(this, e);
    }
    
    /// <summary>
    /// Occurs when <see cref="Adapter"/> is going to remove <see cref="DataObject"/> instance.
    /// </summary>
    public event BeforeRemoveObjectEventHandler BeforeRemoveObject;
    
    /// <summary>
    /// Raises the <see cref="CreateObject"/> event.
    /// </summary>
    protected virtual void OnCreateObject(CreateObjectEventArgs e)
    {
      if (CreateObject!=null)
        CreateObject(this, e);
    }
    
    /// <summary>
    /// Occurs when <see cref="Adapter"/> is going to create new <see cref="DataObject"/> instance.
    /// </summary>
    public event CreateObjectEventHandler CreateObject;
    
    internal void Internal_OnCreateVtcItem(CreateVtcItemEventArgs e)
    {
      OnCreateVtcItem(e);
    }
    
    /// <summary>
    /// Raises the <see cref="CreateVtcItem"/> event.
    /// </summary>
    protected virtual void OnCreateVtcItem(CreateVtcItemEventArgs e)
    {
      if (CreateVtcItem!=null)
        CreateVtcItem(this, e);
    }
    
    /// <summary>
    /// Occurs when <see cref="Adapter"/> is going to create new <see cref="ValueTypeCollection"/> item.
    /// </summary>
    public event CreateVtcItemEventHandler CreateVtcItem;
    
    internal void Internal_OnVersionConflict(VersionConflictEventArgs e)
    {
      OnVersionConflict(e);
    }
    
    /// <summary>
    /// Raises the <see cref="VersionConflict"/> event.
    /// </summary>
    protected virtual void OnVersionConflict(VersionConflictEventArgs e)
    {
      if (VersionConflict!=null)
        VersionConflict(this, e);
    }
    
    /// <summary>
    /// Occurs when <see cref="Adapter"/> has determined version conflict while updating a <see cref="DataObject"/> instance.
    /// </summary>
    /// <remarks>
    /// <see cref="VersionConflict"/> event occurs even when "IgnoreVersionConflict" option is set.
    /// </remarks>
    public event VersionConflictEventHandler VersionConflict;
    
    /// <summary>
    /// Raises the <see cref="BeginUpdateObject"/> event.
    /// </summary>
    protected virtual void OnBeginUpdateObject()
    {
      if (BeginUpdateObject!=null)
        BeginUpdateObject(this, null);
    }
    
    /// <summary>
    /// Occurs before beginning to update <see cref="AdapterUpdateQueue.CurrentObject"/>
    /// in the <see cref="UpdateQueue"/>.
    /// </summary>
    public event EventHandler BeginUpdateObject;
    
    /// <summary>
    /// Raises the <see cref="EndUpdateObject"/> event.
    /// </summary>
    protected virtual void OnEndUpdateObject()
    {
      if (EndUpdateObject!=null)
        EndUpdateObject(this, null);
    }
    
    /// <summary>
    /// Occurs after completion of updating <see cref="AdapterUpdateQueue.CurrentObject"/>
    /// in the <see cref="UpdateQueue"/>.
    /// </summary>
    public event EventHandler EndUpdateObject;
    
    internal void Internal_OnSetProperty(PropertyEventArgs e)
    {
      OnSetProperty(e);
    }
    
    /// <summary>
    /// Raises the <see cref="SetProperty"/> event.
    /// </summary>
    /// <param name="e">Provides information for <see cref="Adapter.SetProperty"/> event.</param>
    protected virtual void OnSetProperty(PropertyEventArgs e)
    {
      if (SetProperty!=null)
        SetProperty(this, e);
    }
    
    /// <summary>
    /// Occurs when <see cref="Adapter"/> is going to set <see cref="DataObject"/>'s property value.
    /// </summary>
    public event SetPropertyEventHandler SetProperty;
    
    #endregion
    
    /// <summary> 
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing )
    {
      if (disposing) {
        if (components != null) {
          components.Dispose();
        }
      }
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      components = new System.ComponentModel.Container();
    }
    
    /// <summary>
    /// Initializes a new instance of the <see cref="Adapter"/> class.
    /// </summary>
    /// <param name="container"><see cref="IContainer"/>.</param>
    public Adapter(System.ComponentModel.IContainer container)
    {
      container.Add(this);
      InitializeComponent();
    }

    /// <summary>
    /// Initializes a new instance of the <see cref="Adapter"/> class.
    /// </summary>
    public Adapter()
    {
      InitializeComponent();
    }
  }
}
