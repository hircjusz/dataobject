// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;
using System.Collections.Specialized;
using DataObjects.NET.Attributes;
using DataObjects.NET.Caching;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Database;
using DataObjects.NET.ObjectModel;
using DataObjects.NET.DatabaseModel;

namespace DataObjects.NET.Internals
{
  /// <summary>
  /// Underlying <see cref="DataObjectCollection"/> implementation.
  /// </summary>
  internal class DataObjectCollectionImplementation: 
    IDataObjectCollectionImplementation
  {
    const  string   rootName   = "root";
    const  string   extLinkPfx = "oqlExtLink";

    private DataObjectCollection    collection;
    private PersisterForCollections persister;
    private ISchemaNode schemaNode;
    private ISchemaNode targetSchemaNode;
    private string cOwner;
    private Column cOwnerColumn;
    private string cItem;
    private Column cItemColumn;
    private bool             isLoaded   = false;
    private int              count      = -1;
    private ArrayList        items      = new ArrayList();
    private HybridDictionary itemsIndex = new HybridDictionary();
    private HybridDictionary itemsCache = new HybridDictionary();
    private HybridDictionary itemsUpdateActions = new HybridDictionary();

    /// <summary>
    /// Called on attachment to <see cref="DataObject"/>.
    /// </summary>
    public void Attach()
    {
      Field field = collection.Field;
      Culture culture = collection.Culture;
      ICollectionField cField = (ICollectionField)collection.Field;

      this.persister        = collection.session.persister.PersisterForCollections;
      this.schemaNode       = cField.GetSchemaNode(culture);
      this.targetSchemaNode = this.schemaNode;
      this.cOwner           = cField.GetOwnerIdColumnName(culture);
      this.cItem            = cField.GetItemIdColumnName(culture);
      if (collection.PairTo==null) {
        Table realTable = field.RelatedTables[culture==null ? 0 : culture.Index];
        this.cOwnerColumn = realTable.Columns[cOwner];
        this.cItemColumn  = realTable.Columns[cItem];
      }
      else {
        if (collection.PairTo is ReferenceField) {
          ObjectModel.Type type = collection.PairTo.Type;
          if (type.ShareDescendantTable || type.ShareAncestorTable)
            this.targetSchemaNode = type.RelatedView;
          this.cOwnerColumn = null;
          this.cItemColumn = null;
        }
        else {
          Table realTable = collection.PairTo.RelatedTables[culture==null ? 0 : culture.Index];
          this.cOwnerColumn = realTable.Columns[cOwner];
          this.cItemColumn  = realTable.Columns[cItem];
        }
      }
    }

    /// <summary>
    /// Called on detachment from <see cref="DataObject"/>.
    /// </summary>
    public void Detach()
    {
    }

    public void InvalidateCache()
    {
      isLoaded = false;
      count    = -1;
      items.Clear();
      itemsIndex.Clear();
      itemsCache.Clear();
      itemsUpdateActions.Clear();
    }

    /// <summary>
    /// <see langword="True"/> if the collection is completely loaded;
    /// otherwise, <see langword="false"/>.
    /// </summary>
    public bool IsLoaded {
      get {
        return isLoaded;
      }
    }
    
    /// <summary>
    /// Indicates whether collection contains delayed updates.
    /// </summary>
    public bool IsChanged {
      get {
        return itemsUpdateActions.Count!=0;
      }
    }
    
    /// <summary>
    /// Caches the specified item.
    /// </summary>
    /// <param name="value">Item to cache.</param>
    /// <param name="exists"><see langword="True"/> if the specified item exists
    /// in the collection; otherwise, <see langword="false"/>.</param>
    public void CacheItem(long value, bool exists)
    {
      if (!isLoaded) {
        if (exists)
          itemsCache[value] = itemsCache;
        else
          itemsCache[value] = null;
      }
    }
    
    /// <summary>
    /// Loads collection from the database.
    /// </summary>
    public void Load()
    {
      try {
        isLoaded = true;
        items.Clear();
        itemsIndex.Clear();
        itemsCache.Clear();
        if (collection.Owner.State!=DataObjectState.Persistent) {
          count = 0;
          return;
        }
        
        Transaction t = collection.Session.Transaction;
        bool canReadCache = collection.ChangesTrackingMode==ChangesTrackingMode.ThroughOwner;
        bool canCache = (t==null ? false : t.IsReadOnly) && canReadCache;
        
        if (canReadCache) {
          long[] gcItems = LoadItemsFromGlobalCache();
          if (gcItems!=null) {
            count  = gcItems.Length;
            for (int i = 0; i<gcItems.Length; i++) {
              long itemId = gcItems[i];
              items.Add(itemId);
              itemsIndex.Add(itemId,i);
              itemsCache[itemId] = itemsCache;
            }
            return;
          }
        }
        
        ArrayList newItems;
        try {
          newItems = persister.LoadRange(targetSchemaNode, cOwner, cItem, collection.Owner.ID, -1, RangeType.Greater, 0);
        }
        catch (Exception e) {
          throw collection.session.utils.SubstituteException(e);
        }
        count  = newItems.Count;
        for (int i = 0; i<count; i++) {
          long itemId = Convert.ToInt64(newItems[i]);
          items.Add(itemId);
          itemsIndex.Add(itemId,i);
          itemsCache[itemId] = itemsCache;
        }
        
        if (canCache)
          SaveItemsToGlobalCache();
      }
      catch {
        InvalidateCache();
        throw;
      }
    }

    /// <summary>
    /// Loads collection content from the given <see cref="ArrayList"/>.
    /// </summary>
    public void Load(ArrayList queryResultData)
    {
      try {
        isLoaded = true;
        items.Clear();
        itemsIndex.Clear();
        itemsCache.Clear();
        if (collection.Owner.State!=DataObjectState.Persistent) {
          count  = 0;
          return;
        }
        count  = queryResultData.Count;
        for (int i = 0; i<count; i++) {
          DataObjectIdentificationInfo info = (DataObjectIdentificationInfo)queryResultData[i];
          items.Add(info.ID);
          itemsIndex.Add(info.ID,i);
          itemsCache[info.ID] = itemsCache;
        }
      }
      catch {
        InvalidateCache();
        throw;
      }
    }

    /// <summary>
    /// Loads collection content from deserialized 
    /// <see cref="DataObject.FastLoadData"/> for this collection.
    /// </summary>
    /// <param name="itemIds">An <see cref="Array"/> containing item IDs.</param>
    /// <param name="count">The count of items in the collection.</param>
    public void Load(long[] itemIds, int count)
    {
      try {
        isLoaded = (itemIds.Length==count);
        items.Clear();
        itemsIndex.Clear();
        itemsCache.Clear();
        if (collection.Owner.State!=DataObjectState.Persistent) {
          this.count = 0;
          return;
        }
        this.count = count;
        for (int i = 0, itemCount=itemIds.Length; i<itemCount; i++) {
          long id = itemIds[i];
          items.Add(id);
          itemsIndex.Add(id,i);
          itemsCache[id] = itemsCache;
        }
      }
      catch {
        InvalidateCache();
        throw;
      }
    }

    /// <summary>
    /// Loads collection content from the given <see cref="ArrayList"/> contaning preload data.
    /// </summary>
    public void Load(ArrayList dbItems, int startIndex, int count) 
    {
      try {
        isLoaded = true;
        this.items.Clear();
        itemsIndex.Clear();
        itemsCache.Clear();
        if (collection.Owner.State!=DataObjectState.Persistent) {
          this.count  = 0;
          return;
        }
        this.count = count;
        for (int i = 0; i<count; i++) {
          IDictionary record = (IDictionary)dbItems[startIndex+i];
          long id = Convert.ToInt64(record[cItem]);
          this.items.Add(id);
          itemsIndex.Add(id,i);
          itemsCache[id] = itemsCache;
        }
      }
      catch {
        InvalidateCache();
        throw;
      }
    }

    /// <summary>
    /// Gets the number of elements contained in the collection.
    /// </summary>
    public int Count {
      get {
        if (count>=0)
          return count;
        else {
          if (collection.Owner.State!=DataObjectState.Persistent)
            return 0;
          else {
            if (collection.PairTo==null)
              Persist();
            else
              collection.session.Persist();
              
            Transaction t = collection.Session.Transaction;
            bool canReadCache = collection.ChangesTrackingMode==ChangesTrackingMode.ThroughOwner;
            bool canCache = (t==null ? false : t.IsReadOnly) && canReadCache;
              
            if (canReadCache) {
              count = LoadCountFromGlobalCache();
              if (count>=0)
                return count;
            }
            
            try {
              count = persister.Count(targetSchemaNode,cOwner,collection.Owner.ID);
            }
            catch (Exception e) {
              throw collection.session.utils.SubstituteException(e);
            }
            
            if (canCache)
              SaveCountToGlobalCache();
            
            return count;
          }
        }
      }
    }
    
    /// <summary>
    /// Returns an <see cref="Array"/> with contained items.
    /// </summary>
    /// <returns><see cref="Array"/> with contained items.</returns>
    public long[] GetContainedItems()
    {
      long[] copy = new long[items.Count];
      items.CopyTo(copy);
      return copy;
    }

    /// <summary>
    /// Returns an enumerator that can iterate through the
    /// collection instance.
    /// </summary>
    /// <returns>
    /// An <see cref="IEnumerator"/> for the 
    /// collection instance.
    /// </returns>
    public IEnumerator GetEnumerator()
    {
      return new DataObjectCollectionEnumerator(collection, items.GetEnumerator());
    }

    /// <summary>
    /// Removes all objects from the collection instance.
    /// </summary>
    public void Clear()
    {
      isLoaded = true;
      count    = 0;
      items.Clear();
      itemsIndex.Clear();
      itemsCache.Clear();
      itemsUpdateActions.Clear();
      try {
        if (collection.PairTo==null)
          persister.Clear(schemaNode, cOwner, collection.Owner.ID);
      }
      catch (Exception e) {
        throw collection.session.utils.SubstituteException(e);
      }
    }

    /// <summary>
    /// Returns <see langword="True"/> if the specified item
    /// exists in the collection; otherwise, <see langword="false"/>.
    /// </summary>
    /// <param name="value">Item to check.</param>
    /// <returns><see langword="True"/> if the specified item
    /// exists in the collection; otherwise, <see langword="false"/>.</returns>
    public bool Contains(long value)
    {
      if (itemsCache.Contains(value) || isLoaded)
        return itemsCache[value]!=null;
      else {
        collection.session.Persist();
        
        bool canReadCache = collection.ChangesTrackingMode==ChangesTrackingMode.ThroughOwner;
          
        if (canReadCache) {
          long[] gcItems = LoadItemsFromGlobalCache();
          if (gcItems!=null) {
            isLoaded = true;
            items.Clear();
            itemsIndex.Clear();
            itemsCache.Clear();
            count  = gcItems.Length;
            for (int i = 0; i<gcItems.Length; i++) {
              long itemId = gcItems[i];
              items.Add(itemId);
              itemsIndex.Add(itemId,i);
              itemsCache[itemId] = itemsCache;
            }
            return itemsCache[value]!=null;
          }
        }
        
        ArrayList newItems;
        try {
          newItems = persister.LoadRange(targetSchemaNode, cOwner, cItem, collection.Owner.ID, value, RangeType.Equal, 0);
        }
        catch (Exception e) {
          throw collection.session.utils.SubstituteException(e);
        }
        bool exists = newItems.Count>0;
        CacheItem(value, exists);
        return exists;
      }
    }

    /// <summary>
    /// Searches for the specified value and returns the index of the first occurrence within the current instance.
    /// </summary>
    /// <param name="value">The value to locate.</param>
    /// <returns>The index of the first occurrence of value within the entire collection, if found; otherwise, -1.</returns>
    public int IndexOf(long value)
    {
      if (!isLoaded)
        throw new DataObjectsDotNetException(
          "Internal error: IndexOf is invoked, but collection isn't loaded.");
      object o = itemsIndex[value];
      return o==null ? -1 : (int)o;
    }
    
    /// <summary>
    /// Gets the element at the specified index.
    /// </summary>
    /// <param name="index">Item index.</param>
    public long GetItem(int index)
    {
      if (!isLoaded)
        throw new DataObjectsDotNetException(
          "Internal error: GetItem is invoked, but collection isn't loaded.");
      object oItem = items[index];
      if (oItem==null)
        return 0;
      else 
        return (long)oItem;
    }
    
    /// <summary>
    /// Adds new element to the collection.
    /// </summary>
    /// <param name="value">Item to add.</param>
    /// <returns>Index of newly added item.</returns>
    public int  Add(long value)
    {
      if (collection.PairTo==null)
        if (itemsUpdateActions.Contains(value))
          if (itemsUpdateActions[value]==null)
            itemsUpdateActions.Remove(value);
          else
            throw new DataObjectsDotNetException(String.Format(
              "Internal error: attempt to add the item with ID={0} while it is already marked as added.",value));
        else
          itemsUpdateActions[value] = itemsUpdateActions;

      if (count>=0)
        count++;
      itemsCache[value] = itemsCache;
      if (isLoaded) {
        int i = items.Add(value);
        itemsIndex[value] = i;
        return i;
      }
      else
        return -1;
    }
    
    /// <summary>
    /// Removes element from the collection instance.
    /// </summary>
    /// <param name="value">Item to remove.</param>
    public void Remove(long value)
    {
      if (collection.PairTo==null)
        if (itemsUpdateActions.Contains(value))
          if (itemsUpdateActions[value]!=null)
            itemsUpdateActions.Remove(value);
          else
            throw new DataObjectsDotNetException(String.Format(
              "Internal error: attempt to remove the item with ID={0} while it is already marked as removed.",value));
        else
          itemsUpdateActions[value] = null;

      if (count>0)
        count--;
      else if (count==0)
        throw new DataObjectsDotNetException(String.Format(
          "Internal error: attempt to remove the item with ID={0} while Count==0.",value));
      itemsCache.Remove(value);
      if (isLoaded) {
        object oIndex = itemsIndex[value];
        if (oIndex==null)
          throw new DataObjectsDotNetException(String.Format(
            "Internal error: collection is loaded, but index of item with ID={0} is unknown.",value));
        int index = (int)oIndex;
        items.RemoveAt(index);
        itemsIndex.Clear();
        int i = 0;
        foreach (long id in items)
          itemsIndex.Add(id,i++);
      }
    }
    
    /// <summary>
    /// Sets the element in the collection.
    /// </summary>
    /// <param name="oldValue">Old value.</param>
    /// <param name="newValue">New value.</param>
    public void SetItem(long oldValue, long newValue)
    {
      if (itemsUpdateActions.Contains(oldValue)) {
        if (itemsUpdateActions[oldValue]!=null) {
          itemsUpdateActions.Remove(oldValue);
          itemsUpdateActions[newValue] = itemsUpdateActions;
        }
        else
          throw new DataObjectsDotNetException(String.Format(
            "Internal error: attempt to replace item with ID={0} that is already marked as removed.",oldValue));
      }
      else {
        try {
          if (collection.PairTo==null) {
            ArrayList cols = new ArrayList(1);
            cols.Add(new ColumnValue(cItemColumn, newValue));
            persister.Set(schemaNode, cOwner, cItem, collection.Owner.ID, oldValue, cols);
          }
        }
        catch (Exception e) {
          throw collection.session.utils.SubstituteException(e);
        }
      }
      itemsCache.Remove(oldValue);
      itemsCache[newValue] = itemsCache;
      if (isLoaded) {
        object oIndex = itemsIndex[oldValue];
        if (oIndex==null)
          throw new DataObjectsDotNetException(String.Format(
            "Internal error: collection is loaded, but index of item with ID={0} is unknown.",oldValue));
        int index = (int)oIndex;
        items[index] = newValue;
        itemsIndex.Remove(oldValue);
        itemsIndex[newValue] = index;
      }
    }
    
    /// <summary>
    /// Restricts query range to the elements of collection.
    /// </summary>
    /// <param name="query">Query to restrict.</param>
    public void RestrictQuery(QueryBase query)
    {
      Utils utils = collection.session.utils;

      string tableName = schemaNode.Name;
      if (schemaNode.RelatedType!=null)
        tableName = schemaNode.RelatedType.RelatedView.Name;
      ReferenceField pair = (collection.Field.DeclaredField as IPairToAllowed).PairTo as ReferenceField;
      
      if ((query.InstanceType==(collection.Field.DeclaredField as DataObjectCollectionField).ItemType) &&
          pair!=null && pair.Type==collection.Owner.Type) {
        // Eliminating unnecessary join
        string additionalSqlRestriction = utils.QuoteDoubleIdentifier(rootName,pair.Name) + "="+collection.Owner.ID.ToString();
        if (query.SqlRestriction.Trim()=="")
          query.SqlRestriction =  additionalSqlRestriction;
        else
          query.SqlRestriction += " and (" + additionalSqlRestriction +")";
      }
      else {
        if (query is Query) {
          // We should add an DataObjectCollectionBaseQueryRestriction in this case
          (query as Query).QueryRestrictions.Add(
            new DataObjectCollectionQueryRestriction(
              collection.Field.DeclaredField as DataObjectCollectionField,
              collection.Culture,
              collection.Owner));
        }
        else {
          string aliasName = extLinkPfx + (collection.session.counter++).ToString();
          // We should add an SqlJoin in this case
          query.Joins.Add(
            new SqlJoin(
              SqlJoinType.Inner,
              tableName,
              aliasName,
              utils.QuoteDoubleIdentifier(aliasName, cOwner) + "=" + collection.Owner.ID.ToString() +
                " and " + utils.QuoteDoubleIdentifier(aliasName, cItem) + "=" +
                utils.QuoteIdentifier(rootName) + "." + collection.session.sqlQuotedID
              ));
        }
      }
    }

    /// <summary>
    /// Persists all cached changes in the collection to database.
    /// </summary>
    public void Persist()
    {
      try {
        foreach (long key in itemsUpdateActions.Keys) {
          if (itemsUpdateActions[key]==null)
            persister.Remove(schemaNode,cOwner,cItem,collection.Owner.ID,key);
          else
            persister.Add(schemaNode,cOwner,cItem,collection.Owner.ID,key,null);
        }
      }
      catch (Exception e) {
        throw collection.session.utils.SubstituteException(e);
      }
      itemsUpdateActions.Clear();      
    }

    /// <summary>
    /// Clears all delayed updates.
    /// </summary>
    public void ClearChanges()
    {
      itemsUpdateActions.Clear();      
    }
    
    /// <summary>
    /// Loads collection content from <see cref="DataObjects.NET.Caching.GlobalCache"/>.
    /// </summary>
    /// <returns>Cached collection content.</returns>
    public long[] LoadItemsFromGlobalCache()
    {
      Session s = collection.Session;
      Field f = collection.Field;
      Culture c = collection.Culture;
      DataObject owner = collection.Owner;
      
      string propertyName = f.Name + (f.Translatable ? "-"+c.Name : "");
      PropertyInstantiationInfo pInstInfo = (PropertyInstantiationInfo)
        s.Cache.GlobalCache[new PropertyKey(owner.ID, propertyName), owner.VersionID];
        
      if (pInstInfo==null) {
        s.Domain.PerformanceCounters.RegisterCacheHit(
          InstantiationInfoSource.Database, false);
        return null;
      }
      
      object data = pInstInfo.GetValue();
      if (data.GetType()==typeof(long[])) {
        s.Domain.PerformanceCounters.RegisterCacheHit(
          InstantiationInfoSource.GlobalCache, false);
        return (long[])data;
      }
      
      s.Domain.PerformanceCounters.RegisterCacheHit(
        InstantiationInfoSource.Database, false);
      return null;
    }
    
    /// <summary>
    /// Saves collection content to <see cref="DataObjects.NET.Caching.GlobalCache"/>.
    /// </summary>
    public void SaveItemsToGlobalCache()
    {
      Session s = collection.Session;
      Field f = collection.Field;
      Culture c = collection.Culture;
      DataObject owner = collection.Owner;
      
      string propertyName = f.Name + (f.Translatable ? "-"+c.Name : "");
      PropertyInstantiationInfo pInstInfo =
        new PropertyInstantiationInfo(GlobalCacheItemType.DataObjectCollection, owner.ID, propertyName, owner.VersionID);
      pInstInfo.SetValue(GetContainedItems());
      s.Cache.GlobalCache.Remove(new PropertyKey(owner.ID, propertyName));
      s.Cache.GlobalCache.Add(pInstInfo);
    }
    
    /// <summary>
    /// Loads the number of elements contained in the collection from <see cref="DataObjects.NET.Caching.GlobalCache"/>.
    /// </summary>
    /// <returns>Cached collection size.</returns>
    public int LoadCountFromGlobalCache()
    {
      Session s = collection.Session;
      Field f = collection.Field;
      Culture c = collection.Culture;
      DataObject owner = collection.Owner;
      
      string propertyName = f.Name + (f.Translatable ? "-"+c.Name : "");
      PropertyInstantiationInfo pInstInfo = (PropertyInstantiationInfo)
        s.Cache.GlobalCache[new PropertyKey(owner.ID, propertyName), owner.VersionID];
        
      if (pInstInfo==null) {
        s.Domain.PerformanceCounters.RegisterCacheHit(
          InstantiationInfoSource.Database, false);
        return -1;
      }
        
      s.Domain.PerformanceCounters.RegisterCacheHit(
        InstantiationInfoSource.GlobalCache, false);
        
      object data = pInstInfo.GetValue();
      if (data.GetType()==typeof(long[]))
        return ((long[])data).Length;
      
      return (int)data;
    }
    
    /// <summary>
    /// Saves the number of elements contained int the collection to <see cref="DataObjects.NET.Caching.GlobalCache"/>.
    /// </summary>
    public void SaveCountToGlobalCache()
    {
      Session s = collection.Session;
      Field f = collection.Field;
      Culture c = collection.Culture;
      DataObject owner = collection.Owner;
      
      string propertyName = f.Name + (f.Translatable ? "-"+c.Name : "");
      PropertyInstantiationInfo pInstInfo =
        new PropertyInstantiationInfo(GlobalCacheItemType.DataObjectCollection, owner.ID, propertyName, owner.VersionID);
      pInstInfo.SetValue(count);
      s.Cache.GlobalCache.Add(pInstInfo);
    }
    

    // Constructor

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="collection">Collection that will use this instance.</param>
    internal DataObjectCollectionImplementation(DataObjectCollection collection)
    {
      this.collection = collection;
    }
  }
}
