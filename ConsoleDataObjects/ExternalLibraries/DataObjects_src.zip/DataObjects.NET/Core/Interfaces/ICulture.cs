// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Globalization;

namespace DataObjects.NET
{
  /// <summary>
  /// Summary description for ICultureInfo.
  /// </summary>
  public interface ICulture
  {
    /// <summary>
    /// Name of the culture (E.g. "En"). 
    /// </summary>
    string Name {get;}

    /// <summary>
    /// Title of the culture (E.g. "German").
    /// </summary>
    string Title {get; set;}

    /// <summary>
    /// <see cref="CultureInfo"/> object associated with this culture.
    /// </summary>
    CultureInfo Info {get;}

    /// <summary>
    /// <see cref="CompareOptions"/> object associated with this culture.
    /// </summary>
    CompareOptions CompareOptions {get;}

    /// <summary>
    /// Gets the index of this <see cref="ICulture"/> instance in the
    /// collection where this culture is plased.
    /// </summary>
    int Index {get;}
    
    /// <summary>
    /// <see langword="True"/> if this <see cref="ICulture"/> instance is the default culture.
    /// </summary>
    bool Default {get;}

    /// <summary>
    /// Gets <see cref="SqlCollation"/> for this <see cref="ICulture"/> instance.
    /// </summary>
    SqlCollation SqlCollation {get;}
  }
}
