// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.IO;
using System.Threading;
using System.Configuration;
using System.Runtime.Serialization;
using System.Diagnostics;
using System.Globalization;
using System.Collections;
using DataObjects.NET;
using DataObjects.NET.Attributes;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Security.Permissions;

namespace DataObjects.NET.Security
{
  /// <summary>
  /// Security permission set stored in the <see cref="AccessControlList"/>.
  /// <seealso cref="Permission"/>
  /// <seealso cref="IPermission"/>
  /// <seealso cref="IPermissionSet"/>
  /// </summary>
  [Serializable]
  public sealed class AccessControlListPermissionSet: PermissionSet,
    ISerializable,
    IDeserializationCallback
  {
    internal AccessControlList owner;
    internal long              principalID;
    internal bool              isAllowedSet;
    
    // Events
    
    /// <summary>
    /// Called before any changes are made in the collection.
    /// </summary>
    protected override void OnChanging()
    {
      if (owner==null)
        throw new InvalidOperationException(
          "This permission set is detached from the AccessControlList. " +
          "Use GetAllowedPermissionSet\\GetDeniedPermissionSet to " +
          "obtain it's updated copy.");
      owner.OnChanging(this);
    }

    /// <summary>
    /// Called after some changes were made in collection.
    /// </summary>
    protected override void OnChanged()
    {
      if (owner==null)
        throw new InvalidOperationException(
          "This permission set is detached from the AccessControlList. " +
          "Use GetAllowedPermissionSet\\GetDeniedPermissionSet to " +
          "obtain it's updated copy.");
      owner.OnChanged(this);
    }
    
    /// <summary>
    /// Runs when the entire object graph has been deserialized.
    /// </summary>
    /// <param name="sender">The object that initiated the callback. The functionality for the this parameter is not currently implemented.</param>
    public void OnDeserialization(object sender)
    {
      ArrayList toRemove = new ArrayList();
      foreach (IPermission ip in this)
        if (ip is NotDeserializedPermission) {
          owner.Inconsistent = true;
          toRemove.Add(ip);
          break;
        }
      foreach (IPermission ip in toRemove) {
        // TODO: Optimize
        InternalSubtract(ip);
      }
    }


    // Constructors
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="owner"><see cref="AccessControlList"/> this set is bound to.</param>
    /// <param name="principalID">ID of the <see cref="Principal"/> this set is bound to.</param>
    /// <param name="isAllowedSet"><see langword="True"/>, if the set is "allowed set"; 
    /// otherwise, <see langword="false"/>.</param>
    internal AccessControlListPermissionSet(
      AccessControlList owner, long principalID, bool isAllowedSet)
    {
      this.owner        = owner;
      this.principalID  = principalID;
      this.isAllowedSet = isAllowedSet;
    }

    /// <summary>
    /// Deserialization constructor.
    /// </summary>
    /// <param name="info"><see cref="SerializationInfo"/> object.</param>
    /// <param name="context"><see cref="StreamingContext"/> object.</param>
    private AccessControlListPermissionSet(SerializationInfo info, StreamingContext context) :
      base(info, context)
    {
    #if MONO
      if (Count==0) {
        if (isAllowedSet)
          this.owner.allowedPermissionSets.Remove(principalID);
        else
          this.owner.deniedPermissionSets.Remove(principalID);
        if (this.owner.allowedPermissionSets.Count==0 &&
            this.owner.deniedPermissionSets.Count==0)
          this.owner.principals.Remove(principalID);
      }
    #endif
    }
  }
}
