// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Configuration;

namespace DataObjects.NET
{
  /// <summary>
  /// Each instance of this class provides access to 
  /// static methods of <see cref="Configuration"/> object.
  /// </summary>
  /// <remarks>
  /// Any two instances of this class work absolutely the same. So this
  /// type can be configured (in the remoting configuration section of
  /// your application) as well-known object operating in single-call
  /// or singleton mode. It will provide remote access to 
  /// <see cref="Configuration"/> object, which methods are static
  /// (so it's impossible to call them remotely).
  /// </remarks>
  public sealed class ConfigurationEndPoint: MarshalByRefObject
  {
    /// <summary>
    /// Nonstatic version of <see cref="Configuration"/>.<see cref="Configuration.Domains"/>.
    /// </summary>
    public DomainCollection Domains {
      get {
        return Configuration.Domains;
      }
    }
    
    /// <summary>
    /// Nonstatic version of <see cref="Configuration"/>.<see cref="Configuration.DefaultDomain"/>.
    /// </summary>
    public Domain DefaultDomain {
      get {
        return Configuration.DefaultDomain;
      }
    }
  }
}
