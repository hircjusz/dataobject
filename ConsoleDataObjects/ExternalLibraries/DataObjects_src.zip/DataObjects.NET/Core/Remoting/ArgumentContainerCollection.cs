// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;

namespace DataObjects.NET.Remoting
{
  /// <summary>
  /// Collection of the <see cref="ArgumentContainer"/> instances.
  /// </summary>
  [Serializable]
  public class ArgumentContainerCollection : CollectionBase,
    ICloneable
  {
    /// <summary>
    /// Creates a new object that is a copy of a curent instance.
    /// </summary>
    public object Clone()
    {
      ArgumentContainerCollection clone = new ArgumentContainerCollection();
      for (int i=0, count=Count; i<count; i++)
        clone.InnerList.Add(this[i].Clone());
      return clone;
    }

    /// <summary>
    /// Adds specified <see cref="ArgumentContainer"/> instance to the end of collection.
    /// </summary>
    public int Add(ArgumentContainer argument)
    {
      return this.List.Add(argument);
    }
    
    /// <summary>
    /// Adds a range of the <see cref="ArgumentContainer"/> instances to the end of collection.
    /// </summary>
    public void AddRange(ArgumentContainer[] arguments)
    {
      for (int i=0, count=arguments.Length; i<count; i++)
        this.List.Add(arguments[i]);
    }

    /// <summary>
    /// Inserts an <see cref="ArgumentContainer"/> instance to the collection at the specified index.
    /// </summary>
    public void Insert(int index, ArgumentContainer argument)
    {
      this.List.Insert(index, argument);
    }
    
    /// <summary>
    /// Determines whether collection contains specified <see cref="ArgumentContainer"/> instance.
    /// </summary>
    /// <param name="argument"><see cref="ArgumentContainer"/> instance to check for the containment.</param>
    /// <returns><see langword="True"/> if specified <paramref name="argument"/> is found; 
    /// otherwise, <see langword="false"/></returns>
    public bool Contains(ArgumentContainer argument)
    {
      return this.List.Contains(argument);
    }
    
    /// <summary>
    /// Returns the index of the specified <see cref="ArgumentContainer"/> instance in the collection.
    /// </summary>
    /// <param name="argument"><see cref="ArgumentContainer"/> instance to locate.</param>
    /// <returns>Index of the specified <paramref name="argument"/>, if found;
    /// otherwise, <see langword="-1"/>.</returns>
    public int IndexOf(ArgumentContainer argument)
    {
      return this.List.IndexOf(argument);
    }
    
    /// <summary>
    /// Removes specified <see cref="ArgumentContainer"/> instance from the collection"/>.
    /// </summary>
    /// <param name="argument">Instance to remove.</param>
    public void Remove(ArgumentContainer argument)
    {
      this.List.Remove(argument);
    }

    /// <summary>
    /// Gets or sets the <see cref="ArgumentContainer"/> instance by its index.
    /// </summary>
    public ArgumentContainer this[int index] {
      get {
        return (ArgumentContainer)this.List[index];
      }
      set {
        this.List[index] = value;
      }
    }

    /// <summary>
    /// Validates type of the inserted item.
    /// </summary>
    protected override void OnValidate(object value)
    {
      if (value==null)
        throw new ArgumentNullException("Collection item can't be null.");
      if (!(value is ArgumentContainer))
        throw new InvalidOperationException("Incompatible item type.\nCollection item should implement IMethodParameter interface.");
    }

    /// <summary>
    /// Returns an <see cref="Array"/> of parameter values.
    /// </summary>
    public object[] ToValuesArray(CallContext context)
    {
      object[] paramValues = new object[Count];
      for (int i=0, count=Count; i<count; i++)
        paramValues[i] = this[i].GetValue(context);
      return paramValues;
    }

    // Constructors
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    public ArgumentContainerCollection() :
      base()
    {
    }
  }
}
