// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Runtime.Serialization;
using DataObjects.NET.DatabaseModel;

namespace DataObjects.NET.Exceptions
{
  /// <summary>
  /// Describes different errors which may occur while extracting 
  /// <see cref="Database">database model</see>.
  /// </summary>
  [Serializable]
  public class DatabaseModelExtractorException: DataObjectsDotNetException
  {
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    public DatabaseModelExtractorException(): base("Database Model Extractor error.") {}

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="text">Text of message.</param>
    public DatabaseModelExtractorException(string text): base(text) {}

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="innerException">Inner exception.</param>
    public DatabaseModelExtractorException(Exception innerException): this("Database Model Extractor error.",innerException) 
    {
    }
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="text">Text of message.</param>
    /// <param name="innerException">Inner exception.</param>
    public DatabaseModelExtractorException(string text, Exception innerException): base(text,innerException) 
    {
    }
    
    /// <summary>
    /// Deserialization constructor.
    /// </summary>
    /// <param name="info"><see cref="SerializationInfo"/> object.</param>
    /// <param name="context"><see cref="StreamingContext"/> object.</param>
    protected DatabaseModelExtractorException(SerializationInfo info, StreamingContext context):
      base(info, context)
    {
    }
  }
}