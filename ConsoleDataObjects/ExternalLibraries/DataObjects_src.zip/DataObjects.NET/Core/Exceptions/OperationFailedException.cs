// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Runtime.Serialization;

namespace DataObjects.NET.Exceptions
{
  /// <summary>
  /// This client-side exception is thrown when a set
  /// of errors (or at least one error) has occured during
  /// a set of server-side operations. 
  /// Usually it is thrown on <see cref="Offline.ObjectSet.ApplyChanges"/>
  /// operation in the <see cref="Offline.ObjectSet"/>.
  /// </summary>
  [Serializable]
  public class OperationFailedException: DataObjectsDotNetException
  {
    private Exception[] errors;

    /// <summary>
    /// Gets an array of errors that lead to this exception.
    /// </summary>
    public Exception[] Errors {
      get {
        return errors;
      }
    }

    /// <summary>
    /// Creates and returns a string representation of the exception.
    /// </summary>
    public override string ToString()
    {
      if (errors==null || errors.Length<2)
        return base.ToString();
      string result = GetType().FullName;
      if (Message!=null && Message.Length>0)
        result = String.Concat(result, ": ", Message);
      result += " Inner exceptions:";
      string[] resultParts = new string[errors.Length+1];
      resultParts[0] = result;
      if (errors!=null)
        for (int errorIndex=0, errorCount=errors.Length; errorIndex<errorCount; errorIndex++)
          resultParts[errorIndex+1] = errors[errorIndex].ToString();
      result = String.Join(Environment.NewLine + " ---> ", resultParts);
      result = String.Concat(result, Environment.NewLine, " --- End of inner exceptions list --- ");
      if (this.StackTrace != null)
        result = String.Concat(result, Environment.NewLine, this.StackTrace);
      return result;
    }

    // Constructors

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="errors">Initial <see cref="Errors"/> property value.</param>
    public OperationFailedException(Exception[] errors): 
      this(errors, "An errors occured during operation execution.")
    {
    }
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="errors">Initial <see cref="Errors"/> property value.</param>
    /// <param name="message">Error message.</param>
    public OperationFailedException(Exception[] errors, string message) : 
      base(message, (errors!=null && errors.Length>0 ? errors[0] : null))
    {
      this.errors = errors;
    }
    
    /// <summary>
    /// Deserialization constructor.
    /// </summary>
    /// <param name="info"><see cref="SerializationInfo"/> object.</param>
    /// <param name="context"><see cref="StreamingContext"/> object.</param>
    protected OperationFailedException(SerializationInfo info, StreamingContext context): base(info, context)
    {
    }
  }
}
