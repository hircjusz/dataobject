// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Configuration;

namespace DataObjects.NET
{
  /// <summary>
  /// Provides access to <see cref="Domain"/> objects that were
  /// configured via ExeName.config or Web.config file.
  /// </summary>
  /// <remarks>
  /// <example>An example of configuration file:
  /// <code>
  ///  &lt;configuration&gt;
  ///    &lt;configSections&gt;
  ///      &lt;section name="DataObjects.NET"
  ///              type="DataObjects.NET.ConfigurationSectionHandler,Dataobjects.NET" /&gt;
  ///    &lt;/configSections&gt;
  ///    
  ///    &lt;DataObjects.NET&gt;
  ///      &lt;clientSideCache
  ///        folder="ClientSideCache"
  ///        expirationPeriod="3.00:00:00" /&gt;
  ///      &lt;domain
  ///        name="Default"
  ///        runtimeServiceStartupDelay="00:00:30"
  ///        guid="F9168C5E-CEB2-4faa-B6BF-329BF39FA1E4"
  ///        objectModelGuid="F9168C5E-CEB2-4faa-B6BF-329BF755A1E4"
  ///        connectionUrl="mssql://localhost/DataObjectsDotNetDemos"
  ///        productKeyPath=""
  ///        productKey=""
  ///        debugInfoOutputFolder="C:/Debug"      
  ///        proxyAssemblyCacheFolder="C:/Debug"
  ///        globalCacheSize="10240000"
  ///        transactionalUpdate="false"
  ///        threadedBuildExecution="false"
  ///        fastLoadDataFormat="Compact"
  ///        databaseOptions="CreateForeignKeys,CreateNullRows,EnableFullTextSearch"
  ///        namingMode="UseNamespaces"
  ///        identifierPrefix="do"
  ///        securityMode="Modern"
  ///        securityOptions="Standard"
  ///        sessionSecurityOptions="Standard"      
  ///        remoteSessionSecurityOptions="Minimal"      
  ///        defaultUpdateMode="Recreate"
  ///        build="false"      
  ///        &gt;
  ///        &lt;cultures defaultCulture="En"&gt;
  ///          &lt;culture name="En" title="U.S. English"
  ///                  cultureName="en-US" 
  ///                  compareOptions="IgnoreWidth,IgnoreKanaType"
  ///          /&gt;
  ///        &lt;/cultures&gt;
  ///        &lt;load&gt;
  ///          &lt;assembly  name="AddOn.PersistentModel" /&gt;
  ///        &lt;/load&gt;
  ///        &lt;types&gt;
  ///          &lt;assembly  name="AddOn.PersistentModel" /&gt;
  ///          &lt;namespace name="MyApplication.PersistentModel" /&gt;
  ///        &lt;/types&gt;
  ///        &lt;services&gt;
  ///          &lt;assembly  name="AddOn.PersistentModel" /&gt;
  ///          &lt;namespace name="MyApplication.PersistentModel" /&gt;
  ///        &lt;/services&gt;
  ///        &lt;fieldTypes&gt;
  ///          &lt;assembly  name="AddOn.PersistentModel" /&gt;
  ///        &lt;/fieldTypes&gt;
  ///      &lt;/domain&gt;
  ///    &lt;/DataObjects.NET&gt;
  ///  &lt;/configuration&gt;
  /// </code>
  /// </example>
  /// </remarks>
  public sealed class Configuration
  {
    /// <summary>
    /// Mono cannot lock bool values, so we will use this wrapper to store bool flag.
    /// </summary>
    private class Configured
    {
      public bool Value = false;
    }

    static Configured configured = new Configured(); 
    static DomainCollection domains;
    static string sectionName = "DataObjects.NET";
    
    /// <summary>
    /// Gets or sets the name of DataObjects.NET configuration section
    /// in ExeName.config or Web.config file.
    /// Default value is "DataObjects.NET".
    /// </summary>
    /// <remarks>
    /// It's possible to set a value of this property only prior to
    /// accessing <see cref="Domains"/> or <see cref="DefaultDomain"/>
    /// properties.
    /// </remarks>
    public static string SectionName {
      get {
        lock (configured) {
          return sectionName;
        }
      }
      set {
        lock (configured) {
          if (configured.Value)
            throw new InvalidOperationException(
              "DataObjects.NET configuration is already done.");
          sectionName = value;
        }
      }
    }
    
    /// <summary>
    /// Gets a collection of <see cref="Domain"/> objects that were
    /// configured via ExeName.config or Web.config file.
    /// </summary>
    public static DomainCollection Domains {
      get {
        lock (configured) {
          if (!configured.Value) {
            domains = (DomainCollection)ConfigurationSettings.GetConfig(sectionName);
            configured.Value = true;
          }
          return domains;
        }
      }
    }
    
    /// <summary>
    /// The same as <see cref="Domains"/>.<see cref="DefaultDomain"/>.
    /// </summary>
    public static Domain DefaultDomain {
      get {
        return Domains.DefaultDomain;
      }
    }
  }
}
