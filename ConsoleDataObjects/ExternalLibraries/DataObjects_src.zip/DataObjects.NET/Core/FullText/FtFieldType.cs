// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

namespace DataObjects.NET.FullText
{
  /// <summary>
  /// Enumerates supported <see cref="FtField"/> types.
  /// </summary>
  public enum FtFieldType
  {
    /// <summary>
    /// Keyword field - fields of this type aren't parsed 
    /// aren't exploded into tokens (words), so it's only possible
    /// to search for the whole value of such field.
    /// </summary>
    Keyword,
    /// <summary>
    /// Text field - fields of this type are parsed and exploded
    /// into tokens (word).
    /// </summary>
    Text,
    /// <summary>
    /// Text field - fields of this type are parsed and exploded
    /// into tokens (word). Also the full field content is stored.
    /// </summary>
    StoredText,
  }
}