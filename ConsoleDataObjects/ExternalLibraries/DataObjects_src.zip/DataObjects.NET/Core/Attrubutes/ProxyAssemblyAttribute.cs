using System;

namespace DataObjects.NET.Attributes
{
  /// <summary>
  /// This attribute is an internal marker of proxy assemblies.
  /// This attribute should not be used in your code.
  /// </summary>
  [Serializable]
  [AttributeUsage(AttributeTargets.Assembly)]
  public class ProxyAssemblyAttribute: DataObjectAttribute
  {
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    public ProxyAssemblyAttribute() {}
  }
}