// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;
using DataObjects.NET.Attributes;
using Offline=DataObjects.NET.Offline;

namespace DataObjects.NET.Helpers
{
  /// <summary>
  /// A <see cref="IPropertyValueCorrector">corrector</see> that
  /// checks if property value fits into specified range and replaces it with <see cref="UpperBound"/> 
  /// or <see cref="LowerBound"/> respectively if this condition is violated.
  /// <seealso cref="CorrectorAttribute"/>
  /// <seealso cref="IComparable"/>
  /// </summary>
  /// <remarks>
  /// See <see cref="CorrectorAttribute"/> also.
  /// See <see cref="IComparable"/> also.
  /// </remarks>
  [Serializable]
  public class RangeTruncator: IPropertyValueCorrector, Offline.IPropertyValueCorrector
  {
    // We should hold object references here instead of IComparable ones
    // to prevent bug with a Validator deserialization
    private object lowerBound;
    private object upperBound;

    /// <summary>
    /// Gets minimal property value that passes through this corrector.
    /// <seealso cref="IComparable"/>.
    /// </summary>
    public IComparable LowerBound {
      get {
        return (IComparable)lowerBound;
      }
    }

    /// <summary>
    /// Gets maximal property value that passes through this corrector.
    /// <seealso cref="IComparable"/>.
    /// </summary>
    public IComparable UpperBound{
      get {
        return (IComparable)upperBound;
      }
    }


    /// <summary>
    /// Corrects <see cref="DataObject"/> property value 
    /// before it is actually set by 
    /// <see cref="DataObject.SetProperty">DataObject.SetProperty</see>
    /// method.
    /// </summary>
    /// <param name="dataObject"><see cref="DataObject"/> instance
    /// which property is to be changed.</param>
    /// <param name="propertyName">Property name.</param>
    /// <param name="culture">Property culture.</param>
    /// <param name="value">Property value to correct.</param>
    /// <returns>Corrected property value.</returns>
    /// <remarks>
    /// Checks if property value fits into specified range and replaces it with <see cref="UpperBound"/> 
    /// or <see cref="LowerBound"/> respectively if this condition is violated.
    /// </remarks>
    public object CorrectValue(DataObject dataObject, string propertyName, Culture culture, object value) 
    {
      return CorrectValue(value);
    }

    /// <summary>
    /// Corrects <see cref="DataObject"/> property value 
    /// before it is actually set by 
    /// <see cref="DataObject.SetProperty">DataObject.SetProperty</see>
    /// method.
    /// </summary>
    /// <param name="dataObject"><see cref="DataObject"/> instance
    /// which property is to be changed.</param>
    /// <param name="propertyName">Property name.</param>
    /// <param name="culture">Property culture.</param>
    /// <param name="value">Property value to correct.</param>
    /// <returns>Corrected property value.</returns>
    /// <remarks>
    /// Checks if property value fits into specified range and replaces it with <see cref="UpperBound"/> 
    /// or <see cref="LowerBound"/> respectively if this condition is violated.
    /// </remarks>
    public object CorrectValue(Offline.DataObject dataObject, string propertyName, Offline.Culture culture, object value) 
    {
      return CorrectValue(value);
    }
    
    private object CorrectValue(object value)
    {
      //checking lower range
      if (lowerBound != null) {
        if (LowerBound.CompareTo(value)>0) { // lowerBound > value
          value = lowerBound;
        }
      }

      //checking upperbound
      if (upperBound==null) {
        value = null;
      }
      else {
        if (UpperBound.CompareTo(value) < 0) // upperBound < value
          value = upperBound;
      }
      return value;
    }
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="lowerBound">
    /// Minimal property value that passes through this corrector.
    /// <seealso cref="IComparable"/>.
    /// </param>
    /// <param name="upperBound">
    /// Maximal property value that passes through this corrector.
    /// <seealso cref="IComparable"/>.
    /// </param>
  #if !MONO
    public RangeTruncator(IComparable lowerBound, IComparable upperBound)
    {
      this.lowerBound = lowerBound;
      this.upperBound = upperBound;
    }
  #else
    public RangeTruncator(object lowerBound, object upperBound)
    {
      IComparable argLowerBound = lowerBound as IComparable;
      if (argLowerBound==null)
        throw new ArgumentException( "Argument should implement IComparable interface", "lowerBound");
      IComparable argUpperBound = upperBound as IComparable;
      if (argUpperBound==null)
        throw new ArgumentException( "Argument should implement IComparable interface", "upperBound");
      this.lowerBound = lowerBound;
      this.upperBound = upperBound;
    }
  #endif
  }
}
