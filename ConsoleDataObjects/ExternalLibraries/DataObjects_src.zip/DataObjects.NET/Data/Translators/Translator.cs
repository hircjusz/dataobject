// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;
using System.Data;
using DataObjects.NET.Exceptions;

namespace DataObjects.NET.Data
{
  /// <summary>
  /// Provides a relation between <see cref="DataObject"/> types and <see cref="DataTable"/>s.
  /// </summary>
  internal class Translator
  {
    private Adapter adapter;
    private Hashtable doTranslatorByType;
    private Hashtable doTranslatorByTable;
    private Hashtable doTranslatorListByType;
    private Hashtable updatedPropByPath;
    
    /// <summary>
    /// Gets <see cref="Adapter"/> associated with the <see cref="Translator"/>.
    /// </summary>
    public Adapter Adapter 
    {
      get {
        return adapter;
      }
    }
    
    /// <summary>
    /// Fills specified <see cref="DataObject"/> into adapter's DataSource.
    /// </summary>
    /// <param name="dataObject"><see cref="DataObject"/> to fill.</param>
    public void Fill(DataObject dataObject)
    {
      if (dataObject==null)
        throw new ArgumentNullException("dataObject");
        
      DoTranslator[] translators = GetTranslators(dataObject.Type);
      
      for (int i = 0; i < translators.Length; i++)
        translators[i].Fill(dataObject);
    }
    
    /// <summary>
    /// Updates specified <see cref="DataObject"/> from adapter's DataSource.
    /// </summary>
    /// <param name="dataObject"><see cref="DataObject"/> to update.</param>
    public void Update(DataObject dataObject)
    {
      if (dataObject==null)
        throw new ArgumentNullException("dataObject");
        
      DoTranslator[] translators = GetTranslators(dataObject.Type);
      
      updatedPropByPath = new Hashtable();
      
      string versionCode = dataObject.VersionCode;
      
      for (int i = 0; i < translators.Length; i++)
        translators[i].Update(dataObject, versionCode);
    }
    
    /// <summary>
    /// Fills specified <see cref="DataObject"/> into adapter's DataSource after update operation.
    /// </summary>
    /// <param name="dataObject"><see cref="DataObject"/> to fill.</param>
    internal void FillAfterUpdate(DataObject dataObject)
    {
      if (dataObject==null)
        throw new ArgumentNullException("dataObject");
        
      DoTranslator[] translators = GetTranslators(dataObject.Type);
      
      for (int i = 0; i < translators.Length; i++)
        translators[i].FillAfterUpdate(dataObject);
    }
    
    /// <summary>
    /// Updates <see cref="DataObjectCollection"/>s and <see cref="ValueTypeCollection"/>s.
    /// </summary>
    public void UpdateCollections()
    {
      ICollection doTranslators = doTranslatorByType.Values;
      foreach (DoTranslator doTranslator in doTranslators)
        doTranslator.UpdateCollections();
    }
    
    private DoTranslator[] GetTranslators(ObjectModel.Type type)
    {
      if (doTranslatorListByType==null)
        doTranslatorListByType = new Hashtable();
        
      DoTranslator[] translators = (DoTranslator[])doTranslatorListByType[type];
        
      if (translators==null) {
        ArrayList tmpList = new ArrayList();
        
        for (ObjectModel.Type currentType = type; ; currentType = currentType.BaseType) {
          DoTranslator doTranslator = (DoTranslator)doTranslatorByType[currentType];
          if (doTranslator!=null)
            tmpList.Add(doTranslator);
          if (currentType.SourceType==typeof(DataObjects.NET.DataObject))
            break;
        }
        
        ObjectModel.InterfaceCollection interfaces = type.Interfaces;
        foreach (ObjectModel.Type interfaceType in interfaces) {
          DoTranslator interfaceDoTranslator = (DoTranslator)doTranslatorByType[interfaceType];
          if (interfaceDoTranslator!=null)
            tmpList.Add(interfaceDoTranslator);
        }
        
        translators = (DoTranslator[])tmpList.ToArray(typeof(DoTranslator));
        
        doTranslatorListByType[type] = translators;
      }
      
      return translators;
    }
    
    /// <summary>
    /// Returns <see langword="true"/> if specified property can be updated (it is not updated yet).
    /// </summary>
    /// <param name="path">Full property "path".</param>
    /// <returns><see langword="True"/> if specified property can be updated (it is not updated yet).</returns>
    internal bool CanUpdateProperty(string path)
    {
      if (updatedPropByPath.ContainsKey(path))
        return false;
      updatedPropByPath[path] = updatedPropByPath;
      return true;
    }
    
    /// <summary>
    /// Registers all objects <see cref="Translator"/> could update.
    /// Currently this method registers all object ids in 
    /// the <see cref="AdapterUpdateQueue"/> for creation, removal or update.
    /// </summary>
    internal void RegisterIds()
    {
      ICollection doTranslators = doTranslatorByType.Values;
      foreach (DoTranslator doTranslator in doTranslators)
        doTranslator.RegisterIds();
    }
    
    /// <summary>
    /// Updates system columns: sets ID and VersionCode in all raws that has id equal to oldID.
    /// </summary>
    /// <param name="oldID">old ID.</param>
    /// <param name="newID">new ID.</param>
    /// <param name="newVersionCode">new VersionCode.</param>
    internal void UpdateSystemColumns(long oldID, long newID, string newVersionCode)
    {
      ICollection doTranslators = doTranslatorByType.Values;
      foreach (DoTranslator doTranslator in doTranslators)
        doTranslator.UpdateSystemColumns(oldID, newID, newVersionCode);
    }
    
    /// <summary>
    /// Suggests <see cref="ObjectModel.Type"/> using id for <see cref="DataObject"/> creation.
    /// </summary>
    /// <param name="id">id.</param>
    /// <returns>Suggested <see cref="ObjectModel.Type"/> or null.</returns>
    internal ObjectModel.Type SuggestType(long id)
    {
      ObjectModel.Type type = null;
      ICollection doTranslators = doTranslatorByType.Values;
      foreach (DoTranslator doTranslator in doTranslators) {
        ObjectModel.Type newType = doTranslator.SuggestType(id);
        if (type==null || (newType!=null && type.IsAncestorOf(newType)))
          type = newType;
      }
      return type;
    }
    
    /// <summary>
    /// Returns an <see cref="Array"/> of <see cref="DataRow"/>s, that corresponds to the id.
    /// </summary>
    /// <param name="id">id.</param>
    /// <returns>An <see cref="Array"/> of <see cref="DataRow"/>s, that corresponds to the id.</returns>
    internal DataRow[] GetCorrespondingRows(long id)
    {
      ArrayList rows = new ArrayList();
      ICollection doTranslators = doTranslatorByType.Values;
      foreach (DoTranslator doTranslator in doTranslators) {
        DataRow row = doTranslator.GetCorrespondingRow(id);
        if (row!=null)
          rows.Add(row);
      }
      return (DataRow[])rows.ToArray(typeof(DataRow));
    }
  
    /// <summary>
    /// Initializes a new instance of the <see cref="Translator"/> class.
    /// </summary>
    /// <param name="adapter"></param>
    internal Translator(Adapter adapter)
    {
      if (adapter==null)
        throw new ArgumentNullException("adapter");
      if (adapter.DataSource==null)
        throw new NullReferenceException("adapter.DataSource is null.");
        
      this.adapter = adapter;
      
      doTranslatorByType = new Hashtable();
      doTranslatorByTable = new Hashtable();
      
      foreach (ClassMappingItem mappingItem in adapter.ClassMapping) {
        DoTranslator doTranslator = new DoTranslator(adapter, mappingItem);
        if (doTranslatorByType.ContainsKey(doTranslator.Type))
          throw new AdapterException(
            String.Format("Type \"{0}\" is already mapped.", doTranslator.Type.SourceType.FullName));
        if (doTranslatorByTable.ContainsKey(doTranslator.DataTable))
          throw new AdapterException(
            String.Format("Table \"{0}\" is already mapped.", doTranslator.DataTable.TableName));
        doTranslatorByType[doTranslator.Type] = doTranslator;
        doTranslatorByTable[doTranslator.DataTable] = doTranslator;
      }
      
      foreach (InterfaceMappingItem mappingItem in adapter.InterfaceMapping) {
        DoTranslator doTranslator = new DoTranslator(adapter, mappingItem);
        if (doTranslatorByType.ContainsKey(doTranslator.Type))
          throw new AdapterException(
            String.Format("Type \"{0}\" is already mapped.", doTranslator.Type.SourceType.FullName));
        if (doTranslatorByTable.ContainsKey(doTranslator.DataTable))
          throw new AdapterException(
            String.Format("Table \"{0}\" is already mapped.", doTranslator.DataTable.TableName));
        doTranslatorByType[doTranslator.Type] = doTranslator;
        doTranslatorByTable[doTranslator.DataTable] = doTranslator;
      }
    }
  }
}
