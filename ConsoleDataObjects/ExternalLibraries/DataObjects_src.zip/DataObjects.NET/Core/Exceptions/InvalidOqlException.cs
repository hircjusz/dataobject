// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.IO;
using System.Text;
using System.Runtime.Serialization;

namespace DataObjects.NET.Exceptions
{
  /// <summary>
  /// Thrown by <see cref="Query"/> on different errors in the
  /// <see cref="Query.Text"/> property syntax.
  /// </summary>
  [Serializable]
  public class InvalidOqlException: PersisterException
  {
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    public InvalidOqlException(): base("Invalid OQL expression.") {}
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="message">Error message.</param>
    public InvalidOqlException(string message): base(message) {}

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="message">Error message.</param>
    /// <param name="text">Text containing error.</param>
    /// <param name="pos">Error position.</param>
    public InvalidOqlException(string message, string text, int pos): 
      base(
        "Invalid OQL expression ("+message+"): \""+
          text.Substring(0,pos)+
          "[Error]"+
          text.Substring(pos)+"\".") {}

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="text">Text containing error.</param>
    /// <param name="pos">Error position.</param>
    public InvalidOqlException(string text, int pos): 
      base(
        "Invalid OQL expression: \""+
          text.Substring(0,pos)+
          "[Error]"+
          text.Substring(pos)+"\".") {}
    
    /// <summary>
    /// Deserialization constructor.
    /// </summary>
    /// <param name="info"><see cref="SerializationInfo"/> object.</param>
    /// <param name="context"><see cref="StreamingContext"/> object.</param>
    protected InvalidOqlException(SerializationInfo info, StreamingContext context):
      base(info, context)
    {
    }
  }
}
