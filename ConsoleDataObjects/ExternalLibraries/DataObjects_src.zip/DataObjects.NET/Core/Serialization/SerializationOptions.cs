// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Attributes;
using DataObjects.NET.Security;

namespace DataObjects.NET.Serialization
{
  /// <summary>
  /// Enumeration of possible serialization options 
  /// for the <see cref="Serializer"/>.
  /// <note type="note"><see cref="ISecurityRoot"/> object is always serialized
  /// as reference, also its <see cref="DataObject.ID"/> value stored in the
  /// deserialization stream is ignored during the deserialization (because
  /// only one <see cref="ISecurityRoot"/> instance can exist in the storage).
  /// </note>
  /// <seealso cref="DeserializationOptions"/>
  /// </summary>
  [Flags]
  public enum SerializationOptions
  {
    /// <summary>
    /// Simplest serialization mode.
    /// Serializes only instances that are <see langword="directly"/> 
    /// refered from the other instance types in the serialization graph.
    /// Value is <see langword="0"/>. 
    /// </summary>
    Minimal = 0,
    /// <summary>
    /// Use this option to additionally include all contained 
    /// (see <see cref="ContainedAttribute"/>) instances (recursively)
    /// to the serialization stream.
    /// Value is <see langword="0x1"/>. 
    /// </summary>
    IncludeContainedInstances = 0x1,
    /// <summary>
    /// Use this option to additionally include all refered isntances 
    /// (recursively) to the serialization stream.
    /// Value is <see langword="0x2"/>. 
    /// </summary>
    IncludeReferedInstances   = 0x2,
    /// <summary>
    /// This option makes serializer to store information about all 
    /// references to external instances (instances, that exists in the 
    /// database, but can't be serialized, e.g when instance isn't contained,
    /// but <see cref="SerializationOptions"/> require to serialize only 
    /// contained instances. For any external instance <see cref="Serializer"/> 
    /// stores its ID and <see cref="Type"/>. In this case further (during 
    /// deserialization) it will be possible to restore references to such
    /// instances.
    /// Value is <see langword="0x4"/>. 
    /// </summary>
    IncludeExternalReferences = 0x4,
    /// <summary>
    /// Use this option to serialize permissions additionaly.
    /// This option takes effect only when the <see cref="AlwaysUseReferences"/> 
    /// option isn't specified.
    /// Value is <see langword="0x8"/>. 
    /// </summary>
    IncludePermissions  = 0x8,
    /// <summary>
    /// This option makes serializer to store only ID of 
    /// persistent instance rather then full instance data. 
    /// Value is <see langword="0x10"/>. 
    /// </summary>
    AlwaysUseReferences = 0x10,
    /// <summary>
    /// Default serialization mode.
    /// Value is <see langword="0x1 | 0x4 | 0x8"/>. 
    /// </summary>
    Default = 0x1 | 0x4 | 0x8,
    /// <summary>
    /// Most comprehensive serialization mode.
    /// Value is <see langword="0x1 | 0x2 | 0x4 | 0x8"/>. 
    /// </summary>
    Maximal = 0x1 | 0x2 | 0x4 | 0x8,
//    /// <summary>
//    /// This option affects only on XML serialization and allows to serialize 
//    /// contained instances into the nodes of the collection containing them.
//    /// Value is <see langword="0x10"/>. 
//    /// </summary>
//    Tree                      = 0x10,
  }
}
