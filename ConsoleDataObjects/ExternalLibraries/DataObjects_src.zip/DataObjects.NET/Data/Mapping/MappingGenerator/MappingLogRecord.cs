// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;

namespace DataObjects.NET.Data
{
  /// <summary>
  /// Single record of a log.
  /// </summary>
  public class MappingLogRecord
  {
    /// <summary>
    /// Mapping item source. This could be interface, class, collection or field full name.
    /// </summary>
    public string Source;
    
    /// <summary>
    /// Mapping item destination. This could be table name or column full name (Table.Column).
    /// </summary>
    public string Destination;
    
    /// <summary>
    /// Initializes a new instance of the <see cref="MappingLogRecord"/> class.
    /// </summary>
    /// <param name="source">Mapping item source.</param>
    /// <param name="destination">Mapping item destination.</param>
    public MappingLogRecord(string source, string destination)
    {
      this.Source = source;
      this.Destination = destination;
    }
  }
}
