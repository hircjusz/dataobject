// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.IO;
using System.Threading;
using System.Configuration;
using System.Diagnostics;
using System.Globalization;
using System.Collections;
using DataObjects.NET;
using DataObjects.NET.Attributes;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Security.Permissions;

namespace DataObjects.NET.Security
{
  /// <summary>
  /// Base class for the user account.
  /// <see langword="Persistent, Abstract"/>.
  /// </summary>
  /// <remarks>
  /// <para>
  /// You can find more information about the whole DataObjects.NET
  /// security system <see cref="AccessControlList">here</see>.
  /// </para>
  /// </remarks>
  [Abstract]
  public abstract class User: Principal
  {
    /// <summary>
    /// <see langword="Persistent"/>.
    /// <see langword="True"/> if user is disabled.
    /// </summary>
    public bool IsDisabled {
      get {return (bool)GetProperty("IsDisabled", null);}
      set {SetProperty("IsDisabled", null, value);}
    }

//    /// <summary>
//    /// <see langword="Persistent"/>.
//    /// The collection of <see cref="UserInfo"/> objects 
//    /// related to this user.
//    /// </summary>
//    [ItemType(typeof(UserInfo))]
//    [PairTo(typeof(UserInfo),"User")]
//    public UserInfoCollection UserInfos {
//      get {return (UserInfoCollection)GetProperty("UserInfos", null);}
//    }

    /// <summary>
    /// Always <see langword="false"/>.
    /// </summary>
    [NotPersistent]
    public override bool IsRole {
      get {
        return false;
      }
    }

    /// <summary>
    /// Gets the type of the principal.
    /// </summary>
    [NotPersistent]
    public override PrincipalType PrincipalType {
      get {
        string name;
        DisableSecurity();
        try {
          name = (string)GetProperty("Name", null);
        }
        finally {
          EnableSecurity();
        }
        SystemObjectNames names = session.domain.systemObjectNames;
        if (name==names.systemUserName)
          return PrincipalType.SystemUser;
        if (name==names.administratorUserName)
          return PrincipalType.AdministratorUser;
        if (name==names.guestUserName)
          return PrincipalType.GuestUser;
        if (name==names.anonymousUserName)
          return PrincipalType.AnonymousUser;
        return PrincipalType.Normal;
      }
    }
    
    /// <summary>
    /// Authenticates the user.
    /// </summary>
    /// <param name="authParams">Authentication params (e.g. password).</param>
    /// <returns><see langword="True"/> if authentication was successful, 
    /// otherwise <see langword="false"/>.</returns>
    /// <remarks>
    /// <para>
    /// Override this method to implement your authentication mechanism.
    /// </para>
    /// <para>
    /// The implementation of this method in <see cref="User"/> type
    /// always returns <see langword="false"/>.
    /// </para>
    /// </remarks>
    public virtual bool Authenticate(params object[] authParams)
    {
      return false;
    }

    /// <summary>
    /// Called when user becomes current in the session (see 
    /// <see cref="Session.User"/> property).
    /// Override this method to perform some additional actions
    /// on attaching a user to the session (e.g. impersonation?).
    /// This method should never throw an exception.
    /// <seealso cref="Session.User"/>
    /// <seealso cref="Session.Authenticate"/>
    /// <seealso cref="Session"/>
    /// </summary>
    [Transactional(TransactionMode.Disabled)]
    protected internal virtual void OnAttachToSession()
    {
    }

    /// <summary>
    /// Called before another user becomes current in the session (see 
    /// <see cref="Session.User"/> property).
    /// Override this method to perform some additional actions
    /// on detaching a user from the session.
    /// This method should never throw an exception.
    /// <seealso cref="Session.User"/>
    /// <seealso cref="Session.Authenticate"/>
    /// <seealso cref="Session"/>
    /// </summary>
    [Transactional(TransactionMode.Disabled)]
    protected internal virtual void OnDetachFromSession()
    {
    }
  }
}
