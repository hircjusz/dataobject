// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;
using DataObjects.NET.ObjectModel;

namespace DataObjects.NET
{
  internal class QueryCompilerRefLayer
  {
    private ObjectModel.Type type;
    public  ObjectModel.Type Type {
      get {
        return type;
      }
    }
    
    private Field field;
    public  Field Field {
      get {
        return field;
      }
    }
    
    private Culture fieldCulture;
    public  Culture FieldCulture {
      get {
        return fieldCulture;
      }
    }
    
    private string alias;
    public  string Alias {
      get {
        return alias;
      }
    }
    
    private string ownerAlias;
    public  string OwnerAlias {
      get {
        return ownerAlias;
      }
    }

    private DataObjectCollectionField collectionField;
    public  DataObjectCollectionField CollectionField {
      get {
        return collectionField;
      }
    }
    
    // Constructors

    public QueryCompilerRefLayer(ObjectModel.Type type, string alias)
    {
      this.type  = type;
      this.alias = alias;
    }

    public QueryCompilerRefLayer(ObjectModel.Type type, string alias, string ownerAlias, DataObjectCollectionField collectionField)
      : this (type,alias)
    {
      this.ownerAlias = ownerAlias;
      this.collectionField = collectionField;
    }


    public QueryCompilerRefLayer(Field field, Culture fieldCulture, string alias)
    {
      this.field = field;
      this.fieldCulture = fieldCulture;
      this.alias = alias;
    }
  }
}
