// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Text;
using System.Text.RegularExpressions;
using System.Collections;
using System.Diagnostics;
using System.Data;
using System.Data.OleDb;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Attributes;

namespace DataObjects.NET.Database.Drivers.MSAccess
{
  /// <summary>
  /// Microsoft Access Database Driver.
  /// </summary>
  /// <remarks>
  /// <para>
  /// The following additional connection parameters are available for this driver:
  /// <list type="table">
  ///  <listheader>
  ///    <term>Parameter</term>
  ///    <description>Description</description>
  ///  </listheader>
  ///  <item>
  ///    <term>databasePassword</term>
  ///    <description>Optional. Database password.
  ///    Example connection URL: 
  ///      msaccess://localhost/C:\\SampleDB.mdb?databasePassword=admin 
  ///    </description>
  ///  </item>
  ///  <item>
  ///    <term>providerName</term>
  ///    <description>Optional. OLEDB provider name.
  ///    Default value is "Microsoft.Jet.OLEDB.4.0".
  ///    Example connection URL: 
  ///      msaccess://localhost/C:\\SampleDB.mdb?providerName=Microsoft.Jet.OLEDB.4.0 
  ///    </description>
  ///  </item>
  ///  <item>
  ///    <term>ConnectionStringSuffix</term>
  ///    <description>Anything you want to append to the underlying ADO.NET connection string.
  ///    Example connection URL (example is valid for Microsoft SQL Server 2005): 
  ///      mssql://.\\sqlexpress/.?ConnectionStringSuffix='AttachDBFilename=C:\\1\\aspnetdb.mdf;Application Name='vasya''
  ///    </description>
  ///  </item>
  /// </list>
  /// </para>
  /// </remarks>
  public class MSAccessDriver: Driver
  {
    internal const string DefaultProviderName = "Microsoft.Jet.OLEDB.4.0";

    /// <summary>
    /// Constructor
    /// </summary>
    static MSAccessDriver()
    {
      // Driver registration code
      RegisteredDrivers.Add("msaccess", typeof(MSAccessDriver));
      RegisteredDrivers.Add("mdb",      typeof(MSAccessDriver));
    }

    /// <summary>
    /// Determines whether specified <see cref="SqlType"/> is supported by the driver.
    /// </summary>
    /// <param name="type"><see cref="SqlType"/> to check supporting for.</param>
    /// <returns><see langword="true"/> if the driver supports specified <see cref="SqlType"/>;
    /// otherwise <see langword="false"/>.</returns>
    public override bool SupportsSqlType(SqlType type)
    {
      return (type!=SqlType.AnsiVarCharMax && type!=SqlType.VarCharMax && type!=SqlType.VarBinaryMax);
    }

    /// <summary>
    /// Creates new <see cref="IDbConnection"/> instance.
    /// </summary>
    /// <returns>Connection instance.</returns>
    public override IDbConnection CreateConnection() 
    {
      String cs = "";
      Regex re = new Regex("[=;]");
      Exception e = new InvalidConnectionUrlException(@"Part of URL contains ""="" or "";"" characters.");
      if (re.IsMatch(ConnectionInfo.Host))
        throw e;
      if (re.IsMatch(ConnectionInfo.Database))
        throw e;
      if (re.IsMatch(ConnectionInfo.User))
        throw e;
      if (re.IsMatch(ConnectionInfo.Password))
        throw e;
      if (ConnectionInfo.Port!=0)
        throw new InvalidConnectionUrlException("URL contains Port specification - Port is unsupported.");
        
      string providerName = ConnectionInfo.Params["providerName"];
      if (providerName == null)
        providerName = DefaultProviderName;
      cs += "Provider=" + providerName + ";";

      cs += "Data Source=" + ConnectionInfo.Database + ";";

      if (ConnectionInfo.User!="") {
        cs += "User ID="  + ConnectionInfo.User + ";";
        cs += "Password=" + ConnectionInfo.Password + ";";
      }
      
      string databasePassword = ConnectionInfo.Params["databasePassword"];
      if (databasePassword!=null)
        cs += "Jet OLEDB:Database Password="+databasePassword+";";
      
      string connectionStringSuffix = ConnectionInfo.Params["ConnectionStringSuffix"];
      if (connectionStringSuffix!=null)
      {
        if (connectionStringSuffix.Length >= 2)
        {
          if ((connectionStringSuffix.StartsWith("'") && connectionStringSuffix.EndsWith("'"))
              || (connectionStringSuffix.StartsWith("\"") && connectionStringSuffix.EndsWith("\"")))
            connectionStringSuffix = connectionStringSuffix.Substring(1, connectionStringSuffix.Length - 2);
        }
        if (connectionStringSuffix.Length > 0)
          cs += connectionStringSuffix;
      }
      
      return new OleDbConnection(cs);
    }

    /// <summary>
    /// Configures <see cref="IDbConnection"/>.
    /// </summary>
    /// <param name="connection">Connection to configure.</param>
    public override void ConfigureConnection(IDbConnection connection)
    {
      /* Nothing required for Microsoft Access
      IDbCommand cmd = connection.CreateCommand();
      cmd.CommandText = "";
      cmd.ExecuteNonQuery();
      */
    }

    /// <summary>
    /// Creates a new instance of <see cref="SysInfoManager"/>.
    /// </summary>
    /// <param name="connection">Connection it should be bound to.</param>
    /// <param name="transaction">Transaction it should operate in.</param>
    /// <returns>New <see cref="SysInfoManager"/> instance.</returns>
    public override SysInfoManager CreateSysInfoManager(IDbConnection connection, IDbTransaction transaction)
    {
       return new MSAccessSysInfoManager(this, connection, transaction);
    }

    /// <summary>
    /// Creates a new instance of <see cref="Extractor"/>.
    /// </summary>
    /// <param name="connection">Connection it should be bound to.</param>
    /// <param name="transaction">Transaction it should operate in.</param>
    /// <returns>New <see cref="Extractor"/> instance.</returns>
    public override Extractor CreateExtractor(IDbConnection connection, IDbTransaction transaction)
    {
      return new MSAccessExtractor(this, connection, transaction);
    }

    /// <summary>
    /// Creates a new instance of <see cref="Persister"/>.
    /// </summary>
    /// <param name="session">Session it should be bound to.</param>
    /// <returns>New <see cref="Persister"/> instance.</returns>
    public override Persister CreatePersister(Session session)
    {
      return new MSAccessPersister(session);
    }
    
    /// <summary>
    /// Creates a new instance of <see cref="UpdateActionTranslator"/>.
    /// </summary>
    /// <returns>New <see cref="UpdateActionTranslator"/> instance.</returns>
    protected override UpdateActionTranslator CreateUpdateActionTranslator()
    {
      return new MSAccessUpdateActionTranslator(this);
    }

    /// <summary>
    /// Logs the sql command, if logging is enabled
    /// </summary>
    /// <param name="functionName">The calling function's name</param>
    /// <param name="command">The command object</param>
    internal void LogSqlCommand( string functionName, OleDbCommand command ) //BSB
    {
      return;
//      System.Diagnostics.Debug.WriteLine(new StackTrace().ToString());
//      System.Diagnostics.Debug.WriteLine( "SQL COMMAND in " + functionName + ": " );
//      System.Diagnostics.Debug.WriteLine( "\t" + command.CommandText );
//      if (0!=command.Parameters.Count)
//      {
//        System.Diagnostics.Debug.WriteLine( "\t\twhere" );
//        foreach( OleDbParameter parameter in command.Parameters ) {
//          System.Diagnostics.Debug.WriteLine( "\t\t" + parameter.ParameterName + "=" + parameter.Value.ToString() );
//        }
//      }
    }

    /// <summary>
    /// Translates isolation level to one supported by the
    /// underlying RDBMS.
    /// </summary>
    /// <param name="isolationLevel">Isolation level to translate.</param>
    /// <returns>Supported isolation level.</returns>
    protected internal override IsolationLevel TranslateIsolationLevel(IsolationLevel isolationLevel)
    {
      switch (isolationLevel) {
      case IsolationLevel.Chaos:
      case IsolationLevel.ReadUncommitted:
        return IsolationLevel.ReadUncommitted;
      case IsolationLevel.ReadCommitted:
      case IsolationLevel.RepeatableRead:
      case IsolationLevel.Serializable:
        return IsolationLevel.ReadCommitted;
      }
      return IsolationLevel.Unspecified;
    }

    /// <summary>
    /// Detects version of the underlying database.
    /// </summary>
    public override void DetectRdbmsVersion()
    {
      using (OleDbConnection conection = (OleDbConnection)OpenConnection()) {
        try {
          string sqlServerVersion = conection.ServerVersion;
          int index = sqlServerVersion.IndexOf(' ');
          if (index>0)
            sqlServerVersion = sqlServerVersion.Substring(0, index);
          SetRdbmsVersion (new Version(sqlServerVersion));
        }
        catch {
          SetRdbmsVersion (new Version(4, 0));
        }
      }
    }

    // Constructor

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="connectionInfo">Information about default connection.</param>
    /// <param name="domain"><see cref="Domain"/>, to which this driver belongs.</param>
    public MSAccessDriver(ConnectionInfo connectionInfo, Domain domain): base(connectionInfo,domain)
    {
      SetInfo(new MSAccessInfo(this));
      SetUtils(new MSAccessUtils(this));
      SetNamingManager(new MSAccessNamingManager(this));
    }
  }
}
