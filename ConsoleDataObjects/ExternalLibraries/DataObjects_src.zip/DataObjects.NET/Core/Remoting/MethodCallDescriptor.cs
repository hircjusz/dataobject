// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;

namespace DataObjects.NET.Remoting
{
  /// <summary>
  /// Describes a single method invocation action.
  /// </summary>
  [Serializable]
  public class MethodCallDescriptor : ICloneable
  {
    private ArgumentContainer              target;
    private string                         methodName;
    private ArgumentContainerCollection    arguments;
    private MethodCallDescriptorCollection owner;
    
    #region ICloneable Members

    /// <summary>
    /// Creates a new object that is shallow copy of a curent instance.
    /// </summary>
    public virtual object Clone()
    {
      return new MethodCallDescriptor(this);
    }

    #endregion

    /// <summary>
    /// Invokes described method.
    /// </summary>
    public virtual object Invoke()
    {
      object target = this.target.GetValue(CallContext);
      if (target!=null) {
        IMethodCallTarget callTarget = target as IMethodCallTarget;
        if (callTarget!=null)
          return callTarget.Invoke(this);
        object[] arguments = Arguments.ToValuesArray(CallContext);
        return DefaultMethodInvoker.InvokeMethod(target, methodName, arguments);
      }
      throw new NullReferenceException("Method invocation target is null.");
    }
    
    /// <summary>
    /// Gets the collection this descriptor belongs to.
    /// </summary>
    public MethodCallDescriptorCollection Owner {
      get {
        return owner;
      }
    }
    
    internal void SetOwnerCollection (MethodCallDescriptorCollection ownerCollection)
    {
      this.owner = ownerCollection;
    }
    
    /// <summary>
    /// Gets an <see cref="CallContext"/> for the whole set of invocation actions.
    /// </summary>
    public CallContext CallContext {
      get {
        return (owner==null ? null : owner.CallContext);
      }
    }

    /// <summary>
    /// Gets the target of method invocation.
    /// </summary>
    public ArgumentContainer Target {
      get {
        return target;
      }
    }
    
    
    /// <summary>
    /// Gets the name of the method to invoke.
    /// </summary>
    public string MethodName {
      get {
        return methodName;
      }
    }
    
    /// <summary>
    /// Gets ordered <see cref="ArgumentContainerCollection">collection</see> of method invocation parameters.
    /// </summary>
    public ArgumentContainerCollection Arguments {
      get {
        return arguments;
      }
    }
    
    // Constructors

    /// <summary>
    /// Initializes a new instance of this class.
    /// The newly created instance is the copy of the specified one.
    /// </summary>
    protected MethodCallDescriptor(MethodCallDescriptor source)
    {
      this.target = (ArgumentContainer) source.target.Clone();
      this.methodName = source.methodName;
      this.arguments = (ArgumentContainerCollection)source.arguments.Clone();
      this.owner = source.owner;
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="invocationTarget">Method invocation target.</param>
    /// <param name="methodName">Name of the method to invoke.</param>
    public MethodCallDescriptor(object invocationTarget, string methodName)
    {
      this.target = ArgumentConverter.Convert(invocationTarget);
      this.arguments = new ArgumentContainerCollection();
      this.methodName = methodName;
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="invocationTarget">Method invocation target.</param>
    /// <param name="methodName">Name of the method to invoke.</param>
    /// <param name="parameters">Parameters to invoke method with.</param>
    public MethodCallDescriptor (object invocationTarget, string methodName, params object[] parameters) :
      this(invocationTarget, methodName)
    {
      if (parameters!=null)
        for (int i=0, count=parameters.Length; i<count; i++)
          this.Arguments.Add(ArgumentConverter.Convert(parameters[i]));
    }
  }
}
