// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Runtime.Serialization;

namespace DataObjects.NET.Exceptions
{
  /// <summary>
  /// Thrown by <see cref="Domain"/> <see cref="ObjectModel.Field"/> registration methods.
  /// </summary>
  [Serializable]
  public class FieldTypeRegistrationException: DataObjectsDotNetException
  {
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    public FieldTypeRegistrationException(): base("Field type registration error.") {}
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="text">Text of message.</param>
    public FieldTypeRegistrationException(string text): base(text) {}
    
    /// <summary>
    /// Deserialization constructor.
    /// </summary>
    /// <param name="info"><see cref="SerializationInfo"/> object.</param>
    /// <param name="context"><see cref="StreamingContext"/> object.</param>
    protected FieldTypeRegistrationException(SerializationInfo info, StreamingContext context):
      base(info, context)
    {
    }
  }
}
