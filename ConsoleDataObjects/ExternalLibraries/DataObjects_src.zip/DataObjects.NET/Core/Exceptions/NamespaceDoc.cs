// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;

namespace DataObjects.NET.Exceptions
{
  /// <summary>
  /// Contains almost all exceptions 
  /// (except single base class and set of standard exceptions) 
  /// used in DataObjects.NET.
  /// </summary>
  internal class NamespaceDoc {}
}
