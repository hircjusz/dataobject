// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;
using System.Collections.Specialized;
using System.Runtime.Serialization;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Security;

namespace DataObjects.NET.Serialization
{
  /// <summary>
  /// This type is used internally by the the <see cref="DataObjects.NET.Session"/>
  /// during serialization of <see cref="DataObject"/> instances.
  /// It's primary task is to substitute <see cref="DataObject"/> instances
  /// to <see cref="DataObjectReference"/> instances in the serialization
  /// stream.
  /// This is an implementation of <see cref="ISerializationSurrogate"/>.
  /// </summary>
  public sealed class SessionalSerializationSurrogate: ISerializationSurrogate
  {
    private  Session session;
    /// <summary>
    /// Session of the surrogate.
    /// </summary>
    public   Session Session {
      get {
        return session;
      }
    }
    
    /// <summary>
    /// Serializes <see cref="DataObject"/> instances.
    /// </summary>
    /// <param name="obj">Instance to serialize.</param>
    /// <param name="info">The <see cref="SerializationInfo"/> to populate with data. </param>
    /// <param name="context">The destination (see <see cref="StreamingContext"/>) for this serialization.</param>
    public void GetObjectData(object obj, SerializationInfo info, StreamingContext context)
    {
      if (obj is AccessControlList) {
        info.SetType(typeof(AccessControlList));
        AccessControlList o = (AccessControlList)obj;
        if (o.owner.State==DataObjectState.Removed)
          throw new InstanceIsRemovedException();
        int cnt = o.principals.Count;
        // info.AddValue("Owner-ID",o.owner.ID);
        info.AddValue("Inherit", o.InternalInherit);
        info.AddValue("Principals-Count",o.principals.Count);
        int i = 0;
        foreach (long pid in o.principals.Keys) {
          string pfx = "Principal-"+(i++).ToString();
          info.AddValue(pfx+"-ID",pid);
          info.AddValue(pfx+"-Allowed",o.allowedPermissionSets[pid]);
          info.AddValue(pfx+"-Denied",o.deniedPermissionSets[pid]);
        }
      }
      else {
        DataObject o = (DataObject)obj;
        if (o.Session!=session)
          throw new InvalidOperationException("Refered object should share the same Session.");
//        if (o==session.fastLoadDataSerializationTarget) {
//          // This as exceptional situation, when this surrogate
//          // is actually used to serialize FastLoadData!
//          session.fastLoadDataSerializationTarget = null;
//          info.SetType(typeof(FastLoadDataSubstitution));
//          o.GetObjectFastLoadData(info, context);
//          return;
//        }
        switch (o.State) {
        case DataObjectState.New:
          o.Persist();
          break;
        case DataObjectState.Removed:
          info.SetType(typeof(DataObjectReference));
          info.AddValue("ID",0);
          info.AddValue("Type",o.Type.Name);
          return;
        }
        info.SetType(typeof(DataObjectReference));
        info.AddValue("ID",o.ID);
        info.AddValue("Type",o.Type.Name);
      }
    }
    
    /// <summary>
    /// Deserializes <see cref="DataObjectReference"/> and <see cref="FastLoadDataSubstitution"/>
    /// instances.
    /// </summary>
    /// <param name="obj">Unititialized object to deserialize.</param>
    /// <param name="info">The information to populate the object.</param>
    /// <param name="context">The source from which the object is deserialized.</param>
    /// <param name="selector">The surrogate selector where the search for a compatible surrogate begins.</param>
    /// <returns>Always throws <see cref="SerializationException"/>.</returns>
    public object SetObjectData(object obj, SerializationInfo info, StreamingContext context, ISurrogateSelector selector)
    {
      Type t = obj.GetType();
//      if (t==typeof(FastLoadDataSubstitution)) {
//        FastLoadDataSubstitution sObj = (FastLoadDataSubstitution)obj;
//        sObj.realObject = session.fastLoadDataSerializationTarget;
//        session.fastLoadDataSerializationTarget = null;
//        sObj.realObject.SetObjectFastLoadData(info, context);
//        return sObj;
//      }
//      else
      if (t==typeof(AccessControlList)) {
        AccessControlList o = (AccessControlList)obj; 
        o.InternalInherit = true;
        o.principals = new Hashtable();
        o.allowedPermissionSets = new Hashtable();
        o.deniedPermissionSets  = new Hashtable();
        o.cachedPermissions = new ListDictionary();
        o.session = session;
        try {
          // We use this way to check if new "Inherit" element
          // exists in serializationInfo without exceptions.
          SerializationInfoEnumerator e = info.GetEnumerator();
          e.MoveNext();
          if (e.Current.Name=="Inherit") {
            try {
              o.InternalInherit = info.GetBoolean("Inherit");
            }
            catch (SerializationException) {
              o.Inconsistent = true;
            }
          }
          else
            o.Inconsistent = true;
          // long hid = info.GetInt64("Owner-ID");
          int  cnt = info.GetInt32("Principals-Count");
          for (int i = 0; i<cnt; i++) {
            try {
              string pfx = "Principal-"+i.ToString();
              long pid = 0;
              try {
                pid = info.GetInt64(pfx+"-ID");
              }
              catch {
                // DataObjects.NET 2.0.1 format...
                // Let's handle it by the old way...
                o.Inconsistent = true;
                o.serializationInfo = info;
                o.session = null;
                return o;
              }
              AccessControlListPermissionSet aps = 
                info.GetValue(pfx+"-Allowed",typeof(object)) as AccessControlListPermissionSet;
              AccessControlListPermissionSet dps = 
                info.GetValue(pfx+"-Denied",typeof(object)) as AccessControlListPermissionSet;
            #if !MONO
              // Mono unlike .NET deserializes parent object first
              // so in our case deserialization constructor is not
              // called yet for aps and dps and consequently we can't 
              // examine count property.
              if (aps!=null && aps.Count==0)
                aps = null;
              if (dps!=null && dps.Count==0)
                dps = null;
            #endif
            
              if (aps!=null || dps!=null) {
                o.principals[pid] = o;
                if (aps!=null) {
                  aps.owner = o;
                  aps.principalID = pid;
                  aps.isAllowedSet = true;
                  o.allowedPermissionSets[pid] = aps;
                }
                if (dps!=null) {
                  dps.owner = o;
                  dps.principalID = pid;
                  dps.isAllowedSet = false;
                  o.deniedPermissionSets[pid] = dps;
                }
              }
            } 
            catch {
              o.Inconsistent = true;
              throw;
            }
          }
        }
        catch {
          o.Inconsistent = true;
          throw;
        }
        return o;
      }
      else if (t==typeof(DataObjectReference)) {
        DataObjectReference rObj = (DataObjectReference)obj;
        long id = info.GetInt64("ID");
        string typeName;
        try {
          typeName = info.GetString("Type");
        }
        catch (SerializationException) {
          typeName = info.GetString("TypeName"); // Compatibility issue
        }
        ObjectModel.Type type = session.Types[typeName];
        if (type==null)
          throw new SerializationException("Unknown type: "+typeName);
        if (type.IsAbstract)
          throw new SerializationException(
            String.Format("Type \"{0}\" is an interface or an abstract type.",typeName));
        
        DataObject dObj = null;
        if (id==0)
          dObj = session.GetNullObject(type.SourceType);
        else {
          dObj = session[id];
          if (dObj==null)
            dObj = session.GetNullObject(type.SourceType);
        }
        rObj.realObject = dObj;
        return rObj;
      }
      else
        throw new SerializationException("Can't deserialize DataObject by this way.");
    }
    
    /// <summary>
    /// Initializes an instance of this class.
    /// </summary>
    /// <param name="session">Session of the surrogate.</param>
    public SessionalSerializationSurrogate(Session session)
    {
      if (session==null)
        throw new ArgumentNullException("session");
      this.session = session;
    }
  }
}
