// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;
using System.Diagnostics;

namespace DataObjects.NET.Diagnostics
{
  internal class PerformanceCounterCategoryDescriptor: IEnumerable
  {
    public string categoryName = null;
    public string categoryHelp = null;
    public Hashtable counterDescriptors = new Hashtable();
    public bool categoryChecked = false;
    public bool delayUsingCategory = false;

    private CounterCreationDataCollection GetCounterCreationData()
    {
      CounterCreationDataCollection result = new CounterCreationDataCollection();
      foreach (PerformanceCounterFactoryCounterDescriptor desc in this) {
        CounterCreationData cdc1 = new CounterCreationData(desc.counterName, desc.counterHelp, desc.counterType);
        result.Add(cdc1);
        if (desc.HasBaseCounter) {
          CounterCreationData cdc2 = new CounterCreationData(desc.baseCounterName, desc.counterHelp, desc.baseCounterType);
          result.Add(cdc2);
        }
      }

      return result;
    }

    public PerformanceCounterCategory CreatePerformanceCategory()
    {
      return PerformanceCounterCategory.Create(categoryName, categoryHelp, GetCounterCreationData());
    }

    public IEnumerator GetEnumerator()
    {
      return counterDescriptors.Values.GetEnumerator();
    }
    

    // Constructors

    public PerformanceCounterCategoryDescriptor(string categoryName)
    {
      this.categoryName = categoryName;
    }
  }
}
