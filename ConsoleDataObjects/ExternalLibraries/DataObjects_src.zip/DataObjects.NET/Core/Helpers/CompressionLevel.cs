// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using DataObjects.NET.Attributes;

namespace DataObjects.NET.Helpers
{
  /// <summary>
  /// Enumerates different compression levels that can be used by
  /// <see cref="Compressor"/>.
  /// </summary>
  public enum CompressionLevel
  {
    /// <summary>
    /// No compression (value should be stored as is).
    /// Value is <see langword="0x0"/>.
    /// </summary>
    None = 0x0,
    /// <summary>
    /// Fastest compression, but the worst compression level.
    /// Value is <see langword="0x1"/>.
    /// </summary>
    Fastest  = 0x1,
    /// <summary>
    /// Fast compression.
    /// Value is <see langword="0x2"/>.
    /// </summary>
    Fast  = 0x2,
    /// <summary>
    /// Normal compression.
    /// Value is <see langword="0x3"/>.
    /// </summary>
    Normal  = 0x3,
    /// <summary>
    /// Good compression.
    /// Value is <see langword="0x4"/>.
    /// </summary>
    Good  = 0x4,
    /// <summary>
    /// Best compression, but the lowest compression speed.
    /// Value is <see langword="0x5"/>.
    /// </summary>
    Best  = 0x5,
  }
}
