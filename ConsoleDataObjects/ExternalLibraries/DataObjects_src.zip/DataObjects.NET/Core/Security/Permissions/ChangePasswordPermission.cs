// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.IO;
using System.Threading;
using System.Configuration;
using System.Diagnostics;
using System.Globalization;
using System.Collections;
using DataObjects.NET;
using DataObjects.NET.Attributes;
using DataObjects.NET.Exceptions;

namespace DataObjects.NET.Security.Permissions
{
  /// <summary>
  /// This permission is required to use <see cref="StdUser.SetPassword"/>
  /// method for the particular <see cref="StdUser"/>.
  /// <seealso cref="IPermission"/>
  /// <seealso cref="IPermissionSet"/>
  /// <seealso cref="PermissionSet"/>
  /// </summary>
  [Serializable]
  public class ChangePasswordPermission: Permission
  {
    private static ChangePasswordPermission _value = new ChangePasswordPermission();
    /// <summary>
    /// Represents the instance of the this class.
    /// Normally you should use this static member to obtain
    /// an instance of this type (e.g. to improve permission
    /// checking cache performance and reduce the memory usage), 
    /// but this isn't strongly required.
    /// </summary>
    public  static ChangePasswordPermission Value {
      get {return _value;}
    }
  }
}
