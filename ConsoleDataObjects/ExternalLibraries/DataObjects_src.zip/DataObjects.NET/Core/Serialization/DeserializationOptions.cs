// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Attributes;
using DataObjects.NET.Security;

namespace DataObjects.NET.Serialization
{
  /// <summary>
  /// Enumeration of possible deserialization options 
  /// for the <see cref="Serializer"/>.
  /// <note type="note"><see cref="ISecurityRoot"/> object is always serialized
  /// as reference, also its <see cref="DataObject.ID"/> value stored in the
  /// deserialization stream is ignored during the deserialization (because
  /// only one <see cref="ISecurityRoot"/> instance can exist in the storage).
  /// </note>
  /// <seealso cref="SerializationOptions"/>
  /// </summary>
  [Flags]
  public enum DeserializationOptions
  {
    /// <summary>
    /// Simplest deserialization mode.
    /// All serialized instances will be deserialized and added to the
    /// database.
    /// Value is <see langword="0"/>. 
    /// </summary>
    Minimal = 0,
    /// <summary>
    /// Use this option to enable <see cref="Serializer"/> to additionaly 
    /// restore all references to external instances during deserialization.
    /// Value is <see langword="0x1"/>. 
    /// </summary>
    EnableExternalReferences = 0x1,
    /// <summary>
    /// Use this option to allow <see cref="Serializer"/> to overwrite
    /// existing instances (with the same <see cref="DataObject.ID"/>
    /// value as the <see cref="DataObject.ID"/> of serialized instance) 
    /// during deserialization process. Overwrite means "to 
    /// <see cref="DataObject.Remove">delete</see> existing instance and 
    /// then to add a new instance".
    /// Value is <see langword="0x2"/>. 
    /// </summary>
    EnableOverwrite = 0x2,
    /// <summary>
    /// Use this option to enable <see cref="Serializer"/> to additionaly 
    /// deserialize the permissions.
    /// Value is <see langword="0x4"/>. 
    /// </summary>
    DeserializePermissions = 0x4,
    /// <summary>
    /// Default deserialization mode.
    /// Value is <see langword="0x1 | 0x4"/>. 
    /// </summary>
    Default = 0x1 | 0x4,
  }
}
