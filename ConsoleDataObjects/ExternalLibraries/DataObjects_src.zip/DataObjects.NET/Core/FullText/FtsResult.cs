// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Text;
using DataObjects.NET.Database;
using DataObjects.NET.Offline.Helpers;

namespace DataObjects.NET.FullText
{
  /// <summary>
  /// Stores full-text query result returned by
  /// full-text search driver 
  /// (see <see cref="FtsDriver.ExecuteQuery">FtsDriver.ExecuteQuery</see>).
  /// <seealso cref="FtsDriver"/>
  /// <seealso cref="FtsDriver.ExecuteQuery"/>
  /// <seealso cref="Persister.BuildQueryCommandText"/>
  /// </summary>
  [Serializable]
  public sealed class FtsResult
  {
    private FtsResultEntry[] entries;
    /// <summary>
    /// Gets the actual data returned by the full-text search driver.
    /// <seealso cref="FtsResultEntry"/>
    /// </summary>
    public FtsResultEntry[] Entries {
      get { return entries; }
    }

    /// <summary>
    /// Converts <see cref="Entries"/> to string containing
    /// their <see cref="FtsResultEntry.ID"/>s delimited
    /// by commas.
    /// </summary>
    /// <returns></returns>
    public string ConvertToSqlInExpression()
    {
      if (entries.Length==0)
        return "-1"; // There can be no object with id = -1 so 
                      // returning -1 actually means an empty set.
      StringBuilder b = new StringBuilder(entries.Length * 3);
      foreach (FtsResultEntry entry in entries)
        b.Append("," + entry.ID);
      return b.ToString().Substring(1);
    }
    
    
    // Constructors

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="entries">Array of <see cref="FtsResultEntry"/> objects 
    /// specifying initial <see cref="Entries"/> value.</param>
    public FtsResult(FtsResultEntry[] entries)
    {
      this.entries = entries;
    }
  }
}
