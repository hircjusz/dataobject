// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Runtime.Serialization;

namespace DataObjects.NET.Exceptions
{
  /// <summary>
  /// Thrown by some <see cref="DataObject"/> methods when 
  /// instance <see cref="DataObject.State"/> is <see cref="DataObjectState">DataObjectState.Removed</see>.
  /// </summary>
  [Serializable]
  public class InstanceIsRemovedException: InvalidInstanceStateException
  {
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    public InstanceIsRemovedException(): base("Instance is deleted.") {}
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="text">Text of message.</param>
    public InstanceIsRemovedException(string text): base(text) {}
    
    /// <summary>
    /// Deserialization constructor.
    /// </summary>
    /// <param name="info"><see cref="SerializationInfo"/> object.</param>
    /// <param name="context"><see cref="StreamingContext"/> object.</param>
    protected InstanceIsRemovedException(SerializationInfo info, StreamingContext context):
      base(info, context)
    {
    }
  }
}
