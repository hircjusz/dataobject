// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;
using System.Data;

namespace DataObjects.NET.Attributes
{
  /// <summary>
  /// Determines automatic transactions mode (see <see cref="DataObjects.NET.TransactionMode"/>) 
  /// for a method or property.
  /// </summary>
  /// <remarks>
  /// <note>This attribute can be applied to methods of persistent types
  /// (<see cref="DataObject"/> descendants) or services
  /// (<see cref="DataService"/> descendants).</note>
  /// <para>
  /// This attribute controls automatic transactions behavoir
  /// for a method or a property.
  /// </para>
  /// <note type="note">If you decided to apply this attribute to some method
  /// or property, you should ensure that this method changes only
  /// transaction-dependent data.</note>
  /// <para>
  /// E.g. imagine that one of your methods 
  /// can modify an external (e.g. <see cref="ArrayList"/>, passed as 
  /// argument) instance of non-<see cref="DataObject"/> type - it will 
  /// be impossible to make a complete rollback if exception occurs and
  /// modifications are already made. But you can handle this situation
  /// by writting a custom exception handler.
  /// </para>
  /// <para>
  /// Or another example: your method have changed some
  /// non-transactional instance, and after that a deadlock took place. 
  /// In this case changes in this instance will not be rolled back, 
  /// and this will affect on possible successive method call 
  /// reprocessing.
  /// </para>
  /// <para>
  /// See <see cref="TransactionController"/> also to understand the
  /// behavior of this attribute better.
  /// </para>
  /// <para>
  /// <example>Example:
  /// <code lang="C#">
  ///  public abstract class HomeAnimal: Animal
  ///  {
  ///    ...
  ///
  ///    [Transactional(TransactionMode.Disabled)] // Not transactional method!
  ///    public string GetTypeName()
  ///    {
  ///      return this.GetType().BaseType.FullName; // BaseType is required, since
  ///                                               // we are work with proxies!
  ///    }
  ///
  ///    [Transactional(TransactionMode.TransactionRequired)] // Transactional method!
  ///    public virtual Animal[] GetAnimalsWithTheSameName1()
  ///    {
  ///      Query q = Session.CreateQuery(
  ///        "Select Animal objects where {Name}=@Name");
  ///      q.Parameters.Add("@Name", Name);
  ///      return (Animal[])q.ExecuteArray();
  ///    }
  ///
  ///    // Any method requires a transaction by default, so this declaration 
  ///    // is equivalent to previous one.
  ///    public virtual Animal[] GetAnimalsWithTheSameName2()
  ///    {
  ///      Query q = Session.CreateQuery(
  ///        "Select Animal objects where {Name}=@Name");
  ///      q.Parameters.Add("@Name", Name);
  ///      return (Animal[])q.ExecuteArray();
  ///    }
  ///
  ///    [Transactional(TransactionMode.NewTransactionRequired)] // Transactional method, that always
  ///                                                            // executes in the new (possible nested)
  ///                                                            // transaction.
  ///    public virtual Animal[] GetAnimalsWithTheSameName3()
  ///    {
  ///      Query q = Session.CreateQuery(
  ///        "Select Animal objects where {Name}=@Name");
  ///      q.Parameters.Add("@Name", Name);
  ///      return (Animal[])q.ExecuteArray();
  ///    }
  ///
  ///    [Transactional(TransactionMode.Unsafe)] // A method containing try-catch blocks
  ///                                            // that can perform some transactional
  ///                                            // methods on exception.
  ///    public virtual void TryCatchMethod()
  ///    {
  ///      try {
  ///        SomeTransactionalMethod();
  ///      }
  ///      catch {
  ///        // Since this method is marked as unsafe, this transactional
  ///        // method will have a chance to execute (otherwise it couldn't
  ///        // be executed, because DataObjects.NET usually rolls back
  ///        // a transaction on exception, but in this case it will perform
  ///        // a rollback of a method that thrown an exception, i.e.
  ///        // of SomeTransactionalMethod() in our case).
  ///        OtherTransactionalMethod();
  ///      }
  ///    }
  ///
  ///    ...
  ///  }
  /// </code>
  /// </example>
  /// </para>
  /// <seealso cref="Transaction"/>
  /// <seealso cref="TransactionController"/>
  /// <seealso cref="DataObjects.NET.TransactionMode"/>
  /// <seealso cref="Session.ReprocessingAttemptsCount"/>
  /// <seealso cref="Session.ReprocessingDelay"/>
  /// </remarks>
  [AttributeUsage(AttributeTargets.Property | AttributeTargets.Method, AllowMultiple = false, Inherited = true)]
  [Serializable]
  public class TransactionalAttribute: DataObjectAttribute
  {
    private TransactionMode transactionMode = TransactionMode.TransactionRequired;
    /// <summary>
    /// Determines automatic transactions mode (see <see cref="DataObjects.NET.TransactionMode"/>) 
    /// for the method or property.
    /// </summary>
    public  TransactionMode TransactionMode 
    {
      get {return transactionMode;}
      set {transactionMode = value;}
    }

    private Type[] commitExceptions = new Type[] {};
    /// <summary>
    /// An array of exception types (<see cref="Exception"/> descendants) that
    /// should fall through transactional exception handler of method with commit.
    /// </summary>
    public  Type[] CommitExceptions 
    {
      get {return commitExceptions;}
      set {
        if (value==null)
          commitExceptions = new Type[] {};
        else
          commitExceptions = value;
      }
    }

    private IsolationLevel isolationLevel = IsolationLevel.Unspecified;
    /// <summary>
    /// Determines isolation level of the transaction. 
    /// </summary>
    public  IsolationLevel IsolationLevel 
    {
      get {return isolationLevel;}
      set {isolationLevel = value;}
    }


    /// <summary>
    /// Initializes a new instance of this class.
    /// <see cref="IsolationLevel"/> considered equal to 
    /// <see cref="System.Data.IsolationLevel.Unspecified"/>.
    /// </summary>
    /// <param name="transactionMode">Determines <see cref="DataObjects.NET.TransactionMode"/> for the method or property.</param>
    public TransactionalAttribute(TransactionMode transactionMode) 
    {
      this.transactionMode = transactionMode;
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// <see cref="TransactionMode"/> considered equal to 
    /// <see cref="DataObjects.NET.TransactionMode.TransactionRequired"/>.
    /// </summary>
    /// <param name="isolationLevel">Determines isolation level of the transaction.</param>
    public TransactionalAttribute(IsolationLevel isolationLevel) 
    {
      this.isolationLevel = isolationLevel;
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// <see cref="IsolationLevel"/> considered equal to 
    /// <see cref="System.Data.IsolationLevel.Unspecified"/>.
    /// </summary>
    /// <param name="transactionMode">Determines <see cref="DataObjects.NET.TransactionMode"/> for the method or property.</param>
    /// <param name="commitExceptions">An array of exception types (<see cref="Exception"/> descendants) that
    /// should fall through transactional exception handler of method with commit.
    /// </param>
    public TransactionalAttribute(TransactionMode transactionMode, Type[] commitExceptions) 
    {
      this.transactionMode  = transactionMode;
      this.CommitExceptions = commitExceptions;
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// <see cref="IsolationLevel"/> considered equal to 
    /// <see cref="System.Data.IsolationLevel.Unspecified"/>.
    /// </summary>
    /// <param name="transactionMode">Determines <see cref="DataObjects.NET.TransactionMode"/> for the method or property.</param>
    /// <param name="commitException">Exception type (<see cref="Exception"/> descendant) that
    /// should fall through transactional exception handler of method with commit.
    /// </param>
    public TransactionalAttribute(TransactionMode transactionMode, Type commitException) 
    {
      this.transactionMode  = transactionMode;
      this.CommitExceptions = new System.Type[] {commitException};
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// <see cref="TransactionMode"/> considered equal to 
    /// <see cref="DataObjects.NET.TransactionMode.TransactionRequired"/>.
    /// </summary>
    /// <param name="isolationLevel">Determines isolation level of the transaction.</param>
    /// <param name="commitExceptions">An array of exception types (<see cref="Exception"/> descendants) that
    /// should fall through transactional exception handler of method with commit.
    /// </param>
    public TransactionalAttribute(IsolationLevel isolationLevel, Type[] commitExceptions) 
    {
      this.isolationLevel   = isolationLevel;
      this.CommitExceptions = commitExceptions;
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="transactionMode">Determines <see cref="DataObjects.NET.TransactionMode"/> for the method or property.</param>
    /// <param name="isolationLevel">Determines isolation level of the transaction.</param>
    public TransactionalAttribute(TransactionMode transactionMode, IsolationLevel isolationLevel) 
    {
      this.transactionMode = transactionMode;
      this.isolationLevel  = isolationLevel;
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="transactionMode">Determines <see cref="DataObjects.NET.TransactionMode"/> for the method or property.</param>
    /// <param name="isolationLevel">Determines isolation level of the transaction.</param>
    /// <param name="commitExceptions">An array of exception types (<see cref="Exception"/> descendants) that
    /// should fall through transactional exception handler of method with commit.
    /// </param>
    public TransactionalAttribute(TransactionMode transactionMode, 
      IsolationLevel isolationLevel, Type[] commitExceptions) 
    {
      this.transactionMode  = transactionMode;
      this.isolationLevel   = isolationLevel;
      this.CommitExceptions = commitExceptions;
    }
  }
}
