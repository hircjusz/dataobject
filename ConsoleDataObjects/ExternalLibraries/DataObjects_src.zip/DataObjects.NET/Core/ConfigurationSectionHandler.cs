// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.IO;
using System.Collections;
using System.Configuration;
using System.Globalization;
using System.Xml;
using System.Reflection;
using DataObjects.NET.DatabaseModel;

namespace DataObjects.NET
{
  /// <summary>
  /// Reads DataObjects.NET configuration from ExeName.config or web.config file.
  /// </summary>
  public sealed class ConfigurationSectionHandler: IConfigurationSectionHandler
  {
    private XmlNode sectionNode;
    private XmlNode domainNode;
    private Domain  domain;    
    
    /// <summary>
    /// Parses ExeName.config or Web.config configuration file.
    /// </summary>
    /// <param name="parent">The configuration settings in a corresponding parent configuration section.</param>
    /// <param name="configContext">Is reserved and is <see langword="null"/>.</param>
    /// <param name="section">The <see cref="XmlNode"/> that contains the 
    /// configuration information from the configuration file. 
    /// Provides direct access to the XML contents of the configuration section.</param>
    /// <returns><see cref="DomainCollection"/> object containing all
    /// configured <see cref="Domain"/>s.</returns>    
    public object Create(object parent, object configContext, XmlNode section)
    {
      try {
        this.sectionNode = section;

        // Global settings
        SetClientSideCacheSettings();                    

        // Domains
        DomainCollection domains = new DomainCollection();             
        XmlNodeList domainNodes = sectionNode.SelectNodes("domain");        
//        if (domainNodes.Count==0)
//          throw new ConfigurationException("Tag <domain> wasn't found.", section);                  
        foreach (XmlNode node in domainNodes) {
          domainNode = node;
          
          CreateDomain();
          SetName();
          SetRuntimeServiceStartupDelay();
          SetGuid();
          SetObjectModelGuid();
          SetDebugInfoOutputFolder();                    
          SetProxyAssemblyCacheFolder();     

          SetNamingMode();
          SetIdentifierPrefix();
//          SetIdentifierStyle();
          SetFastLoadDataFormat();                   
          SetDatabaseOptions();
          SetSecurityMode();
          SetSecurityOptions();
          SetSessionSecurityOptions();
          SetRemoteSessionSecurityOptions();
          SetGlobalCacheSize();
          SetUpdateMode();
          SetTransactionalUpdate();
          SetThreadedBuildExecution();
          SetEnablePerformanceCounters();
//SM begin
          SetChangeCacheSize();
          SetEnableCommandTrace();
          SetConnectionCleanInterval();
          SetConnectionLifeTime();
          SetTransactionOnDemand();          
//SM end
          LoadAssemblies();

          SetCultures();
          SetTypes();
          SetServices();
          SetFieldTypes();
          SetNonPersistedFields();          
          TryBuild();
          
          domains.Add(domain);
        }
        domains.Lock();
        return domains;
      }
      catch (ConfigurationException) 
      {
        throw;
      }
      catch (Exception e) 
      {
        throw new ConfigurationException(
          "Error processing DataObjects.NET configuration, inner exception: "+e.ToString(), e, section);
      }
    }
    
    private void SetClientSideCacheSettings()
    {
      XmlNode cscNode = sectionNode.SelectSingleNode("clientSideCache");
      if (cscNode==null)
        return;
      XmlNode n = cscNode.SelectSingleNode("@folder");
      if (n!=null)
        Offline.ClientSideCache.Folder = n.Value;
      n = cscNode.SelectSingleNode("@expirationPeriod");
      if (n!=null)
        Offline.ClientSideCache.ExpirationPeriod = TimeSpan.Parse(n.Value);
    }

    private void CreateDomain()
    {
      string connectionUrl    = null;
      string ftsConnectionUrl = null;
      string productKey = "";   

      XmlNode n = domainNode.SelectSingleNode("@productKeyPath");
      XmlNode m = domainNode.SelectSingleNode("@productKey");
      if (m!=null && n!=null) 
        throw new ConfigurationException("Both \"productKeyPath\" and \"productKey\" attributes exist.", domainNode);      
      if (n!=null) {
        string fileName = n.Value;
        if (!Path.IsPathRooted(fileName))
          fileName = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, fileName);
        if (File.Exists(fileName))
          using (StreamReader sr = new StreamReader(fileName)) {
            productKey = sr.ReadToEnd().Trim();
          }
      }
      if (m!=null)
        productKey = m.Value;

      n = domainNode.SelectSingleNode("@connectionUrl");
      if (n==null) 
        throw new ConfigurationException("Attribute \"connectionUrl\" wasn't found.", domainNode);      
      connectionUrl = n.Value;

      n = domainNode.SelectSingleNode("@ftsConnectionUrl");
      if (n!=null) 
        ftsConnectionUrl = n.Value;

      if (ftsConnectionUrl==null)
        domain = new Domain(connectionUrl, productKey);
      else
        domain = new Domain(connectionUrl, ftsConnectionUrl, productKey);
    }
    
    private void SetName()
    {
      XmlNode n = domainNode.SelectSingleNode("@name");
      if (n!=null) 
        domain.Name = n.Value; 
      else
        domain.Name = "Default"; 
    }

    private void SetRuntimeServiceStartupDelay()
    {
      XmlNode n = domainNode.SelectSingleNode("@runtimeServiceStartupDelay");
      if (n!=null) 
        domain.RuntimeServiceStartupDelay = TimeSpan.Parse(n.Value);
    }
        
    private void SetGuid()
    {
      XmlNode n = domainNode.SelectSingleNode("@guid");
      if (n!=null) 
        domain.Guid = new Guid(n.Value);
    }

    private void SetObjectModelGuid()
    {
      XmlNode n = domainNode.SelectSingleNode("@objectModelGuid");
      if (n!=null) 
        domain.ObjectModelGuid = new Guid(n.Value);
    }

    private void SetDebugInfoOutputFolder()
    {
      XmlNode n = domainNode.SelectSingleNode("@debugInfoOutputFolder");
      if (n!=null)
        domain.DebugInfoOutputFolder = n.Value;
    }

    private void SetProxyAssemblyCacheFolder()
    {
      XmlNode n = domainNode.SelectSingleNode("@proxyAssemblyCacheFolder");
      if (n!=null)
        domain.ProxyAssemblyCacheFolder = n.Value;
    }
    
    private void SetFastLoadDataFormat()
    {
      XmlNode n = domainNode.SelectSingleNode("@fastLoadDataFormat");
      if (n!=null) {
        domain.FastLoadDataFormat = (DomainFastLoadDataFormat)Enum.Parse(typeof(DomainFastLoadDataFormat),n.Value);
      }  
    }
    
    private void SetDatabaseOptions()
    {
      XmlNode n = domainNode.SelectSingleNode("@databaseOptions");
      if (n!=null) {
        domain.DatabaseOptions = (DomainDatabaseOptions)Enum.Parse(typeof(DomainDatabaseOptions),n.Value);
      }      
    }
    
    private void SetNamingMode()
    {
      XmlNode n = domainNode.SelectSingleNode("@namingMode");
      if (n!=null) {
        domain.NamingMode = (DomainNamingMode)Enum.Parse(typeof(DomainNamingMode),n.Value);
      }      
    }   
 
    private void SetIdentifierPrefix()
    {
      XmlNode n = domainNode.SelectSingleNode("@identifierPrefix");
      if (n!=null) 
      {
        domain.IdentifierPrefix = n.Value;
      }      
    }   
      
    private void SetSecurityMode()
    {
      XmlNode n = domainNode.SelectSingleNode("@securityMode");
      if (n!=null) {
        domain.SecurityMode = (DomainSecurityMode)Enum.Parse(typeof(DomainSecurityMode),n.Value);
      }      
    }      
      
    private void SetSecurityOptions()
    {
      XmlNode n = domainNode.SelectSingleNode("@securityOptions");
      if (n!=null) {
        domain.SecurityOptions = (DomainSecurityOptions)Enum.Parse(typeof(DomainSecurityOptions),n.Value);
      }      
    }    
    
    private void SetSessionSecurityOptions()
    {
      XmlNode n = domainNode.SelectSingleNode("@sessionSecurityOptions");
      if (n!=null) {
        domain.SessionSecurityOptions = (SessionSecurityOptions)Enum.Parse(typeof(SessionSecurityOptions),n.Value);
      }      
    }    
    
    private void SetRemoteSessionSecurityOptions()
    {
      XmlNode n = domainNode.SelectSingleNode("@remoteSessionSecurityOptions");
      if (n!=null) {
        domain.RemoteSessionSecurityOptions = (SessionSecurityOptions)Enum.Parse(typeof(SessionSecurityOptions),n.Value);
      }      
    }    
    
    private void SetUpdateMode()
    {
      XmlNode n = domainNode.SelectSingleNode("@updateMode");
      XmlNode m = domainNode.SelectSingleNode("@defaultUpdateMode");
      if (m!=null && n!=null) 
        throw new ConfigurationException("Both \"defaultUpdateMode\" and \"updateMode\" attributes exist.", domainNode);      
      if (n!=null) 
        domain.DefaultUpdateMode = (DomainUpdateMode)Enum.Parse(typeof(DomainUpdateMode),n.Value);        
      if (m!=null)
        domain.DefaultUpdateMode = (DomainUpdateMode)Enum.Parse(typeof(DomainUpdateMode),m.Value);        
    }
    
    private void SetTransactionalUpdate()
    {
      XmlNode n = domainNode.SelectSingleNode("@transactionalUpdate");
      if (n!=null) {
        domain.TransactionalUpdate = Boolean.Parse(n.Value);
      }
    }    
    
    private void SetThreadedBuildExecution()
    {
      XmlNode n = domainNode.SelectSingleNode("@threadedBuildExecution");
      if (n!=null) {
        domain.ThreadedBuildExecution = Boolean.Parse(n.Value);
      }
    }    

    private void SetChangeCacheSize()
    {
      XmlNode n = domainNode.SelectSingleNode("@changeCacheSize");
      if (n!=null) {
        domain.ChangeCacheSize = Int32.Parse(n.Value);
      }
    }

      private void SetTransactionOnDemand()
      {
          XmlNode n = domainNode.SelectSingleNode("@transactionOnDemand");
          if (n != null)
          {
              domain.TransactionOnDemand = Boolean.Parse(n.Value);
          }
      }

      private void SetConnectionCleanInterval()
      {
          XmlNode n = domainNode.SelectSingleNode("@connectionCleanInterval");
          if (n != null)
          {
              domain.ConnectionCleanInterval= Int32.Parse(n.Value);
          }
      }

      private void SetEnableCommandTrace()
      {
          XmlNode n = domainNode.SelectSingleNode("@enableCommandTrace");
          if (n != null)
          {
              domain.EnableCommandTrace = Boolean.Parse(n.Value);
          }
      }

      private void SetIdentifierStyle()
      {
          XmlNode n = domainNode.SelectSingleNode("@styleID");
          if (n != null)
          {
              switch (Int32.Parse(n.Value))
              {
                  case 1:
                      Domain.StyleID = IDStyle.Minimal;
                      break;
              }
          }
      }

      private void SetConnectionLifeTime()
      {
          XmlNode n = domainNode.SelectSingleNode("@connectionLifeTime");
          if (n != null)
          {
              domain.ConnectionLifeTime = Int32.Parse(n.Value);
          }
      }    


    private void SetEnablePerformanceCounters()
    {
      XmlNode n = domainNode.SelectSingleNode("@enablePerformanceCounters");
      if (n!=null) {
        domain.EnablePerformanceCounters = Boolean.Parse(n.Value);
      }
    }    
    
    private void SetGlobalCacheSize()
    {
      XmlNode n = domainNode.SelectSingleNode("@globalCacheSize");
      if (n!=null) {
        domain.GlobalCacheSize = Int32.Parse(n.Value);
      }
    }
    
    private void SetCultures()
    {
      string defaultCultureName = null;
      XmlNode culturesNode = domainNode.SelectSingleNode("cultures");
      if (culturesNode==null)
        throw new ConfigurationException("Tag <cultures> wasn't found.", domainNode);

      XmlNode n;
      n = culturesNode.SelectSingleNode("@defaultCulture");
      if (n!=null)
        defaultCultureName = n.Value;
          
      XmlNodeList cultureNodes = culturesNode.SelectNodes("culture");
      if (cultureNodes.Count==0)
        throw new ConfigurationException("Tag <culture> wasn't found.", culturesNode);
          
      foreach (XmlNode cultureNode in cultureNodes) 
      {
        n = cultureNode.SelectSingleNode("@name");
        if (n==null)
          throw new ConfigurationException("Attribute \"name\" wasn't found.", cultureNode);
        string cultureName = n.Value;
            
        n = cultureNode.SelectSingleNode("@title");
        if (n==null)
          throw new ConfigurationException("Attribute \"title\" wasn't found.", cultureNode);
        string cultureTitle = n.Value;
            
        n = cultureNode.SelectSingleNode("@cultureName");
        if (n==null)
          throw new ConfigurationException("Attribute \"cultureName\" wasn't found.", cultureNode);
        string cultureInfoName = n.Value;

        string cultureCompareOptions = "";
        n = cultureNode.SelectSingleNode("@compareOptions");
        if (n!=null)
          cultureCompareOptions = n.Value;
            
        string cultureSqlCollation = "";
        n = cultureNode.SelectSingleNode("@sqlCollation");
        if (n!=null)
          cultureSqlCollation = n.Value;
            
        Culture culture = null;
        try 
        {
          if (cultureCompareOptions!="") 
          {
            if (cultureSqlCollation!="")
              culture = new Culture(cultureName, cultureTitle, new CultureInfo(cultureInfoName, false),
                (CompareOptions)Enum.Parse(typeof(CompareOptions),cultureCompareOptions,true),
                (SqlCollation)Enum.Parse(typeof(SqlCollation),cultureSqlCollation,true));
            else 
              culture = new Culture(cultureName, cultureTitle, new CultureInfo(cultureInfoName, false),
                (CompareOptions)Enum.Parse(typeof(CompareOptions),cultureCompareOptions,true));
          }
          else 
          {
            if (cultureSqlCollation!="")
              culture = new Culture(cultureName, cultureTitle, new CultureInfo(cultureInfoName, false),
                (SqlCollation)Enum.Parse(typeof(SqlCollation),cultureSqlCollation,true));
            else
              culture = new Culture(cultureName, cultureTitle, new CultureInfo(cultureInfoName, false));
          }
        } 
        catch 
        {
          throw new ConfigurationException("One of applied attributes contains invalid value.", cultureNode);
        }
            
        domain.RegisterCulture(culture);
      }          
      if (domain.Cultures.Count==0)
        throw new ConfigurationException("At least one culture should be described.", culturesNode);
      if (domain.Cultures.DefaultCulture==null)
        domain.Cultures[defaultCultureName].Default = true;                               
    }

      private void SetNonPersistedFields()
      {


          XmlNode master = domainNode.SelectSingleNode("objectModel");
          if (master == null)
              return;

          //init script
          XmlNode dbSchemaNode = master.SelectSingleNode("databaseSchemaInitializationScript");
          if (dbSchemaNode != null)
          {
              XmlNodeList cmdNodes = dbSchemaNode.SelectNodes("command");
              foreach (XmlNode commandNode in cmdNodes)
              {
                  Domain.ModelExtensions.DatabaseSchemaInitCommands.Add(commandNode.InnerText.Trim());
              }

          }

          XmlNode attrNode = master.SelectSingleNode("@tablespace");
          if (attrNode != null)
              Domain.ModelExtensions.Tablespace = attrNode.Value;
          attrNode = master.SelectSingleNode("@lobtablespace");
          if (attrNode != null)
              Domain.ModelExtensions.LOBTablespace = attrNode.Value;

          attrNode = master.SelectSingleNode("@indextablespace");
          if (attrNode != null)
              Domain.ModelExtensions.IndexTablespace = attrNode.Value;
        
          XmlNodeList typeNodes = master.SelectNodes("type");

          foreach (XmlNode typeNode in typeNodes)
          {

              XmlNode nt = typeNode.SelectSingleNode("@name");
              if (nt != null)
              {
                  DataObjects.NET.ObjectModel.Builders.TypeExtension typeExt = new DataObjects.NET.ObjectModel.Builders.TypeExtension(nt.Value);
                  attrNode = typeNode.SelectSingleNode("@tablespace");
                  if (attrNode != null)
                    typeExt.Tablespace = attrNode.Value;
                  attrNode = typeNode.SelectSingleNode("@lobtablespace");
                  if (attrNode != null)
                        typeExt.LOBTablespace = attrNode.Value;
                  attrNode = typeNode.SelectSingleNode("@indextablespace");
                  if (attrNode != null)
                    typeExt.IndexTablespace = attrNode.Value;


                  Domain.ModelExtensions.AddTypeExtension(typeExt);

                  //fields
                  XmlNodeList propertyNodes = typeNode.SelectNodes("@field");
                  foreach (XmlNode propertyNode in propertyNodes)
                  {
                      XmlNode n = propertyNode.SelectSingleNode("@name");
                      if (n != null)
                      {
                          DataObjects.NET.ObjectModel.Builders.FieldExtension fldExt = new DataObjects.NET.ObjectModel.Builders.FieldExtension(n.Value);
                          XmlNode node = propertyNode.SelectSingleNode("@disabled");
                          if (node != null)
                              fldExt.IsNonPersistent = (node.Value == "true");

                          typeExt.AddFieldExtension(fldExt);
                      }
                  }

                  //indexes
                  propertyNodes = typeNode.SelectNodes("index");
                  foreach (XmlNode propertyNode in propertyNodes)
                  {
                      XmlNode n = propertyNode.SelectSingleNode("@name");
                      if (n != null)
                      {
                          DataObjects.NET.ObjectModel.Builders.IndexExtension idxExt = new DataObjects.NET.ObjectModel.Builders.IndexExtension(n.Value);
                          // index fields
                          XmlNode node = propertyNode.SelectSingleNode("@fields");
                          if (node != null)
                              idxExt.IndexFields = node.Value;

                          // index type
                          node = propertyNode.SelectSingleNode("@type");
                          if (node != null)
                              idxExt.IndexType = node.Value;

                          // index type
                          node = propertyNode.SelectSingleNode("@unique");
                          if (node != null)
                              idxExt.IsUnique = (node.Value == "true");

                          // tablespace
                          node = propertyNode.SelectSingleNode("@tablespace");
                          if (node != null)
                              idxExt.Tablespace = node.Value;

                          // fillfactor
                          node = propertyNode.SelectSingleNode("@fillfactor");
                          if (node != null)
                              idxExt.FillFactor = (double)Convert.ChangeType(node.Value, typeof(double));

                          // clustered
                          node = propertyNode.SelectSingleNode("@clustered");
                          if (node != null)
                              idxExt.Clustered = (bool)Convert.ChangeType(node.Value, typeof(bool));

                          // partitions
                          node = propertyNode.SelectSingleNode("partitions");
                          if (node != null)
                              idxExt.Partitions = node.InnerText.Trim();

                          typeExt.AddIndexExtension(idxExt);
                      }
                  }

                  //partition
                  XmlNode partitionNode = typeNode.SelectSingleNode("partitions");
                  if (partitionNode != null)
                  {
                      typeExt.Partitions = partitionNode.InnerText.Trim();
                  }


                  /*
                  XmlNode setNode = typeNode.SelectSingleNode("partitions");
                  if (setNode != null)
                  {
                      XmlNode n = setNode.SelectSingleNode("@type");
                      if (n != null)
                      {
                          PartitionSet set = domain.Driver.CreatePartitionSet(n.Value, null);
                          if (set != null)
                          {
                              XmlNodeList partsNode = setNode.SelectNodes("partition");
                              Hashtable properties = new Hashtable();
                              foreach (XmlNode partitionNode in partsNode)
                              {
                                  properties.Clear();
                                  n = partitionNode.SelectSingleNode("@name");
                                  properties.Add("NAME", n.Value);
                                  XmlNodeList propertiesNode = partitionNode.SelectNodes("property");
                                  if (propertiesNode != null)
                                  {
                                      foreach (XmlNode propertyNode in propertiesNode)
                                      {
                                          n = propertyNode.SelectSingleNode("@name");
                                          if (n != null)
                                          {
                                              string propertyName = n.Value;
                                              n = propertyNode.SelectSingleNode("@value");
                                              if (n != null)
                                                  properties.Add(propertyName, n.Value);
                                          }
                                      }
                                  }
                                  set.Partitions.Add(set.LoadPartition(properties));
                              }
                          }
                      }
                  }
                  */
              }
          }
      }  
    

    private void LoadAssemblies()
    {
      XmlNode loadNode = domainNode.SelectSingleNode("load");
      if (loadNode==null)
        return;
          
      XmlNodeList assemblyNodes = loadNode.SelectNodes("assembly");
      foreach (XmlNode assemblyNode in assemblyNodes) {
        XmlNode n = assemblyNode.SelectSingleNode("@name");
        if (n==null) 
          throw new ConfigurationException("Attribute \"name\" wasn't found.", assemblyNode);          
        Assembly.Load(n.Value);
      }  
    }
    
    private void SetTypes()
    {
      XmlNode typesNode = domainNode.SelectSingleNode("types");
      if (typesNode==null)
        return;
          
      XmlNodeList assemblyNodes = typesNode.SelectNodes("assembly");
      foreach (XmlNode assemblyNode in assemblyNodes) {
        XmlNode n = assemblyNode.SelectSingleNode("@name");
        if (n==null) 
          throw new ConfigurationException("Attribute \"name\" wasn't found.", assemblyNode);          
        domain.RegisterTypes(Assembly.Load(n.Value));
      }  
          
      XmlNodeList namespaceNodes = typesNode.SelectNodes("namespace");
      foreach (XmlNode namespaceNode in namespaceNodes) {
        XmlNode n = namespaceNode.SelectSingleNode("@name");
        if (n==null) 
          throw new ConfigurationException("Attribute \"name\" wasn't found.", namespaceNode);          
        domain.RegisterTypes(n.Value);
      }  
    }

    private void SetServices()
    {
      XmlNode typesNode = domainNode.SelectSingleNode("services");
      if (typesNode==null)
        return;
          
      XmlNodeList assemblyNodes = typesNode.SelectNodes("assembly");
      foreach (XmlNode assemblyNode in assemblyNodes) {
        XmlNode n = assemblyNode.SelectSingleNode("@name");
        if (n==null) 
          throw new ConfigurationException("Attribute \"name\" wasn't found.", assemblyNode);          
        domain.RegisterServices(Assembly.Load(n.Value));
      }  
          
      XmlNodeList namespaceNodes = typesNode.SelectNodes("namespace");
      foreach (XmlNode namespaceNode in namespaceNodes) {
        XmlNode n = namespaceNode.SelectSingleNode("@name");
        if (n==null) 
          throw new ConfigurationException("Attribute \"name\" wasn't found.", namespaceNode);          
        domain.RegisterServices(n.Value);
      }  
    }
    
    private void SetFieldTypes()
    {
      XmlNode fieldTypesNode = domainNode.SelectSingleNode("fieldTypes");
      if (fieldTypesNode==null)
        return;
          
      XmlNodeList assemblyNodes = fieldTypesNode.SelectNodes("assembly");
      foreach (XmlNode assemblyNode in assemblyNodes) {
        XmlNode n = assemblyNode.SelectSingleNode("@name");
        if (n==null) 
          throw new ConfigurationException("Attribute \"name\" wasn't found.", assemblyNode);          
        domain.RegisterFieldTypes(Assembly.Load(n.Value));
      }  
    }

    private void TryBuild()
    {
      XmlNode n = domainNode.SelectSingleNode("@build");
      if (n!=null) {
        bool build = Boolean.Parse(n.Value);
        if (build)
          domain.Build();
      }      
    }      

    private void SetEnumProperties()
    {      
      Type domainType = domain.GetType();
      PropertyInfo[] domainProperties = domainType.GetProperties(); 
      foreach (PropertyInfo domainProperty in domainProperties) {
        if (domainProperty.CanWrite) {                                         
          XmlNode n = domainNode.SelectSingleNode("@"+domainProperty.Name);
          if (n!=null) {            
            if (domainProperty.PropertyType.IsEnum) {
              try {
                object val = Enum.Parse(Type.GetType(domainProperty.PropertyType.FullName),n.Value);
                domainProperty.SetValue(domain,val,null);
              }  
              catch (ArgumentException) {
                throw new ConfigurationException(n.Value+" is not valid value for domain property "+domainProperty.Name);
              }
            }
          }
        }
      }
    }
  }    
}
