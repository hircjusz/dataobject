// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;
using System.Diagnostics;

namespace DataObjects.NET.Diagnostics
{
  internal class PerformanceCounterFactoryCounterDescriptor
  {
    public string counterName;
    public string counterHelp;
    public PerformanceCounterType counterType;
    public string baseCounterName = null;
    public PerformanceCounterType baseCounterType;

    public bool HasBaseCounter
    {
      get { return (baseCounterName!=null); }
    }

    // Returns 0 when base type has no sense;
    private static PerformanceCounterType GetBaseType(PerformanceCounterType type)
    {
      switch (type) {
      case PerformanceCounterType.AverageTimer32:
      case PerformanceCounterType.AverageCount64:
        return PerformanceCounterType.AverageBase;
      case PerformanceCounterType.CounterMultiTimer:
      case PerformanceCounterType.CounterMultiTimerInverse:

      case PerformanceCounterType.CounterMultiTimer100Ns:

      case PerformanceCounterType.CounterMultiTimer100NsInverse:
        return PerformanceCounterType.CounterMultiBase;
      case PerformanceCounterType.RawFraction:
        return PerformanceCounterType.RawBase;
      case PerformanceCounterType.SampleCounter:
      case PerformanceCounterType.SampleFraction:
        return PerformanceCounterType.SampleBase;
      default:
        return 0;
      }
    }
    

    // Constructors

    public PerformanceCounterFactoryCounterDescriptor(string counterName, string counterHelp, PerformanceCounterType counterType)
    {
      this.counterName = counterName;
      this.counterHelp = counterHelp;
      this.counterType = counterType;
      baseCounterType = GetBaseType(counterType);
      if (baseCounterType!=0)
        baseCounterName = PerformanceCounterFactory.GetBaseCounterName(counterName);
    }
  }
}
