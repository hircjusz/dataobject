// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.IO;
using System.Text;
using System.Threading;
using System.Collections;
using System.Collections.Specialized;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.Serialization;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Attributes;
using DataObjects.NET.ObjectModel;
using DataObjects.NET.Serialization;
using DataObjects.NET.FullText;
using DataObjects.NET.Security.Permissions;
using Helpers = DataObjects.NET.Helpers;

namespace DataObjects.NET.Security
{
  /// <summary>
  /// Represents <see cref="DataObject"/> instance's Access Control List (it is
  /// accessible via <see cref="DataObject.Permissions">DataObject.Permissions</see> 
  /// property).
  /// <seealso cref="DomainSecurityMode"/>
  /// <seealso cref="DataObject.Permissions"/>
  /// <seealso cref="DataObject.SecurityParent"/>
  /// <seealso cref="DataObject.SecurityChildren"/>
  /// <seealso cref="DataObject.SecurityRoot"/>
  /// <seealso cref="IPermission"/>
  /// <seealso cref="IPermissionSet"/>
  /// <seealso cref="ISecurityRoot"/>
  /// <seealso cref="PermissionSet"/>
  /// <seealso cref="Principal"/>
  /// <seealso cref="User"/>
  /// <seealso cref="Role"/>
  /// <seealso cref="SecurityRoot"/>
  /// <seealso cref="SessionBoundObject.DisableSecurity"/>
  /// <seealso cref="SessionBoundObject.EnableSecurity"/>
  /// <seealso cref="DataObjects.NET.Security.Permissions"/>
  /// </summary>
  /// <remarks>
  /// <para>
  /// DataObjects.NET security system is based on permissions acquisition
  /// principal. This means that effective permission set for any persistent
  /// instance is determined by: 
  /// </para>
  /// <para>1) permissions applied directly on it;</para>
  /// <para>2) all inherited permissions (i.e. permissions applied on its 
  /// <see cref="DataObject.SecurityParent"/> and so further - till the 
  /// <see cref="DataObject.SecurityRoot"/>).</para>
  /// <para>
  /// <see cref="DataObject"/> instance's <see cref="DataObject.SecurityParent"/> 
  /// property specifies the object to inherit permissions from. 
  /// <see cref="DataObject.SecurityRoot"/> object is a root object 
  /// in the permissions inheritance hierarchy (so its value of
  /// <see cref="DataObject.SecurityParent"/> property is <see langword="null"/>).
  /// </para>
  /// <para>
  /// "Permissions acquisition" exactly means that if we want to determine
  /// effective permission set for some <see cref="User"/> and some 
  /// <see cref="DataObject"/> instance, we should:
  /// </para>
  /// <para>
  /// 1) Locate all <see cref="Role"/>s to which this user belongs directly or 
  ///    indirectly 
  ///    (see <see cref="Principal.AllRoles">Principal.AllRoles</see> property
  ///    description).
  ///    Let's call all these roles + current user as effective security 
  ///    principal set.
  /// </para>
  /// <para>
  /// 2) Locate all <see cref="DataObject.SecurityParent"/> instances of the current
  ///    <see cref="DataObject"/> instance.
  ///    Let's call all these instances + current <see cref="DataObject"/> 
  ///    instance as inheritance branch.
  /// </para>
  /// <para>
  /// 3) <see cref="IPermissionSet.Union"/> all permissions, 
  ///    that are explicitely allowed (see <see cref="Allow"/> method)
  ///    on instances from the inheritance branch
  ///    for <see cref="Principal"/>s from effective security principal set;
  /// </para>
  /// <para>
  /// 4) <see cref="IPermissionSet.Subtract"/> (from the 
  ///    <see cref="PermissionSet">permission set</see> we 
  ///    produced on the previous step) 
  ///    all permissions, that are explicitely denied (see <see cref="Deny"/> method)
  ///    on instances from the inheritance branch
  ///    for <see cref="Principal"/>s from effective security principal set;
  /// </para>
  /// <para>
  /// 5) The resulting <see cref="PermissionSet">permission set</see> will be an effective permission set
  ///    (for the specified <see cref="User"/> and 
  ///    <see cref="DataObject"/> instance).
  /// </para>
  /// <para>
  /// Any permission that exists in the effective permission set is allowed 
  /// for the current <see cref="User"/> (on the specified 
  /// <see cref="DataObject"/> instance) - this means that <see cref="DataObject.Demand"/>
  /// of this permission won't throw a <see cref="SecurityException"/>.
  /// Also a permission can be allowed, if there is another permission
  /// from its <see cref="IPermission.GrantedIfGrantedAnyOf"/> permission list
  /// exists in the effective permission set.
  /// All other permissions are not allowed (<see cref="SecurityException"/>
  /// will be thrown on attemp to <see cref="DataObject.Demand"/> any of such permissions).
  /// </para>
  /// <para>
  /// Actually this is almost the same security model as used in the NTFS
  /// (primary difference is that DataObjects.NET allows to use not only
  /// the predefined permissions, but custom permissions).
  /// </para>
  /// <note type="note">Some permissions are supported internally by
  /// DataObjects.NET - e.g. presence of <see cref="AdministrationPermission"/>
  /// in the effective permission set actually means that any permission
  /// is <see cref="IsAllowed">allowed</see> and any <see cref="DataObject.Demand">demand</see> 
  /// will be completed successfully.
  /// </note>
  /// <para>
  /// You can extend DataObjects.NET security system to satisfy your
  /// application requirements - all you have to do is to:
  /// </para>
  /// <para>a) Implement your own <see cref="Permission"/> descendants (custom 
  ///          permission);</para>
  /// <para>b) Properly apply <see cref="DataObject.Demand"/>s of these 
  ///          permissions.</para>
  /// <note type="note">Moreover, you can prevent most of permission demands 
  /// that DataObjects.NET executes - most of internal permission demands are
  /// executed by the <see cref="DataObject">DataObject.OnXXX</see>
  /// methods (event handlers). You can simply override some of these
  /// methods in your persistent classes to override default permission
  /// demands. You can find examples of such overrides in the
  /// <see cref="FtRecord"/>, <see cref="Principal"/>, <see cref="User"/>,
  /// <see cref="Role"/> implementation (the code of these classes is
  /// shipped with DataObjects.NET 2.0).
  /// </note>
  /// <para>
  /// Refer to the DataObjects.NET Manual for additional information about
  /// the DataObjects.NET 2.0 security concepts.
  /// </para>
  /// </remarks>
  [Serializable]
  #if (!NoMBR)
  public sealed class AccessControlList: MarshalByRefObject, 
  #else
  public sealed class AccessControlList: Object, 
  #endif
    IDataObjectFieldValue, 
    IEnumerable, ICollection,
    ISerializable, IDeserializationCallback
  {
  
    private sealed class PermissionStatus
    {
      public static PermissionStatus Allowed = new PermissionStatus();
      public static PermissionStatus Denied = new PermissionStatus();
    }
  
    private  const int MaxCachedPermissions = 8;
    private  const int InheritMask      = 1;
    private  const int InconsistentMask = 2;
    private  const int AllowChangeMask  = 4;

    // IDataObjectFieldValue support
    internal DataObject owner;
    internal Field      field;
    
    /// <summary>
    /// Gets the owner of the field 
    /// (<see cref="DataObject"/> instance containing the field).
    /// </summary>
    public DataObject Owner  {get {return owner;}}
    
    /// <summary>
    /// Gets field descriptor (<see cref="Field"/> descandant).
    /// </summary>
    public Field      Field {get {return field;}}
    
    /// <summary>
    /// Gets the <see cref="Culture"/> of this instance.
    /// </summary>
    public Culture    Culture {get {return null;}}

    // Primary fields
    private  BitVector32    stateFlags            = new BitVector32(InheritMask);
    internal Hashtable      principals            = new Hashtable();
    internal Hashtable      allowedPermissionSets = new Hashtable();
    internal Hashtable      deniedPermissionSets  = new Hashtable();
    // Caching
    internal DataObject     securityParent;
    private  DataObject     subscribedSecurityParent;
    internal PermissionSet  allowedPermissions;
    internal PermissionSet  deniedPermissions;
    internal PermissionSet  effectivePermissions;
    internal TransactionContext effectivePermissionsTransactionContext;
    internal ListDictionary cachedPermissions = new ListDictionary();
    // Serialization
    internal SerializationInfo serializationInfo;
    internal Session           session;


    // IDataObjectFieldValue methods

    /// <summary>
    /// Attaches the instance to the owner. This method is called by owner
    /// (<see cref="DataObject"/> instance) of the field during
    /// initialization or on property change.
    /// </summary>
    /// <param name="owner">Field owner (<see cref="DataObject"/> instance containing this field).</param>
    /// <param name="field">Field descriptor (<see cref="Field"/> descandant).</param>
    /// <param name="culture">Culture of this instance (if field is marked by 
    /// <see cref="TranslatableAttribute"/>), or <see langword="null"/>.</param>
    /// <remarks>
    /// Always throws <see cref="InvalidOperationException"/>,
    /// since this field is always attached internally by DataObjects.NET.
    /// See <see cref="IDataObjectFieldValue"/> description for additional information.
    /// </remarks>
    void IDataObjectFieldValue.Attach(DataObject owner, Field field, Culture culture)
    {
      throw new InvalidOperationException("This type can't be attached by this way.");
    }
  
    /// <summary>
    /// Detaches the instance from the owner.
    /// </summary>
    /// <remarks>
    /// Always throws <see cref="InvalidOperationException"/>,
    /// since this field is always attached internally by DataObjects.NET.
    /// See <see cref="IDataObjectFieldValue"/> description for additional information.
    /// </remarks>
    void IDataObjectFieldValue.Detach()
    {
      throw new InvalidOperationException("This type can't be detached by this way.");
    }
    
    // State flags
    
    internal bool InternalInherit {
      get {
        return stateFlags[InheritMask];
      }
      set {
        stateFlags[InheritMask] = value;
      }
    }
    
    internal bool AllowChange {
      get {
        return stateFlags[AllowChangeMask];
      }
      set {
        stateFlags[AllowChangeMask] = value;
      }
    }
    
    internal bool Inconsistent {
      get {
        return stateFlags[InconsistentMask];
      }
      set {
        stateFlags[InconsistentMask] = value;
      }
    }
    
    // IEnumerable methods
    
    /// <summary>
    /// Returns an enumerator that can iterate through the
    /// collection instance.
    /// </summary>
    /// <returns>
    /// An <see cref="IEnumerator"/> for the 
    /// collection instance.
    /// </returns>
    public IEnumerator GetEnumerator()
    {
      if (owner.State==DataObjectState.Removed)
        throw new InstanceIsRemovedException();
      return new AccessControlListEnumerator(this, principals.Keys.GetEnumerator());
    }
    
    // ICollection methods
    
    /// <summary>
    /// Gets the number of <see cref="Principal"/>s used in this list.
    /// </summary>
    public int Count {
      get {
        if (owner.State==DataObjectState.Removed)
          throw new InstanceIsRemovedException();
        return principals.Count;
      }
    }

    /// <summary>
    /// <see langword="True"/> if permissions are inherited from
    /// <see cref="Owner"/>.<see cref="DataObject.SecurityParent"/>;
    /// otherwise, <see langword="false"/>.
    /// <seealso cref="DomainSecurityMode"/>
    /// <seealso cref="Domain.SecurityMode"/>
    /// </summary>
    [Transactional(TransactionMode.TransactionRequired)]
    public bool Inherit {
      get {
        if ((owner.session.domain.SecurityMode & DomainSecurityMode.AllowNotInheritPermissions)==0)
          return true;
        return InternalInherit;
      }
      set {
        if ((owner.session.domain.SecurityMode & DomainSecurityMode.AllowNotInheritPermissions)==0 && value==false)
          throw new SecurityException("Operation isn't allowed in active DomainSecurityMode.");
        if (owner.State==DataObjectState.Removed)
          throw new InstanceIsRemovedException();

        owner.Demand(ChangePermissionsPermission.Value);

        TransactionController tc = owner.session.CreateTransactionController( TransactionMode.TransactionRequired);
        AllowChange = true;
        try {
          OnChanging(null);
          InternalInherit = value;
          OnChanged(null);
          tc.Commit();
        }
        catch (Exception e) {
          tc.Rollback(e);
          throw;
        }
        finally {
          AllowChange = false;
        }
      }
    }

    /// <summary>
    /// Always throws an <see cref="NotSupportedException"/>.
    /// </summary>
    /// <param name="array">The one-dimensional Array that is the destination of the elements copied from collection. The Array must have zero-based indexing.</param>
    /// <param name="index">The zero-based index in array at which copying begins.</param>
    void ICollection.CopyTo(Array array, int index)
    {
      throw new NotSupportedException();
    }

    /// <summary>
    /// Gets a value indicating whether access to the 
    /// collection is synchronized (thread-safe).
    /// </summary>
    /// <returns><see langword="True"/> if access to the collection is synchronized (thread-safe); otherwise, <see langword="false"/>.</returns>
    bool ICollection.IsSynchronized {
      get {
        if (owner.State==DataObjectState.Removed)
          throw new InstanceIsRemovedException();
        return false;
      }
    }

    /// <summary>
    /// Gets an object that can be used to synchronize access to the collection.
    /// </summary>
    /// <returns>An object that can be used to synchronize access to the collection.</returns>
    object ICollection.SyncRoot {
      get {
        if (owner.State==DataObjectState.Removed)
          throw new InstanceIsRemovedException();
        return this;
      }
    }

    // Access to the allowed/denied permission sets
    
    /// <summary>
    /// Returns <see cref="PermissionSet"/> containing
    /// allowed permissions for the specified principal.
    /// </summary>
    /// <param name="principal">Principal to get the set for.</param>
    /// <returns><see cref="PermissionSet"/> containing
    /// allowed permissions for the specified principal.</returns>
    public PermissionSet GetAllowedPermissionSet(Principal principal) 
    {
      if (owner.State==DataObjectState.Removed)
        throw new InstanceIsRemovedException();
      object ps = allowedPermissionSets[principal.ID];
      return (ps!=null ? (PermissionSet)ps : new PermissionSet());
    }
  
    /// <summary>
    /// Returns <see cref="PermissionSet"/> containing
    /// denied permissions for the specified principal.
    /// </summary>
    /// <param name="principal">Principal to get the set for.</param>
    /// <returns><see cref="PermissionSet"/> containing
    /// denied permissions for the specified principal.</returns>
    public PermissionSet GetDeniedPermissionSet(Principal principal) 
    {
      if (owner.State==DataObjectState.Removed)
        throw new InstanceIsRemovedException();
      object ps = deniedPermissionSets[principal.ID];
      return (ps!=null ? (PermissionSet)ps : new PermissionSet());
//      return (PermissionSet)deniedPermissionSets[principal.ID];
    }

    /// <summary>
    /// Returns <see cref="PermissionSet"/> containing
    /// effective permissions for the specified principal.
    /// </summary>
    /// <param name="principal">Principal to get the set for.</param>
    /// <returns><see cref="PermissionSet"/> containing
    /// effective permissions for the specified principal.</returns>
    public PermissionSet GetEffectivePermissionSet(Principal principal) 
    {
      if (owner.session.IsOfflineMode) 
        return InnerGetEffectivePermissionSet(principal);

      // Automatic Transactions support code
      TransactionController tc = owner.session.CreateTransactionController( TransactionMode.TransactionRequired);
    Reprocess:
      try {
        PermissionSet r = InnerGetEffectivePermissionSet(principal);
        tc.Commit();
        return r;
      }
      catch (Exception e) {
        if (tc.Rollback(e, true))
          goto Reprocess;             
        throw;
      }
    }
    private PermissionSet InnerGetEffectivePermissionSet(Principal principal)
    {
      if (owner.State==DataObjectState.Removed)
        throw new InstanceIsRemovedException();

      Stack stackSecurityParents = GetAllSecurityParents(this.owner); 
      
      // Let's produce Allowed-Denied permission sets for
      // the given principal on the current object.
      Session session   = owner.session;
      Domain  domain    = session.domain;
      Role[]  allRoles  = principal.InternalAllRoles;

      PermissionSet cumulativeAps = null;
      PermissionSet cumulativeDps = null;
      while (stackSecurityParents.Count>0) {
        DataObject obj = (DataObject)stackSecurityParents.Pop();
        PermissionSet aps = null;
        PermissionSet dps = null;

        long id = principal.ID;
        for (int roleIndex = 0, roleCount = allRoles.Length; roleIndex <= roleCount; roleIndex++) {
          PermissionSet cps = (PermissionSet) obj.permissions.allowedPermissionSets[id];
          if (cps!=null) {
            if (aps==null)
              aps = new PermissionSet(cps);
            else
              aps.Union(cps);
          }
          cps = (PermissionSet) obj.permissions.deniedPermissionSets[id];
          if (cps!=null) {
            if (dps==null)
              dps = new PermissionSet(cps);
            else
              dps.Union(cps);
          }
          if (roleIndex < roleCount)
            id = allRoles[roleIndex].ID;
        }

        if (obj.SecurityParent!=obj && obj.permissions.Inherit) {
          // Obj is not a SecurityRoot
          switch (domain.SecurityMode) {
          case DomainSecurityMode.InheritedDenyWinsExplicitAllow:
          case DomainSecurityMode.InheritedDenyWinsExplicitAllow | DomainSecurityMode.AllowNotInheritPermissions:
            if (aps!=null) {
              if (cumulativeAps==null)
                cumulativeAps=new PermissionSet(aps);
              else
                cumulativeAps.Union(aps);
            }
            if (dps!=null) {
              if (cumulativeDps==null)
                cumulativeDps=new PermissionSet(dps);
              else
                cumulativeDps.Union(dps);
            }
            break;
          case DomainSecurityMode.ExplicitAllowOrDenyWinsInheritedAllowOrDeny:
          case DomainSecurityMode.ExplicitAllowOrDenyWinsInheritedAllowOrDeny | DomainSecurityMode.AllowNotInheritPermissions:
            if (aps!=null) {
              if (cumulativeDps!=null)
                cumulativeDps.Subtract(aps);
              if (dps!=null) {
                if (cumulativeDps==null)
                  cumulativeDps = new PermissionSet(dps);
                else
                  cumulativeDps.Union(dps);
              }
              if (cumulativeAps==null)
                cumulativeAps = new PermissionSet(aps);
              else
                cumulativeAps.Union(aps);
            }
            else {
              if (dps!=null) {
                if (cumulativeDps==null)
                  cumulativeDps = new PermissionSet(dps);
                else
                  cumulativeDps.Union(dps);
              }
            }
            break;
          default:
            throw new InvalidOperationException("Unknown Domain.SecurityMode value.");
          }
        }
        else {
          // This is a SecurityRoot
          if (aps!=null)
            cumulativeAps=new PermissionSet(aps);
          if (dps!=null)
            cumulativeDps=new PermissionSet(dps);
        }
      }
      PermissionSet effectivePermisionSet = null;
      if (cumulativeAps!=null || cumulativeDps!=null) {
        effectivePermisionSet = new PermissionSet(cumulativeAps);
        effectivePermisionSet.Subtract(cumulativeDps);
      }
      return effectivePermisionSet;
    }
    private Stack GetAllSecurityParents(DataObject objSecurityTarget)
    {
      Stack stackSecurityParents = new Stack(); 
      DataObject obj = objSecurityTarget;
      while (obj!=null) {
        if (obj.permissions!=null) {
          stackSecurityParents.Push(obj);
          if (!obj.permissions.Inherit)
            break;
        }
        if (obj==obj.SecurityParent)
          break;
        obj = obj.SecurityParent;
      }
      return stackSecurityParents;
    }

    /// <summary>
    /// Returns <see cref="FlatPermissionEntryCollection"/> object containing
    /// full information about all permissions applied to every 
    /// <see cref="DataObject"/> instance in the <see cref="Owner"/>'s 
    /// permission inheritance hierarchy.
    /// </summary>
    /// <remarks>
    /// <para>
    /// This method is useful for GUI representation of object's permission
    /// inheritance hierarchy. It is relatively slow incomparison to other
    /// methods of <see cref="AccessControlList"/> class.
    /// </para>
    /// </remarks>
    public FlatPermissionEntryCollection GetFlatPermissions()
    {
      if (owner.session.IsOfflineMode) 
        return InnerGetFlatPermissions();

      // Automatic Transactions support code
      TransactionController tc = owner.session.CreateTransactionController( TransactionMode.TransactionRequired);
    Reprocess:
      try {
        FlatPermissionEntryCollection r = InnerGetFlatPermissions();
        tc.Commit();
        return r;
      }
      catch (Exception e) {
        if (tc.Rollback(e, true))
          goto Reprocess;             
        throw;
      }
    }
    private FlatPermissionEntryCollection InnerGetFlatPermissions()
    {
      if (owner.State==DataObjectState.Removed)
        throw new InstanceIsRemovedException();

      Stack stackSecurityParents = GetAllSecurityParents(this.owner); 
      ArrayList fpeCollection = new ArrayList();
      while (stackSecurityParents.Count>0) {
        DataObject obj = (DataObject)stackSecurityParents.Pop();
        if (obj.permissions!=null) {
          if (obj.permissions.allowedPermissionSets!=null) {
            foreach (long id in obj.permissions.allowedPermissionSets.Keys) {
              PermissionSet ps = (PermissionSet)obj.permissions.allowedPermissionSets[id];
              Principal principal = (Principal)obj.Session[id];
              foreach (IPermission p in ps) {
                fpeCollection.Add(new FlatPermissionEntry(p, obj, principal, true));
              }
            }
          }
          if (obj.permissions.deniedPermissionSets!=null) {
            foreach (long id in obj.permissions.deniedPermissionSets.Keys) {
              PermissionSet ps = (PermissionSet)obj.permissions.deniedPermissionSets[id];
              Principal principal = (Principal)obj.Session[id];
              foreach (IPermission p in ps) {
                fpeCollection.Add(new FlatPermissionEntry(p, obj, principal, false));
              }
            }
          }
        }
      }
      return new FlatPermissionEntryCollection(fpeCollection);
    }
    
    /// <summary>
    /// Returns effective <see cref="PermissionSet">permission set</see>
    /// for the current <see cref="Session.User"/> in the <see cref="Session"/>
    /// and this access control list's owner (<see cref="DataObject"/>
    /// instance).
    /// </summary>
    /// <returns>Effective <see cref="PermissionSet">permission set</see>.</returns>
    /// <remarks>
    /// <para>
    /// You can find more information about the whole DataObjects.NET
    /// security system <see cref="AccessControlList">here</see>.
    /// </para>
    /// </remarks>
    [Transactional(TransactionMode.TransactionRequired | TransactionMode.SupportsOfflineMode)]
    public PermissionSet GetEffectivePermissionSet()
    {
      if (owner.session.IsOfflineMode) 
        return InnerGetEffectivePermissionSet();

      // Automatic Transactions support code
      TransactionController tc = owner.session.CreateTransactionController( TransactionMode.TransactionRequired);
    Reprocess:
      try {
        PermissionSet r = InnerGetEffectivePermissionSet();
        tc.Commit();
        return r;
      }
      catch (Exception e) {
        if (tc.Rollback(e, true))
          goto Reprocess;
        throw;
      }
    }
    private PermissionSet InnerGetEffectivePermissionSet()
    {
      if (owner.State==DataObjectState.Removed)
        throw new InstanceIsRemovedException();
      UpdatePermissionCache();
      return new PermissionSet(effectivePermissions);
    }
  
    // Allow/deny methods
  
    /// <summary>
    /// Grants the permission for the specified principal.
    /// <seealso cref="RemoveAllowed"/>
    /// <seealso cref="Deny"/>
    /// <seealso cref="RemoveDenied"/>
    /// </summary>
    /// <param name="principal">Principal to grant the permission for.</param>
    /// <param name="permission">Permission to grant (<see cref="IPermissionSet"/> is allowed here).</param>
    /// <param name="checkPermissions"><see langword="True"/> if permissions for this action should be checked;
    /// otherwise, <see langword="false"/>.</param>
    /// <remarks>
    /// <para>
    /// Any non-<see cref="DataObject"/> and non-<see cref="DataService"/>
    /// caller should set <paramref name="checkPermissions"/> parameter 
    /// to <see langword="true"/> - otherwise a <see cref="SecurityException"/> 
    /// will be thrown.
    /// </para>
    /// <para>
    /// When permissions for this action are checked, the following permission
    /// <see cref="DataObject.Demand"/>s occur:
    /// <see cref="ChangePermissionsPermission"/>.
    /// Additionally all permissions that will be changed are demanded
    /// too - this means that any <see cref="User"/> can change (<see cref="Allow"/>\
    /// <see cref="Deny"/>\<see cref="ResetPermissions"/>) only those
    /// permissions that are allowed for himself.
    /// </para>
    /// </remarks>
    public void Allow(Principal principal, IPermission permission, bool checkPermissions)
    {
      if (principal==null)
        throw new ArgumentNullException("principal");

      if (owner.State==DataObjectState.Removed)
        throw new InstanceIsRemovedException();

      long pid = principal.ID;
      if (checkPermissions)
        CheckChangePermissions(permission);
      else
        CheckCaller();

      PermissionSet ps = (PermissionSet)allowedPermissionSets[pid];
      if (ps==null) {
        ps = new AccessControlListPermissionSet(this, pid, true);
        allowedPermissionSets[pid] = ps;
        principals[pid] = this;
      }

      TransactionController tc = owner.session.CreateTransactionController( TransactionMode.TransactionRequired);
      AllowChange = true;
      try {
        ps.Union(permission);
        tc.Commit();
      }
      catch (Exception e) {
        tc.Rollback(e);
        throw;
      }
      finally {
        AllowChange = false;
      }
    }

    /// <summary>
    /// Grants the permission for the specified principal.
    /// <seealso cref="RemoveAllowed"/>
    /// <seealso cref="Deny"/>
    /// <seealso cref="RemoveDenied"/>
    /// </summary>
    /// <param name="principal">Principal to grant the permission for.</param>
    /// <param name="permission">Permission to grant (<see cref="IPermissionSet"/> is allowed here).</param>
    /// <remarks>
    /// <para>
    /// When permissions for this action are checked, the following permission
    /// <see cref="DataObject.Demand"/>s occur:
    /// <see cref="ChangePermissionsPermission"/>.
    /// Additionally all permissions that will be changed are demanded
    /// too - this means that any <see cref="User"/> can change (<see cref="Allow"/>\
    /// <see cref="Deny"/>\<see cref="ResetPermissions"/>) only those
    /// permissions that are allowed for himself.
    /// </para>
    /// </remarks>
    [Transactional(TransactionMode.TransactionRequired)]
    public void Allow(Principal principal, IPermission permission)
    {
      Allow(principal, permission, true);
    }
  
    /// <summary>
    /// Removes the permission from the principal's granted permissions set.
    /// <seealso cref="Allow"/>
    /// <seealso cref="Deny"/>
    /// <seealso cref="RemoveDenied"/>
    /// </summary>
    /// <param name="principal">Principal to remove the permission for.</param>
    /// <param name="permission">Permission to remove (<see cref="IPermissionSet"/> is allowed here).</param>
    /// <param name="checkPermissions"><see langword="True"/> if permissions for this action should be checked;
    /// otherwise, <see langword="false"/>.</param>
    /// <remarks>
    /// <para>
    /// Any non-<see cref="DataObject"/> and non-<see cref="DataService"/>
    /// caller should set <paramref name="checkPermissions"/> parameter 
    /// to <see langword="true"/> - otherwise a <see cref="SecurityException"/> 
    /// will be thrown.
    /// </para>
    /// <para>
    /// When permissions for this action are checked, the following permission
    /// <see cref="DataObject.Demand"/>s occur:
    /// <see cref="ChangePermissionsPermission"/>.
    /// Additionally all permissions that will be changed are demanded
    /// too - this means that any <see cref="User"/> can change (<see cref="Allow"/>\
    /// <see cref="Deny"/>\<see cref="ResetPermissions"/>) only those
    /// permissions that are allowed for himself.
    /// </para>
    /// </remarks>
    public void RemoveAllowed(Principal principal, IPermission permission, bool checkPermissions)
    {
      if (principal==null)
        throw new ArgumentNullException("principal");
      RemoveAllowed(principal.ID, permission, checkPermissions);
    }
    
    internal void RemoveAllowed(long pid, IPermission permission, bool checkPermissions)
    {

      if (owner.State==DataObjectState.Removed)
        throw new InstanceIsRemovedException();

      if (checkPermissions)
        CheckChangePermissions(permission);
      else
        CheckCaller();

      PermissionSet ps = (PermissionSet)allowedPermissionSets[pid];
      if (ps==null) {
        owner.FieldContentChanging(this);
        return;
      }

      TransactionController tc = owner.session.CreateTransactionController( TransactionMode.TransactionRequired);
      AllowChange = true;
      try {
        ps.Subtract(permission);
        tc.Commit();
      }
      catch (Exception e) {
        tc.Rollback(e);
        throw;
      }
      finally {
        AllowChange = false;
      }
    }
  
    /// <summary>
    /// Removes the permission from the principal's granted permissions set.
    /// <seealso cref="Allow"/>
    /// <seealso cref="Deny"/>
    /// <seealso cref="RemoveDenied"/>
    /// </summary>
    /// <param name="principal">Principal to remove the permission for.</param>
    /// <param name="permission">Permission to remove (<see cref="IPermissionSet"/> is allowed here).</param>
    /// <remarks>
    /// <para>
    /// When permissions for this action are checked, the following permission
    /// <see cref="DataObject.Demand"/>s occur:
    /// <see cref="ChangePermissionsPermission"/>.
    /// Additionally all permissions that will be changed are demanded
    /// too - this means that any <see cref="User"/> can change (<see cref="Allow"/>\
    /// <see cref="Deny"/>\<see cref="ResetPermissions"/>) only those
    /// permissions that are allowed for himself.
    /// </para>
    /// </remarks>
    public void RemoveAllowed(Principal principal, IPermission permission)
    {
      RemoveAllowed(principal, permission, true);
    }
    
    /// <summary>
    /// Denies the permission for the specified principal.
    /// <seealso cref="Allow"/>
    /// <seealso cref="RemoveAllowed"/>
    /// <seealso cref="RemoveDenied"/>
    /// </summary>
    /// <param name="principal">Principal to deny the permission for.</param>
    /// <param name="permission">Permission to deny (<see cref="IPermissionSet"/> is allowed here).</param>
    /// <param name="checkPermissions"><see langword="True"/> if permissions for this action should be checked;
    /// otherwise, <see langword="false"/>.</param>
    /// <remarks>
    /// <para>
    /// Any non-<see cref="DataObject"/> and non-<see cref="DataService"/>
    /// caller should set <paramref name="checkPermissions"/> parameter 
    /// to <see langword="true"/> - otherwise a <see cref="SecurityException"/> 
    /// will be thrown.
    /// </para>
    /// <para>
    /// When permissions for this action are checked, the following permission
    /// <see cref="DataObject.Demand"/>s occur:
    /// <see cref="ChangePermissionsPermission"/>.
    /// Additionally all permissions that will be changed are demanded
    /// too - this means that any <see cref="User"/> can change (<see cref="Allow"/>\
    /// <see cref="Deny"/>\<see cref="ResetPermissions"/>) only those
    /// permissions that are allowed for himself.
    /// </para>
    /// </remarks>
    [Transactional(TransactionMode.TransactionRequired)]
    public void Deny(Principal principal, IPermission permission, bool checkPermissions)
    {
      if (principal==null)
        throw new ArgumentNullException("principal");

      if (owner.State==DataObjectState.Removed)
        throw new InstanceIsRemovedException();

      long pid = principal.ID;
      if (checkPermissions)
        CheckChangePermissions(permission);
      else
        CheckCaller();

      PermissionSet ps = (PermissionSet)deniedPermissionSets[pid];
      if (ps==null) {
        ps = new AccessControlListPermissionSet(this, pid, false);
        deniedPermissionSets[pid] = ps;
        principals[pid] = this;
      }

      TransactionController tc = owner.session.CreateTransactionController( TransactionMode.TransactionRequired);
      AllowChange = true;
      try {
        ps.Union(permission);
        tc.Commit();
      }
      catch (Exception e) {
        tc.Rollback(e);
        throw;
      }
      finally {
        AllowChange = false;
      }
    }
  
    /// <summary>
    /// Denies the permission for the specified principal.
    /// <seealso cref="Allow"/>
    /// <seealso cref="RemoveAllowed"/>
    /// <seealso cref="RemoveDenied"/>
    /// </summary>
    /// <param name="principal">Principal to deny the permission for.</param>
    /// <param name="permission">Permission to deny (<see cref="IPermissionSet"/> is allowed here).</param>
    /// <remarks>
    /// <para>
    /// When permissions for this action are checked, the following permission
    /// <see cref="DataObject.Demand"/>s occur:
    /// <see cref="ChangePermissionsPermission"/>.
    /// Additionally all permissions that will be changed are demanded
    /// too - this means that any <see cref="User"/> can change (<see cref="Allow"/>\
    /// <see cref="Deny"/>\<see cref="ResetPermissions"/>) only those
    /// permissions that are allowed for himself.
    /// </para>
    /// </remarks>
    public void Deny(Principal principal, IPermission permission)
    {
      Deny(principal, permission, true);
    }
    
    /// <summary>
    /// Removes the permission from the principal's denied permissions set.
    /// <seealso cref="Allow"/>
    /// <seealso cref="RemoveAllowed"/>
    /// <seealso cref="Deny"/>
    /// </summary>
    /// <param name="principal">Principal to remove the permission for.</param>
    /// <param name="permission">Permission to remove (<see cref="IPermissionSet"/> is allowed here).</param>
    /// <param name="checkPermissions"><see langword="True"/> if permissions for this action should be checked;
    /// otherwise, <see langword="false"/>.</param>
    /// <remarks>
    /// <para>
    /// Any non-<see cref="DataObject"/> and non-<see cref="DataService"/>
    /// caller should set <paramref name="checkPermissions"/> parameter 
    /// to <see langword="true"/> - otherwise a <see cref="SecurityException"/> 
    /// will be thrown.
    /// </para>
    /// <para>
    /// When permissions for this action are checked, the following permission
    /// <see cref="DataObject.Demand"/>s occur:
    /// <see cref="ChangePermissionsPermission"/>.
    /// Additionally all permissions that will be changed are demanded
    /// too - this means that any <see cref="User"/> can change (<see cref="Allow"/>\
    /// <see cref="Deny"/>\<see cref="ResetPermissions"/>) only those
    /// permissions that are allowed for himself.
    /// </para>
    /// </remarks>
    [Transactional(TransactionMode.TransactionRequired)]
    public void RemoveDenied(Principal principal, IPermission permission, bool checkPermissions)
    {
      if (principal==null)
        throw new ArgumentNullException("principal");
      RemoveDenied(principal.ID,permission,checkPermissions);
    }
    
    internal void RemoveDenied(long pid, IPermission permission, bool checkPermissions)
    {
      if (owner.State==DataObjectState.Removed)
        throw new InstanceIsRemovedException();

      if (checkPermissions)
        CheckChangePermissions(permission);
      else
        CheckCaller();

      PermissionSet ps = (PermissionSet)deniedPermissionSets[pid];
      if (ps==null) {
        owner.FieldContentChanging(this);
        return;
      }

      TransactionController tc = owner.session.CreateTransactionController( TransactionMode.TransactionRequired);
      AllowChange = true;
      try {
        ps.Subtract(permission);
        tc.Commit();
      }
      catch (Exception e) {
        tc.Rollback(e);
        throw;
      }
      finally {
        AllowChange = false;
      }
    }
  
    /// <summary>
    /// Removes the permission from the principal's denied permissions set.
    /// <seealso cref="Allow"/>
    /// <seealso cref="RemoveAllowed"/>
    /// <seealso cref="Deny"/>
    /// </summary>
    /// <param name="principal">Principal to remove the permission for.</param>
    /// <param name="permission">Permission to remove (<see cref="IPermissionSet"/> is allowed here).</param>
    /// <remarks>
    /// <para>
    /// When permissions for this action are checked, the following permission
    /// <see cref="DataObject.Demand"/>s occur:
    /// <see cref="ChangePermissionsPermission"/>.
    /// Additionally all permissions that will be changed are demanded
    /// too - this means that any <see cref="User"/> can change (<see cref="Allow"/>\
    /// <see cref="Deny"/>\<see cref="ResetPermissions"/>) only those
    /// permissions that are allowed for himself.
    /// </para>
    /// </remarks>
    public void RemoveDenied(Principal principal, IPermission permission)
    {
      RemoveDenied(principal, permission, true);
    }
    
    /// <summary>
    /// Removes all permissions that was granted or denied for a 
    /// particular <paramref name="principal"/> from the current
    /// <see cref="DataObject"/> instance.
    /// </summary>
    /// <param name="principal">Principal to remove permissions for. 
    /// <see langword="Null"/>, if all permissions for all principals should 
    /// be removed.</param>
    /// <param name="checkPermissions"><see langword="True"/> if permissions for this action should be checked;
    /// otherwise, <see langword="false"/>.</param>
    /// <remarks>
    /// <para>
    /// Any non-<see cref="DataObject"/> and non-<see cref="DataService"/>
    /// caller should set <paramref name="checkPermissions"/> parameter 
    /// to <see langword="true"/> - otherwise a <see cref="SecurityException"/> 
    /// will be thrown.
    /// </para>
    /// <para>
    /// When permissions for this action are checked, the following permission
    /// <see cref="DataObject.Demand"/>s occur:
    /// <see cref="ChangePermissionsPermission"/>.
    /// Additionally all permissions that will be changed are demanded
    /// too - this means that any <see cref="User"/> can change (<see cref="Allow"/>\
    /// <see cref="Deny"/>\<see cref="ResetPermissions"/>) only those
    /// permissions that are allowed for himself.
    /// </para>
    /// </remarks>
    [Transactional(TransactionMode.TransactionRequired)]
    public void ResetPermissions(Principal principal, bool checkPermissions)
    {
      // Automatic Transactions support code
      TransactionController tc = owner.session.CreateTransactionController( TransactionMode.ExistingTransactionRequired);
    Reprocess:
      try {
        InnerResetPermissions(principal, checkPermissions);
        tc.Commit();
      }
      catch (Exception e) {
        if (tc.Rollback(e, true))
          goto Reprocess;             
        throw;
      }
    }
    private void InnerResetPermissions(Principal principal, bool checkPermissions)
    {
      if (owner.State==DataObjectState.Removed)
        throw new InstanceIsRemovedException();

      if (principal==null) {
        object[] aPrincipals = new object[principals.Count];
        principals.Keys.CopyTo(aPrincipals, 0);
        foreach (long pid in aPrincipals) {
          Principal p = (Principal)owner.session[pid];
          PermissionSet ps = (PermissionSet)allowedPermissionSets[pid];
          if (ps!=null) {
            PermissionSet psCopy = ps.Copy();
            RemoveAllowed(pid, psCopy, checkPermissions);
          }
          ps = (PermissionSet)deniedPermissionSets[pid];
          if (ps!=null) {
            PermissionSet psCopy = ps.Copy();
            RemoveDenied(pid, psCopy, checkPermissions);
          }
        }
      }
      else {
        long pid = principal.ID;
        PermissionSet ps = (PermissionSet)allowedPermissionSets[pid];
        if (ps!=null) {
          PermissionSet psCopy = ps.Copy();
          RemoveAllowed(principal, psCopy, checkPermissions);
        }
        ps = (PermissionSet)deniedPermissionSets[pid];
        if (ps!=null) {
          PermissionSet psCopy = ps.Copy();
          RemoveDenied(principal, psCopy, checkPermissions);
        }
      }
    }
    
    /// <summary>
    /// Removes all permissions that was granted or denied for a 
    /// particular <paramref name="principal"/> from the current
    /// <see cref="DataObject"/> instance.
    /// </summary>
    /// <param name="principal">Principal to remove permissions for. 
    /// <see langword="Null"/>, if all permissions for all principals should 
    /// be removed.</param>
    /// <remarks>
    /// <para>
    /// When permissions for this action are checked, the following permission
    /// <see cref="DataObject.Demand"/>s occur:
    /// <see cref="ChangePermissionsPermission"/>.
    /// Additionally all permissions that will be changed are demanded
    /// too - this means that any <see cref="User"/> can change (<see cref="Allow"/>\
    /// <see cref="Deny"/>\<see cref="ResetPermissions"/>) only those
    /// permissions that are allowed for himself.
    /// </para>
    /// </remarks>
    public void ResetPermissions(Principal principal)
    {
      ResetPermissions(principal, true);
    }
    
    /// <summary>
    /// Removes all permissions from the current
    /// <see cref="DataObject"/> instance.
    /// </summary>
    /// <param name="checkPermissions"><see langword="True"/> if permissions for this action should be checked;
    /// otherwise, <see langword="false"/>.</param>
    /// <remarks>
    /// <para>
    /// Any non-<see cref="DataObject"/> and non-<see cref="DataService"/>
    /// caller should set <paramref name="checkPermissions"/> parameter 
    /// to <see langword="true"/> - otherwise a <see cref="SecurityException"/> 
    /// will be thrown.
    /// </para>
    /// <para>
    /// When permissions for this action are checked, the following permission
    /// <see cref="DataObject.Demand"/>s occur:
    /// <see cref="ChangePermissionsPermission"/>.
    /// Additionally all permissions that will be changed are demanded
    /// too - this means that any <see cref="User"/> can change (<see cref="Allow"/>\
    /// <see cref="Deny"/>\<see cref="ResetPermissions"/>) only those
    /// permissions that are allowed for himself.
    /// </para>
    /// </remarks>
    public void ResetPermissions(bool checkPermissions)
    {
      ResetPermissions(null, checkPermissions);
    }
    
    /// <summary>
    /// Removes all permissions from the current
    /// <see cref="DataObject"/> instance.
    /// </summary>
    /// <remarks>
    /// <para>
    /// When permissions for this action are checked, the following permission
    /// <see cref="DataObject.Demand"/>s occur:
    /// <see cref="ChangePermissionsPermission"/>.
    /// Additionally all permissions that will be changed are demanded
    /// too - this means that any <see cref="User"/> can change (<see cref="Allow"/>\
    /// <see cref="Deny"/>\<see cref="ResetPermissions"/>) only those
    /// permissions that are allowed for himself.
    /// </para>
    /// </remarks>
    public void ResetPermissions()
    {
      ResetPermissions(null, true);
    }
    
    /// <summary>
    /// Removes all permissions that was granted or denied for a 
    /// particular <paramref name="principal"/> from the 
    /// <see cref="DataObject.SecurityChildren"/> objects recursively.
    /// </summary>
    /// <param name="principal">Principal to remove permissions for. 
    /// <see langword="Null"/>, if all permissions for all principals should 
    /// be removed.</param>
    /// <param name="checkPermissions"><see langword="True"/> if permissions for this action should be checked;
    /// otherwise, <see langword="false"/>.</param>
    /// <remarks>
    /// <para>
    /// Any non-<see cref="DataObject"/> and non-<see cref="DataService"/>
    /// caller should set <paramref name="checkPermissions"/> parameter 
    /// to <see langword="true"/> - otherwise a <see cref="SecurityException"/> 
    /// will be thrown.
    /// </para>
    /// <para>
    /// When permissions for this action are checked, the following permission
    /// <see cref="DataObject.Demand"/>s occur:
    /// <see cref="ChangePermissionsPermission"/>.
    /// Additionally all permissions that will be changed are demanded
    /// too - this means that any <see cref="User"/> can change (<see cref="Allow"/>\
    /// <see cref="Deny"/>\<see cref="ResetPermissions"/>) only those
    /// permissions that are allowed for himself.
    /// </para>
    /// </remarks>
    [Transactional(TransactionMode.TransactionRequired)]
    public void ResetChildrenPermissions(Principal principal, bool checkPermissions)
    {
      // Automatic Transactions support code
      TransactionController tc = owner.session.CreateTransactionController( TransactionMode.ExistingTransactionRequired);
    Reprocess:
      try {
        InnerResetChildrenPermissions(principal, checkPermissions);
        tc.Commit();
      }
      catch (Exception e) {
        if (tc.Rollback(e, true))
          goto Reprocess;             
        throw;
      }
    }
    private void InnerResetChildrenPermissions(Principal principal, bool checkPermissions)
    {
      QueryResult children = owner.SecurityChildren;
      if (children!=null) {
        foreach (DataObject child in children)
          child.permissions.InnerResetChildrenPermissions(principal, checkPermissions);
      }
      InnerResetPermissions(principal, checkPermissions);
    }
    
    /// <summary>
    /// Removes all permissions that was granted or denied for a 
    /// particular <paramref name="principal"/> from the 
    /// <see cref="DataObject.SecurityChildren"/> objects recursively.
    /// </summary>
    /// <param name="principal">Principal to remove permissions for. 
    /// <see langword="Null"/>, if all permissions for all principals should 
    /// be removed.</param>
    /// <remarks>
    /// <para>
    /// When permissions for this action are checked, the following permission
    /// <see cref="DataObject.Demand"/>s occur:
    /// <see cref="ChangePermissionsPermission"/>.
    /// Additionally all permissions that will be changed are demanded
    /// too - this means that any <see cref="User"/> can change (<see cref="Allow"/>\
    /// <see cref="Deny"/>\<see cref="ResetPermissions"/>) only those
    /// permissions that are allowed for himself.
    /// </para>
    /// </remarks>
    public void ResetChildrenPermissions(Principal principal)
    {
      ResetChildrenPermissions(principal, true);
    }

    /// <summary>
    /// Removes all permissions from the <see cref="DataObject.SecurityChildren"/> 
    /// objects recursively.
    /// </summary>
    /// <param name="checkPermissions"><see langword="True"/> if permissions for this action should be checked;
    /// otherwise, <see langword="false"/>.</param>
    /// <remarks>
    /// <para>
    /// Any non-<see cref="DataObject"/> and non-<see cref="DataService"/>
    /// caller should set <paramref name="checkPermissions"/> parameter 
    /// to <see langword="true"/> - otherwise a <see cref="SecurityException"/> 
    /// will be thrown.
    /// </para>
    /// <para>
    /// When permissions for this action are checked, the following permission
    /// <see cref="DataObject.Demand"/>s occur:
    /// <see cref="ChangePermissionsPermission"/>.
    /// Additionally all permissions that will be changed are demanded
    /// too - this means that any <see cref="User"/> can change (<see cref="Allow"/>\
    /// <see cref="Deny"/>\<see cref="ResetPermissions"/>) only those
    /// permissions that are allowed for himself.
    /// </para>
    /// </remarks>
    public void ResetChildrenPermissions(bool checkPermissions)
    {
      ResetChildrenPermissions(null, checkPermissions);
    }
    
    /// <summary>
    /// Removes all permissions from the <see cref="DataObject.SecurityChildren"/>
    /// objects recursively.
    /// </summary>
    /// <remarks>
    /// <para>
    /// When permissions for this action are checked, the following permission
    /// <see cref="DataObject.Demand"/>s occur:
    /// <see cref="ChangePermissionsPermission"/>.
    /// Additionally all permissions that will be changed are demanded
    /// too - this means that any <see cref="User"/> can change (<see cref="Allow"/>\
    /// <see cref="Deny"/>\<see cref="ResetPermissions"/>) only those
    /// permissions that are allowed for himself.
    /// </para>
    /// </remarks>
    public void ResetChildrenPermissions()
    {
      ResetChildrenPermissions(null, true);
    }

    /// <summary>
    /// Checks if the permission is allowed.
    /// <seealso cref="SessionBoundObject.DisableSecurity"/>
    /// <seealso cref="SessionBoundObject.EnableSecurity"/>
    /// <seealso cref="DataObjects.NET.Security.Permissions"/>
    /// </summary>
    /// <param name="permission">Permission that should be checked.</param>
    /// <returns><see langword="True"/> if the permission is allowed; 
    /// otherwise, <see langword="false"/>.</returns>
    /// <remarks>
    /// <note type="note">It's not always required that checked permission
    /// should be directly allowed (i.e. contained in the effective permission 
    /// set. 
    /// E.g. <see cref="ReadPermission"/> will be allowed indirectly, if one 
    /// of the following permissions is allowed: <see cref="ChangePermission"/>, 
    /// <see cref="OwnerPermission"/>, <see cref="AdministrationPermission"/>. 
    /// See 
    /// <see cref="IPermission.GrantedIfGrantedAnyOf">IPermission.GrantedIfGrantedAnyOf</see> 
    /// property description for additional information.
    /// </note>
    /// </remarks>
    internal bool IsAllowed(IPermission permission)
    {
      if (owner.State==DataObjectState.Removed)
        throw new InstanceIsRemovedException();

      if (permission==null) {
        return true;
      }
      else {
        Session session = owner.session;
        User    user    = session.user;
        if (!session.IsSecurityEnabled || owner.serializationInfo!=null)
          return true;
        UpdatePermissionCache();
        if (permission is IPermissionSet) {
          foreach (IPermission p in (IPermissionSet)permission) {
            if (cachedPermissions[p]==PermissionStatus.Denied)
              return false;
            if (deniedPermissions.IsSupersetOf(p)) {
              if (cachedPermissions.Count>MaxCachedPermissions)
                cachedPermissions.Clear();
              cachedPermissions[p] = PermissionStatus.Denied;
              return false;
            }
          }
          if (effectivePermissions.IsSupersetOf(AdministrationPermission.Value))
            return true;
          foreach (IPermission p in (IPermissionSet)permission) {
            if (cachedPermissions[p]==PermissionStatus.Allowed)
              continue;
            if (effectivePermissions.IsSupersetOf(p)) {
              if (cachedPermissions.Count>MaxCachedPermissions)
                cachedPermissions.Clear();
              cachedPermissions[p] = PermissionStatus.Allowed;
              continue;
            }
            else {
              ReadOnlyPermissionCollection gigList = p.GrantedIfGrantedAnyOf;
              if (gigList==null)
                return false;
              int cnt = gigList.Count;
              bool oneAllowed = false;
              for (int i = 0; i<cnt; i++) {
                if (effectivePermissions.IsSupersetOf(gigList[i])) {
                  if (cachedPermissions.Count>MaxCachedPermissions)
                    cachedPermissions.Clear();
                  cachedPermissions[p] = PermissionStatus.Allowed;
                  //cachedAllowedPermissions[gigList[i]] = this;
                  oneAllowed = true;
                  break;
                }
              }
              if (!oneAllowed)
                return false;
              continue;
            }
          }
          return true;
        }
        else {
          if (cachedPermissions[permission]==PermissionStatus.Denied)
            return false;
          if (deniedPermissions.IsSupersetOf(permission)) {
            if (cachedPermissions.Count>MaxCachedPermissions)
              cachedPermissions.Clear();
            cachedPermissions[permission] = PermissionStatus.Denied;
            return false;
          }
          if (cachedPermissions[permission]==PermissionStatus.Allowed)
            return true;
          if (effectivePermissions.IsSupersetOf(permission)) {
            if (cachedPermissions.Count>MaxCachedPermissions)
              cachedPermissions.Clear();
            cachedPermissions[permission] = PermissionStatus.Allowed;
            return true;
          }
          else {
            if (effectivePermissions.IsSupersetOf(AdministrationPermission.Value)) {
              if (cachedPermissions.Count>MaxCachedPermissions)
                cachedPermissions.Clear();
              cachedPermissions[permission] = PermissionStatus.Allowed;
              return true;
            }
            ReadOnlyPermissionCollection gigList = permission.GrantedIfGrantedAnyOf;
            if (gigList==null)
              return false;
            int cnt = gigList.Count;
            for (int i = 0; i<cnt; i++) {
              if (effectivePermissions.IsSupersetOf(gigList[i])) {
                if (cachedPermissions.Count>MaxCachedPermissions)
                  cachedPermissions.Clear();
                cachedPermissions[permission] = PermissionStatus.Allowed;
                //cachedPermissions[gigList[i]] = true;
                return true;
              }
            }
            return false;
          }
        }
      }
    }
    
    // Private members

    private static readonly Role[] nullRoles = new Role[0];
    private void UpdatePermissionCache()
    {
    Repeat:
      if (effectivePermissionsTransactionContext==owner.transactionContext)
        return;
      if (effectivePermissionsTransactionContext==null) {
        securityParent = null;
        goto UpdateSecurityParent;
      }
      switch (effectivePermissionsTransactionContext.State) {
      case TransactionContextState.Valid:
        effectivePermissionsTransactionContext = owner.transactionContext;
        return;
      case TransactionContextState.Dirty:
        securityParent = null;
        goto UpdateSecurityParent;
      }
      
      if (securityParent!=null)
        goto SecurityParentIsOK;

    UpdateSecurityParent:
      // Bad... We should update the whole permission cache
      DataObject sp = owner.SecurityParent;
      if (sp==null) {
        if (owner is ISecurityRoot)
          sp = owner;
        else {
          string sId = "[Unknown]";
          try {
            sId = owner.ID.ToString();
          } catch {}
          throw new SecurityException(String.Format(
            "Can't acquire inherited permissions: " +
            "SecurityParent of instance with ID={0} is null, " +
            "and this instance isn't an ISecurityRoot.", sId));
        }
      }
      securityParent = sp;
      if (sp!=owner && sp!=subscribedSecurityParent) {
        if (sp.permissionsChangedEventSource==null)
          sp.permissionsChangedEventSource = new Helpers.EventSource();
        sp.permissionsChangedEventSource.Subscribe(owner.PermissionsChangedCallbackEventHandler);
        subscribedSecurityParent = sp;
      }
        
    SecurityParentIsOK:
      DataObject currentSecurityParent = securityParent;
      AccessControlList securityParentPermissions = currentSecurityParent.permissions;
      try {
        while (securityParentPermissions==null) {
          if (currentSecurityParent is ISecurityRoot)
            throw new SecurityException(
              "Can't acquire inherited permissions: " +
              "SecurityRoot object has no AccessControlList.");
          if (currentSecurityParent==null) {
            string sId = "[Unknown]";
            try {
              sId = owner.ID.ToString();
            } catch {}
            throw new SecurityException(String.Format(
              "Can't acquire inherited permissions: " +
              "SecurityParent of instance with ID={0} is null, " +
              "and this instance isn't an ISecurityRoot.", sId));
          }
          if (currentSecurityParent.State==DataObjectState.Removed) {
            string sId = "[Unknown]";
            try {
              sId = owner.ID.ToString();
            } catch {}
            throw new SecurityException(String.Format(
              "Can't acquire inherited permissions: " +
              "SecurityParent of instance with ID={0} is removed object.", sId));
          }
          currentSecurityParent = currentSecurityParent.SecurityParent;
          securityParentPermissions = currentSecurityParent.permissions;
        }
        if (currentSecurityParent!=owner) {
          // Let's check the State of the SecurityParent, also this check
          // will reload it, if this is necessary...
          if (currentSecurityParent.State==DataObjectState.Removed) {
            string sId = "[Unknown]";
            try {
              sId = owner.ID.ToString();
            } catch {}
            throw new SecurityException(String.Format(
              "Can't acquire inherited permissions: " +
              "SecurityParent of instance with ID={0} is removed object.", sId));
          }
          securityParentPermissions.UpdatePermissionCache();
        }
      }
      catch {
        securityParent = null;
        throw;
      }

      // Let's produce Allowed-Denied permission sets for
      // the current user on the current object.
      Session session   = owner.session;
      Domain  domain    = session.domain;
      User    user      = session.user;
      Role[]  allRoles  = user==null? nullRoles : user.InternalAllRoles;
      PermissionSet aps = null;
      PermissionSet dps = null;
      int cnt = allRoles.Length;
      for (int i = 0; i<cnt; i++) {
        long id = allRoles[i].ID;
        PermissionSet cps = (PermissionSet)allowedPermissionSets[id];
        if (cps!=null) {
          if (aps==null)
            aps = new PermissionSet(cps);
          else
            aps.Union(cps);
        }
        cps = (PermissionSet)deniedPermissionSets[id];
        if (cps!=null) {
          if (dps==null)
            dps = new PermissionSet(cps);
          else
            dps.Union(cps);
        }
      }
      if (user != null)
      {
        long id = user.ID;
        PermissionSet cps = (PermissionSet)allowedPermissionSets[id];
        if (cps!=null) {
          if (aps==null)
            aps = new PermissionSet(cps);
          else
            aps.Union(cps);
        }
        cps = (PermissionSet)deniedPermissionSets[id];
        if (cps!=null) {
          if (dps==null)
            dps = new PermissionSet(cps);
          else
            dps.Union(cps);
        }
      }
      
      if (securityParent!=owner && Inherit) {
        // This is not a SecurityRoot
        switch (domain.SecurityMode) {
        case DomainSecurityMode.InheritedDenyWinsExplicitAllow:
        case DomainSecurityMode.InheritedDenyWinsExplicitAllow | DomainSecurityMode.AllowNotInheritPermissions:
          if (aps!=null)
            aps.Union(securityParentPermissions.allowedPermissions);
          else
            aps = securityParentPermissions.allowedPermissions;
          if (dps!=null)
            dps.Union(securityParentPermissions.deniedPermissions);
          else
            dps = securityParentPermissions.deniedPermissions;
          if (aps==securityParentPermissions.allowedPermissions && 
              dps==securityParentPermissions.deniedPermissions)
            effectivePermissions = securityParentPermissions.effectivePermissions;
          else {
            effectivePermissions = new PermissionSet(aps);
            effectivePermissions.Subtract(dps);
          }
          break;
        case DomainSecurityMode.ExplicitAllowOrDenyWinsInheritedAllowOrDeny:
        case DomainSecurityMode.ExplicitAllowOrDenyWinsInheritedAllowOrDeny | DomainSecurityMode.AllowNotInheritPermissions:
          if (aps!=null) {
            PermissionSet newDps = new PermissionSet(securityParentPermissions.deniedPermissions);
            newDps.Subtract(aps);
            if (dps!=null)
              dps.Union(newDps);
            else
              dps = newDps;
            aps.Union(securityParentPermissions.allowedPermissions);
          }
          else {
            aps = securityParentPermissions.allowedPermissions;
            if (dps!=null)
              dps.Union(securityParentPermissions.deniedPermissions);
            else
              dps = securityParentPermissions.deniedPermissions;
          }
          if (aps==securityParentPermissions.allowedPermissions && 
              dps==securityParentPermissions.deniedPermissions)
            effectivePermissions = securityParentPermissions.effectivePermissions;
          else {
            effectivePermissions = new PermissionSet(aps);
            effectivePermissions.Subtract(dps);
          }
          break;
        default:
          throw new InvalidOperationException("Unknown Domain.SecurityMode value.");
        }
      }
      else {
        // This is a SecurityRoot
        if (aps==null)
          aps = new PermissionSet();
        if (dps==null)
          dps = new PermissionSet();
        effectivePermissions = new PermissionSet(aps);
        effectivePermissions.Subtract(dps);
      }
      allowedPermissions = aps;
      deniedPermissions  = dps;
      cachedPermissions.Clear();
      effectivePermissionsTransactionContext = owner.transactionContext;
    }
    
    internal void ConvertToRemovedPermissionCache()
    {
      securityParent       = null;
      allowedPermissions   = new PermissionSet();
      deniedPermissions    = allowedPermissions;
      effectivePermissions = allowedPermissions;
      effectivePermissionsTransactionContext = null;
      cachedPermissions.Clear();
    }

    private void CheckChangePermissions(IPermission permission)
    {
      owner.Demand(ChangePermissionsPermission.Value);
      if (permission!=ChangePermissionsPermission.Value)
        owner.Demand(permission);
    }
    
    private void CheckCaller()
    {
      StackTrace st = new StackTrace(0, false);
      StackFrame sf = null;
      MethodBase mb = null;
      System.Type t = null;
      Assembly   a  = null;

      int cnt = st.FrameCount;
      int skipFrames = -1;
      for (int i = 0; i<cnt; i++) {
        sf = st.GetFrame(i);
        mb = sf.GetMethod();
        t  = mb.ReflectedType;
        if (t!=typeof(AccessControlList)) {
          a  = t.Assembly;
          skipFrames = i;
          break;
        }
      }

      if (skipFrames<0)
        throw new SecurityException("Stack check error.");
      
      Session session = owner.session;
      if (a!=session.proxyAssembly && a!=session.doAssembly && !session.IsTypeTransactional(t))
        throw new SecurityException(
          "This method\\property can be invoked only from DataObjects.NET assembly, " +
          "proxy assembly and DataObject\\DataService methods.");
    }


    // Events
    
    /// <summary>
    /// Called before any changes are made in the collection.
    /// </summary>
    /// <param name="permissionSet">Changing permission set.</param>
    internal void OnChanging(AccessControlListPermissionSet permissionSet)
    {
      if (!AllowChange)
        throw new SecurityException(
          "This way of changing AccessControlListPermissionSet instance isn't allowed. " +
          "Use AccessControlList Allow\\Deny\\RemoveAllowed\\RemoveDenied methods instead.");
       
      AllowChange = false;
      owner.FieldContentChanging(this);
    }

    /// <summary>
    /// Called after some changes were made in collection.
    /// </summary>
    /// <param name="permissionSet">Changed permission set.</param>
    internal void OnChanged(AccessControlListPermissionSet permissionSet)
    {
      if (permissionSet!=null) {
        // We should optimize this stuff first
        long pid = permissionSet.principalID;
        if (permissionSet.Count==0) {
          if (permissionSet.isAllowedSet) {
            if (deniedPermissionSets[pid]==null) {
              deniedPermissionSets.Remove(pid);
              principals.Remove(pid);
            }
            allowedPermissionSets.Remove(pid);
          }
          else {
            if (allowedPermissionSets[pid]==null) {
              allowedPermissionSets.Remove(pid);
              principals.Remove(pid);
            }
            deniedPermissionSets.Remove(pid);
          }
        }
      }
      owner.FieldContentChanged(this);
    }
    
    internal void CopyFrom(AccessControlList source)
    {
      stateFlags = source.stateFlags;
      stateFlags[AllowChangeMask] = false;
      principals = source.principals;
      allowedPermissionSets = source.allowedPermissionSets;
      foreach (AccessControlListPermissionSet ps in allowedPermissionSets.Values)
        ps.owner = this;
      deniedPermissionSets  = source.deniedPermissionSets;
      foreach (AccessControlListPermissionSet ps in deniedPermissionSets.Values)
        ps.owner = this;
      effectivePermissionsTransactionContext = null;
      effectivePermissions = null;
      securityParent = null;
    }
    
    /// <summary>
    /// Returns <see cref="String"/> representation of current instance.
    /// </summary>
    /// <returns>The <see cref="String"/> representation of this instance.</returns>
    [Transactional(TransactionMode.TransactionRequired | TransactionMode.SupportsOfflineMode)]
    public override string ToString()
    {
      if (owner.session.IsOfflineMode) 
        return InnerToString();

      // Automatic Transactions support code
      TransactionController tc = owner.session.CreateTransactionController( TransactionMode.TransactionRequired);
    Reprocess:
      try {
        string r = InnerToString();
        tc.Commit();
        return r;
      }
      catch (Exception e) {
        if (tc.Rollback(e, true))
          goto Reprocess;             
        throw;
      }
    }
    private string InnerToString()
    {
      if (owner.State==DataObjectState.Removed)
        throw new InstanceIsRemovedException();

      PermissionSet eps = GetEffectivePermissionSet();
      StringBuilder sb = new StringBuilder();
      sb.Append("Inherit: "+Inherit.ToString()+"; ");
      foreach (long pid in principals.Keys) {
        Principal p = (Principal)owner.session[pid];
        sb.Append(String.Format(
          "Principal {0}:\r\n", p));
        PermissionSet aps = GetAllowedPermissionSet(p);
        if (aps!=null)
          sb.Append(String.Format(
            "  Allowed: {0}\r\n", aps));
        PermissionSet dps = GetDeniedPermissionSet(p);
        if (dps!=null)
          sb.Append(String.Format(
            "  Denied:  {0}\r\n", dps));
      }
      if (eps!=null)
        sb.Append(String.Format(
          "Effective permission set: {0}", eps));
      else
        sb.Append(String.Format(
          "Effective permission set currently is not available.", eps));
      return sb.ToString();
    }


    // Constructors
  
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    internal AccessControlList()
    {
    }
    
    // Serialization support
    
    /// <summary>
    /// Serializer.
    /// </summary>
    /// <param name="info"><see cref="SerializationInfo"/> object.</param>
    /// <param name="context"><see cref="StreamingContext"/> object.</param>
    [Transactional(TransactionMode.TransactionRequired | TransactionMode.SupportsOfflineMode)]
    public void GetObjectData(SerializationInfo info, StreamingContext context)
    {
      if (owner.session.IsOfflineMode) {
        InnerGetObjectData(info, context);
        return;
      }

      // Automatic Transactions support code
      TransactionController tc = owner.session.CreateTransactionController( TransactionMode.TransactionRequired);
    Reprocess:
      try {
        InnerGetObjectData(info, context);
        tc.Commit();
      }
      catch (Exception e) {
        if (tc.Rollback(e, true))
          goto Reprocess;             
        throw;
      }
    }
    private void InnerGetObjectData(SerializationInfo info, StreamingContext context)
    {
      if (owner.State==DataObjectState.Removed)
        throw new InstanceIsRemovedException();

      int cnt = principals.Count;
      // info.AddValue("Owner-ID",owner.ID);
      info.AddValue("Inherit", InternalInherit);
      info.AddValue("Principals-Count",principals.Count);
      int i = 0;
      foreach (long pid in principals.Keys) {
        string pfx = "Principal-"+(i++).ToString();
        DataObject principal = owner.session[pid];
        info.AddValue(pfx,principal);
        info.AddValue(pfx+"-Allowed",allowedPermissionSets[pid]);
        info.AddValue(pfx+"-Denied",deniedPermissionSets[pid]);
      }
    }

    /// <summary>
    /// Deserialization constructor.
    /// </summary>
    /// <param name="info"><see cref="SerializationInfo"/> object.</param>
    /// <param name="context"><see cref="StreamingContext"/> object.</param>
    private AccessControlList(SerializationInfo info, StreamingContext context)
    {
      stateFlags = new BitVector32(0);
      serializationInfo = info;
    }
    
    void IDeserializationCallback.OnDeserialization(object sender)
    {
      if (serializationInfo==null) {
        if (session==null)
          throw new SerializationException("OnDeserialization method can't be called manually.");
        // DataObjects.NET 2.0.2 format, here we only should
        // check if all principals are valid.
        try {
          int cnt = principals.Count;
          long[] pids = new long[cnt];
          principals.Keys.CopyTo(pids,0);
          session.Preload(pids);
          for (int i = 0; i<cnt; i++) {
            long pid = pids[i];
            Principal principal = null;
            try {
              principal = session[pid] as Principal;
            }
            catch {}
            if (principal==null || principal.State==DataObjectState.Removed) {
              Inconsistent = true;
              principals.Remove(pid);
              allowedPermissionSets.Remove(pid);
              deniedPermissionSets.Remove(pid);
            }
          }
        }
        catch (SerializationException) {
          Inconsistent = true;
        }
        session = null;
        return;
      }
      SerializationInfo info = serializationInfo;
      serializationInfo = null;
      InternalInherit = true;
      principals = new Hashtable();
      allowedPermissionSets = new Hashtable();
      deniedPermissionSets  = new Hashtable();
      cachedPermissions =  new ListDictionary();
      try {
        // We use this way to check if new "Inherit" element
        // exists in serializationInfo without exceptions.
        SerializationInfoEnumerator e = info.GetEnumerator();
        e.MoveNext();
        if (e.Current.Name=="Inherit") {
          try {
            InternalInherit = info.GetBoolean("Inherit");
          }
          catch {
            Inconsistent = true;
          }
        }
        else
          Inconsistent = true;
        // long hid = info.GetInt64("Owner-ID");
        int  cnt = info.GetInt32("Principals-Count");
        for (int i = 0; i<cnt; i++) {
          try {
            string pfx = "Principal-"+i.ToString();
            Principal principal = info.GetValue(pfx,typeof(Principal)) as Principal;
            if (principal==null || principal.State==DataObjectState.Removed) {
              Inconsistent = true;
              continue;
            }
            long pid = principal.ID;
            AccessControlListPermissionSet aps = 
              info.GetValue(pfx+"-Allowed",typeof(object)) as AccessControlListPermissionSet;
            AccessControlListPermissionSet dps = 
              info.GetValue(pfx+"-Denied",typeof(object)) as AccessControlListPermissionSet;
            if (aps!=null && aps.Count==0)
              aps = null;
            if (dps!=null && dps.Count==0)
              dps = null;
            if (aps!=null || dps!=null) {
              principals[pid] = this;
              if (aps!=null) {
                aps.owner = this;
                aps.principalID = pid;
                aps.isAllowedSet = true;
                allowedPermissionSets[pid] = aps;
              }
              if (dps!=null) {
                dps.owner = this;
                dps.principalID = pid;
                dps.isAllowedSet = false;
                deniedPermissionSets[pid] = dps;
              }
            }
          } 
          catch (SerializationException) {
            Inconsistent = true;
          };
        }
      }
      catch {
        Inconsistent = true;
      }
    }
  }
}
