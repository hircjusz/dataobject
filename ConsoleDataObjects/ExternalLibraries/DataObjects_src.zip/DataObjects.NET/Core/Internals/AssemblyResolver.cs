// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;
using System.Reflection;

namespace DataObjects.NET.Internals
{
  internal class AssemblyResolver
  {
    private bool      eventHandlerRegistered    = false;
    private Hashtable assemblyResolveCache = new Hashtable();
    private Domain    domain;
    
    private Assembly CurrentDomain_AssemblyResolve(
      object sender,
      ResolveEventArgs args) 
    {
      Assembly result = (Assembly)assemblyResolveCache[args.Name];
      if (result==null) {
        string[] fnParts = args.Name.Split(new char[] {','});
        if (fnParts[0]=="DataObjects.NET")
          result = typeof(AssemblyResolver).Assembly;
        else {
          foreach(Assembly asm in AppDomain.CurrentDomain.GetAssemblies())
            if (asm.FullName==args.Name) {
              result = asm;
              break;
            }
          if (domain!=null && result==null && fnParts[0].StartsWith("DataObjects.NET"))
        #if MONO
            result = AssemblyUtils.LoadDriverAssembly(fnParts[0], domain.ProxyAssemblyCacheFolder);
        #else
            result = AssemblyUtils.LoadDriverAssembly(fnParts[0], null);
        #endif
        }
        if (result!=null)
          assemblyResolveCache[args.Name] = result;
      }
      return result;
    }

    public void RegisterEventHandler()
    {
      if (!eventHandlerRegistered) {
        AppDomain.CurrentDomain.AssemblyResolve += new ResolveEventHandler(CurrentDomain_AssemblyResolve);
        eventHandlerRegistered = true;
      }
    }

    public void AddAssembly(string assemblyName, Assembly assembly)
    {
      assemblyResolveCache[assemblyName] = assembly;
    }

    public bool EventHandlerRegistered {
      get {
        return eventHandlerRegistered;  
      }
    }

    public AssemblyResolver(Domain domain)
    {
      this.domain = domain;
    }
  }
}
