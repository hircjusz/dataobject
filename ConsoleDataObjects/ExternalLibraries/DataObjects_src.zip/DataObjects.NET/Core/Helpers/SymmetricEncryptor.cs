// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.IO;
using System.Security.Cryptography;
using DataObjects.NET.Attributes;
using Offline=DataObjects.NET.Offline;

namespace DataObjects.NET.Helpers
{
  /// <summary>
  /// A <see cref="IPropertyStorageValueModifier">property storage value modifier</see> that
  /// encrypts internal property value before
  /// persisting it to the database and decrypts
  /// it back on fetches.
  /// <seealso cref="StorageValueModifierAttribute"/>
  /// </summary>
  /// <remarks>
  /// <see cref="SymmetricEncryptor"/> can be used to encrypt persistent properties
  /// of type <see langword="byte[]"/> (managed by <see cref="DataObjects.NET.ObjectModel.BlobField"/>) 
  /// or of type <see cref="Object"/> (managed by <see cref="DataObjects.NET.ObjectModel.ObjectField"/>).
  /// See <see cref="StorageValueModifierAttribute"/> also.
  /// </remarks>
  [Serializable]
  public class SymmetricEncryptor: IPropertyStorageValueModifier
  {
    #if !MONO
    private SymmetricEncryptionMethod symmetricEncryptionMethod = SymmetricEncryptionMethod.Rijndael;
    #else
    private SymmetricEncryptionMethod symmetricEncryptionMethod = SymmetricEncryptionMethod.None;
    #endif
    /// <summary>
    /// Gets the <see cref="SymmetricEncryptionMethod">method</see> of encryption.
    /// Default value is <see cref="SymmetricEncryptionMethod">SymmetricEncryptionMethod.Rijndael</see>.
    /// </summary>
    public  SymmetricEncryptionMethod SymmetricEncryptionMethod {
      get {
        return symmetricEncryptionMethod;
      }
    }

    private byte[] key;
    /// <summary>
    /// Gets or sets symmetric key (the same for encryption and decryption).
    /// </summary>
    public byte[] Key {
      get {
        return key;
      }
      set {
        key = value;
      }
    }
    
    private byte[] iV;
    /// <summary>
    /// Gets or sets IV (initialization vector).
    /// </summary>
    public byte[] IV {
      get {
        return iV;
      }
      set {
        iV = value;
      }
    }
  
    /// <summary>
    /// Encryptes value that DataObjects.NET is going to persist to
    /// the storage.
    /// </summary>
    /// <param name="session"><see cref="Session"/> where conversion occurs.</param>
    /// <param name="dataObject"><see cref="DataObject"/> for which we  store a property.</param>
    /// <param name="propertyName">Property name.</param>
    /// <param name="culture">Property culture.</param>
    /// <param name="value">Internal value.</param>
    /// <returns>Value to be stored into database.</returns>
    /// <remarks>
    /// <para>
    /// Remember that value passed to this method may differ from
    /// value returned by <see cref="DataObject.GetProperty"/> method.
    /// For example, any <see cref="Object"/> property is stored
    /// as <see cref="Byte"/> <see cref="Array"/>.
    /// </para>
    /// </remarks>
    public object ConvertToStorageValue(Session session, DataObject dataObject, string propertyName, Culture culture, object value)
    {
      return ConvertToStorageValue(value);
    }

    /// <summary>
    /// Decryptes value fetched by DataObjects.NET from the storage.
    /// </summary>
    /// <param name="session"><see cref="Session"/> where conversion occurs.</param>
    /// <param name="dataObject"><see cref="DataObject"/> for which we  load a property value.</param>
    /// <param name="propertyName">Property name.</param>
    /// <param name="culture">Property culture.</param>
    /// <param name="value">Loaded value.</param>
    /// <returns>Value to be stored in <see cref="DataObject"/>.</returns>
    /// <remarks>
    /// <para>
    /// Remember that value passed to this method may differ from
    /// value returned by <see cref="DataObject.GetProperty"/> method.
    /// For example, any <see cref="Object"/> property is stored
    /// as <see cref="Byte"/> <see cref="Array"/>.
    /// </para>
    /// </remarks>
    public object ConvertFromStorageValue(Session session, DataObject dataObject, string propertyName, Culture culture, object value)
    {
      return ConvertFromStorageValue(value);
    }
    
    private SymmetricAlgorithm CreateSymmetricAlgorithm(SymmetricEncryptionMethod method)
    {
      switch (method) {
        case SymmetricEncryptionMethod.Rijndael:
          RijndaelManaged rm = new RijndaelManaged();
          // Visual Studio 2005 beta 2 bug workaround, see 
          // http://www.x-tensive.com/Forum/viewtopic.php?t=700
          rm.Padding = PaddingMode.Zeros;
          return rm;
        case SymmetricEncryptionMethod.DES:
          return(new DESCryptoServiceProvider());
        case SymmetricEncryptionMethod.TripleDES:
          return(new TripleDESCryptoServiceProvider());
        case SymmetricEncryptionMethod.RC2:
          return(new RC2CryptoServiceProvider());
        default:
          throw new InvalidOperationException("Unknown encryption method.");
      }   
    }

    private object ConvertToStorageValue(object value)
    {
    #if !MONO
      byte[] data = (byte[])value;
      if (data==null || data.Length==0)
        return data;
        
      SymmetricEncryptionMethod em = symmetricEncryptionMethod;

      using (MemoryStream ms = new MemoryStream(256)) {
        ms.WriteByte((byte)em);
        switch (em) {
        case SymmetricEncryptionMethod.None:
          ms.Write(data, 0, data.Length);
          break;
        case SymmetricEncryptionMethod.Rijndael:
        case SymmetricEncryptionMethod.DES:
        case SymmetricEncryptionMethod.TripleDES:
        case SymmetricEncryptionMethod.RC2:
          SymmetricAlgorithm algorithm = CreateSymmetricAlgorithm(em);
          CryptoStream cryptoStream = new CryptoStream(ms, 
            algorithm.CreateEncryptor(key, iV), CryptoStreamMode.Write);
          cryptoStream.Write(data, 0, data.Length);
          cryptoStream.Close();
          break;
        default:
          throw new InvalidOperationException("Unknown encryption method.");
        }
        return ms.ToArray();
      }
    #else
      return value;
    #endif
    }
    
    private object ConvertFromStorageValue(object value)
    {
    #if !MONO
      byte[] data = (byte[])value;
      if (data==null || data.Length==0)
        return data;

      SymmetricEncryptionMethod em = symmetricEncryptionMethod;
      try {
        em = (SymmetricEncryptionMethod)data[0];
      }
      catch (Exception e) {
        throw new InvalidOperationException("Unknown encryption method.",e);
      }

      if (key.Length==0)
         key = key;
         
      int len = data.Length-1;
      switch (em) {
      case SymmetricEncryptionMethod.None:
        byte[] ret = new byte[len];
        Array.Copy(data, 1, ret, 0, len);
        return ret;
      case SymmetricEncryptionMethod.Rijndael:
      case SymmetricEncryptionMethod.DES:
      case SymmetricEncryptionMethod.TripleDES:
      case SymmetricEncryptionMethod.RC2:
        using (MemoryStream msIn = new MemoryStream(256)) {
          msIn.Write(data, 1, len);
          msIn.Position = 0;
          SymmetricAlgorithm algorithm = CreateSymmetricAlgorithm(em);
          CryptoStream cryptoStream = new CryptoStream(msIn, 
            algorithm.CreateDecryptor(key, iV), CryptoStreamMode.Read);
          using (MemoryStream msOut = new MemoryStream(256)) {
            int readingBufSize = 1000;  
            byte[] decryptedData = new byte[readingBufSize]; 
            int numBytesRead = 0;
            while (true) {
              int n = cryptoStream.Read(decryptedData, 0, readingBufSize);
              msOut.Write(decryptedData, 0, n);
              numBytesRead += n;
              if (n<readingBufSize)
                break;
            }
            cryptoStream.Close();
            return msOut.ToArray();
          }  
        }
      default:
        throw new InvalidOperationException("Unknown encryption method.");
      }
    #else
      return value;
    #endif
    }
    
    // Constructors

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    public SymmetricEncryptor()
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="symmetricEncryptionMethod">Encryption method.</param>
    /// <param name="key">Encryption key.</param>
    /// <param name="iV">Initialization vector.</param>
    public SymmetricEncryptor(SymmetricEncryptionMethod symmetricEncryptionMethod, byte[] key, byte[] iV)
    {
      this.symmetricEncryptionMethod = symmetricEncryptionMethod;
      this.key = key;
      this.iV = iV;
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="symmetricEncryptionMethod">Encryption method.</param>
    /// <param name="key">Encryption key.</param>
    public SymmetricEncryptor(SymmetricEncryptionMethod symmetricEncryptionMethod, byte[] key):
      this(symmetricEncryptionMethod, key, null)
    {
    }
  }
}
