// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;

namespace DataObjects.NET.Attributes
{
  /// <summary>
  /// Specifies that persistent type or service is abstract.
  /// </summary>
  /// <remarks>
  /// <note>This attribute can be applied to persistent types
  /// (<see cref="DataObject"/> descendants) services
  /// (<see cref="DataService"/> descendants) and collections
  /// (<see cref="DataObjectCollection"/> or 
  /// <see cref="ValueTypeCollection"/> descendants).</note>
  /// This attribute allows to mark a persistent class as abstract.
  /// Note that all DataObjects.NET persistent classes are abstract
  /// in CLR, but nevertheless DataObjects.NET generates a non-abstract 
  /// proxy for each persistent type. This attribute allows to mark
  /// this proxy as abstract CLR class, so it will be impossible to
  /// create an instance of this proxy.
  /// <para>
  /// <example>Example (part of <see cref="DataObjects.NET.Security.Principal"/> code):
  /// <code lang="C#">
  ///  [Abstract] // !!!
  ///  public abstract class Principal: FtObject
  ///  {
  ///    ...
  ///  }
  /// </code>
  /// </example>
  /// </para>
  /// <seealso cref="SealedAttribute"/>
  /// </remarks>
  [AttributeUsage(AttributeTargets.Class, AllowMultiple = false, Inherited = false)]
  [Serializable]
  public class AbstractAttribute: DataObjectAttribute
  {
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    public AbstractAttribute() 
    {
    }
  }

    [AttributeUsage(AttributeTargets.Class, AllowMultiple = false, Inherited = true)]
    [Serializable]
    public class FlatAttribute : DataObjectAttribute
    {
        /// <summary>
        /// Initializes a new instance of this class.
        /// </summary>
        public FlatAttribute()
        {
        }
    }

}
