// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;
using System.Runtime.Serialization;
using DataObjects.NET.Serialization;
using DataObjects.NET.Security;

namespace DataObjects.NET
{
  /// <summary>
  /// Holds miscellaneous serialization-related information
  /// for <see cref="DataObject"/> instance.
  /// </summary>
  internal class DataObjectSerializationInfo
  {
    public Serializer        Serializer;
    public SerializationInfo SerializationInfo;
    public StreamingContext  StreamingContext;
    public AccessControlList DeserializedPermissions;

    
    // Constructors
    
    public DataObjectSerializationInfo()
    {
    }
    
    public DataObjectSerializationInfo(Serializer serializer)
    {
      Serializer        = serializer;
    }

    public DataObjectSerializationInfo(
      Serializer serializer, SerializationInfo info, StreamingContext context)
    {
      Serializer        = serializer;
      SerializationInfo = info;
      StreamingContext  = context;
    }
  }
}
