// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Runtime.Serialization;

namespace DataObjects.NET.Exceptions
{
  /// <summary>
  /// Thrown on any <see cref="IPropertyValueValidator">validation</see> exceptions.
  /// </summary>
  [Serializable]
  public class ValidationException: DataObjectsDotNetException
  {
    private DataObject dataObject;
    private string     propertyName;
    private Culture    culture;
    private IPropertyValueValidator validator;
    
    /// <summary>
    /// Gets <see cref="DataObjects.NET.DataObject"/> instance which property caused
    /// this <see cref="ValidationException"/>.
    /// </summary>
    public DataObject DataObject {
      get {
        return dataObject;
      }
    }
  
    /// <summary>
    /// Gets name of the <see cref="DataObject"/> property that caused
    /// this <see cref="ValidationException"/>.
    /// </summary>
    public string PropertyName {
      get {
        return propertyName;
      }
    }
  
    /// <summary>
    /// Gets <see cref="Culture"/> of the <see cref="DataObject"/> property that caused
    /// this <see cref="ValidationException"/>.
    /// </summary>
    public Culture Culture {
      get {
        return culture;
      }
    }
  
    /// <summary>
    /// Gets <see cref="IPropertyValueValidator"/> instance of the <see cref="DataObject"/> property that caused
    /// this <see cref="ValidationException"/>.
    /// </summary>
    public IPropertyValueValidator Validator {
      get {
        return validator;
      }
    }
  
    /// <summary>
    /// Serializer.
    /// </summary>
    /// <param name="info"><see cref="SerializationInfo"/> object.</param>
    /// <param name="context"><see cref="StreamingContext"/> object.</param>
    public override void GetObjectData(SerializationInfo info, StreamingContext context)
    {
      base.GetObjectData(info,context);
      info.AddValue("DataObject",dataObject);
      info.AddValue("PropertyName",propertyName);
      info.AddValue("Culture",culture);
      info.AddValue("Validator",validator);
    }


    // Constructors

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="dataObject"><see cref="DataObjects.NET.DataObject"/> instance which property caused
    /// this exception.</param>
    /// <param name="propertyName">Name of the <see cref="DataObject"/> property that caused
    /// this exception.</param>
    /// <param name="culture"><see cref="Culture"/> of the <see cref="DataObject"/> property that caused
    /// this exception.</param>
    /// <param name="validator"><see cref="IPropertyValueValidator"/> instance of the <see cref="DataObject"/> property that caused
    /// this exception.</param>
    /// <param name="innerException">Inner exception (an exception that was originally thrown by <paramref name="validator"/>).</param>
    /// <param name="text">Text of message.</param>
    public ValidationException(DataObject dataObject, string propertyName, 
      Culture culture, IPropertyValueValidator validator, 
      string text, Exception innerException): base(text, innerException) 
    {
      this.dataObject = dataObject;
      this.propertyName = propertyName;
      this.culture = culture;
      this.validator = validator;
    }

    /// <summary>
    /// Deserialization constructor.
    /// </summary>
    /// <param name="info"><see cref="SerializationInfo"/> object.</param>
    /// <param name="context"><see cref="StreamingContext"/> object.</param>
    protected ValidationException(SerializationInfo info, StreamingContext context):
      base(info, context)
    {
      dataObject = (DataObject)info.GetValue("DataObject",typeof(DataObject));
      propertyName = info.GetString("PropertyName");
      culture    = (Culture)info.GetValue("Culture",typeof(Culture));
      validator  = (IPropertyValueValidator)info.GetValue("Validator",typeof(object));
    }
  }
}
