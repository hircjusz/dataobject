// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using DataObjects.NET;
using DataObjects.NET.Data;

namespace DataObjects.NET.Data
{
  /// <summary>
  /// Represents a method that will handle the 
  /// <see cref="Adapter.BeforeRemoveObject"/> events.
  /// </summary>
  /// <param name="sender">The source of the event.</param>
  /// <param name="e">An <see cref="BeforeRemoveObjectEventArgs"/> that contains the event data.</param>
  /// <remarks>
  /// This event is raised before <see cref="Adapter"/> 
  /// removes <see cref="DataObject"/> instance.
  /// </remarks>
  public delegate void BeforeRemoveObjectEventHandler(object sender, BeforeRemoveObjectEventArgs e);
}
