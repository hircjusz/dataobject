// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;
using System.Data;
using System.Reflection;
using DataObjects.NET.Exceptions;

namespace DataObjects.NET.Data
{
  /// <summary>
  /// Provides a relation between <see cref="DataObject"/>'s property and a <see cref="DataColumn"/>.
  /// Gets and sets <see cref="DataObject"/> property value.
  /// </summary>
  /// <remarks>
  /// If property value is a structure this translator is used to get and set 
  /// subfields of this structure, subfields of subfields and so on.
  /// The target field of this translator is established using dotted path:
  /// "PropertyName[-Culture][.FieldName[.FieldName[...]]]".
  /// </remarks>
  internal class PropertyTranslator
  {
    private DoTranslator doTranslator;
    
    private string path;
    private string propertyName;
    private string[] fieldPath;
    
    private DataColumn dataColumn;
    
    private Culture culture;
    
    private PropertyInfo propertyInfo;
    private FieldInfo[] preFieldInfos;
    private FieldInfo targetFieldInfo;
    private System.Type targetType;
    
    private PropertyInfo workingPropertyInfo;
    private FieldInfo[] workingPreFieldInfos;
    private FieldInfo workingTargetFieldInfo;
    private System.Type workingTargetType;
    
    /// <summary>
    /// Gets path associated with the translator.
    /// </summary>
    public string Path {
      get {
        return path;
      }
    }
    
    /// <summary>
    /// Gets <see cref="DataColumn"/> associated with the translator.
    /// </summary>
    public DataColumn DataColumn {
      get {
        return dataColumn;
      }
    }
    
    /// <summary>
    /// Gets a value indicating whether current <see cref="DataRow"/> contains corresponding
    /// cell that is modified and <see cref="Update"/> method should be called.
    /// </summary>
    public bool ShouldUpdate {
      get {
        DataRow dataRow = doTranslator.DataRow;
        if (dataRow.RowState==DataRowState.Added)
          return true;
        if (dataRow.RowState==DataRowState.Modified) {
          object currentValue = dataRow[dataColumn, DataRowVersion.Current];
          object originalValue = dataRow[dataColumn, DataRowVersion.Original];
          if (System.DBNull.Value.Equals(currentValue))
            currentValue = null;
          if (System.DBNull.Value.Equals(originalValue))
            originalValue = null;
          if (currentValue==null && originalValue==null)
            return false;
          if (currentValue==null || originalValue==null)
            return true;
          IComparable comparable = currentValue as IComparable;
          if (comparable==null)
            return true;
          if (comparable.CompareTo(originalValue)!=0)
            return true;
        }
        return false;
      }
    }
    
    /// <summary>
    /// Gets <see cref="ObjectModel.Type"/> of object the property belongs to.
    /// </summary>
    private ObjectModel.Type ObjectType {
      get {
        return doTranslator.Type;
      }
    }
    
    /// <summary>
    /// Fills specified <see cref="DataObject"/> into the <see cref="DoTranslator.DataRow"/>.
    /// </summary>
    /// <param name="dataObject"><see cref="DataObject"/> to fill.</param>
    public void Fill(DataObject dataObject)
    {
      GetWorkingSet(dataObject.GetType());
      
      object value = GetValue(dataObject);
      if (value is DataObject) {
        DataObject doVal = (DataObject)value;
        Adapter adapter = doTranslator.Adapter;
        if (adapter.FillQueue.GetObjectFillState(doVal)==DataObjectFillState.NotQueued) {
          EnqueueObjectEventArgs e = new EnqueueObjectEventArgs(adapter, doVal.ID);
          adapter.Internal_OnEnqueueObject(e);
          if (e.Enqueue)
            adapter.FillQueue.Enqueue(doVal);
        }
        value = doVal.ID;
      }
      doTranslator.DataRow[dataColumn] = (value==null) ? System.DBNull.Value : value;
    }
    
    /// <summary>
    /// Updates specified <see cref="DataObject"/> from the <see cref="DataRow"/>.
    /// </summary>
    /// <param name="dataObject"><see cref="DataObject"/> to update.</param>
    public void Update(DataObject dataObject)
    {
      GetWorkingSet(dataObject.GetType());
      
      Adapter adapter = doTranslator.Adapter;
      Translator translator = adapter.Translator;
      
      if (ShouldUpdate && translator.CanUpdateProperty(path)) {
        if (workingPropertyInfo==null || workingPropertyInfo.CanWrite) {
          object value = doTranslator.DataRow[dataColumn];
          if (System.DBNull.Value.Equals(value))
            value = null;
          
          if (workingTargetType!=null) {
            if (typeof(DataObject).IsAssignableFrom(workingTargetType)) {
              if (value!=null) {
                long id = (long)value;
              
                value = null;
              
                if (id!=0) {
                  value = (id>0) ? 
                    adapter.Session[id] : 
                    adapter.UpdateQueue.GetCreatedObject(id);
              
                  if (value==null)
                    throw new AdapterException(
                      String.Format("DataObject with ID=\"{0}\" is not found.", id));
                }
              }
            }
          }
          
          SetValue(dataObject, value);
        }
      }
    }
    
    /// <summary>
    /// Returns a value of a property or target field 
    /// this <see cref="PropertyTranslator"/> represents.
    /// </summary>
    /// <param name="dataObject"><see cref="DataObject"/> from which to extract value.</param>
    /// <returns>A value of a property or target field 
    /// this <see cref="PropertyTranslator"/> represents.</returns>
    private object GetValue(DataObject dataObject)
    {
      if (dataObject==null)
        throw new ArgumentNullException("dataObject");
        
      object value = null;
        
      if (workingPropertyInfo!=null) {
        if (culture!=null && culture!=dataObject.Session.Culture) {
          Culture oldCulture = dataObject.Session.Culture;
          try {
            dataObject.Session.Culture = culture;
            value = workingPropertyInfo.GetValue(dataObject, null);
          } finally {
            dataObject.Session.Culture = oldCulture;
          }
        } else {
          value = workingPropertyInfo.GetValue(dataObject, null);
        }
      }
      
      PropertyEventArgs e = new PropertyEventArgs(dataObject, propertyName, culture, value);
      doTranslator.Adapter.Internal_OnGetProperty(e);
      value = e.Value;
      
      if (value!=null && workingTargetFieldInfo!=null) {
        if (workingPreFieldInfos!=null) {
          TypedReference tr = TypedReference.MakeTypedReference(value, workingPreFieldInfos);
          return workingTargetFieldInfo.GetValueDirect(tr);
        }
        return workingTargetFieldInfo.GetValue(value);
      }
      return value;
    }
    
    /// <summary>
    /// Sets a value of a property or target field 
    /// this <see cref="PropertyTranslator"/> represents.
    /// </summary>
    /// <param name="dataObject"><see cref="DataObject"/> whose property to set.</param>
    /// <param name="value">A value of a property.</param>
    private void SetValue(DataObject dataObject, object value)
    {
      if (dataObject==null)
        throw new ArgumentNullException("dataObject");
        
      if (workingPropertyInfo!=null) {
        if (workingTargetFieldInfo!=null) {
          object propValue = null;
          
          if (culture!=null && culture!=dataObject.Session.Culture) {
            Culture oldCulture = dataObject.Session.Culture;
            try {
              dataObject.Session.Culture = culture;
              propValue = workingPropertyInfo.GetValue(dataObject, null);
            } finally {
              dataObject.Session.Culture = oldCulture;
            }
          } else {
            propValue = workingPropertyInfo.GetValue(dataObject, null);
          }
        
          PropertyEventArgs ge = new PropertyEventArgs(dataObject, propertyName, culture, propValue);
          doTranslator.Adapter.Internal_OnGetProperty(ge);
          propValue = ge.Value;
          
          if (propValue!=null) {
            if (workingPreFieldInfos!=null) {
              TypedReference tr = TypedReference.MakeTypedReference(propValue, workingPreFieldInfos);
              workingTargetFieldInfo.SetValueDirect(tr, value);
            } else {
              workingTargetFieldInfo.SetValue(propValue, value);
            }
          }
          
          value = propValue;
        }
      }
      
      PropertyEventArgs se = new PropertyEventArgs(dataObject, propertyName, culture, value);
      doTranslator.Adapter.Internal_OnSetProperty(se);
      value = se.Value;
        
      if (workingPropertyInfo!=null) {
        value = ConvertValue(workingPropertyInfo.PropertyType, value);
        if (culture!=null && culture!=dataObject.Session.Culture) {
          Culture oldCulture = dataObject.Session.Culture;
          try {
            dataObject.Session.Culture = culture;
            workingPropertyInfo.SetValue(dataObject, value, null);
          } finally {
            dataObject.Session.Culture = oldCulture;
          }
        } else {
          workingPropertyInfo.SetValue(dataObject, value, null);
        }
      }
    }
    
    private object ConvertValue(System.Type type, object value)
    {
      if (value==null)
        return value;
      if (!type.IsAssignableFrom(value.GetType())) {
        if (type.IsEnum)
          value = Enum.ToObject(type, value);
      }
      return value;
    }
    
    private void GetWorkingSet(System.Type type)
    {
      if (propertyInfo==null && type!=doTranslator.Type.SourceType) {
        workingPropertyInfo = GetFullPropertyInfo(
          type, 
          propertyName, 
          fieldPath,
          out workingPreFieldInfos,
          out workingTargetFieldInfo,
          out workingTargetType
          );
      }
    }
    
    private PropertyInfo GetPropertyInfo(System.Type type, string propertyName)
    {
      if (type.IsClass) {
        return type.GetProperty(propertyName);
      } else if (type.IsInterface) {
        PropertyInfo propInfo = type.GetProperty(propertyName);
        if (propInfo==null) {
          System.Type[] interfaces = type.GetInterfaces();
          foreach (System.Type interfaceType in interfaces) {
            propInfo = interfaceType.GetProperty(propertyName);
            if (propInfo!=null)
              break;
          }
        }
        return propInfo;
      }
      return null;
    }
    
    private PropertyInfo GetFullPropertyInfo(System.Type type, string propertyName, string[] fieldPath, out FieldInfo[] preFieldInfos, out FieldInfo targetFieldInfo, out System.Type targetType)
    {
      PropertyInfo propertyInfo = GetPropertyInfo(type, propertyName);
      preFieldInfos = null;
      targetFieldInfo = null;
      targetType = null;
      
      if (propertyInfo!=null) {
        targetType = propertyInfo.PropertyType;
      
        if (fieldPath.Length>0) {
          int cnt = fieldPath.Length - 1;
        
          if (cnt>0) {
            preFieldInfos = new FieldInfo[cnt];
            for (int i = 0; i < cnt; i++) {
              FieldInfo fieldInfo = targetType.GetField(fieldPath[i]);
              if (fieldInfo==null)
                throw new AdapterException(
                  String.Format("Field \"{0}\" does not exists.", fieldPath[i]));
              preFieldInfos[i] = fieldInfo;
              targetType = fieldInfo.FieldType;
            }
          }
          targetFieldInfo = targetType.GetField(fieldPath[cnt]);
          if (targetFieldInfo==null)
            throw new AdapterException(
              String.Format("Field \"{0}\" does not exists.", fieldPath[cnt]));
          targetType = targetFieldInfo.FieldType;
        }
      }
      
      return propertyInfo;
    }
    
    /// <summary>
    /// Initializes a new instance of the <see cref="PropertyTranslator"/> class.
    /// </summary>
    /// <param name="doTranslator"><see cref="DoTranslator"/> of a <see cref="DataObject"/>.</param>
    /// <param name="fieldMapping">Field mapping item.</param>
    internal PropertyTranslator(DoTranslator doTranslator, FieldMappingItem fieldMapping)
    {
      if (doTranslator==null)
        throw new ArgumentNullException("doTranslator");
      if (fieldMapping==null)
        throw new ArgumentNullException("fieldMapping");
      if (fieldMapping.FieldName==null)
        throw new NullReferenceException("fieldMapping.FieldName is null");
      if (fieldMapping.ColumnName==null)
        throw new NullReferenceException("fieldMapping.ColumnName is null");
      
      this.path = fieldMapping.FieldName;
      this.doTranslator = doTranslator;
      
      if (!doTranslator.DataTable.Columns.Contains(fieldMapping.ColumnName))
        throw new AdapterException(
          String.Format("Column \"{0}\" does not exists.", fieldMapping.ColumnName));
      dataColumn = doTranslator.DataTable.Columns[fieldMapping.ColumnName];
      
      string[] pathPart = path.Split(new char[] {'.'});
      
      propertyName = pathPart[0];
      
      int cnt = pathPart.Length - 1;
      fieldPath = new string[cnt];
      for (int i = 0; i < cnt; i++)
        fieldPath[i] = pathPart[i + 1];
      
      int cultureInd = propertyName.LastIndexOf("-");
      if (cultureInd!=-1) {
        string cultureName = propertyName.Substring(cultureInd + 1);
        propertyName = propertyName.Substring(0, cultureInd);
        culture = doTranslator.Adapter.Domain.Cultures[cultureName];
        if (culture==null)
          throw new AdapterException(
            String.Format("Culture \"{0}\" is not registered in the domain.", cultureName));
      }
      
      propertyInfo = GetFullPropertyInfo(
        doTranslator.Type.SourceType, 
        propertyName, 
        fieldPath, 
        out preFieldInfos, 
        out targetFieldInfo, 
        out targetType
        );
        
      workingPropertyInfo = propertyInfo;
      workingPreFieldInfos = preFieldInfos;
      workingTargetFieldInfo = targetFieldInfo;
      workingTargetType = targetType;
    }
  }
}