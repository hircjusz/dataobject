// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Text;
using System.Text.RegularExpressions;

namespace DataObjects.NET.Attributes
{
  /// <summary>
  /// Specifies an alias (synonym) for the field\class name.
  /// </summary>
  /// <remarks>
  /// Aliases are useful when:
  /// <para>1) It's necessary to give a short synonym
  /// to the type or property name - to use this synonym 
  /// in queries.</para>
  /// <para>1) It's desirable to shorten full type names
  /// in case when two or more types have equal names, 
  /// but located in different namespaces.</para>
  /// <para>
  /// Multiple aliases are allowed. 
  /// You can use the following characters in <see cref="Alias"/>es: [_A-Za-z0-9]. 
  /// <see cref="Alias"/> can't be an empty string or <see langword="null"/>.
  /// </para>
  /// <para>
  /// <example>Example:
  /// <code lang="C#">
  ///  public abstract class Person: DataObject
  ///  {
  ///    ...
  ///
  ///    [Alias("FN")] // !!!
  ///    public abstract string FullName {get; set;}
  ///
  ///    ...
  ///  }
  /// </code>
  /// </example>
  /// </para>
  /// <seealso cref="DbNameAttribute"/>
  /// </remarks>
  [AttributeUsage(AttributeTargets.Class | AttributeTargets.Interface | AttributeTargets.Property | AttributeTargets.Field, 
    AllowMultiple = true, Inherited = true)]
  [Serializable]
  public class AliasAttribute: DataObjectAttribute
  {
    private string alias;
    /// <summary>
    /// Gets or sets the alias (synonym) for the field\class name.
    /// </summary>
    /// <remarks>
    /// You can use the following characters in <see cref="Alias"/>es: [_A-Za-z0-9]. 
    /// <see cref="Alias"/> can't be an empty string or <see langword="null"/>.
    /// </remarks>
    public string Alias {
      get {return alias;}
      set {alias = value;}
    }
    
    /// <summary>
    /// Returns <see langword="true"/> if <see cref="Alias"/> is valid;
    /// otherwise, <see langword="false"/>.
    /// </summary>
    /// <returns><see langword="True"/> if <see cref="Alias"/> is valid;
    /// otherwise, <see langword="false"/>.</returns>
    public bool Validate()
    {
      if (alias==null || alias=="")
        return false;
      Regex re = new Regex("^[_A-Za-z0-9]+$");
      if (!re.IsMatch(alias))
        return false;
      return true;
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="alias">The alias (synonym) for the field\class name.</param>
    public AliasAttribute(string alias) 
    {
      this.alias = alias;
    }
  }
}
