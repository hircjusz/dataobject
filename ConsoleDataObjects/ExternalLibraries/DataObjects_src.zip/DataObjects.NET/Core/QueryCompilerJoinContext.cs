// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;
using System.Collections.Specialized;
using DataObjects.NET.ObjectModel;

namespace DataObjects.NET
{
  internal class QueryCompilerJoinContext:
    IEnumerable
  {
    private ListDictionary layers = new ListDictionary();
    int     lastAutoNameN = 1;

    public int Count {
      get {
        return layers.Count;
      }
    }

    public QueryCompilerRefLayer this[string name] {
      get {
        return (QueryCompilerRefLayer)layers[name];
      }
    }
    
    public IEnumerator GetEnumerator()
    {
      return layers.GetEnumerator();
    }

    public string Add(string name, QueryCompilerRefLayer layer)
    {
      if (name==null || name=="")
        name = "__Join" + (lastAutoNameN++).ToString();
      layers.Add(name, layer);
      return name;
    }

    public string Add(QueryCompilerRefLayer layer)
    {
      return Add(null, layer);
    }

    public void Rename(string oldName, string newName)
    {
      QueryCompilerRefLayer layer = 
        (QueryCompilerRefLayer)layers[oldName];
      layers.Remove(oldName);
      layers.Add(newName, layer);
    }
    
    public void Clear()
    {
      layers.Clear();
    }


    // Constructors
    
    public QueryCompilerJoinContext()
    {
    }
  }
}
