// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Attributes;
using DataObjects.NET.ObjectModel;

namespace DataObjects.NET
{
  /// <summary>
  /// Interface allowing DataObjects.NET to interact with the field.
  /// </summary>
  public interface IDataObjectFieldValue
  {
    /// <summary>
    /// Gets the owner of the field 
    /// (<see cref="DataObject"/> instance containing the field).
    /// </summary>
    DataObject Owner {get;}

    /// <summary>
    /// Gets field descriptor (<see cref="Field"/> descandant).
    /// </summary>
    Field      Field  {get;}
    
    /// <summary>
    /// Gets <see cref="Culture"/> of the field.
    /// </summary>
    Culture    Culture {get;}
    
    /// <summary>
    /// Attaches the instance to the owner. This method is called by owner
    /// (<see cref="DataObject"/> instance) of the field during
    /// initialization or on property change.
    /// </summary>
    /// <param name="owner">Field owner (<see cref="DataObject"/> instance containing this field).</param>
    /// <param name="field">Field descriptor (<see cref="Field"/> descandant).</param>
    /// <param name="culture">Culture of this instance (if field is marked by 
    /// <see cref="TranslatableAttribute"/>), or <see langword="null"/>.</param>
    /// <remarks>
    /// The implementation of this method should throw <see cref="InvalidOperationException"/>
    /// if this method is invoked more then once for the particular instance. 
    /// In this case peroperties <see cref="Owner"/>, <see cref="Field"/>, <see cref="Culture"/>
    /// shouldn't be changed.
    /// The implementation of this method shouldn't call <see cref="DataObject.Persist"/>
    /// or <see cref="DataObject.FieldContentChanged"/> methods.
    /// </remarks>
    void Attach(DataObject owner, Field field, Culture culture);

    /// <summary>
    /// Detaches the instance from the owner. This method is called by owner
    /// (<see cref="DataObject"/> instance) of the field on property change.
    /// </summary>
    /// <remarks>
    /// The implementation of this method shouldn't call <see cref="DataObject.Persist"/>
    /// or <see cref="DataObject.FieldContentChanged"/> methods.
    /// In the worst case it can throw an exception to prevent the change of
    /// the field.
    /// </remarks>
    void Detach();
  }
}
