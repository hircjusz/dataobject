// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.ComponentModel;

namespace DataObjects.NET.Data
{
  /// <summary>
  /// Collection of class mapping items.
  /// </summary>
  [Editor("DataObjects.NET.Data.Design.ClassMappingCollectionEditor, DataObjects.NET", 
    "System.Drawing.Design.UITypeEditor, System.Drawing")]
  public class ClassMappingCollection: MappingCollectionBase
  {
    /// <summary>
    /// Adds an item to the collection.
    /// </summary>
    /// <param name="value">The <see cref="ClassMappingItem"/> to add to the collection.</param>
    /// <returns>The position into which the new element was inserted.</returns>
    public int Add(ClassMappingItem value)
    {
      return base.Add(value);
    }

    /// <summary>
    /// Adds an item to the collection.
    /// </summary>
    /// <param name="value">The <see cref="Object"/> to add to the collection.</param>
    /// <returns>The position into which the new element was inserted.</returns>  
    public override int Add(object value)
    {
      ClassMappingItem item = (ClassMappingItem)value;
      return base.Add(item);
    }
    
    /// <summary>
    /// Adds an array of <see cref="ClassMappingItem"/> objects to the collection.
    /// </summary>
    /// <param name="values">An array of <see cref="ClassMappingItem"/> objects to add to the collection.</param>
    public void AddRange(ClassMappingItem[] values)
    {
      if (values==null)
        throw new ArgumentNullException("values");
      foreach (ClassMappingItem item in values)
        Add(item);
    }
    
    /// <summary>
    /// Inserts an item to the collection at the specified position.
    /// </summary>
    /// <param name="index">The zero-based index at which value should be inserted.</param>
    /// <param name="value">The <see cref="ClassMappingItem"/> to insert into the collection.</param>
    public void Insert(int index, ClassMappingItem value)
    {
      base.Insert(index, value);
    }
    
    /// <summary>
    /// Inserts an item to the collection at the specified position.
    /// </summary>
    /// <param name="index">The zero-based index at which value should be inserted.</param>
    /// <param name="value">The <see cref="Object"/> to insert into the collection.</param>
    public override void Insert(int index, object value)
    {
      ClassMappingItem item = (ClassMappingItem)value;
      base.Insert(index, item);
    }
    
    /// <summary>
    /// Gets or sets the element at the specified index.
    /// </summary>
    public override object this[int index] 
    {
      get {
        return List[index];
      }
      set {
        ClassMappingItem item = (ClassMappingItem)value;
        List[index] = item;
      }
    }
    
    /// <summary>
    /// Initializes a new instance of the <see cref="ClassMappingCollection"/> class.
    /// </summary>
    /// <param name="owner">An owner of a collection.</param>
    public ClassMappingCollection(object owner): base(owner)
    {
    }
  }
}
