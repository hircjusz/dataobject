// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.IO;
using System.Collections;
using System.Reflection;
using System.Diagnostics;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Attributes;
using DataObjects.NET.Internals;

namespace DataObjects.NET.Database
{
  /// <summary>
  /// Locates and creates <see cref="Driver"/> for the specified <see cref="ConnectionInfo"/>.
  /// </summary>
  #if (!NoMBR)
  public sealed class DriverFactory: MarshalByRefObject
  #else
  public sealed class DriverFactory: Object
  #endif
  {
    private static Hashtable KnownExternalDrivers = new Hashtable();
    static DriverFactory()
    {
      string sNativeOracleDriverName = "DataObjects.NET Native Oracle Driver";
      string sDB2DriverName          = "DataObjects.NET DB2 Driver";
      string sMySQLDriverName        = "DataObjects.NET MySQL Driver";
      string sPostgreSQLDriverName   = "DataObjects.NET PostgreSQL Driver";
      string sInterbaseDriverName    = "DataObjects.NET Interbase Driver";
      string sFirebirdDriverName     = "DataObjects.NET FireBird Driver";
      string sMimerSQLDriverName     = "DataObjects.NET Mimer SQL Driver";
      string sCustomDriverName       = "DataObjects.NET Custom Driver";
      KnownExternalDrivers["nativeoracle"] = sNativeOracleDriverName;
      KnownExternalDrivers["nativeoci"]    = sNativeOracleDriverName;
      KnownExternalDrivers["oracle2"]      = sNativeOracleDriverName;
      KnownExternalDrivers["oci2"]         = sNativeOracleDriverName;
      KnownExternalDrivers["db2"]          = sDB2DriverName;
      KnownExternalDrivers["mysql"]        = sMySQLDriverName;
      KnownExternalDrivers["postgres"]     = sPostgreSQLDriverName;
      KnownExternalDrivers["postgresql"]   = sPostgreSQLDriverName;
      KnownExternalDrivers["pgsql"]        = sPostgreSQLDriverName;
      KnownExternalDrivers["ib"]           = sInterbaseDriverName;
      KnownExternalDrivers["interbase"]    = sInterbaseDriverName;
      KnownExternalDrivers["firebird"]     = sFirebirdDriverName;
      KnownExternalDrivers["fb"]           = sFirebirdDriverName;
      KnownExternalDrivers["mimer"]        = sMimerSQLDriverName;
      KnownExternalDrivers["mimersql"]     = sMimerSQLDriverName;
      KnownExternalDrivers["custom"]       = sCustomDriverName;
    }


    /// <summary>
    /// Creates <see cref="Driver"/> for the specified <see cref="ConnectionInfo"/>.
    /// </summary>
    /// <param name="info">Connection information.</param>
    /// <param name="domain"><see cref="Domain"/> to which this driver belongs.</param>
    /// <returns>Appropriate driver for <see cref="ConnectionInfo"/>.</returns>
    public Driver CreateDriver(ConnectionInfo info, Domain domain)
    {
      // Further this code should be optimized.
      Type t = typeof(Driver);
      Type[] cti = {typeof(ConnectionInfo),typeof(Domain)};
      Object[] ca = {info,domain};

      // First we search through registered drivers
      Type ct1 = (Type)Driver.RegisteredDrivers[info.Protocol];
      if (ct1!=null && ct1.IsSubclassOf(t) && ct1.IsPublic) {
        ConstructorInfo ci = ct1.GetConstructor(cti);
        try {
          return (Driver)ci.Invoke(ca);
        }
        catch (TargetInvocationException e) {
          throw e.InnerException;
        }
      }

      string externalDriver = (string)KnownExternalDrivers[info.Protocol];
      
      // And finally through all classes
      Assembly executingAssembly = Assembly.GetExecutingAssembly();
      Assembly[] ma = AppDomain.CurrentDomain.GetAssemblies();
      foreach (Assembly a in ma) {
        // It's better to skip some assemblies (like mscorlib)
        if (a!=executingAssembly) {
          string[] fnParts = a.FullName.Split(new char[] {','});
          if (fnParts[0]!=externalDriver)
            continue;
        }
          
        // OK :)  
        Type[] mt = a.GetTypes();
        foreach (Type ct in mt) {
          if (ct.IsSubclassOf(t) && ct.IsPublic) {
            ConstructorInfo ci = ct.GetConstructor(cti);
            try {
              Driver d = (Driver)ci.Invoke(ca);
              if (d.CanHandle())
                return d;
            }
            catch (TargetInvocationException e) {
              throw e.InnerException;
            }
          }
        }
      }
      
      // And at last let's try to load known external driver
      if (externalDriver!=null) {
#if MONO
         Assembly a = AssemblyUtils.LoadDriverAssembly(externalDriver, domain.ProxyAssemblyCacheFolder);
#else
        Assembly a = AssemblyUtils.LoadDriverAssembly(externalDriver, null);
#endif
        if (a!=null)
          return CreateDriver(info, domain);
      }
      
      throw new DriverFactoryException(
        String.Format("Driver for protocol \"{0}\" wasn't found.",info.Protocol)
        );
    }
  }
}
