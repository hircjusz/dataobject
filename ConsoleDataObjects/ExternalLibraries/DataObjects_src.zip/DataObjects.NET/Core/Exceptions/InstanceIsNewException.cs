// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Runtime.Serialization;

namespace DataObjects.NET.Exceptions
{
  /// <summary>
  /// Exception thrown by some <see cref="DataObject"/> methods when
  /// instance <see cref="DataObject.State"/> is <see cref="DataObjectState">DataObjectState.New</see>.
  /// </summary>
  [Serializable]
  public class InstanceIsNewException: InvalidInstanceStateException
  {
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    public InstanceIsNewException(): base("Instance is new.") {}
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="text">Text of message.</param>
    public InstanceIsNewException(string text): base(text) {}
    
    /// <summary>
    /// Deserialization constructor.
    /// </summary>
    /// <param name="info"><see cref="SerializationInfo"/> object.</param>
    /// <param name="context"><see cref="StreamingContext"/> object.</param>
    protected InstanceIsNewException(SerializationInfo info, StreamingContext context):
      base(info, context)
    {
    }
  }
}
