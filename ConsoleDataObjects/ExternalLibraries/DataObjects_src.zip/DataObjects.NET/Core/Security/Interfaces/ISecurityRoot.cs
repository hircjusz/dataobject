// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.IO;
using System.Threading;
using System.Configuration;
using System.Diagnostics;
using System.Globalization;
using System.Collections;
using DataObjects.NET;
using DataObjects.NET.Attributes;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Serialization;

namespace DataObjects.NET.Security
{
  /// <summary>
  /// This tagging interface should be implemented by any
  /// <see cref="DataObject"/> descendant that can be used
  /// as the security root.
  /// <seealso cref="Session.SecurityRoot"/>
  /// <seealso cref="SystemObjects"/>
  /// <seealso cref="IDataObject"/>
  /// <seealso cref="DataObject"/>
  /// </summary>
  /// <remarks>
  /// <para>
  /// You can find more information about the whole DataObjects.NET
  /// security system <see cref="AccessControlList">here</see>.
  /// </para>
  /// <para>
  /// Only one <see cref="ISecurityRoot"/> object should exist in the 
  /// <see cref="Domain"/>.
  /// </para>
  /// <para>
  /// You should correctly override <see cref="DataObject.SecurityChildren"/> 
  /// property to allow the security system to change child object permissions 
  /// properly.
  /// But you can omit this if you're going to never use this feature - 
  /// e.g. when you want to perform this action manually.
  /// </para>
  /// <para>
  /// Any <see cref="ISecurityRoot"/> object should return
  /// <see langword="null"/> from <see cref="DataObject.SecurityParent"/> property. 
  /// Any other object shouldn't return <see langword="null"/> from the
  /// <see cref="DataObject.SecurityParent"/> property.
  /// </para>
  /// <note type="note"><see cref="ISecurityRoot"/> object is always serialized
  /// (see <see cref="Serializer"/>)
  /// as reference, also its <see cref="DataObject.ID"/> value stored in the
  /// deserialization stream is ignored during the deserialization (because
  /// only one <see cref="ISecurityRoot"/> instance can exist in the storage).
  /// </note>
  /// </remarks>
  public interface ISecurityRoot: IDataObject
  {
  }
}
