// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;

namespace DataObjects.NET
{
  internal class SecurityDisabler : IDisposable
  {
    private SessionBoundObject sbObject;
    private bool enable;

    internal SecurityDisabler(bool enable, SessionBoundObject sbObject)
    {
      // Check argument 
      if (sbObject==null) throw new ArgumentNullException("sbObject");

      this.enable = enable;

      if (enable)
        sbObject.EnableSecurity();
      else
        sbObject.DisableSecurity();

      this.sbObject = sbObject;
    }

    void IDisposable.Dispose()
    {
      // Aquire lock on this to prevent multiple enables 
      if (sbObject!=null)
        lock (this) {
          if (sbObject!=null) {
            if (enable)
              sbObject.DisableSecurity();
            else
              sbObject.EnableSecurity();
            sbObject = null;
          }
        }
    }
  }

}
