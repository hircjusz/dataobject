// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;
using System.Data;
using DataObjects.NET;

namespace DataObjects.NET.Data
{
  /// <summary>
  /// Update queue of <see cref="Adapter"/>.
  /// </summary>
  /// <remarks>
  /// Update queue contains IDs of <see cref="DataObject"/>s 
  /// that are queued to be created, removed or updated from
  /// <see cref="DataObjects.NET.Data.Adapter.DataSource"/>.
  /// </remarks>
  public sealed class AdapterUpdateQueue
  {
    private Adapter adapter;
    
    private Hashtable createItems = new Hashtable();
    private Queue createQueue = new Queue();
    
    private Hashtable removeItems = new Hashtable();
    private Queue removeQueue = new Queue();
    
    private Hashtable updateItems = new Hashtable();
    private Queue updateQueue = new Queue();
    
    /// <summary>
    /// Gets the <see cref="DataObjects.NET.Data.Adapter"/> this instance belongs to.
    /// </summary>
    public Adapter Adapter {
      get {
        return adapter;
      }
    }
    
    /// <summary>
    /// Gets <see cref="AdapterUpdateQueue"/>'s state.
    /// </summary>
    public AdapterUpdateQueueState State {
      get {
        if (createQueue.Count>0)
          return AdapterUpdateQueueState.Create;
        else if (updateQueue.Count>0)
          return AdapterUpdateQueueState.Update;
        else if (removeQueue.Count>0)
          return AdapterUpdateQueueState.Remove;
        return AdapterUpdateQueueState.Empty;
      }
    }
    
    /// <summary>
    /// Gets the <see cref="DataObject.ID"/> of instance that is currently processed.
    /// </summary>
    public long CurrentObjectID {
      get {
        if (createQueue.Count>0)
          return (long)createQueue.Peek();
        else if (updateQueue.Count>0)
          return (long)updateQueue.Peek();
        else if (removeQueue.Count>0)
          return (long)removeQueue.Peek();
        return 0;
      }
    }
    
    /// <summary>
    /// Gets the <see cref="DataObject"/> instance that is currently processed.
    /// </summary>
    public DataObject CurrentObject {
      get {
        return adapter.Session[this.CurrentObjectID];
      }
    }
    
    /// <summary>
    /// Gets <see cref="DataObjectUpdateState"/> for object with specified
    /// <see cref="DataObject.ID"/>.
    /// </summary>
    /// <param name="id"><see cref="DataObject.ID"/> of instance to get update state for.</param>
    /// <returns>Object update state.</returns>
    public DataObjectUpdateState GetObjectUpdateState(long id) 
    {
      DataObjectUpdateState doUpdateState = 0; //Nan
      if (createItems[id]!=null) {
        doUpdateState |= DataObjectUpdateState.Created;
        id = (long)createItems[id];
      }
      if (updateItems[id]!=null)
        doUpdateState |= DataObjectUpdateState.Updated;
      if (removeItems[id]!=null)
        doUpdateState |= DataObjectUpdateState.Removed;
      return doUpdateState;
    }
    
    /// <summary>
    /// Gets <see cref="DataObjectUpdateState"/> for  specified
    /// <see cref="DataObject"/> instance.
    /// </summary>
    /// <param name="dataObject"><see cref="DataObject"/> instance to get update state for.</param>
    /// <returns>Object update state.</returns>
    public DataObjectUpdateState GetObjectUpdateState(DataObject dataObject)
    {
      return GetObjectUpdateState(dataObject.ID);
    }
    
    /// <summary>
    /// Returns <see cref="DataObject.ID"/> of the object that was previously
    /// registered for creation using negative id.
    /// </summary>
    /// <param name="id">Negative id that was registered for creation.</param>
    /// <returns><see cref="DataObject.ID"/> if object was registered and created,
    /// otherwise zero.</returns>
    public long GetCreatedObjectID(long id)
    {
      object val = createItems[id];
      if (val==null)
        return 0;
      return (long)val;
    }
    
    /// <summary>
    /// Returns <see cref="DataObject"/> that was previously
    /// registered for creation using negative id.
    /// </summary>
    /// <param name="id">Negative id that was registered for creation.</param>
    /// <returns><see cref="DataObject"/> if object was registered and created,
    /// otherwise null.</returns>
    public DataObject GetCreatedObject(long id)
    {
      long newId = GetCreatedObjectID(id);
      if (newId!=0)
        return adapter.Session[newId];
      return null;
    }
    
    // internal methods.
    
    /// <summary>
    /// Enqueues <see cref="DataObject"/> for creation.
    /// </summary>
    /// <param name="id">An id of the <see cref="DataObject"/> to create. Value must be negative.</param>
    /// <returns><see langword="False"/> if id was registered before,
    /// otherwise <see langword="true"/>.</returns>
    internal bool EnqueueObjectForCreate(long id)
    {
      if (id>=0)
        throw new InvalidOperationException();
        
      if (createItems.ContainsKey(id))
        return false;
      createItems.Add(id, null);
      createQueue.Enqueue(id);
      return true;
    }
    
    /// <summary>
    /// Re-enqueues <see cref="DataObject"/> for creation.
    /// </summary>
    /// <param name="id">An id of the <see cref="DataObject"/> to create. Value must be negative.</param>
    /// <returns><see langword="False"/> if id was registered before and an object has been created,
    /// otherwise <see langword="true"/>.</returns>
    internal bool ReEnqueueObjectForCreate(long id)
    {
      if (id>=0)
        throw new InvalidOperationException();
        
      if (createItems[id]!=null)
        return false;
      createItems.Add(id, null);
      createQueue.Enqueue(id);
      return true;
    }
    
    /// <summary>
    /// Enqueues <see cref="DataObject"/> for removal.
    /// </summary>
    /// <param name="id">An id of the <see cref="DataObject"/> to remove.</param>
    /// <returns><see langword="False"/> if id was registered before,
    /// otherwise <see langword="true"/>.</returns>
    internal bool EnqueueObjectForRemove(long id)
    {
      if (removeItems.ContainsKey(id))
        return false;
      removeItems.Add(id, null);
      removeQueue.Enqueue(id);
      return true;
    }
    
    /// <summary>
    /// Enqueue <see cref="DataObject"/> for update.
    /// </summary>
    /// <param name="id">An id of the <see cref="DataObject"/> to update.</param>
    /// <returns><see langword="False"/> if id was registered before,
    /// otherwise <see langword="true"/>.</returns>
    internal bool EnqueueObjectForUpdate(long id)
    {
      if (updateItems.ContainsKey(id))
        return false;
      updateItems.Add(id, null);
      updateQueue.Enqueue(id);
      return true;
    }
    
    internal void SetCreatedObjectID(long id, long createdObjectID)
    {
      createItems[id] = createdObjectID;
      createItems[createdObjectID] = createdObjectID;
    }
    
    internal void Dequeue()
    {
      if (createQueue.Count>0) {
        createQueue.Dequeue();
      } else if (updateQueue.Count>0) {
        long id = (long)updateQueue.Dequeue();
        updateItems[id] = updateItems;
      } else if (removeQueue.Count>0) {
        long id = (long)removeQueue.Dequeue();
        removeItems[id] = removeItems;
      }
    }
    
    // Constructors
    
    /// <summary>
    /// Initializes a new instance of the <see cref="AdapterUpdateQueue"/> class.
    /// </summary>
    /// <param name="adapter">Adapter.</param>
    internal AdapterUpdateQueue(Adapter adapter)
    {
      this.adapter = adapter;
    }
  }
}
