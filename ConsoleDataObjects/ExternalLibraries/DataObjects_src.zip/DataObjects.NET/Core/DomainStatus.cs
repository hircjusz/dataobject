// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Attributes;

namespace DataObjects.NET
{
  /// <summary>
  /// Enumerates possible <see cref="Domain.Status"/> values.
  /// <seealso cref="Domain.Build"/>
  /// <seealso cref="Domain"/>
  /// </summary>
  public enum DomainStatus {
    /// <summary>
    /// Initial status.
    /// Value is <see langword="0x0"/>. 
    /// </summary>
    Created  = 0, 
    /// <summary>
    /// Domain is building (<see cref="Domain.Build"/> method is executing).
    /// Value is <see langword="0x1"/>. 
    /// </summary>
    Building = 1, 
    /// <summary>
    /// Domain is initializing system objects (see
    /// <see cref="Domain.InitializeSystemObjects"/>).
    /// <see cref="Domain.Build"/> method is still executing.
    /// Value is <see langword="0x2"/>. 
    /// </summary>
    InitializingSystemObjects = 2, 
    /// <summary>
    /// Domain is initializing (see 
    /// <see cref="Domain.Initialize"/>).
    /// <see cref="Domain.Build"/> method is still executing.
    /// Value is <see langword="0x3"/>. 
    /// </summary>
    Initializing = 3, 
    /// <summary>
    /// Domain is ready to use.
    /// Value is <see langword="0x10"/>. 
    /// </summary>
    Ready    = 0x10, 
    /// <summary>
    /// Error occured during domain building.
    /// Value is <see langword="0x100"/>. 
    /// </summary>
    Error    = 0x100,
  };
}
