// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Reflection;
using System.Runtime.Serialization;
using DataObjects.NET.ObjectModel;
using DataObjects.NET.Security;

namespace DataObjects.NET.Serialization
{
  /// <summary>
  /// Serialization binder used by the <see cref="Serializer"/>.
  /// </summary>
  public sealed class SerializerBinder: SerializationBinder
  {
    private  Serializer serializer;
    /// <summary>
    /// Serializer of the binder.
    /// </summary>
    public   Serializer Serializer {
      get {
        return serializer;
      }
    }
    
    /// <summary>
    /// Session of the binder.
    /// </summary>
    public  Session Session {
      get {
        return serializer.session;
      }
    }
    
    /// <summary>
    /// Provides a valid types for proxy classes.
    /// </summary>
    /// <param name="assemblyName">Specifies the <see cref="Assembly"/> name of the serialized object.</param>
    /// <param name="typeName">Specifies the <see cref="System.Type"/> name of the serialized object.</param>
    /// <returns></returns>
    public override System.Type BindToType(string assemblyName, string typeName) 
    {
      switch (typeName) {
      case "DataObjects.NET.Serialization.DataObjectReference":
        return typeof(DataObjectReference);
      case "DataObjects.NET.Security.AccessControlList":
        return typeof(AccessControlList);
      case "DataObjects.NET.Security.PermissionSet":
        return typeof(PermissionSet);
      }
      ObjectModel.Type t = serializer.session.types.FindByProxyName(typeName);
      if (t!=null)
        return t.ProxyType;
      return System.Type.GetType(typeName+", "+assemblyName);
    }
    
    /// <summary>
    /// Initializes an instance of this class.
    /// </summary>
    /// <param name="serializer">Serializer of the binder.</param>
    public SerializerBinder(Serializer serializer)
    {
      if (serializer==null)
        throw new ArgumentNullException("serializer");
      this.serializer = serializer;
    }
  }
}
