// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Text;
using DataObjects.NET.Database;
using DataObjects.NET.Offline.Helpers;

namespace DataObjects.NET.FullText
{
  /// <summary>
  /// Stores single full-text search result entry 
  /// in the <see cref="FtsResult"/>.
  /// <seealso cref="FtsResult"/>
  /// <seealso cref="FtsDriver"/>
  /// <seealso cref="FtsDriver.ExecuteQuery"/>
  /// <seealso cref="Persister.BuildQueryCommandText"/>
  /// </summary>
  [Serializable]
  public struct FtsResultEntry
  {
    /// <summary>
    /// <see cref="DataObject.ID"/> of found object. 
    /// </summary>
    public long ID;
    
    /// <summary>
    /// Full-text search rank of this entry.
    /// </summary>
    public double Rank;
  }
}
