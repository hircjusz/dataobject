// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.IO;
using System.Text;
using System.Collections;
using System.Reflection;
using System.Threading;
using System.Security.Cryptography;

namespace DataObjects.NET
{
  internal sealed class Base64Decoder
  {
    const int    Basis  = 6;
    const string Chars  = "0123456789QWERTYUIOPASDFGHJKLZXCVBNM@qwertyuiopasdfghjklzxcvbnm#";
    static bool[][] InvChars;
    const string SplitStr  = "-";
    
    public static byte[] Decode(string data)
    {
      if (data==null || data=="")
        return null;
      if (InvChars==null)
        BuildInvChars();
      int l = data.Length;
      BitArray bits = new BitArray(l*Basis,false);
      int iBit = 0;
      int i = 0;
      int sl = SplitStr.Length;
      while (i<l) {
        int c = data[i++];
        if (c<0 || c>127)
          return null;
        bool[] bools = InvChars[c];
        if (bools==null)
          return null;
        if (bools.Length==0)
          continue;
        for (int j = 0; j<Basis; j++)
          bits[iBit++] = bools[j];
      }
      bits.Length = iBit;
      l = bits.Length/8;
      if (l*8!=bits.Length) {
        for (int t = l*8; t<bits.Length; t++)
          if (bits[t])
            return null;
        bits.Length = l*8;
      }
      if ((iBit-bits.Length)>=Basis)
        return null;
      byte[] buffer = new byte[l];
      bits.CopyTo(buffer,0);
      
      // Product Key validation
      try {
        using (MemoryStream ms = new MemoryStream(buffer, false)) {
          int hashLen = 8;
          byte[] nHash = new byte[hashLen];
          ms.Read(nHash,0,nHash.Length);
          RijndaelManaged rm = new RijndaelManaged();
          // Visual Studio 2005 beta 2 bug workaround, see 
          // http://www.x-tensive.com/Forum/viewtopic.php?t=700
          rm.Padding = PaddingMode.Zeros;
          byte[] cKey = new byte[rm.KeySize/8];
          for (int ii = 0; ii<(rm.KeySize/8); ii++)
            cKey[ii] = nHash[ii%8];
          byte[] cIV = new byte[rm.BlockSize/8];
          for (int ii = 0; ii<(rm.BlockSize/8); ii++)
            cIV[ii] = nHash[ii%8];

          int signatureLen = 48;
          int headLen = buffer.Length-signatureLen;
          byte[] head      = new byte[headLen];
          byte[] signature = new byte[signatureLen];

          int pfxLen = 0; 
          byte[] pfx = null;
          using (CryptoStream cs = new CryptoStream(ms,rm.CreateDecryptor(cKey,cIV),CryptoStreamMode.Read)) {
            pfxLen = cs.ReadByte();
            pfx = new byte[pfxLen];
            cs.Read(pfx,0,pfx.Length);
            ms.Position = 0;
            ms.Read(head,0,head.Length);
            ms.Read(signature,0,signature.Length);
          }
          // MONO: memory stream will be disposed here during CryptoStream disposing.
          // So we should perform all needed operations with MemoryStream before we leave preceding 
          // block 'using' for CryptoStream
          string[] keyData = new string[] {
            "<","R","SA","Key","Value",">",
              "<","Mod","ulus",">",
                "m6DcIwfs8sNt1yOlYnUsa4qODmcQ6ZJ0oyCbl0SZVfA6GBQZJcrA1WGOs7lH7WfL",
              "</","Mod","ulus",">",
              "<","Exp","on","e","nt",">",
                "AQ","AB",
              "</","Exp","on","en","t",">",
            "</","R","SA","Key","Value",">"
            };
          CspParameters cspParams = new CspParameters();
          cspParams.Flags = CspProviderFlags.UseMachineKeyStore;
          RSACryptoServiceProvider rsa = new RSACryptoServiceProvider(cspParams);
          rsa.FromXmlString(String.Join("",keyData));
          if (!rsa.VerifyData(head,String.Join("",new string[] {"SH","A1"}),signature))
            return null;
        }
      }
      catch (Exception) {
        return null;
      }
      return buffer;
    }
    
    static void BuildInvChars()
    {
      InvChars = new bool[128][];
      for (int i = 0; i<Chars.Length; i++)
      {
        int c = Convert.ToInt32(Chars[i]);
        if (c<0 || c>127)
          throw new DataObjectsDotNetException("Internal error.");
        BitArray bits = new BitArray(BitConverter.GetBytes(i));
        bool[] bools = new bool[Basis];
        for (int j = 0; j<Basis; j++)
          bools[j] = bits[j];
        InvChars[c] = bools;
      }
      for (int i = 0; i<SplitStr.Length; i++)
      {
        int c = Convert.ToInt32(SplitStr[i]);
        if (c<0 || c>127)
          throw new DataObjectsDotNetException("Internal error.");
        bool[] bools = new bool[0];
        InvChars[c] = bools;
      }
    }
  }
}
