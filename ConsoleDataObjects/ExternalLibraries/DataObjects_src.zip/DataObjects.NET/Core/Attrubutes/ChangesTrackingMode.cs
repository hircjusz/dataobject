// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Attributes;

namespace DataObjects.NET.Attributes
{
  /// <summary>
  /// Enumeration of possible changes tracking modes.
  /// See <see cref="ChangesTrackingAttribute"/>.
  /// <seealso cref="ChangesTrackingAttribute"/>
  /// </summary>
  public enum ChangesTrackingMode
  {
    /// <summary>
    /// Default changes tracking mode.
    /// Allows owner (<see cref="DataObject"/> instance
    /// that contains the field) to track changes through
    /// its <see cref="DataObject.VersionID"/> field.
    /// This means that owner's <see cref="DataObject.VersionID"/>
    /// will be increased on any change made to field.
    /// Value is <see langword="0"/>. 
    /// </summary>
    Default = 0,
    /// <summary>
    /// Allows owner (<see cref="DataObject"/> instance
    /// containing the field) to track changes through
    /// its <see cref="DataObject.VersionID"/> field.
    /// This means that owner's <see cref="DataObject.VersionID"/>
    /// will be increased on any change made to field.
    /// Value is <see langword="0"/>. 
    /// </summary>
    ThroughOwner = 0,
    /// <summary>
    /// Changes are tracked independently of owner 
    /// (<see cref="DataObject"/> instance containing the field), 
    /// that means its <see cref="DataObject.VersionID"/> won't
    /// be increased on changes in collection field.
    /// You can this mode to decrease the level of concurrency,
    /// but in this case any cached contents of collection
    /// will be invalidated on the completion of each new outermost 
    /// transaction (rather then only on changes of owner's 
    /// <see cref="DataObject.VersionID"/>).
    /// Value is <see langword="1"/>. 
    /// </summary>
    Independently = 1,
  }
}
