// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System.Diagnostics;

namespace DataObjects.NET.Diagnostics
{
  internal class PerformanceCounterWrapper : IPerformanceCounter
  {
    private PerformanceCounter perfomanceCounter;

    public string CategoryName
    {
      get { return perfomanceCounter.CategoryName; }
      set { perfomanceCounter.CategoryName = value; }
    }

    public string CounterHelp
    {
      get { return perfomanceCounter.CounterHelp; }
    }

    public string CounterName
    {
      get { return perfomanceCounter.CounterName; }
      set { perfomanceCounter.CounterName = value; }
    }

    public PerformanceCounterType CounterType
    {
      get { return perfomanceCounter.CounterType; }
    }

    public string InstanceName
    {
      get { return perfomanceCounter.InstanceName; }
      set { perfomanceCounter.InstanceName = value; }
    }

    public bool ReadOnly
    {
      get { return perfomanceCounter.ReadOnly; }
      set { perfomanceCounter.ReadOnly = value; }
    }

    public string MachineName
    {
      get { return perfomanceCounter.MachineName; }
      set { perfomanceCounter.MachineName = value; }
    }

    public long RawValue
    {
      get { return perfomanceCounter.RawValue; }
      set { perfomanceCounter.RawValue = value; }
    }

    public void Close()
    {
      perfomanceCounter.Close();
    }

    public long Decrement()
    {
      return perfomanceCounter.Decrement();
    }

    public long IncrementBy(long value)
    {
      return perfomanceCounter.IncrementBy(value);
    }

    public long Increment()
    {
      return perfomanceCounter.Increment();
    }

    public CounterSample NextSample()
    {
      return perfomanceCounter.NextSample();
    }

    public float NextValue()
    {
      return perfomanceCounter.NextValue();
    }

    public void RemoveInstance()
    {
      perfomanceCounter.RemoveInstance();
    }
    

    // Constructors

    public PerformanceCounterWrapper(
      string categoryName,
      string counterName,
      string instanceName
      )
    {
      perfomanceCounter = new PerformanceCounter(categoryName,counterName,instanceName,false);
      // perfomanceCounter.RawValue = 0;
    }
  }
}
