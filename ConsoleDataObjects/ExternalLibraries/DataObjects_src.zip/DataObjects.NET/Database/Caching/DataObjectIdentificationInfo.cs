// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;

namespace DataObjects.NET.Database
{
  /// <summary>
  /// Holds the <see cref="DataObject.ID"/> value for the the 
  /// <see cref="DataObject"/> instance that will be instantiated
  /// further and possibly a reference to the instance.
  /// </summary>
  public class DataObjectIdentificationInfo
  {
    /// <summary>
    /// Real object or <see langword="null"/> (if it wasn't instantiated yet).
    /// </summary>
    public DataObject RealObject;
    /// <summary>
    /// <see cref="DataObject.ID"/> property value.
    /// </summary>
    public long   ID;

    /// <summary>
    /// Returns estimated size of this object in bytes.
    /// </summary>
    public virtual int Size {
       get { 
         return 12; 
       }
    }
    
    
    // Constructors

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    public DataObjectIdentificationInfo()
    {
    }
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="id">Initial <see cref="ID"/> value.</param>
    public DataObjectIdentificationInfo(long id)
    {
      this.ID = id;
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="realObject">Initial <see cref="RealObject"/> value.</param>
    /// <remarks>
    /// This contructor assigns a value to <see cref="ID"/> property also.
    /// </remarks>
    public DataObjectIdentificationInfo(DataObject realObject)
    {
      this.ID = (long)realObject.GetProperty("ID",null);
      this.RealObject = realObject;
    }
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="id">Initial <see cref="ID"/> value.</param>
    /// <param name="realObject">Initial <see cref="RealObject"/> value.</param>
    /// <remarks>
    /// This contructor assigns a value to <see cref="ID"/> property also.
    /// </remarks>
    public DataObjectIdentificationInfo(long id, DataObject realObject)
    {
      this.ID = id;
      this.RealObject = realObject;
    }
  }
}
