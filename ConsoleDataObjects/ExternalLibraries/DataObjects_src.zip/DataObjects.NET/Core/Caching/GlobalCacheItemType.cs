// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license

using System;
using DataObjects.NET.Database;

namespace DataObjects.NET.Caching
{
  /// <summary>
  /// Enumerates possible types of <see cref="GlobalCache"/> items.
  /// </summary>
  public enum GlobalCacheItemType
  {
    /// <summary>
    /// <see cref="DataObject"/> instance (<see cref="DataObjectInstantiationInfo"/>).
    /// </summary>
    DataObjectInstance,
    /// <summary>
    /// Load-on-demand field.
    /// </summary>
    LoadOnDemandField,
    /// <summary>
    /// <see cref="DataObjectCollection"/> items.
    /// </summary>
    DataObjectCollection,
    /// <summary>
    /// <see cref="ValueTypeCollection"/> items.
    /// </summary>
    ValueTypeCollection
  }
}
