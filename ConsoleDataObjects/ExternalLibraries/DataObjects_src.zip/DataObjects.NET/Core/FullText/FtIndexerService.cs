// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using DataObjects.NET;
using DataObjects.NET.Attributes;
using DataObjects.NET.FullText;

namespace DataObjects.NET.FullText
{
  /// <summary>
  /// A service that runs full-text indexing for the
  /// specified driver.
  /// </summary>
  [ServiceType(DataServiceType.NonShared)]
  [Sealed]
  public abstract class FtIndexerService 
    : RuntimeService
  {
    private IFtIndexer indexerInstance;
    
    /// <summary>
    /// Gets the delay to make before the next execution.
    /// </summary>
    /// <param name="e">Exception thrown by previous <see cref="Execute"/> call, <see langword="null"/> if call succeeded.</param>
    /// <returns>delay.</returns>
    [Transactional(TransactionMode.Disabled)]
    public override TimeSpan GetDelay(Exception e)
    {
      return indexerInstance.GetDelay(e);
    }

    /// <summary>
    /// This method is invoked by <see cref="RuntimeServicePool"/> periodically
    /// (in the special thread and <see cref="Session"/>) to allow the 
    /// service to make its job.
    /// </summary>
    [Transactional(TransactionMode.Disabled)]
    public override void Execute()
    {
      indexerInstance.Execute();
    }
    
    /// <summary>
    /// Creats <see cref="FtRecord"/>s for all <see cref="IFtObject"/> instances
    /// that can provide full-text data but don't have correspondent 
    /// <see cref="FtRecord"/>s for some reasons. 
    /// </summary>
    /// <remarks>
    /// This method is potentially useful for upgrading form earlier versions.
    /// </remarks>
    public virtual void CreateFtRecords()
    {
      indexerInstance.CreateFtRecords();
    }
    
    /// <summary>
    /// Removes all <see cref="FtRecord"/>s which don't have corresponding
    /// <see cref="IFtObject"/> instances. Normally full-text indexer
    /// removes such <see cref="FtRecord"/>s in one or several iterations. 
    /// But in case when it is required to remove all such <see cref="FtRecord"/>s
    /// immediately this method may be used.
    /// </summary>
    /// <remarks>
    /// This method is potentially useful for upgrading form earlier versions.
    /// </remarks>
    public virtual void CleanupFtRecords()
    {
      indexerInstance.CleanupFtRecords();
    }
    
    /// <summary>
    /// Updates all full-text data which is not up-to-date.
    /// Normally full-text indexer updates full-text data in one or several
    /// iterations. But in case when it is necessary to update all full-text
    /// data immediately this method may be used.
    /// </summary>
    /// <remarks>
    /// This method is potentially useful for upgrading form earlier versions.
    /// </remarks>
    public virtual void UpdateIndex()
    {
      indexerInstance.UpdateIndex();
    }
    
    /// <summary>
    /// Invalidates all full-text data. Sets <see cref="IFtObject.FtRecordIsUpToDate"/>
    /// to <see langword="false"/> for all <see cref="IFtObject"/> objects.
    /// </summary>
    /// <remarks>
    /// This method is potentially useful for upgrading form earlier versions.
    /// </remarks>
    public virtual void InvalidateIndex()
    {
      indexerInstance.InvalidateIndex();
    }
    
    /// <summary>
    /// Provides a way to use <see cref="SessionBoundObject.CreateSecurityDisabler"/> method
    /// for the contained indexer.
    /// </summary>
    /// <param name="indexerInstance">Contained indexer to check whether it is caller.</param>
    [Transactional(TransactionMode.Disabled)]
    public IDisposable CreateSecurityDisabler (IFtIndexer indexerInstance)
    {
      if (this.indexerInstance!=indexerInstance)
        throw new InvalidOperationException("Only contained indexer may initiate security disabling.");
      return this.CreateSecurityDisabler();
    }
    
    // Constructors

    /// <summary>
    /// Initializes an instance of this class.
    /// </summary>
    /// <param name="indexerInstance">An instance of the indexer for the certain driver.</param>
    [Transactional(TransactionMode.Disabled)]
    protected virtual void OnCreate(IFtIndexer indexerInstance)
    {
      this.indexerInstance = indexerInstance;
      indexerInstance.SetContainerService(this);
    }
  }
}
