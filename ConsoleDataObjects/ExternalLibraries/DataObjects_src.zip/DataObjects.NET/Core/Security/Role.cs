// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.IO;
using System.Threading;
using System.Configuration;
using System.Diagnostics;
using System.Globalization;
using System.Collections;
using DataObjects.NET;
using DataObjects.NET.Attributes;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Security.Permissions;

namespace DataObjects.NET.Security
{
  /// <summary>
  /// Represents security role (group).
  /// <see langword="Persistent"/>.
  /// </summary>
  /// <remarks>
  /// <para>
  /// You can find more information about the whole DataObjects.NET
  /// security system <see cref="AccessControlList">here</see>.
  /// </para>
  /// </remarks>
  public abstract class Role: Principal
  {
    /// <summary>
    /// <see langword="Persistent"/>.
    /// Principals that forms this role.
    /// </summary>
    [ItemType(typeof(Principal))]
    [PairTo(typeof(Principal),"Roles")]
    public PrincipalCollection Principals {
      get {return (PrincipalCollection)GetProperty("Principals", null);}
    }

    /// <summary>
    /// Always <see langword="true"/>.
    /// </summary>
    [NotPersistent]
    public override bool IsRole {
      get {
        return true;
      }
    }

    /// <summary>
    /// Gets the type of the principal.
    /// </summary>
    [NotPersistent]
    public override PrincipalType PrincipalType {
      get {
        string name;
        DisableSecurity();
        try {
          name = (string)GetProperty("Name", null);
        }
        finally {
          EnableSecurity();
        }
        SystemObjectNames names = session.domain.systemObjectNames;
        if (name==names.administratorsRoleName)
          return PrincipalType.AdministratorsRole;
        if (name==names.usersRoleName)
          return PrincipalType.UsersRole;
        if (name==names.guestsRoleName)
          return PrincipalType.GuestsRole;
        if (name==names.everyoneRoleName)
          return PrincipalType.EveryoneRole;
        return PrincipalType.Normal;
      }
    }
    

    // Event handlers

    /// <summary>
    /// Called when inner content of some non-<see cref="ValueType"/> 
    /// property was changed.
    /// </summary>
    /// <param name="name">Property name.</param>
    /// <param name="culture">Property culture.</param>
    /// <param name="value">Old property value.</param>
    /// <remarks>
    /// <para>
    /// This method doesn't allows to modify <see cref="Principal.Roles"/>
    /// collection of Everyone <see cref="Role"/>.
    /// </para>
    /// <para>
    /// See <see cref="DataObject.OnPropertyContentChanging"/> method description
    /// for additional information.
    /// </para>
    /// </remarks>
    protected override void OnPropertyContentChanging(string name, Culture culture, object value)
    {
      if (name=="Roles") {
        if (PrincipalType==PrincipalType.EveryoneRole)
          if (session.domain.status!=DomainStatus.InitializingSystemObjects)
            throw new SecurityException("Can't modify Roles collection of Everyone Role.");
      }
      base.OnPropertyContentChanging(name, culture, value);
    }
  }
}
