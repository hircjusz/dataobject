// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.IO;
using System.Text;
using System.Threading;
using System.Collections;
using System.Collections.Specialized;
using System.Data;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Attributes;

namespace DataObjects.NET
{
  /// <summary>
  /// Base class for all types requiring DataObjects.NET-generated 
  /// runtime proxy to function properly.
  /// </summary>
  public abstract class TransactionalObject: SessionBoundObject
  {
    // Constructors

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    internal TransactionalObject()
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="session">Session, to which current instance should be bound.</param>
    internal TransactionalObject(Session session): base(session)
    {
    }
  }
}
