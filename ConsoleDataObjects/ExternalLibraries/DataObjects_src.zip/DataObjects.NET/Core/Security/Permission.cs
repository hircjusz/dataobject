// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.IO;
using System.Threading;
using System.Configuration;
using System.Diagnostics;
using System.Globalization;
using System.Collections;
using DataObjects.NET;
using DataObjects.NET.Attributes;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Security.Permissions;

namespace DataObjects.NET.Security
{
  /// <summary>
  /// Base class for any security permission.
  /// Note that any security permission type should be marked 
  /// by <see cref="SerializableAttribute"/>.
  /// <seealso cref="IPermission"/>
  /// <seealso cref="IPermissionSet"/>
  /// <seealso cref="PermissionSet"/>
  /// </summary>
  /// <remarks>
  /// <para>
  /// You can find more information about the whole DataObjects.NET
  /// security system <see cref="AccessControlList">here</see>.
  /// </para>
  /// </remarks>
  [Serializable]
  public abstract class Permission: Object,
    IPermission
  {
    /// <summary>
    /// Creates and returns an identical copy of the current permission.
    /// </summary>
    /// <returns>A copy of the current permission.</returns>
    public IPermission Copy()
    {
      return (IPermission)MemberwiseClone();
    }

    /// <summary>
    /// Gets a collection of <see cref="IPermission"/>s that "grants"
    /// the current permission implicitly. This means that presence
    /// of any of these permissions automatically grants the
    /// current permission.
    /// </summary>
    /// <remarks>
    /// <para>
    /// The implementation of this property in this type always returns
    /// <see langword="null"/>.
    /// See <see cref="IPermission.GrantedIfGrantedAnyOf"/> property description
    /// for additional information.
    /// </para>
    /// </remarks>
    public virtual ReadOnlyPermissionCollection GrantedIfGrantedAnyOf {
      get {return null;}
    }
  
    /// <summary>
    /// Demands the permission.
    /// </summary>
    /// <param name="instance">Object to demand the permission for.</param>
    /// <remarks>
    /// This method throws <see cref="SecurityException"/> if the pemission
    /// isn't allowed for the specified instance and the active user in the 
    /// <see cref="Session"/>.
    /// </remarks>
    public void Demand(ISecureObject instance)
    {
      instance.Demand(this);
    }

    /// <summary>
    /// Checks if the permission is allowed for the specified isntance and 
    /// active user in the <see cref="Session"/>.
    /// </summary>
    /// <param name="instance">Object to demand the permission for.</param>
    /// <returns><see langword="True"/> if the permission is allowed; 
    /// otherwise, <see langword="false"/>.</returns>
    public bool IsAllowed(ISecureObject instance)
    {
      return instance.IsAllowed(this);
    }
  }
}
