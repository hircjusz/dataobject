// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;
using System.ComponentModel;
using System.Configuration.Install;
using DataObjects.NET.Diagnostics;

namespace DataObjects.NET.Install
{
  /// <summary>
  /// DataObjects.NET installer.
  /// Currently installer is used only to install\uninstall
  /// DataObjects.NET performance counters.
  /// </summary>
  [RunInstaller(true)]
  public class Installer: System.Configuration.Install.Installer
  {
    private System.ComponentModel.Container components = null;

    /// <summary> 
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing )
    {
      if (disposing) {
        if (components != null) {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }


    #region Component Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      components = new System.ComponentModel.Container();
    }
    #endregion

    /// <summary>
    /// Performs installation.
    /// </summary>
    /// <param name="stateSaver">An <see cref="IDictionary"/> used to save information needed to perform a commit, rollback, or uninstall operation.</param>
    public override void Install(IDictionary stateSaver) 
    {
      base.Install(stateSaver);
      DomainPerformanceCounters.Install();
    }

    /// <summary>
    /// Performs uninstallation.
    /// </summary>
    /// <param name="savedState"></param>
    public override void Uninstall(IDictionary savedState) 
    {
      base.Uninstall(savedState);
      DomainPerformanceCounters.UnInstall();
    }
    

    // Constructors

    /// <summary>
    /// Creates a new instance of this class.
    /// </summary>
    public Installer()
    {
      // This call is required by the Designer.
      InitializeComponent();

      // TODO: Add any initialization after the InitializeComponent call
    }
  }
}
