// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Runtime.Serialization;
using DataObjects.NET.Database;

namespace DataObjects.NET.Exceptions
{
  /// <summary>
  /// Thrown by <see cref="Persister"/> when deadlock takes place.
  /// <seealso cref="TransactionCanBeReprocessedException"/>
  /// <seealso cref="UpdateConflictException"/>
  /// <seealso cref="InstanceVersionChangedException"/>
  /// <seealso cref="Session.ReprocessingAttemptsCount"/>
  /// <seealso cref="Session.ReprocessingDelay"/>
  /// </summary>
  [Serializable]
  public class DeadlockException: TransactionCanBeReprocessedException
  {
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="innerException">Inner exception.</param>
    public DeadlockException(Exception innerException): base(innerException.Message,innerException) 
    {
    }
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="text">Text of message.</param>
    /// <param name="innerException">Inner exception.</param>
    public DeadlockException(string text, Exception innerException): base(text,innerException) 
    {
    }
    
    /// <summary>
    /// Deserialization constructor.
    /// </summary>
    /// <param name="info"><see cref="SerializationInfo"/> object.</param>
    /// <param name="context"><see cref="StreamingContext"/> object.</param>
    protected DeadlockException(SerializationInfo info, StreamingContext context):
      base(info, context)
    {
    }
  }
}
