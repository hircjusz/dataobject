// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;

namespace DataObjects.NET.Attributes
{
  /// <summary>
  /// Indicates that property is allowed to store a referance to its instance
  /// (persistent instance to which property belongs).
  /// </summary>
  /// <remarks>
  /// <note>This attribute can be applied to persistent properties
  /// of <see cref="DataObject"/> or <see cref="DataObjectCollection"/> type.</note>
  /// <para>
  /// <example>Example:
  /// <code lang="C#">
  ///  public abstract class Person: DataObject
  ///  {
  ///    ...
  ///    
  ///    [SelfReferenceAllowed] // A person can be a best friend of itself :)
  ///    [ItemType(typeof(Person))]
  ///    public abstract Person BestFriend {get;}
  ///
  ///    [SelfReferenceAllowed] // A person can be a friend of itself :)
  ///    [Symmetric]
  ///    [ItemType(typeof(Person))]
  ///    public abstract DataObjectCollection Friends {get;}
  ///
  ///    ...
  ///  }
  /// </code>
  /// </example>
  /// </para>
  /// <seealso cref="ContainedAttribute"/>
  /// <seealso cref="PairToAttribute"/>
  /// <seealso cref="SymmetricAttribute"/>
  /// </remarks>
  [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field, 
    AllowMultiple = false, Inherited = true)]
  [Serializable]
  public class SelfReferenceAllowedAttribute: DataObjectAttribute
  {
    private bool selfReferenceAllowed = true;
    /// <summary>
    /// <see langword="True"/> if property is allowed to store a referance to its instance
    /// (persistent instance to which property belongs).
    /// </summary>
    public  bool SelfReferenceAllowed
    {
      get {return selfReferenceAllowed;}
      set {selfReferenceAllowed = value;}
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    public SelfReferenceAllowedAttribute() 
    {
    }
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="selfReferenceAllowed"><see langword="True"/> if property is allowed to store a referance to its instance.</param>
    public SelfReferenceAllowedAttribute(bool selfReferenceAllowed) 
    {
      this.selfReferenceAllowed = selfReferenceAllowed;
    }
  }
}
