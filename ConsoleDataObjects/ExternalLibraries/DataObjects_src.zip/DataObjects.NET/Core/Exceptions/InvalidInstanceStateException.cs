// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Runtime.Serialization;

namespace DataObjects.NET.Exceptions
{
  /// <summary>
  /// Thrown by some <see cref="DataObject"/> methods when 
  /// instance <see cref="DataObject.State"/> is illegal.
  /// Basically state considered to be illegal when 
  /// it is not equals to <see cref="DataObjectState">DataObjectState.Persistent</see>.
  /// </summary>
  [Serializable]
  public class InvalidInstanceStateException: DataObjectsDotNetException
  {
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    public InvalidInstanceStateException(): base("Invalid instance state.") {}
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="text">Text of message.</param>
    public InvalidInstanceStateException(string text): base(text) {}

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    public InvalidInstanceStateException(DataObject o): this("Invalid instance state: "+o.State.ToString()+".") {}
    
    /// <summary>
    /// Deserialization constructor.
    /// </summary>
    /// <param name="info"><see cref="SerializationInfo"/> object.</param>
    /// <param name="context"><see cref="StreamingContext"/> object.</param>
    protected InvalidInstanceStateException(SerializationInfo info, StreamingContext context):
      base(info, context)
    {
    }
  }
}
