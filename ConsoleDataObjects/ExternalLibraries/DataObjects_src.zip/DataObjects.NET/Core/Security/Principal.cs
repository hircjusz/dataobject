// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Data;
using System.Collections;
using System.Runtime.Serialization;
using DataObjects.NET;
using DataObjects.NET.Attributes;
using DataObjects.NET.Exceptions;
using DataObjects.NET.FullText;
using DataObjects.NET.Serialization;
using DataObjects.NET.Security.Permissions;
using Helpers = DataObjects.NET.Helpers;

namespace DataObjects.NET.Security
{
  /// <summary>
  /// Base class for any security principal (e.g. <see cref="User"/>, 
  /// <see cref="Role"/> classes are its descendatns).
  /// <see langword="Persistent, Abstract"/>.
  /// </summary>
  /// <remarks>
  /// <para>
  /// You can find more information about the whole DataObjects.NET
  /// security system <see cref="AccessControlList">here</see>.
  /// </para>
  /// </remarks>
  [Abstract]
  public abstract class Principal: FtObject
  {
    /// <summary>
    /// <see langword="Persistent"/>.
    /// Gets or sets the name of the security principal.
    /// </summary>
    /// <remarks>
    /// Name is used to identify the security principal an must
    /// be unique in the storage scope.
    /// </remarks>
    [Length(128)]
    [Length(83, DriverTypes="Firebird")] // Firebird - specific declaration
    [Indexed(Unique=true)]
    public string Name {
      get {return (string)GetProperty("Name", null);}
      set {SetProperty("Name", null, value);}
    }
    
    /// <summary>
    /// <see langword="Persistent"/>.
    /// Gets or sets the description of the security principal.
    /// </summary>
    [SqlType(SqlType.Text)]
    public string Description {
      get {return (string)GetProperty("Description", null);}
      set {SetProperty("Description", null, value);}
    }
    
    /// <summary>
    /// <see langword="Persistent"/>.
    /// Gets the collection of <see cref="Role"/>s of the 
    /// security principal.
    /// </summary>
    /// <remarks>
    /// Any security principal can belong to the set of <see cref="Role"/>s.
    /// Note, that <see cref="Role"/> is a <see cref="Principal"/> too,
    /// so any <see cref="Role"/> can belong to the set of <see cref="Role"/>s
    /// correspondingly. So it can be necessary to find all <see cref="Role"/>s
    /// to which the current <see cref="Principal"/> belongs directly or
    /// indirectly - <see cref="AllRoles"/> property provides this information.
    /// </remarks>
    [ItemType(typeof(Role))]
    public RoleCollection Roles {
      get {return (RoleCollection)GetProperty("Roles", null);}
    }
    
    
    // Non-persistent properties and methods

    /// <summary>
    /// Gets the type of the security principal.
    /// </summary>
    [NotPersistent]
    public virtual PrincipalType PrincipalType {
      get {
        return PrincipalType.Normal;
      }
    }
    
    /// <summary>
    /// <see langword="True"/> if this principal 
    /// is a <see cref="Role">role</see>.
    /// </summary>
    [NotPersistent]
    public virtual bool IsRole {
      get {
        return false;
      }
    }
    
    /// <summary>
    /// <see langword="True"/> if this principal belongs to specified 
    /// <paramref name="role"/> (directly or indirectly).
    /// </summary>
    /// <param name="role"><see cref="Role"/> to check.</param>
    /// <returns><see langword="True"/> if this principal belongs to specified 
    /// <paramref name="role"/>.</returns>
    /// <remarks>
    /// This method checks if current <see cref="Principal"/> is contained
    /// in the <see cref="AllRoles"/> collection. Actually successive checks
    /// are very fast, because of <see cref="AllRoles"/> results caching.
    /// </remarks>
    [NotOverridable]
    [Transactional(TransactionMode.TransactionRequired)]
    public virtual bool IsInRole(Role role)
    {
      if (session.user!=this)
        Demand(AdministrationPermission.Value);
      return InternalIsInRole(role);
    }
    
    // This method is called by some of DataObjects.NET security system
    // methods, so it should be possible to invoke it for DataObjects.NET
    // without any permission demands.
    [Transactional(TransactionMode.Disabled)] // This method is always called 
                                              // from transactional methods
    internal bool InternalIsInRole(Role role)
    {
      Role[] unused = InternalAllRoles; // Just to update cached data
      return cachedAllRolesHT[role]!=null;
    }

    /// <summary>
    /// Returns an array containing all <see cref="Roles"/> this security 
    /// principal is belongs to (directly or indirectly).
    /// There is no duplicates in the result array.
    /// </summary>
    /// <remarks>
    /// <para>
    /// This property returns not only the <see cref="Role"/>s contained
    /// in the <see cref="Roles"/> collection, but also all <see cref="Role"/>s
    /// these <see cref="Roles"/> belongs to (recursively).
    /// </para>
    /// <para>
    /// Exactly this property returns an array, that contains all 
    /// <see cref="Roles"/> and <see cref="Principal.AllRoles">all roles</see>
    /// of them.
    /// </para>
    /// <para>
    /// There is no duplicates in the result array.
    /// </para>
    /// <para>
    /// Successive checks of this method are very fast, because the value of
    /// this property is cached once this property was evaluated first time.
    /// Nevertheless you can be sure that you're always getting a correct
    /// set of <see cref="AllRoles"/> - e.g. if you'll add some <see cref="Role"/>
    /// to the <see cref="Roles"/> collection of one of <see cref="AllRoles"/>
    /// this role belongs too, cached value of this property will be
    /// invaludated, and a new <see cref="AllRoles"/> set will be computed
    /// on the next attempt to read this property.
    /// </para>
    /// </remarks>
    [NotPersistent]
    [NotOverridable]
    [Transactional(TransactionMode.TransactionRequired)]
    public virtual Role[] AllRoles {
      get {
        if (session.user!=this)
          Demand(AdministrationPermission.Value);
        Role[] allRoles = InternalAllRoles;
        // We should return a duplicate - to prevent its modification
        int cnt = allRoles.Length;
        Role[] allRolesCopy = new Role[cnt];
        for (int i = 0; i<cnt; i++)
          allRolesCopy[i] = allRoles[i];
        return allRolesCopy;
      }
    }
    
    // This property is used by some of DataObjects.NET security system
    // methods, so it should be possible to invoke it for DataObjects.NET
    // without any permission demands.
    [NotPersistent]
    [Transactional(TransactionMode.Disabled)] // This method is always called 
                                              // from transactional methods
    internal Role[] InternalAllRoles {
      get {
        // First we should update current TransactionContext.
        if (State==DataObjectState.Removed)
          throw new InstanceIsRemovedException();
        if (cachedAllRolesTransactionContext!=null) {
          if (cachedAllRolesTransactionContext==transactionContext)
            return cachedAllRoles; // Cached data is OK.
          switch (cachedAllRolesTransactionContext.State) {
          case TransactionContextState.Valid:
            cachedAllRolesTransactionContext = transactionContext;
            return cachedAllRoles; // Cached data is OK.
          case TransactionContextState.BelongsToAnotherOutermostTransaction:
            CheckAllRolesCache(); // Simply a faster check, then AcquireAllRolesCache
            return cachedAllRoles;
          }
        }
        // Otherwise we should update cached data
        AcquireAllRolesCache();
        return cachedAllRoles;
      }
    }
    
    /// <summary>
    /// Returns string containing composite full-text 
    /// data for the specified <see cref="Culture"/>.
    /// </summary>
    /// <param name="culture"><see cref="Culture"/> to return full-text data for.</param>
    /// <returns>Composite full-text data for the specified <see cref="Culture"/>.</returns>
    public override string ProduceFtData(Culture culture)
    {
      return 
        this.Name + ": " +
        this.Description;
    }


    // AllRoles caching - related fields and methods

    private   Helpers.EventSource rolesChangedEventSource;
    private   EventHandler        rolesChangedCallbackEventHandler;
    private   Hashtable    cachedAllRolesHT;
    private   long[]       cachedAllRolesIDs;
    private   Role[]       cachedAllRoles;
    private   TransactionContext cachedAllRolesTransactionContext;
    
    /// <summary>
    /// This method is invoked on any changes in <see cref="Roles"/>
    /// collection of this principal, or when the same method is
    /// invoked on dependent <see cref="Principal"/>s.
    /// Normally you shouldn't invoke it manually.
    /// </summary>
    [NotOverridable]
    [Transactional(TransactionMode.Disabled)]
    protected virtual void RolesChanged()
    {
      if (cachedAllRolesTransactionContext==null)
        return; // Prevents possible recursion
      // First we should mark cached data as invalidated
      cachedAllRolesTransactionContext = null;
      // Let's notify dependent Principals about this occasion -
      // to propagate the notification to all "indirectly dependent"
      // objects.
      if (rolesChangedEventSource!=null)
        rolesChangedEventSource.RaiseEvent(this, null); 
      // And finaly let's notify SecurityRoot object - because
      // AllRoles change affects on permissions :)
      if (session.user==this)
        session.SecurityRoot.PermissionsChanged();
      // It seems that after reading AcquireAllRolesCache method
      // description you'll completely understand how to 
      // implement your own caching and some of DataObjects.NET
      // internals :)
    }
    private void RolesChangedCallback(object sender, EventArgs e)
    {
      RolesChanged();
    }
    // Used to keep a strong reference to EventHandler(this.PermissionsChangedCallbackMethod)
    internal EventHandler RolesChangedCallbackEventHandler {
      get {
        if (rolesChangedCallbackEventHandler==null)
          rolesChangedCallbackEventHandler = new EventHandler(this.RolesChangedCallback);
        return rolesChangedCallbackEventHandler;
      }
    }


    /// <summary>
    /// Produces cached <see cref="AllRoles"/> value (if this is necessary).
    /// If you're interested on how to implement completely transparent
    /// property value caching, check out the code of this method
    /// (the code of this class is shipped with DataObjects.NET 2.0). 
    /// </summary>
    /// <remarks>
    /// <para>
    /// The most difficult part in property value caching implementation is that
    /// cached value should be invalidate on any changes that makes it
    /// obsolete (i.e. if we recompute a new property value after 
    /// such changes, it can be different in comparison with the cached 
    /// value).
    /// </para>
    /// <para>
    /// Key concepts of <see cref="AllRoles"/> caching implementation:
    /// </para>
    /// 1) <see cref="AllRoles"/> and <see cref="IsInRole"/> methods properly
    ///    checks, if there is a cached value of this property exist. They
    ///    use this value in such case, or invoke this method to evaluate a new
    ///    cached value to use.
    /// <para>
    /// 2) This method evaluates cached data for <see cref="AllRoles"/>
    ///    property (an <see cref="Array"/> + <see cref="Hashtable"/>).
    ///    Any <see cref="Principal"/> has "roles changed" <see cref="Helpers.EventSource"/>,
    ///    (so any principal acts as "event source" of this event)
    ///    that can be used by any dependent principal to be notified on changes
    ///    in source's <see cref="AllRoles"/> data. This method subscribes current
    ///    principal on all such events of any <see cref="Role"/> instance that 
    ///    is located in its <see cref="Roles"/> collection. 
    ///    This allows current instance to be notified when any of dependent 
    ///    <see cref="Roles"/> will be changed in the way that affects on 
    ///    the cached value. 
    /// </para>
    /// <para>
    ///    Notice, that here one key thing is used: while some <see cref="Role"/> 
    ///    is cached (i.e. a reference to it is stored in the cached array), 
    ///    DataObjects.NET will use its instance always when
    ///    the object with its <see cref="DataObject.ID"/> is required (this is
    ///    one of key DataObjects.NET principals - only one instance with a 
    ///    particular <see cref="DataObject.ID"/> can exist in particular
    ///    <see cref="Session"/>).
    /// </para>
    /// <para>
    ///    This means that it's impossible to change a <see cref="Role"/> with this
    ///    <see cref="DataObject.ID"/> without using this object. Also even if you're
    ///    operating on <see cref="IsolationLevel.ReadCommitted"/> isolation level,
    ///    this object will be used to represent itself after possible 
    ///    <see cref="DataObject.Reload"/>.
    ///    So even if instance will be reloaded (because of operation on 
    ///    <see cref="IsolationLevel.ReadCommitted"/> or a transaction
    ///    <see cref="Transaction.Rollback"/>), it will be "notified" about this
    ///    event, and will inform all dependent objects (see e.g. <see cref="OnLoad"/>
    ///    method).
    /// </para>
    /// <para>
    /// 3) <see cref="Principal"/> event handlers (see <see cref="Principal">OnXXX</see>
    ///    method) raises "roles changed" event on any changes that can affect on
    ///    cached <see cref="AllRoles"/> value of subscribers.
    /// </para>
    /// <para>
    /// That's all - you can use the same idea to implement your own property
    /// caching anywhere where it's necessary.
    /// </para>
    /// <para>
    /// DataObjects.NET internally uses almost the same schema to cache
    /// instance's effective permission sets.
    /// </para>
    /// <note type="note">Sometimes it can be necessary to implement
    /// caching that doesn't prevents to .NET Framework unload any objects
    /// (to collect them by a garbage collector).
    /// The background idea of such type of cahing is that we should 
    /// implement finalizers notifying all dependent instances during the 
    /// finalization.
    /// </note>
    /// <para>
    /// Check out <see cref="Helpers.EventSource"/> description - this class allows
    /// to implement event notification mechanism, that was used here.
    /// And - happy caching :)
    /// </para>
    /// </remarks>
    private void AcquireAllRolesCache() 
    {
      Hashtable h = new Hashtable();
      ArrayList a = new ArrayList();
      RoleCollection roles;

      DisableSecurity();
      try {
        roles = Roles;
      }
      finally {
        EnableSecurity();
      }
      
      roles.Preload();
      foreach (Role r in roles) {
        if (h[r]==null) {
          h[r] = r;
          a.Add(r);
          if (r.rolesChangedEventSource==null)
            r.rolesChangedEventSource = new Helpers.EventSource();
          r.rolesChangedEventSource.Subscribe(RolesChangedCallbackEventHandler);
        }
      }
      foreach (Role r in roles) {
        foreach (Role r1 in r.InternalAllRoles) {
          if (h[r1]==null) {
            h[r1] = r1;
            a.Add(r1);
          }
        }
      }
      {
        Role r = Session.SystemObjects.EveryoneRole;
        if (r!=null && h[r]==null) {
          h[r] = r;
          a.Add(r);
        }
      }
      cachedAllRolesHT = h;
      cachedAllRoles   = (Role[])a.ToArray(typeof(Role));
      int cnt = cachedAllRoles.Length;
      cachedAllRolesIDs = new long[cnt];
      for (int i = 0; i<cnt; i++)
        cachedAllRolesIDs[i] = cachedAllRoles[i].ID;
      cachedAllRolesTransactionContext = transactionContext;
    }
    
    private void CheckAllRolesCache() 
    {
      session.Preload(cachedAllRolesIDs); // Fast group version check
      int cnt = cachedAllRoles.Length;
      for (int i = 0; i<cnt; i++)
        if (cachedAllRoles[i].State==DataObjectState.Removed) {
          cachedAllRolesTransactionContext = null;
          AcquireAllRolesCache();
          return;
        }
      if (cachedAllRolesTransactionContext==null) {
        // It can be reseted to null during reload of some
        // role on cachedAllRoles[i].State read in prevoius loop.
        AcquireAllRolesCache();
        return;
      }
      // All is ok - nothing was changed
      cachedAllRolesTransactionContext = transactionContext;
    }


    // Constructors

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    protected Principal()
    {
    }
    
    /// <summary>
    /// A constructor analogue. Called on instance initialization.
    /// </summary>
    /// <remarks>
    /// <para>
    /// This constructor can't be used (it's necessary to specify
    /// initial <see cref="Principal"/>'s <see cref="Name"/> value, 
    /// you should always use the second constructor of this type), 
    /// so it always throws <see cref="InvalidOperationException"/>.
    /// </para>
    /// <para>
    /// See <see cref="DataObject.OnCreate"/> method description
    /// for additional information.
    /// </para>
    /// </remarks>
    [Transactional(TransactionMode.Disabled)]
    protected override void OnCreate()
    {
      throw new InvalidOperationException("This constructor can't be used with this type!");
    }
    
    /// <summary>
    /// A constructor analogue. Called on instance initialization.
    /// </summary>
    /// <param name="name">Initial <see cref="Name"/> value.
    /// Note that <see cref="Name"/> must be unique in the storage scope.</param>
    /// <remarks>
    /// <para>
    /// This method demands the following permissions:
    /// <see cref="AdministrationPermission"/>.
    /// </para>
    /// <para>
    /// See <see cref="DataObject.OnCreate"/> method description
    /// for additional information.
    /// </para>
    /// </remarks>
    [Transactional(TransactionMode.Disabled)]
    protected virtual void OnCreate(string name)
    {
      SetProperty("Name", null, name);
      base.OnCreate();
    }

    /// <summary>
    /// Perform custom actions after instance creation.
    /// Usually security permission <see cref="DataObject.Demand"/>s
    /// should be executed in it.
    /// </summary>
    [Transactional(TransactionMode.Disabled)]
    protected override void OnCreated()
    {
      Demand(AdministrationPermission.Value);
      base.OnCreated();
    }

    /// <summary>
    /// This method is similar to <see cref="OnCreate"/> method, but it 
    /// is invoked on newly created instance before its deserialization.
    /// </summary>
    /// <remarks>
    /// <para>
    /// This method demands the following permissions:
    /// <see cref="AdministrationPermission"/>.
    /// </para>
    /// <para>
    /// See <see cref="DataObject.OnCreateDeserializable"/> method description
    /// for additional information.
    /// </para>
    /// </remarks>
    protected override void OnCreateDeserializable()
    {
      SetProperty("Name", null, Guid.NewGuid().ToString());
      base.OnCreateDeserializable();
    }

    // Event handlers
    
    /// <summary>
    /// Called after instance is loaded.
    /// </summary>
    /// <remarks>
    /// <para>
    /// See <see cref="DataObject.OnLoad"/> method description
    /// for additional information.
    /// </para>
    /// </remarks>
    protected override void OnLoad(bool reload)
    {
      if (reload)
        RolesChanged();
      base.OnLoad(reload);
    }

    /// <summary>
    /// Called during <see cref="DataObject.GetProperty"/> method execution.
    /// </summary>
    /// <param name="name">Property name.</param>
    /// <param name="culture">Property culture.</param>
    /// <param name="value">Stored property value.</param>
    /// <returns>Property value to return.</returns>
    /// <remarks>
    /// <para>
    /// This method demands the following permissions:
    /// <see cref="AdministrationPermission"/> on attempt
    /// to read any property declared in <see cref="Principal"/>
    /// or its descendant.
    /// </para>
    /// <para>
    /// See <see cref="DataObject.OnGetProperty"/> method description
    /// for additional information.
    /// </para>
    /// </remarks>
    protected override object OnGetProperty(string name, Culture culture, object value)
    {
      switch (name) {
      case "FtDataIsUpToDate":
      case "FtRecord":
        return base.OnGetProperty(name, culture, value);
      default:
        Demand(AdministrationPermission.Value);
        return base.OnGetProperty(name, culture, value);
      }
    }

    /// <summary>
    /// Called during <see cref="DataObject.SetProperty"/> method execution.
    /// </summary>
    /// <param name="name">Property name.</param>
    /// <param name="culture">Property culture.</param>
    /// <param name="value">New property value.</param>
    /// <remarks>
    /// <para>
    /// This method demands the following permissions:
    /// <see cref="AdministrationPermission"/> for Name and Description fields,
    /// <see cref="OwnerPermission"/> for others.
    /// </para>
    /// <para>
    /// Additionaly it checks <see cref="Name"/> property value
    /// for uniqueness in the storage scope (only if it isn't equals to
    /// <see cref="String.Empty"/>). Note that <see cref="Name"/>
    /// property of system objects (see <see cref="PrincipalType"/>) 
    /// can be changed only during the system objects initialization
    /// period.
    /// </para>
    /// <para>
    /// See <see cref="DataObject.OnSetProperty"/> method description
    /// for additional information.
    /// </para>
    /// </remarks>
    protected override void OnSetProperty(string name, Culture culture, object value)
    {
      switch (name) {
      case "Name":
        Demand(AdministrationPermission.Value);
        if (PrincipalType!=PrincipalType.Normal)
          if (session.domain.status!=DomainStatus.InitializingSystemObjects)
            throw new SecurityException(
              "System security principal can be renamed only during the system " +
              "objects initialization period.");
        // In case of versionizing UNIQUE indexes are not supported.
        // So we should guarantee originality ourselfs.
        if ((Domain.DatabaseOptions & DomainDatabaseOptions.EnableVersionizing)!=0) {
          Query q = Session.CreateQuery("Select Principal instances where {$root.Name}=@Name");
          q.Parameters.Add(new QueryParameter("@Name", value));
          DataObject[] objs = q.ExecuteArray();
          if (objs!=null && objs.Length>0) {
            if (objs.Length!=1 || objs[0]!=this)
              throw new InvalidOperationException(
                String.Format("Principal with name \"{0}\" already exists.", value));
          }
        }
        base.OnSetProperty(name, culture, value);
        break;
      case "Description":
        Demand(AdministrationPermission.Value);
        break;
      case "FtDataIsUpToDate":
      case "FtRecord":
        base.OnSetProperty(name, culture, value);
        break;
      default:
        Demand(OwnerPermission.Value);
        base.OnSetProperty(name, culture, value);
        break;
      }
    }

    /// <summary>
    /// Called when inner content of some non-<see cref="ValueType"/> 
    /// property was changed.
    /// </summary>
    /// <param name="name">Property name.</param>
    /// <param name="culture">Property culture.</param>
    /// <param name="value">Old property value.</param>
    /// <remarks>
    /// <para>
    /// This method demands the following permissions:
    /// <see cref="AdministrationPermission"/>.
    /// </para>
    /// <para>
    /// See <see cref="DataObject.OnPropertyContentChanging"/> method description
    /// for additional information.
    /// </para>
    /// </remarks>
    protected override void OnPropertyContentChanging(string name, Culture culture, object value)
    {
      if (name!="Permissions")
        Demand(AdministrationPermission.Value);
      base.OnPropertyContentChanging(name, culture, value);
    }

    /// <summary>
    /// Called when inner content of some non-<see cref="ValueType"/> 
    /// property was changed.
    /// </summary>
    /// <param name="name">Property name.</param>
    /// <param name="culture">Property culture.</param>
    /// <param name="value">New property value.</param>
    /// <remarks>
    /// <para>
    /// See <see cref="DataObject.OnPropertyContentChanged"/> method description
    /// for additional information.
    /// </para>
    /// </remarks>
    protected override void OnPropertyContentChanged(string name, Culture culture, object value)
    {
      if (name=="Roles")
        RolesChanged();
      base.OnPropertyContentChanged(name, culture, value);
    }
    
    /// <summary>
    /// Serializes object identity, when object is serialized as reference.
    /// Override this method to add custom serializable identity to 
    /// your persistent type.
    /// <seealso cref="OnDeserializeIdentity"/>
    /// <seealso cref="Serializer"/>
    /// <seealso cref="SerializationOptions"/>
    /// <seealso cref="DeserializationOptions"/>
    /// </summary>
    /// <param name="serializer">Serializer that performs the serialization.</param>
    /// <param name="info">Serialization info.</param>
    /// <param name="context">Streaming context.</param>
    protected override void OnSerializeIdentity(Serializer serializer, SerializationInfo info, StreamingContext context) 
    {
      if (State!=DataObjectState.Removed)
        info.AddValue("Name", Name);
    }
    
    /// <summary>
    /// Converts serialized object identity to real <see cref="DataObject"/>
    /// instance. This method always called on so-called "null object"
    /// (see <see cref="Session.GetNullObject">Session.GetNullObject</see>).
    /// Override this method to add custom serializable identity to 
    /// your persistent type.
    /// <seealso cref="OnSerializeIdentity"/>
    /// <seealso cref="Serializer"/>
    /// <seealso cref="SerializationOptions"/>
    /// <seealso cref="DeserializationOptions"/>
    /// </summary>
    /// <param name="serializer">Serializer that performs the deserialization.</param>
    /// <param name="info">Serialization info.</param>
    /// <param name="context">Streaming context.</param>
    /// <returns><see cref="DataObject"/> instance that corresponds to
    /// serialized object identity, or <see langword="null"/>.</returns>
    protected internal override DataObject OnDeserializeIdentity(Serializer serializer, SerializationInfo info, StreamingContext context) 
    {
      long id = info.GetInt64("ID");
      if (id==0)
        return null;

      string name;
      try {
        name = info.GetString("Name");
      }
      catch {
        return Session[id]; // Old serialization format support code
      }

      SqlQuery q = Session.CreateSqlQuery(typeof(Principal));
      q.Condition = Domain.Utils.QuoteIdentifier("Name") + " = @Name";
      q.Parameters.Add("@Name", name);

      DataObject[] result = q.ExecuteArray();
      return result.Length==0 ? null : result[0];
    }

    /// <summary>
    /// Called before instance is serialized (see <see cref="Serializer"/> class).
    /// <seealso cref="Serializer"/>
    /// <seealso cref="SerializationOptions"/>
    /// <seealso cref="DeserializationOptions"/>
    /// </summary>
    /// <param name="serializer">Serializer that performs the serialization.</param>
    /// <param name="info">Serialization info.</param>
    /// <param name="context">Streaming context.</param>
    /// <param name="fields">A <see cref="Hashtable"/> initially containing pairs (Field name, <see langword="true"/>).
    /// You should set some values to <see langword="false"/> or <see langword="null"/> 
    /// in it to disable automatic serialization of corresponding field.
    /// E.g. you should clear it in case when you serialize all fields manually.</param>
    /// <remarks>
    /// <para>
    /// This method demands the following permissions:
    /// <see cref="AdministrationPermission"/>.
    /// </para>
    /// <para>
    /// See <see cref="DataObject.OnSerializing"/> method description
    /// for additional information.
    /// </para>
    /// </remarks>
    protected override void OnSerializing(Serializer serializer, 
      SerializationInfo info, StreamingContext context, Hashtable fields)
    {
      Demand(AdministrationPermission.Value);
      base.OnSerializing(serializer, info, context, fields);
    }
    
    /// <summary>
    /// Called when the whole object graph is completely deserialized.
    /// <seealso cref="Serializer"/>
    /// <seealso cref="SerializationOptions"/>
    /// <seealso cref="DeserializationOptions"/>
    /// </summary>
    /// <param name="serializer">Serializer that performs the deserialization.</param>
    /// <remarks>
    /// <para>
    /// This method demands the following permissions:
    /// <see cref="AdministrationPermission"/>.
    /// </para>
    /// <para>
    /// See <see cref="DataObject.OnGraphDeserialized"/> method description
    /// for additional information.
    /// </para>
    /// </remarks>
    protected override void OnGraphDeserialized(Serializer serializer)
    {
      RolesChanged();
      Demand(AdministrationPermission.Value);
      base.OnGraphDeserialized(serializer);
    }

    /// <summary>
    /// Called before instance is removed (see <see cref="DataObject.Remove"/> method).
    /// Override this method to perform custom actions before the removal 
    /// of instance.
    /// </summary>
    /// <remarks>
    /// <para>
    /// This method demands the following permissions:
    /// <see cref="AdministrationPermission"/>.
    /// Additionaly it checks <see cref="Domain.Status"/> and throws a
    /// <see cref="SecurityException"/> if it doesn't equal to 
    /// <see cref="DomainStatus.InitializingSystemObjects"/> and
    /// current principal is a system object (see <see cref="PrincipalType"/>).
    /// </para>
    /// <para>
    /// See <see cref="DataObject.OnRemove"/> method description
    /// for additional information.
    /// </para>
    /// </remarks>
    protected internal override void OnRemove()
    {
      if (PrincipalType!=PrincipalType.Normal)
        if (session.domain.status!=DomainStatus.InitializingSystemObjects)
          throw new SecurityException(
            "System security principal can be removed only during the system " +
            "objects initialization period.");
      Demand(AdministrationPermission.Value);
      base.OnRemove();
    }

    /// <summary>
    /// Called after instance is removed (see <see cref="DataObject.Remove"/> method).
    /// Override this method to perform custom actions after the removal 
    /// of instance.
    /// </summary>
    /// <remarks>
    /// <para>
    /// See <see cref="DataObject.OnRemoved"/> method description
    /// for additional information.
    /// </para>
    /// </remarks>
    protected internal override void OnRemoved()
    {
      RolesChanged();
      base.OnRemoved();
    }
  }
}
