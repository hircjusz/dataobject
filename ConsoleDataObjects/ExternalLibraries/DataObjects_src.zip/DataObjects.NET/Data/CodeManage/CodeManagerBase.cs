// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;

namespace DataObjects.NET.Data.CodeManage
{
  /// <summary>
  /// Base class for all code managers.
  /// </summary>
  internal abstract class CodeManagerBase
  {
    private bool isInitialized = false;
    private IInterfaceDescriptor[] interfaces;
    private IClassDescriptor[] classes;
    private IClassDescriptor root;
    private Hashtable interfaceByDbName;
    private Hashtable interfaceByFullName;
    private Hashtable interfaceByName;
    private Hashtable classByDbName;
    private Hashtable classByFullName;
    private Hashtable classByName;
    
    /// <summary>
    /// Gets internal array of interfaces. Do not modify the content of returned array.
    /// </summary>
    internal IInterfaceDescriptor[] Interfaces {
      get {
        EnsureInitialized();
        return interfaces;
      }
    }
    
    /// <summary>
    /// Gets internal array of classes. Do not modify the content of returned array.
    /// </summary>
    internal IClassDescriptor[] Classes {
      get {
        EnsureInitialized();
        return classes;
      }
    }
    
    /// <summary>
    /// Gets a descriptor of the root class.
    /// </summary>
    internal IClassDescriptor Root 
    {
      get {
        EnsureInitialized();
        return root;
      }
    }
    
    /// <summary>
    /// Returns an array of interfaces that have specified database name.
    /// </summary>
    /// <param name="dbName">Database name.</param>
    /// <returns>An array of interfaces that have specified database name.</returns>
    internal IInterfaceDescriptor[] GetInterfacesByDbName(string dbName)
    {
      if (dbName==null)
        return null;
      EnsureInitialized();
      return interfaceByDbName[dbName] as IInterfaceDescriptor[];
    }
    
    /// <summary>
    /// Returns an interface that has specified database name.
    /// </summary>
    /// <param name="dbName">Database name.</param>
    /// <param name="any">If <see langword="true"/> method will return the first interface with the specified dbName.
    /// Otherwise will return an interface only when there is only one interface with the specified dbName.</param>
    /// <returns>An interface that has specified database name.</returns>
    internal IInterfaceDescriptor GetInterfaceByDbName(string dbName, bool any)
    {
      if (dbName==null)
        return null;
      EnsureInitialized();
      IInterfaceDescriptor[] inter = GetInterfacesByDbName(dbName);
      if (inter==null || inter.Length==0 || (inter.Length!=1 && !any))
        return null;
      return inter[0];
    }
    
    /// <summary>
    /// Returns an interface with the specified full name.
    /// </summary>
    /// <param name="fullName">Interface full name.</param>
    /// <returns>An interface with the specified full name.</returns>
    internal IInterfaceDescriptor GetInterfaceByFullName(string fullName)
    {
      if (fullName==null)
        return null;
      EnsureInitialized();
      return interfaceByFullName[fullName] as IInterfaceDescriptor;
    }
    
    /// <summary>
    /// Returns an array of interfaces that have specified name.
    /// </summary>
    /// <param name="name">Name.</param>
    /// <returns>An array of interfaces that have specified name.</returns>
    internal IInterfaceDescriptor[] GetInterfacesByName(string name)
    {
      if (name==null)
        return null;
      EnsureInitialized();
      return interfaceByName[name] as IInterfaceDescriptor[];
    }
    
    /// <summary>
    /// Returns an interface that has specified name.
    /// </summary>
    /// <param name="name">Name.</param>
    /// <param name="any">If <see langword="true"/> method will return the first interface with the specified name.
    /// Otherwise will return an interface only when there is only one interface with the specified name.</param>
    /// <returns>An interface that has specified name.</returns>
    internal IInterfaceDescriptor GetInterfaceByName(string name, bool any)
    {
      if (name==null)
        return null;
      EnsureInitialized();
      IInterfaceDescriptor[] inter = GetInterfacesByName(name);
      if (inter==null || inter.Length==0 || (inter.Length!=1 && !any))
        return null;
      return inter[0];
    }
    
    /// <summary>
    /// Returns an array of interfaces that have full name, name or dbName equal to path.
    /// </summary>
    /// <param name="path">Path.</param>
    /// <returns>An array of interfaces that have full name, name or dbName equal to path.</returns>
    internal IInterfaceDescriptor[] GetInterfaces(string path)
    {
      if (path==null)
        return null;
      EnsureInitialized();
      IInterfaceDescriptor[] interByName = GetInterfacesByName(path);
      ArrayList list = (interByName==null) ? (new ArrayList()) : (new ArrayList(interByName));
      IInterfaceDescriptor interByFullName = GetInterfaceByFullName(path);
      if (interByFullName!=null && !list.Contains(interByFullName))
        list.Add(interByFullName);
      IInterfaceDescriptor[] interByDbName = GetInterfacesByDbName(path);
      if (interByDbName!=null) {
        foreach (IInterfaceDescriptor inter in interByDbName)
          if (!list.Contains(inter))
            list.Add(inter);
      }
      return (IInterfaceDescriptor[])list.ToArray(typeof(IInterfaceDescriptor));
    }
    
    /// <summary>
    /// Returns an interface that has full name, name or dbName equal to path.
    /// </summary>
    /// <param name="path">Path.</param>
    /// <param name="any">If <see langword="true"/> method will return the first interface that has full name, name or dbName equal to path.
    /// Otherwise will return an interface only when there is only one interface that has full name, name or dbName equal to path.</param>
    /// <returns>An interface that has full name, name or dbName equal to path.</returns>
    internal IInterfaceDescriptor GetInterface(string path, bool any)
    {
      if (path==null)
        return null;
      EnsureInitialized();
      IInterfaceDescriptor[] inter = GetInterfaces(path);
      if (inter==null || inter.Length==0 || (inter.Length!=1 && !any))
        return null;
      return inter[0];
    }
    
    /// <summary>
    /// Returns an array of classes that have specified database name.
    /// </summary>
    /// <param name="dbName">Database name.</param>
    /// <returns>An array of classes that have specified database name.</returns>
    internal IClassDescriptor[] GetClassesByDbName(string dbName)
    {
      if (dbName==null)
        return null;
      EnsureInitialized();
      return classByDbName[dbName] as IClassDescriptor[];
    }
    
    /// <summary>
    /// Returns a class that has specified database name.
    /// </summary>
    /// <param name="dbName">Database name.</param>
    /// <param name="any">If <see langword="true"/> method will return the first class with the specified dbName.
    /// Otherwise will return a class only when there is only one class with the specified dbName.</param>
    /// <returns>A class that has specified database name.</returns>
    internal IClassDescriptor GetClassByDbName(string dbName, bool any)
    {
      if (dbName==null)
        return null;
      EnsureInitialized();
      IClassDescriptor[] cls = GetClassesByDbName(dbName);
      if (cls==null || cls.Length==0 || (cls.Length!=1 && !any))
        return null;
      return cls[0];
    }
    
    /// <summary>
    /// Returns a class with the specified full name.
    /// </summary>
    /// <param name="fullName">Class full name.</param>
    /// <returns>A class with the specified full name.</returns>
    internal IClassDescriptor GetClassByFullName(string fullName)
    {
      if (fullName==null)
        return null;
      EnsureInitialized();
      return classByFullName[fullName] as IClassDescriptor;
    }
    
    /// <summary>
    /// Returns an array of classes that have specified name.
    /// </summary>
    /// <param name="name">Name.</param>
    /// <returns>An array of classes that have specified name.</returns>
    internal IClassDescriptor[] GetClassesByName(string name)
    {
      if (name==null)
        return null;
      EnsureInitialized();
      return classByName[name] as IClassDescriptor[];
    }
    
    /// <summary>
    /// Returns a class that has specified name.
    /// </summary>
    /// <param name="name">Name.</param>
    /// <param name="any">If <see langword="true"/> method will return the first class with the specified name.
    /// Otherwise will return a class only when there is only one class with the specified name.</param>
    /// <returns>A class that has specified name.</returns>
    internal IClassDescriptor GetClassByName(string name, bool any)
    {
      if (name==null)
        return null;
      EnsureInitialized();
      IClassDescriptor[] cls = GetClassesByName(name);
      if (cls==null || cls.Length==0 || (cls.Length!=1 && !any))
        return null;
      return cls[0];
    }
    
    /// <summary>
    /// Returns an array of classes that have full name, name or dbName equal to path.
    /// </summary>
    /// <param name="path">Path.</param>
    /// <returns>An array of clsses that have full name, name or dbName equal to path.</returns>
    internal IClassDescriptor[] GetClasses(string path)
    {
      if (path==null)
        return null;
      EnsureInitialized();
      IClassDescriptor[] classByName = GetClassesByName(path);
      ArrayList list = (classByName==null) ? (new ArrayList()) : (new ArrayList(classByName));
      IClassDescriptor classByFullName = GetClassByFullName(path);
      if (classByFullName!=null && !list.Contains(classByFullName))
        list.Add(classByFullName);
      IClassDescriptor[] classByDbName = GetClassesByDbName(path);
      if (classByDbName!=null) {
        foreach (IClassDescriptor cls in classByDbName)
          if (!list.Contains(cls))
            list.Add(cls);
      }
      return (IClassDescriptor[])list.ToArray(typeof(IClassDescriptor));
    }
    
    /// <summary>
    /// Returns a class that has full name, name or dbName equal to path.
    /// </summary>
    /// <param name="path">Path.</param>
    /// <param name="any">If <see langword="true"/> method will return the first class that has full name, name or dbName equal to path.
    /// Otherwise will return a class only when there is only one class that has full name, name or dbName equal to path.</param>
    /// <returns>An interface that has full name, name or dbName equal to path.</returns>
    internal IClassDescriptor GetClass(string path, bool any)
    {
      if (path==null)
        return null;
      EnsureInitialized();
      IClassDescriptor[] cls = GetClasses(path);
      if (cls==null || cls.Length==0 || (cls.Length!=1 && !any))
        return null;
      return cls[0];
    }
    
    /// <summary>
    /// When implemented by a class, returns an array of available interface descriptors.
    /// </summary>
    /// <returns>An array of available interface descriptors.</returns>
    internal protected abstract IInterfaceDescriptor[] GetInterfaces();
    
    /// <summary>
    /// When implemented by a class, returns an array of available class descriptors.
    /// </summary>
    /// <returns>An array of available class descriptors.</returns>
    internal protected abstract IClassDescriptor[] GetClasses();
    
    /// <summary>
    /// When implemented by a class, returns a descriptor of a root class.
    /// </summary>
    /// <returns>Returns a descriptor of a root class.</returns>
    internal protected abstract IClassDescriptor GetRoot();
    
    private void EnsureInitialized()
    {
      if (!isInitialized) {
        interfaces = GetInterfaces();
        classes = GetClasses();
        root = GetRoot();
        
        interfaceByDbName = new Hashtable();
        interfaceByFullName = new Hashtable();
        interfaceByName = new Hashtable();
        foreach (IInterfaceDescriptor id in interfaces) {
          if (id.DbName!=null) {
            if (!interfaceByDbName.ContainsKey(id.DbName))
              interfaceByDbName[id.DbName] = new ArrayList();
            ((ArrayList)interfaceByDbName[id.DbName]).Add(id);
          }
          interfaceByFullName[id.FullName] = id;
          string[] parts = id.FullName.Split(new char[] {'.'});
          string name = parts[parts.Length - 1];
          if (!interfaceByName.ContainsKey(name))
            interfaceByName[name] = new ArrayList();
          ((ArrayList)interfaceByName[name]).Add(id);
        }
        Hashtable interfaceByDbNameOld = interfaceByDbName;
        interfaceByDbName = new Hashtable();
        foreach (string name in interfaceByDbNameOld.Keys)
          interfaceByDbName[name] = ((ArrayList)interfaceByDbNameOld[name]).ToArray(typeof(IInterfaceDescriptor));
        Hashtable interfaceByNameOld = interfaceByName;
        interfaceByName = new Hashtable();
        foreach (string name in interfaceByNameOld.Keys)
          interfaceByName[name] = ((ArrayList)interfaceByNameOld[name]).ToArray(typeof(IInterfaceDescriptor));
          
        classByDbName = new Hashtable();
        classByFullName = new Hashtable();
        classByName = new Hashtable();
        foreach (IClassDescriptor cd in classes) {
          if (cd.DbName!=null) {
            if (!classByDbName.ContainsKey(cd.DbName))
              classByDbName[cd.DbName] = new ArrayList();
            ((ArrayList)classByDbName[cd.DbName]).Add(cd);
          }
          classByFullName[cd.FullName] = cd;
          string[] parts = cd.FullName.Split(new char[] {'.'});
          string name = parts[parts.Length - 1];
          if (!classByName.ContainsKey(name))
            classByName[name] = new ArrayList();
          ((ArrayList)classByName[name]).Add(cd);
        }
        Hashtable classByDbNameOld = classByDbName;
        classByDbName = new Hashtable();
        foreach (string name in classByDbNameOld.Keys)
          classByDbName[name] = ((ArrayList)classByDbNameOld[name]).ToArray(typeof(IClassDescriptor));
        Hashtable classByNameOld = classByName;
        classByName = new Hashtable();
        foreach (string name in classByNameOld.Keys)
          classByName[name] = ((ArrayList)classByNameOld[name]).ToArray(typeof(IClassDescriptor));
          
        isInitialized = true;
      }
    }
    
    /// <summary>
    /// Initializes a new instance of the <see cref="CodeManagerBase"/> class.
    /// </summary>
    internal CodeManagerBase()
    {
    }
  }
}
