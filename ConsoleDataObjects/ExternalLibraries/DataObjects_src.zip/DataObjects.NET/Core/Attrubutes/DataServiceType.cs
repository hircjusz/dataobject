// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Attributes;

namespace DataObjects.NET.Attributes
{
  /// <summary>
  /// Determines service type of the <see cref="DataService"/>.
  /// <seealso cref="ServiceTypeAttribute"/>
  /// <seealso cref="Session.GetService"/>
  /// <seealso cref="Session.CreateService"/>
  /// </summary>
  public enum DataServiceType
  {
    /// <summary>
    /// This type of service is a "sessional singleton".
    /// This means that you should use <see cref="Session.GetService">Session.GetService</see>
    /// to obtain a new or existing instance of the service.
    /// Value is <see langword="0"/>. 
    /// </summary>
    Shared = 0,
    /// <summary>
    /// On contarary, multiple instances of services of this type 
    /// can be created in the single <see cref="Session"/> - you
    /// should call <see cref="Session.CreateService">Session.CreateService</see> to
    /// obtain a new instance.
    /// Value is <see langword="1"/>. 
    /// </summary>
    NonShared = 1,
  }
}
