// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;

namespace DataObjects.NET.Attributes
{
  /// <summary>
  /// Indicates if persistent property can be used in 
  /// offline entities.
  /// By default all persistent properties are available
  /// in offline entities (unless this attribute indicates
  /// the opposite).
  /// </summary>
  [AttributeUsage(AttributeTargets.Property, AllowMultiple = false, Inherited = true)]
  [Serializable]
  public class ToOfflineAttribute: DataObjectAttribute
  {
    private bool hasOfflineAnalogue = true;

    /// <summary>
    /// Gets or sets value indicating whether online property
    /// requires offline analogue in the correspondent offline entity.
    /// If <see langword="false"/>, it's impossible to use the
    /// property in the offline entities at all.
    /// Default value is <see langword="true"/>.
    /// </summary>
    public bool HasOfflineAnalogue
    {
      get { return hasOfflineAnalogue; }
      set { hasOfflineAnalogue = value; }
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    public ToOfflineAttribute()
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="hasOfflineAnalogue">Indicates whether the value of marked 
    /// persistent property is available in corresponding offline entity.</param>
    public ToOfflineAttribute(bool hasOfflineAnalogue)
    {
      this.hasOfflineAnalogue = hasOfflineAnalogue;
    }
  }
}
