// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;
using System.Data;
using System.Reflection;
using DataObjects.NET;
using DataObjects.NET.Exceptions;
using DataObjects.NET.ObjectModel;
using DataObjects.NET.Data.CodeManage;

namespace DataObjects.NET.Data
{
  /// <summary>
  /// Provides a relation between <see cref="DataObjectCollection"/> and a <see cref="DataTable"/>.
  /// <see cref="DoCollectionTranslator"/> is used to fill/update <see cref="DataObjectCollection"/>s.
  /// </summary>
  /// <remarks>
  /// <see cref="DataTable"/> must contain "ID-1" and "ID-2" columns which are a primary key columns.
  /// "ID-1" and "ID-2" columns must be of <see cref="System.Int64"/> type.
  /// </remarks>
  internal class DoCollectionTranslator
  {
    private DoTranslator doTranslator;
    private DataTable dataTable;
    private string collectionName;
    private string fullCollectionName;
    private Culture culture;
    private DataColumn sysID1Column;
    private DataColumn sysID2Column;
    
    /// <summary>
    /// Gets collection full name: "CollectionName[-CultureName]".
    /// </summary>
    public string FullCollectionName {
      get {
        return fullCollectionName;
      }
    }
    
    /// <summary>
    /// Gets collection name. Collection name doesn't include culture part.
    /// </summary>
    public string CollectionName {
      get {
        return collectionName;
      }
    }
    
    /// <summary>
    /// Gets <see cref="DataTable"/> associated with the translator.
    /// </summary>
    public DataTable DataTable {
      get {
        return dataTable;
      }
    }
    
    /// <summary>
    /// Fills <see cref="DataObject"/>'s <see cref="DataObjectCollection"/> into the table.
    /// </summary>
    /// <param name="dataObject">DataObject whose collection to fill.</param>
    public void Fill(DataObject dataObject)
    {
      if (dataObject==null)
        throw new ArgumentNullException("dataObject");
        
      Adapter adapter = doTranslator.Adapter;
        
      DataObjectCollection doCollection = GetDoCollection(dataObject);
      
      if (doCollection!=null) {
        long[] ids = doCollection.GetIDs();
        foreach (long id in ids) {
          if (adapter.FillQueue.GetObjectFillState(id)==DataObjectFillState.NotQueued) {
            EnqueueObjectEventArgs eoe = new EnqueueObjectEventArgs(adapter, id);
            adapter.Internal_OnEnqueueObject(eoe);
            if (eoe.Enqueue)
              adapter.FillQueue.Enqueue(id);
          }
          
          DataRow dataRow = dataTable.Rows.Find(new object[] {dataObject.ID, id});
          if (dataRow!=null) {
            if ((adapter.FillOptions & FillOptions.RemoveOnCollectionConflict)==0)
              throw new AdapterException(
                String.Format("Row with ID-1=\"{0}\" and ID-2=\"{1}\" already exists.", dataObject.ID, id));
          } else
            dataTable.Rows.Add(new object[] {dataObject.ID, id});
        }
      }
    }
    
    /// <summary>
    /// Updates <see cref="DataObjectCollection"/>s from the <see cref="DataTable"/>.
    /// </summary>
    public void Update()
    {
      Adapter adapter = doTranslator.Adapter;
      
      Hashtable docProc = new Hashtable();
      
      foreach (DataRow row in dataTable.Rows) {
        
        TransactionController tc = adapter.Session.CreateTransactionController(TransactionMode.NewTransactionRequired);
        try {

          if (row.RowState!=DataRowState.Deleted) {
            long id1 = (long)row[sysID1Column];
            long id2 = (long)row[sysID2Column];
            
            DataObject do1 = (id1<0) ?
              adapter.UpdateQueue.GetCreatedObject(id1) :
              adapter.Session[id1];
            if (do1==null)
              throw new AdapterException(
                String.Format("DataObject with ID=\"{0}\" is not found.", id1));
                
            DataObject do2 = (id2<0) ?
              adapter.UpdateQueue.GetCreatedObject(id2) :
              adapter.Session[id2];
            if (do2==null)
              throw new AdapterException(
                String.Format("DataObject with ID=\"{0}\" is not found.", id2));
            
            DataObjectCollection doc = (DataObjectCollection)docProc[do1];
            if (doc==null) {
              doc = GetDoCollection(do1);
              docProc[do1] = doc;
            }
            
            if (!doc.Contains(do2))
              doc.Add(do2);
              
            row[sysID1Column] = do1.ID;
            row[sysID2Column] = do2.ID;
          } else {
            long id1 = (long)row[sysID1Column, DataRowVersion.Original];
            long id2 = (long)row[sysID2Column, DataRowVersion.Original];
            
            DataObject do1 = (id1<0) ?
              adapter.UpdateQueue.GetCreatedObject(id1) :
              adapter.Session[id1];
            DataObject do2 = (id2<0) ?
              adapter.UpdateQueue.GetCreatedObject(id2) :
              adapter.Session[id2];
              
            if (do1!=null && do2!=null) {
              DataObjectCollection doc = (DataObjectCollection)docProc[do1];
              if (doc==null) {
                doc = GetDoCollection(do1);
                docProc[do1] = doc;
              }
              if (doc.Contains(do2))
                doc.Remove(do2);
            }
          }
          
          tc.Commit();
        } catch (Exception e) {
          tc.Rollback(e);
          if ((adapter.UpdateOptions & UpdateOptions.IgnoreErrors)==0)
            throw;
        }
      }
    }
    
    private DataObjectCollection GetDoCollection(DataObject dataObject)
    {
      DataObjectCollection doCollection = (DataObjectCollection)dataObject.GetProperty(collectionName, culture);
      
      PropertyEventArgs e = new PropertyEventArgs(dataObject, collectionName, culture, doCollection);
      doTranslator.Adapter.Internal_OnGetProperty(e);
      doCollection = (DataObjectCollection)e.Value;
      
      return doCollection;
    }
  
    /// <summary>
    /// Initializes a new instance of the <see cref="DoCollectionTranslator"/> class.
    /// </summary>
    /// <param name="doTranslator"><see cref="DoTranslator"/> of a <see cref="DataObject"/>.</param>
    /// <param name="docMapping"><see cref="DataObjectCollection"/> mapping item.</param>
    internal DoCollectionTranslator(DoTranslator doTranslator, DocMappingItem docMapping)
    {
      if (doTranslator==null)
        throw new ArgumentNullException("doTranslator");
      if (docMapping==null)
        throw new ArgumentNullException("docMapping");
      if (docMapping.CollectionName==null)
        throw new NullReferenceException("docMapping.CollectionName is null.");
      if (docMapping.TableName==null)
        throw new NullReferenceException("docMapping.TableName is null.");
        
      this.doTranslator = doTranslator;
        
      fullCollectionName = docMapping.CollectionName;
      collectionName = fullCollectionName;
      culture = null;
      
      int ind = fullCollectionName.LastIndexOf("-");
      if (ind!=-1) {
        collectionName = fullCollectionName.Substring(0, ind);
        string cultureName = fullCollectionName.Substring(ind);
        culture = doTranslator.Adapter.Domain.Cultures[cultureName];
        if (culture==null)
          throw new AdapterException(
            String.Format("Culture \"{0}\" is not registered in the domain.", cultureName));
      }
      
      PropertyInfo propertyInfo = doTranslator.Type.SourceType.GetProperty(collectionName);
      if (propertyInfo==null)
        throw new AdapterException(
          String.Format("Property \"{0}\" does not exists.", collectionName));
      
      dataTable = doTranslator.Adapter.dataSource.Tables[docMapping.TableName];
      if (dataTable==null)
        throw new AdapterException(
          String.Format("Table \"{0}\" Does not exists.", docMapping.TableName));
          
      sysID1Column = dataTable.Columns[DataObjectCollectionField.DefaultID1Name];
      sysID2Column = dataTable.Columns[DataObjectCollectionField.DefaultID2Name];
      
      if (sysID1Column==null)
        throw new AdapterException("\"ID-1\" column is absent.");
      if (sysID2Column==null)
        throw new AdapterException("\"ID-2\" column is absent.");
      if (sysID1Column.DataType!=typeof(long))
        throw new AdapterException("Invalid \"ID-1\" column data type.");
      if (sysID2Column.DataType!=typeof(long))
        throw new AdapterException("Invalid \"ID-2\" column data type.");
      
      DataColumn[] primaryKey = dataTable.PrimaryKey;
      if (primaryKey==null || primaryKey.Length!=2 || primaryKey[0]!=sysID1Column || primaryKey[1]!=sysID2Column)
        throw new AdapterException("Invalid Primary Key columns.");
    }
  }
}
