// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Runtime.Serialization;
using DataObjects.NET.Database;

namespace DataObjects.NET.Exceptions
{
  /// <summary>
  /// Thrown by <see cref="Persister"/> on
  /// different errors.
  /// </summary>
  [Serializable]
  public class PersisterException: DatabaseDriverException
  {
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    public PersisterException(): base("Persister error.") {}

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="text">Text of message.</param>
    public PersisterException(string text): base(text) {}

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="innerException">Inner exception.</param>
    public PersisterException(Exception innerException): this("Persister error.",innerException) 
    {
    }
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="text">Text of message.</param>
    /// <param name="innerException">Inner exception.</param>
    public PersisterException(string text, Exception innerException): base(text,innerException) 
    {
    }
    
    /// <summary>
    /// Deserialization constructor.
    /// </summary>
    /// <param name="info"><see cref="SerializationInfo"/> object.</param>
    /// <param name="context"><see cref="StreamingContext"/> object.</param>
    protected PersisterException(SerializationInfo info, StreamingContext context):
      base(info, context)
    {
    }
  }
}
