// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using DataObjects.NET;

namespace DataObjects.NET.Data
{
  /// <summary>
  /// Enumerates possible fill states of <see cref="DataObject"/> instance.
  /// </summary>
  public enum DataObjectFillState
  {
    /// <summary>
    /// Instance is not queued to be filled.
    /// Value is <see langword="0x0"/>.
    /// </summary>
    NotQueued = 0x0,
    
    /// <summary>
    /// Instance is queued to be filled, but isn't filled yet.
    /// Value is <see langword="0x1"/>.
    /// </summary>
    Queued = 0x1,
    
    /// <summary>
    /// Instance is already filled now (so it was queued earlier).
    /// Value is <see langword="0x2"/>.
    /// </summary>
    Filled = 0x2
  }
}
