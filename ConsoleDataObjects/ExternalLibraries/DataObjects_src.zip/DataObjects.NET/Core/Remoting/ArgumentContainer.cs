// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using DataObjects.NET.Offline;

namespace DataObjects.NET.Remoting
{
  /// <summary>
  /// Abstract base class describing a single method invocation 
  /// parameter in the <see cref="MethodCallDescriptor"/>.
  /// </summary>
  [Serializable]
  public abstract class ArgumentContainer : Object,
    ICloneable
  {
    /// <summary>
    /// Gets parameter value.
    /// </summary>
    public abstract object GetValue (CallContext context);

    /// <summary>
    /// Sets parameter value.
    /// </summary>
    /// <param name="value"></param>
    internal protected abstract void SetValue(object value);

    /// <summary>
    /// Creates a new object that is a copy of a curent instance.
    /// </summary>
    public abstract object Clone();

    internal virtual void FixValue(CallContext context)
    {
      // Base version does nothing
    }
  }
}
