// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.IO;
using System.Threading;
using System.Configuration;
using System.Diagnostics;
using System.Globalization;
using System.Collections;
using DataObjects.NET;
using DataObjects.NET.Attributes;
using DataObjects.NET.Exceptions;

namespace DataObjects.NET.Security
{
  /// <summary>
  /// Enumerator for <see cref="PermissionSet"/>.
  /// </summary>
  public class PermissionSetEnumerator: Object, 
    IEnumerator 
  {
    private PermissionSet baseCollection;
    private IEnumerator   baseEnumerator;
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="baseCollection">Base collection.</param>
    /// <param name="baseEnumerator">Base enumerator.</param>
    internal PermissionSetEnumerator(PermissionSet baseCollection, IEnumerator baseEnumerator) 
    {
      this.baseCollection = baseCollection;
      this.baseEnumerator = baseEnumerator;
    }
    
    /// <summary>
    /// Gets the current element in the collection.
    /// </summary>
    public object Current {
      get {
        return baseEnumerator.Current;
      }
    }

    /// <summary>
    /// Advances the enumerator to the next element of the collection.
    /// </summary>
    /// <returns><see><see langword="true"/></see> if the enumerator was successfully 
    /// advanced to the next element; <see><see langword="false"/></see> if the enumerator 
    /// has passed the end of the collection.</returns>
    public bool MoveNext() {
      return baseEnumerator.MoveNext();
    }
    
    /// <summary>
    /// Sets the enumerator to its initial position, which is before the first element in the collection.
    /// </summary>
    public void Reset() {
      baseEnumerator.Reset();
    }
  }
}
