// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;

namespace DataObjects.NET.Attributes
{
  /// <summary>
  /// Indicates that class should share a table that stores properties of 
  /// parent class instances.
  /// </summary>
  /// <remarks>
  /// <note>This attribute can be applied to any persistent type.</note>
  /// <para>
  /// Parent's table will additionaly contain a set of columns representing 
  /// persistent properties declared in descendant having this attribute.
  /// </para>
  /// <para>
  /// <example>Example:
  /// <code lang="C#">
  ///  [ShareAncestorTable] // !!! Shares "doDataObject" table
  ///  public abstract class SomeClassA: DataObject
  ///  {
  ///    ...
  ///  }
  ///  
  ///  [ShareAncestorTable] // !!! Shares "doDataObject" table also
  ///  public abstract class SomeClassB: SomeClassA
  ///  {
  ///    ...
  ///  }
  /// </code>
  /// </example>
  /// </para>
  /// </remarks>
  [AttributeUsage(AttributeTargets.Class, AllowMultiple = false, Inherited = false)]
  [Serializable]
  public class ShareAncestorTableAttribute: DataObjectAttribute
  {
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    public ShareAncestorTableAttribute()
    {
    }
  }
}