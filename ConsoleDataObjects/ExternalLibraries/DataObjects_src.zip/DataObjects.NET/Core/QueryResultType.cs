// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Attributes;

namespace DataObjects.NET
{
  /// <summary>
  /// Enumeration of possible result types of 
  /// <see cref="Query"/> or <see cref="SqlQuery"/>.
  /// </summary>
  public enum QueryResultType
  {
    /// <summary>
    /// Default <see cref="QueryResultType"/>.
    /// The same as <see cref="QueryResultType.Instances"/>.
    /// Value is <see langword="0x0"/>.
    /// </summary>
    Default = 0x0,
    /// <summary>
    /// Query should return a set of <see cref="DataObject"/> instances.
    /// This option allows to use 
    /// <see cref="QueryBase.Execute"/>, 
    /// <see cref="QueryBase.ExecuteArray"/> and 
    /// <see cref="QueryBase.ExecuteCount"/> methods.
    /// Value is <see langword="0x0"/>.
    /// </summary>
    Instances = 0x0,
    /// <summary>
    /// Query should return a set of values (<see cref="ValueType"/> objects).
    /// This option allows to use 
    /// <see cref="QueryBase.ExecuteValueTypeQueryResult"/>, 
    /// <see cref="QueryBase.ExecuteCount"/> methods.
    /// Value is <see langword="0x1"/>.
    /// </summary>
    Values = 0x1,
  }
}
