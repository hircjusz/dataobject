// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.IO;
using System.Threading;
using System.Configuration;
using System.Diagnostics;
using System.Globalization;
using System.Collections;
using DataObjects.NET;
using DataObjects.NET.Attributes;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Security.Permissions;

namespace DataObjects.NET.Security
{
  /// <summary>
  /// An interface that should be implemented by any security permission.
  /// <seealso cref="IPermission"/>
  /// <seealso cref="IPermissionSet"/>
  /// <seealso cref="Permission"/>
  /// <seealso cref="PermissionSet"/>
  /// </summary>
  /// <remarks>
  /// <para>
  /// You can find more information about the whole DataObjects.NET
  /// security system <see cref="AccessControlList">here</see>.
  /// </para>
  /// </remarks>
  public interface IPermission
  {
    /// <summary>
    /// Creates and returns an identical copy of the current permission.
    /// </summary>
    /// <returns>A copy of the current permission.</returns>
    IPermission Copy();
    
    /// <summary>
    /// Gets a collection of <see cref="IPermission"/>s that "grants"
    /// the current permission implicitly. This means that presence
    /// of any of these permissions automatically grants the
    /// current permission.
    /// </summary>
    /// <remarks>
    /// <para>
    /// <see langword="Null"/> can be returned by this property (except
    /// than empty array).
    /// </para>
    /// <para>
    /// Include <see langword="all"/> permissions, that should "grant" the 
    /// current permission - the result will not be checked recursively by
    /// the same way! This means that if permission <see langword="A"/> returns 
    /// permission <see langword="B"/> by <see cref="GrantedIfGrantedAnyOf"/> 
    /// property, and permission <see langword="B"/> returns 
    /// permission <see langword="C"/> by <see cref="GrantedIfGrantedAnyOf"/> 
    /// property, permission <see langword="C"/> will never be checked on demand 
    /// of permission <see langword="A"/> (but permission <see langword="B"/> will
    /// be checked).
    /// </para>
    /// <para>
    /// Do not include <see cref="AdministrationPermission"/>
    /// to this array - its presence always checked by the security system 
    /// implicitly.
    /// </para>
    /// <para>
    /// Do not include <see cref="IPermissionSet">permission sets</see> to this 
    /// array (any permission set will be ignored).
    /// </para>
    /// </remarks>
    ReadOnlyPermissionCollection GrantedIfGrantedAnyOf {get;}
  
    /// <summary>
    /// Demands the permission.
    /// </summary>
    /// <param name="instance">Object to demand the permission for.</param>
    /// <remarks>
    /// This method throws <see cref="SecurityException"/> if the pemission
    /// isn't allowed for the specified instance and the active user in the 
    /// <see cref="Session"/>.
    /// </remarks>
    void Demand(ISecureObject instance);

    /// <summary>
    /// Checks if the permission is allowed for the specified isntance and 
    /// active user in the <see cref="Session"/>.
    /// </summary>
    /// <param name="instance">Object to demand the permission for.</param>
    /// <returns><see langword="True"/> if the permission is allowed; 
    /// otherwise, <see langword="false"/>.</returns>
    bool IsAllowed(ISecureObject instance);
  }
}
