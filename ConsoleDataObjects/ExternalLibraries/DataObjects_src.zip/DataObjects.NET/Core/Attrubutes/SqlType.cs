// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;

namespace DataObjects.NET.Attributes
{
  /// <summary>
  /// Specifies the <see cref="DataObjects.NET.SqlType"/> that should be used to hold the
  /// value of the property (available for properties that can be mapped
  /// to multiple <see cref="DataObjects.NET.SqlType"/>s).
  /// </summary>
  /// <remarks>
  /// <note>This attribute can be applied to persistent properties of any type.</note>
  /// This attribute is a <see cref="DriverTypeSpecificAttribute">driver type-specific</see>,
  /// that means that it can be applied multiple times (with different parameters). 
  /// Each its application can be used or not - dependently on the current type 
  /// of the database driver. 
  /// See <see cref="DriverTypeSpecificAttribute.DriverTypes"/> property
  /// for further information.
  /// <para>
  /// <example>Example:
  /// <code lang="C#">
  ///  public abstract class HomeAnimal: DataObject
  ///  {
  ///    [Indexed]
  ///    [SqlType(SqlType.AnsiVarChar)]
  ///    [Length(128)]
  ///    public abstract string Name {get; set;}
  ///    
  ///    [SqlType(SqlType.AnsiChar)]
  ///    [Length(32)]
  ///    public abstract AnimalType Type {get; set;}
  ///    
  ///    ...
  ///  }
  ///  
  ///  public enum AnimalType {
  ///    ...
  ///  }
  /// </code>
  /// </example>
  /// </para>
  /// <seealso cref="NullableAttribute"/>
  /// <seealso cref="LengthAttribute"/>
  /// </remarks>
  [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field, 
    AllowMultiple = true, Inherited = true)]
  [Serializable]
  public class SqlTypeAttribute: DriverTypeSpecificAttribute
  {
    private SqlType sqlType;
    /// <summary>
    /// SQL type of the property.
    /// </summary>
    public  SqlType SqlType
    {
      get {return sqlType;}
      set {sqlType = value;}
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="sqlType">SQL type of the property.</param>
    public SqlTypeAttribute(SqlType sqlType) 
    {
      this.sqlType = sqlType;
    }
  }
}
