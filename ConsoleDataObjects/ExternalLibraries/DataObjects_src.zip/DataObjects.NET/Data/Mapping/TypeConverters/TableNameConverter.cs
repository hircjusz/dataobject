// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using DataObjects.NET.Data;
using DataObjects.NET.Data.CodeManage;

namespace DataObjects.NET.Data.Design
{
  /// <summary>
  /// TableNameConverter is used only to get a list of available table names for UI designers.
  /// </summary>
  public class TableNameConverter: StringConverter
  {
    /// <summary>
    /// Returns whether this object supports a standard set of values that can be picked from a list, using the specified context.
    /// </summary>
    /// <param name="context">An <see cref="ITypeDescriptorContext"/> that provides a format context.</param>
    /// <returns><see langword="True"/> if <see cref="GetStandardValues"/> should be called to find a common set of values the object supports; otherwise, <see langword="false"/>.</returns>
    public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
    {
      return true;
    }
    
    /// <summary>
    /// Returns a collection of standard values for the data type this type converter is designed for when provided with a format context.
    /// </summary>
    /// <param name="context">An <see cref="ITypeDescriptorContext"/> that provides a format context that can be used to extract additional 
    /// information about the environment from which this converter is invoked. This parameter or properties of this parameter can be a null reference .</param>
    /// <returns>A <see cref="TypeConverter.StandardValuesCollection"/> that holds a standard set of valid values, or a null reference if the data type does not support a standard set of values.</returns>
    public override System.ComponentModel.TypeConverter.StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
    {
      MappingItemBase mappingItem = context.Instance as MappingItemBase;
      if (mappingItem!=null) {
        Adapter adapter = mappingItem.GetAdapter();
        if (adapter!=null && adapter.DataSource!=null) {
          ArrayList nameList = new ArrayList();
          foreach (DataTable table in adapter.dataSource.Tables)
            nameList.Add(table.TableName);
          nameList.Sort();
          return new StandardValuesCollection(nameList);
        }
      }
      return null;
    }
  }
}
