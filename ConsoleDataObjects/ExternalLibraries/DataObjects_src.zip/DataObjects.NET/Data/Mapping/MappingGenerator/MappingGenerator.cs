// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;
using System.Data;
using DataObjects.NET.Data;
using DataObjects.NET.Data.CodeManage;

namespace DataObjects.NET.Data
{
  /// <summary>
  /// Automatic mappings generator.
  /// </summary>
  internal class MappingGenerator
  {
    private Adapter adapter;
    private CodeManagerBase codeManager;
    private DataSet dataSource;
    private Hashtable mappingByElement;
    private Hashtable mappingByTable;
    private ArrayList removedMappingItems;
    private MappingLog log;
    
    /// <summary>
    /// Gets a log of actions.
    /// </summary>
    public MappingLog Log {
      get {
        return log;
      }
    }
    
    /// <summary>
    /// Clears all mappings for current adapter.
    /// </summary>
    public void ClearMappings()
    {
      log = new MappingLog();
      adapter.InterfaceMapping.Clear();
      adapter.ClassMapping.Clear();
    }
    
    /// <summary>
    /// Creates mappings.
    /// </summary>
    public void CreateMappings()
    {
      log = new MappingLog();
      BuildCurrentMappingContext();
      foreach (DataTable table in dataSource.Tables) {
        if (!mappingByTable.ContainsKey(table)) {
          IElementDescriptor element = GetElementByPath(table.TableName);
          if (element!=null && !mappingByElement.ContainsKey(element))
            CreateNewMappingItem(element, table);
        }
      }
      foreach (DataTable table in dataSource.Tables) {
        if (!mappingByTable.ContainsKey(table)) {
          string tableName = table.TableName;
          string path = tableName;
          string culture = null;
          int ind = tableName.LastIndexOf("-");
          if (ind!=-1) {
            path = tableName.Substring(0, ind);
            culture = tableName.Substring(ind + 1);
          }
          ICollectionDescriptor collection = GetCollectionByPath(path);
          if (collection!=null && !mappingByElement.ContainsKey(collection) && mappingByElement.ContainsKey(collection.Parent))
            CreateNewMappingItem(collection, table, culture);
        }
      }
    }
    
    /// <summary>
    /// Gets an element (interface or class) that corresponds to the path.
    /// </summary>
    private IElementDescriptor GetElementByPath(string path)
    {
      IInterfaceDescriptor[] inter = codeManager.GetInterfaces(path);
      IClassDescriptor[] cls = codeManager.GetClasses(path);
      int cnt = 0;
      if (inter!=null)
        cnt += inter.Length;
      if (cls!=null)
        cnt += cls.Length;
      if (cnt==1) {
        if (inter!=null && inter.Length==1)
          return inter[0];
        else if (cls!=null && cls.Length==1)
          return cls[0];
      }
      return null;
    }
    
    /// <summary>
    /// Gets a collection that corresponds to the path.
    /// </summary>
    private ICollectionDescriptor GetCollectionByPath(string path)
    {
      int ind = path.LastIndexOf(".");
      if (ind!=-1) {
        IElementDescriptor parent = GetElementByPath(path.Substring(0, ind));
        ICollectionDescriptor[] collections = null;
        if (parent is IInterfaceDescriptor)
          collections = ((IInterfaceDescriptor)parent).Collections;
        if (collections!=null) {
          string name = path.Substring(ind + 1);
          ICollectionDescriptor resCollection = null;
          int cnt = 0;
          foreach (ICollectionDescriptor collection in collections)
            if (collection.Name==name || collection.DbName==name) {
              resCollection = collection;
              cnt++;
            }
          if (cnt==1)
            return resCollection;
        }
      }
      return null;
    }
    
    /// <summary>
    /// Creates a new mapping, adds it to the current context.
    /// </summary>
    private void CreateNewMappingItem(IElementDescriptor element, DataTable table)
    {
      CreateNewMappingItem(element, table, null);
    }
    
    /// <summary>
    /// Creates a new mapping, adds it to the current context.
    /// </summary>
    private void CreateNewMappingItem(IElementDescriptor element, DataTable table, string culture)
    {
      if (element is IInterfaceDescriptor) {
        IInterfaceDescriptor descriptor = (IInterfaceDescriptor)element;
        FullContainerMappingItem item = null;
        if (element is IClassDescriptor) {
          item = new ClassMappingItem(descriptor.FullName, table.TableName);
          adapter.ClassMapping.Add(item as ClassMappingItem);
        } else {
          item = new InterfaceMappingItem(descriptor.FullName, table.TableName);
          adapter.InterfaceMapping.Add(item as InterfaceMappingItem);
        }
        mappingByElement[descriptor] = item;
        mappingByTable[table] = item;
        UpdateFieldMappingItems(descriptor.Fields, item.Fields, table.Columns);
        log.AddMappingToCreateLog(item);
      } else if (element is ICollectionDescriptor) {
        culture = (culture==null || culture=="") ? "" : ("-" + culture);
        ICollectionDescriptor col = (ICollectionDescriptor)element;
        FullContainerMappingItem parent = (FullContainerMappingItem)mappingByElement[col.Parent];
        MappingItemBase item = null;
        if (col is IValueTypeCollectionDescriptor) {
          item = new VtcMappingItem(col.Name + culture, table.TableName);
          parent.VtCollections.Add(item);
          UpdateFieldMappingItems(((IValueTypeCollectionDescriptor)col).Fields, ((VtcMappingItem)item).Fields, table.Columns);
        } else {
          item = new DocMappingItem(col.Name + culture, table.TableName);
          parent.DoCollections.Add(item);
        }
        mappingByElement[col] = item;
        mappingByTable[table] = item;
        log.AddMappingToCreateLog(item);
      }
    }
    
    /// <summary>
    /// Returns actual field path that corresponds to the specified path.
    /// </summary>
    /// <param name="fields">An array of fields to analize.</param>
    /// <param name="path">A path.</param>
    /// <param name="culture">Can path has a culture or not.</param>
    /// <param name="checkDbName">Check fields' DbName or not.</param>
    private string GetFieldPath(IFieldDescriptor[] fields, string path, bool culture, bool checkDbName)
    {
      if (fields==null || fields.Length==0)
        return null;
      if (path==null || path.Length==0)
        return null;
      int ind = path.IndexOf(".");
      string name = (ind==-1) ? path : path.Substring(0, ind);
      string cultureName = "";
      if (culture) {
        int cind = name.LastIndexOf("-");
        if (cind!=-1) {
          cultureName = name.Substring(cind);
          name = name.Substring(0, cind);
        }
      }
      IFieldDescriptor field = null;
      foreach (IFieldDescriptor f in fields) {
        if (f.Name==name || (checkDbName && f.DbName==name)) {
          field = f;
          break;
        }
      }
      if (field==null)
        return null;
      string fieldName = field.Name + cultureName;
      path = (ind==-1) ? null : path.Substring(ind + 1);
      if (path!=null) {
        string subName = GetFieldPath(field.Fields, path, false, checkDbName);
        if (subName==null)
          return null;
        fieldName += "." + subName;
      }
      return fieldName;
    }
    
    /// <summary>
    /// Remove incorrect field mappings and creates additional mappings if possible.
    /// </summary>
    private void UpdateFieldMappingItems(IFieldDescriptor[] fields, FieldMappingCollection mappings, DataColumnCollection columns)
    {
      Hashtable mappingByColumnName = new Hashtable();
      Hashtable mappingByFieldName = new Hashtable();
  
      // reserved columns    
      mappingByColumnName["ID"] = null;
      // reserved fields
      mappingByFieldName["ID"] = null;
      
      foreach (FieldMappingItem mappingItem in mappings) {
        if (mappingItem.ColumnName==null ||
              !columns.Contains(mappingItem.ColumnName) ||
              mappingItem.FieldName==null ||
              mappingItem.FieldName!=GetFieldPath(fields, mappingItem.FieldName, true, false) ||
              mappingByColumnName.ContainsKey(mappingItem.ColumnName) ||
              mappingByFieldName.ContainsKey(mappingItem.FieldName)) {
          RemoveMappingItem(mappingItem);
        } else {
          mappingByColumnName[mappingItem.ColumnName] = mappingItem;
          mappingByFieldName[mappingItem.FieldName] = mappingItem;
        }
      }
      foreach (DataColumn column in columns) {
        if (!mappingByColumnName.ContainsKey(column.ColumnName)) {
          string path = GetFieldPath(fields, column.ColumnName, true, true);
          if (path!=null && !mappingByFieldName.ContainsKey(path)) {
            FieldMappingItem item = new FieldMappingItem(path, column.ColumnName);
            mappings.Add(item);
            log.AddMappingToCreateLog(item);
          }
        }
      }
    }
    
    /// <summary>
    /// Returns <see langword="true"/> if specified mapping item can be removed, otherwise <see langword="false"/>.
    /// </summary>
    /// <param name="item">mapping item.</param>
    /// <returns><see langword="True"/> if specified mapping item can be removed, otherwise <see langword="false"/>.</returns>
    internal protected virtual bool CanRemoveMappingItem(MappingItemBase item)
    {
      return true;
    }
    
    /// <summary>
    /// Adds mapping item to the list of removed items for futher removal.
    /// </summary>
    private void RemoveMappingItem(MappingItemBase item)
    {
      if (CanRemoveMappingItem(item)) {
        if (removedMappingItems==null)
          removedMappingItems = new ArrayList();
        removedMappingItems.Add(item);
        log.AddMappingToRemoveLog(item);
      }
    }
    
    /// <summary>
    /// Completes to remove mapping item from current adapter mappings.
    /// </summary>
    private void CompleteRemoveMappingItem(MappingItemBase item)
    {
      if (item is InterfaceMappingItem)
        adapter.InterfaceMapping.Remove(item);
      else if (item is ClassMappingItem)
        adapter.ClassMapping.Remove(item);
      else
        item.MappingCollection.Remove(item);
    }
    
    /// <summary>
    /// Returns an array of collection descriptors of the parent element.
    /// item -> parent item -> corresponding element -> element's collection descriptors.
    /// </summary>
    private ICollectionDescriptor[] GetParentElementCollections(MappingItemBase item)
    {
      MappingItemBase parentMapping = item.MappingCollection.Owner as MappingItemBase;
      if (parentMapping!=null) {
        if (parentMapping is InterfaceMappingItem) {
          string interfaceName = ((InterfaceMappingItem)parentMapping).InterfaceName;
          IInterfaceDescriptor inter = codeManager.GetInterface(interfaceName, false);
          if (inter!=null)
            return inter.Collections;
        } else if (parentMapping is ClassMappingItem) {
          string className = ((ClassMappingItem)parentMapping).ClassName;
          IClassDescriptor cls = codeManager.GetClass(className, false);
          if (cls!=null)
            return cls.Collections;
        }
      }
      return null;
    }
    
    /// <summary>
    /// Returns a collection descriptor which corresponds to the mapping item.
    /// </summary>
    private ICollectionDescriptor GetCollectionDescriptor(MappingItemBase item)
    {
      ICollectionDescriptor[] collections = GetParentElementCollections(item);
      if (collections!=null) {
        if (item is DocMappingItem) {
          string name = ((DocMappingItem)item).CollectionName;
          if (name!=null && name.IndexOf("-")!=-1)
            name = name.Substring(0, name.LastIndexOf("-"));
          foreach (ICollectionDescriptor collection in collections) {
            if (collection.Name==name && !(collection is ValueTypeCollectionDescriptor))
              return collection;
          }
        } else if (item is VtcMappingItem) {
          string name = ((VtcMappingItem)item).CollectionName;
          if (name!=null && name.IndexOf("-")!=-1)
            name = name.Substring(0, name.LastIndexOf("-"));
          foreach (ICollectionDescriptor collection in collections) {
            if (collection.Name==name && (collection is ValueTypeCollectionDescriptor))
              return collection;
          }
        }
      }
      return null;
    }
    
    /// <summary>
    /// If item.InterfaceName unambiguously determines an interface and item.TableName determines a table
    /// in a dataSource the item will be added to current mapping context.
    /// </summary>
    /// <param name="item"><see cref="InterfaceMappingItem"/>.</param>
    private void TryToAddInterfaceMappingToCurrentMappingContext(InterfaceMappingItem item)
    {
      IInterfaceDescriptor inter = codeManager.GetInterface(item.InterfaceName, false);
      if (inter!=null) {
        DataTable table = dataSource.Tables[item.TableName];
        if (table!=null) {
          if (!mappingByElement.ContainsKey(inter) && !mappingByTable.ContainsKey(table)) {
            mappingByElement[inter] = item;
            mappingByTable[table] = item;
            foreach (DocMappingItem docItem in item.DoCollections)
              TryToAddCollectionMappingToCurrentMappingContext(docItem);
            foreach (VtcMappingItem vtcItem in item.VtCollections)
              TryToAddCollectionMappingToCurrentMappingContext(vtcItem);
            UpdateFieldMappingItems(inter.Fields, item.Fields, table.Columns);
            return;
          }
        }
      }
      RemoveMappingItem(item);
    }
    
    /// <summary>
    /// If item.ClassName unambiguously determines a class and item.TableName determines a table
    /// in a dataSource the item will be added to current mapping context.
    /// </summary>
    /// <param name="item"><see cref="ClassMappingItem"/>.</param>
    private void TryToAddClassMappingToCurrentMappingContext(ClassMappingItem item)
    {
      IClassDescriptor cls = codeManager.GetClass(item.ClassName, false);
      if (cls!=null) {
        DataTable table = dataSource.Tables[item.TableName];
        if (table!=null) {
          if (!mappingByElement.ContainsKey(cls) && !mappingByTable.ContainsKey(table)) {
            mappingByElement[cls] = item;
            mappingByTable[table] =  item;
            foreach (DocMappingItem docItem in item.DoCollections)
              TryToAddCollectionMappingToCurrentMappingContext(docItem);
            foreach (VtcMappingItem vtcItem in item.VtCollections)
              TryToAddCollectionMappingToCurrentMappingContext(vtcItem);
            UpdateFieldMappingItems(cls.Fields, item.Fields, table.Columns);
            return;
          }
        }
      }
      RemoveMappingItem(item);
    }
    
    /// <summary>
    /// If item unambiguosly determines a collection and item.TableName determines a table
    /// in a dataSource the item wull be added to current mapping context.
    /// </summary>
    /// <param name="item"><see cref="DocMappingItem"/> or <see cref="VtcMappingItem"/>.</param>
    private void TryToAddCollectionMappingToCurrentMappingContext(MappingToTableItem item)
    {
      ICollectionDescriptor collection = GetCollectionDescriptor(item);
      if (collection!=null) {
        string tableName = item.TableName;
        DataTable table = dataSource.Tables[tableName];
        if (table!=null) {
          if (!mappingByElement.ContainsKey(collection) && !mappingByTable.ContainsKey(table)) {
            mappingByElement[collection] = item;
            mappingByTable[table] = item;
            if (item is FieldContainerMappingItem)
              UpdateFieldMappingItems(((IFieldContainerDescriptor)collection).Fields, ((FieldContainerMappingItem)item).Fields, table.Columns);
            return;
          }
        }
      }
      RemoveMappingItem(item);
    }
    
    /// <summary>
    /// Builds mapping context.
    /// </summary>
    private void BuildCurrentMappingContext()
    {
      mappingByElement = new Hashtable();
      mappingByTable = new Hashtable();
      
      foreach (InterfaceMappingItem item in adapter.InterfaceMapping)
        TryToAddInterfaceMappingToCurrentMappingContext(item);
        
      foreach (ClassMappingItem item in adapter.ClassMapping)
        TryToAddClassMappingToCurrentMappingContext(item);
        
      if (removedMappingItems!=null) {
        foreach (MappingItemBase item in removedMappingItems)
          CompleteRemoveMappingItem(item);
        removedMappingItems = null;
      }
    }
  
    /// <summary>
    /// Initializes a new instance of the <see cref="MappingGenerator"/> class.
    /// </summary>
    /// <param name="adapter"><see cref="Adapter"/> to generate mappings for.</param>
    internal MappingGenerator(Adapter adapter)
    {
      if (adapter==null)
        throw new ArgumentNullException("adapter");
      if (adapter.DataSource==null)
        throw new NullReferenceException("DataSource is null.");
      if (adapter.CodeManager==null)
        throw new NullReferenceException("CodeManager is null.");
      this.adapter = adapter;
      this.codeManager = adapter.CodeManager;
      this.dataSource = adapter.dataSource;
    }
  }
}
