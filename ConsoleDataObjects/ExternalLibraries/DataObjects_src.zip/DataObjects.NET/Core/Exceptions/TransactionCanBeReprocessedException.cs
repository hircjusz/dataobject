// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Runtime.Serialization;
using DataObjects.NET.Database;

namespace DataObjects.NET.Exceptions
{
  /// <summary>
  /// Abstract base class for all exceptions that can lead to
  /// reprocessing of automatic transaction.
  /// <seealso cref="DeadlockException"/>
  /// <seealso cref="InstanceVersionChangedException"/>
  /// <seealso cref="Session.ReprocessingAttemptsCount"/>
  /// <seealso cref="Session.ReprocessingDelay"/>
  /// </summary>
  [Serializable]
  public abstract class TransactionCanBeReprocessedException: DatabaseDriverException
  {
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    public TransactionCanBeReprocessedException(): base("Transaction can be reprocessed.") {}

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="text">Text of message.</param>
    public TransactionCanBeReprocessedException(string text): base(text) {}

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="innerException">Inner exception.</param>
    public TransactionCanBeReprocessedException(Exception innerException): this("Transaction can be reprocessed.",innerException) 
    {
    }
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="text">Text of message.</param>
    /// <param name="innerException">Inner exception.</param>
    public TransactionCanBeReprocessedException(string text, Exception innerException): base(text,innerException) 
    {
    }
    
    /// <summary>
    /// Deserialization constructor.
    /// </summary>
    /// <param name="info"><see cref="SerializationInfo"/> object.</param>
    /// <param name="context"><see cref="StreamingContext"/> object.</param>
    protected TransactionCanBeReprocessedException(SerializationInfo info, StreamingContext context):
      base(info, context)
    {
    }
  }
}
