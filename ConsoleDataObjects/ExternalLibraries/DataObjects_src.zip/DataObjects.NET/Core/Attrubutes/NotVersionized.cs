// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;

namespace DataObjects.NET.Attributes
{
  /// <summary>
  /// Indicates that class shouldn't be versionized.
  /// This attribute should be applied to all classes that 
  /// doesn't require versionizing (maintaining their
  /// lifetime history in the storage). Attribute is inherited.
  /// Has no effect, if <see cref="Domain.DatabaseOptions"/> is
  /// <see langword="false"/>.
  /// <seealso cref="Session.BrowsePast"/>
  /// </summary>
  [AttributeUsage(AttributeTargets.Class,
     AllowMultiple = false, Inherited = true)]
  [Serializable]
  public class NotVersionizedAttribute: DataObjectAttribute
  {
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    public NotVersionizedAttribute()
    {
    }
  }
}
