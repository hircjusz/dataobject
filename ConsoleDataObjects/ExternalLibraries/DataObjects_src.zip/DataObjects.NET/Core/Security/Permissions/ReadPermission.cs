// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.IO;
using System.Threading;
using System.Configuration;
using System.Diagnostics;
using System.Globalization;
using System.Collections;
using DataObjects.NET;
using DataObjects.NET.Attributes;
using DataObjects.NET.Exceptions;

namespace DataObjects.NET.Security.Permissions
{
  /// <summary>
  /// This permission is required to read any property of
  /// the <see cref="DataObject"/> instance.
  /// <seealso cref="IPermission"/>
  /// <seealso cref="IPermissionSet"/>
  /// <seealso cref="PermissionSet"/>
  /// </summary>
  [Serializable]
  public class ReadPermission: Permission
  {
    private static ReadPermission _value = new ReadPermission();
    /// <summary>
    /// Represents the instance of the this class.
    /// Normally you should use this static member to obtain
    /// an instance of this type (e.g. to improve permission
    /// checking cache performance and reduce the memory usage), 
    /// but this isn't strongly required.
    /// </summary>
    public  static ReadPermission Value {
      get {return _value;}
    }

    private static ReadOnlyPermissionCollection gigList = 
      new ReadOnlyPermissionCollection(new IPermission[] 
        {OwnerPermission.Value, ChangePermission.Value});
    /// <summary>
    /// Gets a collection of <see cref="IPermission"/>s that "grants"
    /// the current permission implicitly. This means that presence
    /// of any of these permissions automatically grants the
    /// current permission.
    /// </summary>
    /// <remarks>
    /// <para>
    /// The implementation of this property in this type
    /// returns an array of: 
    /// <see cref="OwnerPermission"/> instance,
    /// <see cref="ChangePermission"/> instance.
    /// </para>
    /// <para>
    /// See <see cref="IPermission.GrantedIfGrantedAnyOf"/> property description
    /// for additional information.
    /// </para>
    /// </remarks>
    public override ReadOnlyPermissionCollection GrantedIfGrantedAnyOf {
      get {return gigList;}
    }
  }
}
