// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Runtime.Serialization;

namespace DataObjects.NET.Exceptions
{
  /// <summary>
  /// Thrown by <see cref="Database.DriverFactory"/> if it can't.
  /// find appropriate driver for specified <see cref="ConnectionInfo"/>.
  /// </summary>
  [Serializable]
  public class DriverFactoryException: DataObjectsDotNetException
  {
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    public DriverFactoryException(): base("Driver factory error.") {}
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="text">Text of message.</param>
    public DriverFactoryException(string text): base(text) {}
    
    /// <summary>
    /// Deserialization constructor.
    /// </summary>
    /// <param name="info"><see cref="SerializationInfo"/> object.</param>
    /// <param name="context"><see cref="StreamingContext"/> object.</param>
    protected DriverFactoryException(SerializationInfo info, StreamingContext context):
      base(info, context)
    {
    }
  }
}
