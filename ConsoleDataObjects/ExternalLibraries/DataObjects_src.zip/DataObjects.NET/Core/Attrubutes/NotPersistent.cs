// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;

namespace DataObjects.NET.Attributes
{
  /// <summary>
  /// Indicates that property is not persistent 
  /// (see also <see cref="DeclarationModeAttribute"/>).
  /// This attribute should be applied to all properties that shouldn't be
  /// stored in the database in <see cref="DeclarationMode.PersistentByDefault"/>
  /// declaration mode.
  /// </summary>
  /// <remarks>
  /// <note>This attribute can be applied to properties of any type.
  /// You can't apply this attribute to struct fields (so all
  /// fields of struct are considered as persistent).</note>
  /// <para>
  /// <example>Example:
  /// <code lang="C#">
  ///  public abstract class HomeAnimal: Animal
  ///  {
  ///    // Persistent property!
  ///    [Indexed]
  ///    [Length(128)]
  ///    public abstract string Name {get; set;}
  ///
  ///    ...
  ///
  ///    [NotPersistent] // Not persistent property!
  ///    [Transactional(TransactionMode.Disabled)] // Necessary! 
  ///                                              // Otherwise DataObjects.NET will consider
  ///                                              // this method (property) as requiring a 
  ///                                              // transaction, but it couldn't implement a
  ///                                              // wrapper for it, because it isn't a virtual
  ///                                              // method (property).
  ///    public string SomeNotPersistentProperty {
  ///      get {
  ///        return someNotPersistentData;
  ///      }
  ///    }
  ///
  ///    // This is a transactional, but not persistent property.
  ///    [NotPersistent] // !!!
  ///    public virtual Animal[] AnimalsWithTheSameName  {
  ///      get {
  ///        Query q = Session.CreateQuery(
  ///          "Select Animal objects where {Name}=@Name");
  ///        q.Parameters.Add("@Name", Name);
  ///        return (Animal[])q.ExecuteArray();
  ///      }
  ///    }
  ///
  ///    ...
  ///  }
  /// </code>
  /// </example>
  /// </para>
  /// <seealso cref="PersistentAttribute"/>
  /// <seealso cref="DeclarationModeAttribute"/>
  /// </remarks>
  [AttributeUsage(AttributeTargets.Property,
    AllowMultiple = false, Inherited = true)]
  [Serializable]
  public class NotPersistentAttribute: DataObjectAttribute
  {
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    public NotPersistentAttribute() 
    {
    }
  }
}