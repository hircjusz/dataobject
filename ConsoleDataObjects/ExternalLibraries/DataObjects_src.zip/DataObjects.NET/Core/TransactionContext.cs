// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;
using System.Runtime.Serialization;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Attributes;

namespace DataObjects.NET
{
  /// <summary>
  /// Represents a transaction context - an object describing the 
  /// time period in the transactional application. 
  /// </summary>
  /// <remarks>
  /// <para>
  /// This type is used internally by DataObjects.NET in property caching 
  /// scenarios. You can use it to implement completely transparent 
  /// caching of some aggregated data.
  /// </para>
  /// <para>
  /// Transaction context of <see cref="DataObjects.NET.Session"/> (see
  /// <see cref="DataObjects.NET.Session.TransactionContext"/>) changes
  /// when:
  /// </para>
  /// <para>
  /// a) New outermost or inner transaction begins;
  /// </para>
  /// <para>
  /// b) Rollback of any transaction (inner or outer) occurs;
  /// </para>
  /// <para>
  /// c) Rollback to savepoint occurs.
  /// </para>
  /// <para>
  /// <see cref="DataObject"/> instance data (values of instance persistent
  /// fields cached in memory) is definitely valid in the transaction context 
  /// where this data was retrieved (this can be expanded to any
  /// cached data). Otherwise additional actions should be performed
  /// to ensure this. See <see cref="TransactionContext.State"/> property - 
  /// it allows to determine if the data retrieved in some transaction
  /// context is currently valid.
  /// </para>
  /// <para>
  /// <see cref="TransactionContext"/> objects helps to implement transparent
  /// data caching scenarios - generally you should additionaly keep a reference
  /// to the <see cref="TransactionContext"/> where the data was retrieved, and
  /// check its <see cref="TransactionContext.State"/> during any attempt to
  /// access cached data.
  /// </para>
  /// <para>
  /// You can't create instance of this type manually - these objects are
  /// automatically attached to any <see cref="DataObjects.NET.Transaction"/>.
  /// Additionally any <see cref="DataObjects.NET.Session"/> object has
  /// <see cref="DataObjects.NET.Session.TransactionContext"/> property
  /// allowing get active <see cref="TransactionContext"/>.
  /// </para>
  /// <seealso cref="State"/>
  /// <seealso cref="DataObjects.NET.Session"/>
  /// <seealso cref="DataObjects.NET.Transaction"/>
  /// <seealso cref="DataObjects.NET.DataObject.TransactionContext"/>
  /// <seealso cref="DataObjects.NET.DataObject.State"/>
  /// </remarks>
  public sealed class TransactionContext: SessionBoundObject
  {
    internal Transaction        transaction;
    private  TransactionContext outerContext;
    private  ArrayList          innerContexts = new ArrayList();
    internal bool               isDirty;
    //SM Begin
    internal bool isReadOnly;
    //SM End

    /// <summary>
    /// Transaction, to which this context belongs.
    /// </summary>
    public Transaction Transaction {
      get {
        return transaction;
      }
    }
    
    /// <summary>
    /// If Transaction is not null, returns Transaction.OutermostTransaction,
    /// otherwise returns null.
    /// </summary>
    internal Transaction OutermostTransaction {
      get {
        if (transaction==null)
          return null;
        else
          return transaction.outermostTransaction;
      }
    }

    /// <summary>
    /// Outer <see cref="TransactionContext"/> 
    /// (<see cref="DataObjects.NET.Transaction.TransactionContext"/> 
    /// value of outer transaction at the moment of instance creation).
    /// </summary>
    public  TransactionContext OuterContext {
      get {
        return outerContext;
      }
    }
//SM Begin
      public bool IsReadOnly
      {
          get
          {
              return isReadOnly;
          }
          set
          {
              isReadOnly = value;
          }
      }
//SM End
    

    /// <summary>
    /// <see langword="True"/> if context is dirty.
    /// </summary>
    /// <remarks>
    /// <para>
    /// Context can be marked as dirty if it was released on rollback 
    /// operation.
    /// </para>
    /// </remarks>
    /// 


    public bool IsDirty {
      get {
        return isDirty;
      }
    }
    internal void MarkAsDirty()
    {
      if (isDirty)
        return;
      isDirty = true;
      int cnt = innerContexts.Count;
      for (int i = 0; i<cnt; i++) {
        WeakReference wr = (WeakReference)innerContexts[i];
        TransactionContext ic = wr.Target as TransactionContext;
        if (ic!=null)
          ic.MarkAsDirty();
      }
    }
    
    /// <summary>
    /// Gets the <see cref="TransactionContextState">state</see> of
    /// <see cref="TransactionContext"/>.
    /// </summary>
    public TransactionContextState State {
      get {
        if (isDirty)
          return TransactionContextState.Dirty;
        if ((session==null) || (transaction.outermostTransaction!=session.outermostTransaction))
          return TransactionContextState.BelongsToAnotherOutermostTransaction;
        return TransactionContextState.Valid;
      }
    }
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="transaction">Transaction of this context.</param>
    internal TransactionContext(Transaction transaction)
    {
      this.transaction = transaction;
      this.session     = transaction.session;
      if (transaction.outerTransaction!=null) {
        outerContext = transaction.outerTransaction.transactionContext;
        outerContext.innerContexts.Add(new WeakReference(this));
        isDirty = outerContext.isDirty;
      }
    }
    
    /// <summary>
    /// Creates dirty transaction context.
    /// </summary>
    /// <param name="session">Session, to which the context should be bound.</param>
    internal static TransactionContext CreateDirtyContext(Session session)
    {
      if (session==null)
        throw new ArgumentNullException("session");
      TransactionContext context = new TransactionContext();
      context.session = session;
      context.isDirty = true;
      return context;
    }
    
    /// <summary>
    /// Creates global transaction context marked as requiring version check.
    /// </summary>
    internal static TransactionContext CreateGlobalRequireVersionCheckContext()
    {
      TransactionContext context = new TransactionContext();
      return context;
    }

    private TransactionContext()
    {
    }
  }
}
