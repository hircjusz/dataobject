// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Attributes;

namespace DataObjects.NET
{
  /// <summary>
  /// Allows persistent properties to be notified
  /// on removing of <see cref="DataObject"/> instance.
  /// </summary>
  public interface IRemovableFieldValue: IDataObjectFieldValue
  {
    /// <summary>
    /// Called before removing of the instance containing the property
    /// that implements <see cref="IRemovableFieldValue"/> interface.
    /// </summary>
    void Remove();
  }
}
