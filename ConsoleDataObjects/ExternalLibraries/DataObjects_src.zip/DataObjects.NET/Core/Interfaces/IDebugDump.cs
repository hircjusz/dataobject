// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.IO;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Attributes;

namespace DataObjects.NET
{
  /// <summary>
  /// Debug-helping interface.
  /// </summary>
  public interface IDebugDump
  {
    /// <summary>
    /// Dumps the content of the instance.
    /// </summary>
    /// <param name="output">Writer to output to.</param>
    /// <param name="indent">Indent.</param>
    void Dump(TextWriter output, string indent);
  }
}
