// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using DataObjects.NET.ObjectModel.TypeConversion;

namespace DataObjects.NET.Remoting.ArgumentContainers
{
  /// <summary>
  /// Describes <see cref="Array"/>-type argument.
  /// Properly converts each element of an array to its own <see cref="ArgumentContainer"/>.
  /// </summary>
  [Serializable]
  public class ArrayArgumentContainer : ArgumentContainer
  {
    private Type elementType;
    Array innerValue;
    private object processingValue = null;

    internal override void FixValue(CallContext context)
    {
      if (typeof(ArgumentContainer)==innerValue.GetType().GetElementType() && processingValue==null)
        try {
          processingValue = this;
          int rank = innerValue.Rank;
          int[] lengths = new int[rank];
          int[] lowerBounds = new int[rank];
          long[] dimensionSizes = new long[rank];
          dimensionSizes[0] = 1;
          for (int i=0; i<rank; i++) {
            lengths[i] = innerValue.GetLength(i);
            lowerBounds[i] = innerValue.GetLowerBound(i);
            if (i<rank-1)
              dimensionSizes[i+1]=dimensionSizes[i]*lengths[i];
          }
          long[] indices = new long[rank];
          for(long i=0, count=innerValue.LongLength; i<count; i++) {
            CalculateIndices(i, lowerBounds, dimensionSizes, indices);
            ((ArgumentContainer)innerValue.GetValue(indices)).FixValue(context);
          }
        }
        finally {
          processingValue=null;
        }
    }

    /// <summary>
    /// Creates a new object that is a copy of a curent instance.
    /// </summary>
    public override object Clone()
    {
      if (processingValue==null)
        try {
          ArrayArgumentContainer clone = new ArrayArgumentContainer();
          processingValue   = clone;
          clone.elementType = elementType;
          clone.innerValue  = (Array)innerValue.Clone();
        
          if (typeof(ArgumentContainer)==innerValue.GetType().GetElementType()) {
            int rank = clone.innerValue.Rank;
            int[] lengths = new int[rank];
            int[] lowerBounds = new int[rank];
            long[] dimensionSizes = new long[rank];
            dimensionSizes[0] = 1;
            for (int i=0; i<rank; i++) {
              lengths[i] = innerValue.GetLength(i);
              lowerBounds[i] = innerValue.GetLowerBound(i);
              if (i<rank-1)
                dimensionSizes[i+1]=dimensionSizes[i]*lengths[i];
            }
            long[] indices = new long[rank];
            for(long i=0, count=innerValue.LongLength; i<count; i++) {
              CalculateIndices(i, lowerBounds, dimensionSizes, indices);
              clone.innerValue.SetValue(((ArgumentContainer)innerValue.GetValue(indices)).Clone(), indices);
            }
          }
          return clone;
        }
        finally {
          processingValue = null;
        }
      return processingValue;
    }

    /// <summary>
    /// Gets parameter value.
    /// </summary>
    public override object GetValue (CallContext context)
    {
      if (processingValue==null)
        try {
          if (typeof(ArgumentContainer)==innerValue.GetType().GetElementType()) {
            int rank = innerValue.Rank;
            int[] lengths = new int[rank];
            int[] lowerBounds = new int[rank];
            long[] dimensionSizes = new long[rank];
            dimensionSizes[0] = 1;
            for (int i=0; i<rank; i++) {
              lengths[i] = innerValue.GetLength(i);
              lowerBounds[i] = innerValue.GetLowerBound(i);
              if (i<rank-1)
                dimensionSizes[i+1]=dimensionSizes[i]*lengths[i];
            }
            elementType = TypeConverter.ConvertToOnline(elementType);
            Array resultValue = Array.CreateInstance(elementType, lengths, lowerBounds);
            processingValue = resultValue;
            long[] indices = new long[rank];
            for(long i=0, count=innerValue.LongLength; i<count; i++) {
              CalculateIndices(i, lowerBounds, dimensionSizes, indices);
              resultValue.SetValue(((ArgumentContainer)innerValue.GetValue(indices)).GetValue(context), indices);
            }
            return resultValue;
          }
          return innerValue;
        }
        finally {
          processingValue = null;
        }
      return processingValue;
    }

    /// <summary>
    /// Sets parameter value.
    /// </summary>
    /// <param name="value"></param>
    protected internal override void SetValue(object value)
    {
      if (value==null)
        throw new ArgumentNullException("value");
      Array arrValue = value as Array;
      if (arrValue!=null) {
        Type arrType = value.GetType();
        elementType = arrType.GetElementType();
        if ((elementType.IsPrimitive && elementType.IsValueType) || elementType==typeof(String) || elementType==typeof(Decimal))
          innerValue = (Array)arrValue.Clone();
        else {
          int rank = arrValue.Rank;
          int[] lengths = new int[rank];
          int[] lowerBounds = new int[rank];
          long[] dimensionSizes = new long[rank];
          dimensionSizes[0] = 1;
          for (int i=0; i<rank; i++) {
            lengths[i] = arrValue.GetLength(i);
            lowerBounds[i] = arrValue.GetLowerBound(i);
            if (i<rank-1)
              dimensionSizes[i+1]=dimensionSizes[i]*lengths[i];
          }
          innerValue = Array.CreateInstance(typeof(ArgumentContainer), lengths, lowerBounds);
          long[] indices = new long[rank];
          for(long i=0, count=arrValue.LongLength; i<count; i++) {
            CalculateIndices(i, lowerBounds, dimensionSizes, indices);
            innerValue.SetValue(ArgumentConverter.Convert(arrValue.GetValue(indices)), indices);
          }
        }
      }
      else
        throw new ArgumentException("Parameter should be inctance of Array type.", "value");
    }

    private void CalculateIndices(long index, int[] lowerBounds, long[] sizes, long[] indices)
    {
      for (int dIndex=sizes.Length-1; dIndex>=0; dIndex--) {
        long dSize = sizes[dIndex];
        indices[dIndex] = index / dSize + lowerBounds[dIndex];
        index = index % dSize;
      }
    }

    // Constructors

    internal ArrayArgumentContainer()
    {
    }
  }
}
