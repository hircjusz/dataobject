
// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Attributes;
using DataObjects.NET.Serialization;

namespace DataObjects.NET {
  /// <summary>
  /// Enumeration of possible <see cref="Session"/> operation
  /// <also cref="Session.Options">options</also>.
  /// <seealso cref="SessionOptions"/>
  /// <seealso cref="TransactionMode"/>
  /// </summary>
  [Flags]
  public enum SessionOptions {
    /// <summary>
    /// Default operation mode.
    /// The same as <see cref="SessionOptions.OnlineMode"/>.
    /// Value is <see langword="0x0"/>. 
    /// </summary>
    Default = 0x0,
    /// <summary>
    /// Online operation mode.
    /// Transactions are created for all 
    /// <see cref="TransactionalAttribute">transactional</see> methods.
    /// Value is <see langword="0x0"/>. 
    /// </summary>
    OnlineMode = 0x0,
    /// <summary>
    /// Offline operation mode.
    /// Transactions are created for all
    /// <see cref="TransactionalAttribute">transactional</see> methods
    /// except that are  marked by <see cref="TransactionMode.SupportsOfflineMode"/>
    /// flag.
    /// Practically this means that such methods are capable of
    /// returning cached property values in this case.
    /// Optimistic locking strategy is used in the 
    /// <see cref="SessionOptions.OfflineMode"/>.
    /// Value is <see langword="0x1"/>. 
    /// </summary>
    OfflineMode = 0x1,
    /// <summary>
    /// Disables automatic reloading of any instance in the <see cref="SessionOptions.OfflineMode"/>.
    /// An exception will be thrown if it will be discovered that
    /// <see cref="DataObject.VersionID"/> of some <see cref="DataObject"/>
    /// instance is changed in the storage on version checks.
    /// Value is <see langword="0x101"/>. 
    /// </summary>
    DisableAutoReload = 0x101,
    /// <summary>
    /// Disables loading of any new data in the <see cref="SessionOptions.OfflineMode"/>,
    /// so it will be possible to access only already cached data.
    /// An exception will be thrown on attempt to load anything new.
    /// This doesn't mean it's impossible to run queries in this mode,
    /// queries are allowed, but an exception will be thrown on attempt
    /// to access (get reference to) any new instance from result of
    /// this query.
    /// This option always includes <see cref="SessionOptions.DisableAutoReload"/> flag.
    /// Value is <see langword="0x301"/>. 
    /// </summary>
    DisableAutoLoad = 0x301,
    /// <summary>
    /// Disables transactions in the <see cref="SessionOptions.OfflineMode"/>,
    /// and thus any change operations and access to any uncached data.
    /// An exception will be thrown on any attempt to create a transaction.
    /// Value is <see langword="0x401"/>. 
    /// </summary>
    DisableAutomaticTransactions = 0x401,
    /// <summary>
    /// Disables automatic <see cref="Session"/> disconnection 
    /// on commit or rollback of the outermost transaction.
    /// Value is <see langword="0x800"/>
    /// </summary>
    DisableAutoDisconnect = 0x800,
    /// <summary>
    /// Makes <see cref="Session"/> indexer to throw an exception
    /// if specified <see cref="DataObject.ID"/> doesn't exist.
    /// By default <see cref="Session"/> indexer returns
    /// <see langword="null"/> in this case.
    /// Value is <see langword="0x1000"/>
    /// </summary>
    DisableInvalidObjectIdentifiers = 0x1000
  }
}
