// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Diagnostics;

namespace DataObjects.NET.Diagnostics
{
  internal class PerformanceCounterDummy : IPerformanceCounter
  {
    private static IPerformanceCounter[]  instanceArray = null;
    public static IPerformanceCounter[] InstanceArray {
      get {
        if (instanceArray == null)
          lock(typeof(PerformanceCounterDummy)) {
            if (instanceArray == null)
              instanceArray = new IPerformanceCounter[2]{new PerformanceCounterDummy(),new PerformanceCounterDummy()};
          }
        return instanceArray;
      }
    }

    public string CategoryName
    {
      get { return ""; }
      set { }
    }

    public string CounterHelp
    {
      get { return ""; }
    }

    public string CounterName
    {
      get { return ""; }
      set {  }
    }

    public PerformanceCounterType CounterType
    {
      get { return 0; }
    }

    public string InstanceName
    {
      get { return "";}
      set { }
    }

    public bool ReadOnly
    {
      get {  return true; }
      set { }
    }

    public string MachineName
    {
      get { return "";}
      set { }
    }

    public long RawValue
    {
      get { return 0;}
      set { }
    }

    public void Close()
    {
    }

    public long Decrement()
    {
      return 0;
    }

    public long IncrementBy(long value)
    {
      return 0;
    }

    public long Increment()
    {
      return 0;
    }

    public CounterSample NextSample()
    {
      return CounterSample.Empty;      
    }

    public float NextValue()
    {
      return 0;
    }

    public void RemoveInstance()
    {
    }
  }
}
