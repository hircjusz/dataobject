// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license

using System;
using DataObjects.NET;
using DataObjects.NET.Data;

namespace DataObjects.NET.Data
{
  /// <summary>
  /// Provides information for <see cref="Adapter.VersionConflict"/> event.
  /// </summary>
  public class VersionConflictEventArgs: EventArgs
  {
    private VersionConflictBehaviour behaviour;
    
    /// <summary>
    /// Gets or sets <see cref="Adapter"/> behaviour for current <see cref="DataObject"/>'s version conflict.
    /// </summary>
    public VersionConflictBehaviour Behaviour {
      get {
        return behaviour;
      }
      set {
        behaviour = value;
      }
    }
  
    /// <summary>
    /// Initializes a new instance of the <see cref="VersionConflictEventArgs"/> class.
    /// </summary>
    /// <param name="behaviour">Suggested <see cref="Adapter"/> behaviour.</param>
    public VersionConflictEventArgs(VersionConflictBehaviour behaviour)
    {
      this.behaviour = behaviour;
    }
    
    /// <summary>
    /// Initializes a new instance of the <see cref="VersionConflictEventArgs"/> class.
    /// </summary>
    public VersionConflictEventArgs(): this(VersionConflictBehaviour.Default)
    {
    }
  }
}
