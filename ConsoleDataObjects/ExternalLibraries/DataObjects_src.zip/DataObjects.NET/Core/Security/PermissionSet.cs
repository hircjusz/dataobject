// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.IO;
using System.Text;
using System.Threading;
using System.Configuration;
using System.Runtime.Serialization;
using System.Diagnostics;
using System.Globalization;
using System.Collections;
using DataObjects.NET;
using DataObjects.NET.Attributes;
using DataObjects.NET.Exceptions;

namespace DataObjects.NET.Security
{
  /// <summary>
  /// Security permission set.
  /// <seealso cref="Permission"/>
  /// <seealso cref="IPermission"/>
  /// <seealso cref="IPermissionSet"/>
  /// </summary>
  /// <remarks>
  /// <para>
  /// You can find more information about the whole DataObjects.NET
  /// security system <see cref="AccessControlList">here</see>.
  /// </para>
  /// </remarks>
  [Serializable]
  public class PermissionSet: Object,
    IPermissionSet,
    ISerializable
  {
    /// <summary>
    /// Internal permissions table.
    /// </summary>
    private Hashtable permissions = new Hashtable();
    private bool      disableEvents = false;
    
    
    // Interface methods
    
    /// <summary>
    /// Creates and returns an identical copy of the current permission set.
    /// This method copies all <see cref="IPermission"/> instances
    /// "by reference", but all <see cref="IParameterizedPermission"/>
    /// instances are copied using <see cref="IPermission.Copy"/>
    /// method.
    /// </summary>
    /// <returns>A copy of the current permission set.</returns>
    IPermission IPermission.Copy()
    {
      return (IPermission)Copy();
    }

    /// <summary>
    /// Gets a collection of <see cref="IPermission"/>s that "grants"
    /// the current permission implicitly. This means that presence
    /// of any of these permissions automatically grants the
    /// current permission.
    /// </summary>
    /// <remarks>
    /// <para>
    /// The implementation of this property in this type always returns
    /// <see langword="null"/>.
    /// See <see cref="IPermission.GrantedIfGrantedAnyOf"/> property description
    /// for additional information.
    /// </para>
    /// </remarks>
    public virtual ReadOnlyPermissionCollection GrantedIfGrantedAnyOf {
      get {return null;}
    }

    /// <summary>
    /// Demands the whole permission set.
    /// </summary>
    /// <param name="instance">Object to demand the permission set for.</param>
    /// <remarks>
    /// This method throws <see cref="SecurityException"/> if any part of 
    /// the pemission set isn't allowed for the specified instance and the 
    /// active user in the <see cref="Session"/>.
    /// </remarks>
    public void Demand(ISecureObject instance)
    {
      instance.Demand(this);
    }

    /// <summary>
    /// Checks if the whole permission set is allowed for the specified 
    /// isntance and active user in the <see cref="Session"/>.
    /// </summary>
    /// <param name="instance">Object to demand the permission set for.</param>
    /// <returns><see langword="True"/> if the whole permission set is allowed; 
    /// otherwise, <see langword="false"/>.</returns>
    public bool IsAllowed(ISecureObject instance)
    {
      return instance.IsAllowed(this);
    }

    /// <summary>
    /// Clears the permission set.
    /// </summary>
    void IPermissionSet.Clear()
    {
      Clear();
    }
    
    /// <summary>
    /// Unions current permission and the specified permission set.
    /// </summary>
    /// <param name="target">A permission set to combine with the current permission set.</param>
    void IPermissionSet.Union(IPermission target)
    {
      Union(target);
    }
    
    /// <summary>
    /// Subtracts specified permission set from the current permission set.
    /// </summary>
    /// <param name="target">A permission set to subtract from the current permission set.</param>
    void IPermissionSet.Subtract(IPermission target)
    {
      Subtract(target);
    }

    /// <summary>
    /// Determines whether the current permission set is a subset of the specified permission set.
    /// </summary>
    /// <param name="target">A permission that is to be tested for the subset relationship.</param>
    /// <returns><see langword="True"/> if the current permission set is a subset of the specified permission; otherwise, <see langword="false"/>.</returns>
    bool IPermissionSet.IsSubsetOf(IPermission target)
    {
      return IsSubsetOf(target);
    }

    /// <summary>
    /// Determines whether the current permission set is a superset of the specified permission set.
    /// </summary>
    /// <param name="target">A permission that is to be tested for the superset relationship.</param>
    /// <returns><see langword="True"/> if the current permission set is a superset of the specified permission; otherwise, <see langword="false"/>.</returns>
    bool IPermissionSet.IsSupersetOf(IPermission target)
    {
      return IsSupersetOf(target);
    }

    /// <summary>
    /// Gets the number of elements contained in the collection instance.
    /// </summary>
    public int Count {
      get {
        return permissions.Count;
      }
    }

    /// <summary>
    /// Returns an enumerator that can iterate through the
    /// collection instance.
    /// </summary>
    /// <returns>
    /// An <see cref="IEnumerator"/> for the collection instance.
    /// </returns>
    public IEnumerator GetEnumerator()
    {
      return new PermissionSetEnumerator(this, permissions.Values.GetEnumerator());
    }

    /// <summary>
    /// Copies the elements of the collection to an <see cref="Array"/>, 
    /// starting at a particular <see cref="Array"/> index.
    /// </summary>
    /// <param name="array">The one-dimensional <see cref="Array"/> that is the destination of the elements copied from collection. The <see cref="Array"/> must have zero-based indexing.</param>
    /// <param name="index">The zero-based index in array at which copying begins.</param>
    public void CopyTo(Array array, int index)
    {
      permissions.Values.CopyTo(array, index);
    }

    /// <summary>
    /// Gets a value indicating whether access to the 
    /// collection is synchronized (thread-safe).
    /// </summary>
    /// <returns><see langword="True"/> if access to the collection is synchronized (thread-safe); otherwise, <see langword="false"/>.</returns>
    public bool IsSynchronized {
      get {
        return permissions.IsSynchronized;
      }
    }

    /// <summary>
    /// Gets an object that can be used to synchronize access to the collection.
    /// </summary>
    /// <returns>An object that can be used to synchronize access to the collection.</returns>
    public object SyncRoot {
      get {
        return permissions.SyncRoot;
      }
    }

    
    // PermissionSet methods
    
    /// <summary>
    /// Creates and returns an identical copy of the current permission set.
    /// This method copies all <see cref="IPermission"/> instances
    /// "by reference", but all <see cref="IParameterizedPermission"/>
    /// instances are copied using <see cref="IPermission.Copy"/>
    /// method.
    /// </summary>
    /// <returns>A copy of the current permission set.</returns>
    public virtual PermissionSet Copy()
    {
      PermissionSet ps = (PermissionSet)this.MemberwiseClone();
      ps.permissions = (Hashtable)permissions.Clone();
      foreach (IPermission p in permissions.Values) {
        if (p is IParameterizedPermission)
          ps.permissions[p.GetType()] = p.Copy();
      }
      return ps;
    }
    
    /// <summary>
    /// Clears the permission set.
    /// </summary>
    public virtual void Clear()
    {
      OnChanging();
      permissions.Clear();
      OnChanged();
    }
    
    /// <summary>
    /// Unions current permission and the specified permission set.
    /// </summary>
    /// <param name="target">A permission set to combine with the current permission set.</param>
    public virtual void Union(IPermission target)
    {
      if (target==null) {
        return;
      }
      else if (target is IPermissionSet) {
        // Copy added because of 
        // http://www.x-tensive.com/Forum/viewtopic.php?t=861
        target =  target.Copy();
        Hashtable oldPermissions = permissions;
        permissions = (Hashtable)oldPermissions.Clone();
        disableEvents = true;
        try {
          OnChanging();
          foreach (IPermission p in (IPermissionSet)target)
            Union(p);
        }
        catch {
          permissions = oldPermissions;
          throw;
        }
        finally {
          disableEvents = false;
        }
        OnChanged();
      }
      else if (target is IParameterizedPermission) {
        // Copy added because of 
        // http://www.x-tensive.com/Forum/viewtopic.php?t=861
        target =  target.Copy();
        IParameterizedPermission tpp = (IParameterizedPermission)target;
        System.Type tppt = tpp.GetType();
        if (!disableEvents)
          OnChanging();
        if (permissions[tppt]!=null)
          permissions[tppt] = ((IParameterizedPermission)permissions[tppt]).Union(tpp);
        else
          permissions[tppt] = tpp.Copy();
        if (!disableEvents)
          OnChanged();
      }
      else {
        System.Type tppt = target.GetType();
        if (permissions[tppt]==null) {
          if (!disableEvents)
            OnChanging();
          permissions[tppt] = target.Copy();
          if (!disableEvents)
            OnChanged();
        }
      }
    }
    
    /// <summary>
    /// Subtracts specified permission set from the current permission set.
    /// </summary>
    /// <param name="target">A permission set to subtract from the current permission set.</param>
    public virtual void Subtract(IPermission target)
    {
      if (target==null) {
        return;
      }
      else if (target is IPermissionSet) {
        // Copy added because of 
        // http://www.x-tensive.com/Forum/viewtopic.php?t=861
        target =  target.Copy();
        Hashtable oldPermissions = permissions;
        permissions = (Hashtable)oldPermissions.Clone();
        disableEvents = true;
        try {
          OnChanging();
          foreach (IPermission p in (IPermissionSet)target)
            Subtract(p);
        }
        catch {
          permissions = oldPermissions;
          throw;
        }
        finally {
          disableEvents = false;
        }
        OnChanged();
      }
      else if (target is IParameterizedPermission) {
        // Copy added because of 
        // http://www.x-tensive.com/Forum/viewtopic.php?t=861
        target =  target.Copy();
        IParameterizedPermission tpp = (IParameterizedPermission)target;
        System.Type tppt = tpp.GetType();
        if (permissions[tppt]!=null) {
          if (!disableEvents)
            OnChanging();
          IParameterizedPermission newMy = 
            ((IParameterizedPermission)permissions[tppt]).Subtract(tpp);
          if (newMy.IsEmpty)
            permissions.Remove(tppt);
          else
            permissions[tppt] = newMy;
          if (!disableEvents)
            OnChanged();
        }
      }
      else {
        System.Type tppt = target.GetType();
        if (permissions[tppt]!=null) {
          if (!disableEvents)
            OnChanging();
          permissions.Remove(tppt);
          if (!disableEvents)
            OnChanged();
        }
      }
    }

    internal void InternalSubtract(IPermission target)
    {
      // Subtracts permissions without raising any events,
      // Added because of http://www.x-tensive.com/Forum/viewtopic.php?t=861
      if (target==null) {
        return;
      }
      else if (target is IPermissionSet) {
        target =  target.Copy();
        Hashtable oldPermissions = permissions;
        permissions = (Hashtable)oldPermissions.Clone();
        disableEvents = true;
        try {
          foreach (IPermission p in (IPermissionSet)target)
            Subtract(p);
        }
        catch {
          permissions = oldPermissions;
          throw;
        }
        finally {
          disableEvents = false;
        }
      }
      else if (target is IParameterizedPermission) {
        // Copy added because of 
        // http://www.x-tensive.com/Forum/viewtopic.php?t=861
        target =  target.Copy();
        IParameterizedPermission tpp = (IParameterizedPermission)target;
        System.Type tppt = tpp.GetType();
        if (permissions[tppt]!=null) {
          IParameterizedPermission newMy = 
            ((IParameterizedPermission)permissions[tppt]).Subtract(tpp);
          if (newMy.IsEmpty)
            permissions.Remove(tppt);
          else
            permissions[tppt] = newMy;
        }
      }
      else {
        System.Type tppt = target.GetType();
        if (permissions[tppt]!=null) {
          permissions.Remove(tppt);
        }
      }
    }

    /// <summary>
    /// Determines whether the current permission set is a subset of the specified permission set.
    /// </summary>
    /// <param name="target">A permission that is to be tested for the subset relationship.</param>
    /// <returns><see langword="True"/> if the current permission set is a subset of the specified permission; otherwise, <see langword="false"/>.</returns>
    public virtual bool IsSubsetOf(IPermission target)
    {
      if (target==null) {
        return permissions.Count==0;
      }
      else if (target is PermissionSet) {
        PermissionSet ps = (PermissionSet)target;
        Hashtable psp = ps.permissions;
        foreach (IPermission p in permissions.Values) {
          IPermission lp = (IPermission)psp[p.GetType()];
          if (lp==null)
            return false;
          if (p is IParameterizedPermission) {
            IParameterizedPermission pp  = (IParameterizedPermission)p;
            IParameterizedPermission plp = (IParameterizedPermission)lp;
            if (!pp.IsSubsetOf(plp))
              return false;
          }
        }
        return true;
      }
      else if (target is IPermissionSet) {
        IPermissionSet ps = (IPermissionSet)target;
        Hashtable psp = new Hashtable();
        foreach (IPermission lp in ps) 
          psp[lp.GetType()] = lp;
        foreach (IPermission p in permissions.Values) {
          IPermission lp = (IPermission)psp[p.GetType()];
          if (lp==null)
            return false;
          if (p is IParameterizedPermission) {
            IParameterizedPermission pp  = (IParameterizedPermission)p;
            IParameterizedPermission plp = (IParameterizedPermission)lp;
            if (!pp.IsSubsetOf(plp))
              return false;
          }
        }
        return true;
      }
      else if (target is IParameterizedPermission) {
        IParameterizedPermission tpp = (IParameterizedPermission)target;
        int cnt = permissions.Count;
        if (cnt==0)
          return tpp.IsEmpty;
        if (cnt>1)
          return false;
        System.Type tppt = tpp.GetType();
        IParameterizedPermission my = (IParameterizedPermission)permissions[tppt];
        if (my!=null)
          return my.IsSubsetOf(tpp);
        else
          return false;
      }
      else {
        if (permissions.Count!=1)
          return false;
        System.Type tppt = target.GetType();
        if (permissions[tppt]!=null)
          return true;
        else
          return false;
      }
    }
    
    /// <summary>
    /// Determines whether the current permission set is a superset of the specified permission set.
    /// </summary>
    /// <param name="target">A permission that is to be tested for the superset relationship.</param>
    /// <returns><see langword="True"/> if the current permission set is a superset of the specified permission; otherwise, <see langword="false"/>.</returns>
    public virtual bool IsSupersetOf(IPermission target)
    {
      if (target==null) {
        return true;
      }
      else if (target is PermissionSet) {
        PermissionSet ps = (PermissionSet)target;
        Hashtable psp = ps.permissions;
        foreach (IPermission lp in psp.Values) {
          IPermission p = (IPermission)permissions[lp.GetType()];
          if (p==null)
            return false;
          if (p is IParameterizedPermission) {
            IParameterizedPermission pp  = (IParameterizedPermission)p;
            IParameterizedPermission plp = (IParameterizedPermission)lp;
            if (!plp.IsSubsetOf(pp))
              return false;
          }
        }
        return true;
      }
      else if (target is IPermissionSet) {
        IPermissionSet ps = (IPermissionSet)target;
        Hashtable psp = new Hashtable();
        foreach (IPermission lp in ps) 
          psp[lp.GetType()] = lp;
        foreach (IPermission lp in psp.Values) {
          IPermission p = (IPermission)permissions[lp.GetType()];
          if (p==null)
            return false;
          if (p is IParameterizedPermission) {
            IParameterizedPermission pp  = (IParameterizedPermission)p;
            IParameterizedPermission plp = (IParameterizedPermission)lp;
            if (!plp.IsSubsetOf(pp))
              return false;
          }
        }
        return true;
      }
      else if (target is IParameterizedPermission) {
        IParameterizedPermission tpp = (IParameterizedPermission)target;
        System.Type tppt = tpp.GetType();
        IParameterizedPermission my = (IParameterizedPermission)permissions[tppt];
        if (my!=null)
          return tpp.IsSubsetOf(my);
        else
          return false;
      }
      else {
        System.Type tppt = target.GetType();
        if (permissions[tppt]!=null)
          return true;
        else
          return false;
      }
    }
    
    // Events
    
    /// <summary>
    /// Called before any changes are made in the collection.
    /// </summary>
    protected virtual void OnChanging()
    {
    }

    /// <summary>
    /// Called after some changes were made in collection.
    /// </summary>
    protected virtual void OnChanged()
    {
    }
    
    /// <summary>
    /// Returns <see cref="System.String"/> representation of 
    /// the <see cref="PermissionSet"/>.
    /// </summary>
    /// <returns><see cref="System.String"/> representation of 
    /// the <see cref="PermissionSet"/>.</returns>
    public override string ToString()
    {
      StringBuilder sb = new StringBuilder(GetType().FullName+"(");
      string sDiv = "";
      foreach (IPermission p in permissions.Values) {
        sb.Append(sDiv + p.ToString());
        sDiv = ", ";
      }
      sb.Append(")");
      return sb.ToString();
    }

    
    // Constructors
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    public PermissionSet()
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="initialContent">Initial permission set content.</param>
    public PermissionSet(PermissionSet initialContent)
    {
      PermissionSet ips = initialContent;
      if (ips!=null) {
        Hashtable ipp = ips.permissions;
        permissions = (Hashtable)ipp.Clone();
        foreach (IPermission p in ipp.Values) {
          if (p is IParameterizedPermission)
            permissions[p.GetType()] = p.Copy();
        }
      }
    }
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="initialContent">Initial permission set content.</param>
    public PermissionSet(IPermission initialContent)
    {
      PermissionSet ips = initialContent as PermissionSet;
      if (ips!=null) {
        Hashtable ipp = ips.permissions;
        permissions = (Hashtable)ipp.Clone();
        foreach (IPermission p in ipp.Values) {
          if (p is IParameterizedPermission)
            permissions[p.GetType()] = p.Copy();
        }
      }
      else
        Union(initialContent);
    }
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="initialContent">Initial permission set content.</param>
    public PermissionSet(IEnumerable initialContent)
    {
      foreach (IPermission p in initialContent)
        Union(p);
    }
    
    // Serialization support
    
    /// <summary>
    /// Serializer.
    /// </summary>
    /// <param name="info"><see cref="SerializationInfo"/> object.</param>
    /// <param name="context"><see cref="StreamingContext"/> object.</param>
    public virtual void GetObjectData(SerializationInfo info, StreamingContext context)
    {
      int cnt = permissions.Count;
      info.AddValue("Items-Count",permissions.Count);
      int i = 0;
      foreach (IPermission p in permissions.Values) {
        info.AddValue("Item-"+(i++).ToString(),p);
      }
    }

    /// <summary>
    /// Deserialization constructor.
    /// </summary>
    /// <param name="info"><see cref="SerializationInfo"/> object.</param>
    /// <param name="context"><see cref="StreamingContext"/> object.</param>
    protected PermissionSet(SerializationInfo info, StreamingContext context)
    {
      permissions = new Hashtable();
      try {
        int cnt = info.GetInt32("Items-Count");
        for (int i = 0; i<cnt; i++) {
          try {
            IPermission p = info.GetValue("Item-"+i.ToString(), typeof(object)) as IPermission;
            if (p!=null)
              permissions[p.GetType()] = p;
          } 
          catch (SerializationException) {};
        }
      }
      catch (SerializationException) {};
    }
  }
}
