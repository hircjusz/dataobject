// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using DataObjects.NET;

namespace DataObjects.NET.Data
{
  /// <summary>
  /// Enumerates possible update states of <see cref="DataObject"/> instance.
  /// </summary>
  [Flags]
  public enum DataObjectUpdateState
  {
    /// <summary>
    /// Instance is not enqueued to be created, removed or updated.
    /// Value is <see langword="0x0"/>.
    /// </summary>
    None = 0x0,
    
    /// <summary>
    /// Instance is already created now 
    /// (so it was enqueued for creation earlier).
    /// Value is <see langword="0x1"/>.
    /// </summary>
    Created = 0x1,
    
    /// <summary>
    /// Instance is already updated now 
    /// (so it was enqueued for update earlier; probably it was registered for creation).
    /// Value is <see langword="0x2"/>.
    /// </summary>
    Updated = 0x2,
    
    /// <summary>
    /// Instance is already removed now 
    /// (so it was enqueued for removal earlier).
    /// Value is <see langword="0x4"/>.
    /// </summary>
    Removed = 0x4
  }
}
