// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.IO;
using System.Text;
using System.Threading;
using System.Configuration;
using System.Diagnostics;
using System.Globalization;
using System.Collections;
using System.Security.Cryptography;
using DataObjects.NET;
using DataObjects.NET.Attributes;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Security.Permissions;

namespace DataObjects.NET.Security
{
  /// <summary>
  /// Standard user account implementation.
  /// <see langword="Persistent"/>.
  /// </summary>
  /// <remarks>
  /// <para>
  /// You can find more information about the whole DataObjects.NET
  /// security system <see cref="AccessControlList">here</see>.
  /// </para>
  /// </remarks>
  public abstract class StdUser: User
  {
    private bool allowSetPassword = false;
    
    /// <summary>
    /// <see langword="Persistent"/>.
    /// Gets user's password.
    /// </summary>
    [Length(128)]
    [Length(83, DriverTypes="Firebird")] // Firebird - specific declaration
    [Indexed]
    public string Password {
      get {return (string)GetProperty("Password", null);}
    }
    
    /// <summary>
    /// Sets user's password.
    /// </summary>
    /// <param name="password">New password.</param>
    /// <param name="hashingMethod">A method that should be used to hash 
    /// password value before storing it in the <see cref="Password"/> property.</param>
    /// <remarks>
    /// <para>
    /// This method demands the following permissions:
    /// <see cref="AdministrationPermission"/>, 
    /// if <see cref="Session.User">Session.User</see>!=<see langword="this"/>;
    /// otherwise, 
    /// <see cref="ChangePasswordPermission"/>.
    /// </para>
    /// </remarks>
    [Transactional(TransactionMode.TransactionRequired)]
    public virtual void SetPassword(string password, HashingMethod hashingMethod)
    {
      if (password==null)
        throw new ArgumentNullException("password");
      if (Session.User!=this)
        Demand(AdministrationPermission.Value);
      else
        Demand(ChangePasswordPermission.Value);
      
      password = ComputeHashedPassword(password, hashingMethod);
      
      allowSetPassword = true;
      try {
        SetProperty("Password", null, password);
      }
      finally {
        allowSetPassword = false;
      }
    }
    
    /// <summary>
    /// Computes password hash.
    /// </summary>
    /// <param name="password">Password to hash.</param>
    /// <param name="hashingMethod">Hashing method to use.</param>
    /// <returns>Password hash (with "<paramref name="hashingMethod"/>:" prefix).</returns>
    [Transactional(TransactionMode.Disabled)]
    protected virtual string ComputeHashedPassword(string password, HashingMethod hashingMethod)
    {
      if (password==null)
        throw new ArgumentNullException("password");

      HashAlgorithm ha = GetHashAlgorythm(hashingMethod);
      string pfx = (ha==null) ? 
        (password=="" ? "" : "Plain:") : 
        (hashingMethod.ToString()+":");
      
      string uniquePart = GetUniqueString(hashingMethod);
      if (uniquePart!="")
        uniquePart = uniquePart + ":";
      
      if (ha!=null) {
        UnicodeEncoding enc = new UnicodeEncoding();
        password = uniquePart+Convert.ToBase64String(ha.ComputeHash(enc.GetBytes(uniquePart+password)));
      }
      
      return pfx+password;
    }
    
    /// <summary>
    /// Validates password.
    /// </summary>
    /// <param name="password">Password to validate.</param>
    /// <param name="passwordHash">Hashed value of actual password.</param>
    /// <param name="hashingMethod">Hashing method to use.</param>
    /// <returns><see langword="True"/> if validation was successful;
    /// otherwise, <see langword="false"/>.</returns>
    [Transactional(TransactionMode.Disabled)]
    protected virtual bool ValidatePassword(string password, string passwordHash, HashingMethod hashingMethod)
    {
      if (password==null)
        throw new ArgumentNullException("password");
      if (passwordHash==null)
        throw new ArgumentNullException("password");

      HashAlgorithm ha = GetHashAlgorythm(hashingMethod);
      
      string uniquePart = "";
      if (passwordHash.IndexOf(":")>=0)
        uniquePart = passwordHash.Substring(0,passwordHash.IndexOf(":")+1);
      
      if (ha!=null) {
        UnicodeEncoding enc = new UnicodeEncoding();
        password = uniquePart+Convert.ToBase64String(ha.ComputeHash(enc.GetBytes(uniquePart+password)));
      }
      
      return passwordHash==password;
    }
    
    /// <summary>
    /// Returns <see cref="HashAlgorithm"/> instance for the specific
    /// <paramref name="hashingMethod"/>.
    /// </summary>
    /// <param name="hashingMethod">Hashing method.</param>
    /// <returns><see cref="HashAlgorithm"/> instance for the specific
    /// <paramref name="hashingMethod"/>.</returns>
    [Transactional(TransactionMode.Disabled)]
    protected virtual HashAlgorithm GetHashAlgorythm(HashingMethod hashingMethod)
    {
      switch (hashingMethod) {
      case HashingMethod.None:
        return null;
      case HashingMethod.MD5:
      case HashingMethod.MD5v2:
        return new MD5CryptoServiceProvider();
      case HashingMethod.SHA1:
      case HashingMethod.SHA1v2:
        return new SHA1Managed();
      case HashingMethod.SHA256:
      case HashingMethod.SHA256v2:
        return new SHA256Managed();
      default:
        throw new NotSupportedException(String.Format(
          "Unknown hasing method: {0}.", hashingMethod.ToString()));
      }
    }
    
    /// <summary>
    /// Returns unique string to inject into the password hash for the specific
    /// <paramref name="hashingMethod"/> to prevent password salting.
    /// </summary>
    /// <param name="hashingMethod">Hashing method.</param>
    /// <remarks>
    /// Returns an empty string for
    /// <see cref="HashingMethod.None"/>,
    /// <see cref="HashingMethod.MD5"/>,
    /// <see cref="HashingMethod.SHA1"/>,
    /// <see cref="HashingMethod.SHA256"/> hashing methods). Returned
    /// string shouldn't contain ":" character.
    /// </remarks>
    /// <returns>Unique string to inject into the password hash for the specific
    /// <paramref name="hashingMethod"/>.</returns>
    [Transactional(TransactionMode.Disabled)]
    protected virtual string GetUniqueString(HashingMethod hashingMethod)
    {
      switch (hashingMethod) {
      case HashingMethod.None:
      case HashingMethod.MD5:
      case HashingMethod.SHA1:
      case HashingMethod.SHA256:
        return "";
      case HashingMethod.MD5v2:
      case HashingMethod.SHA1v2:
      case HashingMethod.SHA256v2:
        return Guid.NewGuid().ToString();
      default:
        throw new NotSupportedException(String.Format(
          "Unknown hasing method: {0}.", hashingMethod.ToString()));
      }
    }
    
    /// <summary>
    /// Authenticates the user.
    /// </summary>
    /// <param name="authParams">Authentication parameters (e.g. password).
    /// Should be an array containing a single string (password).</param>
    /// <returns><see langword="True"/> if authentication was successful, 
    /// otherwise <see langword="false"/>.</returns>
    public override bool Authenticate(params object[] authParams)
    {
      if (authParams.Length<1)
        throw new ArgumentException(
          "authParams should be an array containing a single string (password).");
      string password = authParams[0] as string;
      string realPassword;
      if (password==null)
        throw new ArgumentException(
          "authParams should be an array containing a single string (password).");

      DisableSecurity();
      try {
        if (IsDisabled)
          return false;
        realPassword = Password;
        if (realPassword == null)
            realPassword = String.Empty;
      }
      finally {
        EnableSecurity();
      }

      int divIndex = realPassword.IndexOf(':');
      string sHashingMethod    = (divIndex<0) ? ""           : realPassword.Substring(0, divIndex);
      string realPasswordHash  = (divIndex<0) ? realPassword : realPassword.Substring(divIndex+1);
      HashingMethod hashingMethod = HashingMethod.None;
      if (sHashingMethod!="") {
        try {
          hashingMethod = (HashingMethod)Enum.Parse(
            typeof(HashingMethod),sHashingMethod,false);
        } catch {}
      }

      if (ValidatePassword(password, realPasswordHash, hashingMethod))
        return true;
      else {
        // Password is invalid, so let's make a small pause 
        // to prevent brute-force attacks.
        Thread.Sleep(200 + session.random.Next(100)); 
        return false;
      }
    }
    

    // Event handlers

    /// <summary>
    /// Called during <see cref="DataObject.SetProperty"/> method execution.
    /// Note that this method isn't invoked during the deserialization.
    /// </summary>
    /// <param name="name">Property name.</param>
    /// <param name="culture">Property culture.</param>
    /// <param name="value">New property value.</param>
    /// <remarks>
    /// <para>
    /// This method disallows to set the <see cref="Password"/> property
    /// without invoking <see cref="SetPassword"/>.
    /// </para>
    /// <para>
    /// See <see cref="DataObject.OnSetProperty"/> method description
    /// for additional information.
    /// </para>
    /// </remarks>
    protected override void OnSetProperty(string name, Culture culture, object value)
    {
      if (name=="Password") {
        if (allowSetPassword) {
          allowSetPassword = false;
          return; // Note, that base method wasn't called!
        }
        else
          throw new SecurityException(
            "Password changing isn't allowed by this way, " + 
            "use SetPassword method to perform this.");
      }
      base.OnSetProperty(name, culture, value);
    }
  }
}
