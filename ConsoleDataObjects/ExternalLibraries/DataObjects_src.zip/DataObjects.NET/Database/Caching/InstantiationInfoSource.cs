// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using DataObjects.NET;
using DataObjects.NET.Caching;

namespace DataObjects.NET.Database
{
  /// <summary>
  /// Enumerates possible sources of
  /// <see cref="DataObjectInstantiationInfo"/>  objects, load-on-demand fields,
  /// <see cref="DataObjectCollection"/>s and <see cref="ValueTypeCollection"/>s.
  /// </summary>
  public enum InstantiationInfoSource
  {
    /// <summary>
    /// Instantiation info was fetched from <see cref="SessionCache"/>.
    /// </summary>
    SessionCache,
    /// <summary>
    /// Instantiation info was fetched from <see cref="GlobalCache"/>.
    /// </summary>
    GlobalCache,
    /// <summary>
    /// Instantiation info was fetched from the database.
    /// </summary>
    Database,
    ChangeCache
  }
}
