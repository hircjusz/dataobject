// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Attributes;

namespace DataObjects.NET
{
  /// <summary>
  /// Determines declaration mode for the class. See
  /// <see cref="DeclarationModeAttribute"/>,
  /// <see cref="PersistentAttribute"/>,
  /// <see cref="NotPersistentAttribute"/> also.
  /// <seealso cref="DeclarationModeAttribute"/>
  /// <seealso cref="PersistentAttribute"/>
  /// <seealso cref="NotPersistentAttribute"/>
  /// </summary>
  [Flags]
  public enum DeclarationMode
  {
    /// <summary>
    /// Default declaration mode.
    /// Non-persistent properties should be marked by
    /// <see cref="NotPersistentAttribute"/>. All other
    /// properties are considered persistent (except private and 
    /// internal properties).
    /// <see cref="PersistentAttribute"/> shouldn't
    /// be used.
    /// Value is <see langword="0"/>. 
    /// </summary>
    Default = 0,
    /// <summary>
    /// The same as default declaration mode.
    /// Non-persistent properties should be marked by
    /// <see cref="NotPersistentAttribute"/>. All other
    /// properties are considered persistent (except private and 
    /// internal properties).
    /// Value is <see langword="0"/>. 
    /// </summary>
    PersistentByDefault = 0,
    /// <summary>
    /// "Inverse" mode (this was the only available declaration
    /// mode in the versions of DataObjects.NET earlier then 1.3.1).
    /// Persistent properties should be marked by
    /// <see cref="PersistentAttribute"/>. All other
    /// properties are considered non-persistent.
    /// Value is <see langword="1"/>. 
    /// </summary>
    NotPersistentByDefault = 1,
  }
}
