// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;

namespace DataObjects.NET
{
  /// <summary>
  /// Holds values of persistent fields of <see cref="DataObject"/> instance.
  /// </summary>
  internal struct DataObjectProperties
  {
    private object[] properties;
    private BitArray status;
    
    /// <summary>
    /// Gets value of the specified property of the specified culture.
    /// </summary>
    /// <param name="propertyIndex">Index of property.</param>
    /// <param name="cultureIndex">Index of culture.</param>
    /// <param name="cultureCount">Total count of cultures.</param>
    /// <returns>Value</returns>
    internal object GetValue(int propertyIndex, int cultureIndex, int cultureCount)
    {
      return properties[propertyIndex*cultureCount + cultureIndex];
    }
    
    /// <summary>
    /// Sets value of the specified property of the specified culture.
    /// </summary>
    /// <param name="propertyIndex">Index of property.</param>
    /// <param name="cultureIndex">Index of culture.</param>
    /// <param name="cultureCount">Total count of cultures.</param>
    /// <param name="value">Value.</param>
    internal void SetValue(int propertyIndex, int cultureIndex, int cultureCount, object value)
    {
      properties[propertyIndex*cultureCount + cultureIndex] = value;
    }
        
    /// <summary>
    /// Gets value of the specified property.
    /// </summary>
    /// <param name="index">Absolute index of property.</param>
    /// <returns>Value</returns>
    internal object GetValue(int index)
    {
      return properties[index];
    }
    
    /// <summary>
    /// Sets value of the specified property.
    /// </summary>
    /// <param name="index">Absolute index of property.</param>
    /// <param name="value">Value.</param>
    internal void SetValue(int index, object value)
    {
      properties[index] = value;
    }
    
    /// <summary>
    /// Checks whether the specified property of the specified culture is loaded.
    /// </summary>
    /// <param name="propertyIndex">Index of property.</param>
    /// <param name="cultureIndex">Index of culture.</param>
    /// <param name="cultureCount">Total count of cultures.</param>
    /// <returns><see langword="True"/> if the property is loaded;
    /// otherwise, <see langword="false"/>.</returns>
    internal bool GetIsLoaded(int propertyIndex, int cultureIndex, int cultureCount)
    {
      return status[(propertyIndex*cultureCount + cultureIndex)<<1];
    }
    
    /// <summary>
    /// Sets whether or not the specified property of the specified culture is loaded.
    /// </summary>
    /// <param name="propertyIndex">Index of property.</param>
    /// <param name="cultureIndex">Index of culture.</param>
    /// <param name="cultureCount">Total count of cultures.</param>
    /// <param name="value"><see langword="True"/> if property is loaded; 
    /// otherwise, <see langword="false"/>.</param>
    internal void SetIsLoaded(int propertyIndex, int cultureIndex, int cultureCount, bool value)
    {
      status[(propertyIndex*cultureCount + cultureIndex)<<1] = value;
    }
    
    /// <summary>
    /// Checks whether the specified property of the specified culture is changed.
    /// </summary>
    /// <param name="propertyIndex">Index of property.</param>
    /// <param name="cultureIndex">Index of culture.</param>
    /// <param name="cultureCount">Total count of cultures.</param>
    /// <returns><see langword="True"/> if the property is changed;
    /// otherwise, <see langword="false"/>.</returns>
    internal bool GetIsChanged(int propertyIndex, int cultureIndex, int cultureCount)
    {
      return status[((propertyIndex*cultureCount + cultureIndex)<<1)+1];
    }
    
    /// <summary>
    /// Sets whether or not the specified property of the specified culture is changed.
    /// </summary>
    /// <param name="propertyIndex">Index of property.</param>
    /// <param name="cultureIndex">Index of culture.</param>
    /// <param name="cultureCount">Total count of cultures.</param>
    /// <param name="value"><see langword="True"/> if property is changed; 
    /// otherwise, <see langword="false"/>.</param>
    internal void SetIsChanged(int propertyIndex, int cultureIndex, int cultureCount, bool value)
    {
      status[((propertyIndex*cultureCount + cultureIndex)<<1)+1] = value;
    }
    
    /// <summary>
    /// Checks whether the specified property is loaded.
    /// </summary>
    /// <param name="index">Absolute index of property.</param>
    /// <returns><see langword="True"/> if the property is loaded;
    /// otherwise, <see langword="false"/>.</returns>
    internal bool GetIsLoaded(int index)
    {
      return status[index<<1];
    }
    
    /// <summary>
    /// Sets whether or not the specified property is loaded.
    /// </summary>
    /// <param name="index">Absolute index of property.</param>
    /// <param name="value"><see langword="True"/> if property is loaded; 
    /// otherwise, <see langword="false"/>.</param>
    internal void SetIsLoaded(int index, bool value)
    {

      status[index<<1] = value;
    }
    
    /// <summary>
    /// Checks whether the specified property is changed.
    /// </summary>
    /// <param name="index">Absolute index of property.</param>
    /// <returns><see langword="True"/> if the property is changed;
    /// otherwise, <see langword="false"/>.</returns>
    internal bool GetIsChanged(int index)
    {
      
      return status[(index<<1)+1];
    }
    
    /// <summary>
    /// Sets whether or not the specified property is changed.
    /// </summary>
    /// <param name="index">Absolute index of property.</param>
    /// <param name="value"><see langword="True"/> if property is changed; 
    /// otherwise, <see langword="false"/>.</param>
    internal void SetIsChanged(int index, bool value)
    {
    
      status[(index<<1)+1] = value;
    }
    
    /// <summary>
    /// Gets <see cref="Array"/> of values of the specified property.
    /// Each element of array corresponds to one culture.
    /// </summary>
    /// <param name="propertyIndex">Index of property.</param>
    /// <param name="cultureCount">Total count of cultures.</param>
    /// <returns><see cref="Array"/> of property values.</returns>
    internal object[] GetValues(int propertyIndex, int cultureCount)
    {
      object[] property = new object[cultureCount];
      Array.Copy(property, propertyIndex*cultureCount, property, 0, cultureCount);
      return property;
    }
    
    /// <summary>
    /// Sets <see cref="Array"/> of values of the specified property.
    /// Each element of array corresponds to one culture.
    /// </summary>
    /// <param name="propertyIndex">Index of property.</param>
    /// <param name="cultureCount">Total count of cultures.</param>
    /// <param name="values">An <see cref="Array"/> of property values.</param>
    internal void SetValues(int propertyIndex, int cultureCount, object[] values)
    {
      Array.Copy(values, 0, properties, propertyIndex*cultureCount, cultureCount);
    }
    
    /// <summary>
    /// Checks for presence of not loaded properties, 
    /// that are checked in the load map .
    /// </summary>
    /// <param name="loadMap">Load map to check.</param>
    /// <returns><see langowrd="True"/> if loading is requires;
    /// otherwise, <see langword="false"/>.</returns>
    internal bool CheckIfLoadMapRequiresLoading(BitArray loadMap)
    {
      for (int i = 0, cnt = loadMap.Count; i<cnt; i++)
        if (loadMap[i] && (!status[i<<1]))
          return true;
      return false;
    }
    
    /// <summary>
    /// Initializes internal arrays.
    /// </summary>
    /// <param name="propertyCount">Count of properties.</param>
    /// <param name="cultureCount">Count of cultures for each property.</param>
    internal void Initialize(int propertyCount, int cultureCount)
    { 
      properties = new object[propertyCount*cultureCount];
      status     = new BitArray(propertyCount*cultureCount<<1);
    }
    
    
    // Constructors
    
    /// <summary>
    /// Initializes a new instance of this struct.
    /// <seealso cref="Initialize"/>
    /// </summary>
    /// <param name="propertyCount">Count of properties.</param>
    /// <param name="cultureCount">Count of cultures for each property.</param>
    internal DataObjectProperties(int propertyCount, int cultureCount)
    {
      properties = new object[propertyCount*cultureCount];
      status     = new BitArray(propertyCount*cultureCount<<1);
    }
  }
}
