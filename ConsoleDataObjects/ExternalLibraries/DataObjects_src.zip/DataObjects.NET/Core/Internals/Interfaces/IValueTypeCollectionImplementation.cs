// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;

namespace DataObjects.NET.Internals
{
  /// <summary>
  /// An interface describing underlying <see cref="ValueTypeCollection"/> implementation.
  /// </summary>
  public interface IValueTypeCollectionImplementation
  {
    /// <summary>
    /// Called on attachment to <see cref="DataObject"/>.
    /// </summary>
    void Attach();

    /// <summary>
    /// Called on detachment from <see cref="DataObject"/>.
    /// </summary>
    void Detach();

    /// <summary>
    /// Invalidates caches.
    /// </summary>
    void InvalidateCache();

    /// <summary>
    /// <see langword="True"/> if the collection is completely loaded;
    /// otherwise, <see langword="false"/>.
    /// </summary>
    bool IsLoaded {get;}
    
    /// <summary>
    /// Loads collection from the database.
    /// </summary>
    void Load();

    /// <summary>
    /// Loads collection content from the given <see cref="ArrayList"/> contaning preload data.
    /// </summary>
    /// <param name="dbItems">List of items to load.</param>
    /// <param name="startIndex">index in <paaramref name="dbItems"/> to start from.</param>
    /// <param name="count">Number of items to load.</param>
    void Load(ArrayList dbItems, int startIndex, int count);

    /// <summary>
    /// Loads collection content from deserialized 
    /// <see cref="DataObject.FastLoadData"/> for this collection.
    /// </summary>
    /// <param name="itemIds">An <see cref="Array"/> containing item IDs.</param>
    /// <param name="iValues">An <see cref="Array"/> containing item values.</param>
    /// <param name="count">The count of items in the collection.</param>
    void Load(long[] itemIds, object[] iValues, int count);

    /// <summary>
    /// Caches the specified item.
    /// </summary>
    /// <param name="entry">Entry to cache.</param>
    void CacheItem(ValueTypeCollectionEntry entry);

    /// <summary>
    /// Caches the specified item.
    /// </summary>
    /// <param name="entry">Entry to cache.</param>
    void CacheItem(ValueTypeQueryResultEntry entry);

    /// <summary>
    /// Gets the number of elements contained in the collection.
    /// </summary>
    int Count {get;}
    
    /// <summary>
    /// Returns an enumerator that can iterate through the
    /// collection instance.
    /// </summary>
    /// <returns>
    /// An <see cref="IEnumerator"/> for the 
    /// collection instance.
    /// </returns>
    IEnumerator GetEnumerator();

    /// <summary>
    /// Removes all objects from the collection instance.
    /// </summary>
    void Clear();

    /// <summary>
    /// Returns <see langword="True"/> if the specified ItemID (key)
    /// exists in the collection; otherwise, <see langword="false"/>.
    /// </summary>
    /// <param name="itemId">ItemID (key) to check.</param>
    /// <returns><see langword="True"/> if the specified item
    /// exists in the collection; otherwise, <see langword="false"/>.</returns>
    bool Contains(long itemId);
    
    /// <summary>
    /// Returns item identifier if the specified <see cref="ValueTypeCollectionEntry"/> internal value
    /// exists in the collection; otherwise, <see cref="Int64.MinValue"/>.
    /// </summary>
    /// <param name="internalValue">Internal value to check.</param>
    /// <returns>Item identifier if the specified item
    /// exists in the collection; otherwise, <see cref="Int64.MinValue"/>.</returns>
    long GetItemId(object internalValue);
        
    /// <summary>
    /// Searches for the specified ItemID (key) and returns the index of the first occurrence within the current instance.
    /// </summary>
    /// <param name="itemId">The ItemID (key) to locate.</param>
    /// <returns>The index of the first occurrence of value within the entire collection, if found; otherwise, -1.</returns>
    int IndexOf(long itemId);

    /// <summary>
    /// Searches for the specified internal value and returns the index of the first occurrence within the current instance.
    /// </summary>
    /// <param name="internalValue">The InternalValue to locate.</param>
    /// <returns>The index of the first occurrence of value within the entire collection, if found; otherwise, -1.</returns>
    int IndexOf(object internalValue);
        
    /// <summary>
    /// Adds new element to the collection.
    /// </summary>
    /// <param name="iValue">Internal value of item to add.</param>
    /// <returns><see cref="ValueTypeCollectionEntry"/> holding newly added item.</returns>
    ValueTypeCollectionEntry Add(object iValue);
    
    /// <summary>
    /// Adds new element to the collection.
    /// </summary>
    /// <param name="value">Internal value of item to add.</param>
    void Add(ValueTypeCollectionEntry value);

    /// <summary>
    /// Removes element from the collection instance.
    /// </summary>
    /// <param name="value">Item to remove.</param>
    void Remove(ValueTypeCollectionEntry value);
    
    /// <summary>
    /// Gets the element at the specified index.
    /// </summary>
    /// <param name="index">Item index.</param>
    ValueTypeCollectionEntry GetItem(int index);
    
    /// <summary>
    /// Gets the element by its ItemID (key).
    /// </summary>
    /// <param name="itemId">ItemID (key).</param>
    ValueTypeCollectionEntry GetItem(long itemId);
    
    /// <summary>
    /// Marks collection item as changed.
    /// </summary>
    /// <param name="value">Item to mark as changed.</param>
    void MarkItemAsChanged(ValueTypeCollectionEntry value);

    /// <summary>
    /// Indicates whether collection contains delayed updates.
    /// </summary>
    bool IsChanged {get;}

    /// <summary>
    /// Persists all delayed updates from the collection to the database.
    /// </summary>
    void Persist();

    /// <summary>
    /// Clears all delayed updates.
    /// </summary>
    void ClearChanges();
    
    /// <summary>
    /// Loads collection content from <see cref="DataObjects.NET.Caching.GlobalCache"/>.
    /// </summary>
    /// <param name="sHolders">On return contains cached <see cref="StructHolder"/>s.</param>
    /// <returns>Cached collection content.</returns>
    long[] LoadItemsFromGlobalCache(out object[] sHolders);
    
    /// <summary>
    /// Saves collection content to <see cref="DataObjects.NET.Caching.GlobalCache"/>.
    /// </summary>
    void SaveItemsToGlobalCache();
    
    /// <summary>
    /// Loads the number of elements contained in the collection from <see cref="DataObjects.NET.Caching.GlobalCache"/>.
    /// </summary>
    /// <returns>Cached collection size.</returns>
    int LoadCountFromGlobalCache();
    
    /// <summary>
    /// Saves the number of elements contained int the collection to <see cref="DataObjects.NET.Caching.GlobalCache"/>.
    /// </summary>
    void SaveCountToGlobalCache();
  }
}
