using System;

namespace DataObjects.NET.Diagnostics
{
  /// <summary>
  /// Enumeration of possible trace options for <see cref="FileOutputListener"/>.
  /// <seealso cref="FileOutputListener.Options"/>
  /// </summary>
  [Flags]
  public enum FileOutputListenerOptions
  {
    /// <summary>
    /// Default <see cref="FileOutputListener"/> behaviour.
    /// Method name and category are written to the log.
    /// Value is <see langword="0x18"/>.
    /// </summary>
    Default = 0x18,
    /// <summary>
    /// Date and time should be written to the log.
    /// Value is <see langword="0x01"/>.
    /// </summary>
    LogDateTime = 0x01,
    /// <summary>
    /// Thread name should be written to the log.
    /// Value is <see langword="0x02"/>.
    /// </summary>
    LogThread = 0x02,
    /// <summary>
    /// Session name should be written to the log.
    /// Value is <see langword="0x04"/>.
    /// </summary>
    LogSession = 0x04,
    /// <summary>
    /// Method name should be written to the log.
    /// Value is <see langword="0x08"/>.
    /// </summary>
    LogMethod = 0x08,
    /// <summary>
    /// Event category should be written to the log.
    /// Value is <see langword="0x10"/>.
    /// </summary>
    LogCategory = 0x10,
    /// <summary>
    /// Stack trace should be written to the log.
    /// Value is <see langword="0x20"/>.
    /// </summary>
    LogStackTrace = 0x20
  }
}
