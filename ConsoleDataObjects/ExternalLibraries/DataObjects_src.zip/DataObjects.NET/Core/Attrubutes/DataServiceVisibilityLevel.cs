// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Attributes;

namespace DataObjects.NET.Attributes
{
  /// <summary>
  /// Determines service Visibility level of the <see cref="DataService"/>.
  /// <seealso cref="ServiceTypeAttribute"/>
  /// <seealso cref="Session.GetService"/>
  /// <seealso cref="Session.CreateService"/>
  /// </summary>
  public enum DataServiceVisibilityLevel
  {
    /// <summary>
    /// This type of service is visible and available without any restrictions.
    /// Same as <see cref="Public"/>
    /// Value is <see langword="0"/>. 
    /// </summary>
    Default = 0,
    /// <summary>
    /// This type of service is visible and available without any restrictions.
    /// Value is <see langword="0"/>. 
    /// </summary>
    Public = 0,
    /// <summary>
    /// This type of service is visible and available only if session security is disabled.
    /// Value is <see langword="1"/>. 
    /// <seealso cref="SessionBoundObject.DisableSecurity"/>
    /// <seealso cref="SessionBoundObject.EnableSecurity"/>
    /// <seealso cref="DataObjects.NET.Security"/>
    /// <seealso cref="DataObjects.NET.Security.Permissions"/>
    /// <seealso cref="Session.IsSecurityEnabled"/>
    /// </summary>
    Internal = 1,
    /// <summary>
    /// This type of service is visible and available only inside DataObjects.NET.
    /// Value is <see langword="2"/>. 
    /// </summary>
    Private = 2,
  }
}
