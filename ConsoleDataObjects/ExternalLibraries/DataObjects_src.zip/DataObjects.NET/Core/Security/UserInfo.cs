// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using DataObjects.NET;
using DataObjects.NET.Attributes;
using DataObjects.NET.Exceptions;
using DataObjects.NET.FullText;

namespace DataObjects.NET.Security
{
  /// <summary>
  /// Base class for any object that holds additional information related to
  /// the <see cref="User"/>.
  /// <see langword="Persistent, Abstract"/>.
  /// </summary>
  /// <remarks>
  /// <para>
  /// You can find more information about the whole DataObjects.NET
  /// security system <see cref="AccessControlList">here</see>.
  /// </para>
  /// </remarks>
  [Abstract]
  public abstract class UserInfo: FtObject
  {
    /// <summary>
    /// <see langword="Persistent"/>.
    /// <see cref="User"/> that owns this <see cref="UserInfo"/>.
    /// </summary>
    public User User {
      get {return (User)GetProperty("User",null);}
    }
    
    /// <summary>
    /// Gets the parent object for this instance.
    /// This property is used by the security system during permission
    /// demands.
    /// </summary>
    /// <returns>Parent object for this instance.</returns>
    /// <remarks>
    /// This method always returns <see cref="User"/> property value
    /// (or <see cref="DataObjects.NET.Session.SecurityRoot"/> if it is
    /// <see langword="null"/>).
    /// </remarks>
    [NotPersistent]
    [Transactional(TransactionMode.TransactionRequired)]
    public override DataObject SecurityParent {
      get {
        DataObject parent;
        DisableSecurity();
        try {
          parent = (DataObject)GetProperty("User",null);
        }
        finally {
          EnableSecurity();
        }
        return parent!=null ? parent : base.SecurityParent;
      }
    }


    // Constructors

    /// <summary>
    /// Always throws an exception
    /// (InvalidOperationException("This constructor can't be used with FtRecord.")).
    /// </summary>
    protected override void OnCreate()
    {
      throw new InvalidOperationException("This constructor can't be used with UserInfo.");
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="user">Initial <see cref="User"/> property value.</param>
    protected virtual void OnCreate(User user)
    {
      SetProperty("User", null, user);
      base.OnCreate();
    }

    /// <summary>
    /// Called during <see cref="DataObject.SetProperty"/> method execution.
    /// Note that this method isn't invoked during the deserialization.
    /// </summary>
    /// <param name="name">Property name.</param>
    /// <param name="culture">Property culture.</param>
    /// <param name="value">New property value.</param>
    /// <remarks>
    /// <para>
    /// This method allows to set <see cref="User"/> property
    /// without any permission checks for <see cref="OnCreate"/>
    /// method, and denies all attempts to change this property
    /// in future.
    /// </para>
    /// <para>
    /// See <see cref="DataObject.OnSetProperty"/> method description
    /// for additional information.
    /// </para>
    /// </remarks>
    protected override void OnSetProperty(string name, Culture culture, object value)
    {
      if (name=="User") {
        if (!IsCreating) {
          User user = User;
          if (!IsRemoving && user!=null && !user.IsRemoving)
            throw new SecurityException("Property \"User\" can't be changed.");
        }
      }
      base.OnSetProperty(name, culture, value);
    }
  }
}
