// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.ComponentModel;
using DataObjects.NET.Data.Design;

namespace DataObjects.NET.Data
{
  /// <summary>
  /// Field mapping item.
  /// </summary>
  [TypeConverter(typeof(FieldMappingItemConverter))]
  public class FieldMappingItem: MappingItemBase
  {
    private string fieldName;
    private string columnName;
    
    /// <summary>
    /// Gets item name.
    /// </summary>
    public override string Name {
      get {
        if (fieldName!=null)
          return fieldName;
        return "Field Mapping Item";
      }
    }
    
    /// <summary>
    /// Gets or sets field name.
    /// </summary>
    [Category("Mapping")]
    [TypeConverter(typeof(FieldNameConverter))]
    public string FieldName {
      get {
        return fieldName;
      }
      set {
        fieldName = value;
      }
    }
    
    /// <summary>
    /// Gets or sets column name.
    /// </summary>
    [Category("Mapping")]
    [TypeConverter(typeof(ColumnNameConverter))]
    public string ColumnName {
      get {
        return columnName;
      }
      set {
        columnName = value;
      }
    }
    
    /// <summary>
    /// Initializes a new instance of the <see cref="FieldMappingItem"/> class.
    /// </summary>
    public FieldMappingItem(): this(null, null)
    {
    }
    
    /// <summary>
    /// Initializes a new instance of the <see cref="FieldMappingItem"/> class.
    /// </summary>
    /// <param name="fieldName">Field name.</param>
    /// <param name="columnName">Database column name.</param>
    public FieldMappingItem(string fieldName, string columnName): base()
    {
      this.fieldName = fieldName;
      this.columnName = columnName;
    }
  }
}
