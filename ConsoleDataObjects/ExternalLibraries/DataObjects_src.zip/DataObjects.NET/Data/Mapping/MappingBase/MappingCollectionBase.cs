// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;

namespace DataObjects.NET.Data
{
  /// <summary>
  /// Base class for all mapping collections.
  /// </summary>
  public abstract class MappingCollectionBase: IList, ICollection, IEnumerable
  {
    private object owner;
    private ArrayList list = new ArrayList();
    
    /// <summary>
    /// Gets an owner of a collection.
    /// </summary>
    public object Owner {
      get {
        return owner;
      }
    }
    
    /// <summary>
    /// Gets an internal list.
    /// </summary>
    protected ArrayList List {
      get {
        return list;
      }
    }
    
    /// <summary>
    /// Adds an item to the collection.
    /// </summary>
    /// <param name="value">The <see cref="Object"/> to add to the collection.</param>
    /// <returns>The position into which the new element was inserted.</returns>
    public virtual int Add(object value)
    {
      if (value==null)
        throw new ArgumentNullException("value");
      MappingItemBase item = (MappingItemBase)value;
      int index = List.Add(value);
      item.SetMappingCollectionFromContainer(this);
      return index;
    }
    
    /// <summary>
    /// Removes all items from the collection.
    /// </summary>
    public void Clear()
    {
      foreach (MappingItemBase item in List)
        item.SetMappingCollectionFromContainer(null);
      List.Clear();
    }
    
    /// <summary>
    /// Determines whether the collection contains a specific value.
    /// </summary>
    /// <param name="value">The <see cref="Object"/> to locate in the collection. </param>
    /// <returns><see langword="True"/> if the <see cref="Object"/> is found in the collection; otherwise, <see langword="false"/>.</returns>
    public bool Contains(object value)
    {
      return List.Contains(value);
    }
    
    /// <summary>
    /// Determines the index of a specific item in the collection.
    /// </summary>
    /// <param name="value">The <see cref="Object"/> to locate in the collection.</param>
    /// <returns>The index of value if found in the list; otherwise, -1.</returns>
    public int IndexOf(object value)
    {
      return List.IndexOf(value);
    }
    
    /// <summary>
    /// Inserts an item to the collection at the specified position.
    /// </summary>
    /// <param name="index">The zero-based index at which value should be inserted.</param>
    /// <param name="value">The <see cref="Object"/> to insert into the collection.</param>
    public virtual void Insert(int index, object value)
    {
      if (value==null)
        throw new ArgumentNullException("value");
      MappingItemBase item = (MappingItemBase)value;
      List.Insert(index, value);
      item.SetMappingCollectionFromContainer(this);
    }
    
    /// <summary>
    /// Removes the first occurrence of a specific object from the collection.
    /// </summary>
    /// <param name="value">The <see cref="Object"/> to remove from the collection.</param>
    public void Remove(object value)
    {
      if (value==null)
        throw new ArgumentNullException("value");
      MappingItemBase item = (MappingItemBase)value;
      List.Remove(value);
      item.SetMappingCollectionFromContainer(null);
    }
    
    /// <summary>
    /// Removes the collection item at the specified index.
    /// </summary>
    /// <param name="index">The zero-based index of the item to remove.</param>
    public void RemoveAt(int index)
    {
      MappingItemBase item = (MappingItemBase)List[index];
      List.RemoveAt(index);
      item.SetMappingCollectionFromContainer(null);
    }
    
    /// <summary>
    /// Gets a value indicating whether the collection has a fixed size.
    /// </summary>
    public bool IsFixedSize {
      get {
        return List.IsFixedSize;
      }
    }
    
    /// <summary>
    /// Gets a value indicating whether the collection is read-only.
    /// </summary>
    public bool IsReadOnly {
      get {
        return List.IsReadOnly;
      }
    }
    
    /// <summary>
    /// Gets or sets the element at the specified index.
    /// </summary>
    public virtual object this[int index] 
    {
      get {
        return List[index];
      }
      set{
        if (value==null)
          throw new ArgumentNullException("value");
        MappingItemBase item = (MappingItemBase)value;
        MappingItemBase oldItem = (MappingItemBase)List[index];
        if (item!=oldItem) {
          oldItem.SetMappingCollectionFromContainer(null);
          List[index] = item;
          item.SetMappingCollectionFromContainer(this);
        }        
      }
    }
    
    /// <summary>
    /// Copies the elements of the collection to an <see cref="Array"/>, starting at a particular <see langword="Array"/> index.
    /// </summary>
    /// <param name="array">The one-dimensional <see cref="Array"/> that is the destination of the elements copied from collection. The <see langword="Array"/> must have zero-based indexing.</param>
    /// <param name="index"></param>
    void ICollection.CopyTo(Array array, int index)
    {
      List.CopyTo(array, index);
    }

    /// <summary>
    /// Gets the number of elements contained in the collection.
    /// </summary>
    public int Count {
      get {
        return List.Count;
      }
    }
    
    /// <summary>
    /// Gets a value indicating whether access to the collection is synchronized (thread-safe).
    /// </summary>
    public bool IsSynchronized {
      get {
        return List.IsSynchronized;
      }
    }
    
    /// <summary>
    /// Gets an object that can be used to synchronize access to the collection.
    /// </summary>
    public object SyncRoot {
      get {
        return List.SyncRoot;
      }
    }
    
    /// <summary>
    /// Returns an enumerator that can iterate through a collection.
    /// </summary>
    /// <returns>An <see cref="IEnumerator"/> that can be used to iterate through the collection.</returns>
    public IEnumerator GetEnumerator()
    {
      return List.GetEnumerator();
    }
    
    /// <summary>
    /// Returns <see cref="Adapter"/> which uses current mapping collection.
    /// </summary>
    /// <returns><see cref="Adapter"/> which uses current mapping collection.</returns>
    public Adapter GetAdapter()
    {
      object owner = this.Owner;
      if ((owner as Adapter)!=null)
        return (Adapter)owner;
      if ((owner as MappingItemBase)!=null)
        return ((MappingItemBase)owner).GetAdapter();
      return null;
    }
    
    /// <summary>
    /// Initializes a new instance of the <see cref="MappingCollectionBase"/> class.
    /// </summary>
    /// <param name="owner">An owner of a collection.</param>
    public MappingCollectionBase(object owner)
    {
      this.owner = owner;
    }
  }
}
