// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.IO;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Attributes;

namespace DataObjects.NET.Serialization
{
  /// <summary>
  /// Enumerates possible <see cref="Serializer"/> passes.
  /// </summary>
  public enum SerializerPass
  {
    /// <summary>
    /// Serializer is ready.
    /// Value is <see langword="0"/>. 
    /// </summary>
    None = 0,
    /// <summary>
    /// Last pass (actual serialization).
    /// Value is <see langword="0x1FFFFFFF"/>. 
    /// </summary>
    Last = 0x1FFFFFFF,
    /// <summary>
    /// First pass of the serialization (detection of top and contained
    /// <see cref="DataObject"/> instances in the serialization graph).
    /// This pass is used only when required (if flag 
    /// <see langword="IncludeReferedInstances"/> of the 
    /// <see cref="SerializationOptions"/> is off). This pass is performed
    /// on the <see cref="Stream.Null"/> stream.
    /// Value is <see langword="1"/>. 
    /// </summary>
    Detect = 1,
  }
}
