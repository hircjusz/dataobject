// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Runtime.Serialization;

namespace DataObjects.NET.Serialization
{
  /// <summary>
  /// This type is used internally by DataObjects.NET.
  /// </summary>
  internal sealed class FastLoadDataSubstitution: IObjectReference
  {
    internal DataObject realObject;
    /// <summary>
    /// Substituted <see cref="DataObject"/> instance.
    /// </summary>
    public   DataObject RealObject {
      get {return realObject;}
    }

    /// <summary>
    /// Returns real object (substituted <see cref="DataObject"/> instance).
    /// </summary>
    /// <param name="context">Serialization context.</param>
    /// <returns>Real object.</returns>
    public object GetRealObject(StreamingContext context) 
    {
      return realObject;
    }
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="obj">Substituted instance.</param>
    internal FastLoadDataSubstitution(DataObject obj)
    {
      if (obj==null)
        throw new ArgumentNullException("obj");
      realObject = obj;
    }
  }
}
