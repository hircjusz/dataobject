// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Diagnostics;
using DataObjects.NET;
using DataObjects.NET.Caching;
using DataObjects.NET.Database;

namespace DataObjects.NET.Diagnostics
{
  /// <summary>
  /// Internally used as a single access point to all DataObjects.NET 
  /// performance counters.
  /// </summary>
  public class DomainPerformanceCounters
  {
    /// <summary>
    /// <see cref="GlobalCache"/> performance counter category.
    /// Value is "<see langword="DataObjects.NET Global Cache"/>".
    /// </summary>
    public const string  GlobalCache_CounterCategory = "DataObjects.NET Global Cache";
    private const string GlobalCache_CounterCategoryDescription = "DataObjects.NET global cache performance counters.";

    /// <summary>
    /// <see cref="GlobalCache"/> size counter name.
    /// Value is "<see langword="Global cache size"/>".
    /// </summary>
    public const string  GlobalCache_Size_CounterName = "Global cache size";
    private const string GlobalCache_Size_CounterHelp = "Global cache size in bytes";

    /// <summary>
    /// Number of items in the global cache counter name.
    /// Value is "<see langword="Number of items in the global cache"/>".
    /// </summary>
    public const string  GlobalCache_NumberOfItems_CounterName = "Number of items in the global cache";
    private const string GlobalCache_NumberOfItems_CounterHelp = "Number of items in the global cache";

    /// <summary>
    /// Average size of item in the global cache counter name.
    /// Value is "<see langword="Average size of item in the global cache"/>".
    /// </summary>
    public const string  GlobalCache_AverageItemSize_CounterName = "Average size of item in the global cache";
    private const string GlobalCache_AverageItemSize_CounterHelp = "Average size of item in the global cache";

    /// <summary>
    /// % of global cache memory used counter name.
    /// Value is "<see langword="% of global cache memory used"/>".
    /// </summary>
    public const string  GlobalCache_MemoryLoadPrc_CounterName = "% of global cache memory used";
    private const string GlobalCache_MemoryLoadPrc_CounterHelp = "% of available memory used by the global cache";

    

    /// <summary>
    /// % of global cache items used for DataObject instances.
    /// Value is "<see langword="% of global cache items used for DataObject instances"/>".
    /// </summary>
    public const string GlobalCache_DataObjectInstancePrc_CounterName = "% of global cache items used for DataObject instances";
    private const string GlobalCache_DataObjectInstancePrc_CounterHelp = "% of global cache items used for DataObject instances";
    
    /// <summary>
    /// % of global cache memory used for DataObject instances.
    /// Value is "<see langword="% of global cache memory used for DataObject instances"/>".
    /// </summary>
    public const string GlobalCache_DataObjectInstanceSizePrc_CounterName = "% of global cache memory used for DataObject instances";
    private const string GlobalCache_DataObjectInstanceSizePrc_CounterHelp = "% of global cache memory used for DataObject instances";
    
    /// <summary>
    /// % of global cache items used for LoadOnDemand fields.
    /// Value is "<see langword="% of global cache items used for LoadOnDemand fields"/>".
    /// </summary>
    public const string GlobalCache_LoadOnDemandFieldPrc_CounterName = "% of global cache items used for LoadOnDemand fields";
    private const string GlobalCache_LoadOnDemandFieldPrc_CounterHelp = "% of global cache items used for LoadOnDemand fields";
    
    /// <summary>
    /// % of global cache memory used for LoadOnDemand fields.
    /// Value is "<see langword="% of global cache memory used for LoadOnDemand fields"/>".
    /// </summary>
    public const string GlobalCache_LoadOnDemandFieldSizePrc_CounterName = "% of global cache memory used for LoadOnDemand fields";
    private const string GlobalCache_LoadOnDemandFieldSizePrc_CounterHelp = "% of global cache memory used for LoadOnDemand fields";
    
    /// <summary>
    /// % of global cache items used for DataObjectCollections.
    /// Value is "<see langword="% of global cache items used for DataObjectCollections"/>".
    /// </summary>
    public const string GlobalCache_DataObjectCollectionPrc_CounterName = "% of global cache items used for DataObjectCollections";
    private const string GlobalCache_DataObjectCollectionPrc_CounterHelp = "% of global cache items used for DataObjectCollections";
    
    /// <summary>
    /// % of global cache memory used for DataObjectCollections.
    /// Value is "<see langword="% of global cache memory used for DataObjectCollections"/>".
    /// </summary>
    public const string GlobalCache_DataObjectCollectionSizePrc_CounterName = "% of global cache memory used for DataObjectCollections";
    private const string GlobalCache_DataObjectCollectionSizePrc_CounterHelp = "% of global cache memory used for DataObjectCollections";
    
    /// <summary>
    /// % of global cache items used for ValueTypeCollections.
    /// Value is "<see langword="% of global cache items used for ValueTypeCollections"/>".
    /// </summary>
    public const string GlobalCache_ValueTypeCollectionPrc_CounterName = "% of global cache items used for ValueTypeCollections";
    private const string GlobalCache_ValueTypeCollectionPrc_CounterHelp = "% of global cache items used for ValueTypeCollections";
    
    /// <summary>
    /// % of global cache memory used for ValueTypeCollections.
    /// Value is "<see langword="% of global cache memory used for ValueTypeCollections"/>".
    /// </summary>
    public const string GlobalCache_ValueTypeCollectionSizePrc_CounterName = "% of global cache memory used for ValueTypeCollections";
    private const string GlobalCache_ValueTypeCollectionSizePrc_CounterHelp = "% of global cache memory used for ValueTypeCollections";
    
    /// <summary>
    /// Number of global cache queries/sec counter name.
    /// Value is "<see langword="Number of global cache queries/sec"/>".
    /// </summary>
    public const string  GlobalCache_RequestsPerSec_CounterName = "Number of global cache requests/sec";
    private const string GlobalCache_RequestsPerSec_CounterHelp = "Number of global cache requests/sec";

    /// <summary>
    /// Number of global cache hits/sec counter name.
    /// Value is "<see langword="Number of global cache hits/sec"/>".
    /// </summary>
    public const string  GlobalCache_HitsPerSec_CounterName = "Number of global cache hits/sec";
    private const string GlobalCache_HitsPerSec_CounterHelp = "Number of global cache hits/sec";

    /// <summary>
    /// % of global cache hits/sec counter name.
    /// Value is "<see langword="% of global cache hits/sec"/>".
    /// </summary>
    public const string  GlobalCache_HitsPerSecPrc_CounterName = "% of global cache hits/sec";
    private const string GlobalCache_HitsPerSecPrc_CounterHelp = "% of global cache hits/sec";

    /// <summary>
    /// Number of global cache hits with query/sec counter name.
    /// Value is "<see langword="Number of global cache hits with query/sec"/>".
    /// </summary>
    public const string  GlobalCache_HitsPerSecWithQuery_CounterName = "Number of global cache hits with query/sec";
    private const string GlobalCache_HitsPerSecWithQuery_CounterHelp = "Number of global cache hits with version-check query/sec";

    /// <summary>
    /// % of global cache hits with query/sec counter name.
    /// Value is "<see langword="% of global cache hits with query/sec"/>".
    /// </summary>
    public const string  GlobalCache_HitsPerSecWithQueryPrc_CounterName = "% of global cache hits with query/sec";
    private const string GlobalCache_HitsPerSecWithQueryPrc_CounterHelp = "% of global cache hits with version-check query/sec";

    /// <summary>
    /// Number of global cache hits without query/sec counter name.
    /// Value is "<see langword="Number of global cache hits without query/sec"/>".
    /// </summary>
    public const string  GlobalCache_HitsPerSecWithoutQuery_CounterName = "Number of global cache hits without query/sec";
    private const string GlobalCache_HitsPerSecWithoutQuery_CounterHelp = "Number of global cache hits without version-check query/sec";

    /// <summary>
    /// % of global cache hits without query/sec counter name.
    /// Value is "<see langword="% of global cache hits without query/sec"/>".
    /// </summary>
    public const string  GlobalCache_HitsPerSecWithoutQueryPrc_CounterName = "% of global cache hits without query/sec";
    private const string GlobalCache_HitsPerSecWithoutQueryPrc_CounterHelp = "% of global cache hits without version-check query/sec";

    /// <summary>
    /// % of change cache hits without query/sec counter name.
    /// Value is "<see langword="% of global cache hits without query/sec"/>".
    /// </summary>
    public const string ChangeCache_HitsRatio_CounterName = "% of change cache hits ratio";
    private const string ChangeCache_HitsRatio_CounterHelp = "% of global cache hits ratio";
    

    /// <summary>
    /// <see cref="DataObjects.NET.Transaction"/>s performance counter category.
    /// Value is "<see langword="DataObjects.NET Transactions"/>".
    /// </summary>
    public const string  Transactions_CounterCategory = "DataObjects.NET Transactions";
    private const string Transactions_CounterCategoryDescription = "DataObjects.NET transactions performance counters.";
    
    /// <summary>
    /// Number of transactions/sec counter name.
    /// Value is "<see langword="Number of transactions/sec"/>".
    /// </summary>
    public const string  Transactions_TransactionsPerSec_CounterName = "Number of transactions/sec";
    private const string  Transactions_TransactionsPerSec_CounterHelp = "Number of outermost transactions/sec";

    /// <summary>
    /// Number of read-only transactions/sec counter name.
    /// Value is "<see langword="Number of read-only transactions/sec"/>".
    /// </summary>
    public const string Transactions_ReadOnlyTransactionsPerSec_CounterName = "Number of read-only transactions/sec";
    private const string Transactions_ReadOnlyTransactionsPerSec_CounterHelp = "Number of outermost read-only transactions/sec";
    
    /// <summary>
    /// % of read-only transactions/sec counter name.
    /// Value is "<see langword="% of read-only transactions/sec"/>".
    /// </summary>
    public const string Transactions_ReadOnlyTransactionsPerSecPrc_CounterName = "% of read-only transactions/sec";
    private const string Transactions_ReadOnlyTransactionsPerSecPrc_CounterHelp = "% of outermost read-only transactions/sec";
    
    /// <summary>
    /// Number of read-write transactions/sec counter name.
    /// Value is "<see langword="Number of read-write transactions/sec"/>".
    /// </summary>
    public const string Transactions_ReadWriteTransactionsPerSec_CounterName = "Number of read-write transactions/sec";
    private const string Transactions_ReadWriteTransactionsPerSec_CounterHelp = "Number of outermost read-write transactions/sec";
    
    /// <summary>
    /// % of read-write transactions/sec counter name.
    /// Value is "<see langword="% of read-write transactions/sec"/>".
    /// </summary>
    public const string Transactions_ReadWriteTransactionsPerSecPrc_CounterName = "% of read-write transactions/sec";
    private const string Transactions_ReadWriteTransactionsPerSecPrc_CounterHelp = "% of outermost read-write transactions/sec";
    

    // Global cache
    internal IPerformanceCounter   gCache_SizeCounter;
    internal IPerformanceCounter   gCache_ASizeCounter;
    internal IPerformanceCounter   gCache_ItemsCounter;
    internal IPerformanceCounter[] gCache_LoadCounters;

    internal IPerformanceCounter chgCache_HitRatio;

    internal IPerformanceCounter[] gCache_DataObjectInstancePrcCounter;
    internal IPerformanceCounter[] gCache_DataObjectInstanceSizePrcCounter;
    internal IPerformanceCounter[] gCache_LoadOnDemandFieldPrcCounter;
    internal IPerformanceCounter[] gCache_LoadOnDemandFieldSizePrcCounter;
    internal IPerformanceCounter[] gCache_DataObjectCollectionPrcCounter;
    internal IPerformanceCounter[] gCache_DataObjectCollectionSizePrcCounter;
    internal IPerformanceCounter[] gCache_ValueTypeCollectionPrcCounter;
    internal IPerformanceCounter[] gCache_ValueTypeCollectionSizePrcCounter;

    internal IPerformanceCounter   gCache_RequestsPerSecCounter;
    internal IPerformanceCounter   gCache_HitsPerSecCounter;
    internal IPerformanceCounter[] gCache_HitsPerSecPrcCounters;
    internal IPerformanceCounter   gCache_HitsPerSecWithQueryCounter;
    internal IPerformanceCounter[] gCache_HitsPerSecPrcWithQueryCounters;
    internal IPerformanceCounter   gCache_HitsPerSecWithoutQueryCounter;
    internal IPerformanceCounter[] gCache_HitsPerSecPrcWithoutQueryCounters;
    
    // Transactions
    internal IPerformanceCounter   tran_TransactionsPerSecCounter;
    internal IPerformanceCounter   tran_ReadOnlyTransactionsPerSecCounter;
    internal IPerformanceCounter[] tran_ReadOnlyTransactionsPerSecPrcCounter;
    internal IPerformanceCounter   tran_ReadWriteTransactionsPerSecCounter;
    internal IPerformanceCounter[] tran_ReadWriteTransactionsPerSecPrcCounter;

    // Driver-level counters
    // TODO: Add support for driver-level counters
//    internal IPerformanceCounter   driver_FetchedRowsPerSecCounter;
//    internal IPerformanceCounter   driver_FetchedInstantiationInfoPerSecCounter;
//    internal IPerformanceCounter   driver_FetchedValidationInfoPerSecCounter;
//    internal IPerformanceCounter   driver_FetchedInstancePartsPerSecCounter;
//    internal IPerformanceCounter   driver_FetchedCollectionItemPerSecCounter;
//    internal IPerformanceCounter[] driver_FetchedInstantiationInfoPerSecPrcCounters;
//    internal IPerformanceCounter[] driver_FetchedValidationInfoPerSecPrcCounters;
//    internal IPerformanceCounter[] driver_FetchedInstancePartsPerSecPrcCounters;
//    internal IPerformanceCounter[] driver_FetchedCollectionItemPerSecPrcCounters;
//
//    internal IPerformanceCounter   driver_ModifiedInstancesOrCollectionItemsPerSecCounter;
//    internal IPerformanceCounter[] driver_ModifiedInstancesOrCollectionItemsPerSecPrcCounters;
//    internal IPerformanceCounter   driver_ModifiedInstancesPerSecCounter;
//    internal IPerformanceCounter   driver_ModifiedCollectionItemsPerSecCounter;
//    internal IPerformanceCounter[] driver_ModifiedInstancesPerSecPrcCounters;
//    internal IPerformanceCounter[] driver_ModifiedCollectionItemsPerSecPrcCounters;
//
//    internal IPerformanceCounter   driver_QueryPerSecCounter;
//    internal IPerformanceCounter   driver_QueryValidatingCachedInstancePerSecCounter;
//    internal IPerformanceCounter   driver_QueryFetchingInstantiationInfoPerSecCounter;
//    internal IPerformanceCounter   driver_QueryFetchingValidationInfoPerSecCounter;
//    internal IPerformanceCounter   driver_QueryFetchingInstancePartsPerSecCounter;
//    internal IPerformanceCounter   driver_QueryFetchingCollectionItemsPerSecCounter;
//    internal IPerformanceCounter[] driver_QueryFetchingInstantiationInfoPerSecPrcCounters;
//    internal IPerformanceCounter[] driver_QueryFetchingValidationInfoPerSecPrcCounters;
//    internal IPerformanceCounter[] driver_QueryFetchingInstancePartsPerSecPrcCounters;
//    internal IPerformanceCounter[] driver_QueryFetchingCollectionItemsPerSecPrcCounters;
//    
//    internal IPerformanceCounter   driver_QueryModifyingInstancesOrCollectionItemsPerSecCounter;
//    internal IPerformanceCounter[] driver_QueryModifyingInstancesOrCollectionItemsPerSecPrcCounters;
//    internal IPerformanceCounter   driver_QueryModifyingInstancesPerSecCounter;
//    internal IPerformanceCounter   driver_QueryModifyingCollectionItemsPerSecCounter;
//    internal IPerformanceCounter[] driver_QueryModifyingInstancesPerSecPrcCounters;
//    internal IPerformanceCounter[] driver_QueryModifyingCollectionItemsPerSecPrcCounters;
    
    private Domain domain;
    private bool   enabled;

    internal void UpdateGlobalCacheCounters()
    {
#if (!EXPRESS)
      if (!enabled)
        return;
        
      int maxSize     = domain.GlobalCache.Size;
      int currentSize = domain.GlobalCache.CurrentSize;
      int numItems    = domain.GlobalCache.NumberOfItems;
        if (ChangeCache.failCount + ChangeCache.succCount > 0)
            chgCache_HitRatio.RawValue = ChangeCache.succCount * 100/ (ChangeCache.failCount + ChangeCache.succCount);
      gCache_SizeCounter.RawValue = currentSize;
      gCache_LoadCounters[0].RawValue = currentSize;
      gCache_LoadCounters[1].RawValue = maxSize;
      gCache_ItemsCounter.RawValue = numItems;
      gCache_ASizeCounter.RawValue = numItems==0 ? 0 : currentSize / numItems;
      
      gCache_DataObjectInstancePrcCounter[1].RawValue = numItems;
      gCache_LoadOnDemandFieldPrcCounter[1].RawValue = numItems;
      gCache_DataObjectCollectionPrcCounter[1].RawValue = numItems;
      gCache_ValueTypeCollectionPrcCounter[1].RawValue = numItems;
      if (numItems==0) {
        gCache_DataObjectInstancePrcCounter[0].RawValue = 0;
        gCache_LoadOnDemandFieldPrcCounter[0].RawValue = 0;
        gCache_DataObjectCollectionPrcCounter[0].RawValue = 0;
        gCache_ValueTypeCollectionPrcCounter[0].RawValue = 0;
      }
      
      gCache_DataObjectInstanceSizePrcCounter[1].RawValue = maxSize;
      gCache_LoadOnDemandFieldSizePrcCounter[1].RawValue = maxSize;
      gCache_DataObjectCollectionSizePrcCounter[1].RawValue = maxSize;
      gCache_ValueTypeCollectionSizePrcCounter[1].RawValue = maxSize;
      if (currentSize==0) {
        gCache_DataObjectInstanceSizePrcCounter[0].RawValue = 0;
        gCache_LoadOnDemandFieldSizePrcCounter[0].RawValue = 0;
        gCache_DataObjectCollectionSizePrcCounter[0].RawValue = 0;
        gCache_ValueTypeCollectionSizePrcCounter[0].RawValue = 0;
      }
#endif
    }
    
    internal void UpdateGlobalCacheItemCounters(IGlobalCacheItem gcItem, bool add)
    {
#if (!EXPRESS)
      if (!enabled)
        return;
        
      int size = add ? gcItem.Size : -gcItem.Size;
      int cnt = add ? 1 : -1;
      switch (gcItem.ItemType) {
        case GlobalCacheItemType.DataObjectInstance:
          gCache_DataObjectInstancePrcCounter[0].IncrementBy(cnt);
          gCache_DataObjectInstanceSizePrcCounter[0].IncrementBy(size);
          break;
        case GlobalCacheItemType.LoadOnDemandField:
          gCache_LoadOnDemandFieldPrcCounter[0].IncrementBy(cnt);
          gCache_LoadOnDemandFieldSizePrcCounter[0].IncrementBy(size);
          break;
        case GlobalCacheItemType.DataObjectCollection:
          gCache_DataObjectCollectionPrcCounter[0].IncrementBy(cnt);
          gCache_DataObjectCollectionSizePrcCounter[0].IncrementBy(size);
          break;
        case GlobalCacheItemType.ValueTypeCollection:
          gCache_ValueTypeCollectionPrcCounter[0].IncrementBy(cnt);
          gCache_ValueTypeCollectionSizePrcCounter[0].IncrementBy(size);
          break;
      }
#endif
    }

    internal void RegisterCacheHit(InstantiationInfoSource source, bool withAdditionalQuery)
    {
#if (!EXPRESS)
      if (!enabled)
        return;
        
      if (source==InstantiationInfoSource.SessionCache &&
          withAdditionalQuery==false)
        return;
      gCache_RequestsPerSecCounter.Increment();
      gCache_HitsPerSecPrcCounters[1].Increment();
      gCache_HitsPerSecPrcWithQueryCounters[1].Increment();
      gCache_HitsPerSecPrcWithoutQueryCounters[1].Increment();
      if (source!=InstantiationInfoSource.Database) {
        gCache_HitsPerSecCounter.Increment();
        gCache_HitsPerSecPrcCounters[0].Increment();
        // Hit
        if (withAdditionalQuery) {
          gCache_HitsPerSecWithQueryCounter.Increment();
          gCache_HitsPerSecPrcWithQueryCounters[0].Increment();
        }
        else {
          gCache_HitsPerSecWithoutQueryCounter.Increment();
          gCache_HitsPerSecPrcWithoutQueryCounters[0].Increment();
        }
      }
#endif
    }
    
    internal void RegisterTransaction(Transaction transaction)
    {
#if (!EXPRESS)    
      if (!enabled)
        return;
      
      tran_TransactionsPerSecCounter.Increment();
      tran_ReadOnlyTransactionsPerSecPrcCounter[1].Increment();
      tran_ReadWriteTransactionsPerSecPrcCounter[1].Increment();
      
      if (transaction.IsReadOnly) {
        tran_ReadOnlyTransactionsPerSecCounter.Increment();
        tran_ReadOnlyTransactionsPerSecPrcCounter[0].Increment();
      } else {
        tran_ReadWriteTransactionsPerSecCounter.Increment();
        tran_ReadWriteTransactionsPerSecPrcCounter[0].Increment();
      }
#endif
    }

    internal static void Install()
    {
#if (!EXPRESS)
      PerformanceCounterFactory.InstallCategory(GlobalCache_CounterCategory);
      PerformanceCounterFactory.InstallCategory(Transactions_CounterCategory);
#endif
    }

    internal static void UnInstall()
    {
#if (!EXPRESS)    
      PerformanceCounterFactory.UnInstallCategory(GlobalCache_CounterCategory);
      PerformanceCounterFactory.UnInstallCategory(Transactions_CounterCategory);
#endif
    }

    // Constructors

    internal DomainPerformanceCounters(Domain domain, bool enabled)
    {
      this.domain = domain;
      if (enabled && (domain.Name == ""))
        throw new InvalidOperationException("Domain.Name cannot be empty when using performance counters.");
#if (!EXPRESS)    
      this.enabled = enabled;
#else
      this.enabled = false;
#endif
      InitializePerformanceCounters();
    }

    private void InitializePerformanceCounters()
    {
      if (!enabled)
        return;
      
      string instanceName = domain.Name;
      
      gCache_SizeCounter = 
        PerformanceCounterFactory.CreateCounters(GlobalCache_CounterCategory,GlobalCache_Size_CounterName,instanceName)[0];
      gCache_ASizeCounter = 
        PerformanceCounterFactory.CreateCounters(GlobalCache_CounterCategory,GlobalCache_AverageItemSize_CounterName,instanceName)[0];
      gCache_ItemsCounter = 
        PerformanceCounterFactory.CreateCounters(GlobalCache_CounterCategory,GlobalCache_NumberOfItems_CounterName,instanceName)[0];
      gCache_LoadCounters = 
        PerformanceCounterFactory.CreateCounters(GlobalCache_CounterCategory,GlobalCache_MemoryLoadPrc_CounterName,instanceName);

      chgCache_HitRatio = PerformanceCounterFactory.CreateCounters(GlobalCache_CounterCategory, ChangeCache_HitsRatio_CounterName, instanceName)[0];
  
      gCache_DataObjectInstancePrcCounter = 
        PerformanceCounterFactory.CreateCounters(GlobalCache_CounterCategory, GlobalCache_DataObjectInstancePrc_CounterName, instanceName);
      gCache_DataObjectInstanceSizePrcCounter = 
        PerformanceCounterFactory.CreateCounters(GlobalCache_CounterCategory, GlobalCache_DataObjectInstanceSizePrc_CounterName, instanceName);
      gCache_LoadOnDemandFieldPrcCounter = 
        PerformanceCounterFactory.CreateCounters(GlobalCache_CounterCategory, GlobalCache_LoadOnDemandFieldPrc_CounterName, instanceName);
      gCache_LoadOnDemandFieldSizePrcCounter = 
        PerformanceCounterFactory.CreateCounters(GlobalCache_CounterCategory, GlobalCache_LoadOnDemandFieldSizePrc_CounterName, instanceName);
      gCache_DataObjectCollectionPrcCounter = 
        PerformanceCounterFactory.CreateCounters(GlobalCache_CounterCategory, GlobalCache_DataObjectCollectionPrc_CounterName, instanceName);
      gCache_DataObjectCollectionSizePrcCounter = 
        PerformanceCounterFactory.CreateCounters(GlobalCache_CounterCategory, GlobalCache_DataObjectCollectionSizePrc_CounterName, instanceName);
      gCache_ValueTypeCollectionPrcCounter = 
        PerformanceCounterFactory.CreateCounters(GlobalCache_CounterCategory, GlobalCache_ValueTypeCollectionPrc_CounterName, instanceName);
      gCache_ValueTypeCollectionSizePrcCounter = 
        PerformanceCounterFactory.CreateCounters(GlobalCache_CounterCategory, GlobalCache_ValueTypeCollectionSizePrc_CounterName, instanceName);

      gCache_RequestsPerSecCounter = 
        PerformanceCounterFactory.CreateCounters(GlobalCache_CounterCategory,GlobalCache_RequestsPerSec_CounterName,instanceName)[0];
      gCache_HitsPerSecCounter = 
        PerformanceCounterFactory.CreateCounters(GlobalCache_CounterCategory,GlobalCache_HitsPerSec_CounterName,instanceName)[0];
      gCache_HitsPerSecPrcCounters = 
        PerformanceCounterFactory.CreateCounters(GlobalCache_CounterCategory,GlobalCache_HitsPerSecPrc_CounterName,instanceName);
      gCache_HitsPerSecWithQueryCounter = 
        PerformanceCounterFactory.CreateCounters(GlobalCache_CounterCategory,GlobalCache_HitsPerSecWithQuery_CounterName,instanceName)[0];
      gCache_HitsPerSecPrcWithQueryCounters = 
        PerformanceCounterFactory.CreateCounters(GlobalCache_CounterCategory,GlobalCache_HitsPerSecWithQueryPrc_CounterName,instanceName);
      gCache_HitsPerSecWithoutQueryCounter = 
        PerformanceCounterFactory.CreateCounters(GlobalCache_CounterCategory,GlobalCache_HitsPerSecWithoutQuery_CounterName,instanceName)[0];
      gCache_HitsPerSecPrcWithoutQueryCounters = 
        PerformanceCounterFactory.CreateCounters(GlobalCache_CounterCategory,GlobalCache_HitsPerSecWithoutQueryPrc_CounterName,instanceName);
        
      tran_TransactionsPerSecCounter =
        PerformanceCounterFactory.CreateCounters(Transactions_CounterCategory, Transactions_TransactionsPerSec_CounterName, instanceName)[0];
      tran_ReadOnlyTransactionsPerSecCounter =
        PerformanceCounterFactory.CreateCounters(Transactions_CounterCategory, Transactions_ReadOnlyTransactionsPerSec_CounterName, instanceName)[0];
      tran_ReadOnlyTransactionsPerSecPrcCounter =
        PerformanceCounterFactory.CreateCounters(Transactions_CounterCategory, Transactions_ReadOnlyTransactionsPerSecPrc_CounterName, instanceName);
      tran_ReadWriteTransactionsPerSecCounter =
        PerformanceCounterFactory.CreateCounters(Transactions_CounterCategory, Transactions_ReadWriteTransactionsPerSec_CounterName, instanceName)[0];
      tran_ReadWriteTransactionsPerSecPrcCounter =
        PerformanceCounterFactory.CreateCounters(Transactions_CounterCategory, Transactions_ReadWriteTransactionsPerSecPrc_CounterName, instanceName);
    }

    static DomainPerformanceCounters()
    {
#if (!EXPRESS)    
      PerformanceCounterFactory.RegisterCounterCategory(GlobalCache_CounterCategory,GlobalCache_CounterCategoryDescription);
      
      PerformanceCounterFactory.RegisterCounter(GlobalCache_CounterCategory,
        GlobalCache_Size_CounterName, GlobalCache_Size_CounterHelp,
        PerformanceCounterType.NumberOfItems64);
      PerformanceCounterFactory.RegisterCounter(GlobalCache_CounterCategory,
        GlobalCache_AverageItemSize_CounterName, GlobalCache_AverageItemSize_CounterHelp,
        PerformanceCounterType.NumberOfItems64);
      PerformanceCounterFactory.RegisterCounter(GlobalCache_CounterCategory,
        GlobalCache_NumberOfItems_CounterName, GlobalCache_NumberOfItems_CounterHelp,
        PerformanceCounterType.NumberOfItems64);
      PerformanceCounterFactory.RegisterCounter(GlobalCache_CounterCategory,
        GlobalCache_MemoryLoadPrc_CounterName, GlobalCache_MemoryLoadPrc_CounterHelp, 
        PerformanceCounterType.RawFraction);

      PerformanceCounterFactory.RegisterCounter(GlobalCache_CounterCategory,
        ChangeCache_HitsRatio_CounterName, ChangeCache_HitsRatio_CounterHelp,
        PerformanceCounterType.NumberOfItems64);        

      PerformanceCounterFactory.RegisterCounter(GlobalCache_CounterCategory,
        GlobalCache_DataObjectInstancePrc_CounterName, GlobalCache_DataObjectInstancePrc_CounterHelp, 
        PerformanceCounterType.RawFraction);
      PerformanceCounterFactory.RegisterCounter(GlobalCache_CounterCategory,
        GlobalCache_DataObjectInstanceSizePrc_CounterName, GlobalCache_DataObjectInstanceSizePrc_CounterHelp,
        PerformanceCounterType.RawFraction);
      PerformanceCounterFactory.RegisterCounter(GlobalCache_CounterCategory,
        GlobalCache_LoadOnDemandFieldPrc_CounterName, GlobalCache_LoadOnDemandFieldPrc_CounterHelp, 
        PerformanceCounterType.RawFraction);
      PerformanceCounterFactory.RegisterCounter(GlobalCache_CounterCategory,
        GlobalCache_LoadOnDemandFieldSizePrc_CounterName, GlobalCache_LoadOnDemandFieldSizePrc_CounterHelp,
        PerformanceCounterType.RawFraction);
      PerformanceCounterFactory.RegisterCounter(GlobalCache_CounterCategory,
        GlobalCache_DataObjectCollectionPrc_CounterName, GlobalCache_DataObjectCollectionPrc_CounterHelp, 
        PerformanceCounterType.RawFraction);
      PerformanceCounterFactory.RegisterCounter(GlobalCache_CounterCategory,
        GlobalCache_DataObjectCollectionSizePrc_CounterName, GlobalCache_DataObjectCollectionSizePrc_CounterHelp,
        PerformanceCounterType.RawFraction);
      PerformanceCounterFactory.RegisterCounter(GlobalCache_CounterCategory,
        GlobalCache_ValueTypeCollectionPrc_CounterName, GlobalCache_ValueTypeCollectionPrc_CounterHelp, 
        PerformanceCounterType.RawFraction);
      PerformanceCounterFactory.RegisterCounter(GlobalCache_CounterCategory,
        GlobalCache_ValueTypeCollectionSizePrc_CounterName, GlobalCache_ValueTypeCollectionSizePrc_CounterHelp,
        PerformanceCounterType.RawFraction);
        
      PerformanceCounterFactory.RegisterCounter(GlobalCache_CounterCategory,
        GlobalCache_RequestsPerSec_CounterName, GlobalCache_RequestsPerSec_CounterHelp,
        PerformanceCounterType.RateOfCountsPerSecond64);

      PerformanceCounterFactory.RegisterCounter(GlobalCache_CounterCategory,
        GlobalCache_HitsPerSec_CounterName, GlobalCache_HitsPerSec_CounterHelp,
        PerformanceCounterType.RateOfCountsPerSecond64);
      PerformanceCounterFactory.RegisterCounter(GlobalCache_CounterCategory,
        GlobalCache_HitsPerSecPrc_CounterName, GlobalCache_HitsPerSecPrc_CounterHelp,
        PerformanceCounterType.SampleFraction);

      PerformanceCounterFactory.RegisterCounter(GlobalCache_CounterCategory,
        GlobalCache_HitsPerSecWithQuery_CounterName, GlobalCache_HitsPerSecWithQuery_CounterHelp,
        PerformanceCounterType.RateOfCountsPerSecond64);
      PerformanceCounterFactory.RegisterCounter(GlobalCache_CounterCategory,
        GlobalCache_HitsPerSecWithQueryPrc_CounterName, GlobalCache_HitsPerSecWithQueryPrc_CounterHelp,
        PerformanceCounterType.SampleFraction);

      PerformanceCounterFactory.RegisterCounter(GlobalCache_CounterCategory,
        GlobalCache_HitsPerSecWithoutQuery_CounterName, GlobalCache_HitsPerSecWithoutQuery_CounterHelp,
        PerformanceCounterType.RateOfCountsPerSecond64);
      PerformanceCounterFactory.RegisterCounter(GlobalCache_CounterCategory, 
        GlobalCache_HitsPerSecWithoutQueryPrc_CounterName, GlobalCache_HitsPerSecWithoutQueryPrc_CounterHelp,
        PerformanceCounterType.SampleFraction);
        
      
      PerformanceCounterFactory.RegisterCounterCategory(Transactions_CounterCategory, Transactions_CounterCategoryDescription);
      
      PerformanceCounterFactory.RegisterCounter(Transactions_CounterCategory,
        Transactions_TransactionsPerSec_CounterName, Transactions_TransactionsPerSec_CounterHelp,
        PerformanceCounterType.RateOfCountsPerSecond64);
      
      PerformanceCounterFactory.RegisterCounter(Transactions_CounterCategory,
        Transactions_ReadOnlyTransactionsPerSec_CounterName, Transactions_ReadOnlyTransactionsPerSec_CounterHelp,
        PerformanceCounterType.RateOfCountsPerSecond64);
      PerformanceCounterFactory.RegisterCounter(Transactions_CounterCategory,
        Transactions_ReadOnlyTransactionsPerSecPrc_CounterName, Transactions_ReadOnlyTransactionsPerSecPrc_CounterHelp,
        PerformanceCounterType.SampleFraction);

      PerformanceCounterFactory.RegisterCounter(Transactions_CounterCategory,
        Transactions_ReadWriteTransactionsPerSec_CounterName, Transactions_ReadWriteTransactionsPerSec_CounterHelp,
        PerformanceCounterType.RateOfCountsPerSecond64);
      PerformanceCounterFactory.RegisterCounter(Transactions_CounterCategory,
        Transactions_ReadWriteTransactionsPerSecPrc_CounterName, Transactions_ReadWriteTransactionsPerSecPrc_CounterHelp,
        PerformanceCounterType.SampleFraction);
#endif        
    }

    /// <summary>
    /// Finalizer.
    /// Removes all internally maintained performance counters.
    /// </summary>
    ~DomainPerformanceCounters()
    {
      if (!enabled)
        return;

      gCache_SizeCounter.RemoveInstance();
      gCache_ItemsCounter.RemoveInstance();
      gCache_ASizeCounter.RemoveInstance();
      gCache_LoadCounters[0].RemoveInstance();
      gCache_LoadCounters[1].RemoveInstance();
      chgCache_HitRatio.RemoveInstance();
      
      gCache_DataObjectInstancePrcCounter[0].RemoveInstance();
      gCache_DataObjectInstancePrcCounter[1].RemoveInstance();
      gCache_DataObjectInstanceSizePrcCounter[0].RemoveInstance();
      gCache_DataObjectInstanceSizePrcCounter[1].RemoveInstance();
      gCache_LoadOnDemandFieldPrcCounter[0].RemoveInstance();
      gCache_LoadOnDemandFieldPrcCounter[1].RemoveInstance();
      gCache_LoadOnDemandFieldSizePrcCounter[0].RemoveInstance();
      gCache_LoadOnDemandFieldSizePrcCounter[1].RemoveInstance();
      gCache_DataObjectCollectionPrcCounter[0].RemoveInstance();
      gCache_DataObjectCollectionPrcCounter[1].RemoveInstance();
      gCache_DataObjectCollectionSizePrcCounter[0].RemoveInstance();
      gCache_DataObjectCollectionSizePrcCounter[1].RemoveInstance();
      gCache_ValueTypeCollectionPrcCounter[0].RemoveInstance();
      gCache_ValueTypeCollectionPrcCounter[1].RemoveInstance();
      gCache_ValueTypeCollectionSizePrcCounter[0].RemoveInstance();
      gCache_ValueTypeCollectionSizePrcCounter[1].RemoveInstance();

      gCache_RequestsPerSecCounter.RemoveInstance();
      gCache_HitsPerSecCounter.RemoveInstance();
      gCache_HitsPerSecPrcCounters[0].RemoveInstance();
      gCache_HitsPerSecPrcCounters[1].RemoveInstance();
      gCache_HitsPerSecWithQueryCounter.RemoveInstance();
      gCache_HitsPerSecPrcWithQueryCounters[0].RemoveInstance();
      gCache_HitsPerSecPrcWithQueryCounters[1].RemoveInstance();
      gCache_HitsPerSecWithoutQueryCounter.RemoveInstance();
      gCache_HitsPerSecPrcWithoutQueryCounters[0].RemoveInstance();
      gCache_HitsPerSecPrcWithoutQueryCounters[1].RemoveInstance();
      
      tran_TransactionsPerSecCounter.RemoveInstance();
      tran_ReadOnlyTransactionsPerSecCounter.RemoveInstance();
      tran_ReadOnlyTransactionsPerSecPrcCounter[0].RemoveInstance();
      tran_ReadOnlyTransactionsPerSecPrcCounter[1].RemoveInstance();
      tran_ReadWriteTransactionsPerSecCounter.RemoveInstance();
      tran_ReadWriteTransactionsPerSecPrcCounter[0].RemoveInstance();
      tran_ReadWriteTransactionsPerSecPrcCounter[1].RemoveInstance();
    }
  }
}