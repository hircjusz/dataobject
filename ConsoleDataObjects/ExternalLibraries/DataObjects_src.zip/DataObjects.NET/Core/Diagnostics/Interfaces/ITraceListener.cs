// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;

namespace DataObjects.NET.Diagnostics
{
  /// <summary>
  /// This interface should be implemented by any trace listener.
  /// </summary>
  /// <remarks>All methods of trace listener must be thread-safe.</remarks>
  public interface ITraceListener
  {
    /// <summary>
    /// Writes an entry to the event log.
    /// </summary>
    /// <param name="context">Trace context.</param>
    void LogEvent(TraceContext context);
  }
}
