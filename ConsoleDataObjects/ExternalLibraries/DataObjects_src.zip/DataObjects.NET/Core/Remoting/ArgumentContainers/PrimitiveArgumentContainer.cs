// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;

namespace DataObjects.NET.Remoting.ArgumentContainers
{
  /// <summary>
  /// Describes <see cref="ValueType"/> argument, or
  /// and argument of some serializable type.
  /// <see cref="GetValue"/> implementation of this
  /// method does nothing but returns a value provided
  /// to the constructor of this type.
  /// </summary>
  [Serializable]
  public class PrimitiveArgumentContainer : ArgumentContainer
  {
    private object value;

    /// <summary>
    /// Creates a new object that is a copy of a curent instance.
    /// </summary>
    public override object Clone()
    {
      return new PrimitiveArgumentContainer(value);
    }

    /// <summary>
    /// Gets parameter value.
    /// </summary>
    public override object GetValue (CallContext context)
    {
      return value;
    }

    /// <summary>
    /// Sets parameter value.
    /// </summary>
    /// <param name="value"></param>
    protected internal override void SetValue(object value)
    {
      this.value = value;
    }

    // Constructors
    internal PrimitiveArgumentContainer ()
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    private PrimitiveArgumentContainer (object value)
    {
      SetValue(value);
    }
  }
}
