// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;

namespace DataObjects.NET.Data.CodeManage
{
  /// <summary>
  /// Describes an element.
  /// </summary>
  internal interface IElementDescriptor
  {
    /// <summary>
    /// Code manager.
    /// </summary>
    CodeManagerBase CodeManager {get;}
  
    /// <summary>
    /// Element name.
    /// </summary>
    string Name {get;}
    
    /// <summary>
    /// Element full name.
    /// </summary>
    string FullName {get;}
    
    /// <summary>
    /// Element database name.
    /// </summary>
    /// <remarks>May be null.</remarks>
    string DbName {get;}
  }
}
