// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;
using System.Runtime.Serialization;
using DataObjects.NET.Exceptions;

namespace DataObjects.NET
{
  /// <summary>
  /// Base class for any lockable collections that
  /// should be marshalled by reference via .NET Remoting.
  /// </summary>
  [Serializable]
  public abstract class MarshalByRefLockableCollectionBase: MarshalByRefCollectionBase,
    ILockable, ISerializable
  {
    /// <summary>
    /// Determines whether the collection is immutable (locked, read-only). 
    /// </summary>
    /// <remarks>
    /// There is no way to unlock locked collection.
    /// </remarks>
    public bool IsLocked {
      get {
        return InnerList is Array;
      }
    }

    /// <summary>
    /// Locks the collection.
    /// </summary>
    public void Lock() 
    {
      Lock(false);
    }
    
    /// <summary>
    /// Locks the collection and (possible) all dependent objects.
    /// </summary>
    /// <param name="recursive"><see langword="True"/> if all dependent objects should be locked too.</param>
    public virtual void Lock(bool recursive) 
    {
      if (!IsLocked)
        InnerList = ((ArrayList)InnerList).ToArray();
      if (recursive) {
        foreach (Object o in InnerList)
          if (o is ILockable)
            ((ILockable)o).Lock(recursive);
      }
    }

    /// <summary>
    /// Performs additional custom processes when changing the contents of the 
    /// <see cref="MarshalByRefCollectionBase"/> instance.
    /// </summary>
    protected override void OnChange()
    {
      if (IsLocked)
        throw new InstanceIsLockedException("Collection is locked.");
    }

    /// <summary>
    /// Serializer.
    /// </summary>
    /// <param name="info"><see cref="SerializationInfo"/> object.</param>
    /// <param name="context"><see cref="StreamingContext"/> object.</param>
    public virtual void GetObjectData(SerializationInfo info, StreamingContext context)
    {
      info.AddValue("InnerList", InnerList, typeof(IList));
    }

    // Constructors
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <remarks>
    /// This constructor is called by derived class constructors to initialize state in this type.
    /// </remarks>
    protected MarshalByRefLockableCollectionBase(): base()
    {
    }

    /// <summary>
    /// Deserialization constructor.
    /// </summary>
    /// <param name="info"><see cref="SerializationInfo"/> object.</param>
    /// <param name="context"><see cref="StreamingContext"/> object.</param>
    protected MarshalByRefLockableCollectionBase(SerializationInfo info, StreamingContext context)
    {
      InnerList = (IList)info.GetValue("InnerList",typeof(IList));
    }
  }
}
