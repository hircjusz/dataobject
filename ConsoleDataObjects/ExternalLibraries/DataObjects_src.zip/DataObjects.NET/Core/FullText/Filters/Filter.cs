// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.IO;
using System.Text;
using DataObjects.NET.FullText.Filters;

namespace DataObjects.NET.FullText
{
  /// <summary>
  /// Base class for any full-text fillters, including Microsoft Index Service Filters. 
  /// Also works as a factory creating <see cref="Filter"/> objects for 
  /// a particular extension.
  /// </summary>
  /// <remarks>
  /// <example>Example:
  /// <code lang="C#">
  ///   Filter docFilter = Filter.Create("doc");
  ///   FileStream docFile = new FileStream(@"C:\AnyMicrosoftWordFile.doc",FileMode.Open);
  ///   Debug.WriteLine(docFilter.GetFilteredContent(docFile));
  ///
  ///   Filter txtFilter = Filter.Create("txt");
  ///   FileStream txtFile = new FileStream(@"C:\AnyPlainTextFile.txt",FileMode.Open);
  ///   Debug.WriteLine(txtFilter.GetFilteredContent(txtFile));
  /// </code>
  /// </example>
  /// </remarks>
  public abstract class Filter: MarshalByRefObject
  {
    /// <summary>
    /// Gets extension this instance is capable to process.
    /// </summary>
    public abstract string Extension {get;}
    
    /// <summary>
    /// Extracts filtered content from the specified byte array
    /// (applies filter to the specified byte array).
    /// </summary>
    /// <param name="data">A byte array containing document data in the format 
    /// that can be parsed by this instance of <see cref="Filter"/>.</param>
    /// <param name="maxOutputLength">Maximal <see cref="String.Length">length</see> of returned <see cref="String"/>;
    /// <see langword="0"/> means there is no restriction on its <see cref="String.Length">length</see>.</param>
    /// <returns>Extracted filtered content of the document.</returns>
    public string GetFilteredContent(byte[] data, int maxOutputLength)
    {
      return GetFilteredContent(new MemoryStream(data), maxOutputLength);
    }
    
    /// <summary>
    /// Extracts filtered content from the specified byte array
    /// (applies filter to the specified byte array).
    /// </summary>
    /// <param name="data">A byte array containing document data in the format 
    /// that can be parsed by this instance of <see cref="Filter"/>.</param>
    /// <returns>Extracted filtered content of the document.</returns>
    public string GetFilteredContent(byte[] data)
    {
      return GetFilteredContent(new MemoryStream(data), 0);
    }
    
    /// <summary>
    /// Extracts filtered content from the specified byte stream
    /// (applies filter to the specified byte stream).
    /// </summary>
    /// <param name="stream">A stream containing document data in the format 
    /// that can be parsed by this instance of <see cref="Filter"/>.</param>
    /// <returns>Extracted filtered content of the document.</returns>
    public string GetFilteredContent(Stream stream)
    {
      return GetFilteredContent(stream, 0);
    }

    /// <summary>
    /// Extracts filtered content from the specified byte stream
    /// (applies filter to the specified byte stream).
    /// </summary>
    /// <param name="stream">A stream containing document data in the format 
    /// that can be parsed by this instance of <see cref="Filter"/>.</param>
    /// <param name="maxOutputLength">Maximal <see cref="String.Length">length</see> of returned <see cref="String"/>;
    /// <see langword="0"/> means there is no restriction on its <see cref="String.Length">length</see>.</param>
    /// <returns>Extracted filtered content of the document.</returns>
    public abstract string GetFilteredContent(Stream stream, int maxOutputLength);


    // Constructor analogue

    /// <summary>
    /// Creates a <see cref="Filter"/> object for a particular extension.
    /// </summary>
    /// <param name="extension">An extension to create <see cref="IndexServiceFilter"/> for 
    /// (without leading dot, e.g. "txt"). A value of this argument will be
    /// further available via <see cref="Extension"/> property of the newly
    /// created object.</param>
    /// <returns>Newly created <see cref="Filter"/> object (or its descendant) that
    /// is capable to process files with the specified extension.</returns>
    /// <remarks>
    /// <para>This method scans HKLM\SOFTWARE\Microsoft\ContentIndexCommon\Filters\Extension\...
    /// registry key for the specified <paramref name="extension"/>, and
    /// returns a newly created managed wrapper (<see cref="Filter"/> object) 
    /// for located unmanaged Index Service Filter (COM object), if it was found;
    /// otherwise, it returns a newly created <see cref="NullFilter"/> instance.</para>
    /// </remarks>
    public static Filter Create(string extension)
    {
      try {
        return new IndexServiceFilter(extension);
      }
      catch (NotSupportedException) {
        return new NullFilter(extension);
      }
    }
  }
}
