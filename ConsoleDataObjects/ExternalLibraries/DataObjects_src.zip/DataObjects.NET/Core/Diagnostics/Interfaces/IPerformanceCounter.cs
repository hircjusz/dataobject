// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System.Diagnostics;

namespace DataObjects.NET.Diagnostics
{
  internal interface IPerformanceCounter
  {
    string CategoryName { get; set; }

    string CounterHelp { get; }

    string CounterName { get; set; }

    PerformanceCounterType CounterType { get; }

    string InstanceName { get; set; }

    bool ReadOnly { get; set; }

    string MachineName { get; set; }

    long RawValue { get; set; }

    void Close();
    long Decrement();
    long IncrementBy(long value);
    long Increment();
    CounterSample NextSample();
    float NextValue();
    void RemoveInstance();
  }
}
