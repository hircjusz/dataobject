// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;

namespace DataObjects.NET
{
  /// <summary>
  /// Allows to cache a result of <see cref="DataObjects.NET.Query"/>
  /// or <see cref="SqlQuery"/> execution.
  /// </summary>
  /// <remarks>
  /// <note type="Node">Only a <see cref="DataObjects.NET.QueryResult"/>\<see cref="DataObjects.NET.ValueTypeQueryResult"/> themselves are cached
  /// (i.e. a list of <see cref="DataObject.ID"/>s they contain are cached), but not the
  /// content of each fetched object.
  /// </note>
  /// </remarks>
  public class CacheableQuery : CacheableCollection
  {
    private QueryBase query;
    /// <summary>
    /// Gets or sets <see cref="QueryBase"/> object (<see cref="DataObjects.NET.Query"/>
    /// or <see cref="SqlQuery"/>) which <see cref="DataObjects.NET.QueryResult"/>
    /// should be cached.
    /// </summary>
    public QueryBase Query {
      get {
        return query;
      }
      set {
        query = value;
      }
    }
    
    /// <summary>
    /// Recalculates cached <see cref="QueryResult"/>.
    /// </summary>
    /// <remarks>
    /// <para>
    /// Executes appropriate <see cref="Query"/> execution method 
    /// (<see cref="QueryBase.Execute"/>, <see cref="QueryBase.ExecuteCount"/> or
    /// <see cref="QueryBase.ExecuteValueTypeQueryResult"/>), and
    /// assigns result to <see cref="CacheableValue.Value"/> property.
    /// </para>
    /// <para>
    /// See <see cref="CacheableValue.OnCalculateValue">base method description</see>
    /// for additional details.
    /// </para>
    /// </remarks>
    protected override void OnCalculateValue()
    {
      if (query!=null) {
        if ((Query.Options & QueryOptions.Count)!=0)
          Value = Query.ExecuteCount();
        else if (Query.ResultType==QueryResultType.Instances)
          Value = Query.Execute();
        else
          Value = Query.ExecuteValueTypeQueryResult();
      }
    }

    /// <summary>
    /// Gets cached <see cref="DataObjects.NET.QueryResult"/> object returned by
    /// <see cref="DataObjects.NET.QueryBase.Execute"/> method.
    /// </summary>
    public QueryResult QueryResult {
      get {
        return (QueryResult)Value;
      }
    }

    /// <summary>
    /// Gets cached <see cref="DataObjects.NET.ValueTypeQueryResult"/> object returned by
    /// <see cref="DataObjects.NET.QueryBase.ExecuteValueTypeQueryResult"/> method.
    /// </summary>
    public ValueTypeQueryResult ValueTypeQueryResult {
      get {
        return (ValueTypeQueryResult)Value;
      }
    }

    /// <summary>
    /// Gets cached value returned by
    /// <see cref="DataObjects.NET.QueryBase.ExecuteCount"/> method.
    /// </summary>
    public long Count {
      get {
        return (long)Value;
      }
    }

    /// <summary>
    /// Gets cached <see cref="DataObjects.NET.QueryResult"/> object returned by
    /// <see cref="DataObjects.NET.QueryBase.Execute"/> method.
    /// </summary>
    public QueryResult Execute()
    {
      return (QueryResult)Value;
    }

    /// <summary>
    /// Gets cached <see cref="DataObjects.NET.ValueTypeQueryResult"/> object returned by
    /// <see cref="DataObjects.NET.QueryBase.ExecuteValueTypeQueryResult"/> method.
    /// </summary>
    public ValueTypeQueryResult ExecuteValueTypeQueryResult() 
    {
      return (ValueTypeQueryResult)Value;
    }

    /// <summary>
    /// Gets cached value returned by
    /// <see cref="DataObjects.NET.QueryBase.ExecuteCount"/> method.
    /// </summary>
    public long ExecuteCount() 
    {
      return (long)Value;
    }
    

    // Constructors

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="session">Session, to which current instance should be bound.</param>
    public CacheableQuery(Session session) : base(session)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="query">Query object (<see cref="DataObjects.NET.Query"/> or <see cref="SqlQuery"/>),
    /// which result should be cached.</param>
    public CacheableQuery(QueryBase query) : base(query.session)
    {
      this.query = query;
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="query">Query object (<see cref="DataObjects.NET.Query"/> or <see cref="SqlQuery"/>),
    /// which result should be cached.</param>
    /// <param name="expirationPeriod">Initial <see cref="CacheableValue.ExpirationPeriod"/> value.</param>
    public CacheableQuery(QueryBase query, TimeSpan expirationPeriod) : base(query.session, expirationPeriod)
    {
      this.query = query;
    }
  }
}
