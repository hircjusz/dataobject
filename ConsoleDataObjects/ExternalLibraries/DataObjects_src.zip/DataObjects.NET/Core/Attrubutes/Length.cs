// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;

namespace DataObjects.NET.Attributes
{
  /// <summary>
  /// Specifies the length for the property with variable length (e.g. string or
  /// blob).
  /// </summary>
  /// <remarks>
  /// <note>This attribute can be applied to persistent properties which underlying
  /// database type can have some length (size). Examples of such property types:
  /// <see cref="String"/>, <see cref="Array">byte[]</see>, <see cref="Enum"/>
  /// (only when a persistent property has <see cref="SqlTypeAttribute"/> specifying 
  /// that it should be stored as some of SQL string types).</note>
  /// This attribute is a <see cref="DriverTypeSpecificAttribute">driver type-specific</see>,
  /// that means that it can be applied multiple times (with different parameters). 
  /// Each its application can be used or not - dependently on the current type 
  /// of the database driver. 
  /// See <see cref="DriverTypeSpecificAttribute.DriverTypes"/> property
  /// for further information.
  /// <para>
  /// <example>Example:
  /// <code lang="C#">
  ///  public abstract class HomeAnimal: DataObject
  ///  {
  ///    [Indexed]
  ///    [Length(128)] // !!!
  ///    public abstract string Name {get; set;}
  ///    
  ///    [Length(256, Validate=false)] // !!!
  ///    [Validator(typeof(DisallowLongerThan), 256)] // You can attach you own validator here.
  ///    public abstract string Description {get; set;}
  ///    ...
  ///  }
  /// </code>
  /// </example>
  /// </para>
  /// <seealso cref="NullableAttribute"/>
  /// <seealso cref="SqlTypeAttribute"/>
  /// </remarks>
  [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field, 
    AllowMultiple = true, Inherited = true)]
  [Serializable]
  public class LengthAttribute: DriverTypeSpecificAttribute
  {
    private int  length;
    private bool validate = true;
    
    /// <summary>
    /// Length of the property.
    /// </summary>
    public  int Length
    {
      get {return length;}
      set {length = value;}
    }
    
    /// <summary>
    /// Indicates whether DataObjects.NET should automatically validate 
    /// the data size is less or equal to the specified <see cref="LengthAttribute.Length">Length</see> value.
    /// </summary>
    /// <value>If <see langword="false"/> then DataObjects.NET will not automatically validate 
    /// the data size is less or equal to the specified <see cref="LengthAttribute.Length">Length</see> value.
    /// <see langword="True"/> by default.</value>
    public bool Validate
    {
      get {return validate;}
      set {validate=value;}
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="length">Length of the property.</param>
    public LengthAttribute(int length) 
    {
      this.length = length;
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="length">Length of the property.</param>
    /// <param name="validate">If <see langword="false"/> then DataObjects.NET will not automatically validate 
    /// the data size is less or equal to the specified <paramref name="length"/> value.</param>
    public LengthAttribute(int length, bool validate) 
    {
      this.length = length;
      this.validate = validate;
    }
  }
}
