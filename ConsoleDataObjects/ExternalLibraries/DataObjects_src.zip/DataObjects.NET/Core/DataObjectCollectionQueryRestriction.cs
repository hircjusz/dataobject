// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Runtime.Serialization;
using DataObjects.NET;
using DataObjects.NET.ObjectModel;

namespace DataObjects.NET
{
  /// <summary>
  /// Describes a collection-based <see cref="Query"/> restriction.
  /// You can't create instances of this type manually.
  /// <seealso cref="DataObjectCollection"/>
  /// <seealso cref="Query"/>
  /// <seealso cref="SqlQuery"/>
  /// <seealso cref="SqlJoin"/>
  /// </summary>
  public class DataObjectCollectionQueryRestriction: QueryRestriction
  {
    private DataObjectCollectionField collectionField;
    /// <summary>
    /// Gets <see cref="DataObjectCollectionField"/> of the restriction.
    /// </summary>
    public DataObjectCollectionField CollectionField
    {
      get {
        return collectionField;
      }
    }

    private Culture culture;
    /// <summary>
    /// Gets the <see cref="DataObjects.NET.Culture"/> of the restriction.
    /// </summary>
    public Culture Culture
    {
      get {
        return culture;
      }
    }

    private DataObject dataObject;
    /// <summary>
    /// Gets <see cref="DataObject"/> instance containing 
    /// the collection of the restriction.
    /// </summary>
    public DataObject DataObject
    {
      get {
        return dataObject;
      }
    }

    internal DataObjectCollectionQueryRestriction(DataObjectCollectionField collectionField, Culture culture, DataObject dataObject)
    {
      this.collectionField = collectionField;
      this.culture         = culture;
      this.dataObject      = dataObject;
    }
  }
}
