// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using DataObjects.NET.Attributes;
using Offline=DataObjects.NET.Offline;

namespace DataObjects.NET.Helpers
{
  /// <summary>
  /// A <see cref="IPropertyValueValidator">validator</see> that
  /// checks if property value is not <see langword="null"/>; 
  /// throws <see cref="ArgumentOutOfRangeException"/> if this condition
  /// is violated.
  /// <seealso cref="ValidatorAttribute"/>
  /// </summary>
  /// <remarks>
  /// See <see cref="ValidatorAttribute"/> also.
  /// </remarks>
  [Serializable]
  public class DisallowNull: IPropertyValueValidator, Offline.IPropertyValueValidator
  {
    /// <summary>
    /// Validates <see cref="DataObject"/> property value 
    /// before it is actually set by 
    /// <see cref="DataObject.SetProperty">DataObject.SetProperty</see>
    /// method.
    /// </summary>
    /// <param name="dataObject"><see cref="DataObject"/> instance
    /// which property is to be changed.</param>
    /// <param name="propertyName">Property name.</param>
    /// <param name="culture">Property culture.</param>
    /// <param name="value">Value to validate.</param>
    /// <remarks>
    /// Checks if property value is not <see langword="null"/>; 
    /// throws <see cref="ArgumentOutOfRangeException"/> if this condition
    /// is violated.
    /// </remarks>
    public void Validate(DataObject dataObject, string propertyName, Culture culture, object value) 
    {
      Validate(propertyName, value);
    }

    /// <summary>
    /// Validates <see cref="DataObject"/> property value 
    /// before it is actually set by 
    /// <see cref="DataObject.SetProperty">DataObject.SetProperty</see>
    /// method.
    /// </summary>
    /// <param name="dataObject"><see cref="Offline.DataObject"/> instance
    /// which property is to be changed.</param>
    /// <param name="propertyName">Property name.</param>
    /// <param name="culture">Property culture.</param>
    /// <param name="value">Value to validate.</param>
    /// <remarks>
    /// Checks if property value is not <see langword="null"/>; 
    /// throws <see cref="ArgumentOutOfRangeException"/> if this condition
    /// is violated.
    /// </remarks>
    public void Validate(Offline.DataObject dataObject, string propertyName, Offline.Culture culture, object value) 
    {
      Validate(propertyName, value);
    }
    
    private void Validate(string propertyName, object value)
    {
      if (value==null) 
        throw new ArgumentNullException(propertyName,
          String.Format(
            "Value of property \"{0}\" can't be null.", 
            propertyName));
    }
    
    /// <summary>
    /// Attaches a validator instance to a certain field.
    /// </summary>
    /// <param name="field">A <see cref="ObjectModel.Field"/> the validator is related to.</param>
    public void AttachToField (ObjectModel.Field field)
    {
      // Does nothing
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    public DisallowNull()
    {
    }
  }
}
