// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.IO;
using System.Threading;
using System.Configuration;
using System.Diagnostics;
using System.Globalization;
using System.Collections;
using DataObjects.NET;
using DataObjects.NET.Attributes;
using DataObjects.NET.Exceptions;

namespace DataObjects.NET.Security.Permissions
{
  /// <summary>
  /// The presence of this permission for a specific user (or group) tells 
  /// that he is an owner of the <see cref="DataObject"/> instance.
  /// Exactly this permission indirectly grants the following permissions:
  /// <see cref="ReadPermission"/>,
  /// <see cref="ReadPermissionsPermission"/>,
  /// <see cref="SerializationPermission"/>,
  /// <see cref="ChangePermission"/>,
  /// <see cref="ChangePermissionsPermission"/>,
  /// <see cref="ChildrenDeserializationPermission"/>,
  /// <see cref="ChildrenPermissionsDeserializationPermission"/>,
  /// <see cref="RemovePermission"/>.
  /// <seealso cref="IPermission"/>
  /// <seealso cref="IPermissionSet"/>
  /// <seealso cref="PermissionSet"/>
  /// </summary>
  [Serializable]
  public class OwnerPermission: Permission
  {
    private static OwnerPermission _value = new OwnerPermission();
    /// <summary>
    /// Represents the instance of the this class.
    /// Normally you should use this static member to obtain
    /// an instance of this type (e.g. to improve permission
    /// checking cache performance and reduce the memory usage), 
    /// but this isn't strongly required.
    /// </summary>
    public  static OwnerPermission Value {
      get {return _value;}
    }
  }
}
