// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.IO;
using System.Text;
using System.Runtime.Serialization;
using DataObjects.NET.Offline;

namespace DataObjects.NET.Exceptions
{
  /// <summary>
  /// Thrown by syntax analyzers on any syntax-related problems.
  /// </summary>
  [Serializable]
  public class IncorrectExpressionSyntaxException: DataObjectsDotNetException
  {
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    public IncorrectExpressionSyntaxException(): base("Invalid FillDescpriptor definition expression.") {}
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="message">Error message.</param>
    public IncorrectExpressionSyntaxException(string message): base(message) {}

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="message">Error message.</param>
    /// <param name="text">Text containing error.</param>
    /// <param name="pos">Error position.</param>
    public IncorrectExpressionSyntaxException(string message, string text, int pos): 
      base(
        "Incorrect expression syntax ("+message+"): \""+
          text.Substring(0,pos)+
          "[Error]"+
          text.Substring(pos)+"\".") {}

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="text">Text containing error.</param>
    /// <param name="pos">Error position.</param>
    public IncorrectExpressionSyntaxException(string text, int pos): 
      base(
        "Incorrect expression syntax: \""+
          text.Substring(0,pos)+
          "[Error]"+
          text.Substring(pos)+"\".") {}
    
    /// <summary>
    /// Deserialization constructor.
    /// </summary>
    /// <param name="info"><see cref="SerializationInfo"/> object.</param>
    /// <param name="context"><see cref="StreamingContext"/> object.</param>
    protected IncorrectExpressionSyntaxException(SerializationInfo info, StreamingContext context):
      base(info, context)
    {
    }
  }
}
