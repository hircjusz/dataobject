// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using DataObjects.NET.Attributes;

namespace DataObjects.NET.Helpers
{
  /// <summary>
  /// Enumerates different symmetric encryption methods 
  /// (algorithms) that can be used by <see cref="SymmetricEncryptor"/>.
  /// </summary>
  public enum SymmetricEncryptionMethod
  {
    /// <summary>
    /// No encryption (value should be stored as is).
    /// Value is <see langword="0x0"/>.
    /// </summary>
    None = 0x0,
    /// <summary>
    /// Rijndael encryption method.
    /// Value is <see langword="0x1"/>.
    /// </summary>
    Rijndael = 0x1,
    /// <summary>
    /// DES encryption method.
    /// Value is <see langword="0x2"/>.
    /// </summary>
    DES = 0x2,
    /// <summary>
    /// TripleDES encryption method.
    /// Value is <see langword="0x3"/>.
    /// </summary>
    TripleDES = 0x3,
    /// <summary>
    /// RC2 encryption method.
    /// Value is <see langword="0x4"/>.
    /// </summary>
    RC2 = 0x4
  }
}
