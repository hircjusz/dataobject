// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.IO;
using System.Text;
using System.Runtime.InteropServices;
using Microsoft.Win32;

namespace DataObjects.NET.FullText.Filters
{
  /// <summary>
  /// This is a <see cref="Filter"/> implementation that always returns
  /// an <see cref="String.Empty">empty string</see> from its
  /// <see cref="GetFilteredContent"/> method.
  /// </summary>
  public class NullFilter: Filter
  {
    private string extension;
    /// <summary>
    /// Gets extension this instance is capable to process.
    /// </summary>
    public override string Extension {
      get {
        return extension;
      }
    }
    
    /// <summary>
    /// Extracts filtered content from the specified byte stream
    /// (applies filter to the specified byte stream).
    /// </summary>
    /// <param name="stream">A stream containing document data in the format 
    /// that can be parsed by this instance of <see cref="Filter"/>.</param>
    /// <param name="maxOutputLength">Maximal <see cref="String.Length">length</see> of returned <see cref="String"/>;
    /// <see langword="0"/> means there is no restriction on its <see cref="String.Length">length</see>.</param>
    /// <returns>Extracted filtered content of the document.</returns>
    /// <remarks>
    /// The implementation of this method always returns an 
    /// <see cref="String.Empty">empty string</see>.
    /// </remarks>
    public override string GetFilteredContent(Stream stream, int maxOutputLength)
    {
      if (maxOutputLength<0)
        throw new ArgumentOutOfRangeException(
          "maxOutputLength", maxOutputLength, 
          "Maximal output length should be greater then or equal to 0.");
      return string.Empty;
    }
    
    
    // Constructors
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="extension">Initial <see cref="Extension"/> property value.</param>
    public NullFilter(string extension)
    {
      this.extension = extension;
    }
  }
}
