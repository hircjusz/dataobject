// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;

namespace DataObjects.NET
{
  /// <summary>
  /// Enumerator for <see cref="DataObjectRemovalQueue"/>.
  /// </summary>
  public sealed class DataObjectRemovalQueueEnumerator: IEnumerator
  {
    private DataObjectRemovalQueue baseCollection;
    private int currentIndex = -1;

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="baseCollection">Base collection.</param>
    public DataObjectRemovalQueueEnumerator(DataObjectRemovalQueue baseCollection)
    {
      this.baseCollection = baseCollection;
    }
       
    /// <summary>
    /// Sets the enumerator to its initial position, which is before the first element in the collection.
    /// </summary>
    public void Reset()
    {
      currentIndex = -1;
    }
    
    /// <summary>
    /// Gets the current element in the collection.
    /// </summary>
    public object Current {
      get {
        return baseCollection[currentIndex];
      }
    }

    /// <summary>
    /// Advances the enumerator to the next element of the collection.
    /// </summary>
    /// <returns><see langword="True"/> if the enumerator was successfully 
    /// advanced to the next element; otherwise, <see langword="false"/>.</returns>
    public bool MoveNext()
    { 
      if (currentIndex>=baseCollection.Count-1)
        return false;
      currentIndex++;
      return true;
    }       
  }
}
