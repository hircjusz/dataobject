// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.IO;
using System.Reflection;

namespace DataObjects.NET.Internals
{
  internal class AssemblyUtils
  {
    public static byte[] ExtractResourceFile (Assembly containerAssembly, string fileName)
    {
      using(Stream resourceStream = containerAssembly.GetManifestResourceStream(
        "DataObjects.NET.Resources."+fileName)) {
        if (resourceStream!=null && resourceStream.Length>8192) {
          byte[] buffer = new byte[resourceStream.Length];
          resourceStream.Read(buffer, 0, (int) resourceStream.Length);
          return buffer;
        }
        return null;
      }
    }
    
    // If cacheFolder is not null, the asembly will be first saved 
    // into it and then - loaded from disk.
    public static Assembly LoadDriverAssembly(string externalDriver, string cacheFolder)
    {
#if MONO
      if (cacheFolder==null || cacheFolder=="")
        throw new ArgumentNullException("cacheFolder",
          "Domain.ProxyAssemblyCacheFolder cannot be null or empty string.");
      if (!Directory.Exists(cacheFolder))
        Directory.CreateDirectory(cacheFolder);
#endif

      Assembly executingAssembly = Assembly.GetExecutingAssembly();
      Assembly a = null;
      string driverFileName = String.Format("{0}.dll", externalDriver);
      string driverPdbFileName = String.Format("{0}.pdb", externalDriver);
      // Trying to load the driver from resource
      byte[] aBuffer = ExtractResourceFile(executingAssembly, driverFileName);
      byte[] pdbBuffer = null;
      if (aBuffer!=null) {
#if DEBUG
        pdbBuffer = ExtractResourceFile(executingAssembly, driverPdbFileName);;
#endif
        if (cacheFolder==null) {
          if (pdbBuffer!=null)
            a = Assembly.Load(aBuffer, pdbBuffer);
          else
            a = Assembly.Load(aBuffer);
        }
        else {
          // TODO: 
          if (Assembly.GetExecutingAssembly().Location==null)
            throw new DataObjectsDotNetException(
              "DataObjects.NET cannot be loaded from memory.");
          string driverAssemblyCachedLocation = Path.Combine(cacheFolder, driverFileName);
          if (!File.Exists(driverAssemblyCachedLocation)
            || File.GetLastWriteTime(driverAssemblyCachedLocation)<File.GetLastWriteTime(Assembly.GetExecutingAssembly().Location)) {
            FileStream fsDll = new FileStream(driverAssemblyCachedLocation, FileMode.Create, FileAccess.Write, FileShare.Write);
            fsDll.Write(aBuffer, 0, aBuffer.Length);
            fsDll.Close();
            File.SetLastWriteTime(driverAssemblyCachedLocation,File.GetLastWriteTime(Assembly.GetExecutingAssembly().Location));
            if (pdbBuffer!=null) {
              string driverAssemblyPdbCachedLocation = Path.Combine(cacheFolder, driverPdbFileName);
              FileStream fsPdbDll = new FileStream(driverAssemblyPdbCachedLocation, FileMode.Create, FileAccess.Write, FileShare.Write);
              fsPdbDll.Write(pdbBuffer, 0, pdbBuffer.Length);
              fsPdbDll.Close();
              File.SetLastWriteTime(driverAssemblyPdbCachedLocation,File.GetLastWriteTime(Assembly.GetExecutingAssembly().Location));
            }
          }
          a = Assembly.LoadFrom(driverAssemblyCachedLocation);
        }
      }

      // Trying to load the driver from external file
      if (a==null)
        a = Assembly.LoadFrom(driverFileName);
      if (a==null) {
        FileInfo fi = new FileInfo(Assembly.GetExecutingAssembly().Location);
        a = Assembly.LoadFrom(Path.Combine(fi.DirectoryName,driverFileName));
      }
      return a;
    }
  }
}
