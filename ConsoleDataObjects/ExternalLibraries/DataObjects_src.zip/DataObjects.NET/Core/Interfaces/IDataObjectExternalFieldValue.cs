// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using DataObjects.NET.Attributes;

namespace DataObjects.NET
{
  /// <summary>
  /// Interface allowing DataObjects.NET to persist the changes 
  /// accumulated by given instance of <see cref="IDataObjectExternalFieldValue"/>
  /// (<see cref="DataObjectCollection"/> or <see cref="ValueTypeCollection"/>)
  /// to the database by the user defined way.
  /// </summary>
  public interface IDataObjectExternalFieldValue:
    IDataObjectFieldValue
  {
    /// <summary>
    /// Indicates whether field value is completely loaded.
    /// </summary>
    bool IsLoaded {get;}

    /// <summary>
    /// Indicates whether field value contains delayed updates.
    /// </summary>
    bool IsChanged {get;}

    /// <summary>
    /// Gets <see cref="ChangesTrackingMode"/> of the field value.
    /// </summary>
    ChangesTrackingMode ChangesTrackingMode {get;}

    /// <summary>
    /// Persists all changes accumulated by given field value instance 
    /// to the database.
    /// </summary>
    void Persist();
  }
}
