// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Threading;
using System.Diagnostics;
using System.Reflection;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Attributes;

namespace DataObjects.NET
{
  /// <summary>
  /// Represents the savepoint in the <see cref="DataObjects.NET.Transaction"/>.
  /// </summary>
  /// <remarks>
  /// <note type="note">You can create an instance of this class only when
  /// <see cref="DataObjects.NET.Session.SecurityOptions">Session.SecurityOptions</see>
  /// contains <see cref="SessionSecurityOptions.AllowUseSavepoints"/> option.</note>
  /// <example>Usage example:
  /// <code lang="C#">
  ///  d = new Domain("mssql://localhost/DataObjectsDotNetDemos", myProductKey);
  ///  d.NamingMode = DomainNamingMode.UseNamespaces;
  ///  d.RegisterCulture(new Culture("En",  "U.S. English", new CultureInfo("en-us", false)));
  ///  d.Cultures["En"].Default = true;
  ///  d.RegisterTypes("MyApp.PersistentModel");
  ///  d.RegisterServices("MyApp.PersistentModel");
  ///  d.Build(DomainUpdateMode.Perform);
  ///  using (Session s = d.CreateSession()) {
  ///    s.BeginTransaction();
  ///      
  ///    Author a  = (Author)s.CreateObject(typeof(Author));
  ///    a.Name    = "John";
  ///    Savepoint sp = new Savepoint(s);
  ///    a.Surname = "Smith";
  ///    sp.Rollback();
  ///    a.Surname = "Grant";
  ///      
  ///    s.Commit();
  ///  }
  /// </code>
  /// </example>
  /// <seealso cref="DataObjects.NET.Transaction.CreateSavepoint"/>
  /// <seealso cref="DataObjects.NET.Session.CreateSavepoint"/>
  /// </remarks>
  #if (!NoMBR)
  public class Savepoint: MarshalByRefObject, 
  #else
  public class Savepoint: Object, 
  #endif
    IDisposable
  {
    internal Transaction transaction;
    internal int         number;
    private  string      name;
    private  bool        disposed;

    /// <summary>
    /// Gets the <see cref="DataObjects.NET.Transaction"/> of the savepoint.
    /// </summary>
    public  Transaction Transaction {
      get {return transaction;}
    }
    
    /// <summary>
    /// Gets <see cref="DataObjects.NET.Session"/> of the savepoint.
    /// </summary>
    public  Session Session {
      get {return transaction.session;}
    }
    
    /// <summary>
    /// Gets the name of the savepoint.
    /// This property is automatically assigned.
    /// </summary>
    public  string Name {
      get {return name;}
    }
    
    /// <summary>
    /// Rolls back the <see cref="Transaction"/> to this savepoint.
    /// </summary>
    /// <remarks>
    /// You can't repeat this operation for the same savepoint,
    /// and use (rollback to, dispose) any of successive savepoints
    /// after this operation.
    /// </remarks>
    public void Rollback()
    {
      Session session = transaction.session;
      if (disposed)
        throw new InvalidOperationException("Savepoint is disposed.");
      if (transaction.isFinished)
        throw new SecurityException("Transaction is finished or locked.", transaction.RollbackException);
      if (session.transaction!=transaction)
        throw new InvalidOperationException("Savepoint doesn't belongs to the active transaction.");

      Exception persistException = null;
      try {
        session.PersistOnRollback();
      }
      catch (Exception e) {
        persistException = e;
      }

      try {
        session.persister.RollbackToDelayedSavepoint(name);
      }
      catch (Exception e) {
        throw new TransactionAbortedException(
          session.utils.SubstituteException(e));
      }
      finally {
        disposed = true;
        transaction.InvalidateTransactionContext();
      }

      if (persistException!=null)
        throw persistException;
    }
    
    internal void RollbackWithoutInvalidatingTransactionContext()
    {
      Session session = transaction.session;
      if (disposed)
        throw new InvalidOperationException("Savepoint isn't available.");
      try {
        session.persister.RollbackToDelayedSavepoint(name);
        session.savepointNumber = number;
      }
      catch (Exception e) {
        throw session.utils.SubstituteException(e);
      }
      finally {
        disposed = true;
      }
    }
    
    internal void FastRollback()
    {
      disposed = true;
    }

    
    /// <summary>
    /// Initializes a new instance of this class.
    /// <seealso cref="DataObjects.NET.Session.SecurityOptions"/>
    /// <seealso cref="DataObjects.NET.Transaction.CreateSavepoint"/>
    /// <seealso cref="DataObjects.NET.Session.CreateSavepoint"/>
    /// </summary>
    /// <param name="transaction">Transaction to create savepoint in.</param>
    /// <remarks>
    /// <note type="note">You can create an instance of this class only when
    /// <see cref="DataObjects.NET.Session.SecurityOptions">Session.SecurityOptions</see>
    /// contains <see cref="SessionSecurityOptions.AllowUseSavepoints"/> option.</note>
    /// </remarks>
    public Savepoint(Transaction transaction)
    {
      if (transaction==null)
        throw new ArgumentNullException("transaction");
      if (transaction.isFinished) {
        if (transaction.unlockCode!=0)
          throw new TransactionIsLockedException(transaction.rollbackException);
        else
          throw new TransactionIsFinishedException(transaction.rollbackException);
      }
      Session session = transaction.session;
      if (session.disableSecurityThreads[Thread.CurrentThread]==null)
        if ((session.securityOptions & SessionSecurityOptions.AllowUseSavepoints)==0)
          throw new SecurityException("Savepoints aren't allowed.");
      this.transaction = transaction;
      this.number      = session.savepointNumber++;
      this.name        = "Savepoint_"+number.ToString();
      session.Persist();
      try {
        session.persister.CreateDelayedSavepoint(name);
      }
      catch (Exception e) {
        throw session.utils.SubstituteException(e);
      }
    }
    
    internal Savepoint(Transaction transaction, bool internally)
    {
      Session session = transaction.session;
      this.transaction = transaction;
      this.number      = session.savepointNumber++;
      this.name        = "Savepoint_"+number.ToString();
      try {
        session.persister.CreateDelayedSavepoint(name);
      }
      catch (Exception e) {
        throw session.utils.SubstituteException(e);
      }
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// <seealso cref="DataObjects.NET.Transaction.CreateSavepoint"/>
    /// <seealso cref="DataObjects.NET.Session.CreateSavepoint"/>
    /// </summary>
    /// <param name="session">Session to create savepoint in.</param>
    /// <remarks>
    /// <note type="note">You can create an instance of this class only when
    /// <see cref="DataObjects.NET.Session.SecurityOptions">Session.SecurityOptions</see>
    /// contains <see cref="SessionSecurityOptions.AllowUseSavepoints"/> option.</note>
    /// </remarks>
    public Savepoint(Session session): this(session.transaction)
    {
    }
    
    /// <summary>
    /// Disposes the savepoint.
    /// </summary>
    /// <remarks>
    /// <para>
    /// This method is practically used to implement subtrabsactions.
    /// It is called to "commit" subtransaction.
    /// In most cases you aren't required to manualy dispose savepoints.
    /// </para>
    /// <para>
    /// You can't repeat this operation for the same savepoint,
    /// and use (rollback to, dispose) any of successive savepoints
    /// after this operation.
    /// </para>
    /// </remarks>
    public void Dispose()
    {
      if (disposed || transaction.isFinished)
        return;
      try {
        transaction.session.persister.DisposeDelayedSavepoint(name);
        transaction.session.savepointNumber = number;
      }
      catch (Exception e) {
        throw transaction.session.utils.SubstituteException(e);
      }
      finally {
        disposed = true;
      }
    }
  }
}
