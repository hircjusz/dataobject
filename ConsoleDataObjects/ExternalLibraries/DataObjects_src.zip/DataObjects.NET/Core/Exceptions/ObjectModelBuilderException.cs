// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Runtime.Serialization;
using DataObjects.NET.ObjectModel.Builders;

namespace DataObjects.NET.Exceptions
{
  /// <summary>
  /// Thrown by <see cref="ObjectModelBuilder"/> on
  /// different errors during model building process.
  /// <seealso cref="Domain.Build"/>
  /// </summary>
  [Serializable]
  public class ObjectModelBuilderException: DataObjectsDotNetException
  {
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    public ObjectModelBuilderException(): base("Object Model Builder error.") {}
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="text">Text of message.</param>
    public ObjectModelBuilderException(string text): base(text) {}

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="innerException">Inner exception.</param>
    public ObjectModelBuilderException(Exception innerException): this("Object Model Builder error.",innerException) 
    {
    }
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="text">Text of message.</param>
    /// <param name="innerException">Inner exception.</param>
    public ObjectModelBuilderException(string text, Exception innerException): base(text,innerException) 
    {
    }
    
    /// <summary>
    /// Deserialization constructor.
    /// </summary>
    /// <param name="info"><see cref="SerializationInfo"/> object.</param>
    /// <param name="context"><see cref="StreamingContext"/> object.</param>
    protected ObjectModelBuilderException(SerializationInfo info, StreamingContext context):
      base(info, context)
    {
    }
  }
}
