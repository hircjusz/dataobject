// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.IO;
using System.Collections;
using System.Threading;
using System.Data;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization.Formatters.Soap;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Attributes;
using DataObjects.NET.Security;

namespace DataObjects.NET.Serialization
{
  /// <summary>
  /// Serializes and deserializes <see cref="DataObject"/> instances.
  /// </summary>
  /// <remarks>
  /// <para>
  /// You should use this class in order to serialize or deserialize a graph
  /// containing <see cref="DataObject"/> instances.
  /// </para>
  /// <note type="note">You can create an instance of this class only when
  /// <see cref="DataObjects.NET.Session.SecurityOptions">Session.SecurityOptions</see>
  /// contains <see cref="SessionSecurityOptions.AllowUseSerializer"/> option.</note>
  /// <note type="note">All instances from the graph should belong to the same
  /// <see cref="Session"/> in order to serialize it.</note>
  /// <para>The problem with serialization of <see cref="DataObject"/> instances 
  /// is connected with their "sessional" behavior. Any <see cref="DataObject"/>
  /// instance is connected to <see cref="Session"/> and set of other
  /// non-serializable types (e.g. <see cref="Domain"/>). It's impossible
  /// (because of strong design requirements) to create an instance of
  /// <see cref="DataObject"/>, that isn't connected to these objects.
  /// Also there are some other issues, e.g. look 
  /// <see cref="SerializationOptions"/> and <see cref="DeserializationOptions"/>.
  /// </para>
  /// <para><see cref="Serializer"/> overrides default .NET serialization
  /// behavior to connect deserialized <see cref="DataObjects"/> instances
  /// to the <see cref="Session"/> and <see cref="Domain"/>.
  /// </para>
  /// <para>This class internally uses set of special classes
  /// (look <see cref="ISerializationSurrogate"/>, <see cref="SerializationBinder"/>,
  /// <see cref="IObjectReference"/>) to override default serializarion
  /// behavior of <see cref="RealFormatter"/>.
  /// </para>
  /// <note type="note"><see cref="ISecurityRoot"/> object is always serialized
  /// as reference, also its <see cref="DataObject.ID"/> value stored in the
  /// deserialization stream is ignored during the deserialization (because
  /// only one <see cref="ISecurityRoot"/> instance can exist in the storage).
  /// </note>
  /// <seealso cref="DataObjects.NET.Session.CreateSerializer"/>
  /// <seealso cref="DataObject"/>
  /// <seealso cref="IFormatter"/>
  /// <seealso cref="ISerializationSurrogate"/>
  /// <seealso cref="SerializationBinder"/>
  /// <seealso cref="IObjectReference"/>
  /// </remarks>
  #if (!NoMBR)
  public sealed class Serializer: MarshalByRefObject
  #else
  public sealed class Serializer: Object
  #endif
  {
    internal Session                session;
    internal SerializationOptions   serializationOptions   = SerializationOptions.Default;
    internal DeserializationOptions deserializationOptions = DeserializationOptions.Default;
    private  object                 additionalInfo;
    private  IFormatter             realFormatter;
    private  IFormatter             detectionPassFormatter;
    private  FormatterType          formatterType;
    internal SerializerState        state = SerializerState.Ready;
    internal SerializerPass         pass  = SerializerPass.None;
    internal int                    lastOperationInstanceCount  = 0;
    internal int                    lastOperationReferenceCount = 0;
    internal Hashtable              hInclude;
    internal Hashtable              hProcessed;


    /// <summary>
    /// Gets Session where <see cref="Serializer"/> acts.
    /// </summary>
    public   Session Session {
      get {
        return session;
      }
    }
    
    /// <summary>
    /// Gets or sets serialization options.
    /// </summary>
    public   SerializationOptions SerializationOptions {
      get {
        return serializationOptions;
      }
      set {
        serializationOptions = value;
      }
    }
    
    /// <summary>
    /// Gets or sets deserialization options.
    /// </summary>
    public   DeserializationOptions DeserializationOptions {
      get {
        return deserializationOptions;
      }
      set {
        deserializationOptions = value;
      }
    }
    
    /// <summary>
    /// Gets or sets additional serialization information.
    /// </summary>
    /// <remarks>
    /// This property isn't used by <see cref="Serializer"/>,
    /// but it can be used to provide additional information for
    /// serializing\deserializing objects.
    /// </remarks>
    public   object AdditionalInfo {
      get {
        return additionalInfo;
      }
      set {
        additionalInfo = value;
      }
    }
    
    /// <summary>
    /// Gets or sets type style of the formatter.
    /// <seealso cref="BinaryFormatter.TypeFormat"/>
    /// <seealso cref="SoapFormatter.TypeFormat"/>
    /// </summary>
    public   FormatterTypeStyle TypeFormat {
      get {
        if (realFormatter==null)
          throw new InvalidOperationException("RealFormatter is null.");
        SoapFormatter sf = realFormatter as SoapFormatter;
        if (sf!=null)
          return sf.TypeFormat;
        BinaryFormatter bf = realFormatter as BinaryFormatter;
        if (bf!=null)
          return bf.TypeFormat;
        throw new InvalidOperationException("RealFormatter is neither a BinaryFormatter nor a SoapFormatter.");
      }
      set {
        if (realFormatter==null)
          throw new InvalidOperationException("RealFormatter is null.");
        SoapFormatter sf = realFormatter as SoapFormatter;
        if (sf!=null) {
          sf.TypeFormat = value;
          return;
        }
        BinaryFormatter bf = realFormatter as BinaryFormatter;
        if (bf!=null) {
          bf.TypeFormat = value;
          return;
        }
        throw new InvalidOperationException("RealFormatter is neither a BinaryFormatter nor a SoapFormatter.");
      }
    }
    
    /// <summary>
    /// Gets or sets assembly format of the formatter.
    /// <seealso cref="BinaryFormatter.AssemblyFormat"/>
    /// <seealso cref="SoapFormatter.AssemblyFormat"/>
    /// </summary>
    public   FormatterAssemblyStyle AssemblyFormat {
      get {
        if (realFormatter==null)
          throw new InvalidOperationException("RealFormatter is null.");
        SoapFormatter sf = realFormatter as SoapFormatter;
        if (sf!=null)
          return sf.AssemblyFormat;
        BinaryFormatter bf = realFormatter as BinaryFormatter;
        if (bf!=null)
          return bf.AssemblyFormat;
        throw new InvalidOperationException("RealFormatter is neither a BinaryFormatter nor a SoapFormatter.");
      }
      set {
        if (realFormatter==null)
          throw new InvalidOperationException("RealFormatter is null.");
        SoapFormatter sf = realFormatter as SoapFormatter;
        if (sf!=null) {
          sf.AssemblyFormat = value;
          return;
        }
        BinaryFormatter bf = realFormatter as BinaryFormatter;
        if (bf!=null) {
          bf.AssemblyFormat = value;
          return;
        }
        throw new InvalidOperationException("RealFormatter is neither a BinaryFormatter nor a SoapFormatter.");
      }
    }
    
    /// <summary>
    /// Gets <see cref="SerializerState">state</see> of the serializer.
    /// </summary>
    public   SerializerState State {
      get {
        return state;
      }
    }
    
    /// <summary>
    /// Gets <see cref="SerializerPass">pass</see> of the serializer.
    /// </summary>
    public   SerializerPass Pass {
      get {
        return pass;
      }
    }
    
    /// <summary>
    /// Gets or sets the type of formatter to use.
    /// This property also sets <see cref="RealFormatter"/>
    /// value to <see langword="null"/> (if <see langword="FormatterType"/> 
    /// is <see langword="Custom"/>)
    /// or to the <see cref="IFormatter"/> of required type.
    /// </summary>
    public   FormatterType FormatterType {
      get {
        return formatterType;
      }
      set {
        FormatterTypeStyle ts = FormatterTypeStyle.XsdString;
        {
          SoapFormatter sf = realFormatter as SoapFormatter;
          if (sf!=null)
            ts = sf.TypeFormat;
          else {
            BinaryFormatter bf = realFormatter as BinaryFormatter;
            if (bf!=null)
              ts = bf.TypeFormat;
          }
        }
        
        if (value==FormatterType.Custom)
          if (session.disableSecurityThreads[Thread.CurrentThread]==null)
            if ((session.securityOptions & SessionSecurityOptions.AllowAccessRealObjects)==0)
              throw new SecurityException("Custom formatter type can't be used (access to RealObjects disabled).");
        formatterType = value;
        
        switch (value) {
        case FormatterType.Custom:
          realFormatter = null;
          break;
        case FormatterType.Binary:
          BinaryFormatter bf = new BinaryFormatter();
          bf.TypeFormat = ts;
          realFormatter = bf;
          break;
        case FormatterType.Soap:
          SoapFormatter sf = new SoapFormatter();
          sf.TypeFormat = ts;
          realFormatter = sf;
          break;
        }
        
        TuneupFormatter(realFormatter);
      }
    }
    
    /// <summary>
    /// Gets or sets the formetter used to serialize\deserialize
    /// instances.
    /// </summary>
    public IFormatter RealFormatter
    {
      get {
        if (session.disableSecurityThreads[Thread.CurrentThread]==null)
          if ((session.securityOptions & SessionSecurityOptions.AllowAccessRealObjects)==0)
            throw new SecurityException("Access to RealFormatter isn't allowed.");
        return realFormatter;
      }
      set {
        if (formatterType!=FormatterType.Custom)
          throw new InvalidOperationException("FormatterType should be set to Custom to set this property.");
        if (session.disableSecurityThreads[Thread.CurrentThread]==null)
          if ((session.securityOptions & SessionSecurityOptions.AllowAccessRealObjects)==0)
            throw new SecurityException("Access to RealFormatter isn't allowed.");
        realFormatter = value;
        TuneupFormatter(realFormatter);
      }
    }
    
    private void TuneupFormatter(IFormatter formatter)
    {
      if (formatter==null)
        return;

      SurrogateSelector ss = new SurrogateSelector();
      SerializerSerializationSurrogate s = 
        new SerializerSerializationSurrogate(this);
      ss.AddSurrogate(typeof(DataObjectReference), 
        new StreamingContext(StreamingContextStates.All), s);
      foreach (ObjectModel.Type t in session.Types) {
        ss.AddSurrogate(t.SourceType, 
          new StreamingContext(StreamingContextStates.All), s);
        if (!t.IsAbstract)
          ss.AddSurrogate(t.ProxyType,  
            new StreamingContext(StreamingContextStates.All), s);
      }
      formatter.SurrogateSelector = ss;
      formatter.Binder = new SerializerBinder(this);
    }
    
    /// <summary>
    /// Gets number of persistent instances serialized\deserialized 
    /// as true instances during the last operation.
    /// </summary>
    public int LastOperationInstanceCount {
      get {
        return lastOperationInstanceCount;
      }
    }

    /// <summary>
    /// Gets number of persistent instances serialized\deserialized 
    /// as references during the last operation.
    /// </summary>
    public int LastOperationReferenceCount {
      get {
        return lastOperationReferenceCount;
      }
    }
    
    // Methods

    /// <summary>
    /// Serializes an object, or graph of objects with the given root 
    /// to the provided stream.
    /// </summary>
    /// <param name="stream">The stream where the formatter puts the 
    /// serialized data. This stream can reference a variety of backing stores 
    /// (such as files, network, memory, and so on).</param>
    /// <param name="graph">The object, or root of the object graph, to 
    /// serialize. All child objects of this root object are automatically 
    /// serialized.</param>
    /// <remarks>
    /// <para>The <see langword="Serialize"/> method automatically serializes 
    /// the provided objects, and all objects connected to it, to the provided 
    /// stream.
    /// </para>
    /// <para>By default, the serialization process records an object's 
    /// state by gathering the values of all its persistent fields. 
    /// These fields are saved to the stream along with information about 
    /// the object such as the assembly-qualified name for its type.
    /// </para>
    /// <para>
    /// This method acts almost like <see cref="IFormatter.Serialize"/> method
    /// while serializing instances with the only exception - it serializes
    /// instance of non-serializable <see cref="DataObject"/> type.
    /// </para>
    /// <seealso cref="FormatterType"/>
    /// <seealso cref="SerializationOptions"/>
    /// <seealso cref="DeserializationOptions"/>
    /// </remarks>
    public void Serialize(Stream stream, object graph)
    {
      if (realFormatter==null)
        throw new InvalidOperationException("Custom formatter isn't specified while FormatterType.Custom is used.");
      if (state!=SerializerState.Ready)
        throw new InvalidOperationException(String.Format(
          "Serializer is already {0} a graph.",state.ToString().ToLower()));
      
      TransactionController tc = session.CreateTransactionController( 
        TransactionMode.TransactionRequired, IsolationLevel.RepeatableRead);
      state = SerializerState.Serializing;
      try {
        InnerSerialize(stream, graph);
        tc.Commit();
      }
      catch (Exception e) {
        tc.Rollback(e);
        throw;
      }
      finally {
        hInclude = null;
        hProcessed = null;
        pass  = SerializerPass.None;
        state = SerializerState.Ready;
      }
    }
    private void InnerSerialize(Stream stream, object graph)
    {
      lastOperationInstanceCount  = 0;
      lastOperationReferenceCount = 0;
      if ((serializationOptions & SerializationOptions.IncludeReferedInstances)==0) {
        hInclude = new Hashtable();
        pass = SerializerPass.Detect;
        realFormatter.Serialize(Stream.Null, graph);
      }
      lastOperationInstanceCount  = 0;
      lastOperationReferenceCount = 0;
      hProcessed = new Hashtable();
      pass = SerializerPass.Last;
      realFormatter.Serialize(stream, graph);
    }
    
    /// <summary>
    /// Deserializes the data on the provided stream and reconstitutes the graph of objects.
    /// </summary>
    /// <param name="stream">The stream containing the data to deserialize.</param>
    /// <returns>The top object of the deserialized graph.</returns>
    /// <remarks>
    /// <para>The <see langword="Deserialize"/> method reads graph information 
    /// from the stream and reconstructs a clone of the original graph. 
    /// The topology of the graph is preserved.
    /// </para>
    /// <para>The deserialization process allocates an empty object 
    /// of the appropriate type and repopulates its fields from the 
    /// data transmitted in the serializationStream stream. It is important 
    /// to note that no constructor is ever called on the object during 
    /// deserialization.
    /// </para>
    /// <para>
    /// This method acts almost like <see cref="IFormatter.Deserialize"/> method
    /// while serializing instances with the only exception - it serializes
    /// instance of non-serializable <see cref="DataObject"/> type.
    /// </para>
    /// <seealso cref="FormatterType"/>
    /// <seealso cref="SerializationOptions"/>
    /// <seealso cref="DeserializationOptions"/>
    /// </remarks>
    public object Deserialize(Stream stream)
    {
      if (realFormatter==null)
        throw new InvalidOperationException("Custom formatter isn't specified while FormatterType.Custom is used.");
      if (state!=SerializerState.Ready)
        throw new InvalidOperationException(String.Format(
          "Serializer is already {0} a graph.",state.ToString().ToLower()));
        
      TransactionController tc = session.CreateTransactionController( 
        TransactionMode.NewTransactionRequired, IsolationLevel.RepeatableRead);
      state = SerializerState.Deserializing;
      try {
        object r = InnerDeserialize(stream);
        tc.Commit();
        return r;
      }
      catch (Exception e) {
        tc.Rollback(e);
        throw;
      }
      finally {
        hProcessed = null;
        pass  = SerializerPass.None;
        state = SerializerState.Ready;
      }
    }
    private object InnerDeserialize(Stream stream)
    {
      lastOperationInstanceCount  = 0;
      lastOperationReferenceCount = 0;
      hProcessed = new Hashtable();
      pass = SerializerPass.Last;
      try {
        object r = realFormatter.Deserialize(stream);
        foreach (DataObject o in hProcessed.Values)
          o.GraphPreDeserialized(this);
        foreach (DataObject o in hProcessed.Values)
          o.serializationInfo = null;
        foreach (DataObject o in hProcessed.Values)
          o.GraphDeserialized(this);
        return r;
      }
      catch (Exception) {
        foreach (DataObject o in hProcessed.Values) {
          try {
            o.serializationInfo = null;
            o.ConvertToRemoved();
          } catch {}
        }
        throw;
      }
    }
    
    
    // Constructors

    /// <summary>
    /// Initializes a new instance of this class.
    /// <seealso cref="DataObjects.NET.Session.CreateSerializer"/>
    /// </summary>
    /// <param name="session">Session of the serializer.</param>
    public Serializer(Session session)
    {
      if (session==null)
        throw new ArgumentNullException("session");
      if (session.disableSecurityThreads[Thread.CurrentThread]==null)
        if ((session.securityOptions & SessionSecurityOptions.AllowUseSavepoints)==0)
          throw new SecurityException("Use of Serializer isn't allowed.");
      this.session = session;
      this.FormatterType = FormatterType.Binary;
      this.detectionPassFormatter = new BinaryFormatter();
      TuneupFormatter(detectionPassFormatter);
    }
  }
}
