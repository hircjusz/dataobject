// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using DataObjects.NET;
using DataObjects.NET.Caching;

namespace DataObjects.NET.Database
{
  /// <summary>
  /// Holds the information required to validate a particular
  /// cached <see cref="DataObjectInstantiationInfo"/> without additional queries.
  /// </summary>
  public class DataObjectValidationInfo : DataObjectIdentificationInfo,
    IGlobalCacheItemValidationInfo
  {
    private int versionID;
    private TransactionContext transactionContext;
    
    /// <summary>
    /// Gets a key that is used as a global cache key.
    /// </summary>
    object IGlobalCacheItemValidationInfo.Key {
      get {
        return ID;
      }
    }
    
    /// <summary>
    /// Returns estimated size of this object in bytes.
    /// </summary>
    public override int Size {
      get {
        return 12 + 8;
      }
    }
    
    /// <summary>
    /// Gets or sets <see cref="DataObject.VersionID"/> property value.
    /// </summary>
    public int VersionID {
      get {
        return versionID;
      }
      set {
        versionID = value;
      }
    }

    /// <summary>
    /// Gets or sets transaction context, where all specified data was fetched.
    /// </summary>
    public TransactionContext TransactionContext {
      get {
        return transactionContext;
      }
      set {
        transactionContext = value;
      }
    }

    
    // Constructors
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    public DataObjectValidationInfo()
    {
    }
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="ID">Initial <see cref="DataObjectIdentificationInfo.ID"/> value.</param>
    /// <param name="VersionID">Initial <see cref="DataObjectValidationInfo.VersionID"/> value.</param>
    /// <param name="TransactionContext">Initial <see cref="TransactionContext"/> value.</param>
    public DataObjectValidationInfo(
      long   ID,
      int    VersionID,
      TransactionContext TransactionContext): base(ID)
    {
      this.versionID = VersionID;
      this.transactionContext = TransactionContext;
    }
  }
}
