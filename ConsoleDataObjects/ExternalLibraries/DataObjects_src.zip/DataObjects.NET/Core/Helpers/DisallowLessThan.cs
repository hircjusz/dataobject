// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using DataObjects.NET.Attributes;

namespace DataObjects.NET.Helpers
{
  /// <summary>
  /// A <see cref="IPropertyValueValidator">validator</see> that
  /// checks if property value is greater then or equals to specified constant;
  /// throws <see cref="ArgumentOutOfRangeException"/> if this condition
  /// is violated.
  /// <seealso cref="ValidatorAttribute"/>
  /// </summary>
  /// <remarks>
  /// See <see cref="ValidatorAttribute"/> also.
  /// </remarks>
  [Serializable]
  public class DisallowLessThan
    : IPropertyValueValidator,
      Offline.IPropertyValueValidator 
  {
    // We should hold object references here instead of IComparable ones
    // to prevent bug with a Validators deserialization
    private object compareTo;
    private object offlineCompareTo;

    /// <summary>
    /// Gets minimal property value that passes through this validator.
    /// </summary>
    public IComparable CompareTo {
      get {
        return (IComparable) compareTo;
      }
    }

    private IComparable OfflineCompareTo {
      get {
        return (IComparable)offlineCompareTo;
      }
    }

    /// <summary>
    /// Validates <see cref="DataObject"/> property value 
    /// before it is actually set by 
    /// <see cref="DataObject.SetProperty">DataObject.SetProperty</see>
    /// method.
    /// </summary>
    /// <param name="dataObject"><see cref="DataObject"/> instance
    /// which property is to be changed.</param>
    /// <param name="propertyName">Property name.</param>
    /// <param name="culture">Property culture.</param>
    /// <param name="value">New property value.</param>
    /// <remarks>
    /// Checks if property value is greater then or equals to specified constant; 
    /// throws <see cref="ArgumentOutOfRangeException"/> if this condition
    /// is violated.
    /// </remarks>
    public void Validate(DataObject dataObject, string propertyName, Culture culture, object value) 
    {
      if (value==null)
        return;
      if (CompareTo.CompareTo(value)>0)
        throw new ArgumentOutOfRangeException(propertyName, value,
          String.Format(
            "Value of property \"{0}\" can't be less then {1} (actual value is {2}).", 
            propertyName, compareTo, value));
    }

    /// <summary>
    /// Validates <see cref="DataObject"/> property value 
    /// before it is actually set by 
    /// <see cref="DataObject.SetProperty">DataObject.SetProperty</see>
    /// method.
    /// </summary>
    /// <param name="dataObject"><see cref="Offline.DataObject"/> instance
    /// which property is to be changed.</param>
    /// <param name="propertyName">Property name.</param>
    /// <param name="culture">Property culture.</param>
    /// <param name="value">New property value.</param>
    /// <remarks>
    /// Checks if property value is greater then or equals to specified constant; 
    /// throws <see cref="ArgumentOutOfRangeException"/> if this condition
    /// is violated.
    /// </remarks>
    public void Validate(Offline.DataObject dataObject, string propertyName, Offline.Culture culture, object value) 
    {
      if (value==null)
        return;
      if (OfflineCompareTo.CompareTo(value)>0)
        throw new ArgumentOutOfRangeException(propertyName, value,
          String.Format(
            "Value of property \"{0}\" can't be less then {1} (actual value is {2}).", 
            propertyName, offlineCompareTo, value));
    }
    
    /// <summary>
    /// Attaches a validator instance to a certain field.
    /// </summary>
    /// <param name="field">A <see cref="ObjectModel.Field"/> the validator is related to.</param>
    public void AttachToField (ObjectModel.Field field)
    {
      offlineCompareTo = (IComparable) Internals.TypeUtils.ConvertValueToType(compareTo, field.OfflineExternalType);
      compareTo = (IComparable) Internals.TypeUtils.ConvertValueToType(compareTo, field.ExternalType);
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="compareTo">Minimal property value that passes through this validator.</param>
  #if !MONO
    public DisallowLessThan(IComparable compareTo)
    {
      if (compareTo==null)
        throw new ArgumentNullException("compareTo");
      this.compareTo = compareTo;
    }
  #else
    public DisallowLessThan(object compareTo)
    {
      if (compareTo==null)
        throw new ArgumentNullException("compareTo");
      this.compareTo = compareTo as IComparable;
      if (this.compareTo==null)
        throw new ArgumentException( "Argument should implement IComparable interface", "compareTo");
    }
  #endif
  }
}
