// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;

namespace DataObjects.NET.Database.Drivers.MSAccess
{
  /// <summary>
  /// Contains Microsoft Access database driver implementation.
  /// </summary>
  internal class NamespaceDoc {}
}
