// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.IO;
using System.Threading;
using System.Configuration;
using System.Diagnostics;
using System.Globalization;
using System.Collections;
using DataObjects.NET;
using DataObjects.NET.Attributes;
using DataObjects.NET.Exceptions;

namespace DataObjects.NET.Security
{
  /// <summary>
  /// Enumeration of possible <see cref="Principal"/> types.
  /// <seealso cref="SystemObjectNames"/>
  /// <seealso cref="SystemObjects"/>
  /// </summary>
  /// <remarks>
  /// <para>
  /// You can find more information about the whole DataObjects.NET
  /// security system <see cref="AccessControlList">here</see>.
  /// </para>
  /// </remarks>
  public enum PrincipalType
  {
    /// <summary>
    /// A normal (non-system) <see cref="Principal"/> (<see cref="User"/> or <see cref="Role"/>).
    /// </summary>
    Normal = 0,
    /// <summary>
    /// An Anonymous <see cref="User"/>.
    /// </summary>
    AnonymousUser,
    /// <summary>
    /// A Guest <see cref="User"/>.
    /// </summary>
    GuestUser,
    /// <summary>
    /// An Administrator <see cref="User"/>.
    /// </summary>
    AdministratorUser,
    /// <summary>
    /// A System <see cref="User"/>.
    /// </summary>
    SystemUser,
    /// <summary>
    /// An Everyone <see cref="Role"/>.
    /// </summary>
    EveryoneRole,
    /// <summary>
    /// A Guests <see cref="Role"/>.
    /// </summary>
    GuestsRole,
    /// <summary>
    /// A Users <see cref="Role"/>.
    /// </summary>
    UsersRole,
    /// <summary>
    /// An Administrators <see cref="Role"/>.
    /// </summary>
    AdministratorsRole
  }
}
