// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Data;
using DataObjects.NET;
using DataObjects.NET.Data;

namespace DataObjects.NET.Data
{
  /// <summary>
  /// Specifies <see cref="Adapter"/> fill behaviour.
  /// </summary>
  [Flags]
  public enum FillOptions
  {
    /// <summary>
    /// Default behaviour.
    /// Value is <see langword="0x0"/>.
    /// </summary>
    Default = 0x0,
    
    /// <summary>
    /// Ignore errors that could appear while filling a <see cref="DataObject"/> instance
    /// to a <see cref="Adapter.DataSource"/>.
    /// Value is <see langword="0x1"/>.
    /// </summary>
    IgnoreErrors = 0x1,
    
    /// <summary>
    /// Makes <see cref="Adapter"/> remove all conflict
    /// rows before continue filling current <see cref="DataObject"/>.
    /// Value is <see langword="0x2"/>.
    /// </summary>
    RemoveOnConflict = 0x2,
    
    /// <summary>
    /// Makes <see cref="Adapter"/> remove all conflict
    /// rows before continue filling the collection.
    /// Value is <see langword="0x4"/>.
    /// </summary>
    RemoveOnCollectionConflict = 0x4
  }
  
  /// <summary>
  /// Specifies <see cref="Adapter"/> update behaviour.
  /// </summary>
  [Flags]
  public enum UpdateOptions
  {
    /// <summary>
    /// Default behaviour.
    /// Value is <see langword="0x0"/>.
    /// </summary>
    Default = 0x0,
    
    /// <summary>
    /// Ignore errors that could appear while creating, removing or updating 
    /// a <see cref="DataObject"/> instance from a <see cref="Adapter.DataSource"/>.
    /// Value is <see langword="0x1"/>.
    /// </summary>
    IgnoreErrors = 0x1,
    
    /// <summary>
    /// Fills <see cref="DataObject.VersionID"/> only.
    /// Value is <see langword="0x2"/>.
    /// </summary>
    FillVersionOnly = 0x2
  }
}
