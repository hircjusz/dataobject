// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;
using System.Collections.Specialized;
using System.Runtime.Serialization;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Attributes;

namespace DataObjects.NET
{
  /// <summary>
  /// Collection of <see cref="Culture"/>s registered in the <see cref="Domain"/>
  /// (see <see cref="DataObjects.NET.Domain.Cultures">Domain.Cultures</see>).
  /// <seealso cref="Domain"/>
  /// <seealso cref="DataObjects.NET.Domain.Cultures"/>
  /// <seealso cref="DataObjects.NET.Domain.RegisterCulture"/>
  /// </summary>
  [Serializable]
  public sealed class CultureCollection: MarshalByRefLockableCollectionBase
  { 
    private Domain domain = null;
    /// <summary>
    /// <see cref="Domain"/> to which this collection belongs.
    /// </summary>
    public  Domain Domain {
      get {return domain;}
    }
    
    private Culture defaultCulture = null;
    /// <summary>
    /// Gets the <see cref="Culture"/> with the <see cref="Culture.Default"/> property
    /// set to <see langword="true"/> (from this collection).
    /// </summary>
    public  Culture DefaultCulture {
      get {return defaultCulture;}
    }
    
    /// <summary>
    /// This internal method allows others to set DefaultCulture property.
    /// </summary>
    /// <param name="value">New <see cref="DefaultCulture"/> value.</param>
    internal void SetDefaultCultureInternally(Culture value)
    {
      if (!IsLocked)
        defaultCulture = value;
      else
        throw new InstanceIsLockedException("Instance is locked.");
    }
    
    Culture[]        objectByIndex;
    HybridDictionary objectByName;
    HybridDictionary indexByName;
    
    /// <summary>
    /// Collection indexer.
    /// </summary>
    public Culture this[int n] {
      get {
        if (objectByIndex!=null)
          return objectByIndex[n];
        return (Culture)List[n];
      }
      set {
        List[n] = value;
      }
    }
    
    /// <summary>
    /// An indexer that provides access to collection items by their names.
    /// Returns <see langword="null"/> if there is no such item.
    /// </summary>
    public Culture this[string name] {
      get {
        if (objectByName!=null)
          return (Culture)objectByName[name];
        foreach (Culture n in List) {
          if (n.Name==name)
            return n;
        }
        return null;
      }
    }
    
    /// <summary>
    /// Locks the instance and (possible) all dependent objects.
    /// </summary>
    /// <param name="recursive"><see langword="True"/> if all dependent objects should be locked too.</param>
    public override void Lock(bool recursive) 
    {
      base.Lock(recursive);
      objectByIndex = new Culture[Count];
      objectByName = new HybridDictionary(Count);
      indexByName  = new HybridDictionary(Count);
      int i = 0;
      foreach (Culture o in List) {
        objectByIndex[i] = o;
        objectByName[o.Name] = o;
        indexByName[o.Name] = i++;
      }
    }

    /// <summary>
    /// Adds new culture to this collection. If element with the same
    /// name is already exists in this collection, <see cref="InvalidOperationException"/>
    /// will be thrown.
    /// </summary>
    /// <param name="culture">Culture to add.</param>
    public int Add(Culture culture)
    {
      return List.Add(culture);
    }
    
    /// <summary>
    /// Determines, if this collection contains specified culture.
    /// </summary>
    /// <param name="culture">Culture to search for.</param>
    /// <returns><see langword="True"/> if culture was found.</returns>
    public bool Contains(Culture culture)
    {
      if (indexByName!=null)
        return indexByName[culture.Name]!=null;
      return List.Contains(culture);
    }

    /// <summary>
    /// Copies elements of this collection to <see cref="Array"/>.
    /// </summary>
    /// <param name="cultures">Destination array.</param>
    /// <param name="offset">Offset in array to start from.</param>
    public void CopyTo(Culture[] cultures, int offset)
    {
      List.CopyTo(cultures, offset);
    }

    /// <summary>
    /// Searches for the specified object and returns the culture of the first occurrence within the current instance.
    /// </summary>
    /// <param name="culture">The object to locate.</param>
    /// <returns>The culture of the first occurrence of value within the entire collection, if found; otherwise, -1.</returns>
    public int IndexOf(Culture culture)
    {
      if (indexByName!=null) {
        object r = indexByName[culture.Name];
        return (r!=null) ? ((int)r) : -1;
      }
      return List.IndexOf(culture);
    }

    /// <summary>
    /// Inserts culture to collection.
    /// </summary>
    /// <param name="offset">Offset of culture.</param>
    /// <param name="culture">Culture to insert.</param>
    public void Insert(int offset, Culture culture)
    {
      List.Insert(offset, culture);
    }

    /// <summary>
    /// Removes culture from collection.
    /// </summary>
    /// <param name="culture">Culture to remove.</param>
    public void Remove(Culture culture)
    {
      List.Remove(culture);
    }
    
    /// <summary>
    /// Performs additional custom processes when clearing the contents of the 
    /// <see cref="MarshalByRefCollectionBase"/> instance.
    /// </summary>
    protected override void OnClear()
    {
      defaultCulture = null;
      foreach (Culture n in List)
        n.SetDomainFromContainer(null);
    }
    
    /// <summary>
    /// Performs additional custom processes before inserting a new element into the
    /// <see cref="MarshalByRefCollectionBase"/> instance.
    /// </summary>
    /// <param name="culture">The zero-based <paramref name="culture"/> at which to insert value.</param>
    /// <param name="value">The new value of the element at <paramref name="culture"/>.</param>
    protected override void OnInsert(int culture, Object value) 
    {
      Culture t = (Culture)value;
      if (this[t.Name]!=null)
        throw new InvalidOperationException(String.Format("Culture with name \"{0}\" already exists.",t.Name));
      if (t.Default && defaultCulture!=null)
        throw new InvalidOperationException("Only one default culture is allowed.");
      t.Domain = null;
      t.SetDomainFromContainer(this.domain);
      if (t.Default)
        defaultCulture = t;
    }
    
    /// <summary>
    /// Performs additional custom processes before removing a new element into the
    /// <see cref="MarshalByRefCollectionBase"/> instance.
    /// </summary>
    /// <param name="culture">The zero-based <paramref name="culture"/> at which to insert value.</param>
    /// <param name="value">The value of the element to remove from <paramref name="culture"/>.</param>
    protected override void OnRemove(int culture, Object value) 
    {
      Culture t = (Culture)value;
      t.SetDomainFromContainer(null);
      if (defaultCulture==t)
        defaultCulture = null;
    }
    
    /// <summary>
    /// Performs additional custom processes before setting a value in the
    /// <see cref="MarshalByRefCollectionBase"/> instance.
    /// </summary>
    /// <param name="culture">The zero-based <paramref name="culture"/> at which <paramref name="oldValue"/> can be found.</param>
    /// <param name="oldValue">The value to replace with <paramref name="newValue"/>.</param>
    /// <param name="newValue">The new value of the element at <paramref name="culture"/>.</param>
    protected override void OnSet(int culture, Object oldValue, Object newValue)
    {
      Culture t  = (Culture)newValue;
      Culture ot = (Culture)oldValue;
      if (this[t.Name]!=null && ot.Name!=t.Name)
        throw new InvalidOperationException(String.Format("Culture with name \"{0}\" already exists.",t.Name));
      if (t.Default && defaultCulture!=null && ot!=defaultCulture)
        throw new InvalidOperationException("Only one default culture is allowed.");
      ot.SetDomainFromContainer(null);
      t.Domain = null;
      t.SetDomainFromContainer(this.domain);
      if (defaultCulture==ot)
        defaultCulture = null;
      if (t.Default)
        defaultCulture = t;
    }
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="domain">Domain, to which this collection is bound.</param>
    public CultureCollection(Domain domain)
    {
      this.domain = domain;
    }

    /// <summary>
    /// Serializer.
    /// </summary>
    /// <param name="info"><see cref="SerializationInfo"/> object.</param>
    /// <param name="context"><see cref="StreamingContext"/> object.</param>
    public override void GetObjectData(SerializationInfo info, StreamingContext context)
    {
      base.GetObjectData(info,context);
      info.AddValue("Domain",domain);
      info.AddValue("DefaultCulture",defaultCulture);
    }

    /// <summary>
    /// Deserialization constructor.
    /// </summary>
    /// <param name="info"><see cref="SerializationInfo"/> object.</param>
    /// <param name="context"><see cref="StreamingContext"/> object.</param>
    private CultureCollection(SerializationInfo info, StreamingContext context): base(info, context)
    {
      domain = (Domain)info.GetValue("Domain",typeof(Domain));
      defaultCulture = (Culture)info.GetValue("DefaultCulture",typeof(Culture));
    }
  }
}
