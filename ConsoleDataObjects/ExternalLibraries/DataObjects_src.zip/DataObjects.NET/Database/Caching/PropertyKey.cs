// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;

namespace DataObjects.NET.Database
{
  /// <summary>
  /// Instances of this class are used as global cache keys for cached properties.
  /// </summary>
  public sealed class PropertyKey
  {
    private long id;
    private string propertyName;
    
    /// <summary>
    /// Determines whether the specified object is equal to the current object.
    /// </summary>
    /// <param name="obj">The object to compare with the current object.</param>
    /// <returns><see langword="true"/> if the specified object is equal 
    /// to the current object; otherwise, <see langword="false"/>.</returns>
    public override bool Equals(object obj)
    {
      if (obj==null || obj.GetType()!=typeof(PropertyKey))
        return false;
      PropertyKey pk = (PropertyKey)obj;
      return this.id==pk.id && this.propertyName==pk.propertyName;
    }
    
    /// <summary>
    /// Serves as a hash function for a particular type, suitable for use in 
    /// hashing algorithms and data structures like a hash table.
    /// </summary>
    /// <returns>A hash code for the current object.</returns>
    public override int GetHashCode()
    {
      int hash = 0x1020304 ^ id.GetHashCode();
      if (propertyName!=null)
        hash ^= propertyName.GetHashCode();
      return hash;
    }

    
    // Constructors
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="id"><see cref="DataObject.ID"/> property value.</param>
    /// <param name="propertyName"><see cref="DataObject"/>'s property name.</param>
    public PropertyKey(long id, string propertyName)
    {
      this.id = id;
      this.propertyName = propertyName;
    }
  }
}
