// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;

namespace DataObjects.NET.Attributes
{
  /// <summary>
  /// Indicates that related DataObject instance (or instances when property
  /// is collection) is contained, so it should be deleted on parent deletion.
  /// </summary>
  /// <remarks>
  /// <note>This attribute can be applied to persistent properties
  /// of <see cref="DataObject"/> or <see cref="DataObjectCollection"/> type.</note>
  /// This attribite indicates aggregation relationship between refered object
  /// (reference property) and its container. Aggregation implies that any
  /// aggregated object can exist only in some contained object, so its lifetime
  /// is usually shorter then the lifetime of its container (exception is when you
  /// move an aggregated object to another container). Any aggregated object is
  /// removed on removal of its container.
  /// <para>
  /// <example>Example:
  /// <code lang="C#">
  ///  public abstract class Printer: DataObject
  ///  {
  ///    ...
  ///
  ///    [Contained] // !!!
  ///    public abstract PrinterInfo Info {get; set;}
  ///    
  ///    [Contained] // !!!
  ///    [ItemType(typeof(InkLevelInfo))]
  ///    public abstract DataObjectCollection InkLevelInfo {get;}
  ///
  ///    ...
  ///  }
  /// </code>
  /// </example>
  /// </para>
  /// <seealso cref="SelfReferenceAllowedAttribute"/>
  /// <seealso cref="PairToAttribute"/>
  /// <seealso cref="SymmetricAttribute"/>
  /// </remarks>
  [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field, 
    AllowMultiple = false, Inherited = true)]
  [Serializable]
  public class ContainedAttribute: DataObjectAttribute
  {
    private bool contained = true;
    /// <summary>
    /// <see langword="True"/> if related instance(s) is(are) contained.
    /// </summary>
    public  bool Contained {
      get {return contained;}
      set {contained = value;}
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    public ContainedAttribute() 
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="contained"><see langword="True"/> if related instance(s) is(are) contained.</param>
    public ContainedAttribute(bool contained) 
    {
      this.contained = contained;
    }
  }
}
