// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Runtime.Serialization;

namespace DataObjects.NET.Exceptions
{
  /// <summary>
  /// Thrown on different <see cref="SessionOptions">Offline</see> mode exceptions.
  /// </summary>
  [Serializable]
  public class OfflineModeException: DataObjectsDotNetException
  {
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    public OfflineModeException(): base("Operation isn't allowed in the OfflineMode.") {}
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="text">Text of message.</param>
    public OfflineModeException(string text): base(text) {}

    /// <summary>
    /// Deserialization constructor.
    /// </summary>
    /// <param name="info"><see cref="SerializationInfo"/> object.</param>
    /// <param name="context"><see cref="StreamingContext"/> object.</param>
    protected OfflineModeException(SerializationInfo info, StreamingContext context):
      base(info, context)
    {
    }
  }
}
