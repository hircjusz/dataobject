// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Attributes;

namespace DataObjects.NET
{
  /// <summary>
  /// Each naming mode describes rule that will be used to
  /// get the name of the table or view for the type or its property.
  /// <seealso cref="Domain.NamingMode"/>
  /// <seealso cref="Domain.RegisterNamespaceSynonym"/>
  /// <seealso cref="Domain.Build"/>
  /// <seealso cref="Domain"/>
  /// </summary>
  /// <remarks>
  /// <note type="note">
  /// Changing of naming mode will almost definitely lead
  /// to loss of all data stored in the database!
  /// </note>
  /// </remarks>
  [Flags]
  public enum DomainNamingMode
  {
    /// <summary>
    /// Deafult foreign key creation mode.
    /// The same as <see cref="UseNamespaceSynonyms"/>.
    /// Value is <see langword="0x4"/>. 
    /// </summary>
    Default = 0x4,
    /// <summary>
    /// Only name of the type will be used to derive the name of
    /// the table or view.
    /// Value is <see langword="0x1"/>. 
    /// </summary>
    UseOnlyTypeNames = 0x1,
    /// <summary>
    /// Name of the type and namespace name will be used to derive 
    /// the name of the table or view.
    /// Value is <see langword="0x2"/>. 
    /// </summary>
    UseNamespaces = 0x2,
    /// <summary>
    /// Name of the type and namespace synonym will be used to derive 
    /// the name of the table or view.
    /// Value is <see langword="0x4"/>. 
    /// </summary>
    UseNamespaceSynonyms = 0x4,
    /// <summary>
    /// Name of the type and namespace hashes will be used to derive 
    /// the name of the table or view. Driver decides on the type of hashing
    /// algorythm to use.
    /// Value is <see langword="0x8"/>. 
    /// </summary>
    UseNamespaceHashes = 0x8,
    /// <summary>
    /// All names should be in upper case.
    /// Value is <see langword="0x100"/>. 
    /// </summary>
    Uppercase = 0x100,
    /// <summary>
    /// All names should be in lower case.
    /// Value is <see langword="0x200"/>. 
    /// </summary>
    Lowercase = 0x200,
    /// <summary>
    /// All hyphen characters should be replaced to '_'.
    /// Value is <see langword="0x1000"/>. 
    /// </summary>
    NoHyphens = 0x1000,
    /// <summary>
    /// All dots should be replaced to '_'.
    /// Value is <see langword="0x2000"/>. 
    /// </summary>
    NoDots = 0x2000,

  }
}
