// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;

namespace DataObjects.NET.Attributes 
{
  /// <summary>
  /// Attaches <see cref="IPropertyStorageValueModifier"/> object to <see cref="DataObject"/> property.
  /// <seealso cref="CorrectorAttribute"/>
  /// <seealso cref="ValidatorAttribute"/>
  /// <seealso cref="TypeModifierAttribute"/>
  /// </summary>
  /// <remarks>
  /// <note>This attribute can be applied to persistent properties of any type.</note>
  /// <para>
  /// <example>Example:
  /// <code lang="C#">
  ///  using DataObjects.NET;
  ///  using DataObjects.NET.Attributes;
  ///  using DataObjects.NET.Helpers;
  ///
  ///  public abstract class DbImage: DataObject
  ///  {
  ///    ...
  ///    
  ///    [LoadOnDemand]
  ///    [StorageValueModifier(typeof(Compressor), CompressionMethod.Zip, CompressionLevel.Best)]
  ///    public abstract System.Drawing.Image Image {get; set;}
  ///
  ///    [StorageValueModifier(typeof(Compressor))]
  ///    public abstract byte[] AdditionalData {get; set;}
  ///    
  ///    ...
  ///  }
  /// </code>
  /// </example>
  /// </para>
  /// </remarks>
  [AttributeUsage(AttributeTargets.Property, AllowMultiple = false, Inherited = true)]
  [Serializable]
  public class StorageValueModifierAttribute: AssociatedObjectAttribute
  {
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="constructorArguments">An <see cref="Array"/> of arguments 
    /// to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, params object[] constructorArguments): 
      base(type, constructorArguments)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    public StorageValueModifierAttribute(Type type): base(type)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, object arg1) : base(type, arg1)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, byte arg1) : base(type, arg1)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, char arg1) : base(type, arg1)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, short arg1) : base(type, arg1)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, int arg1) : base(type, arg1)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, long arg1) : base(type, arg1)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, float arg1) : base(type, arg1)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, double arg1) : base(type, arg1)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, bool arg1) : base(type, arg1)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, string arg1) : base(type, arg1)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, object arg1, object arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, object arg1, byte arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, object arg1, char arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, object arg1, short arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, object arg1, int arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, object arg1, long arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, object arg1, float arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, object arg1, double arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, object arg1, bool arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, object arg1, string arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, byte arg1, object arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, byte arg1, byte arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, byte arg1, char arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, byte arg1, short arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, byte arg1, int arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, byte arg1, long arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, byte arg1, float arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, byte arg1, double arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, byte arg1, bool arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, byte arg1, string arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, char arg1, object arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, char arg1, byte arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, char arg1, char arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, char arg1, short arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, char arg1, int arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, char arg1, long arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, char arg1, float arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, char arg1, double arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, char arg1, bool arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, char arg1, string arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, short arg1, object arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, short arg1, byte arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, short arg1, char arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, short arg1, short arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, short arg1, int arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, short arg1, long arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, short arg1, float arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, short arg1, double arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, short arg1, bool arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, short arg1, string arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, int arg1, object arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, int arg1, byte arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, int arg1, char arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, int arg1, short arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, int arg1, int arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, int arg1, long arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, int arg1, float arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, int arg1, double arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, int arg1, bool arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, int arg1, string arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, long arg1, object arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, long arg1, byte arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, long arg1, char arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, long arg1, short arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, long arg1, int arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, long arg1, long arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, long arg1, float arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, long arg1, double arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, long arg1, bool arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, long arg1, string arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, float arg1, object arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, float arg1, byte arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, float arg1, char arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, float arg1, short arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, float arg1, int arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, float arg1, long arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, float arg1, float arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, float arg1, double arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, float arg1, bool arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, float arg1, string arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, double arg1, object arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, double arg1, byte arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, double arg1, char arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, double arg1, short arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, double arg1, int arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, double arg1, long arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, double arg1, float arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, double arg1, double arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, double arg1, bool arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, double arg1, string arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, bool arg1, object arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, bool arg1, byte arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, bool arg1, char arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, bool arg1, short arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, bool arg1, int arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, bool arg1, long arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, bool arg1, float arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, bool arg1, double arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, bool arg1, bool arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, bool arg1, string arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, string arg1, object arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, string arg1, byte arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, string arg1, char arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, string arg1, short arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, string arg1, int arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, string arg1, long arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, string arg1, float arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, string arg1, double arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, string arg1, bool arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, string arg1, string arg2) : base(type, arg1, arg2)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg3">Third argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, object arg1, object arg2, object arg3): base(type, arg1, arg2, arg3)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type"><see cref="Type"/> of storage value modifier to attach.</param>
    /// <param name="arg1">First argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg2">Second argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg3">Third argument to pass to the <paramref name="type"/> constructor.</param>
    /// <param name="arg4">4th argument to pass to the <paramref name="type"/> constructor.</param>
    public StorageValueModifierAttribute(Type type, object arg1, object arg2, object arg3, object arg4): base(type, arg1, arg2, arg3, arg4)
    {
    }
  }
}
