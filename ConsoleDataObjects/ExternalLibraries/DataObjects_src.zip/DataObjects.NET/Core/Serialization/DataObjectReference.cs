// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Runtime.Serialization;

namespace DataObjects.NET.Serialization
{
  /// <summary>
  /// <see cref="DataObject"/> reference. Simply holds a referance 
  /// to the single <see cref="DataObject"/> instance.
  /// </summary>
  public sealed class DataObjectReference: 
    IObjectReference
  {
    internal DataObject realObject;
    /// <summary>
    /// Gets the refered <see cref="DataObject"/> instance.
    /// </summary>
    public   DataObject RealObject {
      get {return realObject;}
    }

    /// <summary>
    /// Returns real object (refered <see cref="DataObject"/> instance).
    /// </summary>
    /// <param name="context">Serialization context.</param>
    /// <returns>Real object.</returns>
    public object GetRealObject(StreamingContext context) 
    {
      return realObject;
    }
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="obj">The instance this object should hold a reference to.</param>
    internal DataObjectReference(DataObject obj)
    {
      if (obj==null)
        throw new ArgumentNullException("obj");

      if (obj.State==DataObjectState.New)
        obj.Persist();
      realObject = obj;
    }
  }
}
