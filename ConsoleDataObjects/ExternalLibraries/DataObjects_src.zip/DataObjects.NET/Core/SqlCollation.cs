// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Attributes;

namespace DataObjects.NET
{
  /// <summary>
  /// Enumerates supported SQL collations.
  /// </summary>
  public enum SqlCollation
  {
    /// <summary>
    /// Unknown collation.
    /// </summary>
    Unknown,
    /// <summary>
    /// No collation.
    /// </summary>
    None,
    /// <summary>
    /// Neutral collation.
    /// </summary>
    Neutral,
    /// <summary>
    /// Albanian, binary sort
    /// </summary>
    Albanian_BIN,
    /// <summary>
    /// Albanian, case-insensitive, accent-insensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Albanian_CI_AI,
    /// <summary>
    /// Albanian, case-insensitive, accent-insensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Albanian_CI_AI_KS,
    /// <summary>
    /// Albanian, case-insensitive, accent-insensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Albanian_CI_AI_KS_WS,
    /// <summary>
    /// Albanian, case-insensitive, accent-insensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Albanian_CI_AI_WS,
    /// <summary>
    /// Albanian, case-insensitive, accent-sensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Albanian_CI_AS,
    /// <summary>
    /// Albanian, case-insensitive, accent-sensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Albanian_CI_AS_KS,
    /// <summary>
    /// Albanian, case-insensitive, accent-sensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Albanian_CI_AS_KS_WS,
    /// <summary>
    /// Albanian, case-insensitive, accent-sensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Albanian_CI_AS_WS,
    /// <summary>
    /// Albanian, case-sensitive, accent-insensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Albanian_CS_AI,
    /// <summary>
    /// Albanian, case-sensitive, accent-insensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Albanian_CS_AI_KS,
    /// <summary>
    /// Albanian, case-sensitive, accent-insensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Albanian_CS_AI_KS_WS,
    /// <summary>
    /// Albanian, case-sensitive, accent-insensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Albanian_CS_AI_WS,
    /// <summary>
    /// Albanian, case-sensitive, accent-sensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Albanian_CS_AS,
    /// <summary>
    /// Albanian, case-sensitive, accent-sensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Albanian_CS_AS_KS,
    /// <summary>
    /// Albanian, case-sensitive, accent-sensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Albanian_CS_AS_KS_WS,
    /// <summary>
    /// Albanian, case-sensitive, accent-sensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Albanian_CS_AS_WS,
    /// <summary>
    /// Arabic, binary sort
    /// </summary>
    Arabic_BIN,
    /// <summary>
    /// Arabic, case-insensitive, accent-insensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Arabic_CI_AI,
    /// <summary>
    /// Arabic, case-insensitive, accent-insensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Arabic_CI_AI_KS,
    /// <summary>
    /// Arabic, case-insensitive, accent-insensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Arabic_CI_AI_KS_WS,
    /// <summary>
    /// Arabic, case-insensitive, accent-insensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Arabic_CI_AI_WS,
    /// <summary>
    /// Arabic, case-insensitive, accent-sensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Arabic_CI_AS,
    /// <summary>
    /// Arabic, case-insensitive, accent-sensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Arabic_CI_AS_KS,
    /// <summary>
    /// Arabic, case-insensitive, accent-sensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Arabic_CI_AS_KS_WS,
    /// <summary>
    /// Arabic, case-insensitive, accent-sensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Arabic_CI_AS_WS,
    /// <summary>
    /// Arabic, case-sensitive, accent-insensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Arabic_CS_AI,
    /// <summary>
    /// Arabic, case-sensitive, accent-insensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Arabic_CS_AI_KS,
    /// <summary>
    /// Arabic, case-sensitive, accent-insensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Arabic_CS_AI_KS_WS,
    /// <summary>
    /// Arabic, case-sensitive, accent-insensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Arabic_CS_AI_WS,
    /// <summary>
    /// Arabic, case-sensitive, accent-sensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Arabic_CS_AS,
    /// <summary>
    /// Arabic, case-sensitive, accent-sensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Arabic_CS_AS_KS,
    /// <summary>
    /// Arabic, case-sensitive, accent-sensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Arabic_CS_AS_KS_WS,
    /// <summary>
    /// Arabic, case-sensitive, accent-sensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Arabic_CS_AS_WS,
    /// <summary>
    /// Chinese-PRC, binary sort
    /// </summary>
    Chinese_PRC_BIN,
    /// <summary>
    /// Chinese-PRC, case-insensitive, accent-insensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Chinese_PRC_CI_AI,
    /// <summary>
    /// Chinese-PRC, case-insensitive, accent-insensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Chinese_PRC_CI_AI_KS,
    /// <summary>
    /// Chinese-PRC, case-insensitive, accent-insensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Chinese_PRC_CI_AI_KS_WS,
    /// <summary>
    /// Chinese-PRC, case-insensitive, accent-insensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Chinese_PRC_CI_AI_WS,
    /// <summary>
    /// Chinese-PRC, case-insensitive, accent-sensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Chinese_PRC_CI_AS,
    /// <summary>
    /// Chinese-PRC, case-insensitive, accent-sensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Chinese_PRC_CI_AS_KS,
    /// <summary>
    /// Chinese-PRC, case-insensitive, accent-sensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Chinese_PRC_CI_AS_KS_WS,
    /// <summary>
    /// Chinese-PRC, case-insensitive, accent-sensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Chinese_PRC_CI_AS_WS,
    /// <summary>
    /// Chinese-PRC, case-sensitive, accent-insensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Chinese_PRC_CS_AI,
    /// <summary>
    /// Chinese-PRC, case-sensitive, accent-insensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Chinese_PRC_CS_AI_KS,
    /// <summary>
    /// Chinese-PRC, case-sensitive, accent-insensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Chinese_PRC_CS_AI_KS_WS,
    /// <summary>
    /// Chinese-PRC, case-sensitive, accent-insensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Chinese_PRC_CS_AI_WS,
    /// <summary>
    /// Chinese-PRC, case-sensitive, accent-sensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Chinese_PRC_CS_AS,
    /// <summary>
    /// Chinese-PRC, case-sensitive, accent-sensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Chinese_PRC_CS_AS_KS,
    /// <summary>
    /// Chinese-PRC, case-sensitive, accent-sensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Chinese_PRC_CS_AS_KS_WS,
    /// <summary>
    /// Chinese-PRC, case-sensitive, accent-sensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Chinese_PRC_CS_AS_WS,
    /// <summary>
    /// Chinese-PRC-Stroke, binary sort
    /// </summary>
    Chinese_PRC_Stroke_BIN,
    /// <summary>
    /// Chinese-PRC-Stroke, case-insensitive, accent-insensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Chinese_PRC_Stroke_CI_AI,
    /// <summary>
    /// Chinese-PRC-Stroke, case-insensitive, accent-insensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Chinese_PRC_Stroke_CI_AI_KS,
    /// <summary>
    /// Chinese-PRC-Stroke, case-insensitive, accent-insensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Chinese_PRC_Stroke_CI_AI_KS_WS,
    /// <summary>
    /// Chinese-PRC-Stroke, case-insensitive, accent-insensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Chinese_PRC_Stroke_CI_AI_WS,
    /// <summary>
    /// Chinese-PRC-Stroke, case-insensitive, accent-sensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Chinese_PRC_Stroke_CI_AS,
    /// <summary>
    /// Chinese-PRC-Stroke, case-insensitive, accent-sensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Chinese_PRC_Stroke_CI_AS_KS,
    /// <summary>
    /// Chinese-PRC-Stroke, case-insensitive, accent-sensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Chinese_PRC_Stroke_CI_AS_KS_WS,
    /// <summary>
    /// Chinese-PRC-Stroke, case-insensitive, accent-sensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Chinese_PRC_Stroke_CI_AS_WS,
    /// <summary>
    /// Chinese-PRC-Stroke, case-sensitive, accent-insensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Chinese_PRC_Stroke_CS_AI,
    /// <summary>
    /// Chinese-PRC-Stroke, case-sensitive, accent-insensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Chinese_PRC_Stroke_CS_AI_KS,
    /// <summary>
    /// Chinese-PRC-Stroke, case-sensitive, accent-insensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Chinese_PRC_Stroke_CS_AI_KS_WS,
    /// <summary>
    /// Chinese-PRC-Stroke, case-sensitive, accent-insensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Chinese_PRC_Stroke_CS_AI_WS,
    /// <summary>
    /// Chinese-PRC-Stroke, case-sensitive, accent-sensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Chinese_PRC_Stroke_CS_AS,
    /// <summary>
    /// Chinese-PRC-Stroke, case-sensitive, accent-sensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Chinese_PRC_Stroke_CS_AS_KS,
    /// <summary>
    /// Chinese-PRC-Stroke, case-sensitive, accent-sensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Chinese_PRC_Stroke_CS_AS_KS_WS,
    /// <summary>
    /// Chinese-PRC-Stroke, case-sensitive, accent-sensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Chinese_PRC_Stroke_CS_AS_WS,
    /// <summary>
    /// Chinese-Taiwan-Bopomofo, binary sort
    /// </summary>
    Chinese_Taiwan_Bopomofo_BIN,
    /// <summary>
    /// Chinese-Taiwan-Bopomofo, case-insensitive, accent-insensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Chinese_Taiwan_Bopomofo_CI_AI,
    /// <summary>
    /// Chinese-Taiwan-Bopomofo, case-insensitive, accent-insensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Chinese_Taiwan_Bopomofo_CI_AI_KS,
    /// <summary>
    /// Chinese-Taiwan-Bopomofo, case-insensitive, accent-insensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Chinese_Taiwan_Bopomofo_CI_AI_KS_WS,
    /// <summary>
    /// Chinese-Taiwan-Bopomofo, case-insensitive, accent-insensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Chinese_Taiwan_Bopomofo_CI_AI_WS,
    /// <summary>
    /// Chinese-Taiwan-Bopomofo, case-insensitive, accent-sensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Chinese_Taiwan_Bopomofo_CI_AS,
    /// <summary>
    /// Chinese-Taiwan-Bopomofo, case-insensitive, accent-sensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Chinese_Taiwan_Bopomofo_CI_AS_KS,
    /// <summary>
    /// Chinese-Taiwan-Bopomofo, case-insensitive, accent-sensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Chinese_Taiwan_Bopomofo_CI_AS_KS_WS,
    /// <summary>
    /// Chinese-Taiwan-Bopomofo, case-insensitive, accent-sensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Chinese_Taiwan_Bopomofo_CI_AS_WS,
    /// <summary>
    /// Chinese-Taiwan-Bopomofo, case-sensitive, accent-insensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Chinese_Taiwan_Bopomofo_CS_AI,
    /// <summary>
    /// Chinese-Taiwan-Bopomofo, case-sensitive, accent-insensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Chinese_Taiwan_Bopomofo_CS_AI_KS,
    /// <summary>
    /// Chinese-Taiwan-Bopomofo, case-sensitive, accent-insensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Chinese_Taiwan_Bopomofo_CS_AI_KS_WS,
    /// <summary>
    /// Chinese-Taiwan-Bopomofo, case-sensitive, accent-insensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Chinese_Taiwan_Bopomofo_CS_AI_WS,
    /// <summary>
    /// Chinese-Taiwan-Bopomofo, case-sensitive, accent-sensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Chinese_Taiwan_Bopomofo_CS_AS,
    /// <summary>
    /// Chinese-Taiwan-Bopomofo, case-sensitive, accent-sensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Chinese_Taiwan_Bopomofo_CS_AS_KS,
    /// <summary>
    /// Chinese-Taiwan-Bopomofo, case-sensitive, accent-sensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Chinese_Taiwan_Bopomofo_CS_AS_KS_WS,
    /// <summary>
    /// Chinese-Taiwan-Bopomofo, case-sensitive, accent-sensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Chinese_Taiwan_Bopomofo_CS_AS_WS,
    /// <summary>
    /// Chinese-Taiwan-Stroke, binary sort
    /// </summary>
    Chinese_Taiwan_Stroke_BIN,
    /// <summary>
    /// Chinese-Taiwan-Stroke, case-insensitive, accent-insensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Chinese_Taiwan_Stroke_CI_AI,
    /// <summary>
    /// Chinese-Taiwan-Stroke, case-insensitive, accent-insensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Chinese_Taiwan_Stroke_CI_AI_KS,
    /// <summary>
    /// Chinese-Taiwan-Stroke, case-insensitive, accent-insensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Chinese_Taiwan_Stroke_CI_AI_KS_WS,
    /// <summary>
    /// Chinese-Taiwan-Stroke, case-insensitive, accent-insensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Chinese_Taiwan_Stroke_CI_AI_WS,
    /// <summary>
    /// Chinese-Taiwan-Stroke, case-insensitive, accent-sensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Chinese_Taiwan_Stroke_CI_AS,
    /// <summary>
    /// Chinese-Taiwan-Stroke, case-insensitive, accent-sensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Chinese_Taiwan_Stroke_CI_AS_KS,
    /// <summary>
    /// Chinese-Taiwan-Stroke, case-insensitive, accent-sensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Chinese_Taiwan_Stroke_CI_AS_KS_WS,
    /// <summary>
    /// Chinese-Taiwan-Stroke, case-insensitive, accent-sensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Chinese_Taiwan_Stroke_CI_AS_WS,
    /// <summary>
    /// Chinese-Taiwan-Stroke, case-sensitive, accent-insensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Chinese_Taiwan_Stroke_CS_AI,
    /// <summary>
    /// Chinese-Taiwan-Stroke, case-sensitive, accent-insensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Chinese_Taiwan_Stroke_CS_AI_KS,
    /// <summary>
    /// Chinese-Taiwan-Stroke, case-sensitive, accent-insensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Chinese_Taiwan_Stroke_CS_AI_KS_WS,
    /// <summary>
    /// Chinese-Taiwan-Stroke, case-sensitive, accent-insensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Chinese_Taiwan_Stroke_CS_AI_WS,
    /// <summary>
    /// Chinese-Taiwan-Stroke, case-sensitive, accent-sensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Chinese_Taiwan_Stroke_CS_AS,
    /// <summary>
    /// Chinese-Taiwan-Stroke, case-sensitive, accent-sensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Chinese_Taiwan_Stroke_CS_AS_KS,
    /// <summary>
    /// Chinese-Taiwan-Stroke, case-sensitive, accent-sensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Chinese_Taiwan_Stroke_CS_AS_KS_WS,
    /// <summary>
    /// Chinese-Taiwan-Stroke, case-sensitive, accent-sensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Chinese_Taiwan_Stroke_CS_AS_WS,
    /// <summary>
    /// Croatian, binary sort
    /// </summary>
    Croatian_BIN,
    /// <summary>
    /// Croatian, case-insensitive, accent-insensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Croatian_CI_AI,
    /// <summary>
    /// Croatian, case-insensitive, accent-insensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Croatian_CI_AI_KS,
    /// <summary>
    /// Croatian, case-insensitive, accent-insensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Croatian_CI_AI_KS_WS,
    /// <summary>
    /// Croatian, case-insensitive, accent-insensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Croatian_CI_AI_WS,
    /// <summary>
    /// Croatian, case-insensitive, accent-sensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Croatian_CI_AS,
    /// <summary>
    /// Croatian, case-insensitive, accent-sensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Croatian_CI_AS_KS,
    /// <summary>
    /// Croatian, case-insensitive, accent-sensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Croatian_CI_AS_KS_WS,
    /// <summary>
    /// Croatian, case-insensitive, accent-sensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Croatian_CI_AS_WS,
    /// <summary>
    /// Croatian, case-sensitive, accent-insensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Croatian_CS_AI,
    /// <summary>
    /// Croatian, case-sensitive, accent-insensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Croatian_CS_AI_KS,
    /// <summary>
    /// Croatian, case-sensitive, accent-insensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Croatian_CS_AI_KS_WS,
    /// <summary>
    /// Croatian, case-sensitive, accent-insensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Croatian_CS_AI_WS,
    /// <summary>
    /// Croatian, case-sensitive, accent-sensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Croatian_CS_AS,
    /// <summary>
    /// Croatian, case-sensitive, accent-sensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Croatian_CS_AS_KS,
    /// <summary>
    /// Croatian, case-sensitive, accent-sensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Croatian_CS_AS_KS_WS,
    /// <summary>
    /// Croatian, case-sensitive, accent-sensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Croatian_CS_AS_WS,
    /// <summary>
    /// Cyrillic-General, binary sort
    /// </summary>
    Cyrillic_General_BIN,
    /// <summary>
    /// Cyrillic-General, case-insensitive, accent-insensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Cyrillic_General_CI_AI,
    /// <summary>
    /// Cyrillic-General, case-insensitive, accent-insensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Cyrillic_General_CI_AI_KS,
    /// <summary>
    /// Cyrillic-General, case-insensitive, accent-insensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Cyrillic_General_CI_AI_KS_WS,
    /// <summary>
    /// Cyrillic-General, case-insensitive, accent-insensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Cyrillic_General_CI_AI_WS,
    /// <summary>
    /// Cyrillic-General, case-insensitive, accent-sensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Cyrillic_General_CI_AS,
    /// <summary>
    /// Cyrillic-General, case-insensitive, accent-sensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Cyrillic_General_CI_AS_KS,
    /// <summary>
    /// Cyrillic-General, case-insensitive, accent-sensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Cyrillic_General_CI_AS_KS_WS,
    /// <summary>
    /// Cyrillic-General, case-insensitive, accent-sensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Cyrillic_General_CI_AS_WS,
    /// <summary>
    /// Cyrillic-General, case-sensitive, accent-insensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Cyrillic_General_CS_AI,
    /// <summary>
    /// Cyrillic-General, case-sensitive, accent-insensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Cyrillic_General_CS_AI_KS,
    /// <summary>
    /// Cyrillic-General, case-sensitive, accent-insensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Cyrillic_General_CS_AI_KS_WS,
    /// <summary>
    /// Cyrillic-General, case-sensitive, accent-insensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Cyrillic_General_CS_AI_WS,
    /// <summary>
    /// Cyrillic-General, case-sensitive, accent-sensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Cyrillic_General_CS_AS,
    /// <summary>
    /// Cyrillic-General, case-sensitive, accent-sensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Cyrillic_General_CS_AS_KS,
    /// <summary>
    /// Cyrillic-General, case-sensitive, accent-sensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Cyrillic_General_CS_AS_KS_WS,
    /// <summary>
    /// Cyrillic-General, case-sensitive, accent-sensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Cyrillic_General_CS_AS_WS,
    /// <summary>
    /// Czech, binary sort
    /// </summary>
    Czech_BIN,
    /// <summary>
    /// Czech, case-insensitive, accent-insensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Czech_CI_AI,
    /// <summary>
    /// Czech, case-insensitive, accent-insensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Czech_CI_AI_KS,
    /// <summary>
    /// Czech, case-insensitive, accent-insensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Czech_CI_AI_KS_WS,
    /// <summary>
    /// Czech, case-insensitive, accent-insensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Czech_CI_AI_WS,
    /// <summary>
    /// Czech, case-insensitive, accent-sensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Czech_CI_AS,
    /// <summary>
    /// Czech, case-insensitive, accent-sensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Czech_CI_AS_KS,
    /// <summary>
    /// Czech, case-insensitive, accent-sensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Czech_CI_AS_KS_WS,
    /// <summary>
    /// Czech, case-insensitive, accent-sensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Czech_CI_AS_WS,
    /// <summary>
    /// Czech, case-sensitive, accent-insensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Czech_CS_AI,
    /// <summary>
    /// Czech, case-sensitive, accent-insensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Czech_CS_AI_KS,
    /// <summary>
    /// Czech, case-sensitive, accent-insensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Czech_CS_AI_KS_WS,
    /// <summary>
    /// Czech, case-sensitive, accent-insensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Czech_CS_AI_WS,
    /// <summary>
    /// Czech, case-sensitive, accent-sensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Czech_CS_AS,
    /// <summary>
    /// Czech, case-sensitive, accent-sensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Czech_CS_AS_KS,
    /// <summary>
    /// Czech, case-sensitive, accent-sensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Czech_CS_AS_KS_WS,
    /// <summary>
    /// Czech, case-sensitive, accent-sensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Czech_CS_AS_WS,
    /// <summary>
    /// Danish-Norwegian, binary sort
    /// </summary>
    Danish_Norwegian_BIN,
    /// <summary>
    /// Danish-Norwegian, case-insensitive, accent-insensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Danish_Norwegian_CI_AI,
    /// <summary>
    /// Danish-Norwegian, case-insensitive, accent-insensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Danish_Norwegian_CI_AI_KS,
    /// <summary>
    /// Danish-Norwegian, case-insensitive, accent-insensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Danish_Norwegian_CI_AI_KS_WS,
    /// <summary>
    /// Danish-Norwegian, case-insensitive, accent-insensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Danish_Norwegian_CI_AI_WS,
    /// <summary>
    /// Danish-Norwegian, case-insensitive, accent-sensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Danish_Norwegian_CI_AS,
    /// <summary>
    /// Danish-Norwegian, case-insensitive, accent-sensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Danish_Norwegian_CI_AS_KS,
    /// <summary>
    /// Danish-Norwegian, case-insensitive, accent-sensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Danish_Norwegian_CI_AS_KS_WS,
    /// <summary>
    /// Danish-Norwegian, case-insensitive, accent-sensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Danish_Norwegian_CI_AS_WS,
    /// <summary>
    /// Danish-Norwegian, case-sensitive, accent-insensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Danish_Norwegian_CS_AI,
    /// <summary>
    /// Danish-Norwegian, case-sensitive, accent-insensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Danish_Norwegian_CS_AI_KS,
    /// <summary>
    /// Danish-Norwegian, case-sensitive, accent-insensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Danish_Norwegian_CS_AI_KS_WS,
    /// <summary>
    /// Danish-Norwegian, case-sensitive, accent-insensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Danish_Norwegian_CS_AI_WS,
    /// <summary>
    /// Danish-Norwegian, case-sensitive, accent-sensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Danish_Norwegian_CS_AS,
    /// <summary>
    /// Danish-Norwegian, case-sensitive, accent-sensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Danish_Norwegian_CS_AS_KS,
    /// <summary>
    /// Danish-Norwegian, case-sensitive, accent-sensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Danish_Norwegian_CS_AS_KS_WS,
    /// <summary>
    /// Danish-Norwegian, case-sensitive, accent-sensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Danish_Norwegian_CS_AS_WS,
    /// <summary>
    /// Estonian, binary sort
    /// </summary>
    Estonian_BIN,
    /// <summary>
    /// Estonian, case-insensitive, accent-insensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Estonian_CI_AI,
    /// <summary>
    /// Estonian, case-insensitive, accent-insensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Estonian_CI_AI_KS,
    /// <summary>
    /// Estonian, case-insensitive, accent-insensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Estonian_CI_AI_KS_WS,
    /// <summary>
    /// Estonian, case-insensitive, accent-insensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Estonian_CI_AI_WS,
    /// <summary>
    /// Estonian, case-insensitive, accent-sensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Estonian_CI_AS,
    /// <summary>
    /// Estonian, case-insensitive, accent-sensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Estonian_CI_AS_KS,
    /// <summary>
    /// Estonian, case-insensitive, accent-sensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Estonian_CI_AS_KS_WS,
    /// <summary>
    /// Estonian, case-insensitive, accent-sensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Estonian_CI_AS_WS,
    /// <summary>
    /// Estonian, case-sensitive, accent-insensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Estonian_CS_AI,
    /// <summary>
    /// Estonian, case-sensitive, accent-insensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Estonian_CS_AI_KS,
    /// <summary>
    /// Estonian, case-sensitive, accent-insensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Estonian_CS_AI_KS_WS,
    /// <summary>
    /// Estonian, case-sensitive, accent-insensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Estonian_CS_AI_WS,
    /// <summary>
    /// Estonian, case-sensitive, accent-sensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Estonian_CS_AS,
    /// <summary>
    /// Estonian, case-sensitive, accent-sensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Estonian_CS_AS_KS,
    /// <summary>
    /// Estonian, case-sensitive, accent-sensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Estonian_CS_AS_KS_WS,
    /// <summary>
    /// Estonian, case-sensitive, accent-sensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Estonian_CS_AS_WS,
    /// <summary>
    /// Finnish-Swedish, binary sort
    /// </summary>
    Finnish_Swedish_BIN,
    /// <summary>
    /// Finnish-Swedish, case-insensitive, accent-insensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Finnish_Swedish_CI_AI,
    /// <summary>
    /// Finnish-Swedish, case-insensitive, accent-insensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Finnish_Swedish_CI_AI_KS,
    /// <summary>
    /// Finnish-Swedish, case-insensitive, accent-insensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Finnish_Swedish_CI_AI_KS_WS,
    /// <summary>
    /// Finnish-Swedish, case-insensitive, accent-insensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Finnish_Swedish_CI_AI_WS,
    /// <summary>
    /// Finnish-Swedish, case-insensitive, accent-sensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Finnish_Swedish_CI_AS,
    /// <summary>
    /// Finnish-Swedish, case-insensitive, accent-sensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Finnish_Swedish_CI_AS_KS,
    /// <summary>
    /// Finnish-Swedish, case-insensitive, accent-sensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Finnish_Swedish_CI_AS_KS_WS,
    /// <summary>
    /// Finnish-Swedish, case-insensitive, accent-sensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Finnish_Swedish_CI_AS_WS,
    /// <summary>
    /// Finnish-Swedish, case-sensitive, accent-insensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Finnish_Swedish_CS_AI,
    /// <summary>
    /// Finnish-Swedish, case-sensitive, accent-insensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Finnish_Swedish_CS_AI_KS,
    /// <summary>
    /// Finnish-Swedish, case-sensitive, accent-insensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Finnish_Swedish_CS_AI_KS_WS,
    /// <summary>
    /// Finnish-Swedish, case-sensitive, accent-insensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Finnish_Swedish_CS_AI_WS,
    /// <summary>
    /// Finnish-Swedish, case-sensitive, accent-sensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Finnish_Swedish_CS_AS,
    /// <summary>
    /// Finnish-Swedish, case-sensitive, accent-sensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Finnish_Swedish_CS_AS_KS,
    /// <summary>
    /// Finnish-Swedish, case-sensitive, accent-sensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Finnish_Swedish_CS_AS_KS_WS,
    /// <summary>
    /// Finnish-Swedish, case-sensitive, accent-sensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Finnish_Swedish_CS_AS_WS,
    /// <summary>
    /// French, binary sort
    /// </summary>
    French_BIN,
    /// <summary>
    /// French, case-insensitive, accent-insensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    French_CI_AI,
    /// <summary>
    /// French, case-insensitive, accent-insensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    French_CI_AI_KS,
    /// <summary>
    /// French, case-insensitive, accent-insensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    French_CI_AI_KS_WS,
    /// <summary>
    /// French, case-insensitive, accent-insensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    French_CI_AI_WS,
    /// <summary>
    /// French, case-insensitive, accent-sensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    French_CI_AS,
    /// <summary>
    /// French, case-insensitive, accent-sensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    French_CI_AS_KS,
    /// <summary>
    /// French, case-insensitive, accent-sensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    French_CI_AS_KS_WS,
    /// <summary>
    /// French, case-insensitive, accent-sensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    French_CI_AS_WS,
    /// <summary>
    /// French, case-sensitive, accent-insensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    French_CS_AI,
    /// <summary>
    /// French, case-sensitive, accent-insensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    French_CS_AI_KS,
    /// <summary>
    /// French, case-sensitive, accent-insensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    French_CS_AI_KS_WS,
    /// <summary>
    /// French, case-sensitive, accent-insensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    French_CS_AI_WS,
    /// <summary>
    /// French, case-sensitive, accent-sensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    French_CS_AS,
    /// <summary>
    /// French, case-sensitive, accent-sensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    French_CS_AS_KS,
    /// <summary>
    /// French, case-sensitive, accent-sensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    French_CS_AS_KS_WS,
    /// <summary>
    /// French, case-sensitive, accent-sensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    French_CS_AS_WS,
    /// <summary>
    /// Georgian-Modern-sort, binary sort
    /// </summary>
    Georgian_Modern_sort_BIN,
    /// <summary>
    /// Georgian-Modern-sort, case-insensitive, accent-insensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Georgian_Modern_sort_CI_AI,
    /// <summary>
    /// Georgian-Modern-sort, case-insensitive, accent-insensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Georgian_Modern_sort_CI_AI_KS,
    /// <summary>
    /// Georgian-Modern-sort, case-insensitive, accent-insensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Georgian_Modern_sort_CI_AI_KS_WS,
    /// <summary>
    /// Georgian-Modern-sort, case-insensitive, accent-insensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Georgian_Modern_sort_CI_AI_WS,
    /// <summary>
    /// Georgian-Modern-sort, case-insensitive, accent-sensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Georgian_Modern_sort_CI_AS,
    /// <summary>
    /// Georgian-Modern-sort, case-insensitive, accent-sensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Georgian_Modern_sort_CI_AS_KS,
    /// <summary>
    /// Georgian-Modern-sort, case-insensitive, accent-sensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Georgian_Modern_sort_CI_AS_KS_WS,
    /// <summary>
    /// Georgian-Modern-sort, case-insensitive, accent-sensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Georgian_Modern_sort_CI_AS_WS,
    /// <summary>
    /// Georgian-Modern-sort, case-sensitive, accent-insensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Georgian_Modern_sort_CS_AI,
    /// <summary>
    /// Georgian-Modern-sort, case-sensitive, accent-insensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Georgian_Modern_sort_CS_AI_KS,
    /// <summary>
    /// Georgian-Modern-sort, case-sensitive, accent-insensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Georgian_Modern_sort_CS_AI_KS_WS,
    /// <summary>
    /// Georgian-Modern-sort, case-sensitive, accent-insensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Georgian_Modern_sort_CS_AI_WS,
    /// <summary>
    /// Georgian-Modern-sort, case-sensitive, accent-sensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Georgian_Modern_sort_CS_AS,
    /// <summary>
    /// Georgian-Modern-sort, case-sensitive, accent-sensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Georgian_Modern_sort_CS_AS_KS,
    /// <summary>
    /// Georgian-Modern-sort, case-sensitive, accent-sensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Georgian_Modern_sort_CS_AS_KS_WS,
    /// <summary>
    /// Georgian-Modern-sort, case-sensitive, accent-sensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Georgian_Modern_sort_CS_AS_WS,
    /// <summary>
    /// German-PhoneBook, binary sort
    /// </summary>
    German_PhoneBook_BIN,
    /// <summary>
    /// German-PhoneBook, case-insensitive, accent-insensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    German_PhoneBook_CI_AI,
    /// <summary>
    /// German-PhoneBook, case-insensitive, accent-insensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    German_PhoneBook_CI_AI_KS,
    /// <summary>
    /// German-PhoneBook, case-insensitive, accent-insensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    German_PhoneBook_CI_AI_KS_WS,
    /// <summary>
    /// German-PhoneBook, case-insensitive, accent-insensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    German_PhoneBook_CI_AI_WS,
    /// <summary>
    /// German-PhoneBook, case-insensitive, accent-sensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    German_PhoneBook_CI_AS,
    /// <summary>
    /// German-PhoneBook, case-insensitive, accent-sensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    German_PhoneBook_CI_AS_KS,
    /// <summary>
    /// German-PhoneBook, case-insensitive, accent-sensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    German_PhoneBook_CI_AS_KS_WS,
    /// <summary>
    /// German-PhoneBook, case-insensitive, accent-sensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    German_PhoneBook_CI_AS_WS,
    /// <summary>
    /// German-PhoneBook, case-sensitive, accent-insensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    German_PhoneBook_CS_AI,
    /// <summary>
    /// German-PhoneBook, case-sensitive, accent-insensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    German_PhoneBook_CS_AI_KS,
    /// <summary>
    /// German-PhoneBook, case-sensitive, accent-insensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    German_PhoneBook_CS_AI_KS_WS,
    /// <summary>
    /// German-PhoneBook, case-sensitive, accent-insensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    German_PhoneBook_CS_AI_WS,
    /// <summary>
    /// German-PhoneBook, case-sensitive, accent-sensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    German_PhoneBook_CS_AS,
    /// <summary>
    /// German-PhoneBook, case-sensitive, accent-sensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    German_PhoneBook_CS_AS_KS,
    /// <summary>
    /// German-PhoneBook, case-sensitive, accent-sensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    German_PhoneBook_CS_AS_KS_WS,
    /// <summary>
    /// German-PhoneBook, case-sensitive, accent-sensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    German_PhoneBook_CS_AS_WS,
    /// <summary>
    /// Greek, binary sort
    /// </summary>
    Greek_BIN,
    /// <summary>
    /// Greek, case-insensitive, accent-insensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Greek_CI_AI,
    /// <summary>
    /// Greek, case-insensitive, accent-insensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Greek_CI_AI_KS,
    /// <summary>
    /// Greek, case-insensitive, accent-insensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Greek_CI_AI_KS_WS,
    /// <summary>
    /// Greek, case-insensitive, accent-insensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Greek_CI_AI_WS,
    /// <summary>
    /// Greek, case-insensitive, accent-sensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Greek_CI_AS,
    /// <summary>
    /// Greek, case-insensitive, accent-sensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Greek_CI_AS_KS,
    /// <summary>
    /// Greek, case-insensitive, accent-sensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Greek_CI_AS_KS_WS,
    /// <summary>
    /// Greek, case-insensitive, accent-sensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Greek_CI_AS_WS,
    /// <summary>
    /// Greek, case-sensitive, accent-insensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Greek_CS_AI,
    /// <summary>
    /// Greek, case-sensitive, accent-insensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Greek_CS_AI_KS,
    /// <summary>
    /// Greek, case-sensitive, accent-insensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Greek_CS_AI_KS_WS,
    /// <summary>
    /// Greek, case-sensitive, accent-insensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Greek_CS_AI_WS,
    /// <summary>
    /// Greek, case-sensitive, accent-sensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Greek_CS_AS,
    /// <summary>
    /// Greek, case-sensitive, accent-sensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Greek_CS_AS_KS,
    /// <summary>
    /// Greek, case-sensitive, accent-sensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Greek_CS_AS_KS_WS,
    /// <summary>
    /// Greek, case-sensitive, accent-sensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Greek_CS_AS_WS,
    /// <summary>
    /// Hebrew, binary sort
    /// </summary>
    Hebrew_BIN,
    /// <summary>
    /// Hebrew, case-insensitive, accent-insensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Hebrew_CI_AI,
    /// <summary>
    /// Hebrew, case-insensitive, accent-insensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Hebrew_CI_AI_KS,
    /// <summary>
    /// Hebrew, case-insensitive, accent-insensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Hebrew_CI_AI_KS_WS,
    /// <summary>
    /// Hebrew, case-insensitive, accent-insensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Hebrew_CI_AI_WS,
    /// <summary>
    /// Hebrew, case-insensitive, accent-sensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Hebrew_CI_AS,
    /// <summary>
    /// Hebrew, case-insensitive, accent-sensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Hebrew_CI_AS_KS,
    /// <summary>
    /// Hebrew, case-insensitive, accent-sensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Hebrew_CI_AS_KS_WS,
    /// <summary>
    /// Hebrew, case-insensitive, accent-sensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Hebrew_CI_AS_WS,
    /// <summary>
    /// Hebrew, case-sensitive, accent-insensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Hebrew_CS_AI,
    /// <summary>
    /// Hebrew, case-sensitive, accent-insensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Hebrew_CS_AI_KS,
    /// <summary>
    /// Hebrew, case-sensitive, accent-insensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Hebrew_CS_AI_KS_WS,
    /// <summary>
    /// Hebrew, case-sensitive, accent-insensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Hebrew_CS_AI_WS,
    /// <summary>
    /// Hebrew, case-sensitive, accent-sensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Hebrew_CS_AS,
    /// <summary>
    /// Hebrew, case-sensitive, accent-sensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Hebrew_CS_AS_KS,
    /// <summary>
    /// Hebrew, case-sensitive, accent-sensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Hebrew_CS_AS_KS_WS,
    /// <summary>
    /// Hebrew, case-sensitive, accent-sensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Hebrew_CS_AS_WS,
    /// <summary>
    /// Hindi, binary sort
    /// </summary>
    Hindi_BIN,
    /// <summary>
    /// Hindi, case-insensitive, accent-insensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Hindi_CI_AI,
    /// <summary>
    /// Hindi, case-insensitive, accent-insensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Hindi_CI_AI_KS,
    /// <summary>
    /// Hindi, case-insensitive, accent-insensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Hindi_CI_AI_KS_WS,
    /// <summary>
    /// Hindi, case-insensitive, accent-insensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Hindi_CI_AI_WS,
    /// <summary>
    /// Hindi, case-insensitive, accent-sensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Hindi_CI_AS,
    /// <summary>
    /// Hindi, case-insensitive, accent-sensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Hindi_CI_AS_KS,
    /// <summary>
    /// Hindi, case-insensitive, accent-sensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Hindi_CI_AS_KS_WS,
    /// <summary>
    /// Hindi, case-insensitive, accent-sensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Hindi_CI_AS_WS,
    /// <summary>
    /// Hindi, case-sensitive, accent-insensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Hindi_CS_AI,
    /// <summary>
    /// Hindi, case-sensitive, accent-insensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Hindi_CS_AI_KS,
    /// <summary>
    /// Hindi, case-sensitive, accent-insensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Hindi_CS_AI_KS_WS,
    /// <summary>
    /// Hindi, case-sensitive, accent-insensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Hindi_CS_AI_WS,
    /// <summary>
    /// Hindi, case-sensitive, accent-sensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Hindi_CS_AS,
    /// <summary>
    /// Hindi, case-sensitive, accent-sensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Hindi_CS_AS_KS,
    /// <summary>
    /// Hindi, case-sensitive, accent-sensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Hindi_CS_AS_KS_WS,
    /// <summary>
    /// Hindi, case-sensitive, accent-sensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Hindi_CS_AS_WS,
    /// <summary>
    /// Hungarian, binary sort
    /// </summary>
    Hungarian_BIN,
    /// <summary>
    /// Hungarian, case-insensitive, accent-insensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Hungarian_CI_AI,
    /// <summary>
    /// Hungarian, case-insensitive, accent-insensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Hungarian_CI_AI_KS,
    /// <summary>
    /// Hungarian, case-insensitive, accent-insensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Hungarian_CI_AI_KS_WS,
    /// <summary>
    /// Hungarian, case-insensitive, accent-insensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Hungarian_CI_AI_WS,
    /// <summary>
    /// Hungarian, case-insensitive, accent-sensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Hungarian_CI_AS,
    /// <summary>
    /// Hungarian, case-insensitive, accent-sensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Hungarian_CI_AS_KS,
    /// <summary>
    /// Hungarian, case-insensitive, accent-sensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Hungarian_CI_AS_KS_WS,
    /// <summary>
    /// Hungarian, case-insensitive, accent-sensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Hungarian_CI_AS_WS,
    /// <summary>
    /// Hungarian, case-sensitive, accent-insensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Hungarian_CS_AI,
    /// <summary>
    /// Hungarian, case-sensitive, accent-insensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Hungarian_CS_AI_KS,
    /// <summary>
    /// Hungarian, case-sensitive, accent-insensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Hungarian_CS_AI_KS_WS,
    /// <summary>
    /// Hungarian, case-sensitive, accent-insensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Hungarian_CS_AI_WS,
    /// <summary>
    /// Hungarian, case-sensitive, accent-sensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Hungarian_CS_AS,
    /// <summary>
    /// Hungarian, case-sensitive, accent-sensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Hungarian_CS_AS_KS,
    /// <summary>
    /// Hungarian, case-sensitive, accent-sensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Hungarian_CS_AS_KS_WS,
    /// <summary>
    /// Hungarian, case-sensitive, accent-sensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Hungarian_CS_AS_WS,
    /// <summary>
    /// Hungarian-Technical, binary sort
    /// </summary>
    Hungarian_Technical_BIN,
    /// <summary>
    /// Hungarian-Technical, case-insensitive, accent-insensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Hungarian_Technical_CI_AI,
    /// <summary>
    /// Hungarian-Technical, case-insensitive, accent-insensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Hungarian_Technical_CI_AI_KS,
    /// <summary>
    /// Hungarian-Technical, case-insensitive, accent-insensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Hungarian_Technical_CI_AI_KS_WS,
    /// <summary>
    /// Hungarian-Technical, case-insensitive, accent-insensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Hungarian_Technical_CI_AI_WS,
    /// <summary>
    /// Hungarian-Technical, case-insensitive, accent-sensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Hungarian_Technical_CI_AS,
    /// <summary>
    /// Hungarian-Technical, case-insensitive, accent-sensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Hungarian_Technical_CI_AS_KS,
    /// <summary>
    /// Hungarian-Technical, case-insensitive, accent-sensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Hungarian_Technical_CI_AS_KS_WS,
    /// <summary>
    /// Hungarian-Technical, case-insensitive, accent-sensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Hungarian_Technical_CI_AS_WS,
    /// <summary>
    /// Hungarian-Technical, case-sensitive, accent-insensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Hungarian_Technical_CS_AI,
    /// <summary>
    /// Hungarian-Technical, case-sensitive, accent-insensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Hungarian_Technical_CS_AI_KS,
    /// <summary>
    /// Hungarian-Technical, case-sensitive, accent-insensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Hungarian_Technical_CS_AI_KS_WS,
    /// <summary>
    /// Hungarian-Technical, case-sensitive, accent-insensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Hungarian_Technical_CS_AI_WS,
    /// <summary>
    /// Hungarian-Technical, case-sensitive, accent-sensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Hungarian_Technical_CS_AS,
    /// <summary>
    /// Hungarian-Technical, case-sensitive, accent-sensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Hungarian_Technical_CS_AS_KS,
    /// <summary>
    /// Hungarian-Technical, case-sensitive, accent-sensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Hungarian_Technical_CS_AS_KS_WS,
    /// <summary>
    /// Hungarian-Technical, case-sensitive, accent-sensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Hungarian_Technical_CS_AS_WS,
    /// <summary>
    /// Icelandic, binary sort
    /// </summary>
    Icelandic_BIN,
    /// <summary>
    /// Icelandic, case-insensitive, accent-insensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Icelandic_CI_AI,
    /// <summary>
    /// Icelandic, case-insensitive, accent-insensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Icelandic_CI_AI_KS,
    /// <summary>
    /// Icelandic, case-insensitive, accent-insensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Icelandic_CI_AI_KS_WS,
    /// <summary>
    /// Icelandic, case-insensitive, accent-insensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Icelandic_CI_AI_WS,
    /// <summary>
    /// Icelandic, case-insensitive, accent-sensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Icelandic_CI_AS,
    /// <summary>
    /// Icelandic, case-insensitive, accent-sensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Icelandic_CI_AS_KS,
    /// <summary>
    /// Icelandic, case-insensitive, accent-sensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Icelandic_CI_AS_KS_WS,
    /// <summary>
    /// Icelandic, case-insensitive, accent-sensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Icelandic_CI_AS_WS,
    /// <summary>
    /// Icelandic, case-sensitive, accent-insensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Icelandic_CS_AI,
    /// <summary>
    /// Icelandic, case-sensitive, accent-insensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Icelandic_CS_AI_KS,
    /// <summary>
    /// Icelandic, case-sensitive, accent-insensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Icelandic_CS_AI_KS_WS,
    /// <summary>
    /// Icelandic, case-sensitive, accent-insensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Icelandic_CS_AI_WS,
    /// <summary>
    /// Icelandic, case-sensitive, accent-sensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Icelandic_CS_AS,
    /// <summary>
    /// Icelandic, case-sensitive, accent-sensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Icelandic_CS_AS_KS,
    /// <summary>
    /// Icelandic, case-sensitive, accent-sensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Icelandic_CS_AS_KS_WS,
    /// <summary>
    /// Icelandic, case-sensitive, accent-sensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Icelandic_CS_AS_WS,
    /// <summary>
    /// Japanese, binary sort
    /// </summary>
    Japanese_BIN,
    /// <summary>
    /// Japanese, case-insensitive, accent-insensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Japanese_CI_AI,
    /// <summary>
    /// Japanese, case-insensitive, accent-insensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Japanese_CI_AI_KS,
    /// <summary>
    /// Japanese, case-insensitive, accent-insensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Japanese_CI_AI_KS_WS,
    /// <summary>
    /// Japanese, case-insensitive, accent-insensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Japanese_CI_AI_WS,
    /// <summary>
    /// Japanese, case-insensitive, accent-sensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Japanese_CI_AS,
    /// <summary>
    /// Japanese, case-insensitive, accent-sensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Japanese_CI_AS_KS,
    /// <summary>
    /// Japanese, case-insensitive, accent-sensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Japanese_CI_AS_KS_WS,
    /// <summary>
    /// Japanese, case-insensitive, accent-sensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Japanese_CI_AS_WS,
    /// <summary>
    /// Japanese, case-sensitive, accent-insensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Japanese_CS_AI,
    /// <summary>
    /// Japanese, case-sensitive, accent-insensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Japanese_CS_AI_KS,
    /// <summary>
    /// Japanese, case-sensitive, accent-insensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Japanese_CS_AI_KS_WS,
    /// <summary>
    /// Japanese, case-sensitive, accent-insensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Japanese_CS_AI_WS,
    /// <summary>
    /// Japanese, case-sensitive, accent-sensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Japanese_CS_AS,
    /// <summary>
    /// Japanese, case-sensitive, accent-sensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Japanese_CS_AS_KS,
    /// <summary>
    /// Japanese, case-sensitive, accent-sensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Japanese_CS_AS_KS_WS,
    /// <summary>
    /// Japanese, case-sensitive, accent-sensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Japanese_CS_AS_WS,
    /// <summary>
    /// Japanese-Unicode, binary sort
    /// </summary>
    Japanese_Unicode_BIN,
    /// <summary>
    /// Japanese-Unicode, case-insensitive, accent-insensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Japanese_Unicode_CI_AI,
    /// <summary>
    /// Japanese-Unicode, case-insensitive, accent-insensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Japanese_Unicode_CI_AI_KS,
    /// <summary>
    /// Japanese-Unicode, case-insensitive, accent-insensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Japanese_Unicode_CI_AI_KS_WS,
    /// <summary>
    /// Japanese-Unicode, case-insensitive, accent-insensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Japanese_Unicode_CI_AI_WS,
    /// <summary>
    /// Japanese-Unicode, case-insensitive, accent-sensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Japanese_Unicode_CI_AS,
    /// <summary>
    /// Japanese-Unicode, case-insensitive, accent-sensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Japanese_Unicode_CI_AS_KS,
    /// <summary>
    /// Japanese-Unicode, case-insensitive, accent-sensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Japanese_Unicode_CI_AS_KS_WS,
    /// <summary>
    /// Japanese-Unicode, case-insensitive, accent-sensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Japanese_Unicode_CI_AS_WS,
    /// <summary>
    /// Japanese-Unicode, case-sensitive, accent-insensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Japanese_Unicode_CS_AI,
    /// <summary>
    /// Japanese-Unicode, case-sensitive, accent-insensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Japanese_Unicode_CS_AI_KS,
    /// <summary>
    /// Japanese-Unicode, case-sensitive, accent-insensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Japanese_Unicode_CS_AI_KS_WS,
    /// <summary>
    /// Japanese-Unicode, case-sensitive, accent-insensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Japanese_Unicode_CS_AI_WS,
    /// <summary>
    /// Japanese-Unicode, case-sensitive, accent-sensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Japanese_Unicode_CS_AS,
    /// <summary>
    /// Japanese-Unicode, case-sensitive, accent-sensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Japanese_Unicode_CS_AS_KS,
    /// <summary>
    /// Japanese-Unicode, case-sensitive, accent-sensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Japanese_Unicode_CS_AS_KS_WS,
    /// <summary>
    /// Japanese-Unicode, case-sensitive, accent-sensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Japanese_Unicode_CS_AS_WS,
    /// <summary>
    /// Korean-Wansung, binary sort
    /// </summary>
    Korean_Wansung_BIN,
    /// <summary>
    /// Korean-Wansung, case-insensitive, accent-insensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Korean_Wansung_CI_AI,
    /// <summary>
    /// Korean-Wansung, case-insensitive, accent-insensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Korean_Wansung_CI_AI_KS,
    /// <summary>
    /// Korean-Wansung, case-insensitive, accent-insensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Korean_Wansung_CI_AI_KS_WS,
    /// <summary>
    /// Korean-Wansung, case-insensitive, accent-insensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Korean_Wansung_CI_AI_WS,
    /// <summary>
    /// Korean-Wansung, case-insensitive, accent-sensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Korean_Wansung_CI_AS,
    /// <summary>
    /// Korean-Wansung, case-insensitive, accent-sensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Korean_Wansung_CI_AS_KS,
    /// <summary>
    /// Korean-Wansung, case-insensitive, accent-sensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Korean_Wansung_CI_AS_KS_WS,
    /// <summary>
    /// Korean-Wansung, case-insensitive, accent-sensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Korean_Wansung_CI_AS_WS,
    /// <summary>
    /// Korean-Wansung, case-sensitive, accent-insensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Korean_Wansung_CS_AI,
    /// <summary>
    /// Korean-Wansung, case-sensitive, accent-insensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Korean_Wansung_CS_AI_KS,
    /// <summary>
    /// Korean-Wansung, case-sensitive, accent-insensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Korean_Wansung_CS_AI_KS_WS,
    /// <summary>
    /// Korean-Wansung, case-sensitive, accent-insensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Korean_Wansung_CS_AI_WS,
    /// <summary>
    /// Korean-Wansung, case-sensitive, accent-sensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Korean_Wansung_CS_AS,
    /// <summary>
    /// Korean-Wansung, case-sensitive, accent-sensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Korean_Wansung_CS_AS_KS,
    /// <summary>
    /// Korean-Wansung, case-sensitive, accent-sensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Korean_Wansung_CS_AS_KS_WS,
    /// <summary>
    /// Korean-Wansung, case-sensitive, accent-sensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Korean_Wansung_CS_AS_WS,
    /// <summary>
    /// Korean-Wansung-Unicode, binary sort
    /// </summary>
    Korean_Wansung_Unicode_BIN,
    /// <summary>
    /// Korean-Wansung-Unicode, case-insensitive, accent-insensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Korean_Wansung_Unicode_CI_AI,
    /// <summary>
    /// Korean-Wansung-Unicode, case-insensitive, accent-insensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Korean_Wansung_Unicode_CI_AI_KS,
    /// <summary>
    /// Korean-Wansung-Unicode, case-insensitive, accent-insensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Korean_Wansung_Unicode_CI_AI_KS_WS,
    /// <summary>
    /// Korean-Wansung-Unicode, case-insensitive, accent-insensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Korean_Wansung_Unicode_CI_AI_WS,
    /// <summary>
    /// Korean-Wansung-Unicode, case-insensitive, accent-sensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Korean_Wansung_Unicode_CI_AS,
    /// <summary>
    /// Korean-Wansung-Unicode, case-insensitive, accent-sensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Korean_Wansung_Unicode_CI_AS_KS,
    /// <summary>
    /// Korean-Wansung-Unicode, case-insensitive, accent-sensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Korean_Wansung_Unicode_CI_AS_KS_WS,
    /// <summary>
    /// Korean-Wansung-Unicode, case-insensitive, accent-sensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Korean_Wansung_Unicode_CI_AS_WS,
    /// <summary>
    /// Korean-Wansung-Unicode, case-sensitive, accent-insensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Korean_Wansung_Unicode_CS_AI,
    /// <summary>
    /// Korean-Wansung-Unicode, case-sensitive, accent-insensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Korean_Wansung_Unicode_CS_AI_KS,
    /// <summary>
    /// Korean-Wansung-Unicode, case-sensitive, accent-insensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Korean_Wansung_Unicode_CS_AI_KS_WS,
    /// <summary>
    /// Korean-Wansung-Unicode, case-sensitive, accent-insensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Korean_Wansung_Unicode_CS_AI_WS,
    /// <summary>
    /// Korean-Wansung-Unicode, case-sensitive, accent-sensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Korean_Wansung_Unicode_CS_AS,
    /// <summary>
    /// Korean-Wansung-Unicode, case-sensitive, accent-sensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Korean_Wansung_Unicode_CS_AS_KS,
    /// <summary>
    /// Korean-Wansung-Unicode, case-sensitive, accent-sensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Korean_Wansung_Unicode_CS_AS_KS_WS,
    /// <summary>
    /// Korean-Wansung-Unicode, case-sensitive, accent-sensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Korean_Wansung_Unicode_CS_AS_WS,
    /// <summary>
    /// Latin1-General, binary sort
    /// </summary>
    Latin1_General_BIN,
    /// <summary>
    /// Latin1-General, case-insensitive, accent-insensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Latin1_General_CI_AI,
    /// <summary>
    /// Latin1-General, case-insensitive, accent-insensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Latin1_General_CI_AI_KS,
    /// <summary>
    /// Latin1-General, case-insensitive, accent-insensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Latin1_General_CI_AI_KS_WS,
    /// <summary>
    /// Latin1-General, case-insensitive, accent-insensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Latin1_General_CI_AI_WS,
    /// <summary>
    /// Latin1-General, case-insensitive, accent-sensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Latin1_General_CI_AS,
    /// <summary>
    /// Latin1-General, case-insensitive, accent-sensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Latin1_General_CI_AS_KS,
    /// <summary>
    /// Latin1-General, case-insensitive, accent-sensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Latin1_General_CI_AS_KS_WS,
    /// <summary>
    /// Latin1-General, case-insensitive, accent-sensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Latin1_General_CI_AS_WS,
    /// <summary>
    /// Latin1-General, case-sensitive, accent-insensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Latin1_General_CS_AI,
    /// <summary>
    /// Latin1-General, case-sensitive, accent-insensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Latin1_General_CS_AI_KS,
    /// <summary>
    /// Latin1-General, case-sensitive, accent-insensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Latin1_General_CS_AI_KS_WS,
    /// <summary>
    /// Latin1-General, case-sensitive, accent-insensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Latin1_General_CS_AI_WS,
    /// <summary>
    /// Latin1-General, case-sensitive, accent-sensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Latin1_General_CS_AS,
    /// <summary>
    /// Latin1-General, case-sensitive, accent-sensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Latin1_General_CS_AS_KS,
    /// <summary>
    /// Latin1-General, case-sensitive, accent-sensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Latin1_General_CS_AS_KS_WS,
    /// <summary>
    /// Latin1-General, case-sensitive, accent-sensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Latin1_General_CS_AS_WS,
    /// <summary>
    /// Latvian, binary sort
    /// </summary>
    Latvian_BIN,
    /// <summary>
    /// Latvian, case-insensitive, accent-insensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Latvian_CI_AI,
    /// <summary>
    /// Latvian, case-insensitive, accent-insensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Latvian_CI_AI_KS,
    /// <summary>
    /// Latvian, case-insensitive, accent-insensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Latvian_CI_AI_KS_WS,
    /// <summary>
    /// Latvian, case-insensitive, accent-insensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Latvian_CI_AI_WS,
    /// <summary>
    /// Latvian, case-insensitive, accent-sensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Latvian_CI_AS,
    /// <summary>
    /// Latvian, case-insensitive, accent-sensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Latvian_CI_AS_KS,
    /// <summary>
    /// Latvian, case-insensitive, accent-sensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Latvian_CI_AS_KS_WS,
    /// <summary>
    /// Latvian, case-insensitive, accent-sensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Latvian_CI_AS_WS,
    /// <summary>
    /// Latvian, case-sensitive, accent-insensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Latvian_CS_AI,
    /// <summary>
    /// Latvian, case-sensitive, accent-insensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Latvian_CS_AI_KS,
    /// <summary>
    /// Latvian, case-sensitive, accent-insensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Latvian_CS_AI_KS_WS,
    /// <summary>
    /// Latvian, case-sensitive, accent-insensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Latvian_CS_AI_WS,
    /// <summary>
    /// Latvian, case-sensitive, accent-sensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Latvian_CS_AS,
    /// <summary>
    /// Latvian, case-sensitive, accent-sensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Latvian_CS_AS_KS,
    /// <summary>
    /// Latvian, case-sensitive, accent-sensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Latvian_CS_AS_KS_WS,
    /// <summary>
    /// Latvian, case-sensitive, accent-sensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Latvian_CS_AS_WS,
    /// <summary>
    /// Lithuanian, binary sort
    /// </summary>
    Lithuanian_BIN,
    /// <summary>
    /// Lithuanian, case-insensitive, accent-insensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Lithuanian_CI_AI,
    /// <summary>
    /// Lithuanian, case-insensitive, accent-insensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Lithuanian_CI_AI_KS,
    /// <summary>
    /// Lithuanian, case-insensitive, accent-insensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Lithuanian_CI_AI_KS_WS,
    /// <summary>
    /// Lithuanian, case-insensitive, accent-insensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Lithuanian_CI_AI_WS,
    /// <summary>
    /// Lithuanian, case-insensitive, accent-sensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Lithuanian_CI_AS,
    /// <summary>
    /// Lithuanian, case-insensitive, accent-sensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Lithuanian_CI_AS_KS,
    /// <summary>
    /// Lithuanian, case-insensitive, accent-sensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Lithuanian_CI_AS_KS_WS,
    /// <summary>
    /// Lithuanian, case-insensitive, accent-sensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Lithuanian_CI_AS_WS,
    /// <summary>
    /// Lithuanian-Classic, binary sort
    /// </summary>
    Lithuanian_Classic_BIN,
    /// <summary>
    /// Lithuanian-Classic, case-insensitive, accent-insensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Lithuanian_Classic_CI_AI,
    /// <summary>
    /// Lithuanian-Classic, case-insensitive, accent-insensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Lithuanian_Classic_CI_AI_KS,
    /// <summary>
    /// Lithuanian-Classic, case-insensitive, accent-insensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Lithuanian_Classic_CI_AI_KS_WS,
    /// <summary>
    /// Lithuanian-Classic, case-insensitive, accent-insensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Lithuanian_Classic_CI_AI_WS,
    /// <summary>
    /// Lithuanian-Classic, case-insensitive, accent-sensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Lithuanian_Classic_CI_AS,
    /// <summary>
    /// Lithuanian-Classic, case-insensitive, accent-sensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Lithuanian_Classic_CI_AS_KS,
    /// <summary>
    /// Lithuanian-Classic, case-insensitive, accent-sensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Lithuanian_Classic_CI_AS_KS_WS,
    /// <summary>
    /// Lithuanian-Classic, case-insensitive, accent-sensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Lithuanian_Classic_CI_AS_WS,
    /// <summary>
    /// Lithuanian-Classic, case-sensitive, accent-insensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Lithuanian_Classic_CS_AI,
    /// <summary>
    /// Lithuanian-Classic, case-sensitive, accent-insensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Lithuanian_Classic_CS_AI_KS,
    /// <summary>
    /// Lithuanian-Classic, case-sensitive, accent-insensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Lithuanian_Classic_CS_AI_KS_WS,
    /// <summary>
    /// Lithuanian-Classic, case-sensitive, accent-insensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Lithuanian_Classic_CS_AI_WS,
    /// <summary>
    /// Lithuanian-Classic, case-sensitive, accent-sensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Lithuanian_Classic_CS_AS,
    /// <summary>
    /// Lithuanian-Classic, case-sensitive, accent-sensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Lithuanian_Classic_CS_AS_KS,
    /// <summary>
    /// Lithuanian-Classic, case-sensitive, accent-sensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Lithuanian_Classic_CS_AS_KS_WS,
    /// <summary>
    /// Lithuanian-Classic, case-sensitive, accent-sensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Lithuanian_Classic_CS_AS_WS,
    /// <summary>
    /// Lithuanian, case-sensitive, accent-insensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Lithuanian_CS_AI,
    /// <summary>
    /// Lithuanian, case-sensitive, accent-insensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Lithuanian_CS_AI_KS,
    /// <summary>
    /// Lithuanian, case-sensitive, accent-insensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Lithuanian_CS_AI_KS_WS,
    /// <summary>
    /// Lithuanian, case-sensitive, accent-insensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Lithuanian_CS_AI_WS,
    /// <summary>
    /// Lithuanian, case-sensitive, accent-sensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Lithuanian_CS_AS,
    /// <summary>
    /// Lithuanian, case-sensitive, accent-sensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Lithuanian_CS_AS_KS,
    /// <summary>
    /// Lithuanian, case-sensitive, accent-sensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Lithuanian_CS_AS_KS_WS,
    /// <summary>
    /// Lithuanian, case-sensitive, accent-sensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Lithuanian_CS_AS_WS,
    /// <summary>
    /// Macedonian, binary sort
    /// </summary>
    Macedonian_BIN,
    /// <summary>
    /// Macedonian, case-insensitive, accent-insensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Macedonian_CI_AI,
    /// <summary>
    /// Macedonian, case-insensitive, accent-insensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Macedonian_CI_AI_KS,
    /// <summary>
    /// Macedonian, case-insensitive, accent-insensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Macedonian_CI_AI_KS_WS,
    /// <summary>
    /// Macedonian, case-insensitive, accent-insensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Macedonian_CI_AI_WS,
    /// <summary>
    /// Macedonian, case-insensitive, accent-sensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Macedonian_CI_AS,
    /// <summary>
    /// Macedonian, case-insensitive, accent-sensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Macedonian_CI_AS_KS,
    /// <summary>
    /// Macedonian, case-insensitive, accent-sensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Macedonian_CI_AS_KS_WS,
    /// <summary>
    /// Macedonian, case-insensitive, accent-sensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Macedonian_CI_AS_WS,
    /// <summary>
    /// Macedonian, case-sensitive, accent-insensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Macedonian_CS_AI,
    /// <summary>
    /// Macedonian, case-sensitive, accent-insensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Macedonian_CS_AI_KS,
    /// <summary>
    /// Macedonian, case-sensitive, accent-insensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Macedonian_CS_AI_KS_WS,
    /// <summary>
    /// Macedonian, case-sensitive, accent-insensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Macedonian_CS_AI_WS,
    /// <summary>
    /// Macedonian, case-sensitive, accent-sensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Macedonian_CS_AS,
    /// <summary>
    /// Macedonian, case-sensitive, accent-sensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Macedonian_CS_AS_KS,
    /// <summary>
    /// Macedonian, case-sensitive, accent-sensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Macedonian_CS_AS_KS_WS,
    /// <summary>
    /// Macedonian, case-sensitive, accent-sensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Macedonian_CS_AS_WS,
    /// <summary>
    /// Modern-Spanish, binary sort
    /// </summary>
    Modern_Spanish_BIN,
    /// <summary>
    /// Modern-Spanish, case-insensitive, accent-insensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Modern_Spanish_CI_AI,
    /// <summary>
    /// Modern-Spanish, case-insensitive, accent-insensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Modern_Spanish_CI_AI_KS,
    /// <summary>
    /// Modern-Spanish, case-insensitive, accent-insensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Modern_Spanish_CI_AI_KS_WS,
    /// <summary>
    /// Modern-Spanish, case-insensitive, accent-insensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Modern_Spanish_CI_AI_WS,
    /// <summary>
    /// Modern-Spanish, case-insensitive, accent-sensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Modern_Spanish_CI_AS,
    /// <summary>
    /// Modern-Spanish, case-insensitive, accent-sensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Modern_Spanish_CI_AS_KS,
    /// <summary>
    /// Modern-Spanish, case-insensitive, accent-sensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Modern_Spanish_CI_AS_KS_WS,
    /// <summary>
    /// Modern-Spanish, case-insensitive, accent-sensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Modern_Spanish_CI_AS_WS,
    /// <summary>
    /// Modern-Spanish, case-sensitive, accent-insensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Modern_Spanish_CS_AI,
    /// <summary>
    /// Modern-Spanish, case-sensitive, accent-insensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Modern_Spanish_CS_AI_KS,
    /// <summary>
    /// Modern-Spanish, case-sensitive, accent-insensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Modern_Spanish_CS_AI_KS_WS,
    /// <summary>
    /// Modern-Spanish, case-sensitive, accent-insensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Modern_Spanish_CS_AI_WS,
    /// <summary>
    /// Modern-Spanish, case-sensitive, accent-sensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Modern_Spanish_CS_AS,
    /// <summary>
    /// Modern-Spanish, case-sensitive, accent-sensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Modern_Spanish_CS_AS_KS,
    /// <summary>
    /// Modern-Spanish, case-sensitive, accent-sensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Modern_Spanish_CS_AS_KS_WS,
    /// <summary>
    /// Modern-Spanish, case-sensitive, accent-sensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Modern_Spanish_CS_AS_WS,
    /// <summary>
    /// Polish, binary sort
    /// </summary>
    Polish_BIN,
    /// <summary>
    /// Polish, case-insensitive, accent-insensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Polish_CI_AI,
    /// <summary>
    /// Polish, case-insensitive, accent-insensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Polish_CI_AI_KS,
    /// <summary>
    /// Polish, case-insensitive, accent-insensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Polish_CI_AI_KS_WS,
    /// <summary>
    /// Polish, case-insensitive, accent-insensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Polish_CI_AI_WS,
    /// <summary>
    /// Polish, case-insensitive, accent-sensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Polish_CI_AS,
    /// <summary>
    /// Polish, case-insensitive, accent-sensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Polish_CI_AS_KS,
    /// <summary>
    /// Polish, case-insensitive, accent-sensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Polish_CI_AS_KS_WS,
    /// <summary>
    /// Polish, case-insensitive, accent-sensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Polish_CI_AS_WS,
    /// <summary>
    /// Polish, case-sensitive, accent-insensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Polish_CS_AI,
    /// <summary>
    /// Polish, case-sensitive, accent-insensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Polish_CS_AI_KS,
    /// <summary>
    /// Polish, case-sensitive, accent-insensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Polish_CS_AI_KS_WS,
    /// <summary>
    /// Polish, case-sensitive, accent-insensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Polish_CS_AI_WS,
    /// <summary>
    /// Polish, case-sensitive, accent-sensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Polish_CS_AS,
    /// <summary>
    /// Polish, case-sensitive, accent-sensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Polish_CS_AS_KS,
    /// <summary>
    /// Polish, case-sensitive, accent-sensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Polish_CS_AS_KS_WS,
    /// <summary>
    /// Polish, case-sensitive, accent-sensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Polish_CS_AS_WS,
    /// <summary>
    /// Romanian, binary sort
    /// </summary>
    Romanian_BIN,
    /// <summary>
    /// Romanian, case-insensitive, accent-insensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Romanian_CI_AI,
    /// <summary>
    /// Romanian, case-insensitive, accent-insensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Romanian_CI_AI_KS,
    /// <summary>
    /// Romanian, case-insensitive, accent-insensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Romanian_CI_AI_KS_WS,
    /// <summary>
    /// Romanian, case-insensitive, accent-insensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Romanian_CI_AI_WS,
    /// <summary>
    /// Romanian, case-insensitive, accent-sensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Romanian_CI_AS,
    /// <summary>
    /// Romanian, case-insensitive, accent-sensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Romanian_CI_AS_KS,
    /// <summary>
    /// Romanian, case-insensitive, accent-sensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Romanian_CI_AS_KS_WS,
    /// <summary>
    /// Romanian, case-insensitive, accent-sensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Romanian_CI_AS_WS,
    /// <summary>
    /// Romanian, case-sensitive, accent-insensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Romanian_CS_AI,
    /// <summary>
    /// Romanian, case-sensitive, accent-insensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Romanian_CS_AI_KS,
    /// <summary>
    /// Romanian, case-sensitive, accent-insensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Romanian_CS_AI_KS_WS,
    /// <summary>
    /// Romanian, case-sensitive, accent-insensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Romanian_CS_AI_WS,
    /// <summary>
    /// Romanian, case-sensitive, accent-sensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Romanian_CS_AS,
    /// <summary>
    /// Romanian, case-sensitive, accent-sensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Romanian_CS_AS_KS,
    /// <summary>
    /// Romanian, case-sensitive, accent-sensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Romanian_CS_AS_KS_WS,
    /// <summary>
    /// Romanian, case-sensitive, accent-sensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Romanian_CS_AS_WS,
    /// <summary>
    /// Slovak, binary sort
    /// </summary>
    Slovak_BIN,
    /// <summary>
    /// Slovak, case-insensitive, accent-insensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Slovak_CI_AI,
    /// <summary>
    /// Slovak, case-insensitive, accent-insensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Slovak_CI_AI_KS,
    /// <summary>
    /// Slovak, case-insensitive, accent-insensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Slovak_CI_AI_KS_WS,
    /// <summary>
    /// Slovak, case-insensitive, accent-insensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Slovak_CI_AI_WS,
    /// <summary>
    /// Slovak, case-insensitive, accent-sensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Slovak_CI_AS,
    /// <summary>
    /// Slovak, case-insensitive, accent-sensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Slovak_CI_AS_KS,
    /// <summary>
    /// Slovak, case-insensitive, accent-sensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Slovak_CI_AS_KS_WS,
    /// <summary>
    /// Slovak, case-insensitive, accent-sensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Slovak_CI_AS_WS,
    /// <summary>
    /// Slovak, case-sensitive, accent-insensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Slovak_CS_AI,
    /// <summary>
    /// Slovak, case-sensitive, accent-insensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Slovak_CS_AI_KS,
    /// <summary>
    /// Slovak, case-sensitive, accent-insensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Slovak_CS_AI_KS_WS,
    /// <summary>
    /// Slovak, case-sensitive, accent-insensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Slovak_CS_AI_WS,
    /// <summary>
    /// Slovak, case-sensitive, accent-sensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Slovak_CS_AS,
    /// <summary>
    /// Slovak, case-sensitive, accent-sensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Slovak_CS_AS_KS,
    /// <summary>
    /// Slovak, case-sensitive, accent-sensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Slovak_CS_AS_KS_WS,
    /// <summary>
    /// Slovak, case-sensitive, accent-sensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Slovak_CS_AS_WS,
    /// <summary>
    /// Slovenian, binary sort
    /// </summary>
    Slovenian_BIN,
    /// <summary>
    /// Slovenian, case-insensitive, accent-insensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Slovenian_CI_AI,
    /// <summary>
    /// Slovenian, case-insensitive, accent-insensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Slovenian_CI_AI_KS,
    /// <summary>
    /// Slovenian, case-insensitive, accent-insensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Slovenian_CI_AI_KS_WS,
    /// <summary>
    /// Slovenian, case-insensitive, accent-insensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Slovenian_CI_AI_WS,
    /// <summary>
    /// Slovenian, case-insensitive, accent-sensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Slovenian_CI_AS,
    /// <summary>
    /// Slovenian, case-insensitive, accent-sensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Slovenian_CI_AS_KS,
    /// <summary>
    /// Slovenian, case-insensitive, accent-sensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Slovenian_CI_AS_KS_WS,
    /// <summary>
    /// Slovenian, case-insensitive, accent-sensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Slovenian_CI_AS_WS,
    /// <summary>
    /// Slovenian, case-sensitive, accent-insensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Slovenian_CS_AI,
    /// <summary>
    /// Slovenian, case-sensitive, accent-insensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Slovenian_CS_AI_KS,
    /// <summary>
    /// Slovenian, case-sensitive, accent-insensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Slovenian_CS_AI_KS_WS,
    /// <summary>
    /// Slovenian, case-sensitive, accent-insensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Slovenian_CS_AI_WS,
    /// <summary>
    /// Slovenian, case-sensitive, accent-sensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Slovenian_CS_AS,
    /// <summary>
    /// Slovenian, case-sensitive, accent-sensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Slovenian_CS_AS_KS,
    /// <summary>
    /// Slovenian, case-sensitive, accent-sensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Slovenian_CS_AS_KS_WS,
    /// <summary>
    /// Slovenian, case-sensitive, accent-sensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Slovenian_CS_AS_WS,
    /// <summary>
    /// Latin1-General, case-insensitive, accent-sensitive, kanatype-insensitive, width-insensitive for Unicode Data, SQL Server Sort Order 49 on Code Page 850 for non-Unicode Data
    /// </summary>
    SQL_1xCompat_CP850_CI_AS,
    /// <summary>
    /// Latin1-General, case-insensitive, accent-sensitive, kanatype-insensitive, width-insensitive for Unicode Data, SQL Server Sort Order 121 on Code Page 1253 for non-Unicode Data
    /// </summary>
    SQL_AltDiction_CP1253_CS_AS,
    /// <summary>
    /// Latin1-General, case-insensitive, accent-insensitive, kanatype-insensitive, width-insensitive for Unicode Data, SQL Server Sort Order 57 on Code Page 850 for non-Unicode Data
    /// </summary>
    SQL_AltDiction_CP850_CI_AI,
    /// <summary>
    /// Latin1-General, case-insensitive, accent-sensitive, kanatype-insensitive, width-insensitive for Unicode Data, SQL Server Sort Order 61 on Code Page 850 for non-Unicode Data
    /// </summary>
    SQL_AltDiction_CP850_CI_AS,
    /// <summary>
    /// Latin1-General, case-sensitive, accent-sensitive, kanatype-insensitive, width-insensitive for Unicode Data, SQL Server Sort Order 55 on Code Page 850 for non-Unicode Data
    /// </summary>
    SQL_AltDiction_CP850_CS_AS,
    /// <summary>
    /// Latin1-General, case-insensitive, accent-sensitive, kanatype-insensitive, width-insensitive for Unicode Data, SQL Server Sort Order 56 on Code Page 850 for non-Unicode Data
    /// </summary>
    SQL_AltDiction_Pref_CP850_CI_AS,
    /// <summary>
    /// Croatian, case-insensitive, accent-sensitive, kanatype-insensitive, width-insensitive for Unicode Data, SQL Server Sort Order 92 on Code Page 1250 for non-Unicode Data
    /// </summary>
    SQL_Croatian_CP1250_CI_AS,
    /// <summary>
    /// Croatian, case-sensitive, accent-sensitive, kanatype-insensitive, width-insensitive for Unicode Data, SQL Server Sort Order 91 on Code Page 1250 for non-Unicode Data
    /// </summary>
    SQL_Croatian_CP1250_CS_AS,
    /// <summary>
    /// Czech, case-insensitive, accent-sensitive, kanatype-insensitive, width-insensitive for Unicode Data, SQL Server Sort Order 84 on Code Page 1250 for non-Unicode Data
    /// </summary>
    SQL_Czech_CP1250_CI_AS,
    /// <summary>
    /// Czech, case-sensitive, accent-sensitive, kanatype-insensitive, width-insensitive for Unicode Data, SQL Server Sort Order 83 on Code Page 1250 for non-Unicode Data
    /// </summary>
    SQL_Czech_CP1250_CS_AS,
    /// <summary>
    /// Danish-Norwegian, case-insensitive, accent-sensitive, kanatype-insensitive, width-insensitive for Unicode Data, SQL Server Sort Order 183 on Code Page 1252 for non-Unicode Data
    /// </summary>
    SQL_Danish_Pref_CP1_CI_AS,
    /// <summary>
    /// Latin1-General, case-sensitive, accent-sensitive, kanatype-insensitive, width-insensitive for Unicode Data, SQL Server Sort Order 210 on Code Page 1252 for non-Unicode Data
    /// </summary>
    SQL_EBCDIC037_CP1_CS_AS,
    /// <summary>
    /// German-PhoneBook, case-sensitive, accent-sensitive, kanatype-insensitive, width-insensitive for Unicode Data, SQL Server Sort Order 211 on Code Page 1252 for non-Unicode Data
    /// </summary>
    SQL_EBCDIC273_CP1_CS_AS,
    /// <summary>
    /// Danish-Norwegian, case-sensitive, accent-sensitive, kanatype-insensitive, width-insensitive for Unicode Data, SQL Server Sort Order 212 on Code Page 1252 for non-Unicode Data
    /// </summary>
    SQL_EBCDIC277_CP1_CS_AS,
    /// <summary>
    /// Finnish-Swedish, case-sensitive, accent-sensitive, kanatype-insensitive, width-insensitive for Unicode Data, SQL Server Sort Order 213 on Code Page 1252 for non-Unicode Data
    /// </summary>
    SQL_EBCDIC278_CP1_CS_AS,
    /// <summary>
    /// Latin1-General, case-sensitive, accent-sensitive, kanatype-insensitive, width-insensitive for Unicode Data, SQL Server Sort Order 214 on Code Page 1252 for non-Unicode Data
    /// </summary>
    SQL_EBCDIC280_CP1_CS_AS,
    /// <summary>
    /// Modern-Spanish, case-sensitive, accent-sensitive, kanatype-insensitive, width-insensitive for Unicode Data, SQL Server Sort Order 215 on Code Page 1252 for non-Unicode Data
    /// </summary>
    SQL_EBCDIC284_CP1_CS_AS,
    /// <summary>
    /// Latin1-General, case-sensitive, accent-sensitive, kanatype-insensitive, width-insensitive for Unicode Data, SQL Server Sort Order 216 on Code Page 1252 for non-Unicode Data
    /// </summary>
    SQL_EBCDIC285_CP1_CS_AS,
    /// <summary>
    /// French, case-sensitive, accent-sensitive, kanatype-insensitive, width-insensitive for Unicode Data, SQL Server Sort Order 217 on Code Page 1252 for non-Unicode Data
    /// </summary>
    SQL_EBCDIC297_CP1_CS_AS,
    /// <summary>
    /// Estonian, case-insensitive, accent-sensitive, kanatype-insensitive, width-insensitive for Unicode Data, SQL Server Sort Order 156 on Code Page 1257 for non-Unicode Data
    /// </summary>
    SQL_Estonian_CP1257_CI_AS,
    /// <summary>
    /// Estonian, case-sensitive, accent-sensitive, kanatype-insensitive, width-insensitive for Unicode Data, SQL Server Sort Order 155 on Code Page 1257 for non-Unicode Data
    /// </summary>
    SQL_Estonian_CP1257_CS_AS,
    /// <summary>
    /// Hungarian, case-insensitive, accent-sensitive, kanatype-insensitive, width-insensitive for Unicode Data, SQL Server Sort Order 86 on Code Page 1250 for non-Unicode Data
    /// </summary>
    SQL_Hungarian_CP1250_CI_AS,
    /// <summary>
    /// Hungarian, case-sensitive, accent-sensitive, kanatype-insensitive, width-insensitive for Unicode Data, SQL Server Sort Order 85 on Code Page 1250 for non-Unicode Data
    /// </summary>
    SQL_Hungarian_CP1250_CS_AS,
    /// <summary>
    /// Icelandic, case-insensitive, accent-sensitive, kanatype-insensitive, width-insensitive for Unicode Data, SQL Server Sort Order 186 on Code Page 1252 for non-Unicode Data
    /// </summary>
    SQL_Icelandic_Pref_CP1_CI_AS,
    /// <summary>
    /// Latin1-General, case-insensitive, accent-insensitive, kanatype-insensitive, width-insensitive for Unicode Data, SQL Server Sort Order 54 on Code Page 1252 for non-Unicode Data
    /// </summary>
    SQL_Latin1_General_CP1_CI_AI,
    /// <summary>
    /// Latin1-General, case-insensitive, accent-sensitive, kanatype-insensitive, width-insensitive for Unicode Data, SQL Server Sort Order 52 on Code Page 1252 for non-Unicode Data
    /// </summary>
    SQL_Latin1_General_CP1_CI_AS,
    /// <summary>
    /// Latin1-General, case-sensitive, accent-sensitive, kanatype-insensitive, width-insensitive for Unicode Data, SQL Server Sort Order 51 on Code Page 1252 for non-Unicode Data
    /// </summary>
    SQL_Latin1_General_CP1_CS_AS,
    /// <summary>
    /// Latin1-General, case-insensitive, accent-sensitive, kanatype-insensitive, width-insensitive for Unicode Data, SQL Server Sort Order 82 on Code Page 1250 for non-Unicode Data
    /// </summary>
    SQL_Latin1_General_CP1250_CI_AS,
    /// <summary>
    /// Latin1-General, case-sensitive, accent-sensitive, kanatype-insensitive, width-insensitive for Unicode Data, SQL Server Sort Order 81 on Code Page 1250 for non-Unicode Data
    /// </summary>
    SQL_Latin1_General_CP1250_CS_AS,
    /// <summary>
    /// Latin1-General, case-insensitive, accent-sensitive, kanatype-insensitive, width-insensitive for Unicode Data, SQL Server Sort Order 106 on Code Page 1251 for non-Unicode Data
    /// </summary>
    SQL_Latin1_General_CP1251_CI_AS,
    /// <summary>
    /// Latin1-General, case-sensitive, accent-sensitive, kanatype-insensitive, width-insensitive for Unicode Data, SQL Server Sort Order 105 on Code Page 1251 for non-Unicode Data
    /// </summary>
    SQL_Latin1_General_CP1251_CS_AS,
    /// <summary>
    /// Latin1-General, case-insensitive, accent-insensitive, kanatype-insensitive, width-insensitive for Unicode Data, SQL Server Sort Order 124 on Code Page 1253 for non-Unicode Data
    /// </summary>
    SQL_Latin1_General_CP1253_CI_AI,
    /// <summary>
    /// Latin1-General, case-insensitive, accent-sensitive, kanatype-insensitive, width-insensitive for Unicode Data, SQL Server Sort Order 114 on Code Page 1253 for non-Unicode Data
    /// </summary>
    SQL_Latin1_General_CP1253_CI_AS,
    /// <summary>
    /// Latin1-General, case-sensitive, accent-sensitive, kanatype-insensitive, width-insensitive for Unicode Data, SQL Server Sort Order 113 on Code Page 1253 for non-Unicode Data
    /// </summary>
    SQL_Latin1_General_CP1253_CS_AS,
    /// <summary>
    /// Turkish, case-insensitive, accent-sensitive, kanatype-insensitive, width-insensitive for Unicode Data, SQL Server Sort Order 130 on Code Page 1254 for non-Unicode Data
    /// </summary>
    SQL_Latin1_General_CP1254_CI_AS,
    /// <summary>
    /// Turkish, case-sensitive, accent-sensitive, kanatype-insensitive, width-insensitive for Unicode Data, SQL Server Sort Order 129 on Code Page 1254 for non-Unicode Data
    /// </summary>
    SQL_Latin1_General_CP1254_CS_AS,
    /// <summary>
    /// Latin1-General, case-insensitive, accent-sensitive, kanatype-insensitive, width-insensitive for Unicode Data, SQL Server Sort Order 138 on Code Page 1255 for non-Unicode Data
    /// </summary>
    SQL_Latin1_General_CP1255_CI_AS,
    /// <summary>
    /// Latin1-General, case-sensitive, accent-sensitive, kanatype-insensitive, width-insensitive for Unicode Data, SQL Server Sort Order 137 on Code Page 1255 for non-Unicode Data
    /// </summary>
    SQL_Latin1_General_CP1255_CS_AS,
    /// <summary>
    /// Latin1-General, case-insensitive, accent-sensitive, kanatype-insensitive, width-insensitive for Unicode Data, SQL Server Sort Order 146 on Code Page 1256 for non-Unicode Data
    /// </summary>
    SQL_Latin1_General_CP1256_CI_AS,
    /// <summary>
    /// Latin1-General, case-sensitive, accent-sensitive, kanatype-insensitive, width-insensitive for Unicode Data, SQL Server Sort Order 145 on Code Page 1256 for non-Unicode Data
    /// </summary>
    SQL_Latin1_General_CP1256_CS_AS,
    /// <summary>
    /// Latin1-General, case-insensitive, accent-sensitive, kanatype-insensitive, width-insensitive for Unicode Data, SQL Server Sort Order 154 on Code Page 1257 for non-Unicode Data
    /// </summary>
    SQL_Latin1_General_CP1257_CI_AS,
    /// <summary>
    /// Latin1-General, case-sensitive, accent-sensitive, kanatype-insensitive, width-insensitive for Unicode Data, SQL Server Sort Order 153 on Code Page 1257 for non-Unicode Data
    /// </summary>
    SQL_Latin1_General_CP1257_CS_AS,
    /// <summary>
    /// Latin1-General, binary sort for Unicode Data, SQL Server Sort Order 30 on Code Page 437 for non-Unicode Data
    /// </summary>
    SQL_Latin1_General_CP437_BIN,
    /// <summary>
    /// Latin1-General, case-insensitive, accent-insensitive, kanatype-insensitive, width-insensitive for Unicode Data, SQL Server Sort Order 34 on Code Page 437 for non-Unicode Data
    /// </summary>
    SQL_Latin1_General_CP437_CI_AI,
    /// <summary>
    /// Latin1-General, case-insensitive, accent-sensitive, kanatype-insensitive, width-insensitive for Unicode Data, SQL Server Sort Order 32 on Code Page 437 for non-Unicode Data
    /// </summary>
    SQL_Latin1_General_CP437_CI_AS,
    /// <summary>
    /// Latin1-General, case-sensitive, accent-sensitive, kanatype-insensitive, width-insensitive for Unicode Data, SQL Server Sort Order 31 on Code Page 437 for non-Unicode Data
    /// </summary>
    SQL_Latin1_General_CP437_CS_AS,
    /// <summary>
    /// Latin1-General, binary sort for Unicode Data, SQL Server Sort Order 40 on Code Page 850 for non-Unicode Data
    /// </summary>
    SQL_Latin1_General_CP850_BIN,
    /// <summary>
    /// Latin1-General, 2nd binary sort for Unicode Data, SQL Server Sort Order 40 on Code Page 850 for non-Unicode Data
    /// </summary>
    SQL_Latin1_General_CP850_BIN2,
    /// <summary>
    /// Latin1-General, case-insensitive, accent-insensitive, kanatype-insensitive, width-insensitive for Unicode Data, SQL Server Sort Order 44 on Code Page 850 for non-Unicode Data
    /// </summary>
    SQL_Latin1_General_CP850_CI_AI,
    /// <summary>
    /// Latin1-General, case-insensitive, accent-sensitive, kanatype-insensitive, width-insensitive for Unicode Data, SQL Server Sort Order 42 on Code Page 850 for non-Unicode Data
    /// </summary>
    SQL_Latin1_General_CP850_CI_AS,
    /// <summary>
    /// Latin1-General, case-sensitive, accent-sensitive, kanatype-insensitive, width-insensitive for Unicode Data, SQL Server Sort Order 41 on Code Page 850 for non-Unicode Data
    /// </summary>
    SQL_Latin1_General_CP850_CS_AS,
    /// <summary>
    /// Latin1-General, case-insensitive, accent-sensitive, kanatype-insensitive, width-insensitive for Unicode Data, SQL Server Sort Order 53 on Code Page 1252 for non-Unicode Data
    /// </summary>
    SQL_Latin1_General_Pref_CP1_CI_AS,
    /// <summary>
    /// Latin1-General, case-insensitive, accent-sensitive, kanatype-insensitive, width-insensitive for Unicode Data, SQL Server Sort Order 33 on Code Page 437 for non-Unicode Data
    /// </summary>
    SQL_Latin1_General_Pref_CP437_CI_AS,
    /// <summary>
    /// Latin1-General, case-insensitive, accent-sensitive, kanatype-insensitive, width-insensitive for Unicode Data, SQL Server Sort Order 43 on Code Page 850 for non-Unicode Data
    /// </summary>
    SQL_Latin1_General_Pref_CP850_CI_AS,
    /// <summary>
    /// Latvian, case-insensitive, accent-sensitive, kanatype-insensitive, width-insensitive for Unicode Data, SQL Server Sort Order 158 on Code Page 1257 for non-Unicode Data
    /// </summary>
    SQL_Latvian_CP1257_CI_AS,
    /// <summary>
    /// Latvian, case-sensitive, accent-sensitive, kanatype-insensitive, width-insensitive for Unicode Data, SQL Server Sort Order 157 on Code Page 1257 for non-Unicode Data
    /// </summary>
    SQL_Latvian_CP1257_CS_AS,
    /// <summary>
    /// Lithuanian, case-insensitive, accent-sensitive, kanatype-insensitive, width-insensitive for Unicode Data, SQL Server Sort Order 160 on Code Page 1257 for non-Unicode Data
    /// </summary>
    SQL_Lithuanian_CP1257_CI_AS,
    /// <summary>
    /// Lithuanian, case-sensitive, accent-sensitive, kanatype-insensitive, width-insensitive for Unicode Data, SQL Server Sort Order 159 on Code Page 1257 for non-Unicode Data
    /// </summary>
    SQL_Lithuanian_CP1257_CS_AS,
    /// <summary>
    /// Latin1-General, case-sensitive, accent-sensitive, kanatype-insensitive, width-insensitive for Unicode Data, SQL Server Sort Order 120 on Code Page 1253 for non-Unicode Data
    /// </summary>
    SQL_MixDiction_CP1253_CS_AS,
    /// <summary>
    /// Polish, case-insensitive, accent-sensitive, kanatype-insensitive, width-insensitive for Unicode Data, SQL Server Sort Order 88 on Code Page 1250 for non-Unicode Data
    /// </summary>
    SQL_Polish_CP1250_CI_AS,
    /// <summary>
    /// Polish, case-sensitive, accent-sensitive, kanatype-insensitive, width-insensitive for Unicode Data, SQL Server Sort Order 87 on Code Page 1250 for non-Unicode Data
    /// </summary>
    SQL_Polish_CP1250_CS_AS,
    /// <summary>
    /// Romanian, case-insensitive, accent-sensitive, kanatype-insensitive, width-insensitive for Unicode Data, SQL Server Sort Order 90 on Code Page 1250 for non-Unicode Data
    /// </summary>
    SQL_Romanian_CP1250_CI_AS,
    /// <summary>
    /// Romanian, case-sensitive, accent-sensitive, kanatype-insensitive, width-insensitive for Unicode Data, SQL Server Sort Order 89 on Code Page 1250 for non-Unicode Data
    /// </summary>
    SQL_Romanian_CP1250_CS_AS,
    /// <summary>
    /// Finnish-Swedish, case-insensitive, accent-sensitive, kanatype-insensitive, width-insensitive for Unicode Data, SQL Server Sort Order 60 on Code Page 850 for non-Unicode Data
    /// </summary>
    SQL_Scandinavian_CP850_CI_AS,
    /// <summary>
    /// Finnish-Swedish, case-sensitive, accent-sensitive, kanatype-insensitive, width-insensitive for Unicode Data, SQL Server Sort Order 59 on Code Page 850 for non-Unicode Data
    /// </summary>
    SQL_Scandinavian_CP850_CS_AS,
    /// <summary>
    /// Finnish-Swedish, case-insensitive, accent-sensitive, kanatype-insensitive, width-insensitive for Unicode Data, SQL Server Sort Order 58 on Code Page 850 for non-Unicode Data
    /// </summary>
    SQL_Scandinavian_Pref_CP850_CI_AS,
    /// <summary>
    /// Slovak, case-insensitive, accent-sensitive, kanatype-insensitive, width-insensitive for Unicode Data, SQL Server Sort Order 94 on Code Page 1250 for non-Unicode Data
    /// </summary>
    SQL_Slovak_CP1250_CI_AS,
    /// <summary>
    /// Slovak, case-sensitive, accent-sensitive, kanatype-insensitive, width-insensitive for Unicode Data, SQL Server Sort Order 93 on Code Page 1250 for non-Unicode Data
    /// </summary>
    SQL_Slovak_CP1250_CS_AS,
    /// <summary>
    /// Slovenian, case-insensitive, accent-sensitive, kanatype-insensitive, width-insensitive for Unicode Data, SQL Server Sort Order 96 on Code Page 1250 for non-Unicode Data
    /// </summary>
    SQL_Slovenian_CP1250_CI_AS,
    /// <summary>
    /// Slovenian, case-sensitive, accent-sensitive, kanatype-insensitive, width-insensitive for Unicode Data, SQL Server Sort Order 95 on Code Page 1250 for non-Unicode Data
    /// </summary>
    SQL_Slovenian_CP1250_CS_AS,
    /// <summary>
    /// Finnish-Swedish, case-insensitive, accent-sensitive, kanatype-insensitive, width-insensitive for Unicode Data, SQL Server Sort Order 184 on Code Page 1252 for non-Unicode Data
    /// </summary>
    SQL_SwedishPhone_Pref_CP1_CI_AS,
    /// <summary>
    /// Finnish-Swedish, case-insensitive, accent-sensitive, kanatype-insensitive, width-insensitive for Unicode Data, SQL Server Sort Order 185 on Code Page 1252 for non-Unicode Data
    /// </summary>
    SQL_SwedishStd_Pref_CP1_CI_AS,
    /// <summary>
    /// Ukrainian, case-insensitive, accent-sensitive, kanatype-insensitive, width-insensitive for Unicode Data, SQL Server Sort Order 108 on Code Page 1251 for non-Unicode Data
    /// </summary>
    SQL_Ukrainian_CP1251_CI_AS,
    /// <summary>
    /// Ukrainian, case-sensitive, accent-sensitive, kanatype-insensitive, width-insensitive for Unicode Data, SQL Server Sort Order 107 on Code Page 1251 for non-Unicode Data
    /// </summary>
    SQL_Ukrainian_CP1251_CS_AS,
    /// <summary>
    /// Thai, binary sort
    /// </summary>
    Thai_BIN,
    /// <summary>
    /// Thai, case-insensitive, accent-insensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Thai_CI_AI,
    /// <summary>
    /// Thai, case-insensitive, accent-insensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Thai_CI_AI_KS,
    /// <summary>
    /// Thai, case-insensitive, accent-insensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Thai_CI_AI_KS_WS,
    /// <summary>
    /// Thai, case-insensitive, accent-insensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Thai_CI_AI_WS,
    /// <summary>
    /// Thai, case-insensitive, accent-sensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Thai_CI_AS,
    /// <summary>
    /// Thai, case-insensitive, accent-sensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Thai_CI_AS_KS,
    /// <summary>
    /// Thai, case-insensitive, accent-sensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Thai_CI_AS_KS_WS,
    /// <summary>
    /// Thai, case-insensitive, accent-sensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Thai_CI_AS_WS,
    /// <summary>
    /// Thai, case-sensitive, accent-insensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Thai_CS_AI,
    /// <summary>
    /// Thai, case-sensitive, accent-insensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Thai_CS_AI_KS,
    /// <summary>
    /// Thai, case-sensitive, accent-insensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Thai_CS_AI_KS_WS,
    /// <summary>
    /// Thai, case-sensitive, accent-insensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Thai_CS_AI_WS,
    /// <summary>
    /// Thai, case-sensitive, accent-sensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Thai_CS_AS,
    /// <summary>
    /// Thai, case-sensitive, accent-sensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Thai_CS_AS_KS,
    /// <summary>
    /// Thai, case-sensitive, accent-sensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Thai_CS_AS_KS_WS,
    /// <summary>
    /// Thai, case-sensitive, accent-sensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Thai_CS_AS_WS,
    /// <summary>
    /// Traditional-Spanish, binary sort
    /// </summary>
    Traditional_Spanish_BIN,
    /// <summary>
    /// Traditional-Spanish, case-insensitive, accent-insensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Traditional_Spanish_CI_AI,
    /// <summary>
    /// Traditional-Spanish, case-insensitive, accent-insensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Traditional_Spanish_CI_AI_KS,
    /// <summary>
    /// Traditional-Spanish, case-insensitive, accent-insensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Traditional_Spanish_CI_AI_KS_WS,
    /// <summary>
    /// Traditional-Spanish, case-insensitive, accent-insensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Traditional_Spanish_CI_AI_WS,
    /// <summary>
    /// Traditional-Spanish, case-insensitive, accent-sensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Traditional_Spanish_CI_AS,
    /// <summary>
    /// Traditional-Spanish, case-insensitive, accent-sensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Traditional_Spanish_CI_AS_KS,
    /// <summary>
    /// Traditional-Spanish, case-insensitive, accent-sensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Traditional_Spanish_CI_AS_KS_WS,
    /// <summary>
    /// Traditional-Spanish, case-insensitive, accent-sensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Traditional_Spanish_CI_AS_WS,
    /// <summary>
    /// Traditional-Spanish, case-sensitive, accent-insensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Traditional_Spanish_CS_AI,
    /// <summary>
    /// Traditional-Spanish, case-sensitive, accent-insensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Traditional_Spanish_CS_AI_KS,
    /// <summary>
    /// Traditional-Spanish, case-sensitive, accent-insensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Traditional_Spanish_CS_AI_KS_WS,
    /// <summary>
    /// Traditional-Spanish, case-sensitive, accent-insensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Traditional_Spanish_CS_AI_WS,
    /// <summary>
    /// Traditional-Spanish, case-sensitive, accent-sensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Traditional_Spanish_CS_AS,
    /// <summary>
    /// Traditional-Spanish, case-sensitive, accent-sensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Traditional_Spanish_CS_AS_KS,
    /// <summary>
    /// Traditional-Spanish, case-sensitive, accent-sensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Traditional_Spanish_CS_AS_KS_WS,
    /// <summary>
    /// Traditional-Spanish, case-sensitive, accent-sensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Traditional_Spanish_CS_AS_WS,
    /// <summary>
    /// Turkish, binary sort
    /// </summary>
    Turkish_BIN,
    /// <summary>
    /// Turkish, case-insensitive, accent-insensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Turkish_CI_AI,
    /// <summary>
    /// Turkish, case-insensitive, accent-insensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Turkish_CI_AI_KS,
    /// <summary>
    /// Turkish, case-insensitive, accent-insensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Turkish_CI_AI_KS_WS,
    /// <summary>
    /// Turkish, case-insensitive, accent-insensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Turkish_CI_AI_WS,
    /// <summary>
    /// Turkish, case-insensitive, accent-sensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Turkish_CI_AS,
    /// <summary>
    /// Turkish, case-insensitive, accent-sensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Turkish_CI_AS_KS,
    /// <summary>
    /// Turkish, case-insensitive, accent-sensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Turkish_CI_AS_KS_WS,
    /// <summary>
    /// Turkish, case-insensitive, accent-sensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Turkish_CI_AS_WS,
    /// <summary>
    /// Turkish, case-sensitive, accent-insensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Turkish_CS_AI,
    /// <summary>
    /// Turkish, case-sensitive, accent-insensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Turkish_CS_AI_KS,
    /// <summary>
    /// Turkish, case-sensitive, accent-insensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Turkish_CS_AI_KS_WS,
    /// <summary>
    /// Turkish, case-sensitive, accent-insensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Turkish_CS_AI_WS,
    /// <summary>
    /// Turkish, case-sensitive, accent-sensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Turkish_CS_AS,
    /// <summary>
    /// Turkish, case-sensitive, accent-sensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Turkish_CS_AS_KS,
    /// <summary>
    /// Turkish, case-sensitive, accent-sensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Turkish_CS_AS_KS_WS,
    /// <summary>
    /// Turkish, case-sensitive, accent-sensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Turkish_CS_AS_WS,
    /// <summary>
    /// Ukrainian, binary sort
    /// </summary>
    Ukrainian_BIN,
    /// <summary>
    /// Ukrainian, case-insensitive, accent-insensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Ukrainian_CI_AI,
    /// <summary>
    /// Ukrainian, case-insensitive, accent-insensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Ukrainian_CI_AI_KS,
    /// <summary>
    /// Ukrainian, case-insensitive, accent-insensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Ukrainian_CI_AI_KS_WS,
    /// <summary>
    /// Ukrainian, case-insensitive, accent-insensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Ukrainian_CI_AI_WS,
    /// <summary>
    /// Ukrainian, case-insensitive, accent-sensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Ukrainian_CI_AS,
    /// <summary>
    /// Ukrainian, case-insensitive, accent-sensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Ukrainian_CI_AS_KS,
    /// <summary>
    /// Ukrainian, case-insensitive, accent-sensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Ukrainian_CI_AS_KS_WS,
    /// <summary>
    /// Ukrainian, case-insensitive, accent-sensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Ukrainian_CI_AS_WS,
    /// <summary>
    /// Ukrainian, case-sensitive, accent-insensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Ukrainian_CS_AI,
    /// <summary>
    /// Ukrainian, case-sensitive, accent-insensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Ukrainian_CS_AI_KS,
    /// <summary>
    /// Ukrainian, case-sensitive, accent-insensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Ukrainian_CS_AI_KS_WS,
    /// <summary>
    /// Ukrainian, case-sensitive, accent-insensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Ukrainian_CS_AI_WS,
    /// <summary>
    /// Ukrainian, case-sensitive, accent-sensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Ukrainian_CS_AS,
    /// <summary>
    /// Ukrainian, case-sensitive, accent-sensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Ukrainian_CS_AS_KS,
    /// <summary>
    /// Ukrainian, case-sensitive, accent-sensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Ukrainian_CS_AS_KS_WS,
    /// <summary>
    /// Ukrainian, case-sensitive, accent-sensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Ukrainian_CS_AS_WS,
    /// <summary>
    /// Vietnamese, binary sort
    /// </summary>
    Vietnamese_BIN,
    /// <summary>
    /// Vietnamese, case-insensitive, accent-insensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Vietnamese_CI_AI,
    /// <summary>
    /// Vietnamese, case-insensitive, accent-insensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Vietnamese_CI_AI_KS,
    /// <summary>
    /// Vietnamese, case-insensitive, accent-insensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Vietnamese_CI_AI_KS_WS,
    /// <summary>
    /// Vietnamese, case-insensitive, accent-insensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Vietnamese_CI_AI_WS,
    /// <summary>
    /// Vietnamese, case-insensitive, accent-sensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Vietnamese_CI_AS,
    /// <summary>
    /// Vietnamese, case-insensitive, accent-sensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Vietnamese_CI_AS_KS,
    /// <summary>
    /// Vietnamese, case-insensitive, accent-sensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Vietnamese_CI_AS_KS_WS,
    /// <summary>
    /// Vietnamese, case-insensitive, accent-sensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Vietnamese_CI_AS_WS,
    /// <summary>
    /// Vietnamese, case-sensitive, accent-insensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Vietnamese_CS_AI,
    /// <summary>
    /// Vietnamese, case-sensitive, accent-insensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Vietnamese_CS_AI_KS,
    /// <summary>
    /// Vietnamese, case-sensitive, accent-insensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Vietnamese_CS_AI_KS_WS,
    /// <summary>
    /// Vietnamese, case-sensitive, accent-insensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Vietnamese_CS_AI_WS,
    /// <summary>
    /// Vietnamese, case-sensitive, accent-sensitive, kanatype-insensitive, width-insensitive
    /// </summary>
    Vietnamese_CS_AS,
    /// <summary>
    /// Vietnamese, case-sensitive, accent-sensitive, kanatype-sensitive, width-insensitive
    /// </summary>
    Vietnamese_CS_AS_KS,
    /// <summary>
    /// Vietnamese, case-sensitive, accent-sensitive, kanatype-sensitive, width-sensitive
    /// </summary>
    Vietnamese_CS_AS_KS_WS,
    /// <summary>
    /// Vietnamese, case-sensitive, accent-sensitive, kanatype-insensitive, width-sensitive
    /// </summary>
    Vietnamese_CS_AS_WS,
  }
}
