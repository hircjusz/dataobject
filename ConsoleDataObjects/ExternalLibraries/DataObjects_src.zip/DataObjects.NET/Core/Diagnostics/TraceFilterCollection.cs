// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;

namespace DataObjects.NET.Diagnostics
{
  /// <summary>
  /// A collection-like object containing tracing filters.
  /// </summary>
  /// <remarks>All public methods and properties of this collection 
  /// are thread-safe.</remarks>
  public sealed class TraceFilterCollection
  {
    private Hashtable filters;
    
    /// <summary>
    /// Gets the number of elements contained in the collection.
    /// </summary>
    public int Count {
      get {
        lock (Trace.staticLock)
          return filters.Count;
      }
    }
    
    /// <summary>
    /// Copies the elements of the colelction to an <see cref="Array"/>, 
    /// starting at a particular <see cref="Array"/> index.
    /// </summary>
    /// <param name="array">The one-dimensional <see cref="Array"/> that is the 
    /// destination of the elements copied from collection. 
    /// The <see cref="Array"/> must have zero-based indexing.</param>
    /// <param name="index">The zero-based index in array at which copying begins. </param>
    public void CopyTo(Array array, int index)
    {
      lock (Trace.staticLock)
        filters.Keys.CopyTo(array, index);
    }
    
    /// <summary>
    /// Adds a filter to the collection.
    /// </summary>
    /// <param name="filter"></param>
    public void Add(string filter)
    {
      lock (Trace.staticLock) {
        if (Trace.isActive)
          throw new InvalidOperationException("Can not change tracing filters. Trace is active.");
        filters[filter] = filters;
      }
    }
    
    /// <summary>
    /// Removes all filters from the collection.
    /// </summary>
    public void Clear()
    {
      lock (Trace.staticLock) {
        if (Trace.isActive)
          throw new InvalidOperationException("Can not change tracing filters. Trace is active.");
        filters.Clear();
      }
    }
    
    /// <summary>
    /// Determines whether the collection contains specified filter.
    /// </summary>
    /// <param name="filter">The filter to locate in the collection.</param>
    /// <returns><see langword="true"/> if the collection contains the filter; 
    /// otherwise, <see langword="false"/>.</returns>
    public bool Contains(string filter)
    {
      lock (Trace.staticLock)
        return filters.Contains(filter);
    }
    
    /// <summary>
    /// Removes the filter from the collection.
    /// </summary>
    /// <param name="filter">The filter to remove.</param>
    public void Remove(string filter)
    {
      lock (Trace.staticLock) {
        if (Trace.isActive)
          throw new InvalidOperationException("Can not change tracing filters. Trace is active.");
        filters.Remove(filter);
      }
    }
    
    // Constructors
    
    internal TraceFilterCollection()
    {
      this.filters = new Hashtable();
    }
  }
}
