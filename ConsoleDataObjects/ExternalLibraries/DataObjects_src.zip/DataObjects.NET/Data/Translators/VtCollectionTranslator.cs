// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;
using System.Data;
using System.Reflection;
using DataObjects.NET.Attributes;
using DataObjects.NET.Exceptions;
using DataObjects.NET.ObjectModel;
using DataObjects.NET.Data.CodeManage;

namespace DataObjects.NET.Data
{
  /// <summary>
  /// Provides a relation between <see cref="ValueTypeCollection"/> and a <see cref="DataTable"/>.
  /// <see cref="VtCollectionTranslator"/> is used to fill/update <see cref="ValueTypeCollection"/>s.
  /// </summary>
  /// <remarks>
  /// <see cref="DataTable"/> must contain "ID" and "Owner" columns which are a primary key columns.
  /// "ID" and "Owner" columns must be of <see cref="System.Int64"/> type.
  /// </remarks>
  internal class VtCollectionTranslator
  {
    private DoTranslator doTranslator;
    private DataTable dataTable;
    private string collectionName;
    private string fullCollectionName;
    private Culture culture;
    private ArrayList fieldTranslatorsList;
    private System.Type itemType;
    private DataColumn sysIDColumn;
    private DataColumn sysOwnerColumn;
    
    /// <summary>
    /// Gets <see cref="Adapter"/> associated with the <see cref="VtCollectionTranslator"/>.
    /// </summary>
    public Adapter Adapter {
      get {
        return doTranslator.Adapter;
      }
    }
    
    /// <summary>
    /// Gets collection full name: "CollectionName[-CultureName]".
    /// </summary>
    public string FullCollectionName {
      get {
        return fullCollectionName;
      }
    }
    
    /// <summary>
    /// Gets collection name. Collection name doesn't include culture part.
    /// </summary>
    public string CollectionName {
      get {
        return collectionName;
      }
    }
    
    /// <summary>
    /// Gets <see cref="DataTable"/> associated with the translator.
    /// </summary>
    public DataTable DataTable {
      get {
        return dataTable;
      }
    }
    
    /// <summary>
    /// Gets <see cref="ValueTypeCollection"/>'s item type.
    /// </summary>
    public System.Type ItemType {
      get {
        return itemType;
      }
    }
    
    /// <summary>
    /// Fills <see cref="DataObject"/>'s <see cref="ValueTypeCollection"/> into the table.
    /// </summary>
    /// <param name="dataObject">DataObject whose collection to fill.</param>
    public void Fill(DataObject dataObject)
    {
      if (dataObject==null)
        throw new ArgumentNullException("dataObject");
        
      ValueTypeCollection vtCollection = GetVtCollection(dataObject);
      
      if (vtCollection!=null) {
        foreach (ValueTypeCollectionEntry vtcEntry in vtCollection) {
          DataRow dataRow = dataTable.Rows.Find(vtcEntry.ItemID);
          if (dataRow!=null) {
            if ((doTranslator.Adapter.FillOptions & FillOptions.RemoveOnCollectionConflict)!=0) {
              dataRow[sysOwnerColumn] = vtcEntry.Owner.ID;
              foreach (FieldTranslator fieldTranslator in fieldTranslatorsList)
                fieldTranslator.Fill(vtcEntry.Value, dataRow);
            } else
              throw new AdapterException(
                String.Format("Row with ID={0} is already exists.", vtcEntry.ItemID));
          } else {
            DataRow newRow = dataTable.NewRow();
            newRow.BeginEdit();
            newRow[sysIDColumn] = vtcEntry.ItemID;
            newRow[sysOwnerColumn] = vtcEntry.Owner.ID;
            foreach (FieldTranslator fieldTranslator in fieldTranslatorsList)
              fieldTranslator.Fill(vtcEntry.Value, newRow);
            newRow.EndEdit();
            dataTable.Rows.Add(newRow);
          }
        }
      }
    }
    
    /// <summary>
    /// Updates <see cref="ValueTypeCollection"/>s from the <see cref="DataTable"/>.
    /// </summary>
    public void Update()
    {
      Adapter adapter = doTranslator.Adapter;
      
      Hashtable vtcProc = new Hashtable();
      
      foreach (DataRow row in dataTable.Rows) {
      
        TransactionController tc = adapter.Session.CreateTransactionController(TransactionMode.NewTransactionRequired);
        try {
        
          if (row.RowState!=DataRowState.Deleted) {
            long id = (long)row[sysIDColumn];
            long ownerID = (long)row[sysOwnerColumn];
            
            DataObject owner = (ownerID<0) ?
              adapter.UpdateQueue.GetCreatedObject(ownerID) :
              adapter.Session[ownerID];
            if (owner==null)
              throw new AdapterException(
                String.Format("DataObject with ID=\"{0}\" is not found.", ownerID));
                
            ValueTypeCollection vtc = (ValueTypeCollection)vtcProc[owner];
            if (vtc==null) {
              vtc = GetVtCollection(owner);
              vtc.Load();
              vtcProc[owner] = vtc;
            }
            
            ValueTypeCollectionEntry vtce = null;
            if (id<0) {
              CreateVtcItemEventArgs cvi = new CreateVtcItemEventArgs(vtc.ItemType, row);
              adapter.Internal_OnCreateVtcItem(cvi);
              if (cvi.Value!=null) {
                object obj = cvi.Value;
                foreach (FieldTranslator fieldTranslator in fieldTranslatorsList)
                  obj = fieldTranslator.Update(obj, row);
                if (vtc.PairTo!=null) {
                  ValueTypeCollectionField vtcf = (ValueTypeCollectionField)(vtc.PairTo);
                  DataObject masterCollectionOwner = (DataObject)vtcf.OwnerField.FieldInfo.GetValue(obj);
                  ((ValueTypeCollection)masterCollectionOwner.GetProperty(vtcf.AbsoluteName, culture)).Load();
                }
                int ind = vtc.Add(obj);
                if (ind>=0) {
                  vtce = vtc[ind];
                  row[sysIDColumn] = vtce.ItemID;
                  foreach (FieldTranslator fieldTranslator in fieldTranslatorsList)
                    fieldTranslator.Fill(vtce.Value, row);
                }
              }
            } else {
              vtce = vtc[id];
              if (vtce==null)
                throw new AdapterException(
                  String.Format("ValueTypeCollectionEntry with ID=\"{0}\" is not found.", id));
              foreach (FieldTranslator fieldTranslator in fieldTranslatorsList)
                fieldTranslator.Update(vtce, row);
            }
          } else {
            long id = (long)row[sysIDColumn, DataRowVersion.Original];
            long ownerID = (long)row[sysOwnerColumn, DataRowVersion.Original];
            
            DataObject owner = (ownerID<0) ?
              adapter.UpdateQueue.GetCreatedObject(ownerID) :
              adapter.Session[ownerID];
            if (owner!=null) {
              ValueTypeCollection vtc = (ValueTypeCollection)vtcProc[owner];
              if (vtc==null) {
                vtc = GetVtCollection(owner);
                vtc.Load();
                vtcProc[owner] = vtc;
              }
              
              vtc.Remove(id);
            }
          }
          
          tc.Commit();
        } catch (Exception e) {
          tc.Rollback(e);
          if ((adapter.UpdateOptions & UpdateOptions.IgnoreErrors)==0)
            throw;
        }
      }
    }
    
    private ValueTypeCollection GetVtCollection(DataObject dataObject)
    {
      ValueTypeCollection vtCollection = (ValueTypeCollection)dataObject.GetProperty(collectionName, culture);
      
      PropertyEventArgs e = new PropertyEventArgs(dataObject, collectionName, culture, vtCollection);
      doTranslator.Adapter.Internal_OnGetProperty(e);
      vtCollection = (ValueTypeCollection)e.Value;
      
      return vtCollection;
    }
    
    /// <summary>
    /// Initializes a new instance of the <see cref="VtCollectionTranslator"/> class.
    /// </summary>
    /// <param name="doTranslator"><see cref="DoTranslator"/> of a <see cref="DataObject"/>.</param>
    /// <param name="vtcMapping"><see cref="ValueTypeCollection"/> mapping item.</param>
    internal VtCollectionTranslator(DoTranslator doTranslator, VtcMappingItem vtcMapping)
    {
      if (doTranslator==null)
        throw new ArgumentNullException("doTranslator");
      if (vtcMapping==null)
        throw new ArgumentNullException("vtcMapping");
      if (vtcMapping.CollectionName==null)
        throw new NullReferenceException("vtcMapping.CollectionName is null.");
      if (vtcMapping.TableName==null)
        throw new NullReferenceException("vtcMapping.TableName is null.");
        
      this.doTranslator = doTranslator;
      
      fullCollectionName = vtcMapping.CollectionName;
      collectionName = fullCollectionName;
      culture = null;
      
      int ind = fullCollectionName.LastIndexOf("-");
      if (ind!=-1) {
        collectionName = fullCollectionName.Substring(0, ind);
        string cultureName = fullCollectionName.Substring(ind);
        culture = doTranslator.Adapter.Domain.Cultures[cultureName];
        if (culture==null)
          throw new AdapterException(
            String.Format("Culture \"{0}\" is not registered in the domain.", cultureName));
      }
      
      PropertyInfo propertyInfo = doTranslator.Type.SourceType.GetProperty(collectionName);
      if (propertyInfo==null)
        throw new AdapterException(
          String.Format("Property \"{0}\" does not exists.", collectionName));
      
      itemType = typeof(System.Object);
      object[] attributes = propertyInfo.GetCustomAttributes(typeof(ItemTypeAttribute), true);
      if (attributes!=null && attributes.Length==1) {
        ItemTypeAttribute itemTypeAttr = (ItemTypeAttribute)attributes[0];
        itemType = itemTypeAttr.Type;
      }
      
      dataTable = doTranslator.Adapter.dataSource.Tables[vtcMapping.TableName];
      if (dataTable==null)
        throw new AdapterException(
          String.Format("Table \"{0}\" Does not exists.", vtcMapping.TableName));
          
      sysIDColumn = dataTable.Columns["ID"];
      sysOwnerColumn = dataTable.Columns[ValueTypeCollectionField.DefaultOwnerName];
      
      if (sysIDColumn==null)
        throw new AdapterException("\"ID\" column is absent.");
      if (sysOwnerColumn==null)
        throw new AdapterException(String.Format(
          "\"{0}\" column is absent.", ValueTypeCollectionField.DefaultOwnerName));
      if (sysIDColumn.DataType!=typeof(long))
        throw new AdapterException("Invalid \"ID\" column data type.");
      if (sysOwnerColumn.DataType!=typeof(long))
        throw new AdapterException(String.Format(
          "Invalid \"{0}\" column data type.", ValueTypeCollectionField.DefaultOwnerName));
      
      DataColumn[] primaryKey = dataTable.PrimaryKey;
      if (primaryKey==null || primaryKey.Length!=1 || primaryKey[0]!=sysIDColumn)
        throw new AdapterException("Invalid Primary Key column.");
       
      Hashtable fieldTransByPath = new Hashtable();
      Hashtable fieldTransByColumn = new Hashtable(); 
      fieldTranslatorsList = new ArrayList();
      
      foreach (FieldMappingItem fieldMapping in vtcMapping.Fields) {
        FieldTranslator fieldTrans = new FieldTranslator(this, fieldMapping);
        if (fieldTransByPath.ContainsKey(fieldTrans.Path))
          throw new AdapterException(
            String.Format("Field \"{0}\" is already mapped.", fieldTrans.Path));
        if (fieldTransByColumn.ContainsKey(fieldTrans.DataColumn))
          throw new AdapterException(
            String.Format("Column \"{0}\" is already mapped.", fieldTrans.DataColumn.ColumnName));
        fieldTransByPath[fieldTrans.Path] = fieldTrans;
        fieldTransByColumn[fieldTrans.DataColumn] = fieldTrans;
        fieldTranslatorsList.Add(fieldTrans);
      }
    }
  }
}
