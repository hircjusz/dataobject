// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.IO;
using System.Text;
using System.Threading;
using System.Collections;
using System.Collections.Specialized;
using System.Data;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Attributes;
using DataObjects.NET.Security;
using DataObjects.NET.Security.Permissions;

namespace DataObjects.NET
{
  /// <summary>
  /// Provides set of properties allowing to change system object names
  /// in the <see cref="Domain"/>.
  /// <seealso cref="DataObjects.NET.Domain.SystemObjectNames"/>
  /// <seealso cref="SystemObjects"/>
  /// </summary>
  /// <remarks>
  /// <note type="note">It's your responsibility - to provide a unique name 
  /// for each system object.</note>
  /// </remarks>
  #if (!NoMBR)
  public class SystemObjectNames: MarshalByRefObject
  #else
  public class SystemObjectNames: Object
  #endif
  {
    private  Domain domain;
    internal string systemUserName          = "System";
    internal string administratorUserName   = "Administrator";
    internal string guestUserName           = "Guest";
    internal string anonymousUserName       = "Anonymous User";
    internal string administratorsRoleName  = "Administrators";
    internal string usersRoleName           = "Users";
    internal string guestsRoleName          = "Guests";
    internal string everyoneRoleName        = "Everyone";
  

    /// <summary>
    /// Gets or sets the name of the System <see cref="User"/>.
    /// Default value is "System".
    /// </summary>
    /// <remarks>
    /// <note type="note">It's your responsibility - to provide a unique name 
    /// for each system object.</note>
    /// </remarks>
    public string SystemUserName {
      get {
        return systemUserName;
      }
      set {
        if (domain.status!=DomainStatus.Created && domain.status!=DomainStatus.Error)
          throw new InvalidOperationException("Attempt to change SystemObjectNames in the Domain with already called Build method.");
        if (value==null)
          throw new ArgumentNullException("value");
        if (value=="")
          throw new ArgumentException("Value shouldn't be an empty string.");
        systemUserName = value;
      }
    }

    /// <summary>
    /// Gets or sets the name of the Administrator <see cref="User"/>.
    /// Default value is "Administrator".
    /// </summary>
    /// <remarks>
    /// <note type="note">It's your responsibility - to provide a unique name 
    /// for each system object.</note>
    /// </remarks>
    public string AdministratorUserName {
      get {
        return administratorUserName;
      }
      set {
        if (domain.status!=DomainStatus.Created && domain.status!=DomainStatus.Error)
          throw new InvalidOperationException("Attempt to change SystemObjectNames in the Domain with already called Build method.");
        if (value==null)
          throw new ArgumentNullException("value");
        if (value=="")
          throw new ArgumentException("Value shouldn't be an empty string.");
        administratorUserName = value;
      }
    }
    
    /// <summary>
    /// Gets or sets the name of the Guest <see cref="User"/>.
    /// Default value is "Guest".
    /// This system object isn't specially supported by DataObjects.NET, it is
    /// provided simply for convenience.
    /// </summary>
    /// <remarks>
    /// <note type="note">It's your responsibility - to provide a unique name 
    /// for each system object.</note>
    /// </remarks>
    public string GuestUserName {
      get {
        return guestUserName;
      }
      set {
        if (domain.status!=DomainStatus.Created && domain.status!=DomainStatus.Error)
          throw new InvalidOperationException("Attempt to change SystemObjectNames in the Domain with already called Build method.");
        if (value==null)
          throw new ArgumentNullException("value");
        if (value=="")
          throw new ArgumentException("Value shouldn't be an empty string.");
        guestUserName = value;
      }
    }
    
    /// <summary>
    /// Gets or sets the name of the Anonymous <see cref="User"/>.
    /// Default value is "Anonymous User".
    /// This system object isn't specially supported by DataObjects.NET, it is
    /// provided simply for convenience.
    /// </summary>
    /// <remarks>
    /// <note type="note">It's your responsibility - to provide a unique name 
    /// for each system object.</note>
    /// </remarks>
    public string AnonymousUserName {
      get {
        return anonymousUserName;
      }
      set {
        if (domain.status!=DomainStatus.Created && domain.status!=DomainStatus.Error)
          throw new InvalidOperationException("Attempt to change SystemObjectNames in the Domain with already called Build method.");
        if (value==null)
          throw new ArgumentNullException("value");
        if (value=="")
          throw new ArgumentException("Value shouldn't be an empty string.");
        anonymousUserName = value;
      }
    }
    
    /// <summary>
    /// Gets or sets the name of the Administrators <see cref="Role"/>.
    /// Default value is "Administrators".
    /// </summary>
    /// <remarks>
    /// <note type="note">It's your responsibility - to provide a unique name 
    /// for each system object.</note>
    /// </remarks>
    public string AdministratorsRoleName {
      get {
        return administratorsRoleName;
      }
      set {
        if (domain.status!=DomainStatus.Created && domain.status!=DomainStatus.Error)
          throw new InvalidOperationException("Attempt to change SystemObjectNames in the Domain with already called Build method.");
        if (value==null)
          throw new ArgumentNullException("value");
        if (value=="")
          throw new ArgumentException("Value shouldn't be an empty string.");
        administratorsRoleName = value;
      }
    }
    
    /// <summary>
    /// Gets or sets the name of the Users <see cref="Role"/>.
    /// Default value is "Users".
    /// This system object isn't specially supported by DataObjects.NET, it is
    /// provided simply for convenience.
    /// </summary>
    /// <remarks>
    /// <note type="note">It's your responsibility - to provide a unique name 
    /// for each system object.</note>
    /// </remarks>
    public string UsersRoleName {
      get {
        return usersRoleName;
      }
      set {
        if (domain.status!=DomainStatus.Created && domain.status!=DomainStatus.Error)
          throw new InvalidOperationException("Attempt to change SystemObjectNames in the Domain with already called Build method.");
        if (value==null)
          throw new ArgumentNullException("value");
        if (value=="")
          throw new ArgumentException("Value shouldn't be an empty string.");
        usersRoleName = value;
      }
    }
    
    /// <summary>
    /// Gets or sets the name of the Guests <see cref="Role"/>.
    /// Default value is "Guests".
    /// This system object isn't specially supported by DataObjects.NET, it is
    /// provided simply for convenience.
    /// </summary>
    /// <remarks>
    /// <note type="note">It's your responsibility - to provide a unique name 
    /// for each system object.</note>
    /// </remarks>
    public string GuestsRoleName {
      get {
        return guestsRoleName;
      }
      set {
        if (domain.status!=DomainStatus.Created && domain.status!=DomainStatus.Error)
          throw new InvalidOperationException("Attempt to change SystemObjectNames in the Domain with already called Build method.");
        if (value==null)
          throw new ArgumentNullException("value");
        if (value=="")
          throw new ArgumentException("Value shouldn't be an empty string.");
        guestsRoleName = value;
      }
    }
    
    /// <summary>
    /// Gets or sets the name of the Everyone <see cref="Role"/>.
    /// Default value is "Everyone".
    /// </summary>
    /// <remarks>
    /// <note type="note">It's your responsibility - to provide a unique name 
    /// for each system object.</note>
    /// </remarks>
    public string EveryoneRoleName {
      get {
        return everyoneRoleName;
      }
      set {
        if (domain.status!=DomainStatus.Created && domain.status!=DomainStatus.Error)
          throw new InvalidOperationException("Attempt to change SystemObjectNames in the Domain with already called Build method.");
        if (value==null)
          throw new ArgumentNullException("value");
        if (value=="")
          throw new ArgumentException("Value shouldn't be an empty string.");
        everyoneRoleName = value;
      }
    }
    

    // Constructors
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="domain">Domain, to which current instance should be bound.</param>
    internal SystemObjectNames(Domain domain)
    {
      if (domain==null)
        throw new ArgumentNullException("domain");
      this.domain = domain;
    }
  }
}
