// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.IO;
using System.Text;
using System.Collections;
using System.Collections.Specialized;
using System.Data;
using System.Data.OleDb;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Attributes;
using DataObjects.NET.ObjectModel;
using DataObjects.NET.DatabaseModel;
using DataObjects.NET.FullText;

namespace DataObjects.NET.Database.Drivers.MSAccess
{
  /// <summary>
  /// Microsoft Access implementation of <see cref="PersisterForCollections"/>.
  /// </summary>
  public class MSAccessPersisterForCollections : PersisterForCollections
  {
    OleDbCommand  cmd;
    StringBuilder sbCmd  = new StringBuilder(256);
    Utils         utils;
    
    /// <summary>
    /// Called when it's necessary to change the command timeout value.
    /// </summary>
    /// <param name="commandTimeout">New command timeout value.</param>
    public override void SetCommandTimeout(int commandTimeout)
    {
      EnsureCommandValid(cmd);
      cmd.CommandTimeout = commandTimeout;
    }

    /// <summary>
    /// Called by <see cref="Persister.SetTransaction"/> method to
    /// switch the instance to the next transaction.
    /// </summary>
    /// <param name="transaction">New transaction.</param>
    public override void SetTransaction(IDbTransaction transaction)
    {
      EnsureCommandValid(cmd);
      cmd.Transaction  = (OleDbTransaction)transaction;
    }

    /// <summary>
    /// Counts the number of items in the collection.
    /// This method should always place serializable level locks.
    /// </summary>
    /// <param name="table">Table where collection data is stored.</param>
    /// <param name="ownerIdColumn">Column with the container IDs.</param>
    /// <param name="ownerId">ID of the container.</param>
    /// <returns>Item count.</returns>
    public override int Count(ISchemaNode table, string ownerIdColumn, long ownerId)
    {
      EnsureCommandValid(cmd);
      cmd.Parameters.Clear();
      
      cmd.CommandText = 
        "Select count(*) from "+table.FullQuotedName+" where ["+ownerIdColumn+"]=" + ownerId.ToString();
      ((MSAccessDriver)Driver).LogSqlCommand( "MSAccessPersisterForCollections.Count", cmd );
      return Convert.ToInt32(cmd.ExecuteScalar());
    }

    /// <summary>
    /// Gets the minimal ID of item in the collection.
    /// This method should always place serializable level locks.
    /// </summary>
    /// <param name="table">Table where collection data is stored.</param>
    /// <param name="ownerIdColumn">Column with the container IDs.</param>
    /// <param name="itemIdColumn">Column with the item IDs.</param>
    /// <param name="ownerId">ID of the container.</param>
    /// <returns>Item ID.</returns>
    public override long Min(ISchemaNode table, string ownerIdColumn, string itemIdColumn, long ownerId)
    {
      EnsureCommandValid(cmd);
      cmd.Parameters.Clear();
      
      cmd.CommandText = 
        "Select min(["+itemIdColumn+"]) from "+table.FullQuotedName+" where ["+ownerIdColumn+"]=" + ownerId.ToString();
      ((MSAccessDriver)Driver).LogSqlCommand( "MSAccessPersisterForCollections.Min", cmd );
      object retval = cmd.ExecuteScalar();
      if (retval is DBNull)
        return -1;
      return Convert.ToInt32(retval);
    }

    /// <summary>
    /// Gets the maximal ID of item in the collection.
    /// This method should always place serializable level locks.
    /// </summary>
    /// <param name="table">Table where collection data is stored.</param>
    /// <param name="ownerIdColumn">Column with the container IDs.</param>
    /// <param name="itemIdColumn">Column with the item IDs.</param>
    /// <param name="ownerId">ID of the container.</param>
    /// <returns>Item ID.</returns>
    public override long Max(ISchemaNode table, string ownerIdColumn, string itemIdColumn, long ownerId)
    {
      EnsureCommandValid(cmd);
      cmd.Parameters.Clear();
      
      cmd.CommandText = 
        "Select max(["+itemIdColumn+"]) from "+table.FullQuotedName+" where ["+ownerIdColumn+"]=" + ownerId.ToString();
      ((MSAccessDriver)Driver).LogSqlCommand( "MSAccessPersisterForCollections.Max", cmd );
      object retval = cmd.ExecuteScalar();
      if (retval is DBNull)
        return -1;
      return Convert.ToInt32(retval);
    }

    /// <summary>
    /// Loads a range of items from the collection.
    /// This method should always place serializable level locks.
    /// </summary>
    /// <param name="table">Table where collection data is stored.</param>
    /// <param name="ownerIdColumn">Column with the container IDs.</param>
    /// <param name="itemIdColumn">Column with the item IDs.</param>
    /// <param name="ownerId">ID of the container.</param>
    /// <param name="itemId">ID of the item.</param>
    /// <param name="rangeType">Type of the range.</param>
    /// <param name="length">Length of the range.</param>
    /// <returns><see cref="ArrayList"/> of IDs.</returns>
    public override ArrayList LoadRange(ISchemaNode table, string ownerIdColumn, string itemIdColumn, long ownerId, long itemId, RangeType rangeType, long length)
    {
      return LoadRange(table, ownerIdColumn, itemIdColumn, ownerId, itemId, rangeType, length, null);
    }

    /// <summary>
    /// Loads a range of items from the collection.
    /// This method should always place serializable level locks.
    /// </summary>
    /// <param name="table">Table where collection data is stored.</param>
    /// <param name="ownerIdColumn">Column with the container IDs.</param>
    /// <param name="itemIdColumn">Column with the item IDs.</param>
    /// <param name="ownerId">ID of the container.</param>
    /// <param name="itemId">ID of the item.</param>
    /// <param name="rangeType">Type of the range.</param>
    /// <param name="length">Length of the range.</param>
    /// <param name="columns">Names of the additional columns to fetch.</param>
    /// <returns><see cref="ArrayList"/> of <see cref="IDictionary"/>s.</returns>
    public override ArrayList LoadRange(ISchemaNode table, string ownerIdColumn, string itemIdColumn, long ownerId, long itemId, RangeType rangeType, long length, ArrayList columns)
    {
      EnsureCommandValid(cmd);
      cmd.Parameters.Clear();
      
      sbCmd.Length = 0;
      sbCmd.Append("Select ");
      if (rangeType != RangeType.Equal && length != 0)
        sbCmd.Append("top "+length.ToString()+" ");
      sbCmd.Append("["+itemIdColumn+"]");
      int cnt = columns!=null ? columns.Count : 0;
      for (int i = 0; i<cnt; i++)
        sbCmd.Append(", ["+(columns[i] as string)+"]");
      sbCmd.Append(" from "+table.FullQuotedName+" where ["+ownerIdColumn+"]=" + ownerId.ToString() + " and ["+itemIdColumn+"]");
      switch (rangeType)
      {
        case RangeType.Equal:
          sbCmd.Append("=" + itemId.ToString());
          break;
        case RangeType.Greater:
          sbCmd.Append(">" + itemId.ToString() + " order by ["+itemIdColumn+"] asc");
          break;
        case RangeType.GreaterOrEqual:
          sbCmd.Append(">=" + itemId.ToString() + " order by ["+itemIdColumn+"] asc");
          break;
        case RangeType.Less:
          sbCmd.Append("<" + itemId.ToString() + " order by ["+itemIdColumn+"] desc");
          break;
        case RangeType.LessOrEqual:
          sbCmd.Append("<=" + itemId.ToString() + " order by ["+itemIdColumn+"] desc");
          break;
      }
      cmd.CommandText = sbCmd.ToString();
      return ExecuteAndFetchItems(cmd, length);
    }

    /// <summary>
    /// Loads a range of items from the collection.
    /// This method should always place serializable level locks.
    /// </summary>
    /// <param name="table">Table where collection data is stored.</param>
    /// <param name="ownerIdColumn">Column with the container IDs.</param>
    /// <param name="itemIdColumn">Column with the item IDs.</param>
    /// <param name="ownerIDs">An <see cref="Array"/> containing IDs of the container objects.</param>
    /// <param name="columns">Names of the additional columns to fetch.</param>
    /// <returns><see cref="ArrayList"/> of <see cref="IDictionary"/>s.</returns>
    public override ArrayList LoadRange(ISchemaNode table, string ownerIdColumn, string itemIdColumn, long[] ownerIDs, ArrayList columns) 
    {
      sbCmd.Length = 0;
      sbCmd.Append("Select ");
      string sKeyColumns = "["+ownerIdColumn+"], ["+itemIdColumn+"]";
      sbCmd.Append(sKeyColumns);
      int cnt = columns!=null ? columns.Count : 0;
      for (int i = 0; i<cnt; i++)
        sbCmd.Append(", ["+(columns[i] as string)+"]");
      sbCmd.Append(" from "+table.FullQuotedName+" where ["+ownerIdColumn+"] in (");
      for (int i = 0, idCnt = ownerIDs.Length; i<idCnt; i++) {
        if (ownerIDs[i]==0)
          break;
        if (i!=0) 
          sbCmd.Append(", ");
        sbCmd.Append(ownerIDs[i].ToString());
      }
      sbCmd.Append(") order by "+sKeyColumns);

      EnsureCommandValid(cmd);
      cmd.Parameters.Clear();
      cmd.CommandText = sbCmd.ToString();

      return ExecuteAndFetchItems(cmd, 0);
    }

    /// <summary>
    /// Loads a range of items from the collection.
    /// This method should always place serializable level locks.
    /// </summary>
    /// <param name="table">Table where collection data is stored.</param>
    /// <param name="ownerColumn">Column with the container IDs.</param>
    /// <param name="ownerId">ID of the container.</param>
    /// <param name="searchCriteria">Pairs of columns and their values to search by.</param>
    /// <param name="columns">Names of the columns to fetch.</param>
    /// <returns><see cref="ArrayList"/> of <see cref="IDictionary"/>s.</returns>
    public override ArrayList LoadRange(ISchemaNode table, string ownerColumn, long ownerId, ArrayList searchCriteria, ArrayList columns)
    {
      if (searchCriteria==null)
        throw new ArgumentNullException("searchCriteria");
      if (searchCriteria==null)
        throw new ArgumentNullException("columns");

      EnsureCommandValid(cmd);
      cmd.Parameters.Clear();

      sbCmd.Length = 0;
      sbCmd.Append("Select ");
      for (int i = 0, cnt=columns.Count; i<cnt; i++)
        sbCmd.Append("["+(columns[i] as string)+"],");
      sbCmd.Length=sbCmd.Length-1;
      sbCmd.Append(" from " + table.FullQuotedName);
      sbCmd.Append(" where [" + ownerColumn + "]=" + ownerId.ToString());
      for (int i = 0, cnt=searchCriteria.Count; i<cnt; i++) {
        sbCmd.Append(" and");
        ColumnValue cv = (ColumnValue)searchCriteria[i];
        object cValue = cv.Value;
        if (cValue!=null) {
          string PName = "@P"+i.ToString();
          sbCmd.Append(" ["+cv.Column.Name+"]="+PName);
          OleDbParameter p = new OleDbParameter(PName, cValue);
          p.DbType = utils.GetDbType(cv.Column.SqlType);
          cmd.Parameters.Add(p);
        }
        else
          sbCmd.Append(" ["+cv.Column.Name+"] is null");
      }
      cmd.CommandText = sbCmd.ToString();

      return ExecuteAndFetchItems(cmd, 0);
    }

    /// <summary>
    /// Clears the collection.
    /// This method should always place serializable level locks.
    /// </summary>
    /// <param name="table">Table where collection data is stored.</param>
    /// <param name="ownerIdColumn">Column with the container IDs.</param>
    /// <param name="ownerId">ID of the container.</param>
    public override void Clear(ISchemaNode table, string ownerIdColumn, long ownerId)
    {
      Persister.FlushDelayedSavepoints();

      EnsureCommandValid(cmd);
      cmd.Parameters.Clear();
      cmd.CommandText = 
        "Delete from "+table.FullQuotedName+" where ["+ownerIdColumn+"]=" + ownerId.ToString();
      ((MSAccessDriver)Driver).LogSqlCommand( "MSAccessPersisterForCollections.Clear", cmd );
      cmd.ExecuteNonQuery();
    }

    /// <summary>
    /// Adds a new item into the collection.
    /// </summary>
    /// <param name="table">Table where collection data is stored.</param>
    /// <param name="ownerIdColumn">Column with the container IDs.</param>
    /// <param name="itemIdColumn">Column with the item IDs.</param>
    /// <param name="ownerId">ID of the container.</param>
    /// <param name="itemId">ID of the new item.</param>
    /// <param name="columnValues">A list of additional <see cref="ColumnValue"/>s to add.</param>
    public override void Add(ISchemaNode table, string ownerIdColumn, string itemIdColumn, long ownerId, long itemId, ArrayList columnValues)
    {
      Persister.FlushDelayedSavepoints();

      EnsureCommandValid(cmd);
      cmd.Parameters.Clear();
      sbCmd.Length = 0;
      sbCmd.Append("Insert into "+table.FullQuotedName+" (["+ownerIdColumn+"], ["+itemIdColumn+"]");
      int cnt = columnValues!=null ? columnValues.Count : 0;
      for (int i = 0; i<cnt; i++)
        sbCmd.Append(", ["+(columnValues[i] as ColumnValue).Column.Name+"]");
      sbCmd.Append(") values (" + ownerId.ToString() + ", " + itemId.ToString() );
      for (int i = 0; i<cnt; i++) 
      {
        ColumnValue cv = (ColumnValue)columnValues[i];
        string PName = "@P"+i.ToString();
        sbCmd.Append(", "+PName);
        OleDbParameter p = new OleDbParameter(PName, cv.Value);
        p.DbType = utils.GetDbType(cv.Column.SqlType);
        cmd.Parameters.Add(p);
      }
      sbCmd.Append(")");

      cmd.CommandText = sbCmd.ToString();
      ((MSAccessDriver)Driver).LogSqlCommand( "MSAccessPersisterForCollections.Add", cmd );
      int rowcount = cmd.ExecuteNonQuery();
      if (rowcount!=1)
        throw new PersisterException("Specified item is already added by another transaction.");
    }

    /// <summary>
    /// Adds a new item into the collection.
    /// </summary>
    /// <param name="table">Table where collection data is stored.</param>
    /// <param name="ownerIdColumn">Column with the container IDs.</param>
    /// <param name="itemIdColumn">Column with the item IDs.</param>
    /// <param name="ownerId">ID of the container.</param>
    /// <param name="columnValues">A list of additional <see cref="ColumnValue"/>s to add.</param>
    /// <returns>ID (key) of newly created item.</returns>
    public override long Add(ISchemaNode table, string ownerIdColumn, string itemIdColumn, long ownerId, ArrayList columnValues)
    {
      Persister.FlushDelayedSavepoints();

      EnsureCommandValid(cmd);
      cmd.Parameters.Clear();
      sbCmd.Length = 0;
      sbCmd.Append("Insert into "+table.FullQuotedName+" (["+ownerIdColumn+"]");
      int cnt = columnValues!=null ? columnValues.Count : 0;
      for (int i = 0; i<cnt; i++)
        sbCmd.Append(", ["+(columnValues[i] as ColumnValue).Column.Name+"]");
      sbCmd.Append(") values (" + ownerId.ToString() );
      for (int i = 0; i<cnt; i++) {
        ColumnValue cv = (ColumnValue)columnValues[i];
        string PName = "@P"+i.ToString();
        sbCmd.Append(", "+PName);
        object value = cv.Value;
        if (value.GetType() == typeof(DateTime)) 
          value = ((DateTime)value).ToOADate(); 
        OleDbParameter p = new OleDbParameter(PName, value);
        p.DbType = utils.GetDbType(cv.Column.SqlType);
        cmd.Parameters.Add(p);
      }
      sbCmd.Append(")");

      cmd.CommandText = sbCmd.ToString();
      ((MSAccessDriver)Driver).LogSqlCommand( "MSAccessPersisterForCollections.Add", cmd );
      cmd.ExecuteNonQuery();
      cmd.CommandText = "Select @@IDENTITY";
      ((MSAccessDriver)Driver).LogSqlCommand( "MSAccessPersisterForCollections.Add", cmd );
      long key = Convert.ToInt32(cmd.ExecuteScalar());
      if (key==0)
        throw new PersisterException("Error on fetching item key (identity column).");
      return key;
    }

    /// <summary>
    /// Adds a new item into the collection.
    /// </summary>
    /// <param name="table">Table where collection data is stored.</param>
    /// <param name="itemIdColumn">Column with the item IDs.</param>
    /// <param name="columnValues">A list of <see cref="ColumnValue"/>s to add.</param>
    /// <returns>ID (key) of newly created item.</returns>
    public override long Add(ISchemaNode table, string itemIdColumn, ArrayList columnValues)
    {
      int cnt = columnValues!=null ? columnValues.Count : 0;
      if (cnt==0)
        throw new DataObjectsDotNetException(
          "Internal error: Column values list is empty.");

      Persister.FlushDelayedSavepoints();
      EnsureCommandValid(cmd);
      cmd.Parameters.Clear();
      sbCmd.Length = 0;
      sbCmd.Append("Insert into "+table.FullQuotedName+" (");
      sbCmd.Append("["+(columnValues[0] as ColumnValue).Column.Name+"]");
      for (int i = 1; i<cnt; i++)
        sbCmd.Append(", ["+(columnValues[i] as ColumnValue).Column.Name+"]");

      sbCmd.Append(") values (@P0");
      ColumnValue cv = (ColumnValue)columnValues[0];
      OleDbParameter p = new OleDbParameter("@P0", cv.Value);
      p.DbType = utils.GetDbType(cv.Column.SqlType);
      cmd.Parameters.Add(p);
      for (int i = 1; i<cnt; i++) {
        cv = (ColumnValue)columnValues[i];
        string PName = "@P"+i.ToString();
        sbCmd.Append(", "+PName);
        p = new OleDbParameter(PName, cv.Value);
        p.DbType = utils.GetDbType(cv.Column.SqlType);
        cmd.Parameters.Add(p);
      }
      sbCmd.Append(")");

      cmd.CommandText = sbCmd.ToString();
      ((MSAccessDriver)Driver).LogSqlCommand( "MSAccessPersisterForCollections.Add", cmd );
      cmd.ExecuteNonQuery();
      cmd.CommandText = "Select @@IDENTITY";
      ((MSAccessDriver)Driver).LogSqlCommand( "MSAccessPersisterForCollections.Add", cmd );
      long key = Convert.ToInt32(cmd.ExecuteScalar());
      if (key==0)
        throw new PersisterException("Error on fetching item key (identity column).");
      return key;
    }

    /// <summary>
    /// Changes the item in the collection.
    /// </summary>
    /// <param name="table">Table where collection data is stored.</param>
    /// <param name="ownerIdColumn">Column with the container IDs.</param>
    /// <param name="itemIdColumn">Column with the item IDs.</param>
    /// <param name="ownerId">ID of the container.</param>
    /// <param name="itemId">ID of the item.</param>
    /// <param name="columnValues">A list of <see cref="ColumnValue"/>s to update.</param>
    public override void Set(ISchemaNode table, string ownerIdColumn, string itemIdColumn, long ownerId, long itemId, ArrayList columnValues)
    {
      Persister.FlushDelayedSavepoints();

      EnsureCommandValid(cmd);
      cmd.Parameters.Clear();
      sbCmd.Length = 0;
      sbCmd.Append("Update "+table.FullQuotedName+" set ");
      int cnt = columnValues.Count;
      for (int i = 0; i<cnt; i++) 
      {
        if (i>0)
          sbCmd.Append(", ");
        ColumnValue cv = (ColumnValue)columnValues[i];
        string PName = "@P"+i.ToString();
        sbCmd.Append("["+cv.Column.Name+"]="+PName);
        OleDbParameter p = new OleDbParameter(PName, cv.Value);
        p.DbType = utils.GetDbType(cv.Column.SqlType);
        cmd.Parameters.Add(p);
      }
      sbCmd.Append(
        " where ["+ownerIdColumn+"]=" + ownerId.ToString() + " and ["+itemIdColumn+"]=" + itemId.ToString() );        
      
      cmd.CommandText = sbCmd.ToString();        
      ((MSAccessDriver)Driver).LogSqlCommand( "MSAccessPersisterForCollections.Set", cmd );
      int rowcount = cmd.ExecuteNonQuery();
      if (rowcount!=1)
        throw new PersisterException("Item is already removed by another transaction.");
    }

    /// <summary>
    /// Removes the item from the collection.
    /// </summary>
    /// <param name="table">Table where collection data is stored.</param>
    /// <param name="ownerIdColumn">Column with the container IDs.</param>
    /// <param name="itemIdColumn">Column with the item IDs.</param>
    /// <param name="ownerId">ID of the container.</param>
    /// <param name="itemId">ID of the item.</param>
    public override void Remove(ISchemaNode table, string ownerIdColumn, string itemIdColumn, long ownerId, long itemId)
    {
      Persister.FlushDelayedSavepoints();

      EnsureCommandValid(cmd);
      cmd.Parameters.Clear();
      cmd.CommandText = 
        "Delete from "+table.FullQuotedName+" where ["+ownerIdColumn+"]=" + ownerId.ToString() + " and ["+itemIdColumn+"]=" + itemId.ToString();

      ((MSAccessDriver)Driver).LogSqlCommand( "MSAccessPersisterForCollections.Remove", cmd );
      int rowcount = cmd.ExecuteNonQuery();
      if (rowcount!=1)
        throw new PersisterException("Item is already removed by another transaction.");
    }

    /// <summary>
    /// Builds <see cref="Query"/> command.
    /// </summary>
    /// <param name="forSubQuery">Indicates whether to preparing a command for subquery.</param>
    /// <param name="idOnly">Indicates whether to include only IDs.</param>
    /// <param name="table">Table where collection data is stored.</param>
    /// <param name="aliasName">View alias name.</param>
    /// <param name="ownerIdColumn">Column with the container IDs.</param>
    /// <param name="itemIdColumn">Column with the item IDs.</param>
    /// <param name="options">Query options.</param>
    /// <param name="top">Number of rows to fetch, 0 means all.</param>
    /// <param name="sqlJoin">Join expression.</param>
    /// <param name="sqlCondition">Condition.</param>
    /// <param name="ftsCondition">Full-text search condition.</param>
    /// <param name="sqlRestriction">Additional restriction.</param>
    /// <param name="sqlOrderBy">Order by expression.</param>
    /// <param name="columns">Names of the additional columns to fetch.</param>
    /// <param name="isDistinct"><see langword="True"/> if a <see cref="QueryOptions.Distinct"/>
    /// was applied; otherwise, <see langword="false"/>.</param>
    public override string BuildQueryCommandText(
      bool forSubQuery, 
      bool idOnly,
      ISchemaNode table,
      string aliasName,
      string ownerIdColumn,
      string itemIdColumn,
      QueryOptions options, 
      long top, 
      string sqlJoin, 
      string sqlCondition, 
      FtsCondition ftsCondition,
      string sqlRestriction, 
      string sqlOrderBy,
      ArrayList columns,
      ref bool isDistinct
      )
    {
      if (ftsCondition!=null)
        throw new InvalidSqlException(
          "Full-text search condition can't be used with QueryResultType.Values option.");
          
      string fullAliasName = "["+aliasName+"]";

      bool bDistinct  = (options & QueryOptions.Distinct)!=0;
      bool bCount     = (options & QueryOptions.Count)!=0;
      bool bLOD       = (options & QueryOptions.LoadOnDemand)!=0;
      bool bOrdered   = sqlOrderBy!="" && !bCount;
      isDistinct      = bDistinct && (bCount || (bLOD && !bOrdered));
      string sFullId  = fullAliasName+".["+itemIdColumn+"]";
      string sFullKey = fullAliasName+".["+ownerIdColumn+"], "+
                        sFullId;

      string sFieldList;
      if (bCount) {
        if (isDistinct)
          sFieldList = "count(distinct *)";
        else
          sFieldList = "count(*)";
      } else if (idOnly) {
        if (isDistinct)
          sFieldList = "distinct "+sFullId;
        else
          sFieldList = sFullId;
      } else {
        sFieldList = sFullKey;
        if (!isDistinct && !bLOD && columns!=null && columns.Count>0) {
          int cnt = columns.Count;
          for (int i = 0; i<cnt; i++)
            sFieldList += ", "+fullAliasName+".["+(columns[i] as string)+"]";
        }
      }
      
      sbCmd.Length = 0;
      sbCmd.Append("Select ");
      if (isDistinct && !bCount) 
        sbCmd.Append("distinct ");
      if (top > 0)
        sbCmd.Append("top "+top.ToString()+" ");
      sbCmd.Append(sFieldList+" from "+table.FullQuotedName+" "+fullAliasName);
      sbCmd.Append(MSAccessPersister.TranslateQueryOptionsToHints(options));
      if (sqlJoin!="")  
        sbCmd.Append("\n  "+sqlJoin);
      
      if (sqlCondition!="") {
        if (sqlRestriction!="")
          sbCmd.Append("\nwhere ("+sqlCondition+") and ("+sqlRestriction+")");
        else
          sbCmd.Append("\nwhere ("+sqlCondition+")");
      }
      else {
        if (sqlRestriction!="")
          sbCmd.Append("\nwhere ("+sqlRestriction+")");
      }

      if (sqlOrderBy!="" && ((options & QueryOptions.Count)==0))
        sbCmd.Append("\norder by "+sqlOrderBy);

      return sbCmd.ToString();
    }

    /// <summary>
    /// Executes the command and fetches selected items.
    /// </summary>
    /// <param name="command">Command to execute.</param>
    /// <param name="top">Number of rows to fetch, 0 means all.</param>
    /// <returns><see cref="ArrayList"/> of <see cref="IDictionary"/>s or IDs (if only).</returns>
    public override ArrayList ExecuteAndFetchItems(IDbCommand command, long top)
    {
      ArrayList list = new ArrayList();

      EnsureCommandValid(cmd);
      ((MSAccessDriver)Driver).LogSqlCommand( "MSAccessPersisterForCollections.ExecuteAndFetchItems", cmd );
      using (IDataReader r = command.ExecuteReader()) {
        if (top==0) {
          while (r.Read()) {
            int FieldCount = r.FieldCount;
            if (FieldCount > 1) {
              HybridDictionary d = new HybridDictionary(FieldCount);
              for (int i = 0; i < FieldCount; i++)
                d.Add(r.GetName(i),r.GetValue(i));
              list.Add(d);
            }
            else
              list.Add(r[0]);
          }
        }
        else {
          while (r.Read() && (top--)>0) {
            int FieldCount = r.FieldCount;
            if (FieldCount > 1) {
              HybridDictionary d = new HybridDictionary(FieldCount);
              for (int i = 0; i < FieldCount; i++)
                d.Add(r.GetName(i),r.GetValue(i));
              list.Add(d);
            }
            else
              list.Add(r[0]);
          }
        }
        r.NextResult(); // Bug workaround. 
        // Read ms-help://MS.MSDNQTR.2003APR.1033/enu_kbwebdatanetkb/webdatanetkb/316667.htm
        r.Close();
      }
      return list;
    }

    /// <summary>
    /// Executes the command.
    /// </summary>
    /// <param name="command">Command to execute.</param>
    /// <returns><see cref="IDataReader"/> containing result set.</returns>
    public override IDataReader ExecuteReader(IDbCommand command)
    {
      ((MSAccessDriver)Driver).LogSqlCommand( "MSAccessPersisterForCollections.ExecuteReader", command as OleDbCommand );
      return command.ExecuteReader();
    }

    /// <summary>
    /// Executes the command.
    /// </summary>
    /// <param name="command">Command to execute.</param>
    /// <returns>Execution result.</returns>
    public override object ExecuteScalar(IDbCommand command)
    {
      ((MSAccessDriver)Driver).LogSqlCommand( "MSAccessPersisterForCollections.ExecuteScalar", command as OleDbCommand );
      return command.ExecuteScalar();
    }

    /// <summary>
    /// Executes the command.
    /// </summary>
    /// <param name="command">Command to execute.</param>
    public override void ExecuteNonQuery(IDbCommand command)
    {
      ((MSAccessDriver)Driver).LogSqlCommand( "MSAccessPersisterForCollections.ExecuteNonQuery", command as OleDbCommand );
      command.ExecuteNonQuery();
    }
    
    
    // Constructor

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="persister"><see cref="Persister"/> to which this instance belongs.</param>
    public MSAccessPersisterForCollections(Persister persister): base(persister)
    {
      cmd = (OleDbCommand)Driver.CreateCommand(Connection);
      utils = Driver.Utils;
    }
  }
}
