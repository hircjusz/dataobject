// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using DataObjects.NET.Attributes;

namespace DataObjects.NET
{
  /// <summary>
  /// Allows to validate <see cref="DataObject"/> property value 
  /// before it is actually set by 
  /// <see cref="DataObject.SetProperty">DataObject.SetProperty</see>
  /// method. The behaviour is almost the same as for 
  /// <see cref="IPropertyValueValidator"/> interface but in addition
  /// it is possible to force permission checkind during validation.
  /// <seealso cref="ValidatorAttribute"/>
  /// <seealso cref="IPropertyValueValidator"/>
  /// </summary>
  public interface IPropertyValueSecureValidator : IPropertyValueValidator 
  {
    /// <summary>
    /// Indicates whether sequrity checks is disabled for the validator.
    /// </summary>
    bool DisableSecurity { get; set;}
  }
}
