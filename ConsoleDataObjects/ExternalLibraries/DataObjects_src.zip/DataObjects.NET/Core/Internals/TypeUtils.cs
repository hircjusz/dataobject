// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.ComponentModel;

namespace DataObjects.NET.Internals
{
  internal class TypeUtils
  {
    public static Type FindCommonAncestor(Type[] types)
    {
      Type commonAncestor = null;
      for (int typeIndex=0, typeCount=types.Length; typeIndex<typeCount && commonAncestor!=typeof(Object); typeIndex++) {
        if (commonAncestor==null)
          commonAncestor = types[typeIndex];
        else {
          Type type = types[typeIndex];
          if (!commonAncestor.IsAssignableFrom(type)) {
            while (type!=null && type!=typeof(Object)) {
              if (type.IsAssignableFrom(commonAncestor)) {
                commonAncestor = type;
                break;
              }
              type = type.BaseType;
            }
          }
        }
      }
      return commonAncestor==null ? typeof(Object) : commonAncestor;
    }
    
    public static object ConvertValueToType (object value, Type type)
    {
      if (value==null) {
        if (type.IsValueType)
          throw new InvalidCastException(
            String.Format("Can't convert value to the \"{0}\" type.", type.FullName));
        else 
          return null;
      }
      try {
        IConvertible convertibleValue = value as IConvertible;
        if (convertibleValue!=null)
          value = Convert.ChangeType(value, type);
        else
          throw new InvalidCastException(
            String.Format("Can't convert value to the \"{0}\" type.", type.FullName));
      }
      catch (InvalidCastException) {
        TypeConverter valueConverter = TypeDescriptor.GetConverter(value);
        TypeConverter targetConverter = TypeDescriptor.GetConverter(value);
        if (valueConverter!=null && valueConverter.CanConvertTo(type))
          value = valueConverter.ConvertTo(value, type);
        else if (targetConverter!=null && targetConverter.CanConvertFrom(value.GetType()))
          value = targetConverter.ConvertFrom(value);
        else
          throw;
      }
      return value;
    }
    
  }
}
