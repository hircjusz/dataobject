// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using DataObjects.NET.DatabaseModel;

namespace DataObjects.NET.Database
{
  /// <summary>
  /// Represents <see cref="Column"/>-<see cref="Value"/> pair.
  /// Used in update\insert statements.
  /// </summary>
  public class ColumnValue
  {
    /// <summary>
    /// <see cref="DataObjects.NET.DatabaseModel.Column"/> to update.
    /// </summary>
    public Column Column;
    /// <summary>
    /// New value to insert or set in <see cref="Column"/>.
    /// </summary>
    public object Value;
    
    
    // Constructors

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    public ColumnValue(Column column, object value)
    {
      Column = column;
      Value  = value;
    }
  }
}
