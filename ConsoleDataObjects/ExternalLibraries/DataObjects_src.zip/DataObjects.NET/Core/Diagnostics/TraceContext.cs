// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Diagnostics;
using DataObjects.NET;

namespace DataObjects.NET.Diagnostics
{
  /// <summary>
  /// Provides additional information about traced event.
  /// </summary>
  public class TraceContext
  {
    private Session session;
    private StackTrace stackTrace;
    private string category;
    private string message;
    
    /// <summary>
    /// Gets trace event session.
    /// </summary>
    public Session Session {
      get {
        return session;
      }
    }
    
    /// <summary>
    /// Gets trace event stack trace.
    /// </summary>
    public StackTrace StackTrace {
      get {
        return stackTrace;
      }
    }
    
    /// <summary>
    /// Gets trace event category.
    /// </summary>
    public string Category {
      get {
        return category;
      }
    }
    
    /// <summary>
    /// Gets trace event message.
    /// </summary>
    public string Message {
      get {
        return message;
      }
    }
    
    // Constructors
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="session">Trace event session.</param>
    /// <param name="stackTrace">Trace event stack trace.</param>
    /// <param name="category">Trace event category.</param>
    /// <param name="message">Trace event message.</param>
    public TraceContext(Session session, StackTrace stackTrace, string category, string message)
    {
      this.session = session;
      this.stackTrace = stackTrace;
      this.category = category;
      this.message = message;
    }
  }
}
