// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE (*).
// All rights reserved.
// For conditions of distribution and use, see license.
// (*) Parts of this file were contributed by 
//     Horst Veith (horst.veith@intercom.at).

using System;
using System.Text.RegularExpressions;
using DataObjects.NET;
using DataObjects.NET.Attributes;
using Offline=DataObjects.NET.Offline;

namespace DataObjects.NET.Helpers
{
  /// <summary>
  /// A <see cref="IPropertyValueValidator">validator</see> that
  /// checks if property value matches specified regular expression; 
  /// throws <see cref="ArgumentOutOfRangeException"/> if this condition
  /// is violated.
  /// <seealso cref="ValidatorAttribute"/>
  /// </summary>
  /// <remarks>
  /// <example>Example:
  /// <code lang="C#">
  /// [Validator(typeof(MatchesRegex), MatchesRegex.EmailRegex)]
  ///  public abstract string Email { get; set; }
  /// </code>
  /// </example>
  /// See <see cref="ValidatorAttribute"/> also.
  /// </remarks>
  [Serializable]
  public class MatchesRegex : IPropertyValueValidator, Offline.IPropertyValueValidator
  {
    /// <summary>
    /// Regular expression that matches any <see cref="Decimal"/> number: ^([+-]{0,1}[\d].{0,1}[\d]+)*$
    /// </summary>
    public const string NumberRegex = @"^([+-]{0,1}[\d].{0,1}[\d]+)*$";
    /// <summary>
    /// Regular expression that matches any floating point number: ^[-+]?([0-9]+\.?[0-9]*|\.[0-9]+)([eE][-+]?[0-9]+)?$
    /// </summary>
    public const string FloatingPointNumberRegex = @"^[-+]?([0-9]+\.?[0-9]*|\.[0-9]+)([eE][-+]?[0-9]+)?$";
    /// <summary>
    /// Regular expression that matches any <see cref="Guid"/>: ^[-+]?([0-9]+\.?[0-9]*|\.[0-9]+)([eE][-+]?[0-9]+)?$
    /// </summary>
    public const string GuidRegex = @"^[a-fA-F0-9]{8}[-][a-fA-F0-9]{4}[-][a-fA-F0-9]{4}[-][a-fA-F0-9]{4}[-][a-fA-F0-9]{12}$";

    /// <summary>
    /// Regular expression that matches any internet IP address: ^((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$
    /// </summary>
    public const string IpAddressRegex = @"^((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$";
    /// <summary>
    /// Regular expression that matches any internet domain name: ^[a-zA-Z]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.[a-zA-Z]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(\.[a-zA-Z]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)?$
    /// </summary>
    public const string InternetDomainNameRegex = @"^[a-zA-Z]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.[a-zA-Z]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(\.[a-zA-Z]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)?$";
    /// <summary>
    /// Regular expression that matches any e-mail address: ^([a-zA-Z0-9_\-])([a-zA-Z0-9_\-\.]*)@(\[((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}|((([a-zA-Z0-9\-]+)\.)+))([a-zA-Z]{2,}|(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\])$
    /// </summary>
    public const string EmailRegex = @"^([a-zA-Z0-9_\-])([a-zA-Z0-9_\-\.]*)@(\[((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}|((([a-zA-Z0-9\-]+)\.)+))([a-zA-Z]{2,}|(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\])$";
    /// <summary>
    /// Regular expression that matches any e-mail address (just checks its RFC conformance): ^[A-Za-z0-9._-]+@[[A-Za-z0-9.-]+$
    /// </summary>
    public const string EmailByRfcRegex = @"^[A-Za-z0-9._-]+@[[A-Za-z0-9.-]+$";
    
    /// <summary>
    /// Regular expression that matches any international phone number: ^\d(\d|-){7,20}$
    /// </summary>
    public const string InternationalPhoneNumberRegex = @"^\d(\d|-){7,20}$";
    /// <summary>
    /// Regular expression that matches any credit card number: ^\d{4}((-\d{4}){3}$)|((\d{4}){3}$)
    /// </summary>
    public const string CreditCardNumberRegex = @"^\d{4}((-\d{4}){3}$)|((\d{4}){3}$)";

    /// <summary>
    /// Regular expression that matches any Zip code: ^\d{5}(-?\d{4})?$
    /// </summary>
    public const string ZipCodeRegex = @"^\d{5}(-?\d{4})?$";
    /// <summary>
    /// Regular expression that matches any US social security number: ^[\d{3}-\d{2}-\d{4}$
    /// </summary>
    public const string SocialSecurityNumberRegex = @"^[\d{3}-\d{2}-\d{4}$";
    /// <summary>
    /// Regular expression that matches any US phone number: ^1?\s*-?\s*(\d{3}|\(\s*\d{3}\s*\))\s*-?\s*\d{3}\s*-?\s*\d{4}$
    /// </summary>
    public const string UsaPhoneNumberRegex = @"^1?\s*-?\s*(\d{3}|\(\s*\d{3}\s*\))\s*-?\s*\d{3}\s*-?\s*\d{4}$";

    private string       expression;
    private RegexOptions options;

    /// <summary>
    /// Gets regular expression used by this validator.
    /// </summary>
    public string Expression {
      get { return expression; }
    }

    /// <summary>
    /// Gets regular expression options used by this validator.
    /// Default value is <see cref="RegexOptions.Singleline"/>.
    /// </summary>
    public RegexOptions Options {
      get { return options; }
    }

    /// <summary>
    /// Validates <see cref="DataObject"/> property value 
    /// before it is actually set by 
    /// <see cref="DataObject.SetProperty">DataObject.SetProperty</see>
    /// method.
    /// </summary>
    /// <param name="dataObject"><see cref="DataObject"/> instance
    /// which property is to be changed.</param>
    /// <param name="propertyName">Property name.</param>
    /// <param name="culture">Property culture.</param>
    /// <param name="value">Value to validate.</param>
    /// <remarks>
    /// Checks if property value matches the specified regular <see cref="Expression">expression</see>; 
    /// throws <see cref="ArgumentOutOfRangeException"/> if this condition
    /// is violated.
    /// </remarks>
    public void Validate(DataObject dataObject, string propertyName, Culture culture, object value)
    {
      Validate(propertyName, value);
    }

    /// <summary>
    /// Validates <see cref="DataObject"/> property value 
    /// before it is actually set by 
    /// <see cref="DataObject.SetProperty">DataObject.SetProperty</see>
    /// method.
    /// </summary>
    /// <param name="dataObject"><see cref="Offline.DataObject"/> instance
    /// which property is to be changed.</param>
    /// <param name="propertyName">Property name.</param>
    /// <param name="culture">Property culture.</param>
    /// <param name="value">Value to validate.</param>
    /// <remarks>
    /// Checks if property value matches the specified regular <see cref="Expression">expression</see>; 
    /// throws <see cref="ArgumentOutOfRangeException"/> if this condition
    /// is violated.
    /// </remarks>
    public void Validate(Offline.DataObject dataObject, string propertyName, Offline.Culture culture, object value)
    {
      Validate(propertyName, value);
    }
    
    private void Validate (string propertyName, object value)
    {
      if (value==null || !(value is string)) return;
      if (!Regex.IsMatch((string)value, expression, options))
        throw new ArgumentOutOfRangeException(propertyName, String.Format(
          "Value of property \"{0}\" doesn't match regular expression \"{1}\".", 
          propertyName, expression));
    }

    /// <summary>
    /// Attaches a validator instance to a certain field.
    /// </summary>
    /// <param name="field">A <see cref="ObjectModel.Field"/> the validator is related to.</param>
    public void AttachToField (ObjectModel.Field field)
    {
      // Does nothing
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="expression">Intial <see cref="Expression"/> value.</param>
    public MatchesRegex(string expression) : this(expression, RegexOptions.Singleline)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="expression">Intial <see cref="Expression"/> value.</param>
    /// <param name="options">Intial <see cref="Options"/> value.</param>
    public MatchesRegex(string expression, RegexOptions options)
    {
      this.expression = expression;
      this.options    = options;
    }
  }
}
