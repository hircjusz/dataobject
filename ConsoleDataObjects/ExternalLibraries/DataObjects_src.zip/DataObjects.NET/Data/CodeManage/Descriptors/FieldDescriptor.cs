// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;
using System.Reflection;
#if !MONO
using EnvDTE;
#endif

namespace DataObjects.NET.Data.CodeManage
{
  /// <summary>
  /// Describes a field.
  /// </summary>
  internal class FieldDescriptor: IFieldDescriptor, ICloneable
  {
    private CodeManagerBase codeManager;
    private string name;
    private string dbName;
    private IElementDescriptor parent;
    private IFieldDescriptor[] fields;
    
    /// <summary>
    /// Code manager.
    /// </summary>
    public CodeManagerBase CodeManager {
      get {
        return codeManager;
      }
    }
  
    /// <summary>
    /// Gets parent element.
    /// </summary>
    public IElementDescriptor Parent {
      get {
        return parent;
      }
    }

    /// <summary>
    /// Gets child field.
    /// </summary>
    public IFieldDescriptor[] Fields {
      get {
        return fields;
      }
    }

    /// <summary>
    /// Gets field name.
    /// </summary>
    public string Name {
      get {
        return name;
      }
    }

    /// <summary>
    /// Gets field full name.
    /// </summary>
    public string FullName {
      get {
        return parent.FullName + "." + name;
      }
    }
    
    /// <summary>
    /// Element database name.
    /// </summary>
    /// <remarks>May be null.</remarks>
    public string DbName {
      get {
        return dbName;
      }
    }
    
    /// <summary>
    /// Creates a new object that is a copy of the current instance.
    /// </summary>
    /// <returns>A new object that is a copy of this instance.</returns>
    object ICloneable.Clone()
    {
      FieldDescriptor clone = new FieldDescriptor();
      clone.codeManager = codeManager;
      clone.parent = parent;
      clone.name = name;
      clone.dbName = dbName;
      clone.fields = new IFieldDescriptor[fields.Length];
      for (int i = 0; i < fields.Length; i++) {
        FieldDescriptor childField = (FieldDescriptor)((ICloneable)fields[i]).Clone();
        childField.SetParentFromContainer(clone);
        clone.fields[i] = childField;
      }
      return clone;
    }
    
    /// <summary>
    /// Sets parent element.
    /// </summary>
    /// <param name="parent"><see cref="IElementDescriptor"/> of a parent element.</param>
    internal void SetParentFromContainer(IElementDescriptor parent)
    {
      this.parent = parent;
    }
    
    private FieldDescriptor()
    {
    }
    
    /// <summary>
    /// Initializes a new instance of the <see cref="FieldDescriptor"/> class.
    /// </summary>
    /// <param name="parent">Field's parent element. Value can be null.</param>
    /// <param name="mInfo"><see cref="MemberInfo"/>.</param>
    internal FieldDescriptor(IElementDescriptor parent, MemberInfo mInfo)
    {
      if (mInfo==null)
        throw new ArgumentNullException("mInfo");
    
      if (parent!=null) {
        codeManager = parent.CodeManager;
        this.parent = parent;
      }
      
      this.name = mInfo.Name;
      object[] attrs = mInfo.GetCustomAttributes(typeof(Attributes.DbNameAttribute), true);
      if (attrs!=null && attrs.Length>0) {
        this.dbName = ((Attributes.DbNameAttribute)attrs[0]).DbName;
      }
        
      Type fieldType = null;
      if (mInfo.MemberType==MemberTypes.Field)
        fieldType = ((FieldInfo)mInfo).FieldType;
      else if (mInfo.MemberType==MemberTypes.Property)
        fieldType = ((PropertyInfo)mInfo).PropertyType;

      ArrayList fieldsList = new ArrayList();
      if (fieldType!=null) {
        int depth = 0;
        // let's check the "field depth" ("A.B.C.D.E ...") for non-valuetype fields.
        if (!fieldType.IsValueType) {
          FieldDescriptor parentField = parent as FieldDescriptor;
          while (parentField!=null) {
            depth++;
            parentField = parentField.Parent as FieldDescriptor;
          }
        }
        if (depth<5) {
          FieldInfo[] childFields = fieldType.GetFields(BindingFlags.Public | BindingFlags.Instance);
          foreach (FieldInfo field in childFields) {
            fieldsList.Add(new FieldDescriptor(this, field));
          }
        }
      }
      fields = (IFieldDescriptor[])fieldsList.ToArray(typeof(IFieldDescriptor));
    }
    
    #if !MONO 
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="name">Field name.</param>
    /// <param name="parent">Field's parent element. Value can be null.</param>
    /// <param name="codeType"><see cref="CodeType"/>. Value can be null.</param>
    /// <param name="attributes"><see cref="CodeElements"/>. Value can be null.</param>
    internal FieldDescriptor(string name, IElementDescriptor parent, CodeType codeType, CodeElements attributes)
    {
      if (name==null)
        throw new ArgumentNullException("name");
    
      if (parent!=null) {
        this.codeManager = codeManager;
        this.parent = parent;
      }
      this.name = name;
      
      if (attributes!=null){
        int attributesCount = 0;
        try {
          attributesCount = attributes.Count;
        } catch {};
        for (int i = 0; i < attributesCount; i++) {
          CodeElement attrElement = attributes.Item(i + 1);
          if (attrElement.Kind==vsCMElement.vsCMElementAttribute) {
            CodeAttribute attr = (CodeAttribute)attrElement;
            if (attr.FullName=="DataObjects.NET.Attributes.DbNameAttribute") {
              string val = attr.Value;
              if (val.StartsWith("\"") && val.EndsWith("\"")) {
                dbName = val.Substring(1, val.Length - 2);
                break;
              }
            }
          }
        }
      }
      
      ArrayList fieldsList = new ArrayList();
      if (codeType!=null && codeType.Kind==vsCMElement.vsCMElementStruct) {
        CodeStruct thisStruct = (CodeStruct)codeType;
        int membersCount = 0;
        try {
          membersCount = thisStruct.Members.Count;
        } catch {}
        for (int i = 0; i < membersCount; i++) {
          CodeElement element = thisStruct.Members.Item(i + 1);
          if (element.Kind==vsCMElement.vsCMElementVariable) {
            CodeVariable var = (CodeVariable)element;
            bool bInstField = false;
            try {
              bInstField = !var.IsConstant && !var.IsShared;
            } catch (NotImplementedException) {}
            if (bInstField) {
              CodeType varCodeType = null;
              if (var.Type!=null && var.Type.TypeKind==vsCMTypeRef.vsCMTypeRefCodeType)
                varCodeType = var.Type.CodeType;
              IFieldDescriptor field = new FieldDescriptor(var.Name, this, varCodeType, var.Attributes);
              fieldsList.Add(field);
            }
          }
        }
      }
      fields = (IFieldDescriptor[])fieldsList.ToArray(typeof(IFieldDescriptor));
    }
    #endif    
  }
}
