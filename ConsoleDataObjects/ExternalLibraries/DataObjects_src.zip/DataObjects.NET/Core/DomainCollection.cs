// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;
using System.Collections.Specialized;
using System.Runtime.Serialization;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Attributes;
using DataObjects.NET;

namespace DataObjects.NET
{
  /// <summary>
  /// Represents collection of <see cref="Domain"/>s
  /// that were configured via application configuration file
  /// (ExeName.config or Web.config).
  /// See <see cref="Configuration"/> class for additional information.
  /// <seealso cref="Domain"/>.
  /// <seealso cref="Configuration"/>.
  /// <seealso cref="ConfigurationSectionHandler"/>.
  /// </summary>
  public sealed class DomainCollection: MarshalByRefLockableCollectionBase
  {    
    /// <summary>
    /// Collection indexer.
    /// </summary>
    public Domain this[int n] {
      get {
        return (Domain)List[n];
      }
      set {
        List[n] = value;
      }
    }
    
    /// <summary>
    /// An indexer that provides access to collection items by their names.
    /// Returns <see langword="null"/> if there is no such item.
    /// </summary>
    public Domain this[string name] {
      get {
        foreach (Domain n in List) {
          if (n.Name==name)
            return n;
        }
        return null;
      }
    }
    
    /// <summary>
    /// The same as <see langword="this[&quot;Default&quot;]"/>
    /// </summary>
    public Domain DefaultDomain {
      get {
        if (Count<1)
          throw new InvalidOperationException("There are no configured Domains.");
        Domain d = this["Default"];
        if (d!=null)
          return d;
        if (Count>1)
          throw new InvalidOperationException("There are several configured Domains, and none is named \"Default\".");
        return this[0];
      }
    }

    /// <summary>
    /// Adds new domain to this collection. If element with the same
    /// name is already exists in this collection, <see cref="InvalidOperationException"/>
    /// will be thrown.
    /// </summary>
    /// <param name="domain">Domain to add.</param>
    public int Add(Domain domain)
    {
      return List.Add(domain);
    }
    
    /// <summary>
    /// Determines whether collection contains specified domain.
    /// </summary>
    /// <param name="domain">Domain to search for.</param>
    /// <returns><see langword="True"/> if domain was found.</returns>
    public bool Contains(Domain domain)
    {
      return List.Contains(domain);
    }

    /// <summary>
    /// Copies elements of this collection to <see cref="Array"/>.
    /// </summary>
    /// <param name="domains">Destination array.</param>
    /// <param name="offset">Offset in array to start from.</param>
    public void CopyTo(Domain[] domains, int offset)
    {
      List.CopyTo(domains, offset);
    }

    /// <summary>
    /// Searches for the specified object and returns the index of the first occurrence within the current instance.
    /// </summary>
    /// <param name="domain">The object to locate.</param>
    /// <returns>The index of the first occurrence of value within the entire collection, if found; otherwise, -1.</returns>
    public int IndexOf(Domain domain)
    {
      return List.IndexOf(domain);
    }

    /// <summary>
    /// Inserts domain to collection.
    /// </summary>
    /// <param name="offset">Offset of domain.</param>
    /// <param name="domain">Domain to insert.</param>
    public void Insert(int offset, Domain domain)
    {
      List.Insert(offset, domain);
    }

    /// <summary>
    /// Removes domain from collection.
    /// </summary>
    /// <param name="domain">Domain to remove.</param>
    public void Remove(Domain domain)
    {
      List.Remove(domain);
    }
    
    /// <summary>
    /// Performs additional custom processes when clearing the contents of the 
    /// <see cref="MarshalByRefCollectionBase"/> instance.
    /// </summary>
    protected override void OnClear()
    {
    }
    
    /// <summary>
    /// Performs additional custom processes before inserting a new element into the
    /// <see cref="MarshalByRefCollectionBase"/> instance.
    /// </summary>
    /// <param name="index">The zero-based <paramref name="index"/> at which to insert value.</param>
    /// <param name="value">The new value of the element at <paramref name="index"/>.</param>
    protected override void OnInsert(int index, Object value) 
    {
      Domain domain = (Domain)value;
      if (this[domain.Name]!=null)
        throw new InvalidOperationException(String.Format("Domain with the name \"{0}\" already exists.",domain.Name));
    }
    
    /// <summary>
    /// Performs additional custom processes before removing a new element into the
    /// <see cref="MarshalByRefCollectionBase"/> instance.
    /// </summary>
    /// <param name="index">The zero-based <paramref name="index"/> at which to insert value.</param>
    /// <param name="value">The value of the element to remove from <paramref name="index"/>.</param>
    protected override void OnRemove(int index, Object value) 
    {
    }
    
    /// <summary>
    /// Performs additional custom processes before setting a value in the
    /// <see cref="MarshalByRefCollectionBase"/> instance.
    /// </summary>
    /// <param name="index">The zero-based <paramref name="index"/> at which <paramref name="oldValue"/> can be found.</param>
    /// <param name="oldValue">The value to replace with <paramref name="newValue"/>.</param>
    /// <param name="newValue">The new value of the element at <paramref name="index"/>.</param>
    protected override void OnSet(int index, Object oldValue, Object newValue)
    {
      Domain t  = (Domain)newValue;
      Domain ot = (Domain)oldValue;
      if (this[t.Name]!=null && ot.Name!=t.Name)
        throw new InvalidOperationException(String.Format("Domain with the name \"{0}\" already exists.",t.Name));
    }
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    public DomainCollection()
    {
    }
  }
}
