// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;
using System.Data;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Data.CodeManage;

namespace DataObjects.NET.Data
{
  /// <summary>
  /// Provides a relation between <see cref="DataObject"/> type and a <see cref="DataTable"/>.
  /// <see cref="DoTranslator"/> is used to fill/update <see cref="DataObject"/>s.
  /// </summary>
  /// <remarks>
  /// <see cref="DataTable"/> must contain "ID" column which is a primary key column.
  /// "ID" column must be of <see cref="System.Int64"/> type.
  /// </remarks>
  internal class DoTranslator
  {
    private Adapter adapter;
    private ObjectModel.Type doType;
    private DataTable dataTable;
    private DataRow dataRow;
    private ArrayList propertyTranslatorsList;
    private ArrayList doCollectionTranslatorsList;
    private ArrayList vtCollectionTranslatorsList;
    private DataColumn sysIDColumn;
    private DataColumn sysTypeIDColumn;
    private DataColumn sysVersionCodeColumn;
    
    /// <summary>
    /// Gets <see cref="Adapter"/> associated with the <see cref="DoTranslator"/>.
    /// </summary>
    public Adapter Adapter {
      get {
        return adapter;
      }
    }
    
    /// <summary>
    /// Gets <see cref="ObjectModel.Type"/> of the <see cref="DataObject"/>.
    /// </summary>
    public ObjectModel.Type Type {
      get {
        return doType;
      }
    }
    
    /// <summary>
    /// Gets <see cref="DataTable"/> associated with <see cref="DoTranslator"/>.
    /// </summary>
    public DataTable DataTable {
      get {
        return dataTable;
      }
    }
    
    /// <summary>
    /// Gets current <see cref="DataRow"/>.
    /// </summary>
    public DataRow DataRow {
      get {
        return dataRow;
      }
    }
    
    /// <summary>
    /// Fills specified <see cref="DataObject"/> into adapter's DataSource.
    /// </summary>
    /// <param name="dataObject"><see cref="DataObject"/> to fill.</param>
    public void Fill(DataObject dataObject)
    {
      if (dataObject==null)
        throw new ArgumentNullException("dataObject");
      if (!doType.SourceType.IsAssignableFrom(dataObject.Type.SourceType))
        throw new AdapterException("Invalid DataObject type.");
      
      dataRow = dataTable.Rows.Find(dataObject.ID);
      if (dataRow!=null) {
        if ((adapter.FillOptions & FillOptions.RemoveOnConflict)!=0) {
          foreach (PropertyTranslator propertyTranslator in propertyTranslatorsList) {
            propertyTranslator.Fill(dataObject);
          }
        } else
          throw new AdapterException(
            String.Format("DataObject with ID={0} is already filled.", dataObject.ID));
      } else {
        dataRow = dataTable.NewRow();
        dataRow.BeginEdit();
        foreach (PropertyTranslator propertyTranslator in propertyTranslatorsList) {
          propertyTranslator.Fill(dataObject);
        }
        dataRow.EndEdit();
        dataTable.Rows.Add(dataRow);
      }
      
      foreach (DoCollectionTranslator doCollectionTranslator in doCollectionTranslatorsList)
        doCollectionTranslator.Fill(dataObject);        
        
      foreach (VtCollectionTranslator vtCollectionTranslator in vtCollectionTranslatorsList)
        vtCollectionTranslator.Fill(dataObject);
    }
    
    /// <summary>
    /// Updates specified <see cref="DataObject"/> from adapter's DataSource.
    /// </summary>
    /// <param name="dataObject"><see cref="DataObject"/> to update.</param>
    /// <param name="dataObjectVersionCode">version code to use.</param>
    public void Update(DataObject dataObject, string dataObjectVersionCode)
    {
      if (dataObject==null)
        throw new ArgumentNullException("dataObject");
      if (!doType.SourceType.IsAssignableFrom(dataObject.Type.SourceType))
        throw new AdapterException("Invalid DataObject type.");
        
      dataRow = dataTable.Rows.Find(dataObject.ID);
      if (dataRow!=null) {
        if (sysVersionCodeColumn!=null) {
          string versionCode = dataRow[sysVersionCodeColumn] as string;
          if (versionCode!=dataObjectVersionCode) {
            VersionConflictEventArgs e = new VersionConflictEventArgs();
            adapter.Internal_OnVersionConflict(e);
            if (e.Behaviour==VersionConflictBehaviour.Abort)
              throw new AdapterException("Version conflict.");
            else if (e.Behaviour==VersionConflictBehaviour.Skip)
              return;
          }
        }
      
        foreach (PropertyTranslator propertyTranslator in propertyTranslatorsList) {
          propertyTranslator.Update(dataObject);
        }
      }
    }
    
    /// <summary>
    /// Fills specified <see cref="DataObject"/> into adapter's DataSource after update.
    /// </summary>
    /// <param name="dataObject"><see cref="DataObject"/> to fill.</param>
    internal void FillAfterUpdate(DataObject dataObject)
    {
      if (dataObject==null)
        throw new ArgumentNullException("dataObject");
      if (!doType.SourceType.IsAssignableFrom(dataObject.Type.SourceType))
        throw new AdapterException("Invalid DataObject type.");
      
      dataRow = dataTable.Rows.Find(dataObject.ID);
      if (dataRow!=null) {
        if ((adapter.UpdateOptions & UpdateOptions.FillVersionOnly)==0) {
          foreach (PropertyTranslator propertyTranslator in propertyTranslatorsList) {
            propertyTranslator.Fill(dataObject);
          }
        } else {
          if (sysVersionCodeColumn!=null)
            dataRow[sysVersionCodeColumn] = dataObject.VersionCode;
        }
      }
    }
    
    /// <summary>
    /// Updates <see cref="DataObjectCollection"/>s and <see cref="ValueTypeCollection"/>s.
    /// </summary>
    internal void UpdateCollections()
    {
      foreach (DoCollectionTranslator doCollectionTranslator in doCollectionTranslatorsList)
        doCollectionTranslator.Update();
        
      foreach (VtCollectionTranslator vtCollectionTranslator in vtCollectionTranslatorsList)
        vtCollectionTranslator.Update();
    }
    
    /// <summary>
    /// Registers all objects <see cref="DoTranslator"/> could update.
    /// Currently this method registers all object ids in 
    /// the <see cref="AdapterUpdateQueue"/> for creation, removal or update.
    /// </summary>
    /// <remarks>
    /// <see cref="DoTranslator"/> scans all rows in the <see cref="DataTable"/>.
    /// If <see cref="DataRow"/>'s <see cref="DataRowState"/> is <see cref="DataRowState.Deleted"/>
    /// <see cref="DoTranslator"/> registers row's ID for removal.
    /// If row's ID is less than zero translator registers ID for creation.
    /// If row's ID is bigger than zero translator registers ID for update.
    /// </remarks>
    internal void RegisterIds()
    {
      AdapterUpdateQueue updateQueue = adapter.UpdateQueue;
      DataRowCollection rows = dataTable.Rows;
      if (rows!=null) {
        foreach (DataRow row in rows) {
          if (row.RowState==DataRowState.Deleted) {
            object id = row[sysIDColumn, DataRowVersion.Original];
            updateQueue.EnqueueObjectForRemove((long)id);
          } else {
            long id = (long)row[sysIDColumn];
            if (id<0)
              updateQueue.EnqueueObjectForCreate(id);
            else if (id>0)
              updateQueue.EnqueueObjectForUpdate(id);
            else
              throw new AdapterException("Invalid ID value");
          }
        }
      }
    }
    
    /// <summary>
    /// Updates system columns: sets ID and VersionCode in all raws that has id equal to oldID.
    /// </summary>
    /// <param name="oldID">old ID.</param>
    /// <param name="newID">new ID.</param>
    /// <param name="newVersionCode">new VersionCode.</param>
    internal void UpdateSystemColumns(long oldID, long newID, string newVersionCode)
    {
      DataRow row = dataTable.Rows.Find(oldID);
      if (row!=null) {
        row[sysIDColumn] = newID;
        if (sysVersionCodeColumn!=null)
          row[sysVersionCodeColumn] = newVersionCode;
      }
    }
    
    /// <summary>
    /// Suggests <see cref="ObjectModel.Type"/> using id for <see cref="DataObject"/> creation.
    /// </summary>
    /// <param name="id">id.</param>
    /// <returns>Suggested <see cref="ObjectModel.Type"/> or null.</returns>
    internal ObjectModel.Type SuggestType(long id)
    {
      DataRow row = dataTable.Rows.Find(id);
      if (row!=null) {
        if (sysTypeIDColumn!=null) {
          object tval = row[sysTypeIDColumn];
          if (System.DBNull.Value.Equals(tval))
            tval = null;
          if (tval!=null) {
            int typeID = (int)row[sysTypeIDColumn];
            ObjectModel.Type type = Adapter.Domain.Types[typeID];
            if (type!=null)
              return type;
          }
        }
        return doType;
      }
      return null;
    }
    
    /// <summary>
    /// Returns a <see cref="DataRow"/> that corresponds to the id.
    /// </summary>
    /// <param name="id">id.</param>
    /// <returns>A <see cref="DataRow"/> that corresponds to the id.</returns>
    internal DataRow GetCorrespondingRow(long id)
    {
      return dataTable.Rows.Find(id);
    }
    
    private void FillPropertyTranslatorsList(FieldMappingCollection fieldMappings)
    {
      Hashtable propTransByPath = new Hashtable();
      Hashtable propTransByColumn = new Hashtable();
      propertyTranslatorsList = new ArrayList();
      
      PropertyTranslator sysIDTranslator = new PropertyTranslator(this, new FieldMappingItem("ID", "ID"));
      propTransByPath[sysIDTranslator.Path] = sysIDTranslator;
      propTransByColumn[sysIDTranslator.DataColumn] = sysIDTranslator;
      propertyTranslatorsList.Add(sysIDTranslator);
      
      foreach (FieldMappingItem fieldMapping in fieldMappings) {
        PropertyTranslator propTrans = new PropertyTranslator(this, fieldMapping);
        if (propTransByPath.ContainsKey(propTrans.Path))
          throw new AdapterException(
            String.Format("Property \"{0}\" is already mapped.", propTrans.Path));
        if (propTransByColumn.ContainsKey(propTrans.DataColumn))
          throw new AdapterException(
            String.Format("Column \"{0}\" is already mapped.", propTrans.DataColumn.ColumnName));
        propTransByPath[propTrans.Path] = propTrans;
        propTransByColumn[propTrans.DataColumn] = propTrans;
        propertyTranslatorsList.Add(propTrans);
      }
    }
    
    private void FillDoCollectionTranslatorsList(DocMappingCollection docMappings)
    {
      Hashtable colTransByName = new Hashtable();
      Hashtable colTransByTable = new Hashtable();
      doCollectionTranslatorsList = new ArrayList();
      
      foreach (DocMappingItem docMapping in docMappings) {
        DoCollectionTranslator colTrans = new DoCollectionTranslator(this, docMapping);
        if (colTransByName.ContainsKey(colTrans.FullCollectionName))
          throw new AdapterException(
            String.Format("Collection \"{0}\" is already mapped.", colTrans.FullCollectionName));
        if (colTransByTable.ContainsKey(colTrans.DataTable))
          throw new AdapterException(
            String.Format("Table \"{0}\" is already mapped.", colTrans.DataTable.TableName));
        colTransByName[colTrans.FullCollectionName] = colTrans;
        colTransByTable[colTrans.DataTable] = colTrans;
        doCollectionTranslatorsList.Add(colTrans);
      }
    }
    
    private void FillVtCollectionTranslatorsList(VtcMappingCollection vtcMappings)
    {
      Hashtable colTransByName = new Hashtable();
      Hashtable colTransByTable = new Hashtable();
      vtCollectionTranslatorsList = new ArrayList();
      
      foreach (VtcMappingItem vtcMapping in vtcMappings) {
        VtCollectionTranslator colTrans = new VtCollectionTranslator(this, vtcMapping);
        if (colTransByName.ContainsKey(colTrans.FullCollectionName))
          throw new AdapterException(
            String.Format("Collection \"{0}\" is already mapped.", colTrans.FullCollectionName));
        if (colTransByTable.ContainsKey(colTrans.DataTable))
          throw new AdapterException(
            String.Format("Table \"{0}\" is already mapped.", colTrans.DataTable.TableName));
        colTransByName[colTrans.FullCollectionName] = colTrans;
        colTransByTable[colTrans.DataTable] = colTrans;
        vtCollectionTranslatorsList.Add(colTrans);
      }
    }
    
    /// <summary>
    /// Initializes a new instance of the <see cref="DoTranslator"/> class.
    /// </summary>
    /// <param name="adapter">Adapter.</param>
    /// <param name="mappingItem">Class mapping item.</param>
    internal DoTranslator(Adapter adapter, ClassMappingItem mappingItem)
    {
      if (adapter==null)
        throw new ArgumentNullException("adapter");
      if (adapter.DataSource==null)
        throw new NullReferenceException("adapter.DataSource is null.");
      if (mappingItem==null)
        throw new ArgumentNullException("mappingItem");
      if (mappingItem.ClassName==null)
        throw new NullReferenceException("mappingItem.ClassName is null.");
      if (mappingItem.TableName==null)
        throw new NullReferenceException("mappingItem.TableName is null.");
        
      this.adapter = adapter;

      IClassDescriptor classDescriptor = adapter.CodeManager.GetClass(mappingItem.ClassName, false);
      if (classDescriptor==null)
        throw new AdapterException(
          String.Format("Class \"{0}\" is not found.", mappingItem.ClassName));
      doType = adapter.Domain.Types[classDescriptor.FullName];
      if (doType==null)
        throw new AdapterException(
          String.Format("Type \"{0}\" is not registered in the Domain.", mappingItem.ClassName));
      
      dataTable = adapter.dataSource.Tables[mappingItem.TableName];
      if (dataTable==null)
        throw new AdapterException(
          String.Format("Table \"{0}\" Does not exists.", mappingItem.TableName));
          
      sysIDColumn = dataTable.Columns["ID"];
      sysTypeIDColumn = dataTable.Columns["TypeID"];
      sysVersionCodeColumn = dataTable.Columns["VersionCode"];
      
      if (sysIDColumn==null)
        throw new AdapterException("ID column is absent.");
      if (sysIDColumn.DataType!=typeof(long))
        throw new AdapterException("Invalid ID column data type.");
      DataColumn[] primaryKey = dataTable.PrimaryKey;
      if (primaryKey==null || primaryKey.Length!=1 || primaryKey[0]!=sysIDColumn)
        throw new AdapterException("Invalid Primary Key column.");
      
      FillPropertyTranslatorsList(mappingItem.Fields);
      FillDoCollectionTranslatorsList(mappingItem.DoCollections);
      FillVtCollectionTranslatorsList(mappingItem.VtCollections);
    }
    
    /// <summary>
    /// Initializes a new instance of the <see cref="DoTranslator"/> class.
    /// </summary>
    /// <param name="adapter">Adapter.</param>
    /// <param name="mappingItem">Interface mapping item.</param>
    internal DoTranslator(Adapter adapter, InterfaceMappingItem mappingItem)
    {
      if (adapter==null)
        throw new ArgumentNullException("adapter");
      if (adapter.DataSource==null)
        throw new NullReferenceException("adapter.DataSource is null.");
      if (mappingItem==null)
        throw new ArgumentNullException("mappingItem");
      if (mappingItem.InterfaceName==null)
        throw new NullReferenceException("mappingItem.InterfaceName is null.");
      if (mappingItem.TableName==null)
        throw new NullReferenceException("mappingItem.TableName is null.");
        
      this.adapter = adapter;

      IInterfaceDescriptor interfaceDescriptor = adapter.CodeManager.GetInterface(mappingItem.InterfaceName, false);
      if (interfaceDescriptor==null)
        throw new AdapterException(
          String.Format("Interface \"{0}\" is not found.", mappingItem.InterfaceName));
      doType = adapter.Domain.Types[interfaceDescriptor.FullName];
      if (doType==null)
        throw new AdapterException(
          String.Format("Type \"{0}\" is not registered in the Domain.", mappingItem.InterfaceName));
      
      dataTable = adapter.dataSource.Tables[mappingItem.TableName];
      if (dataTable==null)
        throw new AdapterException(
          String.Format("Table \"{0}\" Does not exists.", mappingItem.TableName));
          
      sysIDColumn = dataTable.Columns["ID"];
      sysTypeIDColumn = dataTable.Columns["TypeID"];
      sysVersionCodeColumn = dataTable.Columns["VersionCode"];
      
      if (sysIDColumn==null)
        throw new AdapterException("\"ID\" column is absent.");
      if (sysIDColumn.DataType!=typeof(long))
        throw new AdapterException("Invalid \"ID\" column data type.");
      DataColumn[] primaryKey = dataTable.PrimaryKey;
      if (primaryKey==null || primaryKey.Length!=1 || primaryKey[0]!=sysIDColumn)
        throw new AdapterException("Invalid Primary Key column.");
      
      FillPropertyTranslatorsList(mappingItem.Fields);
      FillDoCollectionTranslatorsList(mappingItem.DoCollections);
      FillVtCollectionTranslatorsList(mappingItem.VtCollections);
    }
  }
}
