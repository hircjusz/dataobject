using System;
using System.Collections;
using DataObjects.NET;
using DataObjects.NET.Security;

namespace DataObjects.NET.Security
{
  /// <summary>
  /// Collection of <see cref="FlatPermissionEntry"/> instances.
  /// <seealso cref="AccessControlList.GetFlatPermissions"/>
  /// <seealso cref="FlatPermissionEntry"/>
  /// <seealso cref="IPermission"/>
  /// <seealso cref="Principal"/>
  /// <seealso cref="AccessControlList"/>
  /// </summary>
  /// <remarks>
  /// <para>
  /// This type is useful for GUI representation of object's permission
  /// inheritance hierarchy.
  /// See <see cref="AccessControlList.GetFlatPermissions">AccessControlList.GetFlatPermissions</see>
  /// for additional information.
  /// </para>
  /// <para>
  /// You can find more information about the whole DataObjects.NET
  /// security system <see cref="AccessControlList">here</see>.
  /// </para>
  /// </remarks>
  public class FlatPermissionEntryCollection : MarshalByRefCollectionBase, 
    ICollection, IList, IEnumerable
  {
    /// <summary>
    /// Gets element at the specified index.
    /// </summary>
    public FlatPermissionEntry this[int index] {
      get {
        return (FlatPermissionEntry)List[index];
      }
    }
    
    /// <summary>
    /// Always throws <see cref="InvalidOperationException"/>:
    /// <see cref="FlatPermissionEntryCollection"/> is always read-only.
    /// </summary>
    protected override void OnChange()
    {
      throw new InvalidOperationException(
        "FlatPermissionEntryCollection is always read-only.");
    }


    // Constructors
    
    internal FlatPermissionEntryCollection(ArrayList source)
    {
      InnerList = ArrayList.ReadOnly(source);
    }
  }
}
