// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Reflection;
using DataObjects.NET;
using DataObjects.NET.Attributes;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Security;

namespace DataObjects.NET.Versionizing
{
  /// <summary>
  /// Provides information for a single transaction
  /// in the <see cref="DomainDatabaseOptions.EnableVersionizing">versionizing</see> mode.
  /// <see langword="Persistent"/>.
  /// </summary>
  [NotVersionized]
  public abstract class TransactionInfo: DataObject
  {
    /// <summary>
    /// Gets transaction start time.
    /// </summary>
    [Indexed]
    public abstract DateTime StartTime { get; }
    
    /// <summary>
    /// Gets the <see cref="User"/> that committed the transaction.
    /// </summary>
    [Indexed]
    public abstract User User { get; }
    
    /// <summary>
    /// Called before instance is removed (see <see cref="DataObject.Remove"/> method).
    /// </summary>
    [Transactional(TransactionMode.Disabled)]
    protected internal override void OnRemove()
    {
      throw new InvalidOperationException(
        String.Format("Object of type \"{0}\" can not be removed.", "TransactionInfo"));
    }

    // Constructors
    
    /// <summary>
    /// A constructor analogue. Called on instance initialization.
    /// </summary>
    /// <param name="startTime">Transaction start time.</param>
    /// <remarks>
    /// <para>
    /// See <see cref="DataObject.OnCreate"/> method description
    /// for additional information.
    /// </para>
    /// </remarks>
    [Transactional(TransactionMode.Disabled)]    
    protected virtual void OnCreate(DateTime startTime)
    {
      if (!Session.allowModifyTransactionInfo)
        throw new InvalidOperationException(
          "TransactionInfo objects can't be created manually.");
      SetProperty("StartTime", startTime);
      SetProperty("User", Session.User);
      base.OnCreate();
    }
    
    /// <summary>
    /// A constructor analogue. Called on initialization of 
    /// deserializable instance.
    /// </summary>
    /// <remarks>
    /// <para>
    /// See <see cref="DataObject.OnCreateDeserializable"/> method description
    /// for additional information.
    /// </para>
    /// </remarks>
    protected override void OnCreateDeserializable() 
    {
      if (!Session.allowModifyTransactionInfo)
        throw new InvalidOperationException(
          "TransactionInfo objects can't be created manually.");
      base.OnCreateDeserializable ();
    }
    
    // Event handlers
    
    /// <summary>
    /// Called during <see cref="DataObject.SetProperty"/> method execution.
    /// Note that this method isn't invoked during the deserialization.
    /// </summary>
    /// <param name="name">Property name.</param>
    /// <param name="culture">Property culture.</param>
    /// <param name="value">New property value.</param>
    /// <remarks>
    /// <para>
    /// See <see cref="DataObject.OnSetProperty"/> method description
    /// for additional information.
    /// </para>
    /// </remarks>
    protected override void OnSetProperty(string name, Culture culture, object value) 
    {
      if (name=="User" && value==null &&
          User!=null && User.IsRemoving)
        goto Proceed;
      if (!Session.allowModifyTransactionInfo)
        throw new InvalidOperationException(
          "TransactionInfo objects can't be modified manually.");
    Proceed:
      base.OnSetProperty (name, culture, value);
    }
  }
}
