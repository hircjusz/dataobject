// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;

namespace DataObjects.NET.Attributes
{
  /// <summary>
  /// Specifies the type of items in the <see cref="DataObjectCollection"/>
  /// or <see cref="ValueTypeCollection"/>.
  /// Allows to specify <see cref="OwnerField"/> for 
  /// <see cref="ValueTypeCollection"/>s additionally.
  /// </summary>
  /// <remarks>
  /// <note>This attribute can be applied to persistent properties
  /// of <see cref="DataObjectCollection"/> and 
  /// <see cref="ValueTypeCollection"/> types.</note>
  /// <para>
  /// <example>Example (for <see cref="DataObjectCollection"/>):
  /// <code lang="C#">
  ///  public abstract class Person: DataObject
  ///  {
  ///    ...
  ///    
  ///    [ItemType(typeof(Person))] // !!!
  ///    public abstract DataObjectCollection Children {get;}
  ///
  ///    [Symmetric]
  ///    [ItemType(typeof(Person))] // !!!
  ///    public abstract DataObjectCollection Friends {get;}
  ///
  ///    ...
  ///  }
  /// </code>
  /// </example>
  /// </para>
  /// <para>
  /// <example>Example (for <see cref="ValueTypeCollection"/>):
  /// <code lang="C#">
  ///  public struct Order
  ///  {
  ///    public Seller Seller; 
  ///    public Customer Customer; 
  ///    public Person Advisor; 
  ///    public int Quantity; 
  ///    ....
  ///  }
  ///  public abstract class Person: DataObject
  ///  {
  ///    [ItemType(typeof(Order), OwnerField = "Advisor", AllowNullOwner = true)] // !!!
  ///    [PairTo(typeof(Seller), "Orders")]
  ///    public abstract ValueTypeCollection Orders {get;}
  ///
  ///    ...
  ///  }
  ///    
  ///  public abstract class Seller: Person
  ///  {
  ///    [ItemType(typeof(Order), OwnerField = "Seller")] // !!!
  ///    public abstract ValueTypeCollection Orders {get;}
  ///
  ///    ...
  ///  }
  ///
  ///  public abstract class Customer: Person
  ///  {
  ///    [ItemType(typeof(Order), OwnerField = "Customer")] // !!!
  ///    [PairTo(typeof(Seller), "Orders")]
  ///    public abstract ValueTypeCollection Orders {get;}
  ///
  ///    ...
  ///  }
  /// </code>
  /// </example>
  /// </para>
  /// <seealso cref="ContainedAttribute"/>
  /// <seealso cref="SelfReferenceAllowedAttribute"/>
  /// <seealso cref="PairToAttribute"/>
  /// <seealso cref="SymmetricAttribute"/>
  /// </remarks>
  [AttributeUsage(AttributeTargets.Property, AllowMultiple = false, Inherited = true)]
  [Serializable]
  public class ItemTypeAttribute: DataObjectAttribute
  {
    private Type type;
    /// <summary>
    /// Gets ot sets the <see cref="System.Type"/> of collection items.
    /// </summary>
    public  Type Type 
    {
      get {return type;}
      set {type = value;}
    }
    
    private string ownerField;
    /// <summary>
    /// Gets or sets the name of item field that should hold a reference 
    /// to <see cref="ValueTypeCollection"/> owner. Can be used only
    /// for <see cref="ValueTypeCollection"/> properties.
    /// </summary>
    public string OwnerField {
      get {
        return ownerField;
      }
      set {
        ownerField = value;
      }
    }

    private bool allowNullOwner = false;
    /// <summary>
    /// <see langword="True"/>, if <see langword="null"/> value is
    /// valid <see cref="OwnerField"/> value (in any particular collection item);
    /// otherwise, <see langword="false"/>.
    /// Default value is <see langword="false"/>.
    /// </summary>
    public bool  AllowNullOwner {
      get {
        return allowNullOwner;
      }
      set {
        allowNullOwner = value;
      }
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type">Collection item type.</param>
    public ItemTypeAttribute(Type type) 
    {
      this.type = type;
    }
  }
}
