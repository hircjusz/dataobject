// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

#if !MONO 
using System;
using System.Collections;
using EnvDTE;

namespace DataObjects.NET.Data.CodeManage
{
  /// <summary>
  /// Code manager that is used in design time.
  /// </summary>
  internal class DesigntimeCodeManager: CodeManagerBase
  {
    private bool isInitialized = false;
    private CodeModel codeModel;
    private Hashtable interfaceContext;
    private Hashtable classContext;
    private IInterfaceDescriptor[] interfaces;
    private IClassDescriptor[] classes;
    private IClassDescriptor root;
    
    /// <summary>
    /// Gets code model.
    /// </summary>
    internal CodeModel CodeModel {
      get {
        return codeModel;
      }
    }

    /// <summary>
    /// Returns an array of available interface descriptors.
    /// </summary>
    /// <returns>An array of available interface descriptors.</returns>    
    internal protected override IInterfaceDescriptor[] GetInterfaces()
    {
      EnsureInitialized();
      return interfaces;
    }
    
    /// <summary>
    /// Returns an array of available class descriptors.
    /// </summary>
    /// <returns>An array of available class descriptors.</returns>
    internal protected override IClassDescriptor[] GetClasses()
    {
      EnsureInitialized();
      return classes;
    }

    /// <summary>
    /// Returns a descriptor of a root class.
    /// </summary>
    /// <returns>Returns a descriptor of a root class.</returns>    
    internal protected override IClassDescriptor GetRoot()
    {
      EnsureInitialized();
      return root;
    }
    
    /// <summary>
    /// Adds to the list all interfaces that are implemented by the interface.
    /// </summary>
    /// <param name="list">List to add interfaces to.</param>
    /// <param name="element"><see cref="CodeInterface"/>.</param>
    internal void FillImplementedInterfaces(ArrayList list, CodeInterface element)
    {
      int basesCount = 0;
      try {
        basesCount = element.Bases.Count;
      } catch {}
      for (int i = 0; i < basesCount; i++) {
        CodeElement baseElement = element.Bases.Item(i + 1);
        if (baseElement.Kind==vsCMElement.vsCMElementInterface) {
          CodeInterface codeInterface = (CodeInterface)baseElement;
          IInterfaceDescriptor iDescr = (IInterfaceDescriptor)interfaceContext[codeInterface.FullName];
          if (iDescr!=null && !list.Contains(iDescr)) {
            list.Add(iDescr);
            FillImplementedInterfaces(list, codeInterface);
          }
        }
      }
    }
    
    /// <summary>
    /// Adds to the list all interfaces that are implemented by the interface.
    /// </summary>
    /// <param name="list">List to add interfaces to.</param>
    /// <param name="interfaceFullName">Interface full name.</param>
    internal void FillImplementedInterfaces(ArrayList list, string interfaceFullName)
    {
      CodeType codeType = codeModel.CodeTypeFromFullName(interfaceFullName);
      if (codeType.Kind==vsCMElement.vsCMElementInterface)
        FillImplementedInterfaces(list, (CodeInterface)codeType);
    }

    /// <summary>
    /// Adds to the list all interfaces that are implemented by the class.
    /// </summary>
    /// <param name="list">List to add interfaces to.</param>
    /// <param name="element"><see cref="CodeClass"/>.</param>
    internal void FillImplementedInterfaces(ArrayList list, CodeClass element)
    {
      int implInterfacesCount = 0;
      try {
        implInterfacesCount = element.ImplementedInterfaces.Count;
      } catch {}
      for (int i = 0; i < implInterfacesCount; i++) {
        CodeElement implElement = element.ImplementedInterfaces.Item(i + 1);
        if (implElement.Kind==vsCMElement.vsCMElementInterface) {
          CodeInterface codeInterface = (CodeInterface)implElement;
          IInterfaceDescriptor iDescr = (IInterfaceDescriptor)interfaceContext[codeInterface.FullName];
          if (iDescr!=null && !list.Contains(iDescr)) {
            list.Add(iDescr);
            FillImplementedInterfaces(list, codeInterface);
          }
        }
      }
      int basesCount = 0;
      try {
        basesCount = element.Bases.Count;
      } catch {}
      for (int i = 0; i < basesCount; i++) {
        CodeElement baseElement = element.Bases.Item(i + 1);
        if (baseElement.Kind==vsCMElement.vsCMElementClass)
          FillImplementedInterfaces(list, (CodeClass)baseElement);
      }
    }
    
    /// <summary>
    /// Returns <see langword="true"/> if code element is a descendant of a type with the specified full name.
    /// </summary>
    /// <param name="codeElement"><see cref="CodeElement"/>.</param>
    /// <param name="fullName">Type full name.</param>
    /// <returns><see langword="True"/> if code element is a descendant of a type with the specified full name.</returns>
    internal static bool IsDescendantOf(CodeElement codeElement, string fullName)
    {
      if (!codeElement.IsCodeType)
        return false;
        
      CodeType type = (CodeType)codeElement;
      try {
        int basesCount = 0;
        try {
          basesCount = type.Bases.Count;
        } catch {}
        for (int i = 0; i < basesCount; i++) {
          CodeElement baseElement = type.Bases.Item(i + 1);
          if (baseElement.Kind==vsCMElement.vsCMElementClass || baseElement.Kind==vsCMElement.vsCMElementInterface) {
            if (baseElement.FullName==fullName)
              return true;
            return IsDescendantOf(baseElement, fullName);
          }
        }
      } catch (NotImplementedException) {
        return false;
      }
      return false;
    }
    
    /// <summary>
    /// Returns <see langword="true"/> if code element is a descendant of a type with the specified full name or
    /// is a type with this full name.
    /// </summary>
    /// <param name="codeElement"><see cref="CodeElement"/>.</param>
    /// <param name="fullName">Type full name.</param>
    /// <returns><see langword="True"/> if code element is a descendant of a type with the specified full name or
    /// is a type with this full name.</returns>
    internal static bool IsTypeOrDescendantOf(CodeElement codeElement, string fullName)
    {
      if (codeElement.FullName==fullName)
        return true;
      return IsDescendantOf(codeElement, fullName);
    }
    
    /// <summary>
    /// Returns array of classes that are derived from the class with the specified full name.
    /// </summary>
    /// <param name="classFullName">Class full name.</param>
    /// <returns>Array of classes that are derived from the class with the specified full name.</returns>
    internal object[] GetDerivedClasses(string classFullName)
    {
      ArrayList list = (ArrayList)classContext[classFullName];
      if (list==null)
        list = new ArrayList();
      object[] codeClasses = list.ToArray();
      return codeClasses;
    }
    
    private void AddClassToContext(CodeClass codeClass)
    {
      if (!codeClass.IsAbstract)
        return;
      try {
        int basesCount = 0;
        try {
          basesCount = codeClass.Bases.Count;
        } catch {}
        for (int i = 0; i < basesCount; i++) {
          CodeElement baseElement = codeClass.Bases.Item(i + 1);
          if (baseElement.Kind==vsCMElement.vsCMElementClass) {
            string baseName = baseElement.FullName;
            if (!classContext.ContainsKey(baseName))
              classContext[baseName] = new ArrayList();
            ((IList)classContext[baseName]).Add(codeClass);
          }
        }
      } 
      catch (NotImplementedException) {}
    }
    
    private void AddInterfaceToContext(CodeInterface codeInterface)
    {
      string fullName = codeInterface.FullName;
      interfaceContext[fullName] = new InterfaceDescriptor(codeInterface, this);
    }

    private void FillContext(CodeElement element)
    {
      if (element.Kind==vsCMElement.vsCMElementClass) {
        CodeClass codeClass = (CodeClass)element;
        try {
          if (codeClass.get_IsDerivedFrom("DataObjects.NET.DataObject"))
            AddClassToContext(codeClass);
        } catch (System.Runtime.InteropServices.COMException) {
          if (IsDescendantOf(element, "DataObjects.NET.DataObject"))
            AddClassToContext(codeClass);
        }
      } else if (element.Kind==vsCMElement.vsCMElementInterface) {
        CodeInterface codeInterface = (CodeInterface)element;
        if (codeInterface.FullName=="DataObjects.NET.IDataObject")
          AddInterfaceToContext(codeInterface);
        else {
          try {
            if (codeInterface.get_IsDerivedFrom("DataObjects.NET.IDataObject")) 
              AddInterfaceToContext(codeInterface);
          } catch (System.Runtime.InteropServices.COMException) {
            if (IsDescendantOf(element, "DataObjects.NET.IDataObject"))
              AddInterfaceToContext(codeInterface);
          }
        }
      } else if (element.Kind==vsCMElement.vsCMElementNamespace) {
        if (element.FullName!="System" && element.FullName!="Microsoft") {
          CodeNamespace namespaceElement = (CodeNamespace)element;
          for (int i = 0; i < namespaceElement.Members.Count; i++)
            FillContext(namespaceElement.Members.Item(i + 1));
        }
      }
    }
    
    private void AddClassToList(IClassDescriptor classDesc, ArrayList list)
    {
      list.Add(classDesc);
      foreach (IClassDescriptor childClassDesc in classDesc.DerivedClasses)
        AddClassToList(childClassDesc, list);
    }
    
    private IClassDescriptor GetDataObjectDescriptor()
    {
      CodeType codeType = null;
      try {
        codeType = codeModel.CodeTypeFromFullName("DataObjects.NET.DataObject");
      } catch {}
      if (codeType==null || codeType.Kind!=vsCMElement.vsCMElementClass)
        return null;
      return new ClassDescriptor(null, (CodeClass)codeType, this);
    }
    
    private void EnsureInitialized()
    {
      if (!isInitialized) {
        classContext = new Hashtable();
        interfaceContext = new Hashtable();
        
        for (int i = 0; i < codeModel.CodeElements.Count; i++)
          FillContext(codeModel.CodeElements.Item(i + 1));
        
        interfaces = (IInterfaceDescriptor[])(new ArrayList(interfaceContext.Values)).ToArray(typeof(IInterfaceDescriptor));
        foreach (InterfaceDescriptor id in interfaces)
          id.DesignTime_EnsureFillImplementedInterfaces();
        
        ArrayList classesList = new ArrayList();
        root = GetDataObjectDescriptor();
        if (root!=null)
          AddClassToList(root, classesList);
        classes = (IClassDescriptor[])classesList.ToArray(typeof(IClassDescriptor));
        
        isInitialized = true;
      }
    }
  
    /// <summary>
    /// Initializes a new instance of the <see cref="DesigntimeCodeManager"/> class.
    /// </summary>
    /// <param name="codeModel"><see cref="CodeModel"/>.</param>
    internal DesigntimeCodeManager(CodeModel codeModel): base()
    {
      if (codeModel==null)
        throw new ArgumentNullException("codeModel");
      this.codeModel = codeModel;
    }
  }
}
#endif