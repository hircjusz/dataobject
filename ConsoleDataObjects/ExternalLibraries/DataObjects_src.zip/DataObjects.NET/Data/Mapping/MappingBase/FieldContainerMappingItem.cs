// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.ComponentModel;

namespace DataObjects.NET.Data
{
  /// <summary>
  /// Base class for all mapping item classes that maps to table
  /// and has a FieldMappingCollection.
  /// </summary>
  public abstract class FieldContainerMappingItem: MappingToTableItem
  {
    private FieldMappingCollection fields;
    
    /// <summary>
    /// Gets field mapping collection.
    /// </summary>
    [Category("Mapping")]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    public FieldMappingCollection Fields {
      get {
        return fields;
      }
    }
    
    /// <summary>
    /// Initializes a new instance of the <see cref="MappingToTableItem"/> class.
    /// </summary>
    /// <param name="tableName">Database table name.</param>
    public FieldContainerMappingItem(string tableName): base(tableName)
    {
      this.fields = new FieldMappingCollection(this);
    }
  }
}
