// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using DataObjects.NET.Attributes;

namespace DataObjects.NET
{
  /// <summary>
  /// Base class for any runtime service.
  /// Any of such services can be periodically invoked in the special 
  /// thread and session of the <see cref="Domain"/> to perform such
  /// operations as updating full-text indexes.
  /// </summary>
  public abstract class RuntimeService : DataService
  {
    /// <summary>
    /// Gets the delay to make before the next execution.
    /// </summary>
    /// <param name="e">Exception thrown by previous <see cref="Execute"/> call, <see langword="null"/> if call succeeded.</param>
    /// <returns>delay.</returns>
    public abstract TimeSpan GetDelay(Exception e);

    /// <summary>
    /// This method is invoked by the <see cref="Domain"/> periodically
    /// (in the special thread and <see cref="Session"/>) to allow the 
    /// service to make its job.
    /// </summary>
    [Transactional(TransactionMode.NewTransactionRequired)]
    public abstract void Execute();
  }
}
