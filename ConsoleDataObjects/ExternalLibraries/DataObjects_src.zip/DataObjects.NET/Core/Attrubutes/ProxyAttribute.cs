// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;

namespace DataObjects.NET.Attributes
{
  /// <summary>
  /// Allows to define set of attributes that should
  /// be applied to DataObjects.NET-generated proxy class, its member, 
  /// method parameter, etc.
  /// If these attribute is used, DataObjects.NET doesn't tries
  /// to copy other attributes - except of that it applies
  /// only attributes specified using this attribute.
  /// Normally you shouldn't use this attribute.
  /// </summary>
  [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method | AttributeTargets.Property | AttributeTargets.Parameter, 
    AllowMultiple = true, Inherited = false)]
  [Serializable]
  public class ProxyAttributeAttribute: DataObjectAttribute
  {
    private Type type;
    /// <summary>
    /// Type of attribute to apply.
    /// </summary>
    public  Type Type 
    {
      get {return type;}
      set {type = value;}
    }
    
    private string[] paramNames = new string[0];
    /// <summary>
    /// Constructor argument names.
    /// </summary>
    public  string[] ParamNames {
      get {return paramNames;}
    }

    private object[] paramValues = new object[0];
    /// <summary>
    /// Constructor argument values.
    /// </summary>
    public  object[] ParamValues {
      get {return paramValues;}
    }


    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    public ProxyAttributeAttribute()
    {
      this.type = null;
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type">Type of attribute to create.</param>
    public ProxyAttributeAttribute(Type type)
    {
      this.type = type;
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type">Type of attribute to create.</param>
    /// <param name="parameters">Construction parameters, should be a sequence of
    /// <see cref="String"/>, <see cref="Object"/> pairs, where first part is
    /// parameter name (<see langword="null"/> or empty string if it should be omitted), and
    /// second part is its value.</param>
    public ProxyAttributeAttribute(Type type, params object[] parameters)
    {
      this.type = type;
      int l = parameters.Length/2;
      paramNames  = new string[l];
      paramValues = new object[l];
      for (int i = 0; i<l; i++) {
        string name = parameters[i*2] as string;
        object val  = parameters[i*2+1];
        paramNames[i]  = (name=="") ? null : name;
        paramValues[i] = val;
      }
    }
  }
}
