// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Reflection;
using DataObjects.NET.Attributes;

namespace DataObjects.NET.Remoting
{
  /// <summary>
  /// Encapsulates default method invocation logic (using reflection).
  /// </summary>
  public class DefaultMethodInvoker
  {
    /// <summary>
    /// Invokes specified method on <paramref name="invocationTarget"/>.
    /// </summary>
    /// <param name="invocationTarget">Target instance for method invocation.</param>
    /// <param name="methodName">Name of the method to invoke.</param>
    /// <param name="parameters">Parameters passed to the method.</param>
    /// <returns></returns>
    public static object InvokeMethod (object invocationTarget, string methodName, object[] parameters)
    {
      object state = null;
      System.Type type = invocationTarget.GetType();
      MethodInfo[] methods = (MethodInfo[])type.GetMember(methodName, MemberTypes.Method, 
        BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.InvokeMethod);
      MethodInfo mi = (MethodInfo)System.Type.DefaultBinder.BindToMethod(
        BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.InvokeMethod,
        methods, ref parameters, null, null, null, out state);

      Attribute[] aa = Attribute.GetCustomAttributes(mi, typeof(BusinessMethodAttribute), true);
      bool isOnlineBusinessMethod = (aa!=null && aa.Length>0);
      if (mi.IsPublic || isOnlineBusinessMethod)
        return mi.Invoke(invocationTarget, parameters);
      else
        throw new InvalidOperationException("An attempt to call non public and non business method.");
    }
  }
}
