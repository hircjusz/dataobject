// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;
using System.Runtime.Serialization;
using DataObjects.NET.Attributes;
using DataObjects.NET.Exceptions;
using DataObjects.NET.ObjectModel;

namespace DataObjects.NET
{
  /// <summary>
  /// Represents a collection of <see cref="ValueTypeQueryResultEntry"/> objects 
  /// returned by the <see cref="QueryBase.ExecuteValueTypeQueryResult"/> method.
  /// <seealso cref="ValueTypeQueryResultEntry"/>
  /// <seealso cref="Query"/>
  /// <seealso cref="SqlQuery"/>
  /// <seealso cref="ValueTypeCollection"/>
  /// </summary>
  public sealed class ValueTypeQueryResult: SessionBoundCollectionBase,
    IList, ICollection, IEnumerable
  { 
    private Field   field;
    private Culture culture;
    private bool    loadOnDemand;
    private TransactionContext transactionContext;
    private TransactionContext preLoadTransactionContext;

    /// <summary>
    /// Gets the <see cref="Field"/> that was queried.
    /// </summary>
    public Field Field {
      get {
        return field;
      }
    }
    
    /// <summary>
    /// Gets the <see cref="Culture"/> of the field that was queried.
    /// </summary>
    public Culture Culture {
      get {
        return culture;
      }
    }
    
    /// <summary>
    /// <see langword="True"/> if this result set was retrieved with
    /// <see cref="QueryOptions.LoadOnDemand"/> option;
    /// otherwise, <see langword="false"/>.
    /// </summary>
    public bool LoadOnDemand {
      get {
        return loadOnDemand;
      }
    }
    
    /// <summary>
    /// Gets <see cref="DataObjects.NET.TransactionContext"/> where
    /// data of this result set was retrieved.
    /// </summary>
    public TransactionContext TransactionContext {
      get {
        return transactionContext;
      }
    }

    /// <summary>
    /// Gets the element at the specified index.
    /// </summary>
    /// <param name="index">The zero-based index of the element to get or set.</param>
    /// <returns>The element at the specified index.</returns>
    public ValueTypeQueryResultEntry this[int index] {
      get {
        return (ValueTypeQueryResultEntry)InnerList[index];
      }
    }
    
    /// <summary>
    /// Preloads all <see cref="DataObject"/> instances holding
    /// collection items stored in this result set.
    /// </summary>
    [Transactional(TransactionMode.TransactionRequired)]
    public void Preload()
    {
      if (preLoadTransactionContext!=null &&
          preLoadTransactionContext.State==TransactionContextState.Valid)
        return;
      // Automatic Transactions support code
      TransactionController tc = session.CreateTransactionController( TransactionMode.TransactionRequired);
    Reprocess:
      try {
        InnerPreload();
        tc.Commit();
        return;
      }
      catch (Exception e) {
        if (tc.Rollback(e, true))
          goto Reprocess;             
        throw;
      }
    }
    private void InnerPreload()
    {
      int cnt = InnerList.Count;
      Hashtable hIDs = new Hashtable();
      for (int i = 0; i<cnt; i++) {
        ValueTypeQueryResultEntry entry = (ValueTypeQueryResultEntry)InnerList[i];
        hIDs[entry.OwnerID] = hIDs;
      }
      long[] aIDs = new long[hIDs.Count];
      hIDs.Keys.CopyTo(aIDs, 0);
      session.Preload(aIDs);
      preLoadTransactionContext = session.transactionContext;
    }

    // IList, ICollection, IEnumerable methods implementation
    
    /// <summary>
    /// Returns an enumerator that can iterate through the
    /// <see cref="ValueTypeQueryResult"/> instance.
    /// </summary>
    /// <returns>
    /// An <see cref="IEnumerator"/> for the 
    /// <see cref="ValueTypeQueryResult"/> instance.
    /// </returns>
    public override IEnumerator GetEnumerator()
    {
      return new ValueTypeQueryResultEnumerator(this, InnerList.GetEnumerator());
    }
    
    /// <summary>
    /// Gets or sets the element at the specified index.
    /// </summary>
    /// <param name="index">The zero-based index of the element to get or set.</param>
    /// <returns>The element at the specified index.</returns>
    object IList.this[int index] {
      get {
        return this[index];
      }
      set {
        throw new InvalidOperationException(
          "ValueTypeQueryResult is always read-only.");
      }
    }
    
    /// <summary>
    /// Always throws <see cref="InvalidOperationException"/>:
    /// <see cref="ValueTypeQueryResult"/> doesn't support this method.
    /// </summary>
    /// <param name="array">The one-dimensional Array that is the destination of the elements copied from collection. The Array must have zero-based indexing.</param>
    /// <param name="index">The zero-based index in array at which copying begins.</param>
    void ICollection.CopyTo(Array array, int index)
    {
      throw new InvalidOperationException(
        "ICollection.CopyTo isn't supported in ValueTypeQueryResult.");
    }
    
    /// <summary>
    /// Always throws <see cref="InvalidOperationException"/>:
    /// <see cref="ValueTypeQueryResult"/> doesn't support this method.
    /// </summary>
    /// <param name="value">Value to search for.</param>
    /// <returns><see langword="True"/> if the object is found; otherwise, <see langword="false"/>.</returns>
    bool IList.Contains(object value) 
    {
      throw new InvalidOperationException(
        "IList.Contains isn't supported in ValueTypeQueryResult.");
    }
    
    /// <summary>
    /// Always throws <see cref="InvalidOperationException"/>:
    /// <see cref="ValueTypeQueryResult"/> doesn't support this method.
    /// </summary>
    /// <param name="value">The value to locate.</param>
    /// <returns>The index of the first occurrence of value within the entire collection, if found; otherwise, -1.</returns>
    int  IList.IndexOf(object value)
    {
      throw new InvalidOperationException(
        "IList.IndexOf isn't supported in ValueTypeQueryResult.");
    }
    
    /// <summary>
    /// Always throws <see cref="InvalidOperationException"/>:
    /// <see cref="ValueTypeQueryResult"/> is always read-only.
    /// </summary>
    protected override void OnChange()
    {
      throw new InvalidOperationException(
        "ValueTypeQueryResult is always read-only.");
    }


    // Constructors

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="session">Session, to which this collection is bound.</param>
    /// <param name="field">Queried field.</param>
    /// <param name="culture">Culture of the queried field.</param>
    /// <param name="loadOnDemand"><see langword="True"/> if this result set was retrieved with
    /// <see cref="QueryOptions.LoadOnDemand"/> option;
    /// otherwise, <see langword="false"/>.</param>
    /// <param name="transactionContext">Transaction context.</param>
    /// <param name="queryResultData">List of <see cref="DictionaryEntry"/> objects.</param>
    internal ValueTypeQueryResult(
      Session session, 
      Field field, Culture culture, bool loadOnDemand,
      TransactionContext transactionContext,
      ArrayList queryResultData) : base(session)
    {
      this.field = field;
      this.culture = culture;
      this.loadOnDemand = loadOnDemand;
      this.transactionContext = transactionContext;
      InnerList = queryResultData;
      int cnt = queryResultData.Count;
      for (int i = 0; i<cnt; i++) {
        ValueTypeQueryResultEntry e = queryResultData[i] as ValueTypeQueryResultEntry;
        e.queryResult = this;
      }
    }
  }
}
