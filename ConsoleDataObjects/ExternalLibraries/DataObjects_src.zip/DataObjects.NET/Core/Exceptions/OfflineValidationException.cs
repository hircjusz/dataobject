// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Runtime.Serialization;
using Offline=DataObjects.NET.Offline;

namespace DataObjects.NET.Exceptions
{
  /// <summary>
  /// Thrown on any 
  /// <see cref="DataObjects.NET.Offline.IPropertyValueValidator">offline validation</see> errors.
  /// </summary>
  [Serializable]
  public class OfflineValidationException: DataObjectsDotNetException
  {
    private Offline.DataObject dataObject;
    private string             propertyName;
    private Offline.Culture    culture;
    private Offline.IPropertyValueValidator validator;
    
    /// <summary>
    /// Gets <see cref="DataObjects.NET.Offline.DataObject"/> instance which property caused
    /// this <see cref="ValidationException"/>.
    /// </summary>
    public Offline.DataObject DataObject {
      get {
        return dataObject;
      }
    }
  
    /// <summary>
    /// Gets name of the <see cref="DataObject"/> property that caused
    /// this exception.
    /// </summary>
    public string PropertyName {
      get {
        return propertyName;
      }
    }
  
    /// <summary>
    /// Gets <see cref="DataObjects.NET.Offline.Culture"/> of the <see cref="DataObject"/> property that caused
    /// this exception.
    /// </summary>
    public Offline.Culture Culture {
      get {
        return culture;
      }
    }
  
    /// <summary>
    /// Gets <see cref="DataObjects.NET.Offline.IPropertyValueValidator"/> instance of the <see cref="DataObject"/> property that caused
    /// this exception.
    /// </summary>
    public Offline.IPropertyValueValidator Validator {
      get {
        return validator;
      }
    }
  
    /// <summary>
    /// Serializer.
    /// </summary>
    /// <param name="info"><see cref="SerializationInfo"/> object.</param>
    /// <param name="context"><see cref="StreamingContext"/> object.</param>
    public override void GetObjectData(SerializationInfo info, StreamingContext context)
    {
      base.GetObjectData(info,context);
      info.AddValue("DataObject",dataObject);
      info.AddValue("PropertyName",propertyName);
      info.AddValue("Culture",culture);
      info.AddValue("Validator",validator);
    }


    // Constructors

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="dataObject"><see cref="DataObjects.NET.Offline.DataObject"/> instance which property caused
    /// this exception.</param>
    /// <param name="propertyName">Name of the <see cref="DataObject"/> property that caused
    /// this exception.</param>
    /// <param name="culture"><see cref="DataObjects.NET.Offline.Culture"/> of the <see cref="DataObject"/> property that caused
    /// this exception.</param>
    /// <param name="validator"><see cref="DataObjects.NET.Offline.IPropertyValueValidator"/> instance of the <see cref="DataObject"/> property that caused
    /// this exception.</param>
    /// <param name="innerException">Inner exception (an exception that was originally thrown by <paramref name="validator"/>).</param>
    /// <param name="text">Text of message.</param>
    public OfflineValidationException(Offline.DataObject dataObject, string propertyName, 
      Offline.Culture culture, Offline.IPropertyValueValidator validator, 
      string text, Exception innerException): base(text, innerException) 
    {
      this.dataObject = dataObject;
      this.propertyName = propertyName;
      this.culture = culture;
      this.validator = validator;
    }

    /// <summary>
    /// Deserialization constructor.
    /// </summary>
    /// <param name="info"><see cref="SerializationInfo"/> object.</param>
    /// <param name="context"><see cref="StreamingContext"/> object.</param>
    protected OfflineValidationException(SerializationInfo info, StreamingContext context):
      base(info, context)
    {
      dataObject = (Offline.DataObject)info.GetValue("DataObject",typeof(DataObject));
      propertyName = info.GetString("PropertyName");
      culture    = (Offline.Culture)info.GetValue("Culture",typeof(Culture));
      validator  = (Offline.IPropertyValueValidator)info.GetValue("Validator",typeof(object));
    }
  }
}
