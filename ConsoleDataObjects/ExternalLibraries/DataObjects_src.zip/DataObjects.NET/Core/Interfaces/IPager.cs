// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;

namespace DataObjects.NET
{
  /// <summary>
  /// Defines paging functionality to browse large 
  /// <see cref="IList">collections</see> page-by-page.
  /// <seealso cref="Pager"/>
  /// <seealso cref="QueryPager"/>
  /// </summary>
  public interface IPager: IList, ICollection, IEnumerable
  {

    /// <summary>
    /// Gets base <see cref="IList">collection</see> of this 
    /// <see cref="IPager"/> instance.
    /// </summary>
    System.Collections.IList BaseCollection { get; }

    /// <summary>
    /// Ensures that item with specified <paramref name="absoluteIndex"/> 
    /// is available in <see cref="BaseCollection"/>
    /// </summary>
    /// <param name="absoluteIndex">Absolute index of item.</param>
    void EnsureItemAvailability(int absoluteIndex);

    /// <summary>
    /// Gets or sets zero-based index of current page.
    /// </summary>
    int Page { get; set; }

    /// <summary>
    /// Gets count of pages that are browsed by
    /// this <see cref="IPager"/>.
    /// </summary>
    int PageCount { get; }

    /// <summary>
    /// Gets or sets page size.
    /// Default value of this property is <see langword="10"/>.
    /// </summary>
    int PageSize { get; set; }

    /// <summary>
    /// Reloads the <see cref="BaseCollection"/> and sets current 
    /// <see cref="Page"/> index to <see langword="0"/>.
    /// </summary>
    void Reload();

    /// <summary>
    /// Gets item with specified <paramref name="index"/>.
    /// </summary>
    /// <param name="index">Index of item to get.</param>
    /// <param name="indexIsAbsolute"><see langword="True"/> if specified
    /// <paramref name="index"/> is absolute; otheriwise <paramref name="index"/>
    /// is current page-based.</param>
    object this[int index, bool indexIsAbsolute] { get; set; }

    /// <summary>
    /// Returns an <see cref="Array"/> containing all items
    /// located on the current <see cref="Page"/>.
    /// </summary>
    /// <returns><see cref="Array"/> containing all items
    /// located on the current <see cref="Page"/>.</returns>
    Array ToArray();

    /// <summary>
    /// Gets or sets total count of items that are browsed by
    /// this <see cref="IPager"/>.
    /// </summary>
    int TotalCount { get; set; }
  }
}
