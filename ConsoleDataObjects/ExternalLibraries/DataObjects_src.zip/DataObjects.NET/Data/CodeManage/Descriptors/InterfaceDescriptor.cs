// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;
using System.Reflection;
#if !MONO
using EnvDTE;
#endif
using DataObjects.NET;

namespace DataObjects.NET.Data.CodeManage
{
  /// <summary>
  /// Describes an interface.
  /// </summary>
  internal class InterfaceDescriptor: IInterfaceDescriptor
  {
    private CodeManagerBase codeManager;
    private string name;
    private string dbName;
    private ICollectionDescriptor[] collections;
    private IFieldDescriptor[] fields;
    private IInterfaceDescriptor[] implements;
    
    /// <summary>
    /// Code manager.
    /// </summary>
    public CodeManagerBase CodeManager {
      get {
        return codeManager;
      }
    }
    
    /// <summary>
    /// Gets base type descriptor.
    /// </summary>
    public IClassDescriptor BaseType {
      get {
        return codeManager.Root;
      }
    }
    
    /// <summary>
    /// Gets child collections.
    /// </summary>
    public ICollectionDescriptor[] Collections {
      get{
        return collections;
      }
    }
    
    /// <summary>
    /// Gets child fields.
    /// </summary>
    public IFieldDescriptor[] Fields {
      get {
        return fields;
      }
    }
    
    /// <summary>
    /// Gets implemented interfaces.
    /// </summary>
    public IInterfaceDescriptor[] Implements {
      get {
        return implements;
      }
    }
    
    /// <summary>
    /// Element name.
    /// </summary>
    public string Name {
      get {
        return name;
      }
    }
    
    /// <summary>
    /// Element full name.
    /// </summary>
    public string FullName {
      get {
        return name;
      }
    }
    
    /// <summary>
    /// Element database name.
    /// </summary>
    /// <remarks>May be null.</remarks>
    public string DbName {
      get {
        return dbName;
      }
    }
    
    private bool filledImplementedInterfaces = false;
    
    private void UpdateInterfaceAfterFillImplementedInterfaces(bool isRuntime)
    {
      ArrayList collectionsList = new ArrayList(collections);
      ArrayList fieldsList = new ArrayList(fields);
      Hashtable descriptorByName = new Hashtable();
      foreach (IFieldDescriptor fd in fieldsList)
        descriptorByName[fd.Name] = fd;
      foreach (ICollectionDescriptor cd in collectionsList)
        descriptorByName[cd.Name] = cd;
      foreach (InterfaceDescriptor inter in implements) {
        #if MONO
          inter.Runtime_EnsureFillImplementedInterfaces();
        #else
        if (isRuntime)
          inter.Runtime_EnsureFillImplementedInterfaces();
        else
          inter.DesignTime_EnsureFillImplementedInterfaces();
        #endif
        foreach (IFieldDescriptor field in inter.Fields) {
          if (!descriptorByName.ContainsKey(field.Name)) {
            FieldDescriptor childField = (FieldDescriptor)((ICloneable)field).Clone();
            childField.SetParentFromContainer(this);
            fieldsList.Add(childField);
            descriptorByName[childField.Name] = childField;
          }
        }
        foreach (ICollectionDescriptor colDesc in inter.Collections) {
          if (!descriptorByName.ContainsKey(colDesc.Name)) {
            if (colDesc is ValueTypeCollectionDescriptor) {
              ValueTypeCollectionDescriptor vtcd = (ValueTypeCollectionDescriptor)colDesc;
              ValueTypeCollectionDescriptor vtcdClone = (ValueTypeCollectionDescriptor)((ICloneable)vtcd).Clone();
              vtcdClone.SetParentFromContainer(this);
              collectionsList.Add(vtcdClone);
              descriptorByName[vtcdClone.Name] = vtcdClone;
            } else if (colDesc is CollectionDescriptor) {
              CollectionDescriptor cd = (CollectionDescriptor)colDesc;
              CollectionDescriptor cdClone = (CollectionDescriptor)((ICloneable)cd).Clone();
              cdClone.SetParentFromContainer(this);
              collectionsList.Add(cdClone);
              descriptorByName[cdClone.Name] = cdClone;
            }
          }
        }
      }
      collections = (ICollectionDescriptor[])collectionsList.ToArray(typeof(ICollectionDescriptor));
      fields = (IFieldDescriptor[])fieldsList.ToArray(typeof(IFieldDescriptor));
    }
    
    /// <summary>
    /// This method should be called when the list of all interface descriptors is ready.
    /// Method call is allowed only in runtime.
    /// </summary>
    internal void Runtime_EnsureFillImplementedInterfaces()
    {
      if (!filledImplementedInterfaces) {
        RuntimeCodeManager rtcm = (RuntimeCodeManager)codeManager;
        ObjectModel.Type thisInterfaceType = rtcm.ObjectModel.Types[this.FullName];
        ArrayList implementsList = new ArrayList();
        foreach (ObjectModel.Type inter in thisInterfaceType.Interfaces) {
          IInterfaceDescriptor implInter = rtcm.GetInterface(inter.SourceType.FullName);
          if (implInter!=null)
            implementsList.Add(implInter);
        }
        implements = (IInterfaceDescriptor[])implementsList.ToArray(typeof(IInterfaceDescriptor));
        
        UpdateInterfaceAfterFillImplementedInterfaces(true);
        
        filledImplementedInterfaces = true;
      }
    }
    
    #if !MONO
    /// <summary>
    /// This method should be called when the list of all interface descriptors is ready.
    /// Method call is allowed only in design time.
    /// </summary>
    internal void DesignTime_EnsureFillImplementedInterfaces()
    {
      if (!filledImplementedInterfaces) {
        ArrayList implementsList = new ArrayList();
        ((DesigntimeCodeManager)codeManager).FillImplementedInterfaces(implementsList, name);
        implements = (IInterfaceDescriptor[])implementsList.ToArray(typeof(IInterfaceDescriptor));
        
        UpdateInterfaceAfterFillImplementedInterfaces(false);
        
        filledImplementedInterfaces = true;
      }
    }
    #endif
    
    /// <summary>
    /// Initializes a new instance of the <see cref="InterfaceDescriptor"/> class.
    /// </summary>
    /// <param name="thisInterface"><see cref="ObjectModel.Type"/> of interface.</param>
    /// <param name="codeManager"><see cref="RuntimeCodeManager"/>.</param>
    internal InterfaceDescriptor(ObjectModel.Type thisInterface, RuntimeCodeManager codeManager)
    {
      if (thisInterface==null)
        throw new ArgumentNullException("thisInterface");
      if (codeManager==null)
        throw new ArgumentNullException("codeManager");
        
      this.codeManager = codeManager;
      this.name = thisInterface.SourceType.FullName;
      this.dbName = thisInterface.DbName;

      ArrayList collectionsList = new ArrayList();
      ArrayList fieldsList = new ArrayList();  
      Hashtable propertyByName = new Hashtable();
      PropertyInfo[] properties = thisInterface.SourceType.GetProperties(BindingFlags.Public | BindingFlags.Instance);
      foreach (PropertyInfo property in properties) {
        if (!propertyByName.ContainsKey(property.Name)) {
          System.Type propertyType = property.PropertyType;
          if (propertyType==typeof(DataObjectCollection) || propertyType.IsSubclassOf(typeof(DataObjectCollection))) {
            CollectionDescriptor cd = new CollectionDescriptor(this, property);
            collectionsList.Add(cd);
          } else if (propertyType==typeof(ValueTypeCollection) || propertyType.IsSubclassOf(typeof(ValueTypeCollection))) {
            ValueTypeCollectionDescriptor vtcd = new ValueTypeCollectionDescriptor(this, property);
            collectionsList.Add(vtcd);
          } else {
            FieldDescriptor fd = new FieldDescriptor(this, property);
            fieldsList.Add(fd);
          }
          propertyByName[property.Name] = property;
        }
      }
      collections = (ICollectionDescriptor[])collectionsList.ToArray(typeof(ICollectionDescriptor));
      fields = (IFieldDescriptor[])fieldsList.ToArray(typeof(IFieldDescriptor));
    }

#if !MONO
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="thisInterface"><see cref="CodeInterface"/>.</param>
    /// <param name="codeManager"><see cref="DesigntimeCodeManager"/>.</param>
    internal InterfaceDescriptor(CodeInterface thisInterface, DesigntimeCodeManager codeManager)
    {
      if (thisInterface==null)
        throw new ArgumentNullException("thisInterface");
      if (codeManager==null)
        throw new ArgumentNullException("codeManager");
        
      this.codeManager = codeManager;
      this.name = thisInterface.FullName;
      
      int attributesCount = 0;
      try {
        attributesCount = thisInterface.Attributes.Count;
      } catch {}
      for (int i = 0; i < attributesCount; i++) {
        CodeElement attrElement = thisInterface.Attributes.Item(i + 1);
        if (attrElement.Kind==vsCMElement.vsCMElementAttribute) {
          CodeAttribute attr = (CodeAttribute)attrElement;
          if (attr.FullName=="DataObjects.NET.Attributes.DbNameAttribute") {
            string val = attr.Value;
            if (val.StartsWith("\"") && val.EndsWith("\"")) {
              dbName = val.Substring(1, val.Length - 2);
              break;
            }
          }
        }
      }
      
      ArrayList collectionsList = new ArrayList();
      ArrayList fieldsList = new ArrayList();
      Hashtable descriptorByName = new Hashtable();
      int membersCount = 0;
      try {
        membersCount = thisInterface.Members.Count;
      } catch {}
      for (int i = 0; i < membersCount; i++) {
        CodeElement element = thisInterface.Members.Item(i + 1);
        if (element.Kind==vsCMElement.vsCMElementProperty) {
          CodeProperty codeProperty = (CodeProperty)element;
          CodeType propertyType = null;
          if (codeProperty.Type.TypeKind==vsCMTypeRef.vsCMTypeRefCodeType)
            propertyType = codeProperty.Type.CodeType;
          if (propertyType!=null && DesigntimeCodeManager.IsTypeOrDescendantOf((CodeElement)propertyType, "DataObjects.NET.DataObjectCollection")) {
            if (!descriptorByName.ContainsKey(codeProperty.Name)) {
              ICollectionDescriptor collectionDescr = new CollectionDescriptor(this, codeProperty);
              collectionsList.Add(collectionDescr);
              descriptorByName[codeProperty.Name] = collectionDescr;
            }
          } else if (propertyType!=null && DesigntimeCodeManager.IsTypeOrDescendantOf((CodeElement)propertyType, "DataObjects.NET.ValueTypeCollection")) {
            if (!descriptorByName.ContainsKey(codeProperty.Name)) {
              IValueTypeCollectionDescriptor vtColDescr = new ValueTypeCollectionDescriptor(this, codeProperty);
              collectionsList.Add(vtColDescr);
              descriptorByName[codeProperty.Name] = vtColDescr;
            }
          } else {
            if (!descriptorByName.ContainsKey(codeProperty.Name)) {
              IFieldDescriptor fieldDescr = new FieldDescriptor(codeProperty.Name, this, propertyType, codeProperty.Attributes);
              fieldsList.Add(fieldDescr);
              descriptorByName[codeProperty.Name] = fieldDescr;
            }
          }
        }
      }
      collections = (ICollectionDescriptor[])collectionsList.ToArray(typeof(ICollectionDescriptor));
      fields = (IFieldDescriptor[])fieldsList.ToArray(typeof(IFieldDescriptor));
    }
#endif
  }
}
