// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.IO;
using System.Threading;
using System.Collections;
using System.Collections.Specialized;
using System.Text;
using System.Data;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Attributes;

namespace DataObjects.NET
{
  /// <summary>
  /// A collection of <see cref="QueryParameter"/>s for the 
  /// specific <see cref="Query"/> or <see cref="SqlQuery"/>.
  /// </summary>
  public sealed class QueryParameterCollection: MarshalByRefLockableCollectionBase
  {
    internal bool translated = true;


    // 'Typed' members
    
    /// <summary>
    /// Gets or sets the parameter with specified index.
    /// </summary>
    public QueryParameter this[int n] {
      get {
        return (QueryParameter)List[n];
      }
      set {
        List[n] = value;
      }
    }
    
    /// <summary>
    /// Gets or sets the parameter with specified name.
    /// </summary>
    public QueryParameter this[string parameterName] {
      get {
        foreach (QueryParameter p in List)
          if (p.ParameterName==parameterName)
            return p;
        return null;
      }
      set {
        for (int i = 0; i < List.Count; i++)
          if (((QueryParameter)List[i]).ParameterName==parameterName) {
            List[i] = value;
            return;
          }
        List.Add(value);
      }
    }
    
    /// <summary>
    /// Adds an empty <see cref="QueryParameter"/> to the collection.
    /// </summary>
    public QueryParameter Add()
    {
      QueryParameter param = new QueryParameter();
      List.Add(param);
      return param;
    }

    /// <summary>
    /// Adds an <see cref="QueryParameter"/> with the specified name.
    /// </summary>
    /// <param name="parameterName">Parameter name.</param>
    public QueryParameter Add(string parameterName)
    {
      QueryParameter param = new QueryParameter();
      param.ParameterName = parameterName;
      List.Add(param);
      return param;
    }

    /// <summary>
    /// Adds an <see cref="QueryParameter"/> with the specified name and <see cref="System.Data.DbType"/>.
    /// </summary>
    /// <param name="parameterName">Parameter name.</param>
    /// <param name="dbType"> One of the <see cref="System.Data.DbType"/> values.</param>
    public QueryParameter Add(string parameterName, DbType dbType) 
    {
      QueryParameter param = new QueryParameter();
      param.ParameterName = parameterName;
      param.DbType = dbType;
      List.Add(param);
      return param;
    }

    /// <summary>
    /// Adds an <see cref="QueryParameter"/> with the specified name and value.
    /// </summary>
    /// <param name="parameterName">Parameter name.</param>
    /// <param name="value">Parameter value.</param>
    public QueryParameter Add(string parameterName, object value)
    {
      QueryParameter param = new QueryParameter(parameterName, value);
      List.Add(param);
      return param;
    }

    /// <summary>
    /// Adds new parameter to this collection. If element with the same
    /// name is already exists in this collection, <see cref="InvalidOperationException"/>
    /// will be thrown.
    /// </summary>
    /// <param name="parameter">QueryParameter to add.</param>
    public int Add(QueryParameter parameter)
    {
      return List.Add(parameter);
    }
    
    /// <summary>
    /// Determines whether collection contains specified parameter.
    /// </summary>
    /// <param name="parameter">QueryParameter to search for.</param>
    /// <returns><see langword="True"/> if parameter was found.</returns>
    public bool Contains(QueryParameter parameter)
    {
      return List.Contains(parameter);
    }

    /// <summary>
    /// Copies elements of this collection to <see cref="Array"/>.
    /// </summary>
    /// <param name="parameters">Destination array.</param>
    /// <param name="offset">Offset in array to start from.</param>
    public void CopyTo(QueryParameter[] parameters, int offset)
    {
      List.CopyTo(parameters, offset);
    }

    /// <summary>
    /// Searches for the specified object and returns the index of the first occurrence within the current instance.
    /// </summary>
    /// <param name="parameter">The object to locate.</param>
    /// <returns>The index of the first occurrence of value within the entire collection, if found; otherwise, -1.</returns>
    public int IndexOf(QueryParameter parameter)
    {
      return List.IndexOf(parameter);
    }

    /// <summary>
    /// Inserts parameter to collection.
    /// </summary>
    /// <param name="offset">Offset of parameter.</param>
    /// <param name="parameter">QueryParameter to insert.</param>
    public void Insert(int offset, QueryParameter parameter)
    {
      List.Insert(offset, parameter);
    }

    /// <summary>
    /// Removes parameter from collection.
    /// </summary>
    /// <param name="parameter">QueryParameter to remove.</param>
    public void Remove(QueryParameter parameter)
    {
      List.Remove(parameter);
    }
    
    
    // 'Untyped' methods

    /// <summary>
    /// Performs additional custom processes before clearing the contents of the 
    /// <see cref="QueryParameterCollection"/> instance.
    /// </summary>
    protected override void OnClear()
    {
      foreach (QueryParameter p in List)
        p.InternalBind(null);
    }
    
    /// <summary>
    /// Performs additional custom processes before inserting a new element into the
    /// <see cref="QueryParameterCollection"/> instance.
    /// </summary>
    /// <param name="index">The zero-based <paramref name="index"/> at which to insert value.</param>
    /// <param name="value">The new value of the element at <paramref name="index"/>.</param>
    protected override void OnInsert(int index, Object value) 
    {
      if (value==null)
        throw new ArgumentNullException("value");
      QueryParameter t = (QueryParameter)value;
      t.InternalBind(this);
    }
    
    /// <summary>
    /// Performs additional custom processes before removing a new element into the
    /// <see cref="QueryParameterCollection"/> instance.
    /// </summary>
    /// <param name="index">The zero-based <paramref name="index"/> at which to insert value.</param>
    /// <param name="value">The value of the element to remove from <paramref name="index"/>.</param>
    protected override void OnRemove(int index, Object value) 
    {
      QueryParameter t = (QueryParameter)value;
      t.InternalBind(null);
    }
    
    /// <summary>
    /// Performs additional custom processes before setting a value in the
    /// <see cref="QueryParameterCollection"/> instance.
    /// </summary>
    /// <param name="index">The zero-based <paramref name="index"/> at which <paramref name="oldValue"/> can be found.</param>
    /// <param name="oldValue">The value to replace with <paramref name="newValue"/>.</param>
    /// <param name="newValue">The new value of the element at <paramref name="index"/>.</param>
    protected override void OnSet(int index, Object oldValue, Object newValue)
    {
      if (newValue==null)
        throw new ArgumentNullException("newValue");
      QueryParameter ot = (QueryParameter)oldValue;
      QueryParameter t  = (QueryParameter)newValue;
      ot.InternalBind(null);
      t.InternalBind(this);
    }
    

    // Constructors

    internal QueryParameterCollection()
    {
    }
  }
}
