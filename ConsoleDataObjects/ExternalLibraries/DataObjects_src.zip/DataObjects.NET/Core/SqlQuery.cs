// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using DataObjects.NET.Exceptions;
using DataObjects.NET.FullText;
using DataObjects.NET.FullText.Drivers.Native;

namespace DataObjects.NET
{
  /// <summary>
  /// Allows to select a set of <see cref="DataObject"/> instances 
  /// (or its descendants) from the database by the SQL criteria.
  /// </summary>
  /// <remarks>
  /// <example>Example:
  /// <code lang="C#">
  ///  d = new Domain("mssql://localhost/DataObjectsDotNetDemos", myProductKey);
  ///  d.RegisterCulture(new Culture("En",  "U.S. English", new CultureInfo("en-us", false)));
  ///  d.Cultures["En"].Default = true;
  ///  d.RegisterTypes("MyApp.PersistentModel");
  ///  d.RegisterServices("MyApp.PersistentModel");
  ///  d.Build(DomainUpdateMode.Perform);
  ///  using (Session s = d.CreateSession()) {
  ///    s.BeginTransaction();
  ///      
  ///    SqlQuery q = new SqlQuery(s,typeof(Author));
  ///    q.Top = 10;
  ///    q.Condition = "\"Name-En\" like 'Alex%'";
  ///    QueryResult authors = q.Execute();
  ///    foreach (Author a in authors)
  ///      Console.WriteLine(a.Name);
  ///
  ///    s.Commit();
  ///  }
  /// </code>
  /// </example>
  /// <seealso cref="DataObjects.NET.Session.CreateQuery"/>
  /// </remarks>
  public sealed class SqlQuery: QueryBase
  {
    private  string condition = "";
    private  string orderBy   = "";

    /// <summary>
    /// Gets or sets "where" expression in the underlying select statement.
    /// If both <see cref="Condition"/> and <see cref="FtsCondition"/>
    /// are specified, they are concidered to be AND-associated.
    /// </summary>
    public string Condition {
      get {return condition;}
      set {
        if (value==null)
          throw new ArgumentNullException("Condition");
        translated = false;
        condition  = value;
      }
    }

    /// <summary>
    /// Gets or sets "order by" expression in the underlying select statement.
    /// Important: read remarks section.
    /// </summary>
    /// <remarks>
    /// <para>DataObjects.NET uses simple SQL validation algorithm allowing to prevent
    /// malicious code injection (code like "; drop table [ndsDataObject]").
    /// This algorithm can check only an order by clauses where all
    /// expressions are embraced. If this algorithm detects some expression
    /// that is not embraced, it considers it as error and throws <see cref="InvalidSqlException"/>.</para>
    /// <para>So in general the value of <see cref="OrderBy"/> should have the following
    /// format: (Expression) [asc|desc] [, (Expression) [asc|desc]][,..n]</para>
    /// <para>Examples:</para>
    /// <list type="table">
    /// <listheader><term>Example</term><description>Description</description></listheader>
    /// <item><term>(ID)</term><description>Order by ID.</description></item>
    /// <item><term>("FullTextRank") desc, ("Name-En")</term><description>Order by "FullTextRank" desc, "Name-En".</description></item>
    /// <item><term>([FullTextRank]) desc, ([Name-En])</term><description>The same (valid only for Microsoft SQL Server).</description></item>
    /// </list>
    /// </remarks>
    public string OrderBy {
      get {return orderBy;}
      set {
        if (value==null)
          throw new ArgumentNullException("OrderBy");
        translated = false;
        orderBy = value;
      }
    }

    /// <summary>
    /// Gets or sets full-text search condition in the underlying select statement.
    /// If both <see cref="Condition"/> and <see cref="FtsCondition"/>
    /// are specified, they are concidered to be AND-associated.
    /// </summary>
    public FtsCondition FtsCondition {
      get {return ftsCondition;}
      set {
        if (ftsCondition==value)
          return;
        if (value!=null) {
          if (value.session!=null && value.session!=session)
            throw new InvalidOperationException("FtsCondition instance is already used by another session.");
          Domain d = session.domain;
          Culture c = value.Culture;
          if (c!=null)
            if (d.Cultures[c.Name]!=c)
              throw new InvalidOperationException("Culture isn't registered in the Domain.");
          value.session   = session;
        }
        if (ftsCondition!=null)
          ftsCondition.session = null;
        ftsCondition = value;
        translated = false;
      }
    }

    /// <summary>
    /// Creates new <see cref="FtsCondition"/>.
    /// </summary>
    /// <param name="type">The <see cref="ObjectModel.Type"/> of the requested objects.</param>
    /// <param name="culture">Culture (specify if field is translatable).</param>
    /// <param name="mode">Search mode.</param>
    /// <param name="condition">Search string\condition (depends on <paramref name="mode"/>).</param>
    /// <param name="topNByRank">Top-b-by-rank value, 0 means all.</param>
    public void CreateFtsCondition(
      ObjectModel.Type type,
      Culture culture,
      FtsMode mode,
      string condition,
      int topNByRank)
    {
      this.FtsCondition = new FtsCondition(type, culture, mode, condition, topNByRank);
    }
    
    /// <summary>
    /// Creates new <see cref="FtsCondition"/>.
    /// </summary>
    /// <param name="type">The <see cref="ObjectModel.Type"/> of the requested objects.</param>
    /// <param name="culture">Culture (specify if field is translatable).</param>
    /// <param name="mode">Search mode.</param>
    /// <param name="condition">Search string\condition (depends on <paramref name="mode"/>).</param>
    public void CreateFtsCondition(
      ObjectModel.Type type,
      Culture culture,
      FtsMode mode,
      string condition)
    {
      this.FtsCondition = new FtsCondition(type, culture, mode, condition);
    }

    /// <summary>
    /// Creates new <see cref="FtsCondition"/>.
    /// </summary>
    /// <param name="type">The <see cref="ObjectModel.Type"/> of the requested objects.</param>
    /// <param name="mode">Search mode.</param>
    /// <param name="condition">Search string\condition (depends on <paramref name="mode"/>).</param>
    /// <param name="topNByRank">Top-b-by-rank value, 0 means all.</param>
    public void CreateFtsCondition(
      ObjectModel.Type type,
      FtsMode mode,
      string condition,
      int topNByRank)
    {
      this.FtsCondition = new FtsCondition(type, mode, condition, topNByRank);
    }

    /// <summary>
    /// Creates new <see cref="FtsCondition"/>.
    /// </summary>
    /// <param name="type">The <see cref="ObjectModel.Type"/> of the requested objects.</param>
    /// <param name="mode">Search mode.</param>
    /// <param name="condition">Search string\condition (depends on <paramref name="mode"/>).</param>
    public void CreateFtsCondition(
      ObjectModel.Type type,
      FtsMode mode,
      string condition)
    {
      this.FtsCondition = new FtsCondition(type, mode, condition);
    }
    
    /// <summary>
    /// Creates new <see cref="FtsCondition"/>.
    /// </summary>
    /// <param name="culture">Culture (specify if field is translatable).</param>
    /// <param name="mode">Search mode.</param>
    /// <param name="condition">Search string\condition (depends on <paramref name="mode"/>).</param>
    /// <param name="topNByRank">Top-b-by-rank value, 0 means all.</param>
    public void CreateFtsCondition(
      Culture culture,
      FtsMode mode,
      string condition,
      int topNByRank)
    {
      this.FtsCondition = new FtsCondition(culture, mode, condition, topNByRank);
    }
    
    /// <summary>
    /// Creates new <see cref="FtsCondition"/>.
    /// </summary>
    /// <param name="culture">Culture (specify if field is translatable).</param>
    /// <param name="mode">Search mode.</param>
    /// <param name="condition">Search string\condition (depends on <paramref name="mode"/>).</param>
    public void CreateFtsCondition(
      Culture culture,
      FtsMode mode,
      string condition)
    {
      this.FtsCondition = new FtsCondition(culture, mode, condition);
    }

    /// <summary>
    /// Creates new <see cref="FtsCondition"/>.
    /// </summary>
    /// <param name="mode">Search mode.</param>
    /// <param name="condition">Search string\condition (depends on <paramref name="mode"/>).</param>
    /// <param name="topNByRank">Top-b-by-rank value, 0 means all.</param>
    public void CreateFtsCondition(
      FtsMode mode,
      string condition,
      int topNByRank)
    {
      this.FtsCondition = new FtsCondition(mode, condition, topNByRank);
    }

    /// <summary>
    /// Creates new <see cref="FtsCondition"/>.
    /// </summary>
    /// <param name="mode">Search mode.</param>
    /// <param name="condition">Search string\condition (depends on <paramref name="mode"/>).</param>
    public void CreateFtsCondition(
      FtsMode mode,
      string condition)
    {
      this.FtsCondition = new FtsCondition(mode, condition);
    }
    
    /// <summary>
    /// Translates the query.
    /// </summary>
    protected override void Translate()
    {
      if (translated)
        return;
      BuildCommand(condition, ftsCondition, orderBy, pageInformation);
    }

    /// <summary>
    /// Updates the text of the command (basically to
    /// reflect changes in the Options collection).
    /// </summary>
    protected override void UpdateTranslation()
    {
      UpdateCommand(condition, ftsCondition, orderBy, pageInformation);
    }

    /// <summary>
    /// Returns <see langword="true"/> when query contains dynamic part
    /// and should be rebuilt on each execution.
    /// </summary>
    /// <returns><see langword="True"/> when query contains dynamic part
    /// and should be rebuilt on each execution.</returns>
    protected override bool HasDynamicRestriction()
    {
      return 
        ftsCondition!=null && 
        !(Domain.FtsDriver is NativeFtsDriver);
    }

    // Constructors
    
    /// <summary>
    /// Initializes an instance of this class.
    /// <seealso cref="DataObjects.NET.Session.CreateQuery"/>
    /// </summary>
    /// <param name="session">Session, to which this query belongs.</param>
    /// <param name="instanceType">The type of object (including its descendants) to search.</param>
    public SqlQuery(Session session, System.Type instanceType): base(session, instanceType)
    {
    }
    
    /// <summary>
    /// Initializes an instance of this class.
    /// <seealso cref="DataObjects.NET.Session.CreateQuery"/>
    /// </summary>
    /// <param name="session">Session, to which this query belongs.</param>
    public SqlQuery(Session session): base(session, typeof(DataObject))
    {
    }
  }
}
