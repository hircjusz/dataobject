// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using DataObjects.NET.Data;

namespace DataObjects.NET.Data.Design
{
  /// <summary>
  /// Editor for the interface mapping collections.
  /// </summary>
  public class InterfaceMappingCollectionEditor: MappingCollectionEditorBase
  {
    /// <summary>
    /// Initializes a new instance of the <see cref="InterfaceMappingCollectionEditor"/> class.
    /// </summary>
    public InterfaceMappingCollectionEditor(): base(typeof(InterfaceMappingCollection), typeof(InterfaceMappingItem))
    {
    }
  }
}
