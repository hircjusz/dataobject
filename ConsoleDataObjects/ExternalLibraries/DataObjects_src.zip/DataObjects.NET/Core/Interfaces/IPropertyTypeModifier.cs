// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using DataObjects.NET.Attributes;

namespace DataObjects.NET
{
  /// <summary>
  /// Allows to associate different internal type (in comparison 
  /// with actual property type) that should be used to internally 
  /// store a <see cref="DataObject"/> property. 
  /// For example, it allows to expose some property as object, but internally 
  /// store it as string.
  /// <seealso cref="TypeModifierAttribute"/>
  /// </summary>
  /// <remarks>
  /// See <see cref="TypeModifierAttribute"/> also.
  /// </remarks>
  public interface IPropertyTypeModifier
  {
    /// <summary>
    /// Converts external property value (value that is returned by 
    /// <see cref="DataObject.GetProperty">DataObject.GetProperty</see> method)
    /// to its internal representation.
    /// </summary>
    /// <param name="dataObject"><see cref="DataObject"/> instance
    /// which property is converted.</param>
    /// <param name="propertyName">Property name.</param>
    /// <param name="culture">Property culture.</param>
    /// <param name="value">External property value.</param>
    /// <returns>Internal property value.</returns>
    /// <remarks>
    /// <note type="note">This method should be completely thread-safe 
    /// (it should be possible to invoke this method on a single instance
    /// of class that implements it from multiple threads simultaneously).</note>
    /// </remarks>
    object ConvertToInternalValue(DataObject dataObject, string propertyName, Culture culture, object value);

    /// <summary>
    /// Converts internal property value to its external representation (value 
    /// that is returned by <see cref="DataObject.GetProperty">DataObject.GetProperty</see> method).
    /// </summary>
    /// <param name="dataObject"><see cref="DataObject"/> instance
    /// which property is converted.</param>
    /// <param name="propertyName">Property name.</param>
    /// <param name="culture">Property culture.</param>
    /// <param name="value">Internal property value.</param>
    /// <returns>External property value.</returns>
    /// <remarks>
    /// <note type="note">This method should be completely thread-safe 
    /// (it should be possible to invoke this method on a single instance
    /// of class that implements it from multiple threads simultaneously).</note>
    /// </remarks>
    object ConvertFromInternalValue(DataObject dataObject, string propertyName, Culture culture, object value);

    /// <summary>
    /// Gets <see cref="System.Type"/> specifying internal type of property.
    /// </summary>
    /// <remarks>
    /// <note type="note">This method should be completely thread-safe 
    /// (it should be possible to invoke this method on a single instance
    /// of class that implements it from multiple threads simultaneously).</note>
    /// </remarks>
    System.Type InternalType {get;}
  }
}
