// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;

namespace DataObjects.NET
{
  internal class HeapTable
  {
    private IDictionary Table;
    private ArrayList Heap = new ArrayList();
    private IComparer OrderComparer;

    public HeapTable()
    {
      Table = new Hashtable();
      OrderComparer = Comparer.Default;
    }

    public HeapTable(IDictionary Table)
    {
      this.Table = Table;
      OrderComparer = Comparer.Default;
    }

    public HeapTable(IDictionary Table, IComparer OrderComparer)
    {
      this.Table = Table;
      this.OrderComparer = OrderComparer;
    }

    public object this[object key]
    {
      get {
        HeapEntry entry = (HeapEntry)Table[key];
        if (entry==null)
          return null;
        return entry.Value;
      }
      set {
        HeapEntry entry = (HeapEntry)Table[key];
        if (entry==null)
          return;
        entry.Value = value;
      }
    }

    public bool Contains(object key)
    {
      return Table.Contains(key);
    }

    public object Min
    {
      get {
        if (Heap.Count==0)
          return null;
        HeapEntry entry = (HeapEntry)Heap[0];
        return entry.Value;
      }
    }

    public object MinKey
    {
      get {
        if (Heap.Count==0)
          return null;
        HeapEntry entry = (HeapEntry)Heap[0];
        return entry.Key;
      }
    }

    public object MinOrder
    {
      get {
        if (Heap.Count==0)
          return null;
        HeapEntry entry = (HeapEntry)Heap[0];
        return entry.Order;
      }
    }

    public int Count
    {
      get {
        return Table.Count;
      }
    }

    public void Add(object key, object order, object value)
    {
      if (Contains(key))
        Remove(key);
      HeapEntry entry = new HeapEntry();
      Table.Add(key, entry);
      entry.Key = key;
      entry.Order = order;
      entry.Value = value;
      entry.Index = Heap.Count;
      Heap.Add(entry);
      SiftUp(entry.Index);
    }

    public object GetOrder(object key)
    {
      HeapEntry entry = (HeapEntry)Table[key];
      return entry.Order;
    }

    public void SetOrder(object key, object order)
    {
      HeapEntry entry = (HeapEntry)Table[key];
      entry.Order = order;
      SiftDown(entry.Index);
      SiftUp(entry.Index);
    }

    public void Remove(object key)
    {
      HeapEntry entry = (HeapEntry)Table[key];
      if (entry != null)
        _RemoveAt(entry.Index);
    }

    public void Pop()
    {
      _RemoveAt(0);
    }

    private void _RemoveAt(int Index)
    {
      HeapEntry entry = (HeapEntry)Heap[Index];
      Table.Remove(entry.Key);
      Swap(Index, Heap.Count - 1);
      Heap.RemoveAt(Heap.Count - 1);
      if (Index < Heap.Count)
      {
        SiftDown(Index);
        SiftUp(Index);
      }
      entry.Index = -1;
    }

    public void Clear()
    {
      Table.Clear();
      Heap.Clear();
    }

    private void SiftDown(int i)
    {
      int j, k;
      k = i;
      do
      {
        j = (i << 1) + 1;
        if (j < Heap.Count && OrderComparer.Compare(((HeapEntry)Heap[k]).Order, ((HeapEntry)Heap[j]).Order) > 0)
          k = j;
        j = (i + 1) << 1;
        if (j < Heap.Count && OrderComparer.Compare(((HeapEntry)Heap[k]).Order, ((HeapEntry)Heap[j]).Order) > 0)
          k = j;
        if (k==i)
          return;
        Swap(i, k);
        i = k;
      }
      while (true);
    }

    private void SiftUp(int i)
    {
      int j;
      do
      {
        if (i==0)
          return;
        j = (i - 1) >> 1;
        if (OrderComparer.Compare(((HeapEntry)Heap[i]).Order, ((HeapEntry)Heap[j]).Order) >= 0)
          return;
        Swap(i, j);
        i = j;
      }
      while (true);
    }

    private void Swap(int a, int b)
    {
      object temp;
      temp = Heap[a];
      Heap[a] = Heap[b];
      Heap[b] = temp;
      ((HeapEntry)Heap[a]).Index = a;
      ((HeapEntry)Heap[b]).Index = b;
    }
  }

  internal class HeapEntry
  {
    public object Key;
    public object Order;
    public object Value;
    public int Index;
  }
}
