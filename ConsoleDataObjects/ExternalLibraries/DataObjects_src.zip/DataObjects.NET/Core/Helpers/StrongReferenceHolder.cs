// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;
using System.Collections.Specialized;

namespace DataObjects.NET.Helpers
{
  /// <summary>
  /// This class acts almost like a <see cref="Hashtable"/>, but doesn't
  /// allow to access any of <see cref="Hashtable.Values"/>.
  /// </summary>
  #if (!NoMBR)
  public sealed class StrongReferenceHolder: MarshalByRefObject 
  #else
  public sealed class StrongReferenceHolder: Object
  #endif
  {
    internal IDictionary items = new HybridDictionary();

    /// <summary>
    /// Adds a reference to <paramref name="obj"/> into 
    /// internal <see cref="Hashtable"/>, and associates
    /// it with <paramref name="key"/>.
    /// </summary>
    /// <param name="key">Key allowing to remove a reference to <paramref name="obj"/> further.</param>
    /// <param name="obj">Object to add a reference to.</param>
    public void AddReference(object key, object obj) 
    {
      items[key] = obj;
    }
  
    /// <summary>
    /// Removes a reference associated with <paramref name="key"/>.
    /// </summary>
    /// <param name="key">Key of reference to remove.</param>
    public void RemoveReference(object key) 
    {
      items.Remove(key);
    }

    /// <summary>
    /// Determines whether this instance contains a reference associated 
    /// with <paramref name="key"/>.
    /// </summary>
    /// <param name="key">Key of reference to check.</param>
    public bool Contains(object key) 
    {
      return items.Contains(key);
    }

    /// <summary>
    /// Appends a content of another <see cref="StrongReferenceHolder"/>
    /// to this instance.
    /// </summary>
    /// <param name="unionWith"><see cref="StrongReferenceHolder"/> to append.</param>
    public void Union(StrongReferenceHolder unionWith) 
    {
      foreach (DictionaryEntry e in unionWith.items)
        items[e.Key] = e.Value;
    }

    
    // Constructors
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    public StrongReferenceHolder() 
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="firstKey">First key.</param>
    /// <param name="firstValue">First value.</param>
    public StrongReferenceHolder(object firstKey, object firstValue) 
    {
      AddReference(firstKey, firstValue);
    }
  }
}
