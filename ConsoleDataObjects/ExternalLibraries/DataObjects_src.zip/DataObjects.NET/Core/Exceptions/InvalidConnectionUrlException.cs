// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Runtime.Serialization;

namespace DataObjects.NET.Exceptions
{
  /// <summary>
  /// Thrown by <see cref="ConnectionInfo"/> on attempts to set 
  /// invalid <see cref="ConnectionInfo.Url"/> value.
  /// </summary>
  [Serializable]
  public class InvalidConnectionUrlException: DataObjectsDotNetException
  {
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    public InvalidConnectionUrlException(): base("Invalid connection URL.") {}
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="text">Text of message.</param>
    public InvalidConnectionUrlException(string text): base(text) {}
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="innerException">Inner exception.</param>
    public InvalidConnectionUrlException(Exception innerException): base("Invalid connection URL.",innerException) {}
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="text">Text of message.</param>
    /// <param name="innerException">Inner exception.</param>
    public InvalidConnectionUrlException(string text, Exception innerException): base(text,innerException) {}

    /// <summary>
    /// Deserialization constructor.
    /// </summary>
    /// <param name="info"><see cref="SerializationInfo"/> object.</param>
    /// <param name="context"><see cref="StreamingContext"/> object.</param>
    protected InvalidConnectionUrlException(SerializationInfo info, StreamingContext context):
      base(info, context)
    {
    }
  }
}
