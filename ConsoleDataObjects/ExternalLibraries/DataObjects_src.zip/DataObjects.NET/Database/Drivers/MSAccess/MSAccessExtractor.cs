// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Text;
using System.Text.RegularExpressions;
using System.Collections;
using System.Collections.Specialized;
using System.Diagnostics;
using System.Data;
using System.Data.OleDb;
using DataObjects.NET.DatabaseModel;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Database.ExtractedInfo;
using Constraint = DataObjects.NET.DatabaseModel.Constraint;
using ForeignKeyConstraint = DataObjects.NET.DatabaseModel.ForeignKeyConstraint;

namespace DataObjects.NET.Database.Drivers.MSAccess
{
  /// <summary>
  /// Microsoft Access implementation of <see cref="Extractor"/>.
  /// </summary>
  public class MSAccessExtractor: Extractor 
  {
    private HybridDictionary dbTypes;

    /// <summary>
    /// Gets a list of all essential tables from the database.
    /// </summary>
    /// <returns>An array of strings containing table names.</returns>
    public override string[] GetAllTables() 
    {
      ArrayList allTables = new ArrayList();
      string prefix = Driver.NamingManager.IdentifierPrefix.ToUpper();

      try 
      {        
        DataTable schema = ((OleDbConnection)Connection).GetOleDbSchemaTable( OleDbSchemaGuid.Tables, new object[0] );
        
        DataColumn tableTypeColumn = schema.Columns[ "TABLE_TYPE" ];
        DataColumn tableNameColumn = schema.Columns[ "TABLE_NAME" ];
        
        foreach( DataRow schemaRow in schema.Rows )
        {
          if (string.Compare(schemaRow[tableTypeColumn].ToString(), "TABLE" )==0) {
            string tbname = schemaRow[ tableNameColumn ].ToString();
            if (tbname.Length>=prefix.Length)
              if (tbname.Substring(0,prefix.Length).ToUpper()==prefix)
                allTables.Add(tbname);
          }
        }
      }
      catch (Exception e) 
      {
        throw new DatabaseModelExtractorException("Couldn't get the tables to extract model.",e);  
      }
      return (string[])allTables.ToArray(typeof(string));
    }

    /// <summary>
    /// Gets a list of all essential views from the database.
    /// </summary>
    /// <returns>An array of strings containing <see cref="ViewProperties"/>.</returns>
    public override ViewProperties[] GetAllViews() 
    {
      ArrayList allViews = new ArrayList();
      string prefix = Driver.NamingManager.IdentifierPrefix.ToUpper();

      try 
      {        
        DataTable schema = ((OleDbConnection)Connection).GetOleDbSchemaTable( OleDbSchemaGuid.Views, new object[0] );
        DataColumn viewNameColumn = schema.Columns[ "TABLE_NAME" ];
        DataColumn viewDefColumn = schema.Columns[ "VIEW_DEFINITION" ];
        foreach( DataRow schemaRow in schema.Rows )
        {
          ViewProperties newvp = new ViewProperties();
          newvp.Name = schemaRow[ viewNameColumn ].ToString();
          newvp.DefinitionText = schemaRow[ viewDefColumn ].ToString();
          if (newvp.Name.Length>=prefix.Length)
            if (newvp.Name.Substring(0,prefix.Length).ToUpper()==prefix)
              allViews.Add(newvp);
        }
      }
      catch (Exception e) 
      {
        throw new DatabaseModelExtractorException("Couldn't get views on extraction of database model ("+e.Message+").",e);
      }
      return (ViewProperties[])allViews.ToArray(typeof(ViewProperties));
    }

    /// <summary>
    /// Get a list of all indexes from the specified table.
    /// </summary>
    /// <param name="table">The name of the table to extract indexes from.</param>
    /// <returns>An array of <see cref="IndexProperties"/> objects describing all indexes.</returns>
    public override IndexProperties[] GetAllIndexes(string table) 
    {
      try
      {
        ArrayList allIndexes =  new ArrayList();

        DataTable schema = ((OleDbConnection)Connection).GetOleDbSchemaTable( OleDbSchemaGuid.Indexes, new object[]{} );
        //DumpTable(schema);
        
        DataColumn tableTypeColumn = schema.Columns[ "TABLE_TYPE" ];
        DataColumn tableNameColumn = schema.Columns[ "TABLE_NAME" ];
        DataColumn indexNameColumn = schema.Columns[ "INDEX_NAME" ];
        DataColumn isPrimaryKeyColumn = schema.Columns[ "PRIMARY_KEY" ];
        DataColumn isUniqueColumn = schema.Columns[ "UNIQUE" ];
        DataColumn columnNameColumn = schema.Columns[ "COLUMN_NAME" ];
        DataColumn columnPositionColumn = schema.Columns[ "ORDINAL_POSITION" ];
        
        /* sort order not currently used
        DataColumn sortDirectionColumn = schema.Columns[ "COLLATION" ];
        const int SORT_ASCENDING = 1;
        const int SORT_DESCENTING = 2;
        */

        // Access indexes are stored one row per index column in the schema table.
        // The "ORDINAL_POSITION" value (1-based) indicates the placement of the column within the index.
        // Sort the schema data to ensure the columns are encountered in order, to simplify things.
        schema.DefaultView.Sort = indexNameColumn.ColumnName + "," + columnPositionColumn.ColumnName;
        schema.DefaultView.RowFilter = tableNameColumn.ColumnName + " = '" + table + "'";

        HybridDictionary indexDictionary = new HybridDictionary();        
        int allIndexesIndex;
        foreach( DataRowView schemaRow in schema.DefaultView )
        {
          IndexProperties indexProperties;

          string indexName = schemaRow[indexNameColumn.Ordinal].ToString();

          if (indexDictionary[indexName] == null) {
            // Since multi-column indexes all share the same base values,
            // set the common index properties on the first occurence only
            indexProperties =  new IndexProperties();
            indexProperties.Name = indexName;
            indexProperties.IsPrimary = (bool)schemaRow[isPrimaryKeyColumn.Ordinal];
            indexProperties.IsUnique = (bool)schemaRow[isUniqueColumn.Ordinal];
            indexProperties.FillFactor = 0; // Access doesn't support fillfactor
            indexProperties.IsFullText = false;
            if (indexProperties.IsPrimary )
            {
              indexProperties.IsClustered = true; // Access doesn't actually support clustered, but DO generates primary indexes as Clustered
            }
            else
            {
              indexProperties.IsClustered = false;
            }
            indexProperties.Columns = new string[0];

            allIndexesIndex = allIndexes.Add( indexProperties );
            indexDictionary[indexName] = allIndexesIndex;
          }
          else
          {
            allIndexesIndex = (int)indexDictionary[indexName];
            indexProperties = (IndexProperties) allIndexes[allIndexesIndex];

            // Because of boxing/unboxing of the IndexProperties struct,
            // allIndex.IndexOf doesn't work, so need to manually search
            // for the index
//            allIndexesIndex = -1;
//            for(int index = 0; index < allIndexes.Count; index++) {
//              if (((IndexProperties)allIndexes[index]).Name==indexName) {
//                allIndexesIndex = index;
//                break;
//              }
//            }
          }
            
          // Transfer the previous list of columns into an ArrayList
          ArrayList allColInIdx = new ArrayList();
          allColInIdx.AddRange( indexProperties.Columns );

          // Get this part's column name and column position.
          string indexColumnName = schemaRow[columnNameColumn.Ordinal].ToString();
          allColInIdx.Add( indexColumnName );

          // Transfer the new column list to the index properties instance
          string[] newColumns = (string[])allColInIdx.ToArray(typeof(string));
          indexProperties.Columns = newColumns;

//          allIndexes.RemoveAt( allIndexesIndex ); 
//          allIndexes.Add( indexProperties );
          // need to unbox and rebox the struct so that the columns array is properly updated
          allIndexes[allIndexesIndex] = indexProperties;
        }
      
        return (IndexProperties[])allIndexes.ToArray(typeof(IndexProperties));
      }
      catch (Exception e) 
      {
        throw new DatabaseModelExtractorException("Couldn't get indexes on extraction of database model for " + table + " table ("+e.Message+").",e);
      }
    }

    /// <summary>
    /// Gets information about full-text indexes in database. 
    /// </summary>
    /// <returns>The <see cref="FullTextIndexesInfo"/> object describing all full-text indexes.</returns>
    public override FullTextIndexesInfo GetFullTextIndexesInfo() 
    {
      FullTextIndexesInfo ftiInfo = new FullTextIndexesInfo();
      
      try 
      {
        ArrayList allIndexes = new ArrayList();
        ftiInfo.Indexes = (FullTextIndexesInfo.FullTextIndex[])allIndexes.ToArray(typeof(FullTextIndexesInfo.FullTextIndex));
      }  
      catch (Exception e)
      {
        throw new DatabaseModelExtractorException("Couldn't get full-text indexes while extracting model: " + e.Message,e);
      }
      return ftiInfo;
    }

    /// <summary>
    /// Gets a list of all columns from the specified table.
    /// </summary>
    /// <param name="table">The name of the table to extract columns information from.</param>
    /// <returns>An array of <see cref="ColumnProperties"/> objects describing all columns.</returns>
    public override ColumnProperties[] GetAllColumns(string table) 
    {
      ArrayList allColumns =  new ArrayList();
      Hashtable columnHashtable = new Hashtable();

      try
      {
//        OleDbCommand cmd = (OleDbCommand)CreateCommand();
//        cmd.CommandText = "SELECT * FROM " + Driver.Utils.QuoteIdentifier( table );
//        DataTable schema = null;
//        ((MSAccessDriver)Driver).LogSqlCommand( "MSAccessExtractor.ColumnProperties", cmd );
//        OleDbDataReader reader = cmd.ExecuteReader( CommandBehavior.SchemaOnly | CommandBehavior.KeyInfo );
//        try
//        {
//          schema = reader.GetSchemaTable();
//        }
//        finally
//        {
//          reader.Close();
//        }

        DataTable schema = ((OleDbConnection)Connection).GetOleDbSchemaTable( OleDbSchemaGuid.Columns, new object[]{null,null,table} );
        //DumpTable(schema);

//        DataColumn columnNameColumn = schema.Columns["ColumnName"];
//        DataColumn columnSizeColumn = schema.Columns["ColumnSize"];
//        DataColumn numericPrecisionColumn = schema.Columns["NumericPrecision"];
//        DataColumn numericScaleColumn = schema.Columns["NumericScale"];
//        DataColumn dataTypeColumn = schema.Columns["DataType"];
//        DataColumn providerTypeColumn = schema.Columns["ProviderType"];
//        DataColumn isLongColumn = schema.Columns["IsLong"];
//        DataColumn allowDBNullColumn = schema.Columns["AllowDBNull"];
//        DataColumn isReadOnlyColumn = schema.Columns["IsReadOnly"];
//        DataColumn isRowVersionColumn = schema.Columns["IsRowVersion"];
//        DataColumn isUniqueColumn = schema.Columns["IsUnique"];
//        DataColumn isKeyColumn = schema.Columns["IsKey"];
//        DataColumn isAutoIncrementColumn = schema.Columns["IsAutoIncrement"];

        DataColumn oridnalPositionColumn = schema.Columns["ORDINAL_POSITION"];
        DataColumn columnNameColumn = schema.Columns["COLUMN_NAME"];
        DataColumn columnSizeColumn = schema.Columns["CHARACTER_MAXIMUM_LENGTH"];
        DataColumn numericPrecisionColumn = schema.Columns["NUMERIC_PRECISION"];
        DataColumn numericScaleColumn = schema.Columns["NUMERIC_SCALE"];
        DataColumn dataTypeColumn = schema.Columns["DATA_TYPE"];
        DataColumn allowDBNullColumn = schema.Columns["IS_NULLABLE"];
        //DataColumn isAutoIncrementColumn = schema.Columns["IsAutoIncrement"];
        schema.DefaultView.Sort = oridnalPositionColumn.ColumnName;
        
        foreach( DataRowView schemaRow in schema.DefaultView )
        {
          ColumnProperties columnProperties = new ColumnProperties();

          columnProperties.Name = schemaRow[columnNameColumn.Ordinal].ToString();
          //columnProperties.AutoIncrement = (bool)schemaRow[isAutoIncrementColumn.Ordinal];
          columnProperties.IsNullable = (bool)schemaRow[allowDBNullColumn.Ordinal];
          
//          System.Type colType = (System.Type)schemaRow[dataTypeColumn.Ordinal];
          OleDbType colType = (OleDbType)schemaRow[dataTypeColumn.Ordinal];
          if (dbTypes[colType] != null) 
            columnProperties.SqlType = (SqlType)dbTypes[colType];
          else 
            columnProperties.SqlType = SqlType.Unknown;

          if ((columnProperties.SqlType==SqlType.VarChar)
             || (columnProperties.SqlType==SqlType.VarBinary)
             || (columnProperties.SqlType==SqlType.Binary)
            ) 
          {
            columnProperties.Size = Convert.ToInt32(schemaRow[columnSizeColumn.Ordinal]);
            if (columnProperties.SqlType==SqlType.VarChar && columnProperties.Size==Driver.Info.TextLength )
            {
              // Detect Text columns and correct it from varchar
              columnProperties.SqlType = SqlType.Text;
              columnProperties.Size = 0;
            }
          }
          else if (columnProperties.SqlType==SqlType.Decimal) 
          {
            columnProperties.Size = Convert.ToInt32(schemaRow[numericPrecisionColumn.Ordinal]);
            columnProperties.FractionalSize = Convert.ToInt32(schemaRow[numericScaleColumn.Ordinal]);
          }
//          else if (columnProperties.SqlType==SqlType.Int32)
//          {
//            if (columnProperties.Name == "ID" || columnProperties.Name.StartsWith( "ID-" ))
//            {
//              columnProperties.SqlType = SqlType.Int64;
//            }
//          }
          else if (columnProperties.SqlType==SqlType.Boolean)
          {
            columnProperties.IsNullable = false; // for some reason, the allowDBNullColumn value returns true, so correct it here
          }

          // Microsoft Access doesn't have collation
          columnProperties.SqlCollation = SqlCollation.Neutral;

          int index = allColumns.Add( columnProperties );
          columnHashtable.Add( columnProperties.Name, index ); // store for lookup in AutoIncrement routine below
        }

        #region Need to "read" the table to get AutoIncrement property
        
        schema = null;
        
        using (OleDbCommand cmd = (OleDbCommand)CreateCommand()) {
        cmd.CommandText = "SELECT * FROM " + Driver.Utils.QuoteIdentifier( table );
        ((MSAccessDriver)Driver).LogSqlCommand( "MSAccessExtractor.ColumnProperties", cmd );
          using (OleDbDataReader reader = cmd.ExecuteReader( CommandBehavior.SchemaOnly | CommandBehavior.KeyInfo )) {
            schema = reader.GetSchemaTable();
            reader.Close();
          }
        }
        
        //DumpTable(schema);

        columnNameColumn = schema.Columns["ColumnName"];
        DataColumn isAutoIncrementColumn = schema.Columns["IsAutoIncrement"];
        //        DataColumn columnSizeColumn = schema.Columns["ColumnSize"];
        //        DataColumn numericPrecisionColumn = schema.Columns["NumericPrecision"];
        //        DataColumn numericScaleColumn = schema.Columns["NumericScale"];
        //        DataColumn dataTypeColumn = schema.Columns["DataType"];
        //        DataColumn providerTypeColumn = schema.Columns["ProviderType"];
        //        DataColumn isLongColumn = schema.Columns["IsLong"];
        //        DataColumn allowDBNullColumn = schema.Columns["AllowDBNull"];
        //        DataColumn isReadOnlyColumn = schema.Columns["IsReadOnly"];
        //        DataColumn isRowVersionColumn = schema.Columns["IsRowVersion"];
        //        DataColumn isUniqueColumn = schema.Columns["IsUnique"];
        //        DataColumn isKeyColumn = schema.Columns["IsKey"];
        
        // To speed things up, filter out the non-AutoIncrement columns
        schema.DefaultView.RowFilter = isAutoIncrementColumn.ColumnName + " = true";
        
        foreach ( DataRowView schemaRow in schema.DefaultView )
        {
          string columnName = schemaRow[columnNameColumn.Ordinal].ToString();
          int index = (int)columnHashtable[columnName];
          ColumnProperties columnProperties = (ColumnProperties) allColumns[index];
          columnProperties.AutoIncrement = Convert.ToBoolean( schemaRow[isAutoIncrementColumn.Ordinal] );
          // becase ColumnProperties  is struct, storing it back.
          allColumns[index] = columnProperties;
        }
        #endregion
        return (ColumnProperties[])allColumns.ToArray(typeof(ColumnProperties));
      }  
      catch (Exception e)
      {
        throw new DatabaseModelExtractorException("Couldn't extract columns ("+e.Message+").",e);
      }
    }

    /// <summary>
    /// Get all foreign key constraint properties from the specified table.
    /// </summary>
    /// <param name="tableName">The name of the table to extract foreign keys from.</param>
    /// <returns>An array of <see cref="ForeignKeyConstraintProperties"/> objects
    /// describing all the foreign key constraints.</returns>
    public override ForeignKeyConstraintProperties[] GetAllForeignKeyConstraints(string tableName) 
    {
      try
      {
        ArrayList allConstraints = new ArrayList();

        DataTable schema = ((OleDbConnection)Connection).GetOleDbSchemaTable( OleDbSchemaGuid.Foreign_Keys, new object[0] );
        
        DataColumn foreignKeyTableNameColumn = schema.Columns[ "FK_TABLE_NAME" ];
        DataColumn foreignKeyNameColumn = schema.Columns[ "FK_NAME" ];
        DataColumn primaryTableNameColumn = schema.Columns[ "PK_TABLE_NAME" ];
        DataColumn foreignKeyColumnNameColumn = schema.Columns[ "FK_COLUMN_NAME" ];
        DataColumn primaryKeyColumnNameColumn = schema.Columns[ "PK_COLUMN_NAME" ];
        DataColumn deleteRuleColumnName = schema.Columns[ "DELETE_RULE" ];
        DataColumn updateRuleColumnName = schema.Columns[ "UPDATE_RULE" ];
        DataColumn columnPositionColumn = schema.Columns[ "ORDINAL" ];
              
        // Access foreign keys are stored one row per key column in the schema table.
        // The "ORDINAL" value (1-based) indicates the placement of the column within the foreign key.
        // Sort the schema data to ensure the columns are encountered in order, to simplify things.
        schema.DefaultView.Sort = foreignKeyNameColumn + "," + columnPositionColumn.ColumnName;
        schema.DefaultView.RowFilter = foreignKeyTableNameColumn.ColumnName + " = '" + tableName + "'";

        int allConstraintsIndex;
        HybridDictionary foreignKeyDictionary = new HybridDictionary();        
        foreach( DataRowView schemaRow in schema.DefaultView )
        {
          ForeignKeyConstraintProperties foreignKeyProperties;

          string foreignKeyName = schemaRow[foreignKeyNameColumn.Ordinal].ToString();
          if (foreignKeyDictionary[foreignKeyName]==null) {
            // Since multi-column foreign keys all share the same base values,
            // set the common foreign key properties on the first occurence only
            foreignKeyProperties =  new ForeignKeyConstraintProperties();
            foreignKeyProperties.Name = foreignKeyName;
            foreignKeyProperties.PrimaryKeyTable = schemaRow[primaryTableNameColumn.Ordinal].ToString();
            if (string.Compare( schemaRow[updateRuleColumnName.Ordinal].ToString(), "cascade", true)==0)
              foreignKeyProperties.OnUpdateCascade = true;
            if (string.Compare( schemaRow[deleteRuleColumnName.Ordinal].ToString(), "cascade", true)==0)
              foreignKeyProperties.OnDeleteCascade = true;
            foreignKeyProperties.Columns = new string[0];
            foreignKeyProperties.PrimaryKeyTableColumns = new string[0];
        
            allConstraintsIndex = allConstraints.Add( foreignKeyProperties );
            foreignKeyDictionary[foreignKeyName] = foreignKeyProperties;
          }
          else
          {
            foreignKeyProperties = (ForeignKeyConstraintProperties)foreignKeyDictionary[foreignKeyName];
          
            // Because of boxing/unboxing of the IndexProperties struct,
            // allConstraints.IndexOf doesn't work, so need to manually search
            // for the index
            allConstraintsIndex = -1;
            for( int constraintIndex = 0; constraintIndex < allConstraints.Count; constraintIndex++ )
            {
              if (((ForeignKeyConstraintProperties)allConstraints[constraintIndex]).Name==foreignKeyName) {
                allConstraintsIndex = constraintIndex;
                break;
              }
            }
          }
            
          // Transfer the previous list of foreign key columns into an ArrayList
          ArrayList allColInIdx = new ArrayList();
          allColInIdx.AddRange( foreignKeyProperties.Columns );

          // Get this part's column name and column position.
          string foreignKeyColumnName = schemaRow[foreignKeyColumnNameColumn.Ordinal].ToString();
          allColInIdx.Add( foreignKeyColumnName );

          // Transfer the new column list to the foreignKey properties instance
          foreignKeyProperties.Columns = (string[])allColInIdx.ToArray(typeof(string));
      
          // Transfer the previous list of primary key columns into an ArrayList
          allColInIdx = new ArrayList();
          allColInIdx.AddRange( foreignKeyProperties.PrimaryKeyTableColumns );

          // Get this part's column name and column position.
          string primaryKeyColumnName = schemaRow[primaryKeyColumnNameColumn.Ordinal].ToString();
          allColInIdx.Add( primaryKeyColumnName );

          // Transfer the new column list to the foreignKey properties instance
          foreignKeyProperties.PrimaryKeyTableColumns = (string[])allColInIdx.ToArray(typeof(string));

        
          allConstraints.RemoveAt( allConstraintsIndex ); // need to unbox and rebox the struct so that the columns array is properly updated
          allConstraints.Add( foreignKeyProperties );
        }

        return (ForeignKeyConstraintProperties[])allConstraints.ToArray(typeof(ForeignKeyConstraintProperties));
      }
      catch (Exception e)
      {
        throw new DatabaseModelExtractorException("Couldn't get foreign key properties on extraction of database model ("+e.Message+").",e);
      }
    }    

    /// <summary>
    /// In the case when database driver erroneusly reports indexes and constraints  to be the same, allows
    /// to resolve this situation.
    /// </summary>
    /// <param name="table"><see cref="Table"/> to fix.</param>
    public override void FixIndexesAndConstraints(Table table)
    {
        foreach(Constraint ct in table.Constraints)
        {
          if (!(ct is ForeignKeyConstraint))
            continue;
          Index idx = table.Indexes[ct.Name];
          if (idx != null)
            table.Indexes.Remove(idx);
        }
    }


    /// <summary>
    /// Gets names and IDs of all registered types.
    /// </summary>
    /// <param name="tableName">The name of the table storing information about registered types.</param>
    /// <returns>An array of <see cref="SysTypeProperties"/> objects describing all registered types.</returns>
    public override SysTypeProperties[] GetRegisteredClassTypes(string tableName) {

      ArrayList types =  new ArrayList();

      using (OleDbCommand cmd = (OleDbCommand)CreateCommand()) {
        
        cmd.CommandText = "Select * from " + Driver.Utils.QuoteIdentifier(tableName) + " where " + Driver.Utils.QuoteIdentifier("ID") + "<>0";
        ((MSAccessDriver)Driver).LogSqlCommand( "GetRegisteredClassTypes", cmd );
      
        using (OleDbDataReader myReader = cmd.ExecuteReader()) {
          while(myReader.Read()) {
            SysTypeProperties stp = new SysTypeProperties();
            stp.Name = myReader.GetString(1);
            stp.ID = myReader.GetInt32(0);
            types.Add(stp);
          }
          myReader.Close();
        }
      }

      return (SysTypeProperties[])types.ToArray(typeof(SysTypeProperties));
    }

    /// <summary>
    /// Gets common database properties.
    /// </summary>
    /// <returns><see cref="DatabaseProperties"/> object.</returns>
    public override DatabaseProperties GetDatabaseProperties(string dbName) 
    {
      DatabaseProperties dbp = new DatabaseProperties();

      dbp.SqlCollation = Driver.Utils.GetSqlCollation( string.Empty ); // Access doesn't support collations

      return dbp;
    }

    /// <summary>
    /// Returns <see langword="True"/> if table contains "null row" (a row with ID=0);
    /// otherwise, <see langword="false"/>.
    /// </summary>
    /// <param name="table">Table to get properties for.</param>
    /// <returns><see langword="True"/> if table contains "null row" (a row with ID=0);
    /// otherwise, <see langword="false"/>.</returns>
    public override bool GetHasNullRow(Table table)
    {
      string tableName = table.Name;
      string columnToUse = "ID";
      if ((Driver.Domain.DatabaseOptions & DomainDatabaseOptions.EnableVersionizing)!=0) {
        if (table.Columns["GID"]!=null)
          columnToUse = "GID";
      }
      if (table.Columns[columnToUse]==null)
        return false;

      try 
      {
        using(OleDbCommand cmd =  (OleDbCommand)CreateCommand()) {
          cmd.CommandText = "Select count(*) from [" + tableName + "] where [" + columnToUse+ "]=0";
          ((MSAccessDriver)Driver).LogSqlCommand( "MSAccessExtractor.GetHasNullRow", cmd );
          return Convert.ToDecimal(cmd.ExecuteScalar())>0;
        }
      }
      catch (Exception e)
      {
        throw new DatabaseModelExtractorException("Couldn't get HasNullRow property. ("+e.Message+")",e);
      }
    }

    
    // Constructor

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="driver">Driver to which this instance will be bound.</param>
    /// <param name="connection">Connection through which this instance should operate.</param>
    /// <param name="transaction">Transaction, in which this utility works.</param>
    public MSAccessExtractor(Driver driver, IDbConnection connection, IDbTransaction transaction):
      base(driver, connection, transaction)
    {
      dbTypes = new HybridDictionary();
      dbTypes.Add(typeof(System.String),     SqlType.VarChar);
      dbTypes.Add(typeof(System.Byte[]),    SqlType.VarBinary);
      dbTypes.Add(typeof(System.Boolean),          SqlType.Boolean);
      dbTypes.Add(typeof(System.DateTime),     SqlType.DateTime);
      dbTypes.Add(typeof(System.Decimal),      SqlType.Decimal);
      dbTypes.Add(typeof(System.Double),        SqlType.Double);
      dbTypes.Add(typeof(System.Byte),      SqlType.Byte);
      dbTypes.Add(typeof(System.Int16),     SqlType.Int16);
      dbTypes.Add(typeof(System.Int32),          SqlType.Int32);
      dbTypes.Add(typeof(System.Guid),     SqlType.GUID); 
      
      dbTypes.Add(OleDbType.VarChar,     SqlType.VarChar);
      dbTypes.Add(OleDbType.WChar,     SqlType.VarChar);
      dbTypes.Add(OleDbType.Binary,    SqlType.Binary);
      dbTypes.Add(OleDbType.VarBinary,    SqlType.VarBinary);
      dbTypes.Add(OleDbType.Boolean,          SqlType.Boolean);
      dbTypes.Add(OleDbType.Date,     SqlType.DateTime);
      dbTypes.Add(OleDbType.Numeric,      SqlType.Decimal);
      dbTypes.Add(OleDbType.Decimal,      SqlType.Decimal);
      dbTypes.Add(OleDbType.Double,        SqlType.Double);
      dbTypes.Add(OleDbType.TinyInt,      SqlType.Byte);
      dbTypes.Add(OleDbType.SmallInt,     SqlType.Int16);
      dbTypes.Add(OleDbType.Integer,          SqlType.Int32);
      dbTypes.Add(OleDbType.Guid,     SqlType.GUID); 
    }

    private void DumpTable(DataTable dataTable)
    {
      Debug.WriteLine("Table : columns");
      foreach(DataColumn c in dataTable.Columns)
        Debug.WriteLine("\tTable : " + c.ColumnName);
      Debug.WriteLine("Table : rows");
      foreach(DataRow r in dataTable.Rows)
      {
        foreach(DataColumn c in dataTable.Columns)
          Debug.Write("|\t" + r[c.ColumnName]);
        Debug.WriteLine("");
      }

    }
  }
}
