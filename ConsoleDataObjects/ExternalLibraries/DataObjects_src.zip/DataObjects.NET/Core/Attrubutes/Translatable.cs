// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;

namespace DataObjects.NET.Attributes
{
  /// <summary>
  /// Indicates that property is translatable. This means that set of values 
  /// will be maintained for this property, one for each <see cref="Culture"/>
  /// registered in the <see cref="Domain"/>. Each of such values will be
  /// stored in its own column having a culture suffix (e.g. if property name
  /// is "Title", the name of the column can be "Title-En" for a culture having
  /// "En" <see cref="Culture.Name"/>).
  /// </summary>
  /// <remarks>
  /// <note>This attribute can be applied to persistent properties of any type.</note>
  /// <para>
  /// <example>Example:
  /// <code lang="C#">
  ///  public abstract class Article: DataObject
  ///  {
  ///    [Length(128)]
  ///    [Translatable] // !!!
  ///    public abstract string Title {get; set;}
  ///    
  ///    ...
  ///  }
  /// </code>
  /// </example>
  /// </para>
  /// <seealso cref="CollatableAttribute"/>
  /// </remarks>
  [AttributeUsage(AttributeTargets.Property, AllowMultiple = false, Inherited = true)]
  [Serializable]
  public class TranslatableAttribute: DataObjectAttribute
  {
    private bool translatable = true;
    /// <summary>
    /// <see langword="True"/> if property is translatable.
    /// </summary>
    public  bool Translatable 
    {
      get {return translatable;}
      set {translatable = value;}
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    public TranslatableAttribute() 
    {
    }
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="translatable"><see langword="True"/> if property is translatable.</param>
    public TranslatableAttribute(bool translatable) 
    {
      this.translatable = translatable;
    }
  }
}
