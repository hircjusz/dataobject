// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using DataObjects.NET;

namespace DataObjects.NET.Data
{
  /// <summary>
  /// Enumerates possible states of <see cref="Adapter"/>.
  /// </summary>
  public enum AdapterState
  {
    /// <summary>
    /// Ready to <see cref="Adapter.Fill"/> or 
    /// <see cref="Adapter.Update"/> execution.
    /// Value is <see langword="0x0"/>.
    /// </summary>
    Ready = 0x0,
    /// <summary>
    /// <see cref="Adapter.Fill"/> method is running.
    /// <see cref="Adapter.Update"/> execution is prohibited.
    /// Value is <see langword="0x1"/>.
    /// </summary>
    Filling = 0x1,
    /// <summary>
    /// <see cref="Adapter.Update"/> method is running.
    /// <see cref="Adapter.Fill"/> execution is prohibited.
    /// Value is <see langword="0x2"/>.
    /// </summary>
    Updating = 0x2,
  }
}
