// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using DataObjects.NET.Attributes;

namespace DataObjects.NET
{
  /// <summary>
  /// Allows to pre-process internal property value before
  /// persisting it to the database (e.g. compress it) and 
  /// do the same on fetching it (e.g. decompress it).
  /// <seealso cref="StorageValueModifierAttribute"/>
  /// </summary>
  /// <remarks>
  /// See <see cref="StorageValueModifierAttribute"/> also.
  /// </remarks>
  public interface IPropertyStorageValueModifier
  {
    /// <summary>
    /// Converts a value that DataObjects.NET is going to persist to
    /// the storage to actual value that should be persisted.
    /// </summary>
    /// <param name="session"><see cref="Session"/> where conversion occurs.</param>
    /// <param name="dataObject"><see cref="DataObject"/> for which we  store a property.</param>
    /// <param name="propertyName">Property name.</param>
    /// <param name="culture">Property culture.</param>
    /// <param name="value">Internal value.</param>
    /// <returns>Value to be stored into database.</returns>
    /// <remarks>
    /// <note type="note">This method should be completely thread-safe 
    /// (it should be possible to invoke this method on a single instance
    /// of class that implements it from multiple threads simultaneously).</note>
    /// <note type="note">This method should return the object 
    /// of the same type (as type of <paramref name="value"/> object)</note>
    /// <para>
    /// Remember that value passed to this method may differ from
    /// value returned by <see cref="DataObject.GetProperty"/> method.
    /// For example, any <see cref="Object"/> property is stored
    /// as <see cref="Byte"/> <see cref="Array"/>.
    /// </para>
    /// </remarks>
    object ConvertToStorageValue(Session session, DataObject dataObject, string propertyName, Culture culture, object value);

    /// <summary>
    /// Converts a value fetched by DataObjects.NET from the storage to 
    /// actual value that should be used.
    /// </summary>
    /// <param name="session"><see cref="Session"/> where conversion occurs.</param>
    /// <param name="dataObject"><see cref="DataObject"/> for which we  load a property value.</param>
    /// <param name="propertyName">Property name.</param>
    /// <param name="culture">Property culture.</param>
    /// <param name="value">Loaded value.</param>
    /// <returns>Value to be stored in <see cref="DataObject"/>.</returns>
    /// <remarks>
    /// <note type="note">This method should be completely thread-safe 
    /// (it should be possible to invoke this method on a single instance
    /// of class that implements it from multiple threads simultaneously).</note>
    /// <note type="note">This method should return the object 
    /// of the same type (as type of <paramref name="value"/> object)</note>
    /// <para>
    /// Remember that value passed to this method may differ from
    /// value returned by <see cref="DataObject.GetProperty"/> method.
    /// For example, any <see cref="Object"/> property is stored
    /// as <see cref="Byte"/> <see cref="Array"/>.
    /// </para>
    /// </remarks>
    object ConvertFromStorageValue(Session session, DataObject dataObject, string propertyName, Culture culture, object value);
  }
}
