// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;

namespace DataObjects.NET.Helpers
{
  /// <summary>
  /// Contains <see cref="DataObject"/> property value 
  /// validators (see <see cref="IPropertyValueValidator"/>),
  /// correctors (see <see cref="IPropertyValueCorrector"/>),
  /// type modifiers (see <see cref="IPropertyTypeModifier"/>),
  /// storage value modifiers (see <see cref="IPropertyStorageValueModifier"/>)
  /// and set of other useful classes.
  /// </summary>
  internal class NamespaceDoc {}
}
