// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Data.SqlClient;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Collections;
using System.Collections.Specialized;
using System.Data;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Attributes;
using DataObjects.NET.FullText;
using DataObjects.NET.FullText.Drivers.Native;
using DataObjects.NET.Database;
using DataObjects.NET.ObjectModel;
using DataObjects.NET.DatabaseModel;

namespace DataObjects.NET
{
  /// <summary>
  /// Base class for any query.
  /// </summary>
  public abstract class QueryBase: SessionBoundObject, IDisposable
  {
    internal  bool             translated;
    // Core parameters
    private   System.Type      instanceType;
    private   ObjectModel.Type objectModelType;
    private   Field            field;
    private   Culture          fieldCulture;
    private   QueryParameterCollection parameters;
    private   QueryOptions     options;
    private   string           freeOptions;
    private   QueryResultType resultType = QueryResultType.Instances;
    private   long             top            = 0;
    private   SqlJoinCollection joins;
    private   string           sqlRestriction = "";
    private   bool             sqlIsDistinct = false;
    private   bool             boFetchInstances = true;
    private   bool             idOnly = false;
    // To speedup the access
    private   IDbCommand       command;
    private   StringCollection unnamed2Named = new StringCollection();
    private static Regex       rOrderByLStr;
    private static Regex       rOrderByMStr;
    private static Regex       rOrderByRStr;
    internal FtsCondition      ftsCondition;
    private  FtsResult         ftsResult;
    protected PageInfo           pageInformation;

    /// <summary>
    /// Gets the type of result this query should return.
    /// </summary>
    /// <remarks>
    /// <note type="note">
    /// You should modify this property first while tuning up your
    /// query.
    /// </note>
    /// </remarks>
    public virtual QueryResultType ResultType {
      get {
        return resultType;
      }
    }



    /// <summary>
    /// Gets or sets the <see cref="System.Type"/> of objects to search. 
    /// Note that descendants participate in search too.
    /// </summary>
    public virtual System.Type InstanceType {
      get {
        return instanceType;
      }
      set {
        if (value==null)
          throw new ArgumentNullException("value");
        ObjectModel.Type oType = null;
        if (value!=null) {
          oType = session.types[value.FullName];
          if (oType==null)
            throw new InvalidOperationException(
              String.Format("Type {0} isn't registered in the domain.",value.FullName));
        }
        translated = false;
        resultType = QueryResultType.Instances;
        instanceType = value;
        objectModelType = oType;
      }
    }

    /// <summary>
    /// Gets or sets the <see cref="ObjectModel.Type"/> of objects to search. 
    /// Note that descendants participate in search too.
    /// </summary>
    public virtual ObjectModel.Type ObjectModelType {
      get {
        return objectModelType;
      }
      set {
        if (value==null)
          throw new ArgumentNullException("value");
        if (value.Model.Domain!=session.domain)
          throw new InvalidOperationException(
            String.Format("Type {0} isn't registered in the domain.",value.Name));
        translated = false;
        resultType = QueryResultType.Instances;
        objectModelType = value;
        instanceType = value.SourceType;
      }
    }

    /// <summary>
    /// Gets or sets the <see cref="ObjectModel.Field"/> the query is
    /// targeted to.
    /// </summary>
    public virtual Field Field {
      get {
        return field;
      }
      set {
        if (value==null)
          throw new ArgumentNullException("value");
        if (!value.IsRootField && value.ContainerField is ValueTypeCollectionField)
          throw new InvalidOperationException(String.Format(
            "Using of Item field describing items of ValueTypeCollectionField isn't allowed here. " +
            "Use container ValueTypeCollectionField or some of contained fields instead."));
        if (!value.IsRootField && value.ContainerField is DataObjectCollectionField)
          throw new InvalidOperationException(String.Format(
            "Using of Item field describing items of DataObjectCollectionField isn't allowed here. " +
            "Use container DataObjectCollectionField instead."));
        translated = false;
        resultType = QueryResultType.Values;
        instanceType    = value.Type.SourceType;
        objectModelType = value.Type;
        field = value;
      }
    }

    /// <summary>
    /// Gets or sets the <see cref="Culture"/> of the 
    /// <see cref="Field"/> the query is targeted to.
    /// </summary>
    public virtual Culture FieldCulture {
      get {
        return fieldCulture;
      }
      set {
        translated = false;
        fieldCulture = value;
      }
    }

    /// <summary>
    /// Gets the <see cref="DataObjects.NET.Session.Utils"/> object.
    /// </summary>
    public  Utils Utils {
      get {
        return session.utils;
      } 
    }
    
    /// <summary>
    /// <see langword="True"/> if query is already translated;
    /// otherwise, <see langword="false"/>.
    /// </summary>
    public bool Translated {
      get {
        return translated;
      }
    }
    
    /// <summary>
    /// Gets the query parameters collection.
    /// </summary>
    public  QueryParameterCollection Parameters {
      get {
        return parameters;
      }
    }
    
    /// <summary>
    /// Gets or sets query options.
    /// <seealso cref="ExecuteArray"/>
    /// <seealso cref="ExecuteCount"/>
    /// <seealso cref="QueryResult"/>
    /// </summary>
    public virtual QueryOptions Options {
      get {return options;}
      set {
        if (options==value)
          return;
        translated = false;
        options    = value;
      }
    }

      public virtual string FreeOptions
      {
          get { return this.freeOptions; }
          set
          {
              if (freeOptions == value)
                  return;
              translated = false;
              freeOptions = value;
          }
      }

    private void UpdateFetchInstances(QueryResultType ResultType, Field field, DataObjects.NET.ObjectModel.Type oType)
    {
       boFetchInstances = 
            (ResultType==QueryResultType.Instances) ||
            !(field.RootField is ICollectionField);
    }

    /// <summary>
    /// Gets or sets "top n" expression in the underlying select statement.
    /// </summary>
    public virtual long Top 
    {
      get {return top;}
      set {
        if (value<0)
          throw new ArgumentOutOfRangeException("Top");
        translated = false;
        top = value;
      }
    }
    
    /// <summary>
    /// Gets <see cref="SqlJoinCollection"/> containing a list of joins for 
    /// this query.
    /// </summary>
    public virtual SqlJoinCollection Joins
    {
      get {
        return joins;
      }
    }
    
    /// <summary>
    /// Gets or sets query restriction.
    /// <seealso cref="ExecuteArray"/>
    /// <seealso cref="ExecuteCount"/>
    /// <seealso cref="QueryResult"/>
    /// </summary>
    protected internal string SqlRestriction {
      get {return sqlRestriction;}
      set {
        if (sqlRestriction==value)
          return;
        translated     = false;
        sqlRestriction = value;
      }
    }
    
    /// <summary>
    /// Gets or sets a value indicating whether extracts object IDs only.
    /// </summary>
    internal protected virtual bool IdOnly {
      get {
        return idOnly;
      }
      set {
        if (idOnly!=value)
          translated = false;
        idOnly = value;
      }
    }
    
    /// <summary>
    /// Gets root name. Root name is used in sql queries.
    /// </summary>
    internal virtual string RootName {
      get {
        return "root";
      }
    }

//    // Unused starting from v2.2.2
//
//    // Restriction setters
//    internal void AddRestriction(string sqlRestriction)
//    {
//      if (sqlRestriction.Trim()!="") {
//        if (this.sqlRestriction.Trim()!="")
//          this.sqlRestriction = "("+this.sqlRestriction+") and ("+sqlRestriction+")";
//        else
//          this.sqlRestriction = sqlRestriction;
//        translated = false;
//      }
//    }
//    internal void CopyRestriction(QueryBase q)
//    {
//      this.sqlRestriction = q.sqlRestriction;
//      translated = false;
//    }
//    internal void RemoveRestrictions()
//    {
//      this.sqlRestriction = "";
//      translated = false;
//    }
    
    
    // Execution methods

    /// <summary>
    /// Performs the query.
    /// </summary>
    /// <param name="options">Query options.</param>
    /// <param name="top">N parameter in "Top N" condition.</param>
    /// <returns><see cref="QueryResult"/> containing all selected instances.</returns>
    /// <remarks>
    /// Look <see cref="QueryOptions"/> - a lot depends of the value
    /// of this parameter.
    /// <seealso cref="ExecuteArray"/>
    /// <seealso cref="ExecuteValueTypeQueryResult"/>
    /// <seealso cref="ExecuteCount"/>
    /// </remarks>
    [Transactional(TransactionMode.TransactionRequired)]
    public QueryResult Execute(long top, QueryOptions options, PageInfo pageInfo)
    {
      // Automatic Transactions support code
      TransactionController tc = session.CreateTransactionController( TransactionMode.TransactionRequired);
    Reprocess:
      try {
        QueryResult r = InnerExecute(top, options, pageInfo);
        tc.Commit();
        return r;
      }
      catch (Exception e) {
        if (tc.Rollback(e, true))
          goto Reprocess;             
        throw;
      }
    }
    private QueryResult InnerExecute(long top, QueryOptions options, PageInfo pageInfo)
    {
      if (ResultType==QueryResultType.Values)
        throw new InvalidOperationException("This method doesn't support QueryResultType.Values.");
      ArrayList result;

      QueryOptions oldOpt = this.options;
      long oldTop = this.top;
      try {
        // dynamic restriction queries will be updated in inner call to InternalExecute
        if ((options!=oldOpt || top!=oldTop) && !HasDynamicRestriction()) {
          this.options = options;
          this.top     = top;
          this.pageInformation = pageInfo;
          UpdateTranslation();
        }
        result = (ArrayList)InternalExecute(false);
      }
      finally {
        if (options!=oldOpt || top!=oldTop) {
          this.options = oldOpt;
          this.top     = oldTop;
          this.pageInformation = null;
          if (!HasDynamicRestriction())
            UpdateTranslation();
        }
      }

      return new QueryResult(session,options,result);
    }
    
    /// <summary>
    /// Performs the query.
    /// </summary>
    /// <returns><see cref="QueryResult"/> containing all selected instances.</returns>
    /// <remarks>
    /// This method call is equivalent to 
    /// <see cref="Execute(long, QueryOptions)">Execute</see>(<see cref="Top"/>, <see cref="Options"/>)
    /// invocation.
    /// <seealso cref="ExecuteArray"/>
    /// <seealso cref="ExecuteValueTypeQueryResult"/>
    /// <seealso cref="ExecuteCount"/>
    /// </remarks>
    public QueryResult Execute()
    {
      return Execute(top, options, pageInformation);
    }
    
    /// <summary>
    /// Performs the query.
    /// </summary>
    /// <param name="options">Query options.</param>
    /// <returns><see cref="QueryResult"/> containing all selected instances.</returns>
    /// <remarks>
    /// This method call is equivalent to 
    /// <see cref="Execute(long, QueryOptions)">Execute</see>(<see cref="Top"/>, <paramref name="options"/>)
    /// invocation.
    /// <seealso cref="ExecuteArray"/>
    /// <seealso cref="ExecuteValueTypeQueryResult"/>
    /// <seealso cref="ExecuteCount"/>
    /// </remarks>
    public QueryResult Execute(QueryOptions options)
    {
      return Execute(top, options, pageInformation);
    }
    
    /// <summary>
    /// Performs the query.
    /// </summary>
    /// <param name="top">N parameter in "Top N" condition.</param>
    /// <returns><see cref="QueryResult"/> containing all selected instances.</returns>
    /// <remarks>
    /// This method call is equivalent to 
    /// <see cref="Execute(long, QueryOptions)">Execute</see>(<paramref name="top"/>, <see cref="Options"/>)
    /// invocation.
    /// <seealso cref="ExecuteArray"/>
    /// <seealso cref="ExecuteValueTypeQueryResult"/>
    /// <seealso cref="ExecuteCount"/>
    /// </remarks>
    public QueryResult Execute(long top)
    {
      return Execute(top, options, pageInformation);
    }
    
    /// <summary>
    /// Performs the query.
    /// <seealso cref="Execute"/>
    /// <seealso cref="ExecuteValueTypeQueryResult"/>
    /// <seealso cref="ExecuteCount"/>
    /// </summary>
    /// <param name="top">N parameter in "Top N" condition.</param>
    /// <param name="options">Query options.</param>
    /// <returns>Array of selected instances.</returns>
    [Transactional(TransactionMode.TransactionRequired)]
    public DataObject[] ExecuteArray(long top, QueryOptions options)
    {
      // Automatic Transactions support code
      TransactionController tc = session.CreateTransactionController(TransactionMode.TransactionRequired);
    Reprocess:
      try {
        DataObject[] r = (DataObject[])InnerExecuteArray(top, options, false);
        tc.Commit();
        return r;
      }
      catch (Exception e) {
        if (tc.Rollback(e, true))
          goto Reprocess;             
        throw;
      }
    }

    /// <summary>
    /// Performs the query.
    /// <seealso cref="Execute"/>
    /// <seealso cref="ExecuteValueTypeQueryResult"/>
    /// <seealso cref="ExecuteCount"/>
    /// </summary>
    /// <param name="top">N parameter in "Top N" condition.</param>
    /// <param name="options">Query options.</param>
    /// <returns>Array of selected instances.</returns>
    /// <remarks>The only difference between <see cref="ExecuteArrayI"/> and <see cref="ExecuteArray"/>
    /// is that when you query the interface IMyINterface instances, <see cref="ExecuteArrayI"/> returns IMyINterface[] and
    /// <see cref="ExecuteArray"/> returns <see cref="DataObject"/>[]</remarks>
    [Transactional(TransactionMode.TransactionRequired)]
    public IDataObject[] ExecuteArrayI(long top, QueryOptions options)
    {
      // Automatic Transactions support code
      TransactionController tc = session.CreateTransactionController(TransactionMode.TransactionRequired);
    Reprocess:
      try {
        IDataObject[] r = (IDataObject[])InnerExecuteArray(top, options, true);
        tc.Commit();
        return r;
      }
      catch (Exception e) {
        if (tc.Rollback(e, true))
          goto Reprocess;             
        throw;
      }
    }

    private object InnerExecuteArray(long top, QueryOptions options, bool castToInstanceType)
    {
      if (ResultType==QueryResultType.Values)
        throw new InvalidOperationException("This method doesn't support QueryResultType.Values.");
      ArrayList result;

      QueryOptions oldOpt = this.options;
      long oldTop = this.top;
      try {
        // dynamic restriction queries will be updated in inner call to InternalExecute
        if ((options!=oldOpt || top!=oldTop) && !HasDynamicRestriction()) {
          this.options = options;
          this.top     = top;
          UpdateTranslation();
        }
        result = (ArrayList)InternalExecute(false);
      }
      finally {
        if (options!=oldOpt || top!=oldTop) {
          this.options = oldOpt;
          this.top     = oldTop;
          if (!HasDynamicRestriction())
            UpdateTranslation();
        }
      }

      TransactionContext t = session.TransactionContext;
      int c = result.Count;
      Array aOut;
      if (instanceType.IsInterface && !castToInstanceType)
        aOut = Array.CreateInstance(typeof(DataObject),c);
      else
        aOut = Array.CreateInstance(instanceType,c);
        /*
        if (this.ObjectModelType.IsFlat)
        {
            long[] IDs = new long[c];
            string[] fieldNames = new string[this.ObjectModelType.Fields.Count - 5];
            for (int i = 0; i < this.ObjectModelType.Fields.Count - 5; i++)
            {
                fieldNames[i] = this.ObjectModelType.Fields[i + 5].Name;
            }
            for (int i = 0; i < c; i++)
            {
                DataObjectIdentificationInfo dbib = result[i] as DataObjectIdentificationInfo;
                DataObjectInstantiationInfo dbi = dbib as DataObjectInstantiationInfo;                
                IDs[i] = dbib.ID;
                if (dbi != null)
                    dbi.LoadDenied = true;
            }
            DataObjects.NET.Helpers.StrongReferenceHolder r = session.Preload(IDs, fieldNames);
            for (int i = 0; i < c; i++)
            {
                DataObjectIdentificationInfo dbib = result[i] as DataObjectIdentificationInfo;
                DataObjectInstantiationInfo dbi = dbib as DataObjectInstantiationInfo;
                if (dbi != null)
                    dbi.LoadDenied = false;
            }
            for (int idx = 0; idx < aOut.Length; idx++)
            {
                DataObjectIdentificationInfo dbib = result[idx] as DataObjectIdentificationInfo;
                aOut.SetValue(r.items[dbib.ID], idx);
            }
        }
        else
         */
        for (int i = 0; i < c; i++)
        {
            DataObjectIdentificationInfo dbib = result[i] as DataObjectIdentificationInfo;
            DataObjectInstantiationInfo dbi = dbib as DataObjectInstantiationInfo;
            if (dbi != null)
            {
                aOut.SetValue(session.InnerInstantiateObject(dbi, true), i);
            }
            else
                aOut.SetValue(session[dbib.ID], i);
        }
      return (DataObject[])aOut;
    }
    
    /// <summary>
    /// Performs the query.
    /// </summary>
    /// <returns>Array of selected instances.</returns>
    /// <remarks>
    /// This method call is equivalent to 
    /// <see cref="ExecuteArray(long, QueryOptions)">ExecuteArray</see>(<see cref="Top"/>, <see cref="Options"/>)
    /// invocation.
    /// <seealso cref="Execute"/>
    /// <seealso cref="ExecuteValueTypeQueryResult"/>
    /// <seealso cref="ExecuteCount"/>
    /// </remarks>
    public DataObject[] ExecuteArray()
    {
      return ExecuteArray(top, options);
    }
    
    /// <summary>
    /// Performs the query.
    /// </summary>
    /// <param name="options">Query options.</param>
    /// <returns>Array of selected instances.</returns>
    /// <remarks>
    /// This method call is equivalent to 
    /// <see cref="ExecuteArray(long, QueryOptions)">ExecuteArray</see>(<see cref="Top"/>, <paramref name="options"/>)
    /// invocation.
    /// <seealso cref="Execute"/>
    /// <seealso cref="ExecuteValueTypeQueryResult"/>
    /// <seealso cref="ExecuteCount"/>
    /// </remarks>
    public DataObject[] ExecuteArray(QueryOptions options)
    {
      return ExecuteArray(top, options);
    }
    
    /// <summary>
    /// Performs the query.
    /// </summary>
    /// <param name="top">N parameter in "Top N" condition.</param>
    /// <returns>Array of selected instances.</returns>
    /// <remarks>
    /// This method call is equivalent to 
    /// <see cref="ExecuteArray(long, QueryOptions)">ExecuteArray</see>(<paramref name="top"/>, <see cref="Options"/>)
    /// invocation.
    /// <seealso cref="Execute"/>
    /// <seealso cref="ExecuteValueTypeQueryResult"/>
    /// <seealso cref="ExecuteCount"/>
    /// </remarks>
    public DataObject[] ExecuteArray(long top)
    {
      return ExecuteArray(top, options);
    }
    
    /// <summary>
    /// Performs the query.
    /// </summary>
    /// <returns>Array of selected instances.</returns>
    /// <remarks>
    /// This method call is equivalent to 
    /// <see cref="ExecuteArrayI(long, QueryOptions)">ExecuteArrayI</see>(<see cref="Top"/>, <see cref="Options"/>)
    /// invocation.
    /// The only difference between <see cref="ExecuteArrayI"/> and <see cref="ExecuteArray"/>
    /// is that when you query the interface IMyINterface instances, <see cref="ExecuteArrayI"/> returns IMyINterface[] and
    /// <see cref="ExecuteArray"/> returns <see cref="DataObject"/>[]
    /// <seealso cref="Execute"/>
    /// <seealso cref="ExecuteValueTypeQueryResult"/>
    /// <seealso cref="ExecuteCount"/>
    /// </remarks>
    public IDataObject[] ExecuteArrayI()
    {
      return ExecuteArrayI(top, options);
    }
    
    /// <summary>
    /// Performs the query.
    /// </summary>
    /// <param name="options">Query options.</param>
    /// <returns>Array of selected instances.</returns>
    /// <remarks>
    /// This method call is equivalent to 
    /// <see cref="ExecuteArrayI(long, QueryOptions)">ExecuteArrayI</see>(<see cref="Top"/>, <paramref name="options"/>)
    /// invocation.
    /// The only difference between <see cref="ExecuteArrayI"/> and <see cref="ExecuteArray"/>
    /// is that when you query the interface IMyINterface instances, <see cref="ExecuteArrayI"/> returns IMyINterface[] and
    /// <see cref="ExecuteArray"/> returns <see cref="DataObject"/>[]
    /// <seealso cref="Execute"/>
    /// <seealso cref="ExecuteValueTypeQueryResult"/>
    /// <seealso cref="ExecuteCount"/>
    /// </remarks>
    public IDataObject[] ExecuteArrayI(QueryOptions options)
    {
      return ExecuteArrayI(top, options);
    }
    
    /// <summary>
    /// Performs the query.
    /// </summary>
    /// <param name="top">N parameter in "Top N" condition.</param>
    /// <returns>Array of selected instances.</returns>
    /// <remarks>
    /// This method call is equivalent to 
    /// <see cref="ExecuteArrayI(long, QueryOptions)">ExecuteArrayI</see>(<paramref name="top"/>, <see cref="Options"/>)
    /// invocation.
    /// The only difference between <see cref="ExecuteArrayI"/> and <see cref="ExecuteArray"/>
    /// is that when you query the interface IMyINterface instances, <see cref="ExecuteArrayI"/> returns IMyINterface[] and
    /// <see cref="ExecuteArray"/> returns <see cref="DataObject"/>[]
    /// <seealso cref="Execute"/>
    /// <seealso cref="ExecuteValueTypeQueryResult"/>
    /// <seealso cref="ExecuteCount"/>
    /// </remarks>
    public IDataObject[] ExecuteArrayI(long top)
    {
      return ExecuteArrayI(top, options);
    }
    
    /// <summary>
    /// Performs the query on ValueTypeCollection.
    /// </summary>
    /// <param name="top">N parameter in "Top N" condition.</param>
    /// <param name="options">Query options.</param>
    /// <returns><see cref="ValueTypeQueryResult"/> containing all selected values.</returns>
    /// <remarks>
    /// Look <see cref="QueryOptions"/> - a lot depends of the value
    /// of this parameter.
    /// <seealso cref="ExecuteCount"/>
    /// </remarks>
    [Transactional(TransactionMode.TransactionRequired)]
    public ValueTypeQueryResult ExecuteValueTypeQueryResult(long top, QueryOptions options)
    {
      // Automatic Transactions support code
      TransactionController tc = session.CreateTransactionController( TransactionMode.TransactionRequired);
    Reprocess:
      try {
        ValueTypeQueryResult r = InnerExecuteValueTypeQueryResult(top, options);
        tc.Commit();
        return r;
      }
      catch (Exception e) {
        if (tc.Rollback(e, true))
          goto Reprocess;             
        throw;
      }
    }
    private ValueTypeQueryResult InnerExecuteValueTypeQueryResult(long top, QueryOptions options)
    {
      if (ResultType!=QueryResultType.Values)
        throw new InvalidOperationException("This method doesn't support QueryResultType.Values.");
      ArrayList result;
      
      QueryOptions oldOpt = this.options;
      long oldTop = this.top;
      try {
        // dynamic restriction queries will be updated in inner call to InternalExecute
        if ((options!=oldOpt || top!=oldTop) && !HasDynamicRestriction()) {
          this.options = options;
          this.top     = top;
          UpdateTranslation();
        }
        result = (ArrayList)InternalExecute(false);
      }
      finally {
        if (options!=oldOpt || top!=oldTop) {
          this.options = oldOpt;
          this.top     = oldTop;
          if (!HasDynamicRestriction())
            UpdateTranslation();
        }
      }
      
      return new ValueTypeQueryResult(
        session, field, fieldCulture, 
        ((options & QueryOptions.LoadOnDemand)!=0),
        session.transactionContext,
        result);
    }

    /// <summary>
    /// Performs a query that should return 
    /// a <see cref="ExecuteValueTypeQueryResult"/>.
    /// </summary>
    /// <remarks>
    /// This method call is equivalent to 
    /// <see cref="ExecuteValueTypeQueryResult(long, QueryOptions)">ExecuteValueTypeQueryResult</see>(<see cref="Top"/>, <see cref="Options"/>)
    /// invocation.
    /// <seealso cref="Execute"/>
    /// <seealso cref="ExecuteArray"/>
    /// <seealso cref="ExecuteCount"/>
    /// </remarks>
    public ValueTypeQueryResult ExecuteValueTypeQueryResult()
    {
      return ExecuteValueTypeQueryResult(top, options);
    }

    /// <summary>
    /// Performs a query that should return 
    /// a <see cref="ExecuteValueTypeQueryResult"/>.
    /// </summary>
    /// <param name="top">N parameter in "Top N" condition.</param>
    /// <remarks>
    /// This method call is equivalent to 
    /// <see cref="ExecuteValueTypeQueryResult(long, QueryOptions)">ExecuteValueTypeQueryResult</see>(<paramref name="top"/>, <see cref="Options"/>)
    /// invocation.
    /// <seealso cref="Execute"/>
    /// <seealso cref="ExecuteArray"/>
    /// <seealso cref="ExecuteCount"/>
    /// </remarks>
    public ValueTypeQueryResult ExecuteValueTypeQueryResult(long top)
    {
      return ExecuteValueTypeQueryResult(top, options);
    }

    /// <summary>
    /// Performs a query that should return 
    /// a <see cref="ExecuteValueTypeQueryResult"/>.
    /// </summary>
    /// <param name="options">Query options.</param>
    /// <remarks>
    /// This method call is equivalent to 
    /// <see cref="ExecuteValueTypeQueryResult(long, QueryOptions)">ExecuteValueTypeQueryResult</see>(<see cref="Top"/>, <paramref name="options"/>)
    /// invocation.
    /// <seealso cref="Execute"/>
    /// <seealso cref="ExecuteArray"/>
    /// <seealso cref="ExecuteCount"/>
    /// </remarks>
    public ValueTypeQueryResult ExecuteValueTypeQueryResult(QueryOptions options)
    {
      return ExecuteValueTypeQueryResult(top, options);
    }

    /// <summary>
    /// Performs the query with <see cref="QueryOptions.Count"/> option.
    /// <seealso cref="Execute"/>
    /// <seealso cref="ExecuteArray"/>
    /// <seealso cref="ExecuteValueTypeQueryResult"/>
    /// </summary>
    /// <returns>Count of instances selected.</returns>
    [Transactional(TransactionMode.TransactionRequired)]
    public long ExecuteCount()
    {
      // Automatic Transactions support code
      TransactionController tc = session.CreateTransactionController( TransactionMode.TransactionRequired);
    Reprocess:
      try {
        long r = InnerExecuteCount();
        tc.Commit();
        return r;
      }
      catch (Exception e) {
        if (tc.Rollback(e, true))
          goto Reprocess;             
        throw;
      }
    }
    private long InnerExecuteCount()
    {
      return Convert.ToInt64(InternalExecute(true));
    }
    
    /// <summary>
    /// Preloads all objects that should be fetched during the query
    /// execution.
    /// </summary>
    /// <remarks>
    /// You should call this method when it's planned to process
    /// almost all objects selected by the query further.
    /// <seealso cref="DataObjectCollection.Preload"/>
    /// <seealso cref="Execute"/>
    /// <seealso cref="ExecuteArray"/>
    /// <seealso cref="ExecuteCount"/>
    /// </remarks>
    [Transactional(TransactionMode.TransactionRequired)]
    public Helpers.StrongReferenceHolder Preload()
    {
      if (ResultType==QueryResultType.Values)
        throw new InvalidOperationException("This method doesn't support QueryResultType.Values.");

      // Automatic Transactions support code
      TransactionController tc = session.CreateTransactionController( TransactionMode.TransactionRequired);
    Reprocess:
      try {
        Helpers.StrongReferenceHolder r = InnerPreload();
        tc.Commit();
        return r;
      }
      catch (Exception e) {
        if (tc.Rollback(e, true))
          goto Reprocess;             
        throw;
      }
    }
    private Helpers.StrongReferenceHolder InnerPreload()
    {
      session.Persist();
      Translate();
      if (!parameters.translated)
        TranslateParameters();
      QueryOptions oldOpt = options;
      options = oldOpt & (QueryOptions.Distinct | QueryOptions.LoadOnDemand);
      try {
        // Dynamically restricted queries are updated in the 
        // inner call of InternalExecute method
        if ((options!=oldOpt) && !HasDynamicRestriction())
          UpdateTranslation();
        ArrayList queryResultData = (ArrayList)InternalExecute(false);
        if ((options & QueryOptions.LoadOnDemand)==0)
          return ConvertQueryResultDataToStrongReferenceHolder(queryResultData);
        else
          return (new QueryResult(session,options,queryResultData)).Preload();
      }
      finally {
        if (options!=oldOpt) {
          options = oldOpt;
          if (!HasDynamicRestriction())
            UpdateTranslation();
        }
      }
    }
    internal Helpers.StrongReferenceHolder ConvertQueryResultDataToStrongReferenceHolder(ArrayList queryResultData)
    {
      Helpers.StrongReferenceHolder srh = new Helpers.StrongReferenceHolder();
      for (int i = 0, cnt = queryResultData.Count; i<cnt; i++) {
        DataObjectIdentificationInfo ib = queryResultData[i] as DataObjectIdentificationInfo;
        if (ib==null)
          continue;
        object obj = session[ib.ID];
        if (obj!=null)
          srh.AddReference(ib.ID, obj);
      }
      return srh;
    }
    
    private class InfoAndCount 
    {
      public DataObjectIdentificationInfo Info;
      public int Count = 1;
      
      public InfoAndCount(DataObjectIdentificationInfo info) 
      {
        Info = info;
      }
    }
    
    /// <summary>
    /// Internal query execution method.
    /// </summary>
    /// <param name="count"><see langword="True"/>, if a <see cref="QueryOptions.Count"/>
    /// option should be used; otherwise, <see langword="false"/>.</param>
    /// <returns><see cref="ArrayList"/>, where each item is array containing 
    /// first 4 fields of selected instances.</returns>
    internal object InternalExecute(bool count)
    {
      session.Persist();
      Translate();
      if (!parameters.translated)
        TranslateParameters();
      IDbCommand cmd = GetCommand();
      try
      {
          if (cmd.Transaction != session.transaction.PhysicalTransaction)
              cmd.Transaction = session.transaction.PhysicalTransaction;
      }
      catch (NullReferenceException)
      {
          throw new TransactionRequiredException();
      }
      QueryOptions oldOpt = options;
      if (count)
        options = oldOpt | QueryOptions.Count;
      else
        options &= ~QueryOptions.Count;
      try {
        if ((options!=oldOpt) || HasDynamicRestriction())
          UpdateTranslation();
        if ((options & QueryOptions.Count)==0) {
          bool bDistinct = (options & QueryOptions.Distinct)!=0;
          bool bLOD      = (options & QueryOptions.LoadOnDemand)!=0;
          if (boFetchInstances) {
            ArrayList dbInstances = session.persister.ExecuteAndFetchDataObjects(cmd, top);
            if (bDistinct && !sqlIsDistinct) {
              ArrayList dbDistinctInstances = new ArrayList();
              Hashtable hDistincts = new Hashtable();
              int cnt = dbInstances.Count;
              for (int i = 0; i<cnt; i++) {
                DataObjectIdentificationInfo item = dbInstances[i] as DataObjectIdentificationInfo;
                if (!hDistincts.Contains(item.ID)) {
                  hDistincts.Add(item.ID, null);
                  dbDistinctInstances.Add(item);
                }
              }
              dbInstances = dbDistinctInstances;
            }
            if (ftsCondition!=null && ftsCondition.OrderByRank &&
                !(Domain.FtsDriver is NativeFtsDriver)) {
              ArrayList newDbInstances = new ArrayList();
              // Prepareing ID->InfoAndCount map
              Hashtable hshInstances = new Hashtable();
              foreach (DataObjectIdentificationInfo info in dbInstances) {
                InfoAndCount ic = (InfoAndCount)hshInstances[info.ID];
                if (ic==null) {
                  ic = new InfoAndCount(info);
                  hshInstances[info.ID] = ic;
                }
                else
                  ic.Count++;
              }
              // Filling newDbInstances
              if (ftsResult.Entries!=null) {
                foreach (FtsResultEntry entry in ftsResult.Entries) {
                  long itemId = entry.ID;
                  InfoAndCount ic = (InfoAndCount)hshInstances[itemId];
                  if (ic!=null) {
                    int c = ic.Count;
                    while ((c--)>0)
                      newDbInstances.Add(ic.Info);
                  }
                }
              }
              dbInstances = newDbInstances;
            }
            // Unnecessary from post-v3.3.3
            // session.CacheQueryResultData(dbInstances);
            if (ResultType==QueryResultType.Instances)
              return dbInstances; // Nothing additional is necessary here
            else {
              ArrayList result = new ArrayList();
              int cnt = dbInstances.Count;
              for (int i = 0; i<cnt; i++) {
                DataObjectIdentificationInfo item = dbInstances[i] as DataObjectIdentificationInfo;
                result.Add(new ValueTypeQueryResultEntry(item.ID, 0, null));
              }
              return result;
            }
          }
          else {
            ArrayList dbItems = session.persister.PersisterForCollections.ExecuteAndFetchItems(cmd, top);

            ICollectionField cf = field.RootField as ICollectionField;
            StructField      sf = null;
            string cOwner       = session.dataObjectIDColumn.Name;
            string cItem        = session.dataObjectIDColumn.Name;
            bool   bVtcQuery    = false;
            if (cf!=null) {
              cOwner = cf.GetOwnerIdColumnName(fieldCulture);
              cItem  = cf.GetItemIdColumnName(fieldCulture);
              if (field is ValueTypeCollectionField) {
                ValueTypeCollectionField vtf = cf as ValueTypeCollectionField;
                sf = (StructField)vtf.ContainedFields[0];
                bVtcQuery = true;
              }
            }

            if (bDistinct && !sqlIsDistinct) {
              ArrayList result  = new ArrayList();
              Hashtable hDistincts = new Hashtable();
              int cnt = dbItems.Count;
              for (int i = 0; i<cnt; i++) {
                IDictionary dbItem = (IDictionary)dbItems[i];
                long ownerId  = Convert.ToInt64(dbItem[cOwner]);
                long itemId   = cf==null ? 0 : Convert.ToInt64(dbItem[cItem]);
                Int64x2 pair  = new Int64x2(ownerId, itemId);
                if (!hDistincts.Contains(pair)) {
                  hDistincts.Add(pair, null);
                  object iValue = null;
                  if (bVtcQuery && !bLOD)
                    iValue = sf.InternalValueFromRecord(session, null, fieldCulture, dbItem);
                  result.Add(new ValueTypeQueryResultEntry(ownerId, itemId, iValue));
                }
              }
              return result;
            }
            else {
              ArrayList result  = new ArrayList();
              int cnt = dbItems.Count;
              for (int i = 0; i<cnt; i++) {
                IDictionary dbItem = (IDictionary)dbItems[i];
                long ownerId  = Convert.ToInt64(dbItem[cOwner]);
                long itemId   = cf==null ? 0 : Convert.ToInt64(dbItem[cItem]);
                object iValue = null;
                if (bVtcQuery && !bLOD)
                  iValue = sf.InternalValueFromRecord(session, null, fieldCulture, dbItem);
                result.Add(new ValueTypeQueryResultEntry(ownerId, itemId, iValue));
              }
              return result;
            }
          }
        }
        else
          return session.persister.ExecuteScalar(cmd);
      }
      catch (Exception e) {
        throw session.utils.SubstituteException(e);
      }
      finally {
        if (options!=oldOpt) {
          options = oldOpt;
          if (!HasDynamicRestriction())
            UpdateTranslation();
        }
      }
    }

    /// <summary>
    /// Prepares (compiles) the query (to speedup a set of its 
    /// successive executions).
    /// </summary>
    [Transactional(TransactionMode.TransactionRequired)]
    public void Prepare()
    {
      if (HasDynamicRestriction())
        throw new DataObjectsDotNetException("The query cannot be prepared becuase it contais the dynamic part. TODO:");
      // Automatic Transactions support code
      TransactionController tc = session.CreateTransactionController( TransactionMode.TransactionRequired);
    Reprocess:
      try {
        InnerPrepare();
        tc.Commit();
      }
      catch (Exception e) {
        if (tc.Rollback(e, true))
          goto Reprocess;             
        throw;
      }
    }
    private void InnerPrepare()
    {
      Translate();
      if (!parameters.translated)
        TranslateParameters();
      IDbCommand cmd = GetCommand();
      try {  
        if (cmd.Transaction!=session.transaction.PhysicalTransaction)
            cmd.Transaction = session.transaction.PhysicalTransaction;
      }
      catch (NullReferenceException) {
        throw new TransactionRequiredException();
      }
      try {
        cmd.Prepare();
      }
      catch (Exception e) {
        throw session.utils.SubstituteException(e);
      }
    }
    
    
    // Translation methods
    
    /// <summary>
    /// Translates the query.
    /// </summary>
    protected abstract void Translate();
    
    /// <summary>
    /// Updates the text of the command (basically to
    /// reflect changes in the Options collection).
    /// </summary>
    protected abstract void UpdateTranslation();
    
    /// <summary>
    /// Translates the parameters of the query.
    /// </summary>
    protected void TranslateParameters()
    {
      if (IsSubQuery())
        return;
      IDbCommand cmd = GetCommand();
      cmd.CommandText = TranslateSqlParams(cmd.CommandText);
      cmd.Parameters.Clear();
      bool  namedParams = session.DriverInfo.SupportsNamedParameters;
      Utils       utils = session.utils;
      
      if (namedParams) {
        foreach (QueryParameter p in parameters)
          cmd.Parameters.Add(ConvertParameter(utils, p));
      }
      else {
        foreach (string pName in unnamed2Named) {
          QueryParameter p = parameters[pName];
          if (p==null)
            break;
          cmd.Parameters.Add(ConvertParameter(utils, p));
        }
      }
      parameters.translated = true;
    }
    
    private IDbDataParameter ConvertParameter(Utils utils, QueryParameter queryParameter)
    {
      IDbDataParameter dbParameter = utils.ConvertParameter(queryParameter);
      if (dbParameter.DbType==DbType.DateTime && dbParameter.Value!=null) {
        DateTime dateTime = (DateTime)dbParameter.Value;
        if (dateTime==DateTime.MinValue)
          dbParameter.Value = utils.GetMinimumDateTimeValue(SqlType.DateTime);
      }
      return dbParameter;
    }
    
    /// <summary>
    /// Builds the command for further execution and sets
    /// <see cref="Translated"/> property to <see langword="true"/>.
    /// </summary>
    /// <param name="sqlCondition">Primary "where" condition.</param>
    /// <param name="ftsCondition">Full-text search "where" condition.</param>
    /// <param name="sqlOrderBy">"Order by" expression.</param>
    /// <remarks>
    /// All "where" conditions are combined with "and" operator.
    /// </remarks>
    protected virtual void BuildCommand(
      string sqlCondition,
      FtsCondition ftsCondition,
      string sqlOrderBy, PageInfo pageInfo)
    {
      IDbCommand cmd = GetCommand();
      parameters.translated = false;
      unnamed2Named.Clear();
      cmd.Parameters.Clear();

      UpdateFetchInstances(ResultType, field, objectModelType);
      
      if (!IsSubQuery()) {
        string additionalRestriction = "";
        session.OnQueryBeforeExecute(this, ref additionalRestriction);
        
        if (additionalRestriction.Trim()!="") {
          if (sqlCondition.Trim()!="") 
            sqlCondition = String.Format("({0}) and ({1})", sqlCondition, additionalRestriction);
          else
            sqlCondition = additionalRestriction;
        }
      }
      
      if (!HasDynamicRestriction()){
      if (ftsCondition!=null && !(Domain.FtsDriver is NativeFtsDriver))
        ftsResult = ExecuteFtsQuery(ftsCondition);
      
      if (boFetchInstances)
        cmd.CommandText = 
        session.persister.BuildQueryCommandText(
          IsSubQuery(), 
          idOnly,
          objectModelType.RelatedView,
          RootName,
          options,
          freeOptions,
          top,
          TranslateJoins(joins),
          TranslateSqlCondition(sqlCondition.Trim()),
          ftsCondition,
          sqlRestriction.Trim(),
          TranslateSqlOrderBy(sqlOrderBy.Trim()),
          pageInfo,
          ref sqlIsDistinct,
          ref ftsResult
          );
      else {
        ICollectionField collectionField = (ICollectionField)field;
        cmd.CommandText = 
        session.persister.PersisterForCollections.BuildQueryCommandText(
          IsSubQuery(), 
          idOnly,
          collectionField.GetSchemaNode(fieldCulture),
          RootName,
          collectionField.GetOwnerIdColumnName(fieldCulture),
          collectionField.GetItemIdColumnName(fieldCulture),
          options,
          top,
          TranslateJoins(joins).JoinClause,
          TranslateSqlCondition(sqlCondition.Trim()),
          ftsCondition,
          sqlRestriction.Trim(),
          TranslateSqlOrderBy(sqlOrderBy.Trim()),
          collectionField.GetDataColumnNames(fieldCulture),
          ref sqlIsDistinct
          );
      }
      translated = true;
      
      TranslateParameters();
      }
    }

    internal FtsResult ExecuteFtsQuery(FtsCondition ftsCondition)
    {
      if (ftsCondition.Top==0) {
        ftsCondition = ftsCondition.Clone();
        ftsCondition.top = Domain.DriverInfo.QueryComparisonsLimit - 128;
      }
      return Domain.FtsDriver.ExecuteQuery(session, ftsCondition);
    }

    /// <summary>
    /// Updates the command. This method doesn't modify parameters
    /// collection.
    /// </summary>
    /// <param name="sqlCondition">Primary "where" condition.</param>
    /// <param name="ftsCondition">Full-text search "where" condition.</param>
    /// <param name="sqlOrderBy">"Order by" expression.</param>
    /// <remarks>
    /// All "where" conditions are combined with "and" operator.
    /// </remarks>
    protected virtual void UpdateCommand(
      string sqlCondition,
      FtsCondition ftsCondition,
      string sqlOrderBy,
      PageInfo pageInfo
      )
    {
      unnamed2Named.Clear();

      UpdateFetchInstances(ResultType, field, objectModelType);

      
      if (!IsSubQuery()) {
        string additionalRestriction = "";
        session.OnQueryBeforeExecute(this, ref additionalRestriction);
        
        if (additionalRestriction.Trim()!="") {
          if (sqlCondition.Trim()!="") 
            sqlCondition = String.Format("({0}) and ({1})", sqlCondition, additionalRestriction);
          else
            sqlCondition = additionalRestriction;
        }
      }  
      
      if (ftsCondition!=null && !(Domain.FtsDriver is NativeFtsDriver))
        ftsResult = ExecuteFtsQuery(ftsCondition);
      
      IDbCommand cmd = GetCommand();
      if (boFetchInstances)
        cmd.CommandText = 
        session.persister.BuildQueryCommandText(
          IsSubQuery(), 
          idOnly,
          objectModelType.RelatedView,
          RootName,
          options,
          freeOptions,
          top,
          TranslateJoins(joins),
          TranslateSqlCondition(sqlCondition.Trim()),
          ftsCondition,
          sqlRestriction.Trim(),
          TranslateSqlOrderBy(sqlOrderBy.Trim()),
          pageInfo,
          ref sqlIsDistinct,
          ref ftsResult
          );
      else {
        ICollectionField collectionField = (ICollectionField)field;
        cmd.CommandText = 
        session.persister.PersisterForCollections.BuildQueryCommandText(
          IsSubQuery(), 
          idOnly,
          collectionField.GetSchemaNode(fieldCulture),
          RootName,
          collectionField.GetOwnerIdColumnName(fieldCulture),
          collectionField.GetItemIdColumnName(fieldCulture),
          options,
          top,
          TranslateJoins(joins).JoinClause,
          TranslateSqlCondition(sqlCondition.Trim()),
          ftsCondition,
          sqlRestriction.Trim(),
          TranslateSqlOrderBy(sqlOrderBy.Trim()),
          collectionField.GetDataColumnNames(fieldCulture),
          ref sqlIsDistinct
          );
      }
    }
    
    public JoinTranslationResult TranslateJoins(SqlJoinCollection joins)
    {
      StringBuilder sb = new StringBuilder();
      int cnt = joins.Count;
      JoinTranslationResult result = new JoinTranslationResult();
      result.FromClausePrefix = "";

      string delimeter = " ";
      if (Domain.DriverInfo.RequiresExplicitJoinOrder)
      {
        for (int i=0; i< cnt-1; i++)
          result.FromClausePrefix += "(";
        delimeter += ") ";
      }

      for (int i = 0; i<cnt; i++) {
        SqlJoin join = joins[i];

        string sJoinType = "";
        switch (join.joinType)
        {
          case SqlJoinType.Inner:
            sJoinType = "inner join";
            break;
          case SqlJoinType.LeftOuter:
            sJoinType = "left join";
            break;
//          case SqlJoinType.RightOuter:
//            sJoinType = "right join";
//            break;
//          case SqlJoinType.FullOuter:
//            sJoinType = "full join";
//            break;
//          case SqlJoinType.Cross:
//            sJoinType = "cross join";
//            break;
          default:
            throw new InvalidOperationException("Unsupported join type.");
        }
        
        if (i>0)
          sb.Append(delimeter);
        if (join.alias==null || join.alias.Trim()=="")
          sb.Append(session.persister.BuildJoinExpression(sJoinType,
            session.utils.QuoteIdentifier(join.tableName),
            null,
            TranslateSqlCondition(join.condition)));
        else
          sb.Append(session.persister.BuildJoinExpression(sJoinType,
            session.utils.QuoteIdentifier(join.tableName),
            session.utils.QuoteIdentifier(join.alias.Trim()),
            TranslateSqlCondition(join.condition)));

      }
      result.JoinClause = sb.ToString();
      return result;
    }
    
    private string TranslateSqlCondition(string sqlExpression)
    {
      StringBuilder result = new StringBuilder(64);
      Info   di = session.DriverInfo;
      bool   bSquareBrackets = di.SupportsSquareBrackets;
      bool   bNamedParams    = di.SupportsNamedParameters;
      string sParamPrefix    = di.ParameterPrefix;

      int  leftPos = 0;
      int  curPos  = 0;
      int  brCnt   = 0;
      int  l = sqlExpression.Length;

      while (curPos<l) {
        switch (sqlExpression[curPos]) {
        case ';':
          throw new InvalidSqlException("';' is not allowed here", sqlExpression, curPos);
        // Validate brackets
        case '(':
          brCnt++; 
          break;
        case ')':
          brCnt--; 
          if (brCnt<0) 
            throw new InvalidSqlException("')' is not allowed here", sqlExpression, curPos);
          break;
        // Strings
        case '\'':
          while (true) {
            if (++curPos>=l)
              throw new InvalidSqlException("' expected", sqlExpression, curPos);
            if (sqlExpression[curPos]=='\'') {
              if (++curPos>=l) {
                curPos--;
                break;
              }
              if (sqlExpression[curPos]!='\'') {
                curPos--;
                break;
              }
            }
          }
          break;
        // Quoted indentifiers
        case '"':
          while (true) {
            if (++curPos>=l)
              throw new InvalidSqlException("\" expected", sqlExpression, curPos);
            if (sqlExpression[curPos]=='"')
              break;
          }
          break;
        // Embraced indentifiers
        case '[':
          if (!bSquareBrackets)
            break;
          while (true) {
            if (++curPos>=l)
              throw new InvalidSqlException("']' expected", sqlExpression, curPos);
            if (sqlExpression[curPos]==']')
              break;
          }
          break;
        }
        curPos++;
      }
      // Final checks
      if (brCnt!=0) 
        throw new InvalidSqlException("')' expected", sqlExpression, curPos);
      result.Append(sqlExpression.Substring(leftPos,curPos-leftPos));
      return result.ToString();
    }
    
    private string TranslateSqlOrderBy(string sqlExpression)
    {
      StringBuilder result = new StringBuilder(32);
      Info   di = session.DriverInfo;
      bool   bSquareBrackets = di.SupportsSquareBrackets;
      bool   bNamedParams    = di.SupportsNamedParameters;
      string sParamPrefix    = di.ParameterPrefix;

      int  lastRBrPos = 0;
      int  leftPos = 0;
      int  curPos  = 0;
      int  brCnt   = 0;
      int  l = sqlExpression.Length;

      while (curPos<l) {
        switch (sqlExpression[curPos]) {
        case ';':
          throw new InvalidSqlException("';' is not allowed here", sqlExpression, curPos);
        // Validate brackets
        case '(':
          brCnt++; 
          if (brCnt==1) {
            string midStr = sqlExpression.Substring(lastRBrPos,curPos-lastRBrPos);
            if (lastRBrPos==0) {
              if (!rOrderByLStr.IsMatch(midStr))
                throw new InvalidSqlException("error in the 'order by' clause", sqlExpression, lastRBrPos);
            }
            else
              if (!rOrderByMStr.IsMatch(midStr))
                throw new InvalidSqlException("error in the 'order by' clause", sqlExpression, lastRBrPos);
          }
          break;
        case ')':
          brCnt--; 
          if (brCnt<0) 
            throw new InvalidSqlException("')' is not allowed here", sqlExpression, curPos);
          if (brCnt==0)
            lastRBrPos = curPos+1;
          break;
        // Strings
        case '\'':
          while (true) {
            if (++curPos>=l)
              throw new InvalidSqlException("' expected", sqlExpression, curPos);
            if (sqlExpression[curPos]=='\'') {
              if (++curPos>=l) {
                curPos--;
                break;
              }
              if (sqlExpression[curPos]!='\'') {
                curPos--;
                break;
              }
            }
          }
          break;
        // Quoted indentifiers
        case '"':
          while (true) {
            if (++curPos>=l)
              throw new InvalidSqlException("\" expected", sqlExpression, curPos);
            if (sqlExpression[curPos]=='"')
              break;
          }
          break;
        // Embraced indentifiers
        case '[':
          if (!bSquareBrackets)
            break;
          while (true) {
            if (++curPos>=l)
              throw new InvalidSqlException("']' expected", sqlExpression, curPos);
            if (sqlExpression[curPos]==']')
              break;
          }
          break;
        }
        curPos++;
      }
      // Final checks
      if (brCnt!=0) 
        throw new InvalidSqlException("')' expected", sqlExpression, curPos);
      string lastStr = sqlExpression.Substring(lastRBrPos);
      if (lastRBrPos==0) {
        if (!rOrderByLStr.IsMatch(lastStr))
          throw new InvalidSqlException("error in the 'order by' clause", sqlExpression, lastRBrPos);
      }
      else
        if (!rOrderByRStr.IsMatch(lastStr))
          throw new InvalidSqlException("error in the 'order by' clause", sqlExpression, lastRBrPos);
      result.Append(sqlExpression.Substring(leftPos,curPos-leftPos));
      return result.ToString();
    }

    private string TranslateSqlParams(string sqlExpression)
    {
      StringBuilder result = new StringBuilder(64);
      Info   di = session.DriverInfo;
      bool   bNamedParams    = di.SupportsNamedParameters;
      string sParamPrefix    = di.ParameterPrefix;

      int  leftPos = 0;
      int  curPos  = 0;
      char curChar = ' ';
      int  l = sqlExpression.Length;
      bool stringValue = false;

      while (curPos<l) {
        switch (sqlExpression[curPos]) {
        case '\'':
          stringValue ^= true;  
          break;
        case '@':
          if (!stringValue) {
            result.Append(sqlExpression.Substring(leftPos,curPos-leftPos));
            leftPos = curPos;
            if (++curPos>=l)
              throw new InvalidSqlException("invalid parameter name", sqlExpression, curPos);
            curChar = sqlExpression[curPos];
            if (!(
                    (curChar>='A' && curChar<='Z') ||
                    (curChar>='a' && curChar<='z') ||
                    (curChar=='_')
                  ))
              throw new InvalidSqlException("invalid parameter name", sqlExpression, curPos);
            while (true) {
              if (++curPos>=l)
                break;
              curChar = sqlExpression[curPos];
              if (!(
                      (curChar>='A' && curChar<='Z') ||
                      (curChar>='a' && curChar<='z') ||
                      (curChar>='0' && curChar<='9') ||
                      (curChar=='_')
                    ))
                break;
            }
            string paramName = sqlExpression.Substring(leftPos,curPos-leftPos);
            leftPos = curPos;
            if (bNamedParams)
              result.Append(sParamPrefix + paramName.Substring(1));
            else {
              result.Append(sParamPrefix);
              unnamed2Named.Add(paramName);
            }
            curPos--;
          }
          break;
        }
        curPos++;
      }
      result.Append(sqlExpression.Substring(leftPos,curPos-leftPos));
      return result.ToString();
    }    

    /// <summary>
    /// Returns internal command.
    /// </summary>
    /// <returns>Internal command.</returns>
    protected internal IDbCommand GetCommand()
    {
      if (command.Connection!=Session.InternalRealConnection)
        command.Connection = Session.InternalRealConnection;
      Transaction t = Session.transaction;
      if (t != null && !(t._realTransaction is IDBTransactionProxy))
      {
          if (t != null && t._realTransaction != null &&
              t.PhysicalTransaction != command.Transaction)
              command.Transaction = t.PhysicalTransaction;
      }
      if (command.CommandTimeout!=session.commandTimeout)
        command.CommandTimeout = session.commandTimeout;
      return command;
    }

    
    // Real command creation
    
    /// <summary>
    /// Creates <see cref="IDbCommand"/> that can be executed
    /// to perform the query.
    /// <seealso cref="Session.SecurityOptions"/>
    /// </summary>
    /// <returns><see cref="IDbCommand"/> that can be executed
    /// to perform the query.</returns>
    /// <remarks>
    /// <note type="note">You're allowed to invoke this method only when
    /// <see cref="DataObjects.NET.Session.SecurityOptions">Session.SecurityOptions</see>
    /// contains <see cref="SessionSecurityOptions.AllowAccessRealObjects"/> option.</note>
    /// </remarks>
    public IDbCommand CreateRealCommand()
    {
      if (session.disableSecurityThreads[Thread.CurrentThread]==null)
        if ((session.securityOptions & SessionSecurityOptions.AllowAccessRealObjects)==0)
          throw new SecurityException("Access to CreateRealCommand isn't allowed.");
      IDbCommand cmd = session.CreateRealCommand();
      // Backup
      IDbCommand originalCmd = command;
      bool originalTranslated = translated;
      bool originalParametersTranslated = parameters.translated;
      // Substitution
      translated = false;
      parameters.translated = false;
      command = cmd;
      try {
        Translate();
      }
      finally {
        // Restore
        translated = originalTranslated;
        parameters.translated = originalParametersTranslated;
        command = originalCmd;
      }
      return cmd;
    }

    /// <summary>
    /// Returns <see langword="true"/> when this query is a nested query.
    /// </summary>
    protected virtual bool IsSubQuery()
    {
      return false;
    }
    
    /// <summary>
    /// Returns <see langword="true"/> when query contains dynamic part
    /// and should be rebuilt on each execution.
    /// </summary>
    /// <returns><see langword="True"/> when query contains dynamic part
    /// and should be rebuilt on each execution.</returns>
    protected virtual bool HasDynamicRestriction()
    {
      return false; 
    }

    // Constructors
    
    /// <summary>
    /// Initializes an instance of this class.
    /// <seealso cref="Execute"/>
    /// <seealso cref="ExecuteArray"/>
    /// <seealso cref="ExecuteCount"/>
    /// </summary>
    /// <param name="session">Session, to which this query belongs.</param>
    /// <param name="instanceType">The type of object (including its 
    /// descendants) to search.</param>
    /// <param name="options">Query options.</param>
    internal QueryBase(Session session, System.Type instanceType, QueryOptions options):
      base(session)
    {
      this.parameters = new QueryParameterCollection();
      this.options    = options;
      this.joins = new SqlJoinCollection(this);
      command = session.InternalCreateRealCommand();
      InstanceType = instanceType;
    }
    
    /// <summary>
    /// Initializes an instance of this class.
    /// <seealso cref="Execute"/>
    /// <seealso cref="ExecuteArray"/>
    /// <seealso cref="ExecuteCount"/>
    /// </summary>
    /// <param name="session">Session, to which this query belongs.</param>
    /// <param name="instanceType">The type of object (including its descendants) 
    /// to search.</param>
    internal QueryBase(Session session, System.Type instanceType):
      base(session)
    {
      this.parameters = new QueryParameterCollection();
      this.options    = QueryOptions.Default;
      this.joins = new SqlJoinCollection(this);
      command = session.InternalCreateRealCommand();
      InstanceType = instanceType;
    }
    
    /// <summary>
    /// Initializes an instance of this class.
    /// <seealso cref="Execute"/>
    /// <seealso cref="ExecuteArray"/>
    /// <seealso cref="ExecuteCount"/>
    /// </summary>
    /// <param name="session">Session, to which this query belongs.</param>
    internal QueryBase(Session session):
      base(session)
    {
      this.parameters = new QueryParameterCollection();
      this.options    = QueryOptions.Default;
      this.joins      = new SqlJoinCollection(this);
      command = session.InternalCreateRealCommand();
      InstanceType = typeof(DataObject);
    }
    
    static QueryBase() 
    {
      rOrderByLStr = new Regex(@"^\s*$", RegexOptions.IgnoreCase | RegexOptions.Multiline | RegexOptions.Compiled);
      rOrderByMStr = new Regex(@"^\s*(asc|desc)?\s*,\s*$", RegexOptions.IgnoreCase | RegexOptions.Multiline | RegexOptions.Compiled);
      rOrderByRStr = new Regex(@"^\s*(asc|desc)?\s*$", RegexOptions.IgnoreCase | RegexOptions.Multiline | RegexOptions.Compiled);
    }

    // Destructors

    /// <summary>
    /// Performs application-defined tasks associated with freeing, releasing, or resetting unmanaged resources.
    /// </summary>
    void IDisposable.Dispose()
    {
      Dispose(true);
      GC.SuppressFinalize(this); 
    }

    private void Dispose(bool disposing) 
    {
      if (disposing) {
        if (command!=null)
          command.Dispose();
      }
      command = null;
    }

    /// <summary>
    /// Finalizer.
    /// </summary>
    ~QueryBase()
    {
      Dispose(false);
    }
  }
}
