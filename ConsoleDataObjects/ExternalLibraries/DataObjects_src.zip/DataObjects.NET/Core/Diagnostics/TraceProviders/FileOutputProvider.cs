// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Threading;

namespace DataObjects.NET.Diagnostics
{
  /// <summary>
  /// Default trace provider that posts messages to the file stream.
  /// </summary>
  public class FileOutputProvider: ITraceProvider
  {
    private FileStream fileStream;
    private FileOutputProviderOptions options;
    
    /// <summary>
    /// Gets trace options.
    /// </summary>
    public FileOutputProviderOptions Options {
      get {
        return options;
      }
    }
    
    /// <summary>
    /// Writes an entry to the event log.
    /// </summary>
    /// <param name="context">Trace context.</param>
    public void LogEvent(TraceContext context)
    {
      lock (this) {
        if ((options & FileOutputProviderOptions.LogDateTime)!=0) {
          WriteLine(DateTime.Now.ToString());
        }
        
        if ((options & FileOutputProviderOptions.LogThread)!=0) {
          string threadName = Thread.CurrentThread.Name;
          WriteLine("Thread: \"{0}\"", threadName==null ? "" : threadName);
        }
        
        if ((options & FileOutputProviderOptions.LogSession)!=0) {
          string sessionName = context.Session==null ? null : context.Session.Name;
          WriteLine("Session: \"{0}\"", sessionName==null ? "" : sessionName);
        }
        
        if ((options & FileOutputProviderOptions.LogMethod)!=0) {
          if (context.StackTrace!=null) {
            StackFrame stackFrame = context.StackTrace.GetFrame(0);
            MethodBase method = stackFrame.GetMethod();
            System.Type type = method.ReflectedType;
            WriteLine("Method: \"{0}.{1}\"", type.FullName, method.Name);
          }
        }
        
        if ((options & FileOutputProviderOptions.LogCategory)!=0) {
          string category = context.Category;
          WriteLine("Category: \"{0}\"", category==null ? "" : category);
        }
        
        WriteLine(context.Message);
        
        if ((options & FileOutputProviderOptions.LogStackTrace)!=0) {
          if (context.StackTrace!=null) {
            WriteLine("Stack trace:");
            for (int i=0; i<context.StackTrace.FrameCount; i++) {
              StackFrame stackFrame = context.StackTrace.GetFrame(i);
              MethodBase method = stackFrame.GetMethod();
              System.Type type = method.ReflectedType;
              WriteLine("  {0}.{1}", type.FullName, method.Name);
            }
          }
        }
        
        WriteLine("");
        
        fileStream.Flush();
      }
    }
    
    private void WriteLine(string format, params object[] args)
    {
      byte[] data = System.Text.Encoding.ASCII.GetBytes(String.Format(format, args));
      if (data.Length>0)
        fileStream.Write(data, 0, data.Length);
      data = System.Text.Encoding.ASCII.GetBytes("\n");
      fileStream.Write(data, 0, data.Length);
    }

    // Constructor
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="path">The relative or absolute path for the file to log events to.</param>
    public FileOutputProvider(string path): this(path, FileOutputProviderOptions.Default)
    {
    }
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="path">The relative or absolute path for the file to log events to.</param>
    /// <param name="options">Trace options.</param>
    public FileOutputProvider(string path, FileOutputProviderOptions options)
    {
      if (path==null)
        throw new ArgumentNullException("path");
        
      this.fileStream = new FileStream(path, FileMode.Append, FileAccess.Write, FileShare.Read);
      this.options = options;
    }
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="fileStream">File stream to log events to.</param>
    public FileOutputProvider(FileStream fileStream): this(fileStream, FileOutputProviderOptions.Default)
    {
    }
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="fileStream">File stream to log events to.</param>
    /// <param name="options">Trace options.</param>
    public FileOutputProvider(FileStream fileStream, FileOutputProviderOptions options)
    {
      if (fileStream==null)
        throw new ArgumentNullException("fileStream");
        
      if (!fileStream.CanWrite)
        throw new InvalidOperationException("Can not write to file stream.");
        
      this.fileStream = fileStream;
      this.options = options;
    }
  }
}
