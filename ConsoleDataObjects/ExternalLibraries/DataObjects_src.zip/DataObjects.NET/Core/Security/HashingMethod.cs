using System;
using System.Security.Cryptography;

namespace DataObjects.NET.Security
{
  /// <summary>
  /// Enumerates possible hashing methods
  /// (used e.g. in the <see cref="StdUser.SetPassword">StdUser.SetPassword</see>
  /// method).
  /// <seealso cref="StdUser"/>
  /// </summary>
  public enum HashingMethod
  {
    /// <summary>
    /// No hashing implied.
    /// </summary>
    None   = 0,
    /// <summary>
    /// Same as <see cref="None"/> - no hashing implied.
    /// </summary>
    Plain  = 0,
    /// <summary>
    /// <see cref="MD5"/> hashing.
    /// </summary>
    MD5    = 0x10,
    /// <summary>
    /// <see cref="SHA1"/> hashing.
    /// </summary>
    SHA1   = 0x100,
    /// <summary>
    /// <see cref="SHA256"/> hashing.
    /// </summary>
    SHA256 = 0x110,
    /// <summary>
    /// <see cref="MD5"/> hashing + GUID 
    /// (prevents detection of equal passwords by hash comparison).
    /// </summary>
    MD5v2  = 0x11,
    /// <summary>
    /// <see cref="SHA1"/> hashing + GUID 
    /// (prevents detection of equal passwords by hash comparison).
    /// </summary>
    SHA1v2 = 0x101,
    /// <summary>
    /// <see cref="SHA256"/> hashing + GUID 
    /// (prevents detection of equal passwords by hash comparison).
    /// </summary>
    SHA256v2 = 0x111
  }
}
