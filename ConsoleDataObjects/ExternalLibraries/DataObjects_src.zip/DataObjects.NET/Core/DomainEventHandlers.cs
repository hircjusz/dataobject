// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.IO;
using System.Data;
using System.Collections;
using System.Reflection;
using System.Text.RegularExpressions;
using System.CodeDom;
using System.CodeDom.Compiler;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Lifetime;
using System.Windows.Forms;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Attributes;
using DataObjects.NET.Database;
using DataObjects.NET.DatabaseModel;
using DataObjects.NET.DatabaseModel.Builders;
using DataObjects.NET.DatabaseModel.Extractors;
using DataObjects.NET.DatabaseModel.Comparers;
using DataObjects.NET.ObjectModel;
using DataObjects.NET.ObjectModel.Builders;
using DataObjects.NET.FullText;
using DataObjects.NET.Security;
using DataObjects.NET.Security.Permissions;

namespace DataObjects.NET
{
  /// <summary>
  /// Provides information for 
  /// <see cref="DataObjects.NET.Session"/>-related events 
  /// (or events that should use some <see cref="DataObjects.NET.Session"/> instance)
  /// in the <see cref="DataObjects.NET.Domain"/>.
  /// <seealso cref="SessionEventHandler"/>
  /// <seealso cref="DataObjects.NET.Domain.SessionCreated"/>
  /// <seealso cref="DataObjects.NET.Session"/>
  /// <seealso cref="DataObjects.NET.Domain"/>
  /// </summary>
  public class SessionEventArgs: EventArgs
  {
    private Session session;
    /// <summary>
    /// Gets the session where event takes place 
    /// (or which should be used to process the event).
    /// </summary>
    public   Session Session {
      get {
        return session;
      }
    }

    /// <summary>
    /// Gets the domain where event takes place
    /// (or which should be used to process the event).
    /// </summary>
    public  Domain Domain {
      get {
        if (session!=null)
          return session.domain;
        else
          return null;
      }
    }

    /// <summary>
    /// Gets or sets <see cref="DataObjects.NET.Session.SecurityOptions">Session.SecurityOptions</see>.
    /// </summary>
    /// <remarks>
    /// This property reflects 
    /// <see cref="DataObjects.NET.Session.SecurityOptions">Session.SecurityOptions</see>
    /// value and allows to change it, if <see cref="SessionSecurityOptionsCanBeChanged"/> is
    /// <see langword="true"/>.
    /// </remarks>
    public   SessionSecurityOptions SecurityOptions  {
      get {
        return session.securityOptions;
      }
      set {
        if (sessionSecurityOptionsCanBeChanged) {
          session.securityOptions = value;
          session.EnforceSecurityOptions();
        }
        else
          throw new InvalidOperationException(
            "Session security options can't be changed on this event.");
      }
    }

    internal bool sessionSecurityOptionsCanBeChanged;
    /// <summary>
    /// Determines whether the <see cref="SessionSecurityOptions"/> property
    /// can be used to change <see cref="DataObjects.NET.Session.SecurityOptions">Session.SecurityOptions</see>
    /// in the event handler.
    /// </summary>
    public   bool SessionSecurityOptionsCanBeChanged {
      get {
        return sessionSecurityOptionsCanBeChanged;
      }
    }
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="session">Session where the event takes place
    /// (or which should be used to process the event).</param>
    /// <param name="sessionSecurityOptionsCanBeChanged"><see langword="True"/>,
    /// if <see cref="SessionSecurityOptions"/> property can be changed by event handler.</param>
    public SessionEventArgs(Session session, bool sessionSecurityOptionsCanBeChanged)
    {
      if (session==null)
        throw new ArgumentNullException("session");
      this.session = session;
      this.sessionSecurityOptionsCanBeChanged = sessionSecurityOptionsCanBeChanged;
    }
  }

  /// <summary>
  /// Represents a method that handles 
  /// <see cref="DataObjects.NET.Session"/>-related events
  /// in the <see cref="DataObjects.NET.Domain"/>.
  /// <seealso cref="SessionEventArgs"/>
  /// <seealso cref="DataObjects.NET.Domain.SessionCreated"/>
  /// <seealso cref="DataObjects.NET.Session"/>
  /// <seealso cref="DataObjects.NET.Domain"/>
  /// </summary>
  public delegate void SessionEventHandler(object sender, SessionEventArgs e);

  /// <summary>
  /// Provides information for 
  /// <see cref="DataObjects.NET.Domain"/>-related events.
  /// <seealso cref="DomainEventHandler"/>
  /// <seealso cref="DataObjects.NET.Domain"/>
  /// </summary>
  public class DomainEventArgs: EventArgs
  {
    private Domain domain;
    /// <summary>
    /// Gets the domain where event takes place
    /// (or which should be used to process the event).
    /// </summary>
    public  Domain Domain {
      get { return domain;}
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="domain"><see cref="Domain"/> where the event takes place
    /// (or which should be used to process the event).</param>
    public DomainEventArgs(Domain domain)
    {
      if (domain==null)
        throw new ArgumentNullException("domain");
      this.domain = domain;
    }
  }

  /// <summary>
  /// Represents a method that handles 
  /// <see cref="DataObjects.NET.Domain"/>-related events.
  /// <seealso cref="DomainEventArgs"/>
  /// <seealso cref="DataObjects.NET.Domain"/>
  /// </summary>
  public delegate void DomainEventHandler(object sender, DomainEventArgs e);

  /// <summary>
  /// Provides information for authentication-related events
  /// in the <see cref="DataObjects.NET.Domain"/>.
  /// <seealso cref="AuthenticationEventHandler"/>
  /// <seealso cref="DataObjects.NET.Domain.CreateSession"/>
  /// <seealso cref="DataObjects.NET.Session.Authenticate"/>
  /// <seealso cref="DataObjects.NET.Session"/>
  /// <seealso cref="DataObjects.NET.Domain"/>
  /// </summary>
  public class AuthenticationEventArgs: SessionEventArgs
  {
    internal bool  isLocked;
    internal bool  isRetryLocked;
    private string userName;
    /// <summary>
    /// Gets or sets the user name.
    /// Change this property to override the original user name.
    /// </summary>
    public  string UserName {
      get { 
        return userName;
      }
      set {
        if (!isLocked)
          userName = value;
        else
          throw new InvalidOperationException(
            "Can't change this property in this event handler.");
      }
    }
    
    private  object[] authParams;
    /// <summary>
    /// Gets or sets authentication parameters (e.g. password).
    /// Change this property to override the original authentication parameters.
    /// </summary>
    public   object[] AuthParams {
      get {
        return authParams;
      }
      set {
        if (!isLocked)
          authParams = value;
        else
          throw new InvalidOperationException(
            "Can't change this property in this event handler.");
      }
    }
    
    private bool retry;
    /// <summary>
    /// Determines whether the authentication should be processed once more.
    /// Change authentication parameters and set this property to 
    /// <see langword="true"/> in the 
    /// <see cref="DataObjects.NET.Domain.UserAuthenticationFailed">Domain.UserAuthenticationFailed</see>
    /// event handler to repeat the authentication.
    /// </summary>
    public  bool Retry {
      get {
        return retry;
      }
      set {
        if (!isLocked && !isRetryLocked)
          retry = value;
        else
          throw new InvalidOperationException(
            "Can't change this property in this event handler.");
      }
    }
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="session">Session where the event takes place
    /// (or which should be used to process the event).</param>
    /// <param name="sessionSecurityOptionsCanBeChanged"><see langword="True"/>,
    /// if <see cref="SessionSecurityOptions"/> property can be changed by event handler.</param>
    /// <param name="userName">User name.</param>
    /// <param name="authParams">Authentication parameters (e.g. password).</param>
    public AuthenticationEventArgs(Session session, bool sessionSecurityOptionsCanBeChanged, 
      string userName, object[] authParams):
      base(session, sessionSecurityOptionsCanBeChanged)
    {
      this.userName = userName;
      this.authParams = authParams;
    }
  }
  
  /// <summary>
  /// Represents a method that handles authentication events
  /// in the <see cref="DataObjects.NET.Domain"/>.
  /// <seealso cref="AuthenticationEventArgs"/>
  /// <seealso cref="DataObjects.NET.Domain.CreateSession"/>
  /// <seealso cref="DataObjects.NET.Session.Authenticate"/>
  /// <seealso cref="DataObjects.NET.Session"/>
  /// <seealso cref="DataObjects.NET.Domain"/>
  /// </summary>
  public delegate void AuthenticationEventHandler(object sender, AuthenticationEventArgs e);


  /// <summary>
  /// Provides information for 
  /// <see cref="DataObjects.NET.Security.User"/>-related events
  /// in the <see cref="DataObjects.NET.Domain"/>.
  /// <seealso cref="UserEventHandler"/>
  /// <seealso cref="DataObjects.NET.Session.User"/>
  /// <seealso cref="DataObjects.NET.Session"/>
  /// <seealso cref="DataObjects.NET.Domain"/>
  /// </summary>
  public class UserEventArgs: SessionEventArgs
  {
    private  User user;
    /// <summary>
    /// Gets the user related to the event.
    /// </summary>
    public   User User {
      get { 
        return user;
      }
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="session">Session where the event takes place
    /// (or which should be used to process the event).</param>
    /// <param name="sessionSecurityOptionsCanBeChanged"><see langword="True"/>,
    /// if <see cref="SessionSecurityOptions"/> property can be changed by event handler.</param>
    /// <param name="user">User related to the event.</param>
    public UserEventArgs(Session session, bool sessionSecurityOptionsCanBeChanged, User user):
      base(session, sessionSecurityOptionsCanBeChanged)
    {
      this.user = user;
    }
  }
  
  /// <summary>
  /// Represents a method that handles 
  /// <see cref="DataObjects.NET.Security.User"/>-related 
  /// in the <see cref="DataObjects.NET.Domain"/>.
  /// <seealso cref="UserEventArgs"/>
  /// <seealso cref="DataObjects.NET.Security.User"/>
  /// <seealso cref="DataObjects.NET.Session"/>
  /// <seealso cref="DataObjects.NET.Domain"/>
  /// </summary>
  public delegate void UserEventHandler(object sender, UserEventArgs e);
}
