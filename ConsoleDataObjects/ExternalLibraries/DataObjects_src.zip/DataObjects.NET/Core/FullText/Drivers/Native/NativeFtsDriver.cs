// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using DataObjects.NET.Database;

namespace DataObjects.NET.FullText.Drivers.Native
{
  /// <summary>
  /// Native full-text indexing and search driver implementation.
  /// This class is mainly a stub, since most of native full-text 
  /// search tasks are executed by the underlying database driver.
  /// </summary>
  public sealed class NativeFtsDriver 
    : FtsDriver
  {
    // Driver registration code
    static NativeFtsDriver()
    {
      RegisteredDrivers.Add("native",   typeof(NativeFtsDriver));
      RegisteredDrivers.Add("dbnative", typeof(NativeFtsDriver));
      RegisteredDrivers.Add("builtin",  typeof(NativeFtsDriver));
    }

    /// <summary>
    /// Driver type ("Native").
    /// </summary>
    public override string Type {
      get {
        return "Native";
      }
    }

    /// <summary>
    /// Driver description.
    /// </summary>
    public override string Description {
      get {
        return "Native full-text indexing and search driver for DataObjects.NET";
      }
    }

    /// <summary>
    /// Driver company (developer).
    /// </summary>
    public override string Company {
      get {
        return "X-tensive.com, INLINE";
      }
    }

    /// <summary>
    /// Creates a new full-text indexing service instance.
    /// </summary>
    /// <param name="session"><see cref="Session"/> to create full-text indexing service in.</param>
    /// <returns>Newly created <see cref="NativeFtIndexer"/> instance.</returns>
    /// <remarks>
    /// This method always returns a newly created 
    /// <see cref="NativeFtIndexer"/> instance.
    /// </remarks>
    public override RuntimeService CreateFtIndexer(Session session)
    {
      return (RuntimeService) session.CreateService(typeof(FtIndexerService), new NativeFtIndexer());
    }

    /// <summary>
    /// Creates a new full-text indexing service instance.
    /// </summary>
    /// <param name="session"><see cref="Session"/> to create full-text indexing service in.</param>
    /// <param name="period">Time interval between indexing iterations.</param>
    /// <returns>Newly created full-text indexing service instance.</returns>
    public override RuntimeService CreateFtIndexer (Session session, TimeSpan period)
    {
      return (RuntimeService) session.CreateService(typeof(FtIndexerService), new NativeFtIndexer(period));
    }

    /// <summary>
    /// Creates a new full-text indexing service instance.
    /// </summary>
    /// <param name="session"><see cref="Session"/> to create full-text indexing service in.</param>
    /// <param name="period">Time interval between indexing iterations.</param>
    /// <param name="shortPeriod">Time interval between next indexing iteration 
    /// in case when the previous indexing iteration wasn't fully completed.</param>
    /// <returns>Newly created full-text indexing service instance.</returns>
    public override RuntimeService CreateFtIndexer (Session session, TimeSpan period, TimeSpan shortPeriod)
    {
      return (RuntimeService) session.CreateService(typeof(FtIndexerService), new NativeFtIndexer(period, shortPeriod));
    }

    /// <summary>
    /// Creates a new full-text indexing service instance.
    /// </summary>
    /// <param name="session"><see cref="Session"/> to create full-text indexing service in.</param>
    /// <param name="period">Time interval between indexing iterations.</param>
    /// <param name="shortPeriod">Time interval between next indexing iteration 
    /// in case when the previous indexing iteration wasn't fully completed.</param>
    /// <param name="maxObjectsPerIteration">Maximal number of objects that can 
    /// be processed per one iteration.</param>
    /// <returns>Newly created full-text indexing service instance.</returns>
    public override RuntimeService CreateFtIndexer (
      Session session, TimeSpan period, TimeSpan shortPeriod, int maxObjectsPerIteration)
    {
      return (RuntimeService) session.CreateService(
                                typeof(FtIndexerService),
                                new NativeFtIndexer(period, shortPeriod, maxObjectsPerIteration));
    }

    /// <summary>
    /// Creates a new full-text indexing service instance.
    /// </summary>
    /// <param name="session"><see cref="Session"/> to create full-text indexing service in.</param>
    /// <param name="maxObjectsPerIteration">Maximal number of objects that can 
    /// be processed per one iteration.</param>
    /// <returns>Newly created full-text indexing service instance.</returns>
    public override RuntimeService CreateFtIndexer (Session session, int maxObjectsPerIteration)
    {
      return (RuntimeService) session.CreateService(typeof(FtIndexerService), new NativeFtIndexer(maxObjectsPerIteration));
    }

    /// <summary>
    /// The name of a background indexing service.
    /// </summary>
    public const string RuntimeServiceName = "NativeFtIndexer service";
    
    /// <summary>
    /// Starts full-text indexer as a <see cref="RuntimeService"/>.
    /// </summary>
    public override void StartBackgroundIndexing ()
    {
      Domain.RuntimeServices.AddRuntimeService(
        RuntimeServiceName, typeof(FtIndexerService), new NativeFtIndexer());
    }

    /// <summary>
    /// Starts full-text indexer as a <see cref="RuntimeService"/>.
    /// </summary>
    /// <param name="period">Time interval between indexing iterations.</param>
    public override void StartBackgroundIndexing (TimeSpan period)
    {
      Domain.RuntimeServices.AddRuntimeService(
        RuntimeServiceName, typeof(FtIndexerService), new NativeFtIndexer(period));
    }

    /// <summary>
    /// Starts full-text indexer as a <see cref="RuntimeService"/>.
    /// </summary>
    /// <param name="period">Time interval between indexing iterations.</param>
    /// <param name="shortPeriod">Time interval between next indexing iteration 
    /// in case when the previous indexing iteration wasn't fully completed.</param>
    public override void StartBackgroundIndexing (TimeSpan period, TimeSpan shortPeriod)
    {
      Domain.RuntimeServices.AddRuntimeService(
        RuntimeServiceName, typeof(FtIndexerService), new NativeFtIndexer(period, shortPeriod));
    }

    /// <summary>
    /// Starts full-text indexer as a <see cref="RuntimeService"/>.
    /// </summary>
    /// <param name="period">Time interval between indexing iterations.</param>
    /// <param name="shortPeriod">Time interval between next indexing iteration 
    /// in case when the previous indexing iteration wasn't fully completed.</param>
    /// <param name="maxObjectsPerIteration">Maximal number of objects that can 
    /// be processed per one iteration.</param>
    public override void StartBackgroundIndexing (TimeSpan period, TimeSpan shortPeriod, int maxObjectsPerIteration)
    {
      Domain.RuntimeServices.AddRuntimeService(
        RuntimeServiceName, typeof(FtIndexerService), new NativeFtIndexer(period, shortPeriod, maxObjectsPerIteration));
    }

    /// <summary>
    /// Starts full-text indexer as a <see cref="RuntimeService"/>.
    /// </summary>
    /// <param name="maxObjectsPerIteration">Maximal number of objects that can 
    /// be processed per one iteration.</param>
    public override void StartBackgroundIndexing (int maxObjectsPerIteration)
    {
      Domain.RuntimeServices.AddRuntimeService(
        RuntimeServiceName, typeof(FtIndexerService), new NativeFtIndexer(maxObjectsPerIteration));
    }

    /// <summary>
    /// Stops full-text indexer which is previously started with the <see cref="StartBackgroundIndexing"/>
    /// method, if any.
    /// </summary>
    public override void StopBackgroundIndexing ()
    {
      Domain.RuntimeServices.RemoveRuntimeService(RuntimeServiceName);
    }

    /// <summary>
    /// Executes full-text query (see <see cref="FtsCondition"/>) in the
    /// specified <see paramref="session"/>.
    /// </summary>
    /// <param name="session"><see cref="Session"/> where query is executed.</param>
    /// <param name="ftsCondition">Full-text search condition.</param>
    /// <returns>Full-text query result.</returns>
    /// <remarks>
    /// Since this method shoudn't be normally invoked for this type
    /// of driver (built-in capabilities of the underlying DataObjects.NET
    /// Database <see cref="Driver"/> are used instead), it always
    /// throws <see cref="InvalidOperationException"/>("NativeFtIndexer.ExecuteQuery shouldn't be ever invoked.").
    /// </remarks>
    public override FtsResult ExecuteQuery(Session session, FtsCondition ftsCondition)
    {
      throw new InvalidOperationException(
        "NativeFtIndexer.ExecuteQuery shouldn't be ever invoked.");
    }


    // Constructors

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="connectionInfo">Configuration parameters of this full-text search driver.</param>
    /// <param name="domain"><see cref="Domain"/> this driver belongs to.</param>
    public NativeFtsDriver(ConnectionInfo connectionInfo, Domain domain): 
      base(connectionInfo, domain)
    {
    }
  }
}
