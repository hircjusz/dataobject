// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using DataObjects.NET.Database;

namespace DataObjects.NET.Internals
{
  internal class RDBMSVersionRange
  {
    private RDBMSVersion leftBound;
    private RDBMSVersion rightBound;

    public bool Contains (RDBMSVersion version)
    {
      return leftBound.CompareTo(version)<=0 && rightBound.CompareTo(version)>=0;
    }
 
    public static RDBMSVersionRange Parse (string version)
    {
      if (version==null || version.Length==0)
        throw new ArgumentOutOfRangeException("version", "Argument value is null or empty string.");
      RDBMSVersionRange range = new RDBMSVersionRange();
      int dashIndex = version.IndexOf('-');
      if (dashIndex<0) {
        range.leftBound = RDBMSVersion.Parse(version.Replace("*", "0"));
        range.rightBound = RDBMSVersion.Parse(version.Replace("*", "32767"));
      }
      else {
        range.leftBound = RDBMSVersion.Parse(version.Substring(0, dashIndex).Replace("*", "0"));
        range.rightBound = RDBMSVersion.Parse(version.Substring(dashIndex+1).Replace("*", "32767"));
      }
      return range;
    }

    // Constructors
    
    private RDBMSVersionRange ()
    {
    }
  }
}
