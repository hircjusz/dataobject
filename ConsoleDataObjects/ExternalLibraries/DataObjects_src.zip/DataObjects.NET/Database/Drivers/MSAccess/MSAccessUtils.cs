// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Attributes;

namespace DataObjects.NET.Database.Drivers.MSAccess
{
  /// <summary>
  /// Microsoft Access implementation of <see cref="Utils"/>.
  /// </summary>
  public class MSAccessUtils: Utils
  {
    /// <summary>
    /// Returns string with the name for specified <see cref="SqlType"/>.
    /// </summary>
    /// <param name="sqlType">Type to get the name for.</param>
    /// <returns>String with the name for specified <see cref="SqlType"/>.</returns>
    public override string GetSqlTypeName(SqlType sqlType)
    {
      switch (sqlType)
      {
        case SqlType.Boolean:
          return "bit";

        case SqlType.SByte:
          return "byte";
        case SqlType.Byte:
          return "byte";
        case SqlType.Int16:
          return "short";
        case SqlType.UInt16:
          return "short";
        case SqlType.Int32:
          return "long";
        case SqlType.UInt32:
          return "long";
        case SqlType.Int64:
          return "long";
        case SqlType.UInt64:
          return "long";

        case SqlType.Decimal:
          return "decimal";
        case SqlType.Float:
          return "double";
        case SqlType.Double:
          return "double";

        case SqlType.SmallMoney:
          return "decimal";
        case SqlType.Money:
          return "decimal";

        case SqlType.SmallDateTime:
          return "datetime";
        case SqlType.DateTime:
          return "datetime";

        // non-Unicode 
        case SqlType.AnsiChar:
          return "varchar";
        case SqlType.AnsiVarChar:
          return "varchar";
        case SqlType.AnsiText:
          return "LONGTEXT";
        // Unicode 
        case SqlType.Char:
          return "varchar";
        case SqlType.VarChar:
          return "varchar";
        case SqlType.Text:
          return "longtext";
        
        // Binary
        case SqlType.Binary:
          return "binary";
        case SqlType.VarBinary:
          return "varbinary";
        case SqlType.Image:
          return "longbinary";
        
        // Other
        case SqlType.TimeStamp:
          return "datetime";
        case SqlType.GUID:
          return "guid";

        // Unknown
        default: 
          throw new ArgumentException("Unknown (or unsupported) SQL type.", "sqlType");
      }
    }

    /// <summary>
    /// Compares two <see cref="SqlCollation"/>s.
    /// </summary>
    /// <param name="first">First object to be compared.</param>
    /// <param name="second">Second object to be compared.</param>
    /// <returns><see langword="True"/> if objects are equal; 
    /// <see langword="false"/> if the objects are different.</returns>
    public override bool CompareSqlCollations(SqlCollation first, SqlCollation second)
    {
      return true;
    }

    /// <summary>
    /// Returns string with the name for specified <see cref="SqlCollation"/>.
    /// </summary>
    /// <param name="sqlCollation">Collation to get the name for.</param>
    /// <returns>String with the name for specified <see cref="SqlCollation"/>.</returns>
    public override string GetSqlCollationName(SqlCollation sqlCollation)
    {
      if (sqlCollation==SqlCollation.Unknown)
        throw new ArgumentException("Unknown SQL collation.", "sqlCollation");
      return "";
    }
          
    /// <summary>
    /// Returns <see cref="SqlCollation"/> for specified collation name.
    /// </summary>
    /// <param name="name">Collation name to get the <see cref="SqlCollation"/> for.</param>
    /// <returns><see cref="SqlCollation"/> for specified collation name.</returns>
    public override SqlCollation GetSqlCollation(string name)
    {
      if (name=="")
        return SqlCollation.Neutral;
      return SqlCollation.Unknown;
    }

    /// <summary>
    /// Returns default value for specified <see cref="SqlType"/> (as string).
    /// </summary>
    /// <param name="sqlType">Type to get the default value for.</param>
    /// <returns>Default value for specified <see cref="SqlType"/> (as string).</returns>
    public override string GetDefault(SqlType sqlType)
    {
      switch (sqlType) {
//        case SqlType.Binary:
//          return "Cast('' as binary(1))";
//        case SqlType.VarBinary:
//          return "Cast('' as varbinary(1))";
        default: 
          return base.GetDefault(sqlType);
      }
    }

    /// <summary>
    /// Creates <see cref="IDbDataParameter"/> instance specific
    /// to the driver that corresponds to the specified 
    /// <see cref="QueryParameter"/>.
    /// </summary>
    /// <param name="value">Parameter to convert.</param>
    /// <returns>Driver-specific parameter.</returns>
    public override IDbDataParameter ConvertParameter(QueryParameter value)
    {
      OleDbParameter sp = new OleDbParameter ();
      QueryParameter.Properties cp = value.ChangedProperties;

      sp.ParameterName = value.ParameterName;
      if ((cp & QueryParameter.Properties.IsNullable)!=0)
        sp.IsNullable = value.IsNullable;
      if ((cp & QueryParameter.Properties.DbType)!=0)
        sp.DbType = value.DbType;
      if ((cp & QueryParameter.Properties.Precision)!=0)
        sp.Precision = value.Precision;
      if ((cp & QueryParameter.Properties.Scale)!=0)
        sp.Scale = value.Scale;
      if ((cp & QueryParameter.Properties.Size)!=0)
        sp.Size  = value.Size;
      if ((cp & QueryParameter.Properties.Value)!=0)
        sp.Value = value.Value;
      return sp;
    }

    /// <summary>
    /// Returns string holding quoted identifier name.
    /// </summary>
    /// <param name="name">Unquoted identifier name.</param>
    /// <returns>Quoted identifier name.</returns>
    public override string QuoteIdentifier(string name)
    {
      return "["+name+"]";
    }
    
    /// <summary>
    /// Returns string holding quoted identifier name.
    /// </summary>
    /// <param name="table">Unquoted table name.</param>
    /// <param name="name">Unquoted identified name.</param>
    /// <returns>Quoted identifier name.</returns>
    public override string QuoteDoubleIdentifier(string table, string name)
    {
      return "["+table+"].["+name+"]";
    }
    
    /// <summary>
    /// Returns <see cref="DeadlockException"/>, <see cref="InstanceVersionChangedException"/> 
    /// or similar types of exceptions on corresponding types of "native" 
    /// exception, or returns passed exception (if there is no need to 
    /// substitute it).
    /// </summary>
    /// <remarks>
    /// <para>
    /// In most cases you shouldn't call this method manually. The
    /// only exception is when you perform manual SQL queries 
    /// using <see cref="Session.RealConnection"/>. In this case you
    /// should use the code like:
    /// <code>
    /// try {
    ///   // some code that uses RealConnection
    /// }
    /// catch (Exception e) {
    ///   throw Session.Utils.SubstituteException(e);
    /// }
    /// </code>
    /// This should allow upper callers to recieve correct
    /// exception.
    /// </para>
    /// <para>
    /// Microsoft Access does not support deadlocks, so the 
    /// code of this method is:
    /// <code>
    /// return e;
    /// </code>
    /// </para>
    /// </remarks>
    /// <param name="e">Exception to substitute.</param>
    /// <returns>Substitution.</returns>
    public override Exception SubstituteException(Exception e)
    {  
      // Access doesn't appear to support deadlocks
      return e;
    }
    
    /// <summary>
    /// Compares two <see cref="DatabaseModel.Column"/>s.
    /// </summary>
    /// <param name="first">First object to be compared.</param>
    /// <param name="second">Second object to be compared.</param>
    /// <returns>Zero if objects are equal; -1 if the objects are
    /// completely different; 1 if objects are different, but
    /// nevertheless it's possible to copy the content from
    /// old object to new object, 2 when the is no <see cref="Driver"/>-specific information 
    /// about columns and the default database model comparison should go.</returns>
    public override int CompareColumnTypes(DatabaseModel.Column first, DatabaseModel.Column second)
    {
      // Access doesn't have Int64, but the ObjectModel uses them.  Therefore, override the
      // default comparison, treating Int64 the same as Int32.
      if ( 
        ( first.SqlType == SqlType.Int32 && second.SqlType == SqlType.Int64 ) 
        || 
        ( first.SqlType == SqlType.VarChar && second.SqlType == SqlType.Text ) 
        || 
        ( first.SqlType == SqlType.Text && second.SqlType == SqlType.VarChar ) 
        || 
        ( first.SqlType == SqlType.Binary && second.SqlType == SqlType.Image ) 
        || 
        ( first.SqlType == SqlType.Binary && second.SqlType == SqlType.VarBinary ) 
        || 
        ( first.SqlType == SqlType.DateTime && second.SqlType == SqlType.TimeStamp) 
        )
      {
//        if (first.Name != second.Name || first.AutoIncrement != second.AutoIncrement)
//          return -1;
        if (first.Nullable != second.Nullable)
          return -1;

        return 0;
      }
      else
      {                                                                            
        // For all other types, use the default
        return 2;
      }
    }

    /// <summary> 
    /// Returns <see cref="DbType"/> corresponding to <see cref="SqlType"/>. 
    /// </summary> 
    /// <param name="sqlType">Type to get <see cref="DbType"/> for.</param> 
    /// <returns><see cref="DbType"/> for specified <see cref="SqlType"/>.</returns> 
    public override DbType GetDbType( SqlType sqlType ) 
    { 
      switch( sqlType ) 
      { 
          case SqlType.DateTime: 
            { 
                return DbType.Double; // Access datetimes need to be converted using DateTime.ToOADate(), which returns a double 
            } 
            default: 
            { 
                return base.GetDbType( sqlType ); 
            } 
      } 
    }    

    /// <summary>
    /// Returns the <see cref="SqlType"/> that should be used in a case when driver 
    /// does not support Guid fields.
    /// </summary>
    /// <returns>A value equal to <see cref="SqlType.VarChar"/>.</returns>
    public override SqlType GetGuidSubstitue()
    {
      return SqlType.VarChar;
    }

    /// <summary>
    /// Gets minimal possible not-null value of the appropriate datetime SQLType. 
    /// </summary>
    /// <param name="sqlType">One of the <see cref="SqlType"/> values to get the minimal value for. </param>
    /// <returns>The minimal value.</returns>
    public override DateTime GetMinimumDateTimeValue(SqlType sqlType)
    {
      return new DateTime(1800,1,1);
    }

    // Constructor

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    public MSAccessUtils(Driver driver): base(driver)
    {
    }
  }
}
