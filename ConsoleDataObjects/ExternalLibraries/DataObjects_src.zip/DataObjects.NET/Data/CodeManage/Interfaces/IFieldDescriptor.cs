// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;

namespace DataObjects.NET.Data.CodeManage
{
  /// <summary>
  /// Describes a field.
  /// </summary>
  internal interface IFieldDescriptor: IFieldContainerDescriptor
  {
    /// <summary>
    /// Gets an owner element.
    /// </summary>
    IElementDescriptor Parent {get;}
  }
}
