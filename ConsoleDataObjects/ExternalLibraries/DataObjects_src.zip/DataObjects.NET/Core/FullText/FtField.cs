// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;
using System.Text;

namespace DataObjects.NET.FullText
{
  /// <summary>
  /// Describes single full-text search field 
  /// in the <see cref="FtData"/> object.
  /// <seealso cref="FtData"/>
  /// </summary>
  [Serializable]
  public sealed class FtField
  {
    /// <summary>
    /// Name of the <see cref="FtField"/> storing 
    /// <see cref="DataObject.ID"/> value in the <see cref="FtData"/>.
    /// </summary>
    public const string ObjectIDFieldName = "ID";
    
    /// <summary>
    /// Name of the <see cref="FtField"/> storing 
    /// <see cref="DataObject.ID">FtRecord.ID</see> value in the <see cref="FtData"/>.
    /// </summary>
    public const string FtRecordIDFieldName = "RecordID";
    
    /// <summary>
    /// Name of the <see cref="FtField"/> storing 
    /// <see cref="DataObject.TypeID"/> value in the <see cref="FtData"/>.
    /// </summary>
    public const string TypeIDFieldName = "TypeID";

    /// <summary>
    /// Name of the <see cref="FtField"/> storing the result
    /// of <see cref="IFtObject.ProduceFtData(Culture)"/> call in the <see cref="FtData"/>.
    /// This field stores object's "full-text content".
    /// </summary>
    public const string ContentFieldName = "Content";

    /// <summary>
    /// Suffix of the field combining values of the
    /// group of "cultured" fields with the same base name.
    /// </summary>
    public const string AnyCultureSuffix = "Any";

    private string name;
    /// <summary>
    /// Gets or sets the name of the field.
    /// </summary>
    public string Name {
      get { 
        return name; 
      }
      set { 
        if (value==null)
          throw new ArgumentNullException("value");
        name = value; 
      }
    }

    /// <summary>
    /// Gets <see cref="Culture"/> suffix of the field,
    /// or <see langword="null"/>, if there is no culture suffix.
    /// For example, for "A-Ru" name this property returns
    /// "Ru" value.
    /// </summary>
    public string CultureSuffix {
      get { 
        int dashIndex = name.LastIndexOf('-');
        if (dashIndex!=-1)
          return name.Substring(dashIndex+1);
        else
          return null;
      }
    }

    /// <summary>
    /// Gets or sets the value of the field.
    /// Default value is <see langword="null"/>.
    /// </summary>
    public string Value {
      get {
        string[] values = this.Values;
        return values==null || values.Length==0 ? null : values[0];
      }
      set {this.Values = value==null ? null : new string[1] {value};}
    }

    internal string[] ValueArray = null;
    internal string ValueString = null;
    /// <summary>
    /// Gets or sets multiple values of the field.
    /// </summary>
    /// <remarks>If you set to this property array of strings,
    /// you'll get array of one space-joined string when current type of field
    /// is <see cref="FtFieldType.Text"/> or <see cref="FtFieldType.StoredText"/>.
    /// </remarks>
    /// <exception cref="ArgumentException">Type of the field is <see cref="FtFieldType.Keyword"/>
    /// and you try to set array with more than one element.
    /// </exception>
    public string[] Values {
      get
      {
        string[] result = null;
        switch (type) {
          case FtFieldType.Keyword:
            result = ValueArray==null ? null : ValueArray;
            break;
          case FtFieldType.Text:
          case FtFieldType.StoredText:
              result = ValueString==null ? null : new string[1] {ValueString};
            break;
        }
        return result;
      }
      set
      {
        if (type!=FtFieldType.Keyword && value!=null && value.Length>1)
          throw new ArgumentException("When type of field is not Keyword, there must be "+
            "no more than one element in the Value array. ", "value");
        if (value==null) {
          ValueString = null;
          ValueArray = null;
          return;
        }
        if (type==FtFieldType.Text || type==FtFieldType.StoredText)
          ValueString = string.Join(" ", value);
        else
          ValueArray = value;
      }
    }

    private FtFieldType type = FtFieldType.Text;
    /// <summary>
    /// Gets or sets the type of the field.
    /// Default value is <see cref="FtFieldType.Text"/>.
    /// </summary>
    public FtFieldType Type {
      get { return type; }
      set {
        bool typeChanged = type!=value && (type==FtFieldType.Keyword || value==FtFieldType.Keyword);
        string[] oldValues = null;
        if (typeChanged)
          oldValues = this.Values;
        type = value;
        if (typeChanged)
          this.Values = oldValues;
      }
    }
    
    // Constructors

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="name">Initial <see cref="Name"/> value.</param>
    public FtField(string name)
    {
      if (name==null)
        throw new ArgumentNullException("name");
      this.name = name;
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="baseName">Base part of initial <see cref="Name"/> value (e.g. "Title").</param>
    /// <param name="culture"><see cref="Culture"/> determining suffix of initial <see cref="Name"/> value.</param>
    public FtField(string baseName, Culture culture): this("")
    {
      if (baseName==null)
        throw new ArgumentNullException("baseName");
      if (culture==null)
        throw new ArgumentNullException("culture");
      this.name = baseName+"-"+culture.Name;
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="name">Initial <see cref="Name"/> value.</param>
    /// <param name="type">Initial <see cref="Type"/> value.</param>
    public FtField(string name, FtFieldType type): this(name)
    {
      this.type = type;
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="baseName">Base part of initial <see cref="Name"/> value (e.g. "Title").</param>
    /// <param name="culture"><see cref="Culture"/> determining suffix of initial <see cref="Name"/> value.</param>
    /// <param name="type">Initial <see cref="Type"/> value.</param>
    public FtField(string baseName, Culture culture, FtFieldType type): this(baseName, culture)
    {
      this.type = type;
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="name">Initial <see cref="Name"/> value.</param>
    /// <param name="value">Initial <see cref="Value"/> value.</param>
    public FtField(string name, string value): this(name)
    {
      this.Value = value;
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="name">Initial <see cref="Name"/> value.</param>
    /// <param name="values">Initial <see cref="Values"/> value.</param>
    public FtField(string name, string[] values): this(name)
    {
      this.Values = values;
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="baseName">Base part of initial <see cref="Name"/> value (e.g. "Title").</param>
    /// <param name="culture"><see cref="Culture"/> determining suffix of initial <see cref="Name"/> value.</param>
    /// <param name="value">Initial <see cref="Value"/> value.</param>
    public FtField(string baseName, Culture culture, string value): this(baseName, culture)
    {
      this.Value = value;
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="baseName">Base part of initial <see cref="Name"/> value (e.g. "Title").</param>
    /// <param name="culture"><see cref="Culture"/> determining suffix of initial <see cref="Name"/> value.</param>
    /// <param name="values">Initial <see cref="Values"/> value.</param>
    public FtField(string baseName, Culture culture, string[] values): this(baseName, culture)
    {
      this.Values = values;
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="name">Initial <see cref="Name"/> value.</param>
    /// <param name="type">Initial <see cref="Type"/> value.</param>
    /// <param name="value">Initial <see cref="Value"/> value.</param>
    public FtField(string name, FtFieldType type, string value): this(name)
    {
      this.type  = type;
      this.Value = value;
    }


    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="name">Initial <see cref="Name"/> value.</param>
    /// <param name="type">Initial <see cref="Type"/> value.</param>
    /// <param name="values">Initial <see cref="Values"/> value.</param>
    public FtField(string name, FtFieldType type, string[] values): this(name)
    {
      this.type   = type;
      this.Values = values;
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="baseName">Base part of initial <see cref="Name"/> value (e.g. "Title").</param>
    /// <param name="culture"><see cref="Culture"/> determining suffix of initial <see cref="Name"/> value.</param>
    /// <param name="type">Initial <see cref="Type"/> value.</param>
    /// <param name="value">Initial <see cref="Value"/> value.</param>
    public FtField(string baseName, Culture culture, FtFieldType type, string value): this(baseName, culture)
    {
      this.type  = type;
      this.Value = value;
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="baseName">Base part of initial <see cref="Name"/> value (e.g. "Title").</param>
    /// <param name="culture"><see cref="Culture"/> determining suffix of initial <see cref="Name"/> value.</param>
    /// <param name="type">Initial <see cref="Type"/> value.</param>
    /// <param name="values">Initial <see cref="Values"/> value.</param>
    public FtField(string baseName, Culture culture, FtFieldType type, string[] values):
      this(baseName, culture)
    {
      this.type  = type;
      this.Values = values;
    }
  }
}