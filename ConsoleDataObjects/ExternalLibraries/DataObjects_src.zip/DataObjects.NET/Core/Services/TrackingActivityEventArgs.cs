// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;

namespace DataObjects.NET.Services
{
  /// <summary>
  /// Represents method that is called to process 
  /// <see cref="Services.TrackingSet.Activity">Activity</see> events
  /// in the <see cref="TrackingSet"/>.
  /// </summary>
  /// <seealso cref="TrackingActivityEventArgs"/>
  public delegate void TrackingActivityEventHandler(TrackingActivityEventArgs args);  


  /// <summary>
  /// Provides information for the 
  /// <see cref="Services.TrackingSet.Activity">Activity</see> event.
  /// </summary>
  public class TrackingActivityEventArgs : EventArgs
  {
    private TrackingSet       trackingSet;
    private long              objectId;
    private TrackingActivityType activityType;
    private bool              discard = true;

    /// <summary>
    /// Gets <see cref="Services.TrackingSet"/>
    /// this event is raised in.
    /// </summary>
    public TrackingSet TrackingSet {
      get {
        return trackingSet;
      }
    }

    /// <summary>
    /// Gets <see cref="DataObject.ID"/> of <see cref="DataObject"/>
    /// instance which activity is lead to this event.
    /// </summary>
    public long ObjectID {
      get {
        return objectId;
      }
    }

    /// <summary>
    /// Gets tracking activity type.
    /// </summary>
    public TrackingActivityType ActivityType {
      get {
        return activityType;
      }
    }

    /// <summary>
    /// Indicates whether current activity should be discarded,
    /// and consequently, <see cref="ObjectID"/> shouldn't be
    /// included into the <see cref="TrackingSet"/>.
    /// </summary>
    public bool Discard {
      get { return discard; }
      set { discard = value;}
    }
    

    // Constructor
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    public TrackingActivityEventArgs(TrackingSet trackingSet, long objectId, 
       TrackingActivityType activityType) : base()
    {
      this.trackingSet  = trackingSet;
      this.objectId     = objectId;
      this.activityType = activityType;
    }
  }
}
