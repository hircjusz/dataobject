// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;

namespace DataObjects.NET.Attributes
{
  /// <summary>
  /// Indicates that collection property is symmetric.
  /// Symmetric collection should have <see cref="ItemTypeAttribute">ItemType</see> 
  /// value equals to the type where symmetric property was declared.
  /// </summary>
  /// <remarks>
  /// <note>This attribute can be applied to persistent properties
  /// of <see cref="DataObjectCollection"/> type.</note>
  /// Symmetric collection always satisfies the following condition:
  /// if instance A contains instance B in its symmetric collection tColl 
  /// (so A.tColl.Contains(B) is <see langword="true"/>) then B contains instance A in
  /// corresponding collection (so B.tColl.Contains(A) is <see langword="true"/> too).
  /// <para>
  /// So symmetric collection behaves as collection paired 
  /// (see <see cref="PairToAttribute"/>) to itself.
  /// </para>
  /// <para>
  /// <example>Example:
  /// <code lang="C#">
  ///  public abstract class Person: DataObject
  ///  {
  ///    ...
  ///    
  ///    [Symmetric] // If I'm friend of you, then you are friend of my :)
  ///    [ItemType(typeof(Person))]
  ///    public abstract DataObjectCollection Friends {get;}
  ///
  ///    ...
  ///  }
  /// </code>
  /// </example>
  /// </para>
  /// <seealso cref="PairToAttribute"/>
  /// <seealso cref="ContainedAttribute"/>
  /// <seealso cref="SelfReferenceAllowedAttribute"/>
  /// </remarks>
  [AttributeUsage(AttributeTargets.Property, AllowMultiple = false, Inherited = true)]
  [Serializable]
  public class SymmetricAttribute: DataObjectAttribute
  {
    private bool symmetric = true;
    /// <summary>
    /// <see langword="True"/> if collection property is symmetric.
    /// </summary>
    public  bool Symmetric
    {
      get {return symmetric;}
      set {symmetric = value;}
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    public SymmetricAttribute() 
    {
    }
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="symmetric"><see langword="True"/> if collection property is symmetric.</param>
    public SymmetricAttribute(bool symmetric) 
    {
      this.symmetric = symmetric;
    }
  }
}
