// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;

namespace DataObjects.NET.Caching
{
  /// <summary>
  /// Represents a hybrid of Hashtable and Dequeue with 
  /// an ability to pull any element to the top.
  /// </summary>
  internal class TopDequeue
  {
    // contains mapping id -> TopDequeueEntry 
    private IDictionary Table;
    private TopDequeueEntry root;

    
    public object this[object key]
    {
      get {
        TopDequeueEntry entry = (TopDequeueEntry)Table[key];
        if (entry==null)
          return null;
        return entry.Value;
      }
      set {
        TopDequeueEntry entry = (TopDequeueEntry)Table[key];
        if (entry==null)
          throw new ArgumentException("There is no object with specified key","key");
        entry.Value = value;
      }
    }

    public bool Contains(object key)
    {
      return Table.Contains(key);
    }

    public void Remove(object key)
    {
      TopDequeueEntry entry = (TopDequeueEntry)Table[key];
      if (entry==null)
        return;
      Table.Remove(key);
      removeFromList(entry);
    }

    public object Top
    {
      get {
        if (Count==0)
          return null;
        else
          return root.Next.Value;
      }
    }

    public object TopKey
    {
      get {
        if (Count==0)
          return null;
        else
          return root.Next.Key;
      }
    }

    public object Bottom
    {
      get {
        if (Count==0)
          return null;
        else
          return root.Previous.Value;
      }
    }

    public object BottomKey
    {
      get {
        if (Count==0)
          return null;
        else
          return root.Previous.Key;
      }
    }

    public void MoveToTop(object id)
    {
      TopDequeueEntry entry = (TopDequeueEntry)Table[id];
      if (entry ==null)
          throw new ArgumentException("There is no object with specified key","key");
      removeFromList(entry);
      addToList(root,entry);
    }

    public void MoveToBottom(object id)
    {
      TopDequeueEntry entry = (TopDequeueEntry)Table[id];
      if (entry ==null)
          throw new ArgumentException("There is no object with specified key","key");
      removeFromList(entry);
      addToList(root.Previous,entry);
    }

    public object PeekTop()
    {
      if (Count==0)
        return null;

      TopDequeueEntry top = root.Next;
      removeFromList(top);
      Table.Remove(top.Key);
      return top.Value;
    }

    public object PeekBottom()
    {
      if (Count==0)
        return null;

      TopDequeueEntry bottom = root.Previous;
      removeFromList(bottom);
      Table.Remove(bottom.Key);
      return bottom.Value;
    }

    public int Count
    {
      get {
        return Table.Count;
      }
    }

    /// <summary>
    /// Adds an object with specified key.
    /// If an object already exists, moves it to top.
    /// </summary>
    /// <param name="key"></param>
    /// <param name="value"></param>
    public void AddToTop(object key, object value)
    {
      TopDequeueEntry entry = (TopDequeueEntry)Table[key];
      if (entry != null) {
        removeFromList(entry);
        entry.Value = value;
        addToList(root,entry);
      }
      else {
        entry = new TopDequeueEntry();
        Table[key] =  entry;
        entry.Key = key;
        entry.Value = value;
        addToList(root,entry);
      }
    }

    /// <summary>
    /// Adds an object with specified key.
    /// If an object already exists, moves it to Bottom.
    /// </summary>
    /// <param name="key"></param>
    /// <param name="value"></param>
    public void AddToBottom(object key, object value)
    {
      TopDequeueEntry entry = (TopDequeueEntry)Table[key];
      if (entry != null) {
        removeFromList(entry);
        entry.Value = value;
        addToList(root.Previous,entry);
      }
      else {
        entry = new TopDequeueEntry();
        Table[key] =  entry;
        entry.Key = key;
        entry.Value = value;
        addToList(root.Previous,entry);
      }
    }

    public void Clear()
    {
      Table.Clear();
      root.Next = root;
      root.Previous = root;
    }

    // internal list operations
    
    private void addToList(TopDequeueEntry previous, TopDequeueEntry newEntry) {
      TopDequeueEntry next = previous.Next;
      newEntry.Next = next;
      newEntry.Previous = previous;
      next.Previous = newEntry;
      previous.Next = newEntry;
    }

    private void removeFromList(TopDequeueEntry newEntry) {
      TopDequeueEntry next = newEntry.Next;
      TopDequeueEntry previous = newEntry.Previous;
        
      newEntry.Next = null;
      newEntry.Previous = null;
      next.Previous = previous;
      previous.Next = next;
    }

    //constructors
    public TopDequeue()
    {
      Table = new Hashtable();
      root = new TopDequeueEntry();
      root.Next = root;
      root.Previous = root;
    }
  }

  internal class TopDequeueEntry
  {
    public object Key;
    public object Value;
    public TopDequeueEntry Next;
    public TopDequeueEntry Previous;
  }
}
