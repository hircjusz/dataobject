// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

namespace DataObjects.NET.Services
{
  /// <summary>
  /// Enumerates possible types of activity tracked by
  /// <see cref="TrackingSet"/>.
  /// </summary>
  public enum TrackingActivityType
  {
    /// <summary>
    /// Indicates that <see cref="DataObject"/> instance creation
    /// activity is tracked.
    /// </summary>
    ObjectCreated,
    /// <summary>
    /// Indicates that <see cref="DataObject"/> instance modification
    /// activity is tracked.
    /// </summary>
    ObjectChanged,
    /// <summary>
    /// Indicates that <see cref="DataObject"/> instance removal
    /// activity is tracked.
    /// </summary>
    ObjectRemoved
  }
}
