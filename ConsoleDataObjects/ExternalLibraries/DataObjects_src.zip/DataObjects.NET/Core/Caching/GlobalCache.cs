// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;
using System.Collections.Specialized;
using System.Diagnostics;
using System.Threading;
using DataObjects.NET;
using DataObjects.NET.Database;
using DataObjects.NET.Diagnostics;
using DataObjects.NET.Exceptions;

namespace DataObjects.NET.Caching
{
  /// <summary>
  /// Global (<see cref="Domain"/>-level) cache implementation.
  /// This class is fully safe for multithreaded operations.
  /// </summary>
  public class GlobalCache
  {
#if (EXPRESS)
    private const int cMinSize = 10*1024;
#else
    private const int cMinSize = 1*1024*1024;
#endif
    
    private static GlobalCache alwaysEmptyCache = null;

    private Domain domain;
    private bool alwaysEmpty;
    private int  size        = cMinSize; // size==0 means that Global Cache is disabled
    private int  currentSize = 0;
    private ReaderWriterLock lck = new ReaderWriterLock();
    private TopDequeue topDequeue = new TopDequeue();

    /// <summary>
    /// Gets always empty <see cref="GlobalCache"/> instance.
    /// </summary>
    public static GlobalCache AlwaysEmptyCache {
      get {
        if (alwaysEmptyCache == null)
          lock (typeof(GlobalCache)) {
            if (alwaysEmptyCache == null) {
              alwaysEmptyCache = new GlobalCache();
              alwaysEmptyCache.alwaysEmpty = true;
            }
          }
        return alwaysEmptyCache;
      }
    }

    /// <summary>
    /// Gets <see cref="DataObjects.NET.Domain"/> object this 
    /// global cache instance belongs to.
    /// </summary>
    public Domain Domain {
      get { return domain; }
    }
    
    /// <summary>
    /// Gets global cache size.
    /// </summary>
    public int Size {
      get { return size; }
    }
    
    /// <summary>
    /// Gets global cache current size.
    /// </summary>
    public int CurrentSize {
      get { return currentSize; }
    }
    
    /// <summary>
    /// Gets the number of cached items in the global cache.
    /// </summary>
    public int NumberOfItems {
      get {
        lck.AcquireReaderLock(Timeout.Infinite);
        try {
          return topDequeue.Count;
        } 
        finally {
          lck.ReleaseReaderLock();
        }
      }
    }

    internal IGlobalCacheItem this[object key] {
      get {
        if (alwaysEmpty)
          return null;
        IGlobalCacheItem result = null;
        lck.AcquireReaderLock(Timeout.Infinite);
        try
        {
          // Find an object and update its access time to "now"
          //SM begin
          //SM end
          result = (IGlobalCacheItem)topDequeue[key];
          if (result!=null) {
            LockCookie cookie = lck.UpgradeToWriterLock(Timeout.Infinite);
            try {
                if (topDequeue.Contains(key))
                {
                    //SM begin
                    if (result is DataObjectInstantiationInfo)
                    {
                        DataObjectInstantiationInfo iInfo = result as DataObjectInstantiationInfo;
                        if (ChangeCache.getInstance().IsOlder(iInfo.StartedOn))
                        {
                            InnerRemove(result, key);
                            return null;
                        }
                    }
                    //SM end
                    topDequeue.MoveToTop(key);
                }
                else
                    return null;
            } 
            finally {
              lck.DowngradeFromWriterLock(ref cookie);
            }
            return (IGlobalCacheItem)result.Clone();
          }
          return null;
        } 
        finally {
          lck.ReleaseReaderLock();
      }

      }
      set {
        if (alwaysEmpty)
          return;
        // Checking if there is an already instance with the
        // same version
        IGlobalCacheItem oldValue = null;
        lck.AcquireReaderLock(Timeout.Infinite);
        try {
          oldValue = (IGlobalCacheItem)topDequeue[key];
          if (oldValue!=null && oldValue.VersionID==value.VersionID)
            return;
          // Put instantation info into cache, set in access time to "now"
          // if we have exceeded size limit, remove one or more lowest items
          LockCookie cookie = lck.UpgradeToWriterLock(Timeout.Infinite);
          try {
            oldValue = (IGlobalCacheItem)topDequeue[key];
            if (oldValue!=null) {
              currentSize -= oldValue.Size;
              UpdatePerformanceCounters_ItemRemoved(oldValue);
            }
            
            currentSize += value.Size;
            value = (IGlobalCacheItem)value.Clone();
            topDequeue.AddToTop(key, value);
            UpdatePerformanceCounters_ItemAdded(value);
            // let's notify global cache item that it is cached
            value.OnCached();
            
            while (currentSize > size) {
              oldValue = (IGlobalCacheItem)topDequeue.PeekBottom();
              currentSize -= oldValue.Size;
              UpdatePerformanceCounters_ItemRemoved(oldValue);
            }
          } 
          finally {
            lck.DowngradeFromWriterLock(ref cookie);
          }
          UpdatePerformanceCounters_Total();
        }
        finally {
          lck.ReleaseReaderLock();
        }
      }
    }

    internal IGlobalCacheItem this[object key, int desiredVersionID] {
      get {
        if (alwaysEmpty)
          return null;
        IGlobalCacheItem result = null;
        lck.AcquireReaderLock(Timeout.Infinite);
        try {
          result = (IGlobalCacheItem)topDequeue[key];
          if (result==null || result.VersionID!=desiredVersionID)
            return null;
          LockCookie cookie = lck.UpgradeToWriterLock(Timeout.Infinite);
          try {
              if (topDequeue.Contains(key))
                  topDequeue.MoveToTop(key);
              else
                  return null;
          }
          finally {
            lck.DowngradeFromWriterLock(ref cookie);
          }
          return (IGlobalCacheItem)result.Clone();
        } 
        finally {
          lck.ReleaseReaderLock();
        }
      }
    }

    internal IGlobalCacheItem this[IGlobalCacheItemValidationInfo vInfo] {
      get {
        if (vInfo==null)
          return null;
        object key = vInfo.Key;
        if (key==null)
          return null;
        IGlobalCacheItem iInfo = vInfo as IGlobalCacheItem;
        if (iInfo!=null) {
          // Nice! Let's try to push passed data into the global cache
          if (iInfo.CanCache)
            this[key] = iInfo;
          return iInfo;
        }
        else {
          iInfo = this[key, vInfo.VersionID];
          if (iInfo!=null)
            iInfo.OnValidated(vInfo);
          return iInfo;
        }
      }
    }
    
    internal void Add(IGlobalCacheItem iInfo)
    {
      if (iInfo==null)
        return;
      object key = iInfo.Key;
      if (key==null)
        return;
      if (iInfo.CanCache)
        this[key] = iInfo;
    }

    internal void InnerRemove(IGlobalCacheItem gcItem, object key)
    {
        if (gcItem == null)
            return;
        topDequeue.Remove(key);
        currentSize -= gcItem.Size;
        UpdatePerformanceCounters_ItemRemoved(gcItem);
    }

    internal void Remove(object key) 
    {
      if (alwaysEmpty)
        return;
      lck.AcquireWriterLock(Timeout.Infinite);
      try {
          IGlobalCacheItem gcItem = (IGlobalCacheItem)topDequeue[key];
          InnerRemove(gcItem, key);
      } 
      finally {
        lck.ReleaseWriterLock();
      }
      UpdatePerformanceCounters_Total();
    }

    /// <summary>
    /// Invalidates the whole global cache.
    /// </summary>
    /// <param name="session"><see cref="Session"/>
    /// to check for <see cref="SessionBoundObject.DisableSecurity"/>
    /// mode - it should be on, otherwise this method
    /// throws a <see cref="SecurityException"/>.</param>
    public void Invalidate(Session session) 
    {
      if (session.disableSecurityThreads[Thread.CurrentThread]==null)
        throw new SecurityException("Access to Invalidate isn't allowed.");

      if (alwaysEmpty)
        return;
      lck.AcquireWriterLock(Timeout.Infinite);
      try {
        topDequeue.Clear();
        currentSize = 0;
      } 
      finally {
        lck.ReleaseWriterLock();
      }
      UpdatePerformanceCounters_Total();
    }

    private void UpdatePerformanceCounters_Total()
    {
      domain.PerformanceCounters.UpdateGlobalCacheCounters();
    }
    
    private void UpdatePerformanceCounters_ItemAdded(IGlobalCacheItem gcItem)
    {
      domain.PerformanceCounters.UpdateGlobalCacheItemCounters(gcItem, true);
    }
    
    private void UpdatePerformanceCounters_ItemRemoved(IGlobalCacheItem gcItem)
    {
      domain.PerformanceCounters.UpdateGlobalCacheItemCounters(gcItem, false);
    }

    // Contructors

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    private GlobalCache()
    {
    }

    /// <summary>
    /// Initializes a new instance of the <see cref="GlobalCache"/> class.
    /// </summary>
    /// <param name="domain"><see cref="Domain"/>.</param>
    /// <param name="size">cache size.</param>
    internal GlobalCache(Domain domain, int size) 
    {
      this.domain = domain;
      this.size = ((size<cMinSize) && (size!=0)) ? cMinSize : size;
#if (EXPRESS)
      if (this.size>100*1024)
        this.size = 100*1024;
#endif
#if (STANDARD)
      if (this.size>10*1024*1024)
        this.size = 10*1024*1024;
#endif
    }
  }

//SM begin
  /// <summary>
  /// Change (<see cref="Domain"/>-level) cache implementation.
  /// This class is fully safe for multithreaded operations.
  /// </summary>

    public class ChangeCache
    {
        private Hashtable map;
        private static ChangeCache instance;
        private DateTime start;
        public static int maxSize = 0;
        public static Int64 failCount = 0;
        public static Int64 succCount = 0;

        /// <summary>
        /// </summary>
        public ChangeCache(int capacity)
        {
            start = DateTime.Now;
            map = new Hashtable(capacity);
        }

        public static bool IsAvailable()
        {
            return maxSize > 0;
        }

        /// <summary>
        /// </summary>
        public static ChangeCache getInstance()
        {
            if (instance == null)
            {
                lock (typeof(ChangeCache))
                {
                    if (instance == null)
                        instance = new ChangeCache(1024);
                }
            }
            return instance;
        }

        /// <summary>
        /// </summary>
        public bool IsOlder(DateTime dt)
        {
            lock (map)
            {
                return dt.CompareTo(start) == -1;
            }
        }

        /// <summary>
        /// </summary>
        /// 

        public bool isChanged(long ID, object info)
        {
            bool res = internalIsChanged(ID, info);
            if ((ID > 0) && (info != null))
            {
                if (res) failCount++; else succCount++;
                if (failCount == Int64.MaxValue)
                {
                    failCount = 0;
                    succCount = 0;
                }
            }
            return res;

        }

        public bool internalIsChanged(long ID, object info)
        {
            if (!IsAvailable()) return true;
            if (ID <= 0) return true;
            if (info == null)  return true;
            DateTime timestamp;
            if (info is TransactionContext)
            {
                TransactionContext tInfo = info as TransactionContext;
                if ((tInfo != null) && (tInfo.OutermostTransaction != null))
                {
                    if (tInfo.OutermostTransaction != null)
                        timestamp = tInfo.OutermostTransaction.StartedOn;
                    else
                        return true;
                }
                else
                    return true;
            }
            else
            if (info is DataObject)
            {
                DataObject oInfo = info as DataObject;
                if ((oInfo.TransactionContext != null) && (oInfo.TransactionContext.OutermostTransaction != null))
                {
                    if (oInfo.TransactionContext.OutermostTransaction != null)
                        timestamp = oInfo.TransactionContext.OutermostTransaction.StartedOn;
                    else
                        return true;
                }
                else
                    return true;
            }
            else if (info is DataObjectValidationInfo)
            {
                DataObjectValidationInfo vInfo = info as DataObjectValidationInfo;
                if (vInfo.TransactionContext != null && vInfo.TransactionContext.OutermostTransaction != null)
                    timestamp = vInfo.TransactionContext.OutermostTransaction.StartedOn;
                else
                {
                    if (info is DataObjectInstantiationInfo)
                    {
                        timestamp = (info as DataObjectInstantiationInfo).StartedOn;
                    }
                    else
                        return true;
                }
            }
            else
                return true;
            if (timestamp.CompareTo(start) == -1)
            {
                return true;
            }
            else
            {
//                lock (map)
                {
                    bool res = map.ContainsKey(ID);
                    if (res)
                    {
                        if (info is DataObjectInstantiationInfo)
                        {
                            DateTime changeTime = (DateTime)map[ID];
                            if (changeTime.CompareTo((info as DataObjectInstantiationInfo).StartedOn) == -1)
                                return false;
                        }
                        else if (info is DataObject)
                        {
                            DataObject obj = info as DataObject;
                            if (obj.TransactionContext != null && obj.TransactionContext.OutermostTransaction != null)
                            {
                                DateTime changeTime = (DateTime)map[ID];
                                if (changeTime.CompareTo(obj.TransactionContext.OutermostTransaction.StartedOn) == -1)
                                    return false;
                            }
                        }
                    }
                    return res;
                }
            }
        }

        /// <summary>
        /// </summary>
        public void unregister(long ID)
        {
            if (IsAvailable())
            {
                if (ID <= 0) return;
                lock (map)
                {
                    map.Remove(ID);
                }
            }
        }

        /// <summary>
        /// </summary>
        public void register(long ID)
        {
            if (IsAvailable())
            {
                if (ID <= 0) return;
                if (!map.ContainsKey(ID))
                {
                    lock (map)
                    {
                        map.Add(ID, DateTime.Now);
                        if (map.Count >= maxSize)
                        {
                            start = DateTime.Now;
                            map.Clear(); //TODO decreasing map
                        }
                    }
                }
                else
                {
                    lock (map)
                    {
                        if (map.Count > 0)
                        {
                            map[ID] = DateTime.Now;
                        }
                        else
                        {
                            map.Add(ID, DateTime.Now);
                        }
                    }
                }
            }
        }
    }

    public class ConnectionCleanInfo
    {
        private System.Data.IDbConnection connection;
        private DateTime timestamp;
        private int key;
        private Session session;

        public ConnectionCleanInfo(System.Data.IDbConnection connection, int key)
        {
            timestamp = DateTime.Now;
            this.connection = connection;
            this.key = key;
        }

        public DateTime TimeStamp
        {
            get
            {
                return timestamp;
            }
            set
            {
                timestamp = value;
            }
        }

        public System.Data.IDbConnection Connection
        {
            get
            {
                return connection;
            }
        }


        public int Key
        {
            get
            {
                return key;
            }
        }

        public bool IsTimeOut(int lifetime)
        {
            TimeSpan ts = DateTime.Now.Subtract(timestamp);
            return ts.TotalSeconds > lifetime;
        }
    }

    public class ConnectionCleaner
    {
        private static ConnectionCleaner instance;
        private DateTime cleanedOn;
        private Hashtable connections;
        public static int cleantime;
        public static int connectionlifetime;
        private bool cleaning;

        public ConnectionCleaner()
        {
            cleanedOn = DateTime.Now;
            connections = new Hashtable(100);
        }

        private bool IsClean()
        {
            lock (connections)
            {
                TimeSpan ts = DateTime.Now.Subtract(cleanedOn);
                return ts.TotalSeconds > cleantime;
            }
        }

        private void Clean()
        {
            lock (connections)
            {
                if (IsClean())
                {
                    try
                    {
                        ArrayList list = null;
                        foreach (ConnectionCleanInfo info in connections.Values)
                        {
                            if (info.IsTimeOut(connectionlifetime))
                            {
                                if (list == null)
                                    list = new ArrayList(10);
                                list.Add(info.Key);
                                    try
                                    {
                                        if ((info.Connection.State & System.Data.ConnectionState.Open) != 0)
                                            info.Connection.Close();
                                    }
                                    catch
                                    {
                                    }
                            }
                        }
                        if (list != null)
                        {
                            foreach (int key in list)
                            {
                                connections.Remove(key);
                            }
                        }
                    }
                    finally
                    {
                        cleanedOn = DateTime.Now;
                    }
                }
            }
        }

        public bool IsEnabled()
        {
            return cleantime > 0;
        }

        public bool IsAvailable(Session session)
        {
            return IsEnabled() && ((session.Options & SessionOptions.DisableAutoDisconnect) != 0);
        }

        public void unregister(Session session)
        {
            if (IsAvailable(session))
            {
                int key = session.GetHashCode();
                if (connections.ContainsKey(key))
                {
                    lock (connections)
                    {
                        if (!cleaning)
                            connections.Remove(key);
                    }
                }
                Clean();
            }
        }

        public void register(Session session, System.Data.IDbConnection connection)
        {
            if (IsAvailable(session))
            if (connection != null)
            {
                int key = session.GetHashCode();
                if (connections.ContainsKey(key))
                {
                    ConnectionCleanInfo info = (ConnectionCleanInfo)connections[key];
                    if (info != null)
                        info.TimeStamp = DateTime.Now;
                }
                else
                {
                    ConnectionCleanInfo info = new ConnectionCleanInfo(connection, key);
                    lock (connections)
                    {
                        connections.Add(key, info);
                    }
                }
            }
        }

        public static ConnectionCleaner getInstance()
        {
            if (instance == null)
            {
                lock (typeof(ConnectionCleaner))
                {
                    if (instance == null)
                        instance = new ConnectionCleaner();
                }
            }
            return instance;
        }
    }
//SM end

}
