// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using DataObjects.NET.Attributes;

namespace DataObjects.NET
{
  /// <summary>
  /// An interface that should be implemented by <see cref="DataServiceType.Shared">Shared</see> <see cref="DataService"/>
  /// if it needs to be notified on <see cref="Transaction"/>-related events, such as beginning and committing of a
  /// <see cref="Transaction"/>.
  /// </summary>
  public interface ITransactionEventWatcher
  {
    /// <summary>
    /// Called when a new <see cref="Transaction"/> is started.
    /// </summary>
    /// <param name="transaction">The newly created and started <see cref="Transaction"/>.</param>
    void OnTransactionBegin(Transaction transaction);

    /// <summary>
    /// Called when a <see cref="Transaction"/> is going to be committed.
    /// </summary>
    /// <param name="transaction">The <see cref="Transaction"/> to be committed.</param>
    void OnBeforeTransactionCommit(Transaction transaction);

    /// <summary>
    /// Called when a <see cref="Transaction"/> is committed.
    /// </summary>
    /// <param name="transaction">The committed <see cref="Transaction"/>.</param>
    void OnTransactionCommit(Transaction transaction);

    /// <summary>
    /// Called when a <see cref="Transaction"/> is going to be rolled back.
    /// </summary>
    /// <param name="transaction">The <see cref="Transaction"/> to be rolled back.</param>
    void OnBeforeTransactionRollback(Transaction transaction);

    /// <summary>
    /// Called when a <see cref="Transaction"/> is rolled back.
    /// </summary>
    /// <param name="transaction">The rolled back <see cref="Transaction"/>.</param>
    void OnTransactionRollback(Transaction transaction);
  }
}
