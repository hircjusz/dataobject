// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;

namespace DataObjects.NET.Attributes
{
  /// <summary>
  /// Indicates that class should share tables that store properties of 
  /// descendant class instances.
  /// </summary>
  /// <remarks>
  /// <note>This attribute can be applied to any persistent type.</note>
  /// <para>
  /// Descendant's tables will additionaly contain a set of columns representing 
  /// persistent properties declared in a class having this attribute.
  /// </para>
  /// <para>
  /// <example>Example:
  /// <code lang="C#">
  ///  [ShareDescendantTable] // !!! Shares "SomeClassB" &amp; "SomeClassC" tables
  ///  public abstract class SomeClassA: DataObject
  ///  {
  ///    ...
  ///  }
  ///
  ///  public abstract class SomeClassB: SomeClassA
  ///  {
  ///    ...
  ///  }
  ///
  ///  public abstract class SomeClassC: SomeClassA
  ///  {
  ///   ...
  ///  }
  /// </code>
  /// </example>
  /// </para>
  /// </remarks>
  [AttributeUsage(AttributeTargets.Class, AllowMultiple = false, Inherited = false)]
  [Serializable]
  public class ShareDescendantTableAttribute: DataObjectAttribute
  {
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    public ShareDescendantTableAttribute()
    {
    }
  }
}