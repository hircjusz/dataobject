// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Reflection;
#if !MONO
using EnvDTE;
#endif
using DataObjects.NET;

namespace DataObjects.NET.Data.CodeManage
{
  /// <summary>
  /// Describes a collection.
  /// </summary>
  internal class CollectionDescriptor: ICollectionDescriptor, ICloneable
  {
    private CodeManagerBase codeManager;
    private string name;
    private string dbName;
    private IElementDescriptor parent;
    
    /// <summary>
    /// Code manager.
    /// </summary>
    public CodeManagerBase CodeManager {
      get {
        return codeManager;
      }
    }
    
    /// <summary>
    /// Gets parent element.
    /// </summary>
    public IElementDescriptor Parent {
      get {
        return parent;
      }
    }
    
    /// <summary>
    /// Gets collection name.
    /// </summary>
    public string Name {
      get {
        return name;
      }
    }

    /// <summary>
    /// Gets collection full name.
    /// </summary>
    public string FullName {
      get {
        return parent.FullName + "." + name;
      }
    }
    
    /// <summary>
    /// Element database name.
    /// </summary>
    /// <remarks>May be null.</remarks>
    public string DbName {
      get {
        return dbName;
      }
    }
    
    /// <summary>
    /// Creates a new object that is a copy of the current instance.
    /// </summary>
    /// <returns>A new object that is a copy of this instance.</returns>
    object ICloneable.Clone()
    {
      CollectionDescriptor clone = new CollectionDescriptor();
      clone.codeManager = codeManager;
      clone.dbName = dbName;
      clone.name = name;
      return clone;
    }
    
    /// <summary>
    /// Sets parent element.
    /// </summary>
    /// <param name="parent"><see cref="IElementDescriptor"/> of a parent element.</param>
    internal void SetParentFromContainer(IElementDescriptor parent)
    {
      this.parent = parent;
    }
    

    private CollectionDescriptor()
    {
    }
    
    /// <summary>
    /// Initializes a new instance of the <see cref="CollectionDescriptor"/> class.
    /// </summary>
    /// <param name="parent">Collection's parent element. Value can be null.</param>
    /// <param name="property"><see cref="PropertyInfo"/>.</param>
    internal CollectionDescriptor(IElementDescriptor parent, PropertyInfo property)
    {
      if (property==null)
        throw new ArgumentNullException("property");
    
      if (parent!=null) {
        this.codeManager = parent.CodeManager;
        this.parent = parent;
      }
      
      this.name = property.Name;
      object[] attrs = property.GetCustomAttributes(typeof(Attributes.DbNameAttribute), true);
      if (attrs!=null && attrs.Length>0) {
        this.dbName = ((Attributes.DbNameAttribute)attrs[0]).DbName;
      }
    }
#if !MONO
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="parent">Collection's parent element. Value can be null.</param>
    /// <param name="property"><see cref="CodeProperty"/>. Value can be null.</param>
    internal CollectionDescriptor(IElementDescriptor parent, CodeProperty property)
    {
      if (parent!=null) {
        this.codeManager = parent.CodeManager;
        this.parent = parent;
      }
      
      if (property!=null) {
        this.name = property.Name;
        int attributesCount = 0;
        try {
          attributesCount = property.Attributes.Count;
        } catch {}
        for (int i = 0; i < attributesCount; i++) {
          CodeElement attrElement = property.Attributes.Item(i + 1);
          if (attrElement.Kind==vsCMElement.vsCMElementAttribute) {
            CodeAttribute attr = (CodeAttribute)attrElement;
            if (attr.FullName=="DataObjects.NET.Attributes.DbNameAttribute") {
              string val = attr.Value;
              if (val.StartsWith("\"") && val.EndsWith("\"")) {
                dbName = val.Substring(1, val.Length - 2);
                break;
              }
            }
          }
        }
      }
    }
#endif
  }
}
