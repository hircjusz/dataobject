// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;

namespace DataObjects.NET.FullText
{
  /// <summary>
  /// This interface should be implemented by any full-text indexer.
  /// </summary>
  public interface IFtIndexer
  {
    /// <summary>
    /// Creats <see cref="FtRecord"/>s for all <see cref="IFtObject"/> instances
    /// that can provide full-text data but don't have correspondent 
    /// <see cref="FtRecord"/>s for some reasons. 
    /// </summary>
    /// <remarks>
    /// This method is potentially useful for upgrading form earlier versions.
    /// </remarks>
    void CreateFtRecords();
    
    /// <summary>
    /// Removes all <see cref="FtRecord"/>s which don't have corresponding
    /// <see cref="IFtObject"/> instances. Normally full-text indexer
    /// removes such <see cref="FtRecord"/>s in one or several iterations. 
    /// But in case when it is required to remove all such <see cref="FtRecord"/>s
    /// immediately this method may be used.
    /// </summary>
    /// <remarks>
    /// This method is potentially useful for upgrading form earlier versions.
    /// </remarks>
    void CleanupFtRecords();
    
    /// <summary>
    /// Updates all full-text data which is not up-to-date.
    /// Normally full-text indexer updates full-text data in one or several
    /// iterations. But in case when it is necessary to update all full-text
    /// data immediately this method may be used.
    /// </summary>
    /// <remarks>
    /// This method is potentially useful for upgrading form earlier versions.
    /// </remarks>
    void UpdateIndex();
    
    /// <summary>
    /// Invalidates all full-text data. Sets <see cref="IFtObject.FtRecordIsUpToDate"/>
    /// to <see langword="false"/> for all <see cref="IFtObject"/> objects.
    /// </summary>
    /// <remarks>
    /// This method is potentially useful for upgrading form earlier versions.
    /// </remarks>
    void InvalidateIndex();

    /// <summary>
    /// Gets the delay to make before the next execution.
    /// </summary>
    /// <param name="e">Exception thrown by previous <see cref="Execute"/> call, 
    /// or <see langword="null"/> if call succeeded.</param>
    /// <returns>delay.</returns>
    TimeSpan GetDelay(Exception e);

    /// <summary>
    /// This method is invoked by <see cref="FtIndexerService"/> periodically
    /// and makes all indexing job.
    /// </summary>
    void Execute();

    /// <summary>
    /// Sets the <see cref="FtIndexerService"/> which is runs the indexer.
    /// </summary>
    void SetContainerService(FtIndexerService containerService);
  }
}
