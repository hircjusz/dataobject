// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;
using System.ComponentModel;
using DataObjects.NET.Data;
using DataObjects.NET.Data.CodeManage;

namespace DataObjects.NET.Data.Design
{
  /// <summary>
  /// VtcNameConverter is used only to get a list of available ValueTypeCollection names for UI designers.
  /// </summary>
  public class VtcNameConverter: StringConverter
  {
    /// <summary>
    /// Returns whether this object supports a standard set of values that can be picked from a list, using the specified context.
    /// </summary>
    /// <param name="context">An <see cref="ITypeDescriptorContext"/> that provides a format context.</param>
    /// <returns><see langword="True"/> if <see cref="GetStandardValues"/> should be called to find a common set of values the object supports; otherwise, <see langword="false"/>.</returns>
    public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
    {
      return true;
    }
    
    /// <summary>
    /// Returns a collection of standard values for the data type this type converter is designed for when provided with a format context.
    /// </summary>
    /// <param name="context">An <see cref="ITypeDescriptorContext"/> that provides a format context that can be used to extract additional 
    /// information about the environment from which this converter is invoked. This parameter or properties of this parameter can be a null reference .</param>
    /// <returns>A <see cref="TypeConverter.StandardValuesCollection"/> that holds a standard set of valid values, or a null reference if the data type does not support a standard set of values.</returns>
    public override System.ComponentModel.TypeConverter.StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
    {
      object obj = context.Instance;
      if (obj is MappingItemBase) {
        Adapter adapter = ((MappingItemBase)obj).GetAdapter();
        if (adapter!=null && adapter.CodeManager!=null) {
          CodeManagerBase codeManager = adapter.CodeManager;
          obj = ((MappingItemBase)obj).MappingCollection.Owner;
          ICollectionDescriptor[] collections = null;
          if (obj is InterfaceMappingItem) {
            string interfaceName = ((InterfaceMappingItem)obj).InterfaceName;
            IInterfaceDescriptor interfaceDescriptor = codeManager.GetInterfaceByFullName(interfaceName);
            if (interfaceDescriptor==null)
              interfaceDescriptor = codeManager.GetInterfaceByName(interfaceName, true);
            if (interfaceDescriptor!=null)
              collections = interfaceDescriptor.Collections;
          } else if (obj is ClassMappingItem) {
            string className = ((ClassMappingItem)obj).ClassName;
            IClassDescriptor classDescriptor = codeManager.GetClassByFullName(className);
            if (classDescriptor==null)
              classDescriptor = codeManager.GetClassByName(className, true);
            if (classDescriptor!=null)
              collections = classDescriptor.Collections;
          }
          if (collections!=null) {
            ArrayList names = new ArrayList();
            foreach (ICollectionDescriptor cd in collections)
              if (cd is ValueTypeCollectionDescriptor)
                names.Add(cd.Name);
            names.Sort();
            return new StandardValuesCollection(names);
          }
        }
      }
      return null;
    }
  }
}
