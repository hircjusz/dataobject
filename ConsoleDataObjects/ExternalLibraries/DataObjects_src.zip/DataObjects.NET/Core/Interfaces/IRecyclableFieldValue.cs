// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Attributes;

namespace DataObjects.NET
{
  /// <summary>
  /// Allows persistent properties to be kept (reused)
  /// on reloading of <see cref="DataObject"/> instance.
  /// </summary>
  public interface IRecyclableFieldValue
  {
    /// <summary>
    /// Called to check if a persistent property instance can be reused.
    /// </summary>
    /// <returns><see langword="True"/> if the instance was recycled 
    /// and can be reused; otherwise, <see langword="false"/>.</returns>
    /// <remarks>
    /// <para>
    /// Note that this method implementation should contain code,
    /// that checks if caller's <see cref="System.Reflection.Assembly"/> is 
    /// DataObjects.NET <see cref="System.Reflection.Assembly"/>.
    /// If this condition fails, <see cref="InvalidOperationException"/> 
    /// should be thrown.
    /// </para>
    /// <para>
    /// Example of such code:
    /// <code lang="C#">
    ///  if (Assembly.GetCallingAssembly()!=typeof(DataObject).Assembly)
    ///    throw new InvalidOperationException("This method can be called only by DataObjects.NET.");
    /// </code>
    /// </para>
    /// </remarks>
    bool Recycle();
  }
}
