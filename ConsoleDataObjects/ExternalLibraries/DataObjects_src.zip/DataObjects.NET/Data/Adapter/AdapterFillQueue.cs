// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;
using System.Data;
using DataObjects.NET;

namespace DataObjects.NET.Data
{
  /// <summary>
  /// Fill queue of <see cref="Adapter"/>.
  /// </summary>
  /// <remarks>
  /// Fill queue contains <see cref="DataObject"/> instances
  /// that are queued to be filled into 
  /// <see cref="DataObjects.NET.Data.Adapter.DataSource"/>.
  /// </remarks>
  public sealed class AdapterFillQueue
  {
    private const int cPreLoadLimit = 256;
    private Adapter adapter;
    private Hashtable hItems = new Hashtable();
    private Queue qItems = new Queue();
    private int generation = 0;
    private int generationMark = 0;
    private int preLoadMark = 0;
    private bool bTryPreLoad = false;
    
    /// <summary>
    /// Gets the <see cref="DataObjects.NET.Data.Adapter"/> this instance belongs to.
    /// </summary>
    public Adapter Adapter {
      get {
        return adapter;
      }
    }
    
    /// <summary>
    /// Gets the number of queued items.
    /// </summary>
    public int Count {
      get {
        return qItems.Count;
      }
    }
    
    /// <summary>
    /// Gets the number of filled (already processed) items.
    /// </summary>
    public int CountFilled {
      get {
        return hItems.Count - qItems.Count;
      }
    }

    /// <summary>
    /// Gets the total number of items (queued + processed).
    /// </summary>
    public int CountTotal {
      get {
        return hItems.Count;
      }
    }
    
    /// <summary>
    /// Gets the <see cref="DataObject"/> instance that is currently filled
    /// into the <see cref="DataObjects.NET.Data.Adapter.DataSource"/>.
    /// </summary>
    public DataObject CurrentObject {
      get {
        if (bTryPreLoad)
          PreLoad(cPreLoadLimit);
        return adapter.Session[CurrentObjectID];
      }
    }
    
    /// <summary>
    /// Gets the <see cref="DataObject.ID"/> of instance that is currently filled
    /// into the <see cref="DataObjects.NET.Data.Adapter.DataSource"/>.
    /// </summary>
    public long CurrentObjectID {
      get {
        return (long)qItems.Peek();
      }
    }
    
    /// <summary>
    /// Gets the number of current generation.
    /// </summary>
    /// <remarks>
    /// Zero generation "contains" all initially queued objects,
    /// first - all objects that were queued during filling of
    /// objects from the zero generation, 
    /// second - all objects that were queued during filling of
    /// objects from the first generation, 
    /// etc...
    /// </remarks>
    public int CurrentGeneration {
      get {
        return generation;
      }
    }
    
    /// <summary>
    /// Enqueues <see cref="DataObject.ID"/> of <see cref="DataObject"/>
    /// instance for fill operation.
    /// </summary>
    /// <param name="id"><see cref="DataObject.ID"/> of instance to enqueue.</param>
    /// <returns><see langword="True"/> if instance was queued successfuly;
    /// otherwise, <see langword="false"/> (e.g. if it was already queued or
    /// filled).</returns>
    public bool Enqueue(long id)
    {
      if (adapter.State!=AdapterState.Filling && adapter.State!=AdapterState.Updating)
        throw new InvalidOperationException(
          "Invalid Adapter State.");
      if (hItems.Contains(id))
        return false;
      hItems[id] = null;
      qItems.Enqueue(id);
      bTryPreLoad = true;
      return true;
    }
    
    /// <summary>
    /// Enqueues <see cref="DataObject"/> instance for fill operation.
    /// </summary>
    /// <param name="obj"><see cref="DataObject"/> instance to enqueue.</param>
    /// <returns><see langword="True"/> if instance was queued successfuly;
    /// otherwise, <see langword="false"/> (e.g. if it was already queued or
    /// filled).</returns>
    public bool Enqueue(DataObject obj)
    {
      if (obj==null)
        throw new ArgumentNullException("obj");
      if (adapter.State!=AdapterState.Filling && adapter.State!=AdapterState.Updating)
        throw new InvalidOperationException(
          "Invalid Adapter State.");
      if (obj.Session!=adapter.Session)
        throw new InvalidOperationException("Instance belongs to another Session.");
      return Enqueue(obj.ID);
    }
    
    /// <summary>
    /// Enqueues a list of <see cref="DataObject.ID"/>s of <see cref="DataObject"/>
    /// instances for fill operation.
    /// </summary>
    /// <param name="ids">An array of instance <see cref="DataObject.ID"/>s to enqueue.</param>
    public void Enqueue(long[] ids)
    {
      for (int i = 0; i<ids.Length; i++)
        Enqueue(ids[i]);
    }
    
    /// <summary>
    /// Enqueues all <see cref="DataObject"/> instances from 
    /// the specified <see cref="QueryResult"/> for fill operation.
    /// </summary>
    /// <param name="queryResult"><see cref="QueryResult"/> containing
    /// <see cref="DataObject"/> instances to enqueue.</param>
    public void Enqueue(QueryResult queryResult)
    {
      long[] ids = queryResult.GetIDs();
      for (int i = 0; i<ids.Length; i++)
        Enqueue(ids[i]);
    }
    
    /// <summary>
    /// Enqueues all <see cref="DataObject"/> instances from 
    /// the specified <see cref="DataObjectCollection"/> for fill operation.
    /// </summary>
    /// <param name="collection"><see cref="DataObjectCollection"/> containing
    /// <see cref="DataObject"/> instances to enqueue.</param>
    public void Enqueue(DataObjectCollection collection)
    {
      long[] ids = collection.GetIDs();
      for (int i = 0; i<ids.Length; i++)
        Enqueue(ids[i]);
    }
    
    /// <summary>
    /// Enqueues all <see cref="DataObject"/> instances from 
    /// the specified <see cref="IEnumerable"/> collection for fill operation.
    /// </summary>
    /// <param name="collection"><see cref="IEnumerable"/> collection containing
    /// <see cref="DataObject"/> instances to enqueue.</param>
    public void Enqueue(IEnumerable collection)
    {
      foreach (DataObject o in collection)
        Enqueue(o);
    }
    
    /// <summary>
    /// Gets <see cref="DataObjectFillState"/> for object with specified
    /// <see cref="DataObject.ID"/>.
    /// </summary>
    /// <param name="id"><see cref="DataObject.ID"/> of instance to get fill state for.</param>
    /// <returns>Object fill state.</returns>
    public DataObjectFillState GetObjectFillState(long id)
    {
      if (!hItems.Contains(id))
        return DataObjectFillState.NotQueued;
      if (hItems[id]==null)
        return DataObjectFillState.Queued;
      else
        return DataObjectFillState.Filled;
    }
    
    /// <summary>
    /// Gets <see cref="DataObjectFillState"/> for specified 
    /// <see cref="DataObject"/> instance.
    /// </summary>
    /// <param name="obj"><see cref="DataObject"/> instance to get fill state for.</param>
    /// <returns>Object fill state.</returns>
    public DataObjectFillState GetObjectFillState(DataObject obj)
    {
      return GetObjectFillState(obj.ID);
    }
    

    // Internal methods
    
    internal void Dequeue()
    {
      long id = (long)qItems.Dequeue();
      hItems[id] = hItems;
      generationMark--;
      if (preLoadMark>0)
        preLoadMark--;
      if (generationMark==0) {
        generation++;
        generationMark = qItems.Count;
      }
      bTryPreLoad = true;
    }
    
    internal void SetGenerationMark()
    {
      generationMark = qItems.Count;
    }
    
    internal void PreLoad(int limit)
    {
      int start = preLoadMark;
      if ((start+limit)>qItems.Count)
        limit = qItems.Count-start;
      if (limit<=0) {
        bTryPreLoad = false;
        return;
      }
      long[] list = new long[limit];
      int i = 0;
      foreach (long id in qItems) {
        if ((start--)>0)
          continue;
        list[i++] = id;
        if (i>=limit)
          break;
      }
      adapter.Session.Preload(list);
      preLoadMark += limit;
      bTryPreLoad = false;
      return;
    }
    
    
    // Constructors

    /// <summary>
    /// Initializes a new instance of the <see cref="AdapterFillQueue"/> class.
    /// </summary>
    /// <param name="adapter"></param>
    internal AdapterFillQueue(Adapter adapter)
    {
      this.adapter = adapter;
    }
  }
}
