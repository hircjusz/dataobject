// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.IO;
using System.Threading;
using System.Configuration;
using System.Diagnostics;
using System.Globalization;
using System.Collections;
using DataObjects.NET;
using DataObjects.NET.Attributes;
using DataObjects.NET.Exceptions;

namespace DataObjects.NET.Security
{
  /// <summary>
  /// An interface that should be implemented by any permission set.
  /// <seealso cref="IPermission"/>
  /// <seealso cref="PermissionSet"/>
  /// </summary>
  /// <remarks>
  /// <para>
  /// You can find more information about the whole DataObjects.NET
  /// security system <see cref="AccessControlList">here</see>.
  /// </para>
  /// </remarks>
  public interface IPermissionSet: IPermission, IEnumerable, ICollection
  {
    /// <summary>
    /// Clears the permission set.
    /// </summary>
    void Clear();
    
    /// <summary>
    /// Unions current permission and the specified permission set.
    /// </summary>
    /// <param name="target">A permission set to combine with the current permission set.</param>
    void Union(IPermission target);
    
    /// <summary>
    /// Subtracts specified permission set from the current permission set.
    /// </summary>
    /// <param name="target">A permission set to subtract from the current permission set.</param>
    void Subtract(IPermission target);

    /// <summary>
    /// Determines whether the current permission set is a subset of the specified permission set.
    /// </summary>
    /// <param name="target">A permission that is to be tested for the subset relationship.</param>
    /// <returns><see langword="True"/> if the current permission set is a subset of the specified permission; otherwise, <see langword="false"/>.</returns>
    bool IsSubsetOf(IPermission target);

    /// <summary>
    /// Determines whether the current permission set is a superset of the specified permission set.
    /// </summary>
    /// <param name="target">A permission that is to be tested for the superset relationship.</param>
    /// <returns><see langword="True"/> if the current permission set is a superset of the specified permission; otherwise, <see langword="false"/>.</returns>
    bool IsSupersetOf(IPermission target);
  }
}
