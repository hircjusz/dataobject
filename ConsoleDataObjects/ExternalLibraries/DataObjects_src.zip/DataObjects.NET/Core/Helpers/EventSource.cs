// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;

namespace DataObjects.NET.Helpers
{
  /// <summary>
  /// Provides event subscription mechanism, that doesn't
  /// require unsubscription (a list of event subscribers 
  /// internally uses <see cref="WeakReference"/>s).
  /// This type should be used as <see langword="event"/>
  /// replacement in situations when event consumers
  /// should be available for garbage collection independently
  /// of their subscription status.
  /// </summary>
  public class EventSource
  {
    private static TimeSpan OptimizationPeriod = TimeSpan.FromSeconds(60);
    private ArrayList consumers = new ArrayList();
    private DateTime  lastOptimizationTime;
    private bool raiseIsLocked;
    
    /// <summary>
    /// Registers an event consumer.
    /// <seealso cref="Unsubscribe"/>
    /// <seealso cref="RaiseEvent"/>
    /// </summary>
    /// <param name="consumer">Event consumer to register.</param>
    /// <remarks>
    /// <para>
    /// It's not necessary to unregister event consumers - 
    /// <see cref="EventSource"/> internally holds 
    /// <see cref="WeakReference"/>s to registered event consumers.
    /// </para>
    /// <note type="note">You can register the same event consumer
    /// (<see cref="EventHandler"/> delegate) more then once, but 
    /// anyway it will be notified only once when the event will occur.
    /// You should register different <see cref="EventHandler"/>s 
    /// pointing on the same method if multiple notifications are required.
    /// </note>
    /// </remarks>
    public void Subscribe(EventHandler consumer)
    {
      if (consumer==null)
        throw new ArgumentNullException("consumer");

      TryOptimize();
      consumers.Add(new WeakReference(consumer));
    }
    
    /// <summary>
    /// Unregisters an event consumer.
    /// <seealso cref="Subscribe"/>
    /// <seealso cref="RaiseEvent"/>
    /// </summary>
    /// <param name="consumer">Event consumer to unregister.</param>
    /// <remarks>
    /// <para>
    /// Normally it's not necessary to unregister event consumers - 
    /// <see cref="EventSource"/> internally holds 
    /// <see cref="WeakReference"/>s to registered event consumers.
    /// Also note, that unregistration consumes ~ O(RegisteredConsumersCount) 
    /// time.
    /// </para>
    /// </remarks>
    public void Unsubscribe(EventHandler consumer)
    {
      if (consumer==null)
        throw new ArgumentNullException("consumer");

      TryOptimize();
      int cnt = consumers.Count;
      for (int i = 0; i<cnt; i++) {
        WeakReference wr = (WeakReference)consumers[i];
        EventHandler c = wr.Target as EventHandler;
        if (c!=null && c.Target==consumer.Target) {
          consumers.Remove(i);
          cnt--; i--;
        }
      }
    }
    
    /// <summary>
    /// Notifies all consumers about the event.
    /// <seealso cref="Subscribe"/>
    /// <seealso cref="Unsubscribe"/>
    /// <seealso cref="GetSafeRaiseEventHandler"/>
    /// </summary>
    /// <param name="sender">Event source object.</param>
    /// <param name="e">An <see cref="EventArgs"/> that contains the 
    /// event data.</param>
    /// <remarks>This method <see cref="Optimize">optimizes</see>
    /// internal consumers table additionaly.
    /// </remarks>
    public void RaiseEvent(object sender, EventArgs e)
    {
      if (raiseIsLocked)
        throw new InvalidOperationException(
          "Raise method is locked. Use safe RaiseEvent handler instead.");
      TryOptimize();
      int cnt = consumers.Count;
      for (int i = 0; i<cnt; i++) {
        WeakReference wr = (WeakReference)consumers[i];
        EventHandler c = wr.Target as EventHandler;
        if (c!=null)
          c(sender, e);
      }
    }
    
    private void InternalRaiseEvent(object sender, EventArgs e)
    {
      TryOptimize();
      int cnt = consumers.Count;
      for (int i = 0; i<cnt; i++) {
        WeakReference wr = (WeakReference)consumers[i];
        EventHandler c = wr.Target as EventHandler;
        if (c!=null)
          c(sender, e);
      }
    }
    
    /// <summary>
    /// Returns safe <see cref="RaiseEvent"/> handler and "locks" unsafe
    /// <see cref="RaiseEvent"/> method.
    /// </summary>
    /// <returns>Safe <see cref="RaiseEvent"/> handler.</returns>
    /// <remarks>
    /// <para>
    /// It will be impossible to invoke <see cref="RaiseEvent"/> method
    /// of this object once you called this method, but you can do the same
    /// by invoking a delegate returned by this method.
    /// </para>
    /// <para>
    /// This allows to prevent external invocations of <see cref="RaiseEvent"/>
    /// method. Generally you should use the following schema to do this:
    /// a) Create <see cref="EventSource"/>; b) Obtain its <see cref="GetSafeRaiseEventHandler"/>
    /// (safe <see cref="RaiseEvent"/> handler) and store it in some private 
    /// field of your type; c) Invoke safe <see cref="RaiseEvent"/> handler
    /// when desired event occurs. 
    /// </para>
    /// </remarks>
    public EventHandler GetSafeRaiseEventHandler()
    {
      if (raiseIsLocked)
        throw new InvalidOperationException(
          "Safe RaiseEvent handler was already taken.");
      raiseIsLocked = true;
      return new EventHandler(InternalRaiseEvent);
    }
    
    /// <summary>
    /// Optimizes inner event consumers list by removing
    /// dead <see cref="WeakReference"/>s and duplicates.
    /// </summary>
    /// <remarks>
    /// <para>
    /// Optimization requires ~ O(RegisteredConsumersCount) 
    /// time.
    /// </para>
    /// </remarks>
    public void Optimize()
    {
      Hashtable hConsumers = new Hashtable();
      int cnt = consumers.Count;
      for (int i = 0; i<cnt; i++) {
        WeakReference wr = (WeakReference)consumers[i];
        EventHandler c = wr.Target as EventHandler;
        if (c!=null)
          hConsumers[c.Target] = wr;
      }
      consumers.Clear();
      foreach (object o in hConsumers.Values)
        consumers.Add(o);
      lastOptimizationTime = DateTime.UtcNow;
    }
    
    private void TryOptimize()
    {
      if ((lastOptimizationTime+OptimizationPeriod) < DateTime.UtcNow)
        Optimize();
    }
    
    
    // Constructors
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    public EventSource()
    {
      lastOptimizationTime = DateTime.UtcNow;
    }
  }
}
