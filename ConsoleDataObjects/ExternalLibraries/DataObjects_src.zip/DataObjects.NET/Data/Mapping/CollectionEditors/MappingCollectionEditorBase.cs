// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.ComponentModel.Design;
using DataObjects.NET.Data;

namespace DataObjects.NET.Data.Design
{
  /// <summary>
  /// Base class for all mapping collection editors.
  /// </summary>
  public class MappingCollectionEditorBase: CollectionEditor
  {
    private Type[] itemTypes;

    /// <summary>
    /// Gets the data type that this collection contains.
    /// </summary>
    /// <returns>The data type of the items in the collection.</returns>
    protected override Type CreateCollectionItemType()
    {
      return itemTypes[0];
    }
    
    /// <summary>
    /// Gets the data types that this collection editor can contain.
    /// </summary>
    /// <returns>An array of data types that this collection can contain.</returns>
    protected override Type[] CreateNewItemTypes()
    {
      return itemTypes;
    }
  
    /// <summary>
    /// Initializes a new instance of the <see cref="MappingCollectionEditorBase"/> class.
    /// </summary>
    /// <param name="collectionType">Collection <see cref="Type"/>.</param>
    /// <param name="itemType">Item <see cref="Type"/>.</param>
    public MappingCollectionEditorBase(Type collectionType, Type itemType): base(collectionType)
    {
      this.itemTypes = new Type[] {itemType};
    }
  }
}
