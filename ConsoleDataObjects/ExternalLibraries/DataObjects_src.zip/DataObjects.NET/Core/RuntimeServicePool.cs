// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Threading;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Attributes;

namespace DataObjects.NET
{
  /// <summary>
  /// Holds and executes <see cref="RuntimeService"/>s.
  /// This type is completely safe for multithreaded operations.
  /// <seealso cref="RuntimeService"/>
  /// <seealso cref="Domain.RuntimeServices"/>
  /// </summary>
  #if (!NoMBR)
  public class RuntimeServicePool: MarshalByRefObject
  #else
  public class RuntimeServicePool: Object
  #endif
  {
    private Domain         domain;
    private Session        session;
    private Thread         workerThread;
    private AutoResetEvent reanimateEvent = new AutoResetEvent(false);
    private HeapTable      heap = new HeapTable();
    private int            unnamedServiceIndex = 0;
    
    private class RuntimeServiceCreationInfo {
      public Type Type;
      public object[] InitParams;
    }


    /// <summary>
    /// Adds (registers) the runtime service.
    /// <seealso cref="RemoveRuntimeService"/>
    /// </summary>
    /// <param name="name">Unique name of the service.</param>
    /// <param name="type">Type of service to add.</param>
    /// <param name="initParams">Init parameters.</param>
    public void AddRuntimeService(string name, Type type, params object[] initParams)
    {
      if (!type.IsSubclassOf(typeof(RuntimeService)))
        throw new InvalidOperationException(
          "Only descendants of RuntimeService can be added.");

      RuntimeServiceCreationInfo ci = new RuntimeServiceCreationInfo();
      ci.Type       = type;
      ci.InitParams = initParams;
      
      lock(this) {
        if (!domain.IsServiceRegistered(type))
          domain.RegisterService(type);
        heap.Add(name, DateTime.UtcNow.Add(domain.RuntimeServiceStartupDelay), ci);
      }
      reanimateEvent.Set();
    }
    
    /// <summary>
    /// Adds (registers) the runtime service (with system-defined name).
    /// <seealso cref="RemoveRuntimeService"/>
    /// </summary>
    /// <param name="type">Type of service to add.</param>
    /// <param name="initParams">Init parameters.</param>
    public void AddRuntimeService(Type type, params object[] initParams)
    {
      lock(this) {
        AddRuntimeService("UnnamedService_"+unnamedServiceIndex, type, initParams);
        unnamedServiceIndex++;
      }
    }
    
    /// <summary>
    /// Removes (unregisters) the runtime service.
    /// <seealso cref="AddRuntimeService"/>
    /// </summary>
    /// <param name="name">Name of the service to remove.</param>
    public void RemoveRuntimeService(string name)
    {
      lock(this) {
        heap.Remove(name);
      }
    }
    
    internal void Start(Session session)
    {
      this.session = session;
      workerThread = new Thread(new ThreadStart(Main));
      workerThread.IsBackground = true;
      workerThread.Start();
    }

//    /// <summary>
//    /// Gets the number of <see cref="RuntimeService"/>s in the pool.
//    /// </summary>
//    private int Count {
//      get { 
//        return heap.Count;
//      }
//    }
//
//    /// <summary>
//    /// Gets the <see cref="RuntimeService"/> with the specified name.
//    /// </summary>
//    public RuntimeService this[string name] {
//      get {
//        lock (this) {
//          return heap[name] as RuntimeService;
//        }
//      }
//    }

    private void Main()
    {
      while (true) {
        while (true) {
          lock(this) {
            if (heap.Count==0 || (DateTime)heap.MinOrder>DateTime.UtcNow)
              break;
          }
          
          RuntimeService rs;
          object key = null;
          object o = null;
          lock(this) {
            key = heap.MinKey;
            o = heap[key];
            if (o==null) {
              heap.Remove(key);
              continue;
            }
          }

          if (o is RuntimeServiceCreationInfo) {
            RuntimeServiceCreationInfo ci = (RuntimeServiceCreationInfo)o;
            try {
              ObjectModel.Service s = session.Services[ci.Type];
              if (s!=null && s.ServiceType==DataServiceType.Shared)
                rs = (RuntimeService)session.GetServiceInternal(ci.Type);
              else
                rs = (RuntimeService)session.CreateServiceInternal(ci.Type, ci.InitParams);
            }
            catch (Exception e) {
              lock(this)
                heap.Remove(key);
              session.domain.LogDebugEvent(String.Format(
                "RuntimeServicePool: Service \"{0}\" (type: \"{1}\") was removed from pool due to error.\r\n" +
                "                    Error: {2}", (string)key, ci.Type.Name, e.ToString()));
              continue;
            }
            lock(this) {
              if (heap.Contains(key))
                heap[key] = rs;
            }
          }
          else
            rs = (RuntimeService)o;

          Exception serviceException = null;
          TransactionController tc = null;
          try {
            session.OnRuntimeServiceBeforeExecute(rs);
            tc = session.CreateTransactionController(TransactionMode.TransactionRequired);
            rs.Execute();
            tc.Commit();
            try { session.OnRuntimeServiceAfterExecute(rs, null); } catch {}
          }
          catch (Exception e) {
            // We don't want to re-process the transaction!
            if (tc!=null)
              tc.Rollback(e); 
            serviceException = e;
            session.OnRuntimeServiceAfterExecute(rs, e); 
          }
          try {
            session.CloseConnection();
          } 
          catch {}

          TimeSpan delay = TimeSpan.MaxValue;
          try {
            delay = rs.GetDelay(serviceException);
          }
          catch {}
          
          lock(this) {
            if (heap.Contains(key)) {
              if (delay < TimeSpan.MaxValue)
                heap.SetOrder(key, DateTime.UtcNow + delay);
              else
                heap.Remove(key);
            }
          }
        }

        object timeToSleep = null;
        lock(this)
          if (heap.Count > 0)
            timeToSleep = (DateTime)heap.MinOrder - DateTime.UtcNow;
//        if (heap.Count > 0) {
//          TimeSpan timeToSleep = (DateTime)heap.MinOrder - DateTime.Now;
//          if (timeToSleep < TimeSpan.FromMilliseconds(10))
//            timeToSleep = TimeSpan.FromMilliseconds(10);
//          Thread.Sleep(timeToSleep);
//        }
//        else
//          reanimateEvent.WaitOne();
        if (timeToSleep != null) {

          TimeSpan timeToSleep1 = (TimeSpan) timeToSleep;
          if (timeToSleep1 < TimeSpan.FromMilliseconds(10))
            timeToSleep1 = TimeSpan.FromMilliseconds(10);
          Thread.Sleep(timeToSleep1);
        }
        else
          reanimateEvent.WaitOne();
      }
    }
    
    // Constructors

    /// <summary>
    /// Creates a new instance of this class.
    /// </summary>
    internal RuntimeServicePool(Domain domain)
    {
      if (domain==null)
        throw new ArgumentNullException("domain");
      this.domain = domain;
    }
  }
}
