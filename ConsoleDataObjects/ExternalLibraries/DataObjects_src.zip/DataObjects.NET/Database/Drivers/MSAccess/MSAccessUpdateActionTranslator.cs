// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Text;
using System.Collections;
using System.Reflection;
using System.Data;
using System.Data.OleDb;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Attributes;
using DataObjects.NET.DatabaseModel;
using DataObjects.NET.DatabaseModel.UpdateActions;
using DataObjects.NET.ObjectModel;

namespace DataObjects.NET.Database.Drivers.MSAccess
{
  /// <summary>
  /// Microsoft Access implementation of <see cref="UpdateActionTranslator"/>.
  /// </summary>
  public class MSAccessUpdateActionTranslator: UpdateActionTranslator
  {
    // Pre-calculated values
    string     tDataObject;
    string     cID;
    string     cTypeId;
    string     cVersionId;
    string     cPermissions;
    string     cFastLoadData;
    string     cAll;
    string     tSysTypes;
    string     cSysTypeID;
    string     cSysTypeValue;


    /// <summary>
    /// Adds table to database.
    /// </summary>
    /// <param name="action">An object holding description of the action.</param>
    /// <returns>Array of SQL commands (strings), that performs update.</returns>
    public override string[] DatabaseAddTable(DatabaseAddTableAction action) 
    {
      ArrayList sqlQuery = new ArrayList();

      Table table = action.Table;
      sqlQuery.Add(DatabaseAddTableSqlText(table, table.Name));
      
      return (string[])sqlQuery.ToArray(typeof(string));
    }

    /// <summary>
    /// Fixups the content of the table.
    /// In particular, adds all rows that corresponds to existing objects 
    /// to the table.
    /// </summary>
    /// <param name="action">An object holding description of the action.</param>
    /// <returns>Array of SQL commands (strings), that performs update.</returns>
    public override string[] DatabaseFixupTableContent(DatabaseFixupTableContentAction action)
    {
      ArrayList sqlQuery = new ArrayList();

      Table table = action.Table;
      ObjectModel.Type t = table.RelatedType;
      
      if (t!=null && !t.IsInterface && t.SourceType!=typeof(DataObject)) {
        Table doTable = t.Model.Types[typeof(DataObject)].RelatedTable;
        string typeIdFilter =
          QuoteDoubleIdentifier(doTable.Name,"TypeID") +
          " in (" + t.ID;
        if (!t.ShareDescendantTable)
          foreach (ObjectModel.Type ta in t.Model.Types)
            if (t!=ta && t.IsAncestorOf(ta))
              typeIdFilter += ", " + ta.ID;
        typeIdFilter += ")";
        
        sqlQuery.Add(
          "Delete from " + QuoteIdentifier(table.Name) + "\n" + 
          "  where " + 
             QuoteDoubleIdentifier(table.Name, "ID") + "<>0 and " +
             QuoteDoubleIdentifier(table.Name, "ID") + " not in (\n" + 
          "  Select " + QuoteDoubleIdentifier(doTable.Name, "ID") + " from " + QuoteIdentifier(doTable.Name) + "\n"+
          "    where " + typeIdFilter + ")");

        sqlQuery.Add(
          "Insert into " + QuoteIdentifier(table.Name) + " (" + QuoteIdentifier("ID") + ")\n" + 
          "Select " + QuoteDoubleIdentifier(doTable.Name, "ID") + " from " + QuoteIdentifier(doTable.Name) + "\n"+
          "  left join " + QuoteIdentifier(table.Name) + " on " + 
             QuoteDoubleIdentifier(doTable.Name,"ID") + "=" + 
             QuoteDoubleIdentifier(table.Name,"ID") + "\n"+
          "  where (" + QuoteDoubleIdentifier(table.Name,"ID") + " is null) and " + "(" + typeIdFilter +")");
      }

      return (string[])sqlQuery.ToArray(typeof(string));
    }

    // !!! tableName is only used for Table Name; TableName for default constraints are taken from table.Name
    private string DatabaseAddTableSqlText(Table table, string tableName) 
    {
      // Adds table with its columns.
      string sqlQuery = "Create table " + QuoteIdentifier(tableName) + " ";
      
      if (table.Columns.Count==0) {
        throw new DatabaseUpdateException(String.Format("New table \"{0}\" has empty Columns list.",table.Name));
      }

      // add columns definition
      string coldef = "";
      for (int i=0; i<table.Columns.Count; i++) {
        // column name and type
        Column c2 = table.Columns[i];
        coldef+=", "+QuoteIdentifier(c2.Name)+" " + Driver.Utils.GetSqlTypeName(c2.SqlType);
        // size and fractionalSize for decimal
        if (c2.Size!=0) {
          coldef+=" (" + c2.Size.ToString();
          if (c2.FractionalSize!=0 && c2.SqlType==SqlType.Decimal)
            coldef+="," + c2.FractionalSize.ToString();
          coldef+=") ";
        }

        string defaultValue = GetColumnDefault(table.Columns[i]);
        if (table.Columns[i].AutoIncrement) {
          // identity 
          coldef+=" identity (1,1) ";
        }
        else {
          /* Access doesn't support collation
          // collation
          if (IsStringType(table.Columns[i].SqlType) && table.Columns[i].SqlCollation!=SqlCollation.None)
          coldef+=" collate " + Driver.Utils.GetSqlCollationName(table.Columns[i].SqlCollation);
          */

          // default constraint
          if (defaultValue!="") {
            /* Access doesn't use default constraint
            coldef+=" constraint ";
            coldef+=QuoteIdentifier("DF_" + table.Name + "_" + table.Columns[i].Name);        
            */
            if (table.Columns[i].Nullable)
              coldef+=" default Null";  
            else
              coldef+=" default "+defaultValue;
          }
        }

        //It must be NULLable until DEFAULT value is set!
        if (table.Columns[i].SqlType==SqlType.Boolean || (!table.Columns[i].Nullable && defaultValue!="")) // Access doesn't allow nullable boolean types
          coldef+=" not Null";
      }
      coldef = coldef.Remove(0,2); // remove first ", "

      sqlQuery += " ( " + coldef + " ) ";  // the end of column definitions
      /* Access doesn't support sp_tableoption
      if (table.RelatedType!=null && 
          table.RelatedType.SourceType==typeof(DataObject))
        sqlQuery += "\nExec sp_tableoption "+Driver.Utils.QuoteString(tableName)+
          ", 'text in row', '512'";
      */
        
      return sqlQuery;
    }

    /// <summary>
    /// Changes table in the database.
    /// </summary>
    /// <param name="action">An object holding description of the action.</param>
    /// <returns>Array of SQL commands (strings), that performs update.</returns>
    public override string[] DatabaseChangeTable(DatabaseChangeTableAction action)
    {
      DatabaseModel.Table newTable = action.NewTable;
      DatabaseModel.Table oldTable = action.OldTable;
      ArrayList sqlQuery = new ArrayList();
      string tabName = newTable.Name;
      string tmpTabName = "__tmp_" + tabName;
      
      /* Access doesn't use default constraint
      // drop all table constraints because their names are equal to names of new tables
      foreach (Column c in oldTable.Columns) {
        if (!c.AutoIncrement && c.SqlType!=SqlType.TimeStamp)
          sqlQuery+="Alter table " + QuoteIdentifier(oldTable.Name) + " drop constraint " +
            QuoteIdentifier("DF_" + oldTable.Name + "_" + c.Name) + "\n";
      }
      */

      // create temporary table
      sqlQuery.Add( DatabaseAddTableSqlText(newTable, tmpTabName) );

      // move data
      if (0!=action.PreservedColumns.Keys.Count) 
      {
        string colListTarget = ""; // "col1, col2, ..."
        foreach (Column c in action.PreservedColumns.Keys) 
        {
          if (c.SqlType!=SqlType.TimeStamp)
            colListTarget+=", " + QuoteIdentifier(c.Name);
        }
        colListTarget = colListTarget.Remove(0, 2);

        string colListSource = ""; // "col1, col2, ..."
        foreach (Column c in action.PreservedColumns.Keys) 
        {
          Column cNew = (Column) action.PreservedColumns[c];
          if (c.SqlType!=SqlType.TimeStamp) 
          {
            string columnExpression = QuoteIdentifier(c.Name);
            string columnDefault    = Driver.Utils.GetDefault(c.SqlType);
            if (c.Nullable && !cNew.Nullable)
              columnExpression = String.Format("switch( isnull({0}),{1}, true,{0})", columnExpression, columnDefault);
            else if (!c.Nullable && cNew.Nullable && (cNew.RelatedField is ReferenceField))
              columnExpression = String.Format("switch( {0}=0,null, true,{0})", columnExpression);
            colListSource+=", " + columnExpression;
          }
        }
        colListSource = colListSource.Remove(0, 2);

        DatabaseModel.Index pk = newTable.Indexes.PrimaryIndex;
        bool hasIdentity = pk!=null && pk.Columns[0].AutoIncrement;
        if (hasIdentity)
        {
          //sqlQuery.Add( "Set IDENTITY_INSERT "+QuoteIdentifier(tmpTabName)+" ON " );
        }
        sqlQuery.Add( "Insert into " + QuoteIdentifier(tmpTabName) + " (" + colListTarget + ") \n" +
          "    Select " + colListSource + " from " + QuoteIdentifier(tabName) + " TabLockX" );
        /* Access doesn't support SET IDENTITY_INSERT
        if (hasIdentity)
          sqlQuery.Add( "Set IDENTITY_INSERT "+QuoteIdentifier(tmpTabName)+" OFF" );
        */

        // drop old table
        sqlQuery.Add( DatabaseDeleteTableSqlText(oldTable) );

        // rename table by creating the new tablem, copy the data from temp to new,
        // then drop the tmp table
        sqlQuery.Add( DatabaseAddTableSqlText(newTable, tabName) );
        /* Access doesn't support SET IDENTITY_INSERT
        if (hasIdentity)
        {
          sqlQuery.Add( "Set IDENTITY_INSERT "+QuoteIdentifier(tabName)+" ON " );
        }
        */
        sqlQuery.Add( "Insert into " + QuoteIdentifier(tabName) + " (" + colListTarget + ") \n" +
          "    Select " + colListSource + " from " + QuoteIdentifier(tmpTabName) + " TabLockX" );
        /* Access doesn't support SET IDENTITY_INSERT
        if (hasIdentity)
          sqlQuery.Add( "Set IDENTITY_INSERT "+QuoteIdentifier(tabName)+" OFF" );
        */
        sqlQuery.Add( "DROP TABLE " + QuoteIdentifier(tmpTabName) );
      }
      return (string[]) sqlQuery.ToArray(typeof(string));
    }

    /// <summary>
    /// Deletes table from database.
    /// </summary>
    /// <param name="action">An object holding description of the action.</param>
    /// <returns>Array of SQL commands (strings), that performs update.</returns>
    public override string[] DatabaseDeleteTable(DatabaseDeleteTableAction action)
    {
      string sqlQuery = DatabaseDeleteTableSqlText(action.Table);

      return new string[] {sqlQuery};
    }

    private string DatabaseDeleteTableSqlText(Table table)
    {
      string sqlQuery = "Drop table " + QuoteIdentifier(table.Name);

      return sqlQuery;
    }

    /// <summary>
    /// Adds view to database.
    /// </summary>
    /// <param name="action">An object holding description of the action.</param>
    /// <returns>Array of SQL commands (strings), that performs update.</returns>
    public override string[] DatabaseAddView(DatabaseAddViewAction action)
    {
      View view = action.View;
      string defText = "";
      string join_operator = "\n  inner join ";
      if ((action.View.Database.Domain.DatabaseOptions & DomainDatabaseOptions.UseOuterJoins) != 0)
        join_operator = "\n  LEFT OUTER JOIN ";
      
      if (!view.IsLayered) {
        string typeIdFilter = null;
        if (view.RelatedType!=null && view.RelatedType.ShareAncestorTable) {
          ObjectModel.Type t = view.RelatedType;
          typeIdFilter = 
            QuoteDoubleIdentifier(
              t.Model.Types[typeof(DataObject)].RelatedTable.Name,"TypeID") +
            " in (" + t.ID;
          foreach (ObjectModel.Type ta in t.Model.Types)
            if (t!=ta && t.IsAncestorOf(ta))
              typeIdFilter += ", " + ta.ID;
          typeIdFilter += ")";
        }
        
        ViewColumnCollection vcols = view.Columns;
        defText += "Select ";

        // Compose column names list
        string colList = "";
        for (int i = 0; i<vcols.Count; i++) {
          colList+=", " + QuoteDoubleIdentifier(vcols[i].Column.Table.Name,vcols[i].Column.Name) +
                    " as " + QuoteIdentifier(vcols[i].Name);
        }
        colList = colList.Remove(0,2); // remove first ", "

        // Long inner join clause
        ArrayList joinedTables = new ArrayList();
        Table mainTable = null;
        if (view.RelatedType != null)
          mainTable = view.RelatedType.RelatedTable;
        else
          mainTable = view.Columns[0].Column.Table;

        
        defText+=colList + "\n from ";

        // Need to build up the the join text separately, since
        // we'll need some prefix characters - the number of
        // which will depend on the number of joins that will 
        // be found
        StringBuilder joinText = new StringBuilder("");
        int numJoins = 0;

        joinText.Append(QuoteIdentifier(mainTable.Name));
        joinText.Append(' ');

        joinedTables.Add(mainTable.Name);

        bool bAllTablesHaveNullRows = mainTable.HasNullRow;
        for (int i = 0; i < vcols.Count; i++) {
          if (mainTable.Name!=vcols[i].Column.Table.Name &&
              !joinedTables.Contains(vcols[i].Column.Table.Name)) {
            joinText.Append(
              join_operator + QuoteIdentifier(vcols[i].Column.Table.Name) + " on " +
              QuoteDoubleIdentifier(mainTable.Name,GetTableIDColumn(mainTable).Name) +
              "=" +  QuoteDoubleIdentifier(vcols[i].Column.Table.Name,GetTableIDColumn(vcols[i].Column.Table).Name) + " )");
            numJoins++;

            bAllTablesHaveNullRows &= vcols[i].Column.Table.HasNullRow;
            joinedTables.Add(vcols[i].Column.Table.Name);
          }
        }

        // Now prefix a "( " ahead of the "from" table for each joined table
        // that was found
        for (int joinNum = 0; joinNum<numJoins; joinNum++)
        {
          defText+= "( ";
        }

        // Append the join text now
        defText += joinText.ToString();

        if (bAllTablesHaveNullRows) 
        {
          defText +=
            "\n  where " + 
            QuoteDoubleIdentifier(mainTable.Name,GetTableIDColumn(mainTable).Name) +
            "<>0";
          if (typeIdFilter!=null)
            defText += 
              " and " + typeIdFilter;
        } else {
          if (typeIdFilter!=null)
            defText +=
              "\n  where " + typeIdFilter;
        }
      }
      else {
        string unionExpr = "";
        foreach (ViewLayer layer in view.Layers) {
          string typeIdFilter = null;
          if (layer.RelatedType!=null && layer.RelatedType.ShareAncestorTable) {
            ObjectModel.Type t = layer.RelatedType;
            typeIdFilter = 
              QuoteDoubleIdentifier(
                t.Model.Types[typeof(DataObject)].RelatedTable.Name,"TypeID") +
              " in (" + t.ID;
            foreach (ObjectModel.Type ta in t.Model.Types)
              if (t!=ta && t.IsAncestorOf(ta))
                typeIdFilter += ", " + ta.ID;
            typeIdFilter += ")";
          }
          
          ViewLayer vcols = layer;
          defText += unionExpr + "Select ";

          // Compose column names list
          string colList = "";
          for (int i = 0; i<vcols.Count; i++) {
            colList+=", " + QuoteDoubleIdentifier(vcols[i].Column.Table.Name,vcols[i].Column.Name) +
                      " as " + QuoteIdentifier(vcols[i].Name);
          }
          colList = colList.Remove(0,2); // remove first ", "

          ArrayList joinedTables = new ArrayList();
          Table mainTable = null;
          if (layer.RelatedTable != null)
            mainTable = layer.RelatedTable;
          else
            throw new DataObjectsDotNetException(
              "Internal error: layered view does not contain layer.RelatedTable.");

          defText+=colList + " from ";

          StringBuilder joinText = new StringBuilder("");
          int numJoins = 0;
  
          joinText.Append(QuoteIdentifier(mainTable.Name));
          joinText.Append(' ');
  
          // Long inner join clause
          joinedTables.Add(mainTable.Name);
          bool bAllTablesHaveNullRows = mainTable.HasNullRow;
          for (int i = 0; i < vcols.Count; i++) {
            if (!joinedTables.Contains(vcols[i].Column.Table.Name)) {
              joinText.Append(
                join_operator + QuoteIdentifier(vcols[i].Column.Table.Name) + " on " +
                QuoteDoubleIdentifier(mainTable.Name,GetTableIDColumn(mainTable).Name) +
                "=" +  QuoteDoubleIdentifier(vcols[i].Column.Table.Name,GetTableIDColumn(vcols[i].Column.Table).Name) + " )");
              bAllTablesHaveNullRows &= vcols[i].Column.Table.HasNullRow;
              joinedTables.Add(vcols[i].Column.Table.Name);
              numJoins++;
            }
          }

          // Now prefix a "( " ahead of the "from" table for each joined table
          // that was found
          for (int joinNum = 0; joinNum<numJoins; joinNum++)
          {
            defText+= "( ";
          }

          // Append the join text now
          defText += joinText.ToString();

          if (bAllTablesHaveNullRows) {
            defText +=
              "\n    where " + 
              QuoteDoubleIdentifier(mainTable.Name,GetTableIDColumn(mainTable).Name) +
              "<>0";
            if (typeIdFilter!=null)
              defText +=
                " and " + typeIdFilter;
          } else {
            if (typeIdFilter!=null)
              defText +=
                "\n  where " + typeIdFilter;
          }
          unionExpr = "\n  Union all ";
        }
        if (view.Layers.Count > 1)
          defText = String.Format("select * from ( \n {0} \n )",defText);
      }

      string sqlQuery = "Create view " + QuoteIdentifier(action.View.Name)+" as \n";
      sqlQuery+="  " + defText;

      return new string[] {sqlQuery};
    }

    /// <summary>
    /// Deletes view from database.
    /// </summary>
    /// <param name="action">An object holding description of the action.</param>
    /// <returns>Array of SQL commands (strings), that performs update.</returns>
    public override string[] DatabaseDeleteView(DatabaseDeleteViewAction action)
    {
      string sqlQuery = "Drop view " + QuoteIdentifier(action.View.Name);

      return new string[] {sqlQuery};
    }

    /// <summary>
    /// Adds column to table.
    /// </summary>
    /// <param name="action">An object holding description of the action.</param>
    /// <returns>Array of SQL commands (strings), that performs update.</returns>
    public override string[] TableAddColumn(TableAddColumnAction action)
    {
      string sqlQuery = "";
      sqlQuery+="Alter table " + QuoteIdentifier(action.Table.Name) + " add ";

      string coldef = QuoteIdentifier(action.Column.Name) + " "+Driver.Utils.GetSqlTypeName(action.Column.SqlType);
      if (action.Column.Size!=0) {
        coldef+="("+action.Column.Size.ToString();
        if (action.Column.FractionalSize!=0 && action.Column.SqlType==SqlType.Decimal)
          coldef+=","+action.Column.FractionalSize.ToString();
        coldef+=")";
      }
      
      string defaultValue = GetColumnDefault(action.Column);
      if (action.Column.AutoIncrement) {
        // identity 
        coldef+=" identity(1,1) ";
      }
      else {
        /* Access doesn't support collation
        // collation
        if (IsStringType(action.Column.SqlType) && action.Column.SqlCollation!=SqlCollation.None)
        coldef+=" collate " + Driver.Utils.GetSqlCollationName(action.Column.SqlCollation);
        */

        // default constraint
        /* Access doesn't use default constraint
        coldef+=" constraint ";
        coldef+=QuoteIdentifier("DF_" + action.Table.Name + "_" + action.Column.Name);
        */
        if (action.Column.Nullable) 
          coldef+=" default Null";  
        else
          coldef+=" default "+defaultValue;
      }

      //It must be NULLable until DEFAULT value is set!
      if (!action.Column.Nullable && defaultValue!="") 
        coldef+=" not Null";

      sqlQuery+=coldef;
      return new string[] {sqlQuery};
    }
    
    /// <summary>
    /// Deletes column from table.
    /// </summary>
    /// <param name="action">An object holding description of the action.</param>
    /// <returns>Array of SQL commands (strings), that performs update.</returns>
    public override string[] TableDeleteColumn(TableDeleteColumnAction action)
    {
      string sqlQuery = "";
      /* Access doesn't use default constraint
      if (!action.Column.AutoIncrement && action.Column.SqlType!=SqlType.TimeStamp) {
        // drop default constraint
        sqlQuery += "Alter table " + QuoteIdentifier(action.Table.Name) + " drop constraint " +
                    QuoteIdentifier("DF_" + action.Table.Name + "_" + action.Column.Name);
      }
      */

      sqlQuery += "\nAlter table " + QuoteIdentifier(action.Table.Name) + " drop column " +
                   QuoteIdentifier(action.Column.Name);

      return new string[] {sqlQuery};
    }

    /// <summary>
    /// Adds index to table.
    /// </summary>
    /// <param name="action">An object holding description of the action.</param>
    /// <returns>Array of SQL commands (strings), that performs update.</returns>
    public override string[] TableAddIndex(TableAddIndexAction action) 
    {
      string sqlQuery = "";
      
      if (action.Index.Primary) 
      {
        // Index is primary key. We must add and delete it as table constraint
        sqlQuery = "Alter table " + QuoteIdentifier(action.Table.Name) + " add constraint " +
          QuoteIdentifier(action.Index.Name) +" primary key ";

        /* Access doesn't support clustered indexes
          if (action.Index.Clustered) sqlQuery+=" clustered ";
          else sqlQuery+=" nonClustered ";
          */

        // Fill in columns list
        sqlQuery+=" ( ";
        sqlQuery+=" " + QuoteIdentifier(action.Index.Columns[0].Name) + " ";
        for (int i=1; i<action.Index.Columns.Count; i++) 
        {
          sqlQuery+=", " + QuoteIdentifier(action.Index.Columns[i].Name) + " ";
        }
        sqlQuery+=" ) ";

        /* Access doesn't suppoprt fillfactor
        if (action.Index.FillFactor!=0) 
        {
          int ff = (int)(action.Index.FillFactor*100);
          sqlQuery+=" with fillFactor = " + ff.ToString();
        }
        */
      }
      else 
      {
        // Index is not primary key. We must add and delete it as independent index.
        sqlQuery = "Create ";

        if (action.Index.Unique) sqlQuery+="unique ";

        /* Access doesn't support clustered indexes
          if (action.Index.Clustered)sqlQuery+="clustered ";
          else sqlQuery+="nonClustered ";
          */

        sqlQuery+="index " + QuoteIdentifier(action.Index.Name) + " on " +
          QuoteIdentifier(action.Table.Name) + " (";
        // Fill in columns list
        sqlQuery+=" " + QuoteIdentifier(action.Index.Columns[0].Name) + " ";
        for (int i=1; i<action.Index.Columns.Count; i++) 
        {
          sqlQuery+=", " + QuoteIdentifier(action.Index.Columns[i].Name) + " ";
        }
        sqlQuery+=" )";

        /* Access doesn't suppoprt fillfactor
        if (action.Index.FillFactor!=0) 
        {
          int ff = (int)(action.Index.FillFactor*100);
          sqlQuery+=" with fillFactor = " + ff.ToString();
        }
        */
      }

      return new string[] {sqlQuery};
    }
    
    /// <summary>
    /// Deletes index from table.
    /// </summary>
    /// <param name="action">An object holding description of the action.</param>
    /// <returns>Array of SQL commands (strings), that performs update.</returns>
    public override string[] TableDeleteIndex(TableDeleteIndexAction action) 
    {
      string sqlQuery = "";

      if (action.Index.Name.StartsWith( "FK_" ) || action.Index.Name.StartsWith( "PK_" ) )
      {
        //queries.Add( "ALTER table " + QuoteIdentifier(action.Table.Name) + " drop constraint " + QuoteIdentifier(action.Index.Name) );
        return new string[0];
      }
      else
      {
        sqlQuery = "Drop index " + QuoteIdentifier(action.Index.Name) + " ON " + QuoteIdentifier(action.Table.Name);
      }

      return new string[] {sqlQuery};
    }

    /// <summary>
    /// Adds constraint to the table.
    /// </summary>
    /// <param name="action">An object holding description of the action.</param>
    /// <returns>Array of SQL commands (strings), that performs update.</returns>
    public override string[] TableAddConstraint(TableAddConstraintAction action) 
    {
      // Sample command
      // ALTER TABLE [dbo].[doTestDOClass2] ADD 
      //   CONSTRAINT [FK_doTestDOClass2_doTestDOClass] FOREIGN KEY 
      //   (
      //     [refTest]
      //   ) REFERENCES [dbo].[doTestDOClass] (
      //     [ID]
      //   )
      //   ON DELETE CASCADE | NO ACTION
      //   ON UPDATE CASCADE | NO ACTION
      
      DatabaseModel.ForeignKeyConstraint fk = action.Constraint as DatabaseModel.ForeignKeyConstraint;
      if (fk==null)
        return new string[0];
      
      string sqlQuery = "";
      string fkColumns = "";
      string pkColumns = "";
      
      bool bFirst = true;
      foreach (Column column in fk.PrimaryKeyConstraint.Columns) {
        pkColumns += QuoteIdentifier(column.Name);
        if (!bFirst) {
          pkColumns += ", ";
        }
        bFirst = false;
      }

      bFirst = true;
      foreach (Column column in fk.Columns) {
        fkColumns += QuoteIdentifier(column.Name);
        if (!bFirst) {
          fkColumns += ", ";
        }
        bFirst = false;
      }

      string format = "Alter table {0} add constraint {1} foreign key ({2}) references {3} ({4}) on delete {5} on update {6}";
      sqlQuery = String.Format(format,QuoteIdentifier(action.Table.Name),
        QuoteIdentifier(fk.Name),fkColumns,
        QuoteIdentifier(fk.PrimaryKeyConstraint.Table.Name),
        pkColumns,
        fk.OnDeleteCascade ? "cascade" : "no action",
        fk.OnUpdateCascade ? "cascade" : "no action");

      return new string[] {sqlQuery};
    }
    
    /// <summary>
    /// Drops constraint from the table.
    /// </summary>
    /// <param name="action">An object holding description of the action.</param>
    /// <returns>Array of SQL commands (strings), that performs update.</returns>
    public override  string[] TableDeleteConstraint(TableDeleteConstraintAction action) 
    {
      // Sample command:
      // ALTER TABLE [dbo].[doPrincipal-Roles] DROP CONSTRAINT FK_doPrincipal-Roles_ID-1

      if (action.Constraint is DatabaseModel.ForeignKeyConstraint || action.Constraint is DatabaseModel.PrimaryKeyConstraint) {
        ArrayList queries = new ArrayList();
        if (action.Constraint is DatabaseModel.ForeignKeyConstraint) {
          queries.Add( "ALTER table " + QuoteIdentifier(action.Table.Name) + " drop constraint " + QuoteIdentifier(action.Constraint.Name) );
        }
        else {
          queries.Add( "DROP index " + QuoteIdentifier(action.Constraint.Name) + " ON " + QuoteIdentifier(action.Table.Name) ); // dropping the constraint deletes the index
        }
        return (string[])queries.ToArray(typeof(string));
      }
      else
        return new string[0];

      /*
      DatabaseModel.ForeignKeyConstraint fk = action.Constraint as DatabaseModel.ForeignKeyConstraint;
      if (fk==null )
        return new string[0];
                    
      string sqlQuery = "";
      string format = "Alter table {0} drop constraint {1}";
      sqlQuery = String.Format(format,QuoteIdentifier(action.Table.Name),
        QuoteIdentifier(fk.Name));
      return new string[] {sqlQuery};
      */
    }
    
    /// <summary>
    /// Adds a row with ID=0 to the table.
    /// </summary>
    /// <param name="action">An object holding description of the action.</param>
    /// <returns>Array of SQL commands (strings), that performs update.</returns>
    public override string[] TableAddNullRow(TableAddNullRowAction action) 
    {
      // All columns have default values, so we just need to generate a statement containing "ID" column
      ArrayList queries = new ArrayList();
      if (action.Table.Columns["ID"].AutoIncrement)
      {
        /* Access doesn't support SET IDENTITY_INSERT
        queries.Add( String.Format("Set IDENTITY_INSERT {0} ON", QuoteIdentifier(action.Table.Name)) );
        */
        queries.Add( String.Format("Insert into {0} ({1}) values (0)", QuoteIdentifier(action.Table.Name), QuoteIdentifier("ID")) );
        /* Access doesn't support SET IDENTITY_INSERT
        queries.Add( String.Format("Set IDENTITY_INSERT {0} OFF", QuoteIdentifier(action.Table.Name)) );
        */
      }
      else
      {
        queries.Add( String.Format("Insert into {0} ({1}) values (0)", QuoteIdentifier(action.Table.Name), QuoteIdentifier("ID")) );
      }

      return (string[])queries.ToArray(typeof(string));
    }
    
    /// <summary>
    /// Deletes a row with ID=0 from the table.
    /// </summary>
    /// <param name="action">An object holding description of the action.</param>
    /// <returns>Array of SQL commands (strings), that performs update.</returns>
    public override string[] TableDeleteNullRow(TableDeleteNullRowAction action) 
    {
      string strQuery = String.Format("Delete from {0} where {1}=0",
        QuoteIdentifier(action.Table.Name), QuoteIdentifier("ID"));

      return new string[] {strQuery};
    }
    
//    /// <summary>
//    /// Changes type of the column.
//    /// </summary>
//    /// <param name="action">An object holding description of the action.</param>
//    /// <returns>Array of SQL commands (strings), that performs update.</returns>
//    public override string[] ColumnChangeDbType(ChangeSqlTypeColumnAction action) 
//    {
//      // TODO: dbType can be changed very rarely ms-help://MS.VSCC/MS.MSDNVS/tsqlref/ts_aa-az_3ied.htm
//      // TODO: link action.Column.Table is bad - there is no warranty now,
//      // that table is correct.
//      // TODO: it sets properties of old column
//      string sqlQuery = "Alter table " + QuoteIdentifier(action.Column.Table.Name) + " alter column " +
//                        QuoteIdentifier(action.Column.Name) + " "+action.Column.SqlType.ToString();
//      if (action.Column.Size!=0) {
//        sqlQuery+="("+action.Column.Size.ToString();
//        if (action.Column.FractionalSize!=0 && action.Column.SqlType==SqlType.Decimal)
//          sqlQuery+=","+action.Column.FractionalSize.ToString();
//        sqlQuery+=")";
//      }
//      if (!action.Column.Nullable) sqlQuery+=" not Null";
//
//      return new string[] {sqlQuery};
//    }

    /// <summary>
    /// Registers new types in SysTypes table.
    /// </summary>
    /// <param name="action">An object holding description of the action.</param>
    /// <returns>Array of SQL commands (strings), that performs update.</returns>
    public override string[] RegisterNewTypes(RegisterNewTypesAction action)
    {
      Table sysTypesTable   = Driver.Domain.DatabaseModel.SysTypesTable;
      string cID    = sysTypesTable.Columns[0].Name;
      string cValue = sysTypesTable.Columns[1].Name;

      ArrayList sqlQueries = new ArrayList();
      foreach (string name in action.TypeIDByName.Keys) {
        int id = (int)action.TypeIDByName[name];
        sqlQueries.Add(
          "Insert into " + QuoteIdentifier(sysTypesTable.Name) + " ("+QuoteIdentifier(cID)+", "+QuoteIdentifier(cValue)+") values (" +
            id.ToString()+", '"+name+"')" );
      }

      return (string[])sqlQueries.ToArray(typeof(string));
    }

    /// <summary>
    /// Unregisters old types in SysTypes table and deletes objects of old types.
    /// </summary>
    /// <param name="action">An object holding description of the action.</param>
    /// <returns>Array of SQL commands (strings), that performs update.</returns>
    public override string[] UnregisterOldTypes(UnregisterOldTypesAction action)
    {
      ArrayList sqlQuery = new ArrayList();

      // select all object ids having typeIDs which in list
      // delete this objects from all tables
      // delete sys types
      if (action.TypeIDByName.Count==0) {
        // must be at list one record otherwise nothing te delete
        throw new DatabaseUpdateException("Error unregistering SysTypes: UnregisterOldTypesAction has empty list of types.");
      }
      
      string allTypeIDs = ""; // string of format: "(type_id1, id2, ..)"
      foreach (int s1 in action.TypeIDByName.Values) { 
        allTypeIDs += ", " + s1.ToString();
      }
      allTypeIDs = allTypeIDs.Remove(0,2); // remove first ", "
      allTypeIDs = " (" + allTypeIDs + ") ";

      // Deleting all bad objects from all tables
      foreach (Table t in Driver.Domain.DatabaseModel.Tables) {
        if (!t.IsSystemTable) {
          foreach (Column c in t.Columns) {
            if (c.ContentDescription==ColumnContentDescription.InstanceID ||
                c.ContentDescription==ColumnContentDescription.CollectedInstanceID) {
              sqlQuery.Add( "Delete from " + QuoteIdentifier(t.Name) + 
                          " where "+QuoteIdentifier(c.Name)+" in " +
                "( Select distinct "+tDataObject+"."+cID+ //" as ID " +
                "from "+tDataObject+" where "+tDataObject+"."+cTypeId+" in "+allTypeIDs+" )" );

            }
          }
        }
      }

      // Deleting bad SysTypes
      sqlQuery.Add( "Delete from "+tSysTypes+" where "+cSysTypeID+" in "+allTypeIDs );

      return (string[]) sqlQuery.ToArray(typeof(string));
    }

    /// <summary>
    /// Flashes FastLoadData property for all objects whose definition was changed.
    /// </summary>
    /// <param name="action">An object holding description of the action.</param>
    /// <returns>Array of SQL commands (strings), that performs update.</returns>
    public override string[] FlashFastLoadData(FlashFastLoadDataAction action)
    {
      // Access doesn't support UNIONs in subqueries, so issue a separate query for each changed table
      ArrayList queries = new ArrayList();
      foreach (Table t in action.ChangedTables) 
      { 
        if (!t.IsSystemTable)
        {
          queries.Add( string.Format( "Update{0} set {1}=NULL where {2} in ( Select {3} from {4} )",
            tDataObject,
            cFastLoadData,
            cID,
            Driver.Utils.QuoteIdentifier(t.Indexes.PrimaryIndex.Columns[0].Name),
            QuoteIdentifier(t.Name)
            ) );
          //string.Format( "Update "+tDataObject+" set "+cFastLoadData+"=NULL where "+cID+" in ( Select " + Driver.Utils.QuoteIdentifier(t.Indexes.PrimaryIndex.Columns[0].Name) + " from " + QuoteIdentifier(t.Name) + " )" );
        }
      }

      return (string[])queries.ToArray(typeof(string));
    }

    /// <summary>
    /// Updates database properties.
    /// </summary>
    /// <param name="action">An object holding description of the action.</param>
    /// <returns>Array of SQL commands (strings), that performs update.</returns>
    public override string[] DatabaseUpdateProperties(DatabaseUpdatePropertiesAction action)
    {
      return new string[0];

      /* Access doesn't support collation, making this whole method irrelevant
      string sqlQuery = "";
      sqlQuery += "Alter database " + QuoteIdentifier(action.Database.Domain.InternalConnectionInfo.Database);
        + " " +
                  "collate " + Driver.Utils.GetSqlCollationName(action.Database.SqlCollation);

      return new string[] {sqlQuery};
      */
    }
    
    /// <summary>
    /// Enables full-text indexing for database, creates full-text catalog.
    /// </summary>
    /// <param name="action">An object holding description of the action.</param>
    /// <returns>Array of SQL commands (strings), that performs update.</returns>
    public override string[] DatabaseFullTextEnable(DatabaseFullTextEnableAction action)
    {
      return new string[0];

      /* Access doesn't support full text
      string sqlQuery = "";

      if (action.MustEnableFullTextIndexing) {
        sqlQuery+="Exec sp_fulltext_database @action = 'enable' \n";
      }
      if (action.MustCreateCatalog) {
        sqlQuery+="Exec sp_fulltext_catalog @ftcat = " + QuoteIdentifier(action.Database.FullTextCatalogName) + ", " + 
                  "@action = 'create' \n";
      }

      return new string[] {sqlQuery};
      */
    }

    /// <summary>
    /// Determines whether specified <paramref name="action"/> can be executed 
    /// in the transaction.
    /// </summary>
    /// <param name="action">Action to check.</param>
    /// <returns><see langword="True"/>, if specified <paramref name="action"/>
    /// can be executed in the transaction; otherwise, <see langword="false"/>.</returns>
    public override bool CanExecuteInTransaction(UpdateAction action)
    {
      if (action is DatabaseFullTextEnableAction)
        return false;
      /* Access doesn't support full text
      if (action is TableAddIndexAction)
        if ((action as TableAddIndexAction).Index.FullText)
          return false;
      if (action is TableDeleteIndexAction)
        if ((action as TableDeleteIndexAction).Index.FullText)
          return false;
      */
      return true;
    }
    
    // Private methods
    
    private static string QuoteIdentifier(string s)
    {
      return "[" + s + "]";
    }

    private static string QuoteDoubleIdentifier(string t, string c)
    {
      return "[" + t + "].[" + c + "]";
    }

    private static bool IsStringType(SqlType sqlType)
    {
      if ( sqlType==SqlType.AnsiChar    ||
           sqlType==SqlType.AnsiVarChar ||
           sqlType==SqlType.AnsiText    ||
           sqlType==SqlType.Char        ||
           sqlType==SqlType.VarChar     ||
           sqlType==SqlType.Text )
        return true;
      else
        return false;
    }

    private string GetColumnDefault(Column c)
    {
      string  defaultValue = Driver.Utils.GetDefault(c.SqlType);
      if (c.RelatedField==null)
        return defaultValue;
      if (c.RelatedField is ObjectModel.EnumField) {
        ObjectModel.EnumField ef = c.RelatedField as ObjectModel.EnumField;
        Enum zero = ef.ZeroValue;
        SqlType sqlType = c.SqlType;
        if (IsStringType(c.SqlType))
          return Driver.Utils.QuoteString(zero.ToString());
        else
          return Enum.Format(zero.GetType(), zero, "d");
      }
      return defaultValue;
    }

    private static Column GetTableIDColumn(Table t)
    {
      foreach (Column c in t.Columns) {
        if (c.ContentDescription==ColumnContentDescription.InstanceID)
          return c;
      }
      throw new InvalidOperationException(String.Format("Unable to find ID column for the table \"{0}\".", t.Name));
    }

    private static string GetFtiLanguageID(Column c)
    {
      switch (c.Culture.Info.TwoLetterISOLanguageName) {
      case "en":
        if (c.Culture.Info.Name=="en-US")
          return "0x0409";
        return "0x0809";
      case "de":
        return "0x0407";
      case "fr":
        return "0x040c";
      case "es":
        return "0x0c0a";  
      case "it":
        return "0x0410";  
      case "nl":
        return "0x0413";  
      case "sv":
        return "0x041d";  
      case "ja":
        return "0x0411";  
      case "ko":
        return "0x0412";  
      case "zh":
        if (c.Culture.Info.Name=="zh-CHT")
          return "0x0404";
        return "0x0804";
      default:
        return "0";  
      }
    }
    
    /// <summary>
    /// Initializes an instance of this class.
    /// </summary>
    public override void Init()
    {
      ObjectModel.Type t = Driver.Domain.ObjectModel.Types[typeof(DataObject)];
      tDataObject   = QuoteIdentifier(t.RelatedTable.Name);
      cID           = QuoteIdentifier(t.Fields["ID"].RelatedColumns[0].Name);
      cTypeId       = QuoteIdentifier(t.Fields["TypeID"].RelatedColumns[0].Name);
      cVersionId    = QuoteIdentifier(t.Fields["VersionID"].RelatedColumns[0].Name);
      cPermissions  = QuoteIdentifier(t.Fields["Permissions"].RelatedColumns[0].Name);
      cFastLoadData = QuoteIdentifier(t.Fields["FastLoadData"].RelatedColumns[0].Name);
      cAll          = cID+", "+cTypeId+", "+cVersionId+", "+cPermissions+", "+cFastLoadData;
      
      Table tbl     = Driver.Domain.DatabaseModel.SysTypesTable;
      tSysTypes     = QuoteIdentifier(tbl.Name);
      cSysTypeID    = QuoteIdentifier(tbl.Columns[0].Name);
      cSysTypeValue = QuoteIdentifier(tbl.Columns[1].Name);
    }
    
    
    // Constructor

    /// <summary>
    /// Initializes a new instance of this class and establishes 
    /// new connection to SQL server through which updating process
    /// will be held.
    /// </summary>
    /// <param name="driver">Database driver.</param>
    public MSAccessUpdateActionTranslator(Driver driver): base(driver)
    {
    }
  }
}
