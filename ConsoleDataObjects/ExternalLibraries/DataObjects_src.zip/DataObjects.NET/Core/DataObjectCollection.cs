// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;
using System.Reflection;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Attributes;
using DataObjects.NET.Database;
using DataObjects.NET.ObjectModel;
using DataObjects.NET.Offline;

namespace DataObjects.NET
{
  /// <summary>
  /// Base class for persistent collection of <see cref="DataObject"/>
  /// instances.
  /// </summary>
  public abstract class DataObjectCollection: SessionBoundObject, 
    IList, ICollection, IEnumerable,
    IDataObjectFieldValue, IRecyclableFieldValue, IRemovableFieldValue,
    IDataObjectExternalFieldValue,
    IConvertibleToOffline
  {
    // IDataObjectFieldValue, IRemovableFieldValue support
    private    DataObject owner;
    private    Field      field;
    private    Culture    culture;
    private    Field      pairTo;
    private    System.Type itemType;
    private    ObjectModel.Type itemObjectModelType;
    private    bool       hasPair;
    private    bool       symmetric;
    private    bool       selfRefAllowed;
    private    bool       attached;
    // Implementation & loading
    internal   Internals.IDataObjectCollectionImplementation implementation;
    private    TransactionContext transactionContext;
    private    TransactionContext preLoadTransactionContext;
    private    int        blockContentChangeEvent;

    /// <summary>
    /// Gets the owner of the collection 
    /// (<see cref="DataObject"/> instance containing the collection).
    /// </summary>
    [Transactional(TransactionMode.Disabled)]
    public DataObject Owner  {get {return owner;}}

    /// <summary>
    /// Gets collection field descriptor (<see cref="Field"/> descandant).
    /// </summary>
    [Transactional(TransactionMode.Disabled)]
    public Field      Field {get {return field;}}

    /// <summary>
    /// Gets the <see cref="Culture"/> of this collection.
    /// </summary>
    [Transactional(TransactionMode.Disabled)]
    public Culture    Culture {get {return culture;}}
    

    /// <summary>
    /// Attaches the instance to the owner. This method is called by owner
    /// (<see cref="DataObject"/> instance) of the field during
    /// initialization or on property change.
    /// </summary>
    /// <param name="owner">Field owner (<see cref="DataObject"/> instance containing this field).</param>
    /// <param name="field">Field descriptor (<see cref="Field"/> descandant).</param>
    /// <param name="culture">Culture of this instance (if field is marked by 
    /// <see cref="TranslatableAttribute"/>), or <see langword="null"/>.</param>
    /// <remarks>
    /// See <see cref="IDataObjectFieldValue"/> description for additional information.
    /// </remarks>
    void IDataObjectFieldValue.Attach(DataObject owner, Field field, Culture culture)
    {
      if (attached)
        throw new InvalidOperationException("Instance is already attached.");
      if (Assembly.GetCallingAssembly()!=typeof(DataObject).Assembly)
        throw new InvalidOperationException("This method can be called only by DataObjects.NET.");

      session = owner.session;
      ObjectModel.Type oType = session.Types[itemType.FullName];
      if (oType==null)
        throw new InvalidOperationException("Illegal item type.");
      this.attached = true;
      this.owner   = owner;
      this.field   = field;
      this.culture = culture;
      this.itemObjectModelType = oType;
      DataObjectCollectionField cbf = (DataObjectCollectionField)field;
      this.selfRefAllowed = cbf.SelfRefAllowed;
      this.pairTo  = cbf.PairTo;
      this.hasPair = cbf.HasPair;
      this.symmetric = cbf.Symmetric;
      this.Implementation.Attach();
      if (ChangesTrackingMode==ChangesTrackingMode.ThroughOwner)
        InvalidateCache();
      OnAttach();
    }
  
    /// <summary>
    /// Detaches the instance from the owner.
    /// </summary>
    /// <remarks>
    /// Always throws <see cref="InvalidOperationException"/>,
    /// since this field can't be detached.
    /// See <see cref="IDataObjectFieldValue"/> description for additional information.
    /// </remarks>
    void IDataObjectFieldValue.Detach()
    {
      throw new InvalidOperationException("Collection property can't be assigned.");
    }
    
    /// <summary>
    /// Indicates whether collection contains delayed updates.
    /// </summary>
    [Transactional(TransactionMode.Disabled)]
    public bool IsChanged {
      get {
        if (implementation==null)
          return false;
        return implementation.IsChanged;
      }
    }
    
    /// <summary>
    /// Persists all changes cached by the collection to database.
    /// </summary>
    [Transactional(TransactionMode.Disabled)]
    public void Persist()
    {
      if (!attached)
        throw new InvalidOperationException("Instance isn't attached.");
      if (implementation!=null)
        implementation.Persist();
    }

    /// <summary>
    /// Called before removing of the <see cref="Owner"/> instance.
    /// </summary>
    /// <remarks>
    /// See <see cref="IRemovableFieldValue"/> description for additional information.
    /// </remarks>
    void IRemovableFieldValue.Remove()
    {
      if (Assembly.GetCallingAssembly()!=typeof(DataObject).Assembly)
        throw new InvalidOperationException("This method can be called only by DataObjects.NET.");

      if (!attached)
        throw new InvalidOperationException("Instance isn't attached.");
      // Old code:
      // Clear();
    }
    
    /// <summary>
    /// Called to check if this instance can be reused.
    /// </summary>
    /// <returns><see langword="True"/> if the instance was recycled 
    /// and can be reused; otherwise, <see langword="false"/>.</returns>
    /// <remarks>
    /// See <see cref="IRecyclableFieldValue"/> description for additional information.
    /// </remarks>
    bool IRecyclableFieldValue.Recycle()
    {
      if (Assembly.GetCallingAssembly()!=typeof(DataObject).Assembly)
        throw new InvalidOperationException("This method can be called only by DataObjects.NET.");

      if (!OnRecycle())
        return false;
      if (ChangesTrackingMode==ChangesTrackingMode.ThroughOwner)
        InvalidateCache();
      if (implementation!=null)
        implementation.ClearChanges();
      owner    = null;
      session  = null;
      attached = false;
      return true;
    }

    /// <summary>
    /// Gets <see cref="Internals.IDataObjectCollectionImplementation"/>
    /// object handling low-level services for collection.
    /// </summary>
    [Transactional(TransactionMode.Disabled)]
    protected Internals.IDataObjectCollectionImplementation Implementation {
      get {
        if (implementation!=null)
          return implementation;
        else {
          implementation = CreateImplementation();
          return implementation;
        }
      }
    }
    
    /// <summary>
    /// Creates <see cref="Implementation"/>
    /// object handling low-level services for collection.
    /// Override this method to specify your own
    /// collection implementation, rather then default.
    /// </summary>
    /// <returns></returns>
    [Transactional(TransactionMode.Disabled)]
    protected virtual Internals.IDataObjectCollectionImplementation CreateImplementation()
    {
      return new Internals.DataObjectCollectionImplementation(this);
    }

    /// <summary>
    /// Gets <see cref="ChangesTrackingMode"/> of the collection.
    /// </summary>
    [Transactional(TransactionMode.Disabled)]
    public ChangesTrackingMode ChangesTrackingMode
    {
      get {return field.ChangesTrackingMode;} 
    }
    
    /// <summary>
    /// Gets <see cref="DataObjects.NET.TransactionContext"/> where
    /// cached collection data is valid.
    /// </summary>
    [Transactional(TransactionMode.Disabled)]
    public TransactionContext TransactionContext {
      get {
        if (ChangesTrackingMode==ChangesTrackingMode.Independently)
          return transactionContext;
        else
          return owner.transactionContext;
      }
    }

    [Transactional(TransactionMode.Disabled)]
    internal virtual void InvalidateCache()
    {
      if (implementation!=null)
        implementation.InvalidateCache();
      if (session!=null)
        transactionContext = session.transactionContext;
      else
        transactionContext = null;
    }

    /// <summary>
    /// Validates owner state and collection's <see cref="TransactionContext"/>.
    /// Flushes cached data on validation failure.
    /// </summary>
    [Transactional(TransactionMode.Disabled)]
    internal protected void EnsureCacheValidity()
    {
      if (owner.State==DataObjectState.Removed)
        throw new InstanceIsRemovedException();
      if (session.IsOnlineMode) {
        if (ChangesTrackingMode==ChangesTrackingMode.Independently && 
            (transactionContext==null ||
            transactionContext.State!=TransactionContextState.Valid))
          InvalidateCache();
      }
      else {
        if (ChangesTrackingMode==ChangesTrackingMode.Independently && 
            (transactionContext==null ||
            transactionContext.State==TransactionContextState.Dirty))
          InvalidateCache();
      }
    }

    /// <summary>
    /// Caches the specified item.
    /// </summary>
    /// <param name="value">Item to cache.</param>
    /// <param name="exists"><see langword="True"/> if the specified item exists
    /// in the collection; otherwise, <see langword="false"/>.</param>
    [Transactional(TransactionMode.Disabled)]
    internal void CacheItem(long value, bool exists)
    {
      EnsureCacheValidity();
      Implementation.CacheItem(value, exists);
    }

    /// <summary>
    /// Automatically invoked before any change in the collection.
    /// </summary>
    [Transactional(TransactionMode.Disabled)]
    internal protected void ContentChanging()
    {
      if (blockContentChangeEvent>0)
        return;
      OnChange();
      owner.FieldContentChanging(this);
    }

    /// <summary>
    /// Automatically invoked on completion of any change in the collection.
    /// </summary>
    [Transactional(TransactionMode.Disabled)]
    internal protected void ContentChanged()
    {
      if (blockContentChangeEvent>0)
        return;
      OnChangeComplete();
      owner.FieldContentChanged(this);
    }

    // Other properties

    /// <summary>
    /// Gets or sets <see cref="System.Type"/> of items that can be stored in 
    /// the collection.
    /// </summary>
    [Transactional(TransactionMode.Disabled)]
    public  System.Type ItemType {
      get {return itemType;} 
    }

    /// <summary>
    /// Gets or sets <see cref="ObjectModel.Type"/> of items that can be stored in 
    /// the collection.
    /// </summary>
    [Transactional(TransactionMode.Disabled)]
    public  ObjectModel.Type ItemObjectModelType {
      get {return itemObjectModelType;} 
    }

    /// <summary>
    /// Points to the paired field (if <see cref="PairToAttribute"/> was applied
    /// to the field that declared this property) or <see langword="null"/>.
    /// </summary>
    [Transactional(TransactionMode.Disabled)]
    public Field PairTo {
      get {return pairTo;}
    }

    /// <summary>
    /// <see langword="True"/> if collection has paired field(s) (collection is a target of
    /// some <see cref="PairToAttribute"/>).
    /// </summary>
    [Transactional(TransactionMode.Disabled)]
    public bool HasPair {
      get {return hasPair;}
    }

    /// <summary>
    /// <see langword="True"/> if collection is symmetric (<see cref="SymmetricAttribute"/>).
    /// </summary>
    [Transactional(TransactionMode.Disabled)]
    public bool Symmetric {
      get {return symmetric;}
    }

    /// <summary>
    /// <see langword="True"/> if collection can store a referance to owner instance.
    /// See <see cref="SelfReferenceAllowedAttribute"/>.
    /// </summary>
    [Transactional(TransactionMode.Disabled)]
    public bool SelfRefAllowed {
      get {return selfRefAllowed;}
    }

    /// <summary>
    /// <see langword="True"/> if collection is loaded from the database.
    /// </summary>
    [Transactional(TransactionMode.Disabled)]
    public bool IsLoaded {
      get {
        if (session.IsOfflineMode) 
          return InnerIsLoaded();

        // Automatic Transactions support code
        TransactionController tc = session.CreateTransactionController(TransactionMode.TransactionRequired);
      Reprocess:
        try {
          bool r = InnerIsLoaded();
          tc.Commit();
          return r;
        }
        catch (Exception e) {
          if (tc.Rollback(e, true))
            goto Reprocess;
          throw;
        }
      }
    }
    private bool InnerIsLoaded()
    {
      EnsureCacheValidity();
      if (implementation==null)
        return false;
      return implementation.IsLoaded;
    }

    /// <summary>
    /// Reloads the collection.
    /// This method invalidates collection cache,
    /// and executes <see cref="Load"/> method 
    /// to load a list of object <see cref="DataObject.ID"/>s
    /// contained in the collection.
    /// </summary>
    [Transactional(TransactionMode.Disabled)]
    public void Reload()
    {
      Persist();
      preLoadTransactionContext = null;
      InvalidateCache();
      Load();
    }

    /// <summary>
    /// Indexer (by element index).
    /// </summary>
    [Transactional(TransactionMode.Disabled)]
    public DataObject this[int index] {
      get {
        return (DataObject)List[index];
      }
      set {
        List[index] = value;
      }
    }
    
    /// <summary>
    /// Indexer (by element value).
    /// </summary>
    [Transactional(TransactionMode.Disabled)]
    public DataObject this[DataObject item] {
      get {
        return List.Contains(item) ? item : null;
      }
      set {
        InnerSet(item, value);
      }
    }
    /// <summary>
    /// Replaces specified collection element with the new one.
    /// </summary>
    /// <param name="oldValue">Element to replace.</param>
    /// <param name="value">New element.</param>
    [BusinessMethod]
    [Transactional(TransactionMode.TransactionRequired)]
    protected virtual void InnerSet(DataObject oldValue, DataObject value)
    {
      EnsureCacheValidity();
      if (symmetric)
        throw new InvalidOperationException("Can's use this[item]=value construction for symmetric property.");
      if (owner.State==DataObjectState.New)
        owner.Persist();
      if (oldValue==null)
        throw new ArgumentNullException("item");

      if (!List.Contains(oldValue))
        throw new ArgumentException("Argument wasn't found.");
      if (oldValue==value)
        return;
      DataObject newValue = value;
      if (pairTo!=null) {
        if (pairTo is ReferenceField) {
          oldValue.SetProperty(pairTo.AbsoluteName, culture, null,  true, true, true);
          newValue.SetProperty(pairTo.AbsoluteName, culture, owner, true, true, true);
          return;
        }
        if (pairTo is DataObjectCollectionField) {
          ((DataObjectCollection)oldValue.GetProperty(pairTo.AbsoluteName, culture)).Remove(owner);
          ((DataObjectCollection)newValue.GetProperty(pairTo.AbsoluteName, culture)).Add(owner);
          return;
        }
        throw new InvalidOperationException("Unsupported paired field type.");
      }
      else if (hasPair) {
        Field fN = newValue.Type.GetPairTo(field);
        DataObjectCollectionField cfN = fN as DataObjectCollectionField;
        if (fN!=null && cfN==null)
          throw new InvalidOperationException("Unsupported paired field type.");

        Field fO = oldValue.Type.GetPairTo(field);
        DataObjectCollectionField cfO = fO as DataObjectCollectionField;
        if (fO!=null && cfO==null)
          throw new InvalidOperationException("Unsupported paired field type.");
        
        Validate(newValue);
        DataObjectCollection pcO = null;
        DataObjectCollection pcN = null;
        if (fO!=null) {
          pcO = (DataObjectCollection)oldValue.GetProperty(fO.Name, culture);
          if (!pcO.Contains(owner))
            throw new DataObjectsDotNetException(
              "Internal error: required object wasn't found in paired collection.");
        }
        if (fN!=null)
          pcN = (DataObjectCollection)newValue.GetProperty(fN.Name, culture);

        ContentChanging();
        if (fO!=null) 
          pcO.ContentChanging();
        if (fN!=null) 
          pcN.ContentChanging();

        if (fO!=null) 
          pcO.OnRemove(owner);
        
        oldValue.OnDereferenceEx(owner,field,culture);
        if (fO!=null) 
          owner.OnDereferenceEx(oldValue,fO,culture);

        if (fN!=null) 
          pcN.OnAdd(owner);
        
        newValue.OnReferenceEx(owner,field,culture);
        if (fN!=null) 
          owner.OnReferenceEx(newValue,fN,culture);

        Implementation.SetItem(oldValue.ID, newValue.ID);
        if (fO!=null) 
          pcO.Implementation.Remove(owner.ID);
        if (fN!=null) 
          pcN.Implementation.Add(owner.ID);

        OnSetComplete(oldValue,newValue);
        if (fO!=null) 
          pcO.OnRemoveComplete(owner);
        if (fN!=null) 
          pcN.OnAddComplete(owner);

        ContentChanged();
        if (fO!=null) 
          pcO.ContentChanged();
        if (fN!=null) 
          pcN.ContentChanged();
        return;
      }
      
      Validate(newValue);
      ContentChanging();
      OnSet(oldValue,newValue);
      oldValue.OnDereferenceEx(owner,field,culture);
      newValue.OnReferenceEx(owner,field,culture);
      Implementation.SetItem(oldValue.ID, newValue.ID);
      OnSetComplete(oldValue,newValue);
      ContentChanged();
    }

    /// <summary>
    /// Loads collection from the database.
    /// This method ensures if collection wasn't loaded earlier by
    /// checking the state of collection cache,
    /// and loads a list of object <see cref="DataObject.ID"/>s
    /// contained in the collection, if this is necessary.
    /// </summary>
    [Transactional(TransactionMode.Disabled)]
    public void Load() 
    {
      if (session.IsOfflineMode && InnerIsLoaded())
        return;
      
      // Automatic Transactions support code
      TransactionController tc = session.CreateTransactionController(TransactionMode.TransactionRequired);
    Reprocess:
      try {
        InnerLoad();
        tc.Commit();
      }
      catch (Exception e) {
        if (tc.Rollback(e, true))
          goto Reprocess;
        throw;
      }
    }
    private void InnerLoad() 
    {
      if (InnerIsLoaded())
        return;
      if (PairTo==null)
        Persist();
      else
        session.Persist();
      Implementation.Load();
    }

    /// <summary>
    /// Preloads all objects contained in the collection.
    /// Invoke this method if you're planning to process the
    /// whole collection further.
    /// </summary>
    /// <returns><see cref="SqlQuery"/> instance.</returns>
    [Transactional(TransactionMode.TransactionRequired)]
    public virtual Helpers.StrongReferenceHolder Preload()
    {
      return InnerPreload();
    }
    private Helpers.StrongReferenceHolder InnerPreload()
    {
      EnsureCacheValidity();
      if (owner.State!=DataObjectState.Persistent)
        return null;
      InnerLoad();
      if (session.IsOfflineMode)
        return null;
      if (preLoadTransactionContext!=null && 
          preLoadTransactionContext.State==TransactionContextState.Valid)
        return null;
      long[] ids = GetIDs();
      int cnt = ids.Length;
      int checkCnt = cnt/20;
      if (cnt>0 && checkCnt==0)
        checkCnt = 1;
      bool bItemsLoadad = true;
      for (int i = 0; i<checkCnt; i++) {
        if (session.Cache.GetObjectCachingState(ids[session.random.Next(cnt)])
            !=DataObjectCachingState.Cached) {
          bItemsLoadad = false;
          break;
        }
      }
      if (bItemsLoadad) {
        preLoadTransactionContext = session.transactionContext;
        return null;
      }
      Helpers.StrongReferenceHolder r = session.Preload(ids);
      preLoadTransactionContext = session.transactionContext;
      return r;
//      EnsureCacheValidity();
//      if (owner.State==DataObjectState.Persistent) {
//        if (InnerIsLoaded()) {
//          if (session.Options!=SessionOptions.OnlineMode)
//            return null;
//          if (preLoadTransactionContext!=null && 
//              preLoadTransactionContext.State==TransactionContextState.Valid)
//            return null;
//          long[] ids = GetIDs();
//          if (ids.Length==0) {
//            preLoadTransactionContext = session.transactionContext;
//            return null;
//          }
//          if (session.GetObjectCachingState(ids[session.random.Next(ids.Length)])
//                ==DataObjectCachingState.Cached) {
//            preLoadTransactionContext = session.transactionContext;
//            return null;
//          }
//          Helpers.StrongReferenceHolder r = session.Preload(ids);
//          preLoadTransactionContext = session.transactionContext;
//          return r;
//        }
//        Persist();
//        SqlQuery q = new SqlQuery(session, ItemType);
//        RestrictQuery(q);
//        ArrayList queryResultData = q.InternalExecute(false) as ArrayList;
//        Implementation.Load(queryResultData);
//        preLoadTransactionContext = session.transactionContext;
//        return q.ConvertQueryResultDataToStrongReferenceHolder(queryResultData);
//      }
//      else
//        return null;
    }

    internal void Preload(ArrayList dbItems, int startIndex, int count) 
    {
      EnsureCacheValidity();
      if (PairTo==null)
        Persist();
      else
        session.Persist();
      Implementation.Load(dbItems, startIndex, count);
    }
    
    internal void Preload(long[] itemIds, int count) 
    {
      EnsureCacheValidity();
      if (PairTo==null)
        Persist();
      else
        session.Persist();
      Implementation.Load(itemIds, count);
    }
    
    /// <summary>
    /// Gets the number of elements contained in the collection.
    /// </summary>
    [Transactional(TransactionMode.Disabled)]
    public int Count {
      get {
        if (session.IsOfflineMode) {
          Load();
          return InnerGetCount();
        }
        
        // Automatic Transactions support code
        TransactionController tc = session.CreateTransactionController(TransactionMode.TransactionRequired);
      Reprocess:
        try {
          int r = InnerGetCount();
          tc.Commit();
          return r;
        }
        catch (Exception e) {
          if (tc.Rollback(e, true))
            goto Reprocess;
          throw;
        }
      }
    }
    private int InnerGetCount()
    {
      EnsureCacheValidity();
      return Implementation.Count;
    }
    
    /// <summary>
    /// Adds a new value to this collection. If element with the same
    /// name is already exists in this collection, <see cref="InvalidOperationException"/>
    /// will be thrown.
    /// </summary>
    /// <param name="value">DataObject to add.</param>
    [Transactional(TransactionMode.Disabled)]
    public int Add(DataObject value)
    {
      return List.Add(value);
    }
    
    /// <summary>
    /// <para>Copies the elements of an array to the end of the <see cref='QueryResult'/>.</para>
    /// </summary>
    /// <param name='value'>
    ///   An array of type <see cref='DataObject'/> containing the objects to add to the collection.
    /// </param>
    /// <returns>
    ///   <para>None.</para>
    /// </returns>
    /// <seealso cref='QueryResult.Add'/>
    [Transactional(TransactionMode.TransactionRequired)]
    public virtual void AddRange(DataObject[] value) 
    {
      InnerAddRange(value);
    }
    private void InnerAddRange(DataObject[] value) 
    {
      EnsureCacheValidity();
      for (int i = 0; (i < value.Length); i = (i + 1))
        List.Add(value[i]);
    }

    /// <summary>
    ///   <para>
    ///     Adds the contents of <see cref='QueryResult'/> to the end of the collection.
    ///  </para>
    /// </summary>
    /// <param name='value'>
    ///    A <see cref='QueryResult'/> containing the objects to add to the collection.
    /// </param>
    /// <returns>
    ///   <para>None.</para>
    /// </returns>
    /// <seealso cref='QueryResult.Add'/>
    [Transactional(TransactionMode.Disabled)]
    public void AddRange(QueryResult value) 
    {
      if (session!=value.session)
        throw new InvalidOperationException("Collections belongs to different sessions.");

      // Automatic Transactions support code
      TransactionController tc = session.CreateTransactionController(TransactionMode.TransactionRequired);
    Reprocess:
      try {
        InnerAddRange(value);
        tc.Commit();
      }
      catch (Exception e) {
        if (tc.Rollback(e, true))
          goto Reprocess;
        throw;
      }
    }
    private void InnerAddRange(QueryResult value)
    {
      EnsureCacheValidity();
      foreach (DataObject o in value)
        List.Add(o);
    }

    /// <summary>
    /// Determines, if this collection contains specified value.
    /// </summary>
    /// <param name="value">DataObject to search for.</param>
    /// <returns><see langword="True"/> if value was found.</returns>
    [Transactional(TransactionMode.Disabled)]
    public bool Contains(DataObject value)
    {
      return List.Contains(value);
    }

    /// <summary>
    /// Copies elements of this collection to <see cref="Array"/>.
    /// </summary>
    /// <param name="values">Destination array.</param>
    /// <param name="offset">Offset in array to start from.</param>
    [Transactional(TransactionMode.Disabled)]
    public void CopyTo(DataObject[] values, int offset)
    {
      List.CopyTo(values, offset);
    }

    /// <summary>
    /// Searches for the specified value and returns the index of the first occurrence within the current instance.
    /// </summary>
    /// <param name="value">The value to locate.</param>
    /// <returns>The index of the first occurrence of value within the entire collection, if found; otherwise, -1.</returns>
    [Transactional(TransactionMode.Disabled)]
    public int IndexOf(DataObject value)
    {
      return List.IndexOf(value);
    }

    /// <summary>
    /// Inserts value to collection.
    /// </summary>
    /// <param name="offset">Offset of value.</param>
    /// <param name="value">DataObject to insert.</param>
    [Transactional(TransactionMode.Disabled)]
    public void Insert(int offset, DataObject value)
    {
      List.Insert(offset, value);
    }

    /// <summary>
    /// Removes value from collection.
    /// </summary>
    /// <param name="value">DataObject to remove.</param>
    [Transactional(TransactionMode.Disabled)]
    public void Remove(DataObject value)
    {
      List.Remove(value);
    }
    
    // Collection interfaces support
    
    /// <summary>
    /// Gets an <see cref="IList"/> containing the list of elements in the 
    /// collection instance.
    /// </summary>
    [Transactional(TransactionMode.Disabled)]
    protected IList List {
      get {
        return this;
      }
    }
    
    /// <summary>
    /// Removes all objects from the collection instance.
    /// </summary>
    [Transactional(TransactionMode.TransactionRequired)]
    public virtual void Clear() 
    {
      InnerClear();
    }
    private void InnerClear() 
    {
      if (owner.State==DataObjectState.New)
        return;

      // GetIDs() loads collection content from a RDBMS
      // and consequently we need no to do this explicitly here
      long[] ids = GetIDs();
      int l = ids.Length;

      // Collection is empty
      if (l==0) {
        OnClear();
        OnClearComplete();
        return;
      }
      
      ContentChanging();
      OnClear();

      blockContentChangeEvent++;
      bool success = true;
      try {
        if (pairTo!=null) {
          if (pairTo is ReferenceField) {
            for (int index = 0; index<l; index++) {
              DataObject o = session[ids[index]];
              if (o!=null)
                o.SetProperty(pairTo.AbsoluteName, culture, null, true, true, true);
            }
            Implementation.Clear();
            return;
          }
          if (pairTo is DataObjectCollectionField) {
            for (int index = 0; index<l; index++) {
              DataObject o = session[ids[index]];
              if (o!=null)
                ((DataObjectCollection)o.GetProperty(pairTo.AbsoluteName, culture)).Remove(owner);
            }
            Implementation.Clear();
            return;
          }
          throw new InvalidOperationException("Unsupported paired field type.");
        }

        for (int index = 0; index<l; index++) {
          DataObject o = session[ids[index]];
          if (o!=null) {
            if (hasPair) {
              Field f = o.Type.GetPairTo(field);
              if (f==null) {
                OnRemove(o);
                o.OnDereferenceEx(owner,field,culture);
                continue;
              }
              if (f is DataObjectCollectionField) {
                // Paired collection
                DataObjectCollection pc = (DataObjectCollection)o.GetProperty(f.Name, culture);
                if (!pc.Contains(owner))
                  throw new DataObjectsDotNetException(
                    "Internal error: required object wasn't found in paired collection.");
                OnRemove(o);
                pc.OnRemove(owner);
                o.OnDereferenceEx(owner,field,culture);
                owner.OnDereferenceEx(o,f,culture);
                continue;
              }
              throw new InvalidOperationException("Unsupported paired field type.");
            }
            else if (symmetric && o!=owner) {
              Field f = field;
              DataObjectCollection pc = (DataObjectCollection)o.GetProperty(f.Name, culture);
              if (!pc.Contains(owner))
                throw new DataObjectsDotNetException(
                  "Internal error: required object wasn't found in paired collection.");
              OnRemove(o);
              pc.OnRemove(owner);
              o.OnDereferenceEx(owner,field,culture);
              owner.OnDereferenceEx(o,f,culture);
              continue;
            }
            OnRemove(o);
            o.OnDereferenceEx(owner,field,culture);
          }
        }

        for (int index = 0; index<l; index++) {
          DataObject o = session[ids[index]];
          if (o!=null) {
            if (hasPair) {
              Field f = o.Type.GetPairTo(field);
              if (f==null)
                continue;
              if (f is DataObjectCollectionField) {
                // Paired collection
                DataObjectCollection pc = (DataObjectCollection)o.GetProperty(f.Name, culture);
                pc.Implementation.Remove(owner.ID);
                continue;
              }
              throw new InvalidOperationException("Unsupported paired field type.");
            }
            else if (symmetric && o!=owner) {
              Field f = field;
              DataObjectCollection pc = (DataObjectCollection)o.GetProperty(f.Name, culture);
              pc.Implementation.Remove(owner.ID);
              pc.implementation.Persist();
              continue;
            }
          }
        }

        if (Count!=0)
          Implementation.Clear();

        for (int index = 0; index<l; index++) {
          DataObject o = session[ids[index]];
          if (o!=null) {
            if (hasPair) {
              Field f = o.Type.GetPairTo(field);
              if (f==null) {
                OnRemoveComplete(o);
                continue;
              }
              if (f is DataObjectCollectionField) {
                // Paired collection
                DataObjectCollection pc = (DataObjectCollection)o.GetProperty(f.Name, culture);
                OnRemoveComplete(o);
                pc.OnRemoveComplete(owner);
                continue;
              }
              throw new InvalidOperationException("Unsupported paired field type.");
            }
            else if (symmetric && o!=owner) {
              Field f = field;
              DataObjectCollection pc = (DataObjectCollection)o.GetProperty(f.Name, culture);
              OnRemoveComplete(o);
              pc.OnRemoveComplete(owner);
              continue;
            }
            OnRemoveComplete(o);
          }
        }
      }
      catch {
        success = false;
        throw;
      }
      finally {
        blockContentChangeEvent--;
        if (success) {
          OnClearComplete();
          ContentChanged();
        }
      }
    }
    
    /// <summary>
    /// Removes all items contained in the collection and clears the collection.
    /// </summary>
    /// <param name="withRemove"><see langword="True"/> if <see cref="DataObject.Remove"/> method should be
    /// invoked for each contained item.</param>
    [Transactional(TransactionMode.TransactionRequired)]
    public virtual void Clear(bool withRemove)
    {
      InnerClear(withRemove);
    }
    private void InnerClear(bool withRemove)
    {
      EnsureCacheValidity();
      if (owner.State==DataObjectState.New)
        owner.Persist();

      if (!withRemove) {
        InnerClear();
        return;
      }

      long[] ids = GetIDs();
      InnerClear();
      foreach (long id in ids) {
        DataObject o = session[id];
        if (o!=null && !o.IsRemoving)
          o.Remove();
      }
    }
    
    /// <summary>
    /// Returns array with contained instance IDs.
    /// </summary>
    /// <returns>Array with contained instance IDs.</returns>
    [Transactional(TransactionMode.TransactionRequired)]
    public virtual long[] GetIDs() 
    {
      return InnerGetIDs();
    }
    private long[] InnerGetIDs() 
    {
      InnerLoad();
      return Implementation.GetContainedItems();
    }
    
    /// <summary>
    /// Returns an enumerator that can iterate through the
    /// collection instance.
    /// </summary>
    /// <returns>
    /// An <see cref="IEnumerator"/> for the 
    /// collection instance.
    /// </returns>
    [Transactional(TransactionMode.Disabled)]
    public IEnumerator GetEnumerator()
    {
      Load();
      return Implementation.GetEnumerator();
    }
    
    /// <summary>
    /// Removes the element at the specified index of the
    /// collection instance.
    /// </summary>
    /// <param name="index">The zero-based index of the element to remove.</param>
    [Transactional(TransactionMode.TransactionRequired)]
    public virtual void RemoveAt(int index)
    {
      InnerRemoveAt(index);
    }
    private void InnerRemoveAt(int index)
    {
      if (owner.State==DataObjectState.New)
        owner.Persist();

      InnerLoad();
      InnerRemove(List[index]);
    }
    
    // ICollection methods Implementation

    /// <summary>
    /// Copies the elements of the collection to an Array, 
    /// starting at a particular Array index.
    /// </summary>
    /// <param name="array">The one-dimensional Array that is the destination of the elements copied from collection. The Array must have zero-based indexing.</param>
    /// <param name="index">The zero-based index in array at which copying begins.</param>
    void ICollection.CopyTo(Array array, int index)
    {
      // Automatic Transactions support code
      TransactionController tc = session.CreateTransactionController(TransactionMode.TransactionRequired);
    Reprocess:
      try {
        InnerCopyTo(array, index);
        tc.Commit();
      }
      catch (Exception e) {
        if (tc.Rollback(e, true))
          goto Reprocess;
        throw;
      }
    }
    private void InnerCopyTo(Array array, int index)
    {
      if (owner.State==DataObjectState.New)
        return;

      InnerLoad();
      int i = index;
      foreach (DataObject o in List)
        array.SetValue(o, i++);
    }
    
    /// <summary>
    /// Gets a value indicating whether access to the 
    /// collection is synchronized (thread-safe).
    /// </summary>
    /// <returns><see langword="True"/> if access to the collection is synchronized (thread-safe); otherwise, <see langword="false"/>.</returns>
    bool ICollection.IsSynchronized {
      get {
        return false;
      }
    }
    
    /// <summary>
    /// Gets an object that can be used to synchronize access to the collection.
    /// </summary>
    /// <returns>An object that can be used to synchronize access to the collection.</returns>
    object ICollection.SyncRoot {
      get {
        return this;
      }
    }
    
    // IList methods Implementation

    /// <summary>
    /// Gets a value indicating whether the <see cref="IList"/> has a fixed size.
    /// </summary>
    /// <returns><see langword="True"/> if the <see cref="IList"/> has a fixed size; otherwise, <see langword="false"/>.</returns>
    bool IList.IsFixedSize {
      get {
        return false;
      }
    }
    
    /// <summary>
    /// Gets a value indicating whether the <see cref="IList"/> is read-only.
    /// </summary>
    /// <returns><see langword="True"/> if the <see cref="IList"/> is read-only; otherwise, <see langword="false"/>.</returns>
    bool IList.IsReadOnly {
      get {
        return false;
      }
    }
    
    /// <summary>
    /// Gets or sets the element at the specified index.
    /// </summary>
    /// <param name="index">The zero-based index of the element to get or set.</param>
    /// <returns>The element at the specified index.</returns>
    object IList.this[int index] {
      get {
        if (session.IsOfflineMode) {
          Load();
          return InnerGet(index);
        }

        // Automatic Transactions support code
        TransactionController tc = session.CreateTransactionController(TransactionMode.TransactionRequired);
      Reprocess:
        try {
          object r = InnerGet(index);
          tc.Commit();
          return r;
        }
        catch (Exception e) {
          if (tc.Rollback(e, true))
            goto Reprocess;
          throw;
        }
      }
      set {
        // Automatic Transactions support code
        TransactionController tc = session.CreateTransactionController( TransactionMode.TransactionRequired);
      Reprocess:
        try {
          InnerSet(index, value);
          tc.Commit();
        }
        catch (Exception e) {
          if (tc.Rollback(e, true))
            goto Reprocess;
          throw;
        }
      }
    }
    private object InnerGet(int index)
    {
      InnerLoad();
      return session[Implementation.GetItem(index)];
    }
    private void InnerSet(int index, object value)
    {
      if (symmetric)
        throw new InvalidOperationException("Can's use this[index]=value construction for symmetric property.");
      if (owner.State==DataObjectState.New)
        owner.Persist();

      InnerLoad();
      DataObject oldValue = session[Implementation.GetItem(index)];
      InnerSet(oldValue, (DataObject)value);
    }
    
    /// <summary>
    /// Adds new element to the collection.
    /// </summary>
    /// <param name="value">Item to add.</param>
    /// <returns>Index of newly added item.</returns>
    int  IList.Add(object value) 
    {
      // Automatic Transactions support code
      TransactionController tc = session.CreateTransactionController(TransactionMode.TransactionRequired);
    Reprocess:
      try {
        int r = InnerAdd(value);
        tc.Commit();
        return r;
      }
      catch (Exception e) {
        if (tc.Rollback(e, true))
          goto Reprocess;
        throw;
      }
    }
    private int InnerAdd(object value) 
    {
      EnsureCacheValidity();
      if (owner.State==DataObjectState.New)
        owner.Persist();
      if (value==null)
        throw new ArgumentNullException("value");
      ValidateArgument(value);

      DataObject newValue = (DataObject)value;
      if (pairTo!=null) {
        if (pairTo is ReferenceField) {
          newValue.SetProperty(pairTo.AbsoluteName, culture, owner, true, true, true);
          if (IsLoaded)
            return IndexOf(newValue);
          else
            return -1;
        }
        if (pairTo is DataObjectCollectionField) {
          ((DataObjectCollection)newValue.GetProperty(pairTo.AbsoluteName, culture)).Add(owner);
          if (IsLoaded)
            return IndexOf(newValue);
          else
            return -1;
        }
        throw new InvalidOperationException("Unsupported paired field type.");
      }
      else if (hasPair) {
        Field f = newValue.Type.GetPairTo(field);
        if (f==null)
          goto Std;
        if (f is DataObjectCollectionField) {
          // Paired collection
          Validate(newValue);
          DataObjectCollection pc = (DataObjectCollection)newValue.GetProperty(f.Name, culture);

          ContentChanging();
          pc.ContentChanging();

          OnAdd(newValue);
          pc.OnAdd(newValue);

          newValue.OnReferenceEx(owner,field,culture);
          owner.OnReferenceEx(newValue,f,culture);

          int r = Implementation.Add(newValue.ID);
          pc.Implementation.Add(owner.ID);

          OnAddComplete(newValue);
          pc.OnAddComplete(owner);

          ContentChanged();
          pc.ContentChanged();
          return r;
        }
        throw new InvalidOperationException("Unsupported paired field type.");
      }
      else if (symmetric && owner!=newValue) {
        Field f = field;
        Validate(newValue);
        DataObjectCollection pc = (DataObjectCollection)newValue.GetProperty(f.Name, culture);

        ContentChanging();
        pc.ContentChanging();

        OnAdd(newValue);
        pc.OnAdd(newValue);

        newValue.OnReferenceEx(owner,field,culture);
        owner.OnReferenceEx(newValue,f,culture);

        int r = Implementation.Add(newValue.ID);
        pc.Implementation.Add(owner.ID);

        OnAddComplete(newValue);
        pc.OnAddComplete(owner);

        ContentChanged();
        pc.ContentChanged();
        return r;
      }

      Std:
      Validate(newValue);
      ContentChanging();
      OnAdd(newValue);
      newValue.OnReferenceEx(owner,field,culture);
      int r1 = Implementation.Add(newValue.ID);
      OnAddComplete(newValue);
      ContentChanged();
      return r1;
    }
    internal void InnerAddPairedObject(DataObject dataObject)
    {
      EnsureCacheValidity();
      implementation.Add(dataObject.ID);
    }
    
    /// <summary>
    /// Determines whether collection contains a specific value.
    /// </summary>
    /// <param name="value">Value to search for.</param>
    /// <returns><see langword="True"/> if the object is found; otherwise, <see langword="false"/>.</returns>
    bool IList.Contains(object value) 
    {
      if (session.IsOfflineMode) {
        Load();
        return InnerContains(value);
      }

      // Automatic Transactions support code
      TransactionController tc = session.CreateTransactionController(TransactionMode.TransactionRequired);
    Reprocess:
      try {
        bool r = InnerContains(value);
        tc.Commit();
        return r;
      }
      catch (Exception e) {
        if (tc.Rollback(e, true))
          goto Reprocess;
        throw;
      }
    }
    private bool InnerContains(object value) 
    {
      EnsureCacheValidity();
      if (value==null)
        throw new ArgumentNullException("value");
      ValidateArgument(value);
      DataObject dObj = (DataObject)value;
      return Implementation.Contains(dObj.ID);
    }

    /// <summary>
    /// Searches for the specified value and returns the index of the first occurrence within the current instance.
    /// </summary>
    /// <param name="value">The value to locate.</param>
    /// <returns>The index of the first occurrence of value within the entire collection, if found; otherwise, -1.</returns>
    int  IList.IndexOf(object value)
    {
      if (session.IsOfflineMode) {
        Load();
        return InnerIndexOf(value);
      }

      // Automatic Transactions support code
      TransactionController tc = session.CreateTransactionController(TransactionMode.TransactionRequired);
    Reprocess:
      try {
        int r = InnerIndexOf(value);
        tc.Commit();
        return r;
      }
      catch (Exception e) {
        if (tc.Rollback(e, true))
          goto Reprocess;
        throw;
      }
    }
    private int InnerIndexOf(object value)
    {
      if (value==null)
        throw new ArgumentNullException("value");
      ValidateArgument(value);

      InnerLoad();
      DataObject dObj = (DataObject)value;
      return Implementation.IndexOf(dObj.ID);
    }
    
    /// <summary>
    /// Inserts an element to the collection.
    /// </summary>
    /// <param name="index">The zero-based index at which value should be inserted.</param>
    /// <param name="value">Item to insert.</param>
    void IList.Insert(int index, object value)
    {
      throw new InvalidOperationException(
        "Insert method can't be used with DataObjectCollection, use Add instead.");
    }
    
    /// <summary>
    /// Removes element from the the collection.
    /// </summary>
    /// <param name="value">Item to remove.</param>
    void IList.Remove(object value)
    {
      // Automatic Transactions support code
      TransactionController tc = session.CreateTransactionController(TransactionMode.TransactionRequired);
    Reprocess:
      try {
        InnerRemove(value);
        tc.Commit();
      }
      catch (Exception e) {
        if (tc.Rollback(e, true))
          goto Reprocess;
        throw;
      }
    }
    private void InnerRemove(object value)
    {
      EnsureCacheValidity();
      if (value==null)
        throw new ArgumentNullException("value");
      ValidateArgument(value);

      DataObject o = (DataObject)value;
      if (!Implementation.Contains(o.ID))
        throw new ArgumentException("Argument wasn't found.");

      if (pairTo!=null) {
        if (pairTo is ReferenceField) {
          o.SetProperty(pairTo.AbsoluteName, culture, null, true, true, true);
          return;
        }
        if (pairTo is DataObjectCollectionField) {
          ((DataObjectCollection)o.GetProperty(pairTo.AbsoluteName, culture)).Remove(owner);
          return;
        }
        throw new InvalidOperationException("Unsupported paired field type.");
      }
      else if (hasPair) {
        Field f = o.Type.GetPairTo(field);
        if (f==null)
          goto Std;
        if (f is DataObjectCollectionField) {
          // We have paired collection
          DataObjectCollection pc = (DataObjectCollection)o.GetProperty(f.Name, culture);
          if (!pc.Contains(owner))
            throw new DataObjectsDotNetException(
              "Internal error: required object wasn't found in paired collection.");

          ContentChanging();
          pc.ContentChanging();

          OnRemove(o);
          pc.OnRemove(owner);

          o.OnDereferenceEx(owner,field,culture);
          owner.OnDereferenceEx(o,f,culture);

          Implementation.Remove(o.ID);
          pc.Implementation.Remove(owner.ID);

          OnRemoveComplete(o);
          pc.OnRemoveComplete(owner);

          ContentChanged();
          pc.ContentChanged();
          return;
        }
        throw new InvalidOperationException("Unsupported paired field type.");
      }
      else if (symmetric && owner!=o) {
        Field f = field;
        DataObjectCollection pc = (DataObjectCollection)o.GetProperty(f.Name, culture);
        if (!pc.Contains(owner))
          throw new DataObjectsDotNetException(
            "Internal error: required object wasn't found in paired collection.");

        ContentChanging();
        pc.ContentChanging();

        OnRemove(o);
        pc.OnRemove(owner);

        o.OnDereferenceEx(owner,field,culture);
        owner.OnDereferenceEx(o,f,culture);

        Implementation.Remove(o.ID);
        pc.Implementation.Remove(owner.ID);

        OnRemoveComplete(o);
        pc.OnRemoveComplete(owner);

        ContentChanged();
        pc.ContentChanged();
        return;
      }
      
      Std:
      ContentChanging();
      OnRemove(o);
      o.OnDereferenceEx(owner,field,culture);
      Implementation.Remove(o.ID);
      OnRemoveComplete(o);  
      ContentChanged();
    }
    internal void InnerRemovePairedObject(DataObject dataObject)
    {
      EnsureCacheValidity();
      implementation.Remove(dataObject.ID);
    }
    
    // Validation

    /// <summary>
    /// Validates a value.
    /// </summary>
    /// <param name="value">The instance to validate.</param>
    [Transactional(TransactionMode.Disabled)]
    protected void Validate(DataObject value)
    {
      if (value==null)
        throw new ArgumentNullException("value");
      if (itemType!=null)
        if (!itemType.IsInstanceOfType(value))
          throw new InvalidOperationException("Validation failed: invalid item type.");
      if (value.session!=session)
        throw new InvalidOperationException("Validation failed: instance belongs to different session.");
      if (value==owner && !selfRefAllowed)
        throw new SelfReferenceException(owner);
      if (value.State==DataObjectState.Removed)
        throw new InstanceIsRemovedException();
      if (value.State==DataObjectState.New)
        value.Persist();
      OnValidate(value);
    }
    
    /// <summary>
    /// Validates an argument.
    /// </summary>
    /// <param name="value">The instance to validate.</param>
    private void ValidateArgument(object value)
    {
      if (value==null)
        return;
      if (itemType!=null)
        if (!itemType.IsInstanceOfType(value))
          throw new InvalidOperationException("Validation failed: invalid item type.");
      DataObject dObj = value as DataObject;
      if (dObj.session!=session)
        throw new InvalidOperationException("Validation failed: instance belongs to different session.");
      if (dObj.State==DataObjectState.Removed)
        throw new InstanceIsRemovedException();
      if (dObj.State==DataObjectState.New)
        dObj.Persist();
    }
    
    /// <summary>
    /// Converts <see cref="DataObjectCollection"/> instance to its offline analogue.
    /// </summary>
    object IConvertibleToOffline.ToOffline()
    {
      return this.ToOffline();
    }
    
    /// <summary>
    /// Converts <see cref="DataObjectCollection"/> instance to its offline analogue.
    /// </summary>
    [Transactional(TransactionMode.Disabled)]
    public Offline.DataObjectCollection ToOffline()
    {
      return this.ToOffline(new FillDescriptor());
    }

    /// <summary>
    /// Converts <see cref="DataObjectCollection"/> instance to its offline analogue.
    /// </summary>
    /// <param name="fillExpression">Fill expression (textual
    /// <see cref="Offline.FillDescriptor"/> definition) describing 
    /// desired way of conversion.</param>
    [Transactional(TransactionMode.Disabled)]
    public Offline.DataObjectCollection ToOffline(string fillExpression)
    {
      return this.ToOffline(new FillDescriptor(Domain.ObjectModel, fillExpression));
    }

    /// <summary>
    /// Converts <see cref="DataObjectCollection"/> instance to its offline analogue.
    /// </summary>
    /// <param name="fillDescriptor"><see cref="Offline.FillDescriptor"/> 
    /// desired way of conversion.</param>
    [Transactional(TransactionMode.Disabled)]
    public Offline.DataObjectCollection ToOffline(FillDescriptor fillDescriptor)
    {
      TypeFillDescriptor  tfd = fillDescriptor.TypeFillDescriptors[owner.type];
      FieldFillDescriptor ffd = tfd==null ? null : tfd.FieldFillDescriptors[field];
      if (ffd==null || !ffd.Load)
        fillDescriptor = (FillDescriptor) fillDescriptor.Clone();
      if (ffd==null) {
        if (tfd==null || tfd.Name!=owner.Type.Name) {
          TypeFillDescriptor tfdNew = new TypeFillDescriptor(owner.Type);
          if (tfd!=null)
            tfdNew.CopyPropertiesFrom(tfd);
          tfd = tfdNew;
          fillDescriptor.TypeFillDescriptors.Add(tfd);
        }
        ffd = tfd.FieldFillDescriptors[field];
        ffd.Load = true;
      }
      else if (!ffd.Load) {
        ffd = tfd.FieldFillDescriptors[field];
        ffd.Load = true;
      }
      
      Offline.Internals.ObjectSetProvider osProvider = 
        (Offline.Internals.ObjectSetProvider)Session.GetService(typeof(Offline.Internals.ObjectSetProvider));
      Offline.QueryResult qr = osProvider.CreateObjectSet(new long[] {owner.ID}, fillDescriptor);
      return (Offline.DataObjectCollection)qr.ObjectSet[owner.ID].GetProperty(field.Name, culture==null ? null : qr.ObjectSet.Cultures[culture.Index]);
    }

    // Events

    /// <summary>
    /// Performs additional custom processes when changing the contents of the 
    /// collection instance.
    /// </summary>
    [Transactional(TransactionMode.Disabled)]
    protected virtual void OnChange()
    {
    }
    
    /// <summary>
    /// Performs additional custom processes after the contents of the 
    /// collection instance was changed.
    /// </summary>
    [Transactional(TransactionMode.Disabled)]
    protected virtual void OnChangeComplete()
    {
    }
    
    /// <summary>
    /// Performs additional custom processes when clearing the contents of the 
    /// collection instance.
    /// </summary>
    [Transactional(TransactionMode.Disabled)]
    protected virtual void OnClear()
    {
    }
    
    /// <summary>
    /// Performs additional custom processes after clearing the contents of the 
    /// collection instance.
    /// </summary>
    [Transactional(TransactionMode.Disabled)]
    protected virtual void OnClearComplete()
    {
    }
    
    /// <summary>
    /// Performs additional custom processes before adding a new element into the
    /// collection instance.
    /// </summary>
    /// <param name="value">Value to add.</param>
    [Transactional(TransactionMode.Disabled)]
    protected internal virtual void OnAdd(DataObject value) 
    {
    }
    
    /// <summary>
    /// Performs additional custom processes after adding a new element into the
    /// collection instance.
    /// </summary>
    /// <param name="value">Newly added element.</param>
    [Transactional(TransactionMode.Disabled)]
    protected internal virtual void OnAddComplete(DataObject value) 
    {
    }
    
    /// <summary>
    /// Performs additional custom processes before removing the element from the
    /// collection instance.
    /// </summary>
    /// <param name="value">Value to remove.</param>
    [Transactional(TransactionMode.Disabled)]
    protected internal virtual void OnRemove(DataObject value) 
    {
    }
    
    /// <summary>
    /// Performs additional custom processes after removing the element from the
    /// collection instance.
    /// </summary>
    /// <param name="value">Removed element.</param>
    [Transactional(TransactionMode.Disabled)]
    protected internal virtual void OnRemoveComplete(DataObject value) 
    {
    }
    
    /// <summary>
    /// Performs additional custom processes before setting a value in the
    /// collection instance.
    /// </summary>
    /// <param name="oldValue">The value to replace with <paramref name="newValue"/>.</param>
    /// <param name="newValue">The new value.</param>
    [Transactional(TransactionMode.Disabled)]
    protected virtual void OnSet(DataObject oldValue, DataObject newValue)
    {
    }
    
    /// <summary>
    /// Performs additional custom processes after setting a value in the
    /// collection instance.
    /// </summary>
    /// <param name="oldValue">The value to replace with <paramref name="newValue"/>.</param>
    /// <param name="newValue">The new value.</param>
    [Transactional(TransactionMode.Disabled)]
    protected virtual void OnSetComplete(DataObject oldValue, DataObject newValue)
    {
    }
    
    /// <summary>
    /// Performs additional custom processes when validating a value.
    /// </summary>
    /// <param name="value">The object to validate.</param>
    /// <remarks>
    /// The default Implementation of this method determines whether value is a <see langword="null"/> 
    /// reference (Nothing in Visual Basic), and, if so, throws <see cref="ArgumentNullException"/>. 
    /// It is intended to be overridden by a derived class to perform additional action 
    /// when the specified element is validated.
    /// </remarks>
    [Transactional(TransactionMode.Disabled)]
    protected virtual void OnValidate(DataObject value)
    {
    }
    
    /// <summary>
    /// Called on attachment to <see cref="DataObject"/>.
    /// </summary>
    [Transactional(TransactionMode.Disabled)]
    protected virtual void OnAttach()
    {
    }

    /// <summary>
    /// Called on recycle of this instance.
    /// </summary>
    /// <returns><see langword="True"/> if the instance was recycled 
    /// and can be reused; otherwise, <see langword="false"/>.</returns>
    [Transactional(TransactionMode.Disabled)]
    protected virtual bool OnRecycle()
    {
      return true;
    }
    
    // Query-related methods
    
    /// <summary>
    /// Creates <see cref="Query"/> instance configured to query
    /// the items that belongs to this collection.
    /// </summary>
    /// <returns><see cref="Query"/> instance.</returns>
    [Transactional(TransactionMode.Disabled)]
    public Query CreateQuery()
    {
      Query q = new Query(session);
      RestrictQuery(q);
      return q;
    }
    
    /// <summary>
    /// Creates <see cref="Query"/> instance configured to query
    /// the items that belongs to this collection.
    /// </summary>
    /// <param name="text">Query text (see <see cref="Query.Text"/> property description).</param>
    /// <returns><see cref="Query"/> instance.</returns>
    [Transactional(TransactionMode.Disabled)]
    public Query CreateQuery(string text)
    {
      Query q = new Query(session,text);
      RestrictQuery(q);
      return q;
    }
    
    /// <summary>
    /// Creates <see cref="SqlQuery"/> instance configured to query
    /// the items that belongs to this collection.
    /// </summary>
    /// <returns><see cref="SqlQuery"/> instance.</returns>
    [Transactional(TransactionMode.Disabled)]
    public SqlQuery CreateSqlQuery()
    {
      SqlQuery q = new SqlQuery(session, ItemType);
      RestrictQuery(q);
      return q;
    }

    /// <summary>
    /// Restricts query range to the elements of this collection.
    /// </summary>
    /// <param name="query">Query to restrict.</param>
    [Transactional(TransactionMode.Disabled)]
    private void RestrictQuery(QueryBase query)
    {
      Implementation.RestrictQuery(query);
    }
    
    // ToString implementation
    
    /// <summary>
    /// Returns <see cref="String"/> representation of current collection.
    /// </summary>
    /// <returns>The <see cref="String"/> representation of this collection.</returns>
    /// <remarks>
    /// This method returns <see cref="String"/> in the following format:
    /// "OwnerID=[OwnerID], PropertyName=[PropertyName]".
    /// </remarks>
    [Transactional(TransactionMode.Disabled)]
    public override string ToString()
    {
      return ToDebugString();
    }
    
    /// <summary>
    /// Returns debug <see cref="String"/> of current collection that is used for trace.
    /// </summary>
    /// <returns>Debug <see cref="String"/> of current collection.</returns>
    [Transactional(TransactionMode.Disabled)]
    protected internal virtual string ToDebugString()
    {
      return "OwnerID=" + Owner.GetInternalID() +
             ", PropertyName=" + Field.Name;
    }
    
    // Constructor

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="itemType">Type of collection items.</param>
    public DataObjectCollection(System.Type itemType): base()
    {
      if (!(itemType==typeof(DataObject) || 
            itemType.IsSubclassOf(typeof(DataObject)) || (
            itemType.IsInterface && typeof(IDataObject).IsAssignableFrom(itemType))))
        throw new ObjectModelBuilderException(
          String.Format("Illegal ItemType value: \"{0}\".",itemType)
          );
      this.itemType = itemType;
    }
  }
}
