// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;
using DataObjects.NET.Remoting.ArgumentContainers;

namespace DataObjects.NET.Remoting
{
  /// <summary>
  /// Converts parameter values to the <see cref="ArgumentContainer"/> instances.
  /// </summary>
  public class ArgumentConverter
  {
    private static Hashtable processedObjects = new Hashtable();
    private static int stackSize = 0;
    
    /// <summary>
    /// Converts parameter values to the <see cref="ArgumentContainer"/> instances.
    /// </summary>
    public static ArgumentContainer Convert(object obj)
    {
      lock (processedObjects) {
        try {
          stackSize++;
          ArgumentContainer container = obj as ArgumentContainer;
          if (container!=null)
            return container;
          object key = (obj==null ? processedObjects : obj);
          if (obj!=null && processedObjects.Contains(key))
            return (ArgumentContainer)processedObjects[key];
          if (obj==null)
            container = new PrimitiveArgumentContainer();
          else {
            IArgumentContainerSource argumentSource = obj as IArgumentContainerSource;
            if (argumentSource!=null)
              container = argumentSource.CreateParameter();
            if (obj is Session)
              container = new ContextSessionArgumentContainer();
            if (obj is Domain)
              container = new ContextDomainArgumentContainer();
            if (container==null && obj!=null) {
              System.Type objType = obj.GetType();
              if (objType==typeof(String) || (objType.IsValueType && objType.IsPrimitive))
                container = new PrimitiveArgumentContainer();
              else if (objType.IsArray)
                container = new ArrayArgumentContainer();
              else
                container = new ObjectArgumentContainer();
            }
          }
          processedObjects[key] = container;
          container.SetValue(obj);
          return container;
        }
        finally {
          stackSize--;
          if (stackSize==0)
            processedObjects.Clear();
        }
      }
    }
  }
}
