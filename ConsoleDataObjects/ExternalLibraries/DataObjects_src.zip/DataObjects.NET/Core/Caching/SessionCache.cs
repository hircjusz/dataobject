// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;
using System.Collections.Specialized;
using System.Threading;

using DataObjects.NET;
using DataObjects.NET.Attributes;
using DataObjects.NET.Database;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Helpers;

namespace DataObjects.NET.Caching 
{
  /// <summary>
  /// Local (<see cref="Session"/>-level) cache implementation.
  /// </summary>
  public class SessionCache: SessionBoundObject
  {
    private  const int cMaxLostObjectsCount = 100;

    private  GlobalCache realGlobalCache;
    private  int         lostObjectsCount = 0;
    private  Hashtable   innerCache = new Hashtable();
    
    /// <summary>
    /// Gets <see cref="Caching.GlobalCache"/> instance that
    /// is currently used by <see cref="SessionCache"/>.
    /// Can be either <see cref="Domain.GlobalCache"/> or
    /// <see cref="Caching.GlobalCache.AlwaysEmptyCache"/>
    /// (last is used in <see cref="Session.BrowsePast"/>
    /// mode).
    /// </summary>
    public GlobalCache GlobalCache {
      get{
        if (session.IsBrowsingPast)
          return GlobalCache.AlwaysEmptyCache;
        else
          return realGlobalCache;
      }
    }
    
    internal object GetInnerValue(long id)
    {
      object obj = innerCache[id];
      if (obj is WeakReference) {
        obj = ((WeakReference)obj).Target;
        if (obj==null) {
          innerCache.Remove(id);
          lostObjectsCount++;
          TryOptimize();
        }
      }
      return obj;
    }

    internal object this[long id] {
      get {
        // Returns either DataObject or DataObjectInstantiationInfo,
        // but never - DataObjectValidationInfo (innerCache may
        // contain such entries, but they're used only in this method
        // to validate DataObjectInstantiationInfo taken from the
        // global cache)
        object obj = innerCache[id];
        if (obj is WeakReference) {
          obj = ((WeakReference)obj).Target;
          if (obj==null) {
            innerCache.Remove(id);
            lostObjectsCount++;
            TryOptimize();
          }
        }

        if (obj is DataObject)
          return obj;

        DataObjectValidationInfo    vInfo = (DataObjectValidationInfo)obj;
        DataObjectInstantiationInfo iInfo = (DataObjectInstantiationInfo)GlobalCache[vInfo]; // Updates GlobalCache, if necessary!
        if (iInfo!=vInfo)
          innerCache[id] = new WeakReference(iInfo);

        if (vInfo == null && iInfo == null)
        {
            iInfo = (DataObjectInstantiationInfo)GlobalCache[id]; // Updates GlobalCache, if necessary!
            if (!ChangeCache.getInstance().isChanged(id, iInfo))
            {
                obj = session.InstantiateObject(iInfo, false);
                innerCache[id] = new WeakReference(obj);
                return obj;
            }
        }
        return iInfo;

      }
      set {
        object oldValue = innerCache[id];
        if (oldValue is WeakReference) {
          oldValue = ((WeakReference)oldValue).Target;
          if (oldValue==null) {
            innerCache.Remove(id);
            lostObjectsCount++;
            TryOptimize();
          }
        }
        
        DataObject                  obj   = value as DataObject;
        DataObjectValidationInfo    vInfo = value as DataObjectValidationInfo;

        if (obj!=null)
          innerCache[id] = new WeakReference(obj);
        else if (vInfo!=null) {
          if (oldValue is DataObject)
            ((DataObject) oldValue).useableValidationInfo = vInfo;
          else
            innerCache[id] = new WeakReference(vInfo);
        }
      }
    }
    
    internal void Remove(long id) 
    {
      innerCache.Remove(id);
      lostObjectsCount++;
      TryOptimize();
    }

    /// <summary>
    /// Determines whether an instance with the specified 
    /// <see cref="DataObject.ID"/> and <see cref="DataObject.VersionID"/> is cached.
    /// <seealso cref="IsObjectCached"/>
    /// <seealso cref="DataObjectCachingState"/>
    /// <seealso cref="GetObjectCachingState"/>
    /// <seealso cref="Session.Preload"/>
    /// </summary>
    /// <param name="id"><see cref="DataObject.ID"/> of the instance to check.</param>
    /// <param name="versionID"><see cref="DataObject.VersionID"/> of the instance to check.</param>
    /// <returns><see cref="StrongReferenceHolder"/> object keeping necessary cached data in 
    /// <see cref="SessionCache"/>, if object is cached;
    /// otherwise, <see langword="null"/>.</returns>
    [Transactional(TransactionMode.Disabled)]
    public StrongReferenceHolder IsObjectCached(long id, int versionID)
    {
      object obj = IsObjectCached(id, versionID, null);
      if (obj==null)
        return null;
      else {
        DataObject dObj = obj as DataObject;
        if (dObj!=null)
          return new StrongReferenceHolder(dObj.GetInternalID(), obj);
        DataObjectIdentificationInfo info = (DataObjectIdentificationInfo)obj;
        return new StrongReferenceHolder(info.ID, obj);
      }
    }
    
    internal object IsObjectCached(long id, int versionID, TransactionContext tc)
    {
      object obj = innerCache[id];
      if (obj is WeakReference) {
        obj = ((WeakReference)obj).Target;
        if (obj==null) {
          innerCache.Remove(id);
          lostObjectsCount++;
          TryOptimize();
        }
      }

      DataObject                   dObj = obj as DataObject;
      DataObjectInstantiationInfo iInfo = obj as DataObjectInstantiationInfo;

      if (dObj!=null) {
        // We have a DataObject instance in cache
        if (dObj.transactionContext.isDirty) {
          // But dirty (unusable)...
          iInfo = dObj.useableValidationInfo as DataObjectInstantiationInfo;
          if (CheckAndValidateInstantiationInfo(iInfo, versionID, tc))
            return dObj;
          iInfo = (DataObjectInstantiationInfo)GlobalCache[id, versionID];
          if (CheckAndValidateInstantiationInfo(iInfo, versionID, tc)) {
            dObj.useableValidationInfo = iInfo;
            return dObj;
          }
          else {
            dObj.useableValidationInfo = new DataObjectValidationInfo(id,versionID,tc);
            return null;
          }
        }
        else {
          // Not dirty (useable)...
          if (versionID==dObj.GetInternalVersionID()) {
            if (tc!=null && tc!=dObj.transactionContext) {
              dObj.transactionContext = tc;
              // We should reload properties that track changes independently from it's owner.
              dObj.MarkIndependentlyPersistedFieldsAsNotLoaded();
            }
            return dObj;
          }
          // But it has incorrect version...
          iInfo = dObj.useableValidationInfo as DataObjectInstantiationInfo;
          if (CheckAndValidateInstantiationInfo(iInfo, versionID, tc))
            return dObj;
          iInfo = (DataObjectInstantiationInfo)GlobalCache[id, versionID];
          if (CheckAndValidateInstantiationInfo(iInfo, versionID, tc)) {
            dObj.useableValidationInfo = iInfo;
            return dObj;
          }
          else {
            dObj.useableValidationInfo = new DataObjectValidationInfo(id,versionID,tc);
            return null;
          }
        }
      }
      else if (iInfo!=null) {
        // We have instantiation info in cache...
        if (CheckAndValidateInstantiationInfo(iInfo, versionID, tc))
          return iInfo;
        iInfo = (DataObjectInstantiationInfo)GlobalCache[id, versionID];
        if (CheckAndValidateInstantiationInfo(iInfo, versionID, tc)) {
          innerCache[id] = new WeakReference(iInfo);
          return iInfo;
        }
        else {
          innerCache[id] = new WeakReference(
            new DataObjectValidationInfo(id,versionID,tc));
          return null;
        }
      }
      else {
        // We have nothing or just useless validation info in cache...
        innerCache[id] = new WeakReference(
          new DataObjectValidationInfo(id,versionID,tc));
        return null;
      }
    }
    
    bool CheckAndValidateInstantiationInfo(DataObjectInstantiationInfo iInfo, int expectedVersionID, TransactionContext tc)
    {
      if (iInfo==null)
        return false;
      if (iInfo.TransactionContext.isDirty)
        return false;
      if (iInfo.VersionID==expectedVersionID) {
        if (tc!=null)
          iInfo.TransactionContext = tc;
        return true;
      }
      else
        return false;
    }

    /// <summary>
    /// Determines whether an instance with the specified 
    /// <see cref="DataObject.ID"/> is cached.
    /// </summary>
    /// <param name="id"><see cref="DataObject.ID"/> of the instance to check.</param>
    /// <returns><see langword="True"/> if instance with the specified <see cref="DataObject.ID"/> 
    /// exists in the session cache; otherwise, <see langword="false"/>.</returns>
    /// <remarks>
    /// This method returns <see langword="true"/>, if instance caching state
    /// (see <see cref="GetObjectCachingState"/>) is 
    /// <see cref="DataObjectCachingState.NotCached"/> or
    /// <see cref="DataObjectCachingState.CachedButDirty"/>;
    /// otherwise it returns <see langword="false"/>.
    /// <seealso cref="DataObjectCachingState"/>
    /// <seealso cref="GetObjectCachingState"/>
    /// <seealso cref="Session.Preload"/>
    /// </remarks>
    [Transactional(TransactionMode.Disabled)]
    public bool IsObjectCached(long id) 
    {
      return (GetObjectCachingState(id) & DataObjectCachingState.Cached)!=0;
    }
    
    /// <summary>
    /// Returns the caching state (see <see cref="DataObjectCachingState"/>)
    /// of the instance with the specified <see cref="DataObject.ID"/>.
    /// <seealso cref="DataObjectCachingState"/>
    /// <seealso cref="IsObjectCached"/>
    /// <seealso cref="Session.Preload"/>
    /// </summary>
    /// <param name="id"><see cref="DataObject.ID"/> of the instance.</param>
    /// <returns>Caching state of the instance with the specified 
    /// <see cref="DataObject.ID"/>.</returns>
    [Transactional(TransactionMode.Disabled)]
    public DataObjectCachingState GetObjectCachingState(long id)
    {
      object obj = this[id];
      DataObject dObj = obj as DataObject;
      if (dObj!=null) {
        if (dObj.transactionContext==session.transactionContext)
          return DataObjectCachingState.Cached;
        if (dObj.transactionContext.isDirty) {
          DataObjectInstantiationInfo iInfo = dObj.UseableInstantiationInfo;
          if (iInfo==null)
            return DataObjectCachingState.CachedButDirty;
          if (iInfo.TransactionContext.isDirty)
            return DataObjectCachingState.CachedButDirty;
          if (iInfo.TransactionContext.OutermostTransaction
                ==session.outermostTransaction)
            return DataObjectCachingState.Cached;
          else
            return DataObjectCachingState.CachedButRequiresVersionCheck;
        }
        if (dObj.transactionContext.transaction==null ||
            dObj.transactionContext.transaction!=session.outermostTransaction) {
          DataObjectInstantiationInfo iInfo = dObj.UseableInstantiationInfo;
          if (iInfo!=null &&
              !iInfo.TransactionContext.isDirty &&
              iInfo.TransactionContext.OutermostTransaction
                ==session.outermostTransaction)
            return DataObjectCachingState.Cached;
          else
            return DataObjectCachingState.CachedButRequiresVersionCheck;
        }
        return DataObjectCachingState.Cached;
      }
      {
        DataObjectInstantiationInfo instantiationInfo = obj as DataObjectInstantiationInfo;
        if (instantiationInfo!=null) {
          if (instantiationInfo.TransactionContext==session.transactionContext)
            return DataObjectCachingState.Cached;
          if (instantiationInfo.TransactionContext.isDirty)
            return DataObjectCachingState.NotCached;
          if (instantiationInfo.TransactionContext.OutermostTransaction
                ==session.outermostTransaction)
            return DataObjectCachingState.Cached;
          else
            return DataObjectCachingState.CachedButRequiresVersionCheck;
        }
      }
      return DataObjectCachingState.NotCached;
    }

    internal DataObjectCachingState GetObjectCachingState(long id, ref int cachedVersionID, ref object cachedData)
    {
      // Almost the same stuff as in previous method,
      // but it also correctly fills cachedVersionID before
      // returning DataObjectCachingState.CachedButRequiresVersionCheck.
      object obj = this[id];
      DataObject dObj = obj as DataObject;
      if (dObj!=null) {
        cachedData = dObj;
        if (dObj.transactionContext==session.transactionContext)
          return DataObjectCachingState.Cached;
        if (dObj.transactionContext.isDirty) {
          DataObjectInstantiationInfo iInfo = dObj.UseableInstantiationInfo;
          if (iInfo==null)
            return DataObjectCachingState.CachedButDirty;
          if (iInfo.TransactionContext.isDirty)
            return DataObjectCachingState.CachedButDirty;
          if (iInfo.TransactionContext.OutermostTransaction
                ==session.outermostTransaction)
            return DataObjectCachingState.Cached;
          else {
            cachedVersionID = iInfo.VersionID;
            return DataObjectCachingState.CachedButRequiresVersionCheck;
          }
        }
        if (dObj.transactionContext.transaction==null ||
            dObj.transactionContext.transaction!=session.outermostTransaction) {
          DataObjectInstantiationInfo iInfo = dObj.UseableInstantiationInfo;
          if (iInfo!=null &&
              !iInfo.TransactionContext.isDirty &&
              iInfo.TransactionContext.OutermostTransaction
                ==session.outermostTransaction)
            return DataObjectCachingState.Cached;
          else {
            cachedVersionID = (int)dObj.Properties.GetValue(2,0,session.Domain.cultures.Count);
            return DataObjectCachingState.CachedButRequiresVersionCheck;
          }
        }
        return DataObjectCachingState.Cached;
      }
      {
        DataObjectInstantiationInfo instantiationInfo = obj as DataObjectInstantiationInfo;
        if (instantiationInfo!=null) {
          cachedData = instantiationInfo;
          if (instantiationInfo.TransactionContext==session.transactionContext)
            return DataObjectCachingState.Cached;
          if (instantiationInfo.TransactionContext.isDirty)
            return DataObjectCachingState.NotCached;
          if (instantiationInfo.TransactionContext.OutermostTransaction
                ==session.outermostTransaction)
            return DataObjectCachingState.Cached;
          else {
            cachedVersionID = instantiationInfo.VersionID;
            return DataObjectCachingState.CachedButRequiresVersionCheck;
          }
        }
      }
      return DataObjectCachingState.NotCached;
    }

    /// <summary>
    /// Invalidates <see cref="SessionCache"/> and
    /// possibly <see cref="Domain.GlobalCache"/>.
    /// </summary>
    /// <param name="withGlobalCache">Specifies whether <see cref="Domain.GlobalCache"/>
    /// should also be invalidated.</param>
    public void Invalidate(bool withGlobalCache)
    {
      if (session.disableSecurityThreads[Thread.CurrentThread]==null)
        throw new SecurityException("Access to Invalidate isn't allowed.");

      Hashtable newInstances = new Hashtable(innerCache.Count);
      TransactionContext dirtyContext = 
        TransactionContext.CreateDirtyContext(session);
      
      foreach (DictionaryEntry e in innerCache) {
        WeakReference wr = (WeakReference)e.Value;
        object obj = wr.Target;
        if (obj!=null) {
          DataObject dObj = obj as DataObject;
          if (dObj!=null) {
            dObj.useableValidationInfo = null;
            dObj.transactionContext = dirtyContext;
            newInstances.Add(e.Key,wr);
          }
        }
      }
      innerCache = newInstances;
      lostObjectsCount = 0;
      
      if (withGlobalCache)
        realGlobalCache.Invalidate(Session);
    }
    
    // Cache optimization

//SM begin
      public void Clear()
      {
          innerCache.Clear();
          lostObjectsCount = 0;
      }
//SM end


    private void TryOptimize()
    {
      if (lostObjectsCount>=cMaxLostObjectsCount)
        Optimize();
    }

    private void Optimize() 
    {
      Hashtable newInstances = new Hashtable(innerCache.Count);
      foreach (DictionaryEntry e in innerCache) {
        WeakReference wr = (WeakReference)e.Value;
        if (wr.Target!=null)
          newInstances.Add(e.Key,wr);
      }
      innerCache = newInstances;
      lostObjectsCount = 0;
    }


    // Constructor
    
    internal SessionCache(Session session): base(session)
    {
      realGlobalCache = session.Domain.GlobalCache;
    }
  }
}
