// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Attributes;

namespace DataObjects.NET
{
  /// <summary>
  /// Enumeration of possible SQL join types.
  /// <seealso cref="SqlJoin"/>
  /// <seealso cref="Query"/>
  /// <seealso cref="SqlQuery"/>
  /// </summary>
  public enum SqlJoinType
  {
    /// <summary>
    /// Inner join.
    /// Value is <see langword="0x0"/>.
    /// </summary>
    Inner = 0x0,
    /// <summary>
    /// Left join.
    /// Value is <see langword="0x1"/>.
    /// </summary>
    LeftOuter = 0x1,
//    /// <summary>
//    /// Right join.
//    /// Value is <see langword="0x2"/>.
//    /// </summary>
//    RightOuter = 0x2,
//    /// <summary>
//    /// Full join.
//    /// Value is <see langword="0x3"/>.
//    /// </summary>
//    FullOuter = 0x3,
//    /// <summary>
//    /// Cross join.
//    /// Value is <see langword="0x4"/>.
//    /// </summary>
//    Cross = 0x4,
  }
}
