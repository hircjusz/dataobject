// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.ComponentModel;
using System.Data;

namespace DataObjects.NET.Data
{
  /// <summary>
  /// Provides a type converter for <see cref="Adapter.DataSource">Adapter.DataSource</see>.
  /// </summary>
  public class AdapterDataSourceConverter : ReferenceConverter
  {
    /// <summary>
    /// Returns whether this object supports properties, using the specified context.
    /// </summary>
    /// <param name="context">An <see cref="ITypeDescriptorContext"/> 
    /// that provides a format context.</param>
    /// <returns><see langword="true"/> if <see cref="TypeConverter.GetProperties"/> should be called 
    /// to find the properties of this object; otherwise, <see langword="false"/>.</returns>
    public override bool GetPropertiesSupported(ITypeDescriptorContext context)
    {
      return false;
    }

    /// <summary>
    /// Returns a value indicating whether a particular value can be added to the 
    /// standard values collection.
    /// </summary>
    /// <param name="context">An <see cref="ITypeDescriptorContext"/> 
    /// that provides an additional context.</param>
    /// <param name="value">The value to check.</param>
    /// <returns><see langword="true"/> if the value is allowed and can be added 
    /// to the standard values collection; <see langword="false"/> if the value cannot be added 
    /// to the standard values collection.</returns>
    protected override bool IsValueAllowed(ITypeDescriptorContext context, object value)
    {
      if (value is DataSet)
        return true;
      return false;
    }

    // Constructors

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    public AdapterDataSourceConverter(): base(typeof(DataSet))
    {
    }
  }
}
