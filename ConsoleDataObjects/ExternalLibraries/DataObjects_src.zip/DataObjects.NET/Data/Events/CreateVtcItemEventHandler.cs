// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Data;
using DataObjects.NET;
using DataObjects.NET.Data;

namespace DataObjects.NET.Data
{
  /// <summary>
  /// Represents a method that will handle the <see cref="Adapter.CreateVtcItem"/> events.
  /// </summary>
  /// <param name="sender">The source of the event.</param>
  /// <param name="e">An <see cref="CreateVtcItemEventArgs"/> that contains the event data.</param>
  /// <remarks>
  /// <para>
  /// This event is raised when <see cref="Adapter"/> needs to create new 
  /// <see cref="ValueTypeCollection"/> item.
  /// </para>
  /// <para>
  /// When <see cref="Adapter"/> raises this event it sets 
  /// <see cref="CreateVtcItemEventArgs.Type"/> property and
  /// <see cref="CreateVtcItemEventArgs.DataRow"/> property.
  /// Event handler should create a new item and set <see cref="CreateVtcItemEventArgs.Value"/>
  /// property. If event handler will not set the <see cref="CreateVtcItemEventArgs.Value"/>
  /// <see cref="Adapter"/> will skip current <see cref="DataRow"/>.
  /// </para>
  /// </remarks>
  public delegate void CreateVtcItemEventHandler(object sender, CreateVtcItemEventArgs e);
}
