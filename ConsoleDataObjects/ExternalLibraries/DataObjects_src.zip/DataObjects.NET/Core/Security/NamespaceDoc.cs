// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;

namespace DataObjects.NET.Security
{
  /// <summary>
  /// Contains DataObjects.NET 2.0 security system classes.
  /// <see cref="AccessControlList">Here</see> you can find 
  /// more information about it.
  /// </summary>
  internal class NamespaceDoc {}
}
