// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;
using System.Reflection;
using System.Text.RegularExpressions;
#if !MONO
using EnvDTE;
#endif

namespace DataObjects.NET.Data.CodeManage
{
  /// <summary>
  /// Describes a value type collection.
  /// </summary>
  internal class ValueTypeCollectionDescriptor: IValueTypeCollectionDescriptor, ICloneable
  {
    private CodeManagerBase codeManager;
    private string name;
    private string dbName;
    private IElementDescriptor parent;
    private IFieldDescriptor[] fields;
    
    /// <summary>
    /// Code manager.
    /// </summary>
    public CodeManagerBase CodeManager {
      get {
        return codeManager;
      }
    }
    
    /// <summary>
    /// Gets parent element.
    /// </summary>
    public IElementDescriptor Parent {
      get {
        return parent;
      }
    }
    
    /// <summary>
    /// Gets collection name.
    /// </summary>
    public string Name {
      get {
        return name;
      }
    }

    /// <summary>
    /// Gets collection full name.
    /// </summary>
    public string FullName {
      get {
        return parent.FullName + "." + name;
      }
    }
    
    /// <summary>
    /// Element database name.
    /// </summary>
    /// <remarks>May be null.</remarks>
    public string DbName {
      get {
        return dbName;
      }
    }
    
    /// <summary>
    /// Gets child fields.
    /// </summary>
    public IFieldDescriptor[] Fields {
      get {
        return fields;
      }
    }
    
    /// <summary>
    /// Creates a new object that is a copy of the current instance.
    /// </summary>
    /// <returns>A new object that is a copy of this instance.</returns>
    object ICloneable.Clone()
    {
      ValueTypeCollectionDescriptor clone = new ValueTypeCollectionDescriptor();
      clone.codeManager = codeManager;
      clone.dbName = dbName;
      clone.name = name;
      clone.fields = new IFieldDescriptor[fields.Length];
      for (int i = 0; i < fields.Length; i++) {
        FieldDescriptor childField = (FieldDescriptor)((ICloneable)fields[i]).Clone();
        childField.SetParentFromContainer(clone);
        clone.fields[i] = childField;
      }
      return clone;
    }
    
    /// <summary>
    /// Sets parent element.
    /// </summary>
    /// <param name="parent"><see cref="IElementDescriptor"/> of a parent element.</param>
    internal void SetParentFromContainer(IElementDescriptor parent)
    {
      this.parent = parent;
    }
    

    private ValueTypeCollectionDescriptor()
    {
    }
    
    /// <summary>
    /// Initializes a new instance of the <see cref="ValueTypeCollectionDescriptor"/> class.
    /// </summary>
    /// <param name="parent">Collection's parent element. Value can be null.</param>
    /// <param name="property"><see cref="PropertyInfo"/>.</param>
    internal ValueTypeCollectionDescriptor(IElementDescriptor parent, PropertyInfo property)
    {
      if (property==null)
        throw new ArgumentNullException("property");
        
      if (parent!=null) {
        this.codeManager = parent.CodeManager;
        this.parent = parent;
      }
      
      this.name = property.Name;
      object[] attrs = property.GetCustomAttributes(typeof(Attributes.DbNameAttribute), true);
      if (attrs!=null && attrs.Length>0) {
        this.dbName = ((Attributes.DbNameAttribute)attrs[0]).DbName;
      }
      
      ArrayList fieldsList = new ArrayList();
      attrs = property.GetCustomAttributes(typeof(Attributes.ItemTypeAttribute), true);
      if (attrs!=null && attrs.Length>0) {
        Type itemType = ((Attributes.ItemTypeAttribute)attrs[0]).Type;
        FieldInfo[] childFields = itemType.GetFields(BindingFlags.Public | BindingFlags.Instance);
        foreach (FieldInfo field in childFields) {
          fieldsList.Add(new FieldDescriptor(parent, field));
        }
      }
      fields = (IFieldDescriptor[])fieldsList.ToArray(typeof(IFieldDescriptor));
    }
#if !MONO
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="parent">Collection's parent element. Value can be null.</param>
    /// <param name="property"><see cref="CodeProperty"/>. Value can be null.</param>
    internal ValueTypeCollectionDescriptor(IElementDescriptor parent, CodeProperty property)
    {
      if (parent!=null) {
        this.codeManager = parent.CodeManager;
        this.parent = parent;
      }
      
      if (property!=null) {
        this.name = property.Name;
        int attributesCount = 0;
        try {
          attributesCount = property.Attributes.Count;
        } catch {}
        for (int i = 0; i < attributesCount; i++) {
          CodeElement attrElement = property.Attributes.Item(i + 1);
          if (attrElement.Kind==vsCMElement.vsCMElementAttribute) {
            CodeAttribute attr = (CodeAttribute)attrElement;
            if (attr.FullName=="DataObjects.NET.Attributes.DbNameAttribute") {
              string val = attr.Value;
              if (val.StartsWith("\"") && val.EndsWith("\"")) {
                dbName = val.Substring(1, val.Length - 2);
                break;
              }
            }
          }
        }
      }
      
      CodeType codeType = null;
      if (property!=null) {
        int attributesCount = 0;
        try {
          attributesCount = property.Attributes.Count;
        } catch {}
        for (int i = 0; i < attributesCount; i++) {
          CodeAttribute attr = (CodeAttribute)property.Attributes.Item(i + 1);
          if (attr.FullName=="DataObjects.NET.Attributes.ItemTypeAttribute") {
            Regex r = new Regex(@"typeof(\s)*\((\s)*(?<type>.*?)(\s)*\)");
            Match m = r.Match(attr.Value);
            if (m.Groups["type"].Success) {
              string typeName = m.Result("${type}");
              try {
                codeType = ((DesigntimeCodeManager)codeManager).CodeModel.CodeTypeFromFullName(typeName);
              } catch {
                codeType = null;
              }
              break;
            }
          }
        }
      }
      
      ArrayList fieldsList = new ArrayList();
      if (codeType!=null && codeType.Kind==vsCMElement.vsCMElementStruct) {
        CodeStruct thisStruct = (CodeStruct)codeType;
        int membersCount = 0;
        try {
          membersCount = thisStruct.Members.Count;
        } catch {}
        for (int i = 0; i < membersCount; i++) {
          CodeElement element = thisStruct.Members.Item(i + 1);
          if (element.Kind==vsCMElement.vsCMElementVariable) {
            CodeVariable var = (CodeVariable)element;
            if (!var.IsConstant && !var.IsShared) {
              CodeType varCodeType = null;
              if (var.Type.TypeKind==vsCMTypeRef.vsCMTypeRefCodeType)
                varCodeType = var.Type.CodeType;
              IFieldDescriptor field = new FieldDescriptor(var.Name, this, varCodeType, var.Attributes);
              fieldsList.Add(field);
            }
          }
        }
      }
      fields = (IFieldDescriptor[])fieldsList.ToArray(typeof(IFieldDescriptor));
    }
#endif
  }
}
