// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Runtime.Serialization;
using DataObjects.NET.Attributes;
using Offline=DataObjects.NET.Offline;

namespace DataObjects.NET.Exceptions
{
  /// <summary>
  /// Thrown when a reference to the persistent instance is
  /// established from one of its properties.
  /// See <see cref="SelfReferenceAllowedAttribute"/>.
  /// </summary>
  [Serializable]
  public class SelfReferenceException: ReferentialIntegrityException
  {
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    public SelfReferenceException(): base("Self reference.") {}
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="text">Text of message.</param>
    public SelfReferenceException(string text): base(text) {}

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    public SelfReferenceException(DataObject o): 
      this(String.Format("Self reference: {0}, ID={1}.",o.GetType().BaseType.FullName,o.ID)) {}
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    public SelfReferenceException(Offline.DataObject o): 
      this(String.Format("Self reference: {0}, ID={1}.",o.GetType().BaseType.FullName,o.ID)) {}

    /// <summary>
    /// Deserialization constructor.
    /// </summary>
    /// <param name="info"><see cref="SerializationInfo"/> object.</param>
    /// <param name="context"><see cref="StreamingContext"/> object.</param>
    protected SelfReferenceException(SerializationInfo info, StreamingContext context):
      base(info, context)
    {
    }
  }
}
