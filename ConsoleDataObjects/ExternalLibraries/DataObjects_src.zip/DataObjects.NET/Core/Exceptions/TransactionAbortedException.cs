// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Runtime.Serialization;

namespace DataObjects.NET.Exceptions
{
  /// <summary>
  /// Thrown by <see cref="Transaction.Commit"/>\<see cref="Transaction.Rollback"/> 
  /// methods on fatal errors during execution.
  /// <seealso cref="Session"/>
  /// <seealso cref="Transaction"/>
  /// <seealso cref="Savepoint"/>
  /// </summary>
  [Serializable]
  public class TransactionAbortedException: DataObjectsDotNetException
  {
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="innerException">Inner exception.</param>
    public TransactionAbortedException(Exception innerException): this("Transaction aborted.",innerException) 
    {
    }
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="text">Text of message.</param>
    /// <param name="innerException">Inner exception.</param>
    public TransactionAbortedException(string text, Exception innerException): base(text,innerException) 
    {
    }
    
    /// <summary>
    /// Deserialization constructor.
    /// </summary>
    /// <param name="info"><see cref="SerializationInfo"/> object.</param>
    /// <param name="context"><see cref="StreamingContext"/> object.</param>
    protected TransactionAbortedException(SerializationInfo info, StreamingContext context):
      base(info, context)
    {
    }
  }
}
