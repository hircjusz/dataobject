// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.ComponentModel;

namespace DataObjects.NET.Data
{
  /// <summary>
  /// Base class for all mapping item classes.
  /// </summary>
  public abstract class MappingItemBase
  {
    private MappingCollectionBase mappingCollection;
    
    /// <summary>
    /// Gets item name.
    /// </summary>
    public virtual string Name {
      get {
        return "Mapping Item";
      }
    }
    
    /// <summary>
    /// Gets mapping collection to which this item belongs.
    /// </summary>
    [Browsable(false)]
    public MappingCollectionBase MappingCollection {
      get {
        return mappingCollection;
      }
    }
    
    /// <summary>
    /// Returns <see cref="Adapter"/> which uses current mapping item.
    /// </summary>
    /// <returns><see cref="Adapter"/> which uses current mapping item.</returns>
    public Adapter GetAdapter()
    {
      return this.MappingCollection.GetAdapter();
    }
    
    /// <summary>
    /// Sets the mapping collection to which this item will belong.
    /// </summary>
    /// <param name="mappingCollection"><see cref="MappingCollectionBase"/>.</param>
    internal void SetMappingCollectionFromContainer(MappingCollectionBase mappingCollection)
    {
      this.mappingCollection = mappingCollection;
    }
  
    /// <summary>
    /// Initializes a new instance of the <see cref="MappingItemBase"/> class.
    /// </summary>
    public MappingItemBase()
    {
    }
  }
}
