// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;
using System.Reflection;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Attributes;
using DataObjects.NET.Remoting;
using DataObjects.NET.ObjectModel;
using DataObjects.NET.Internals;

namespace DataObjects.NET
{
  /// <summary>
  /// Represents persistent collection of structures or primitive types.
  /// </summary>
  public abstract class ValueTypeCollection : SessionBoundObject,
    IList, ICollection, IEnumerable, 
    IDataObjectFieldValue, IRecyclableFieldValue, IRemovableFieldValue,
    IDataObjectExternalFieldValue,
    IConvertibleToOffline
  {
    private  DataObject  owner;
    private  Field       field;
    private  Culture     culture;
    private  bool        attached;
    private  Field       containedField;
    private  System.Type itemType;
    private  IReferenceHolderField[] referenceHolderFields;
    private  Field       pairTo;
    private  bool        hasPair;
    // Implementation & loading
    internal IValueTypeCollectionImplementation implementation;
    private  TransactionContext transactionContext;
    private  int         blockContentChangeEvent;

    /// <summary>
    /// Gets the owner of the collection 
    /// (<see cref="DataObject"/> instance containing the collection).
    /// </summary>
    [Transactional(TransactionMode.Disabled)]
    public DataObject Owner  {get {return owner;}}

    /// <summary>
    /// Gets collection field descriptor (<see cref="Field"/> descandant).
    /// </summary>
    [Transactional(TransactionMode.Disabled)]
    public Field      Field {get {return field;}}

    /// <summary>
    /// Gets the <see cref="Culture"/> of this collection.
    /// </summary>
    [Transactional(TransactionMode.Disabled)]
    public Culture    Culture {get {return culture;}}

    /// <summary>
    /// Gets the instance of the <see cref="Field"/> contained in this collection.
    /// </summary>
    [Transactional(TransactionMode.Disabled)]
    public Field      ContainedField {get {return containedField;}}

    /// <summary>
    /// Attaches the instance to the owner. This method is called by owner
    /// (<see cref="DataObject"/> instance) of the field during
    /// initialization or on property change.
    /// </summary>
    /// <param name="owner">Field owner (<see cref="DataObject"/> instance containing this field).</param>
    /// <param name="field">Field descriptor (<see cref="Field"/> descandant).</param>
    /// <param name="culture">Culture of this instance (if field is marked by 
    /// <see cref="TranslatableAttribute"/>), or <see langword="null"/>.</param>
    /// <remarks>
    /// See <see cref="IDataObjectFieldValue"/> description for additional information.
    /// </remarks>
    void IDataObjectFieldValue.Attach(DataObject owner, Field field, Culture culture)
    {
      if (attached)
        throw new InvalidOperationException("Instance is already attached.");
      if (Assembly.GetCallingAssembly()!=typeof(DataObject).Assembly)
        throw new InvalidOperationException("This method can be called only by DataObjects.NET.");

      this.session = owner.session;
      this.attached = true;
      this.owner   = owner;
      this.field   = field;
      this.containedField = field.ContainedFields[0];
      this.culture = culture;
      ValueTypeCollectionField vtcf = (ValueTypeCollectionField)field;
      this.pairTo = vtcf.PairTo;
      this.hasPair = vtcf.HasPair;
      this.Implementation.Attach();
      if (ChangesTrackingMode==ChangesTrackingMode.ThroughOwner)
        InvalidateCache();
      OnAttach();
    }
  
    /// <summary>
    /// Detaches the instance from the owner.
    /// </summary>
    /// <remarks>
    /// Always throws <see cref="InvalidOperationException"/>,
    /// since this field can't be detached.
    /// See <see cref="IDataObjectFieldValue"/> description for additional information.
    /// </remarks>
    void IDataObjectFieldValue.Detach()
    {
      throw new InvalidOperationException("Collection property can't be assigned.");
    }

    /// <summary>
    /// Indicates whether collection contains delayed updates.
    /// </summary>
    [Transactional(TransactionMode.Disabled)]
    public bool IsChanged {
      get {
        if (implementation==null)
          return false;
        return implementation.IsChanged;
      }
    }
    
    /// <summary>
    /// Persists all changes cached by the collection to database.
    /// </summary>
    [Transactional(TransactionMode.Disabled)]
    public void Persist()
    {
      if (!attached)
        throw new InvalidOperationException("Instance isn't attached.");
      if (implementation!=null)
        implementation.Persist();
    }

    /// <summary>
    /// Called before removing of the <see cref="Owner"/> instance.
    /// </summary>
    /// <remarks>
    /// See <see cref="IRemovableFieldValue"/> description for additional information.
    /// </remarks>
    void IRemovableFieldValue.Remove()
    {
      if (Assembly.GetCallingAssembly()!=typeof(DataObject).Assembly)
        throw new InvalidOperationException("This method can be called only by DataObjects.NET.");

      if (!attached)
        throw new InvalidOperationException("Instance isn't attached.");
      // Old code:
      // Clear();
    }
    
    /// <summary>
    /// Called to check if this instance can be reused.
    /// </summary>
    /// <returns><see langword="True"/> if the instance was recycled 
    /// and can be reused; otherwise, <see langword="false"/>.</returns>
    /// <remarks>
    /// See <see cref="IRecyclableFieldValue"/> description for additional information.
    /// </remarks>
    bool IRecyclableFieldValue.Recycle()
    {
      if (Assembly.GetCallingAssembly()!=typeof(DataObject).Assembly)
        throw new InvalidOperationException("This method can be called only by DataObjects.NET.");

      if (!OnRecycle())
        return false;
      if (ChangesTrackingMode==ChangesTrackingMode.ThroughOwner)
        InvalidateCache();
      if (implementation!=null)
        implementation.ClearChanges();
      owner    = null;
      session  = null;
      attached = false;
      return true;
    }

    /// <summary>
    /// Gets <see cref="IValueTypeCollectionImplementation"/>
    /// object handling low-level services for collection.
    /// </summary>
    [Transactional(TransactionMode.Disabled)]
    protected IValueTypeCollectionImplementation Implementation {
      get {
        if (implementation!=null)
          return implementation;
        else {
          implementation = CreateImplementation();
          return implementation;
        }
      }
    }
    
    /// <summary>
    /// Creates <see cref="Implementation"/>
    /// object handling low-level services for collection.
    /// Override this method to specify your own
    /// collection implementation, rather then default.
    /// </summary>
    /// <returns></returns>
    protected virtual IValueTypeCollectionImplementation CreateImplementation()
    {
      return new ValueTypeCollectionImplementation(this);
    }

    private IReferenceHolderField[] ReferenceHolderFields {
      get {
        if (referenceHolderFields!=null)
          return referenceHolderFields;
        else {
          referenceHolderFields = (field as IReferenceHolderGroupField).ReferenceHolderFields;
          return referenceHolderFields;
        }
      }
    }

    /// <summary>
    /// Gets <see cref="ChangesTrackingMode"/> of the collection.
    /// </summary>
    [Transactional(TransactionMode.Disabled)]
    public ChangesTrackingMode ChangesTrackingMode
    {
      get {return field.ChangesTrackingMode;} 
    }
    
    /// <summary>
    /// Gets <see cref="DataObjects.NET.TransactionContext"/> where
    /// cached collection data is valid.
    /// </summary>
    [Transactional(TransactionMode.Disabled)]
    public TransactionContext TransactionContext {
      get {
        if (ChangesTrackingMode==ChangesTrackingMode.Independently)
          return transactionContext;
        else
          return owner.transactionContext;
      }
    }

    [Transactional(TransactionMode.Disabled)]
    internal virtual void InvalidateCache()
    {
      if (implementation!=null)
        implementation.InvalidateCache();
      if (session!=null)
        transactionContext = session.transactionContext;
      else
        transactionContext = null;
    }

    /// <summary>
    /// Validates owner state and collection's <see cref="TransactionContext"/>.
    /// Flushes cached data on validation failure.
    /// </summary>
    [Transactional(TransactionMode.Disabled)]
    internal protected void EnsureCacheValidity()
    {
      if (owner.State==DataObjectState.Removed)
        throw new InstanceIsRemovedException();
      if (session.IsOnlineMode) {
        if (ChangesTrackingMode==ChangesTrackingMode.Independently && 
            (transactionContext==null ||
            transactionContext.State!=TransactionContextState.Valid))
          InvalidateCache();
      }
      else {
        if (ChangesTrackingMode==ChangesTrackingMode.Independently && 
            (transactionContext==null ||
            transactionContext.State==TransactionContextState.Dirty))
          InvalidateCache();
      }
    }

    /// <summary>
    /// Caches the specified item.
    /// </summary>
    /// <param name="entry">Entry to cache.</param>
    [Transactional(TransactionMode.Disabled)]
    internal void CacheItem(ValueTypeCollectionEntry entry)
    {
      EnsureCacheValidity();
      Implementation.CacheItem(entry);
    }

    /// <summary>
    /// Caches the specified item.
    /// </summary>
    /// <param name="entry">Entry to cache.</param>
    [Transactional(TransactionMode.Disabled)]
    internal void CacheItem(ValueTypeQueryResultEntry entry)
    {
      EnsureCacheValidity();
      Implementation.CacheItem(entry);
    }

    /// <summary>
    /// Automatically invoked before any change in the collection.
    /// </summary>
    [Transactional(TransactionMode.Disabled)]
    internal protected void ContentChanging()
    {
      if (blockContentChangeEvent>0)
        return;
      OnChange();
      owner.FieldContentChanging(this);
    }

    /// <summary>
    /// Automatically invoked on completion of any change in the collection.
    /// </summary>
    [Transactional(TransactionMode.Disabled)]
    internal protected void ContentChanged()
    {
      if (blockContentChangeEvent>0)
        return;
      OnChangeComplete();
      owner.FieldContentChanged(this);
    }

    /// <summary>
    /// Gets or sets <see cref="System.Type"/> of items that can be stored in 
    /// the collection.
    /// </summary>
    [Transactional(TransactionMode.Disabled)]
    public  System.Type ItemType 
    {
      get {return itemType;} 
    }

    /// <summary>
    /// Gets the item field (see <see cref="ReferenceField"/>) that holds 
    /// a reference to the <see cref="Owner"/> of the collection.
    /// </summary>
    [Transactional(TransactionMode.Disabled)]
    public ReferenceField OwnerField {
      get {
        return ((ValueTypeCollectionField)field).OwnerField;
      }
    }

    /// <summary>
    /// Points to the paired field (if <see cref="PairToAttribute"/> was applied
    /// to the field that declared this property) or <see langword="null"/>.
    /// </summary>
    [Transactional(TransactionMode.Disabled)]
    public Field PairTo {
      get {return pairTo;}
    }

    /// <summary>
    /// <see langword="True"/> if collection has paired field(s) (collection is a target of
    /// some <see cref="PairToAttribute"/>).
    /// </summary>
    [Transactional(TransactionMode.Disabled)]
    public bool HasPair {
      get {return hasPair;}
    }

    /// <summary>
    /// <see langword="True"/> if collection is loaded from the database.
    /// </summary>
    [Transactional(TransactionMode.Disabled)]
    public bool IsLoaded {
      get {
        if (session.IsOfflineMode) 
          return InnerIsLoaded();

        // Automatic Transactions support code
        TransactionController tc = session.CreateTransactionController(TransactionMode.TransactionRequired);
      Reprocess:
        try {
          bool r = InnerIsLoaded();
          tc.Commit();
          return r;
        }
        catch (Exception e) {
          if (tc.Rollback(e, true))
            goto Reprocess;
          throw;
        }
      }
    }
    private bool InnerIsLoaded()
    {
      EnsureCacheValidity();
      if (implementation==null)
        return false;
      return implementation.IsLoaded;
    }

    /// <summary>
    /// Reloads the collection.
    /// This method invalidates collection cache,
    /// and executes <see cref="Load"/> method 
    /// to load all objects (structs)
    /// contained in the collection.
    /// </summary>
    [Transactional(TransactionMode.Disabled)]
    public void Reload()
    {
      Persist();
      InvalidateCache();
      Load();
    }

    /// <summary>
    /// Indexer (by element index).
    /// </summary>
    [Transactional(TransactionMode.Disabled)]
    public ValueTypeCollectionEntry this[int index] {
      get {
        return (ValueTypeCollectionEntry)List[index];
      }
    }

    /// <summary>
    /// Indexer (by element ItemID (key)).
    /// </summary>
    [Transactional(TransactionMode.Disabled)]
    public ValueTypeCollectionEntry this[long itemId]
    {
      get {
        if (session.IsOfflineMode) {
          Load();
          return InnerGet(itemId);
        }

        // Automatic Transactions support code
        TransactionController tc = session.CreateTransactionController(TransactionMode.TransactionRequired);
      Reprocess:
        try {
          ValueTypeCollectionEntry retval = InnerGet(itemId);
          tc.Commit();
          return retval;
        }
        catch (Exception e) {
          if (tc.Rollback(e, true))
            goto Reprocess;             
          throw;
        }
      }
    }
    private ValueTypeCollectionEntry InnerGet(long itemId)
    {
      EnsureCacheValidity();
      return Implementation.GetItem(itemId);
    }

    /// <summary>
    /// Gets the value of collection item.
    /// Used by <see cref="ValueTypeCollectionEntry"/>.<see cref="ValueTypeCollectionEntry.Value"/>.
    /// </summary>
    /// <param name="itemId">ItemID (key) to get the value for.</param>
    /// <returns>Value of collection item.</returns>
    [Transactional(TransactionMode.Disabled)]
    internal object GetValue(long itemId)
    {
      ValueTypeCollectionEntry entry = this[itemId];
      if (entry==null)
        return null;
      return containedField.ConvertInternalToValue(
        Owner, Culture, entry.InternalValue);
    }
    
    /// <summary>
    /// Sets the value of collection item.
    /// Used by <see cref="ValueTypeCollectionEntry"/>.<see cref="ValueTypeCollectionEntry.Value"/>.
    /// </summary>
    /// <param name="itemId">ItemID (key) to set the value for.</param>
    /// <param name="value">Value to set.</param>
    internal void SetValue(long itemId, object value)
    {
      // Automatic Transactions support code
      TransactionController tc = session.CreateTransactionController(TransactionMode.TransactionRequired);
    Reprocess:
      try {
        InnerSetValue(itemId, value, true, true, true);
        tc.Commit();
        return;
      }
      catch (Exception e) {
        if (tc.Rollback(e, true))
          goto Reprocess;             
        throw;
      }
    }
    private void InnerSetValue(long itemId, object value, bool validate, bool processPairs, bool processMaster)
    {
      // EnsureCacheValidity(); // Next line runs this anyway
      ValueTypeCollectionEntry entry = InnerGet(itemId);
      if (entry==null)
        throw new InvalidOperationException(String.Format(
          "Can't find item with ItemID={0}.", itemId));

      if (validate)
        FixStructOwner(ref value);

      // Forwarding call to master collection
      if (pairTo!=null && processPairs) {
        GetMasterCollection((StructHolder)entry.InternalValue).InnerSetValue(itemId, value, validate, true, true);
        return;
      }

      if (validate)
        Validate(value);

      object valueI    = null;
      object oldValueI = entry.InternalValue;
      object oldValue  = containedField.ConvertInternalToValue(Owner, Culture, oldValueI);
      StructField sf   = containedField as StructField;

      ContentChanging();
      OnSet(entry, value);

      // OnReference\OnDereference support code
      if (sf!=null) {
        if (oldValueI!=null)
          valueI = ((StructHolder)oldValueI).Clone();
        sf.SetStructValue(Owner, Culture, valueI, value, true, false);
      }
      else {
        valueI = containedField.ConvertValueToInternal(Owner, Culture, value);
        // Possible future improvement code: support of direct containment
        // of reference fields
        if (containedField is ReferenceField) {
          if (oldValue!=null)
            ((DataObject)oldValue).OnDereferenceEx(Owner, field, Culture);
          if (value != null)
            ((DataObject)value).OnReferenceEx(Owner, field, Culture);
        }
      }
      
      // Persisting updated entry
      entry.InternalValue = valueI;
      if (pairTo==null) {
        Implementation.MarkItemAsChanged(entry);

        // Updating pairs
        if (hasPair && processMaster) {
          ValueTypeCollection[] oldPairCollections = 
            GetPairCollections((StructHolder)oldValueI, false);
          ValueTypeCollection[] newPairCollections = 
            GetPairCollections((StructHolder)valueI, validate);
          int pcCount = oldPairCollections.Length; // Always equals to newPairCollections.Length

          for (int i = 0; i<pcCount; i++) {
            if (oldPairCollections[i]!=null && oldPairCollections[i]!=newPairCollections[i])
              oldPairCollections[i].InnerRemove(itemId, false);
            if (newPairCollections[i]!=null && oldPairCollections[i]!=newPairCollections[i])
              newPairCollections[i].InnerAdd(itemId, value, false);
            if (oldPairCollections[i]!=null && newPairCollections[i]!=null &&
              oldPairCollections[i]==newPairCollections[i])
              oldPairCollections[i].InnerSetValue(
                itemId, value, validate, false, false);
          }
        }
      }
      
      OnSetComplete(entry, oldValue);
      ContentChanged();
    }

    #region Internal\private methods
    
    internal void SetStructFieldValue(long itemId, string absoluteName, object value)
    {
      EnsureCacheValidity();

      int dotIndex1 = absoluteName.IndexOf('.');
      if (dotIndex1<=0 || absoluteName.Substring(0,dotIndex1)!=field.Name)
        throw new InvalidOperationException(String.Format(
          "Absolute name \"{0}\" is invalid in this context.", absoluteName));

      int dotIndex2 = absoluteName.IndexOf('.', dotIndex1+1);
      if (dotIndex2<0) {
        if (absoluteName.Substring(dotIndex1+1)!=containedField.Name)
          throw new InvalidOperationException(String.Format(
            "Absolute name \"{0}\" is invalid in this context.", absoluteName));
        InnerSetValue(itemId, value, false, true, true);
        return;
      }
      if (absoluteName.Substring(dotIndex1+1,dotIndex2-dotIndex1-1)!=containedField.Name)
        throw new InvalidOperationException(String.Format(
          "Absolute name \"{0}\" is invalid in this context.", absoluteName));
      
      StructField sf = containedField as StructField;

      if (sf==null)
        throw new InvalidOperationException(String.Format(
          "Absolute name \"{0}\" is invalid in this context.", absoluteName));
      
      string partName = absoluteName.Substring(dotIndex2+1);
      ValueTypeCollectionEntry entry = InnerGet(itemId);
      if (entry==null)
        throw new InvalidOperationException(String.Format(
          "Can't find item with ItemID={0}.", itemId));

      object oldValueI = entry.InternalValue;

      object newValueI = ((StructHolder)oldValueI).Clone();
      (sf as ISupportsIndexingField).SetContainedFieldValue(Owner, Culture, newValueI, value, null, partName,
        true, true);
      object newValue  = containedField.ConvertInternalToValue(Owner, Culture, newValueI);

      InnerSetValue(itemId, newValue, false, true, true);
    }
    
    /// <summary>
    /// Gets the value of collection item's inner field.
    /// </summary>
    /// <param name="itemId">ItemID (key) to set the value for.</param>
    /// <param name="absoluteName">Absolute name of inner field.</param>
    /// <returns>Value of collection item's inner field.</returns>
    internal object GetStructFieldValue(long itemId, string absoluteName)
    {
      if (session.IsOfflineMode) {
        Load();
        return InnerGetStructFieldValue(itemId, absoluteName);
      }

      // Automatic Transactions support code
      TransactionController tc = session.CreateTransactionController( TransactionMode.TransactionRequired);
    Reprocess:
      try {
        object r = InnerGetStructFieldValue(itemId, absoluteName);
        tc.Commit();
        return r;
      }
      catch (Exception e) {
        if (tc.Rollback(e, true))
          goto Reprocess;             
        throw;
      }
    }
    private object InnerGetStructFieldValue(long itemId, string absoluteName)
    {
      EnsureCacheValidity();
      int dotIndex1 = absoluteName.IndexOf('.');
      if (dotIndex1<=0 || absoluteName.Substring(0,dotIndex1)!=field.Name)
        throw new InvalidOperationException(String.Format(
          "Absolute name \"{0}\" is invalid in this context.", absoluteName));

      int dotIndex2 = absoluteName.IndexOf('.', dotIndex1+1);
      if (dotIndex2<0) {
        if (absoluteName.Substring(dotIndex1+1)!=containedField.Name)
          throw new InvalidOperationException(String.Format(
            "Absolute name \"{0}\" is invalid in this context.", absoluteName));
        return InnerGet(itemId);
      }
      if (absoluteName.Substring(dotIndex1+1,dotIndex2-dotIndex1-1)!=containedField.Name)
        throw new InvalidOperationException(String.Format(
          "Absolute name \"{0}\" is invalid in this context.", absoluteName));
      
      StructField sf  = containedField as StructField;
      if (sf==null)
        throw new InvalidOperationException(String.Format(
          "Absolute name \"{0}\" is invalid in this context.", absoluteName));
      
      ValueTypeCollectionEntry entry = InnerGet(itemId);
      if (entry==null)
        throw new InvalidOperationException(String.Format(
          "Can't find item with ItemID={0}.", itemId));

      string partName = absoluteName.Substring(dotIndex2+1);
      return (sf as ISupportsIndexingField).GetContainedFieldValue(Owner, Culture, entry.InternalValue, null, partName);
    }
    
    internal object InternalGetStructFieldValue(ValueTypeCollectionEntry entry, string absoluteName)
    {
      if (entry==null)
        throw new ArgumentNullException("entry");
        
      int dotIndex1 = absoluteName.IndexOf('.');
      if (dotIndex1<=0 || absoluteName.Substring(0,dotIndex1)!=field.Name)
        throw new InvalidOperationException(String.Format(
          "Absolute name \"{0}\" is invalid in this context.", absoluteName));

      int dotIndex2 = absoluteName.IndexOf('.', dotIndex1+1);
      if (dotIndex2<0) {
        if (absoluteName.Substring(dotIndex1+1)!=containedField.Name)
          throw new InvalidOperationException(String.Format(
            "Absolute name \"{0}\" is invalid in this context.", absoluteName));
        return entry.Value;
      }
      if (absoluteName.Substring(dotIndex1+1,dotIndex2-dotIndex1-1)!=containedField.Name)
        throw new InvalidOperationException(String.Format(
          "Absolute name \"{0}\" is invalid in this context.", absoluteName));
      
      StructField sf  = containedField as StructField;
      if (sf==null)
        throw new InvalidOperationException(String.Format(
          "Absolute name \"{0}\" is invalid in this context.", absoluteName));
      
      string partName = absoluteName.Substring(dotIndex2+1);

      return (sf as ISupportsIndexingField).GetContainedFieldValue(Owner, Culture, entry.InternalValue, null, partName);
    }

    
    private void ClearReferences(ValueTypeCollectionEntry entry)
    {
      if (entry==null)
        throw new ArgumentNullException("entry");
      
      StructField sf = containedField as StructField;
      if (sf!=null) {
        StructHolder oldValueI = (StructHolder)entry.InternalValue;
        StructHolder newValueI = oldValueI.Clone();
        if (sf!=null) {
          int partialNameOrigin = sf.AbsoluteName.Length+1;
          foreach (Field f in ReferenceHolderFields) {
            if (f is ReferenceField)
              (sf as ISupportsIndexingField).SetContainedFieldValue(Owner, Culture, newValueI, null, 
                null, f.AbsoluteName.Substring(partialNameOrigin), true, true);
          }
          object newValue = containedField.ConvertInternalToValue(Owner, Culture, newValueI);
          InnerSetValue(entry.InternalItemID, newValue, false, false, false);
        }
      }
      else if (containedField is ReferenceField)
        InnerSetValue(entry.InternalItemID, null, false, false, false);
    }

    private ValueTypeCollection GetMasterCollection(StructHolder iValue)
    {
      StructField sf = (StructField)containedField;
      DataObject masterOwner = (DataObject)(sf as ISupportsIndexingField).GetContainedFieldValue(Owner, Culture, iValue, null,
        ((ValueTypeCollectionField)pairTo).OwnerFieldRelativeName);
      if (masterOwner==null)
        throw new InvalidOperationException(String.Format(
          "Provided struct value conains invalid owner reference ({0})", 
          ((ValueTypeCollectionField)pairTo).OwnerFieldRelativeName));
      return (ValueTypeCollection)masterOwner.GetProperty(pairTo.AbsoluteName, Culture);
    }
    
    private ValueTypeCollection[] GetPairCollections(StructHolder iValue, bool validate)
    {
      StructField sf = (StructField)containedField;
      ValueTypeCollectionField vtcf = (ValueTypeCollectionField)field;

      ValueTypeCollectionField[] uniquePairedFields = vtcf.GetUniquePairs();
      int cnt = uniquePairedFields.Length;
      ValueTypeCollection[] pairs = new ValueTypeCollection[cnt];
      for (int i = 0; i<cnt; ++i) {
        ValueTypeCollectionField pairedField = uniquePairedFields[i];
        DataObject pairOwner = (DataObject)(sf as ISupportsIndexingField).GetContainedFieldValue(Owner, Culture, iValue, null, pairedField.OwnerFieldRelativeName);
        if (pairOwner!=null)
          pairs[i] = (ValueTypeCollection)pairOwner.GetProperty(pairedField.AbsoluteName, Culture);
        else {
          if (validate && !pairedField.AllowNullOwner)
            throw new InvalidOperationException(String.Format(
              "Provided struct value conains invalid owner reference ({0})", 
              pairedField.OwnerFieldRelativeName));
          pairs[i] = null;
        }
      }
      return pairs;
    }
    

    private void FixStructOwner(ref object value)
    {
      if (value==null && (ContainedField is StructField))
        throw new ArgumentNullException("value");
      if (OwnerField==null)
        return;
    
      StructField sf = (StructField)containedField;
      StructHolder iValue = (StructHolder)sf.ConvertValueToInternal(Owner, Culture, value);
      ValueTypeCollectionField vtcf = (ValueTypeCollectionField)field;
      if (Owner!=(sf as ISupportsIndexingField).GetContainedFieldValue(Owner, Culture, iValue, null, vtcf.OwnerFieldRelativeName)) {
        (sf as ISupportsIndexingField).SetContainedFieldValue(Owner, Culture, iValue, Owner, null, vtcf.OwnerFieldRelativeName, 
          true, true);
        value = sf.ConvertInternalToValue(Owner, Culture, iValue);
      }
    }
    
    #endregion

    /// <summary>
    /// Loads collection from the database.
    /// This method ensures if collection wasn't loaded earlier by
    /// checking the state of collection cache,
    /// and loads all objects (structs)contained in the collection, 
    /// if this is necessary.
    /// </summary>
    [Transactional(TransactionMode.Disabled)]
    public void Load() 
    {
      if (session.IsOfflineMode && InnerIsLoaded())
        return;
      
      // Automatic Transactions support code
      TransactionController tc = session.CreateTransactionController(TransactionMode.TransactionRequired);
    Reprocess:
      try {
        InnerLoad();
        tc.Commit();
      }
      catch (Exception e) {
        if (tc.Rollback(e, true))
          goto Reprocess;
        throw;
      }
    }
    private void InnerLoad() 
    {
      if (InnerIsLoaded())
        return;
      if (PairTo==null)
        Persist();
      else
        session.Persist();
      Implementation.Load();
    }

    internal void Preload(ArrayList dbItems, int startIndex, int count) 
    {
      if (InnerIsLoaded())
        return;
      if (PairTo==null)
        Persist();
      else
        session.Persist();
      Implementation.Load(dbItems, startIndex, count);
    }

    internal void Preload(long[] itemIds, object[] iValues, int count)
    {
      if (InnerIsLoaded())
        return;
      if (PairTo==null)
        Persist();
      else
        session.Persist();
      Implementation.Load(itemIds, iValues, count);
    }

    /// <summary>
    /// Gets the number of elements contained in the collection.
    /// </summary>
    [Transactional(TransactionMode.Disabled)]
    public int Count {
      get {
        if (session.IsOfflineMode) {
          Load();
          return InnerGetCount();
        }

        // Automatic Transactions support code
        TransactionController tc = session.CreateTransactionController(TransactionMode.TransactionRequired);
      Reprocess:
        try {
          int retval = InnerGetCount();
          tc.Commit();
          return retval;
        }
        catch (Exception e) {
          if (tc.Rollback(e, true))
            goto Reprocess;             
          throw;
        }
      }
    }
    private int InnerGetCount()
    {
      EnsureCacheValidity();
      return Implementation.Count;
    }

    /// <summary>
    /// Adds a new element to the collection.
    /// </summary>
    /// <param name="value">Item to add.</param>
    [Transactional(TransactionMode.TransactionRequired)]
    public virtual int Add(object value)
    {
      return InnerAdd(0, value, true);
    }

    /// <summary>
    /// Adds a new element to the collection.
    /// </summary>
    /// <param name="value">Item to add.</param>
    /// <param name="outputEntry">An entry that will represent new item in the collection.</param>
    [Transactional(TransactionMode.TransactionRequired)]
    public virtual int Add(object value, out ValueTypeCollectionEntry outputEntry)
    {
      return InnerAdd(value, true, out outputEntry);
    }

    private int InnerAdd(long itemId, object value, bool processPairs)
    {
      EnsureCacheValidity();
      if (owner.State==DataObjectState.New)
        owner.Persist();
      if (value==null)
        throw new ArgumentNullException("value");

      FixStructOwner(ref value);

      // Forwarding call to master collection
      if (pairTo!=null && processPairs) {
        object iValueTmp = containedField.ConvertValueToInternal(Owner, Culture, value);
        ValueTypeCollection masterCollection = GetMasterCollection((StructHolder)iValueTmp);
        if (Implementation.IsLoaded && !masterCollection.Implementation.IsLoaded)
          masterCollection.Load();
        int masterCollectionIndex = masterCollection.InnerAdd(itemId, value, true);
        if (Implementation.IsLoaded)
          return Implementation.IndexOf(masterCollection[masterCollectionIndex].InternalItemID);
        else
          return -1;
      }

      Validate(value);

      object iValue  = null;
      StructField sf = containedField as StructField;
      
      ContentChanging();
      OnAdd(value);

      // OnReference\OnDereference support code
      if (sf!=null) {
        iValue = sf.CreateDefaultInternalValue(Culture, Owner);
        sf.SetStructValue(Owner, Culture, iValue, value, true, false);
      }
      else {
        iValue = containedField.ConvertValueToInternal(Owner, Culture, value);
        // Possible future improvement code: support of direct containment
        // of reference fields
        if (containedField is ReferenceField) {
          if (value!=null)
            ((DataObject)value).OnReferenceEx(Owner, field, Culture);
        }
      }

      // Persisting updated entry
      ValueTypeCollectionEntry entry;
      if (pairTo==null) {
        entry = Implementation.Add(iValue);
        itemId = entry.ItemID;
        // Updating pairs
        if (hasPair) {
          ValueTypeCollection[] pairCollections = 
            GetPairCollections((StructHolder)iValue, true);
          int pcCount = pairCollections.Length;
          for (int i = 0; i<pcCount; i++) {
            if (pairCollections[i]!=null)
              pairCollections[i].InnerAdd(itemId, value, false);
          }
        }
      }
      else {
        entry = new ValueTypeCollectionEntry(this, itemId, iValue);
        Implementation.Add(entry);
      }
      
      OnAddComplete(entry);
      ContentChanged();

      if (Implementation.IsLoaded)
        return Implementation.IndexOf(itemId);
      else
        return -1;
    }

    private int InnerAdd(object value, bool processPairs, out ValueTypeCollectionEntry outputEntry)
    {
      EnsureCacheValidity();
      if (owner.State==DataObjectState.New)
        owner.Persist();
      if (value==null)
        throw new ArgumentNullException("value");

      FixStructOwner(ref value);

      // Forwarding call to master collection
      if (pairTo!=null && processPairs) {
        object iValueTmp = containedField.ConvertValueToInternal(Owner, Culture, value);
        ValueTypeCollection masterCollection = GetMasterCollection((StructHolder)iValueTmp);

        if (Implementation.IsLoaded && !masterCollection.Implementation.IsLoaded)
          masterCollection.Load();
        masterCollection.InnerAdd(value, true, out outputEntry);

        outputEntry = Implementation.GetItem(outputEntry.InternalItemID);
        return (Implementation.IsLoaded ? Implementation.IndexOf(outputEntry.InternalItemID) : -1);
      }

      Validate(value);

      object iValue  = null;
      StructField sf = containedField as StructField;
      
      ContentChanging();
      OnAdd(value);

      // OnReference\OnDereference support code
      if (sf!=null) {
        iValue = sf.CreateDefaultInternalValue(Culture, Owner);
        sf.SetStructValue(Owner, Culture, iValue, value, true, false);
      }
      else {
        iValue = containedField.ConvertValueToInternal(Owner, Culture, value);
        // Possible future improvement code: support of direct containment
        // of reference fields
        if (containedField is ReferenceField) {
          if (value!=null)
            ((DataObject)value).OnReferenceEx(Owner, field, Culture);
        }
      }

      // Persisting updated entry
      outputEntry = Implementation.Add(iValue);
      long itemId = outputEntry.ItemID;
      // Updating pairs
      if (hasPair) {
        ValueTypeCollection[] pairCollections = 
          GetPairCollections((StructHolder)iValue, true);
        int pcCount = pairCollections.Length;
        for (int i = 0; i<pcCount; i++) {
          if (pairCollections[i]!=null)
            pairCollections[i].InnerAdd(itemId, value, false);
        }
      }

      OnAddComplete(outputEntry);
      ContentChanged();

      return (Implementation.IsLoaded ? Implementation.IndexOf(itemId) : -1);
    }

    /// <summary>
    /// <para>Copies the elements of an array into the collection.</para>
    /// </summary>
    /// <param name='value'>
    ///   An array containing the objects to add to the collection.
    /// </param>
    /// <returns>
    ///   <para>None.</para>
    /// </returns>
    /// <seealso cref='QueryResult.Add'/>
    [Transactional(TransactionMode.TransactionRequired)]
    public virtual void AddRange(object[] value) 
    {
      InnerAddRange(value);
    }
    private void InnerAddRange(object[] value) 
    {
      EnsureCacheValidity();
      for (int i = 0; (i < value.Length); i = (i + 1))
        List.Add(value[i]);
    }

    /// <summary>
    ///   <para>
    ///     Adds the contents of <see cref='ValueTypeQueryResult'/> to the end of the collection.
    ///  </para>
    /// </summary>
    /// <param name='value'>
    ///    A <see cref='ValueTypeQueryResult'/> containing the objects to add to the collection.
    /// </param>
    /// <returns>
    ///   <para>None.</para>
    /// </returns>
    /// <seealso cref='QueryResult.Add'/>
    [Transactional(TransactionMode.Disabled)]
    public void AddRange(ValueTypeQueryResult value) 
    {
      if (session!=value.session)
        throw new InvalidOperationException("Collections belongs to different sessions.");

      // Automatic Transactions support code
      TransactionController tc = session.CreateTransactionController( TransactionMode.TransactionRequired);
    Reprocess:
      try {
        InnerAddRange(value);
        tc.Commit();
      }
      catch (Exception e) {
        if (tc.Rollback(e, true))
          goto Reprocess;
        throw;
      }
    }
    private void InnerAddRange(ValueTypeQueryResult value)
    {
      EnsureCacheValidity();
      foreach (ValueTypeCollectionEntry o in value)
        List.Add(o.Value);
    }

    /// <summary>
    /// Removes the element at the specified index from the collection.
    /// </summary>
    /// <param name="index">The zero-based index of the element to remove.</param>
    [Transactional(TransactionMode.TransactionRequired)]
    public virtual void RemoveAt(int index)
    {
      InnerRemove(this[index]);
    }

    /// <summary>
    /// Removes the item from the collection.
    /// </summary>
    /// <param name="value">Item to remove.</param>
    [Transactional(TransactionMode.TransactionRequired)]
    public virtual void Remove(ValueTypeCollectionEntry value)
    {
      if (value.IsUnbound)
        throw new InvalidOperationException("Can't remove unbound entry.");
      InnerRemove(value);
    }
    private void InnerRemove(ValueTypeCollectionEntry value)
    {
      if (pairTo==null && !hasPair)
        InnerRemove(value.InternalItemID, true);
      else
        InnerRemove(value.ItemID, true);
    }

    /// <summary>
    /// Removes the element with the specified ItemID (key) from the collection.
    /// </summary>
    /// <param name="itemId">ItemID (key) of item to remove.</param>
    [Transactional(TransactionMode.TransactionRequired)]
    public virtual void Remove(long itemId)
    {
      InnerRemove(itemId, true);
    }
    private void InnerRemove(long itemId, bool processPairs)
    {
      // EnsureCacheValidity(); // Next line runs this anyway
      ValueTypeCollectionEntry entry = InnerGet(itemId);
      if (entry==null)
        throw new InvalidOperationException(String.Format(
          "Can't find item with ItemID={0}.", itemId));

      // Forwarding call to master collection
      if (pairTo!=null && processPairs) {
        GetMasterCollection((StructHolder)entry.InternalValue).InnerRemove(itemId, true);
        return;
      }

      object iValue  = entry.InternalValue;
      object value   = containedField.ConvertInternalToValue(Owner, Culture, iValue);

      ContentChanging();
      blockContentChangeEvent++;
      try {
        OnRemove(entry);

        if (pairTo==null) {
          // Updating pairs
          if (hasPair) {
            ValueTypeCollection[] pairCollections = 
              GetPairCollections((StructHolder)iValue, false);
            int pcCount = pairCollections.Length;
            for (int i = 0; i<pcCount; i++) {
              if (pairCollections[i]!=null)
                pairCollections[i].InnerRemove(itemId, false);
            }
          }
        }

        // OnReference\OnDereference support code
        ClearReferences(entry);

        // Persisting updated entry
        Implementation.Remove(entry);

        OnRemoveComplete(itemId, value);
      }
      finally {
        blockContentChangeEvent--;
      }
      ContentChanged();
    }
    
    /// <summary>
    /// Determines whether collection contains a specific value.
    /// </summary>
    /// <param name="value">Value to search for.</param>
    /// <returns><see langword="True"/> if the object is found; otherwise, <see langword="false"/>.</returns>
    [Transactional(TransactionMode.Disabled)]
    public bool Contains(ValueTypeCollectionEntry value) 
    {
      return List.Contains(value);
    }

    /// <summary>
    /// Searches for the specified value and returns the index of the first occurrence within the current instance.
    /// </summary>
    /// <param name="value">The value to locate.</param>
    /// <returns>The index of the first occurrence of value within the entire collection, if found; otherwise, -1.</returns>
    [Transactional(TransactionMode.Disabled)]
    public int IndexOf(ValueTypeCollectionEntry value)
    {
      return List.IndexOf(value);
    }


    /// <summary>
    /// Determines an identifier of the specified collection entry.
    /// </summary>
    /// <param name="entry"><see cref="ValueTypeCollectionEntry"/> to search identifier for.</param>
    /// <returns>An identifier of the specified entry if found; otherwise, <see langword="ValueTypeCollectionEntry.UndefinedItemID"/>.</returns>
    [Transactional(TransactionMode.Disabled)]
    public long GetItemId(ValueTypeCollectionEntry entry) 
    {
      if (entry==null)
        throw new ArgumentNullException("entry");

      if (session.IsOfflineMode) {
        Load();
        return Implementation.Contains(entry.InternalItemID) ? entry.InternalItemID : ValueTypeCollectionEntry.UndefinedItemID;
      }

      // Automatic Transactions support code
      TransactionController tc = session.CreateTransactionController( TransactionMode.TransactionRequired);
    Reprocess:
      try {
        EnsureCacheValidity();
        if (entry.InternalItemID!=ValueTypeCollectionEntry.UndefinedItemID && entry.Collection==this &&
            Implementation.Contains(entry.InternalItemID))
          return entry.InternalItemID;
        return Implementation.GetItemId(entry.InternalValue);
      }
      catch (Exception e) {
        if (tc.Rollback(e, true))
          goto Reprocess;
        throw;
      }
    }

    // Collection interfaces support
    
    /// <summary>
    /// Gets an <see cref="IList"/> containing the list of elements in the 
    /// collection instance.
    /// </summary>
    [Transactional(TransactionMode.Disabled)]
    protected IList List {
      get {
        return this;
      }
    }
    
    /// <summary>
    /// Removes all objects from the collection instance.
    /// </summary>
    [Transactional(TransactionMode.TransactionRequired)]
    public virtual void Clear()
    {
      InnerClear();
    }
    private void InnerClear()
    {
      if (owner.State==DataObjectState.New)
        return;

      InnerLoad();
      ContentChanging();
      blockContentChangeEvent++;
      try {
        OnClear();
        int cnt = Count;
        if (hasPair || pairTo!=null) {
          while (Count!=0)
            InnerRemove(this[Count-1]);
        }
        else {
          for (int i = 0; i<cnt; i++)
            ClearReferences(this[i]);
          Implementation.Clear();
        }
        OnClearComplete();
      }
      finally {
        blockContentChangeEvent--;
      }
      ContentChanged();
    }

    /// <summary>
    /// Returns an enumerator that can iterate through the
    /// collection instance.
    /// </summary>
    /// <returns>
    /// An <see cref="IEnumerator"/> for the 
    /// collection instance.
    /// </returns>
    [Transactional(TransactionMode.Disabled)]
    public IEnumerator GetEnumerator()
    {
      Load();
      return Implementation.GetEnumerator();
    }

    /// <summary>
    /// Copies the elements of the collection to an Array, 
    /// starting at a particular Array index.
    /// </summary>
    /// <param name="array">The one-dimensional Array that is the destination of the elements copied from collection. The Array must have zero-based indexing.</param>
    /// <param name="index">The zero-based index in array at which copying begins.</param>
    [Transactional(TransactionMode.TransactionRequired)]
    public virtual void CopyTo(Array array, int index)
    {
      InnerCopyTo(array, index);
    }
    private void InnerCopyTo(Array array, int index)
    {
      if (owner.State==DataObjectState.New)
        return;

      InnerLoad();
      int i = index;
      foreach(ValueTypeCollectionEntry e in List)
        array.SetValue(e, i++);
    }

    /// <summary>
    /// Gets a value indicating whether access to the 
    /// collection is synchronized (thread-safe).
    /// </summary>
    /// <returns><see langword="True"/> if access to the collection is synchronized (thread-safe); otherwise, <see langword="false"/>.</returns>
    bool ICollection.IsSynchronized {
      get {
        return false;
      }
    }

    /// <summary>
    /// Gets an object that can be used to synchronize access to the collection.
    /// </summary>
    /// <returns>An object that can be used to synchronize access to the collection.</returns>
    object ICollection.SyncRoot {
      get {
        return this;
      }
    }

    /// <summary>
    /// Gets a value indicating whether the <see cref="IList"/> has a fixed size.
    /// </summary>
    /// <returns><see langword="Talse"/> if the <see cref="IList"/> has a fixed size; otherwise, <see langword="false"/>.</returns>
    bool IList.IsFixedSize {
      get {
        return false;
      }
    }

    /// <summary>
    /// Gets a value indicating whether the <see cref="IList"/> is read-only.
    /// </summary>
    /// <returns><see langword="Talse"/> if the <see cref="IList"/> is read-only; otherwise, <see langword="false"/>.</returns>
    bool IList.IsReadOnly  {
      get {
        return false;
      }
    }
    
    // IList methods

    /// <summary>
    /// Gets or sets the element at the specified index.
    /// </summary>
    /// <param name="index">The zero-based index of the element to get or set.</param>
    /// <returns>The element at the specified index.</returns>
    object IList.this[int index] {
      get {
        if (session.IsOfflineMode) {
          Load();
          return InnerGet(index);
        }

        // Automatic Transactions support code
        TransactionController tc = session.CreateTransactionController( TransactionMode.TransactionRequired);
      Reprocess:
        try {
          ValueTypeCollectionEntry retval = InnerGet(index);
          tc.Commit();
          return retval;
          // return retval!=null ? retval : containedField.CreateNullSubstitution();
        }
        catch (Exception e) {
          if (tc.Rollback(e, true))
            goto Reprocess;             
          throw;
        }
      }
      set {
        throw new InvalidOperationException(
          "IList.this[index]=value can't be used with ValueTypeCollection, " +
          "use ValueTypeCollectionEntry.Value=value instead.");
      }
    }
    private ValueTypeCollectionEntry InnerGet(int index)
    {
      InnerLoad();
      return Implementation.GetItem(index);
    }

    /// <summary>
    /// Determines whether collection contains a specific value.
    /// </summary>
    /// <param name="value">Value to search for.</param>
    /// <returns><see langword="True"/> if the object is found; otherwise, <see langword="false"/>.</returns>
    bool IList.Contains(object value) 
    {
      if (session.IsOfflineMode) {
        Load();
        return InnerContains(value);
      }

      // Automatic Transactions support code
      TransactionController tc = session.CreateTransactionController( TransactionMode.TransactionRequired);
    Reprocess:
      try {
        bool r = InnerContains(value);
        tc.Commit();
        return r;
      }
      catch (Exception e) {
        if (tc.Rollback(e, true))
          goto Reprocess;
        throw;
      }
    }
    private bool InnerContains(object value) 
    {
      if (value==null)
        throw new ArgumentNullException("value");
      ValueTypeCollectionEntry entry = value as ValueTypeCollectionEntry;
      if (entry==null)
        throw new ArgumentException(
          "Argument \"value\" isn't a ValueTypeCollectionEntry.");

      EnsureCacheValidity();
      if (entry.InternalItemID!=ValueTypeCollectionEntry.UndefinedItemID)
        return Implementation.Contains(entry.InternalItemID);
      return Implementation.GetItemId(entry.InternalValue)!=ValueTypeCollectionEntry.UndefinedItemID;
    }

    /// <summary>
    /// Searches for the specified value and returns the index of the first occurrence within the current instance.
    /// </summary>
    /// <param name="value">The value to locate.</param>
    /// <returns>The index of the first occurrence of value within the entire collection, if found; otherwise, -1.</returns>
    int  IList.IndexOf(object value)
    {
      if (session.IsOfflineMode) {
        Load();
        return InnerIndexOf(value);
      }

      // Automatic Transactions support code
      TransactionController tc = session.CreateTransactionController( TransactionMode.TransactionRequired);
    Reprocess:
      try {
        int r = InnerIndexOf(value);
        tc.Commit();
        return r;
      }
      catch (Exception e) {
        if (tc.Rollback(e, true))
          goto Reprocess;
        throw;
      }
    }
    private int InnerIndexOf(object value)
    {
      if (value==null)
        throw new ArgumentNullException("value");
      ValueTypeCollectionEntry entry = value as ValueTypeCollectionEntry;
      if (entry==null)
        throw new ArgumentException(
          "Argument \"value\" isn't a ValueTypeCollectionEntry.");

      InnerLoad();
      if (entry.InternalItemID!=ValueTypeCollectionEntry.UndefinedItemID)
        return Implementation.IndexOf(entry.InternalItemID);
      return Implementation.IndexOf(entry.InternalValue);
    }

    /// <summary>
    /// Inserts an element to the collection.
    /// </summary>
    /// <param name="index">The zero-based index at which value should be inserted.</param>
    /// <param name="value">Item to insert.</param>
    void IList.Insert(int index, object value)
    {
      throw new InvalidOperationException(
        "Insert method can't be used with ValueTypeCollection, use Add instead.");
    }

    /// <summary>
    /// Removes element from the the collection.
    /// </summary>
    /// <param name="value">Item to remove.</param>
    void IList.Remove(object value)
    {
      if (value==null)
        throw new ArgumentNullException("entry");
      ValueTypeCollectionEntry entry = value as ValueTypeCollectionEntry;
      if (entry==null)
        throw new ArgumentException(
          "Argument \"value\" isn't a ValueTypeCollectionEntry.");
      if (entry.Collection!=this)
        throw new ArgumentException(
          "Entry belongs to another collection.");
      Remove(this[entry.InternalItemID]);
    }
    
    /// <summary>
    /// Validating a value.
    /// </summary>
    /// <param name="value">The instance to validate.</param>
    [Transactional(TransactionMode.Disabled)]
    protected void Validate(object value)
    {
      if (itemType!=null)
        if (!itemType.IsInstanceOfType(value))
          throw new InvalidOperationException("Validation failed: invalid item type.");
      // Possible future improvement code: support of direct containment
      // of reference fields
      DataObject doValue = value as DataObject;
      if (doValue!=null) {
        if (doValue.session!=session)
          throw new InvalidOperationException("Validation failed: instance belongs to different session.");
//        if (doValue==owner && !selfRefAllowed)
//          throw new SelfReferenceException(owner);
        if (doValue.State==DataObjectState.Removed)
          throw new InstanceIsRemovedException();
        if (doValue.State==DataObjectState.New)
          doValue.Persist();
      }
      OnValidate(value);
    }

    /// <summary>
    /// Converts <see cref="ValueTypeCollection"/> instance to its offline analogue.
    /// </summary>
    object IConvertibleToOffline.ToOffline()
    {
      throw new NotImplementedException("Offline.ValueTypeCollection support is not implemented yet.");
    }
    
    // Events

    /// <summary>
    /// Performs additional custom processes when changing the contents of the 
    /// collection instance.
    /// </summary>
    [Transactional(TransactionMode.Disabled)]
    protected virtual void OnChange()
    {
    }
    
    /// <summary>
    /// Performs additional custom processes after the contents of the 
    /// collection instance was changed.
    /// </summary>
    [Transactional(TransactionMode.Disabled)]
    protected virtual void OnChangeComplete()
    {
    }
    
    /// <summary>
    /// Performs additional custom processes when clearing the contents of the 
    /// collection instance.
    /// </summary>
    [Transactional(TransactionMode.Disabled)]
    protected virtual void OnClear()
    {
    }
    
    /// <summary>
    /// Performs additional custom processes after clearing the contents of the 
    /// collection instance.
    /// </summary>
    [Transactional(TransactionMode.Disabled)]
    protected virtual void OnClearComplete()
    {
    }
    
    /// <summary>
    /// Performs additional custom processes before adding a new element into the
    /// collection instance.
    /// </summary>
    /// <param name="value">Value to add.</param>
    [Transactional(TransactionMode.Disabled)]
    protected internal virtual void OnAdd(object value) 
    {
    }
    
    /// <summary>
    /// Performs additional custom processes after adding a new element into the
    /// collection instance.
    /// </summary>
    /// <param name="value"><see cref="ValueTypeCollectionEntry"/> holding newly added item.</param>
    [Transactional(TransactionMode.Disabled)]
    protected internal virtual void OnAddComplete(ValueTypeCollectionEntry value) 
    {
    }
    
    /// <summary>
    /// Performs additional custom processes before removing the element from the
    /// collection instance.
    /// </summary>
    /// <param name="value"><see cref="ValueTypeCollectionEntry"/> holding item to remove.</param>
    [Transactional(TransactionMode.Disabled)]
    protected internal virtual void OnRemove(ValueTypeCollectionEntry value) 
    {
    }
    
    /// <summary>
    /// Performs additional custom processes after removing the element from the
    /// collection instance.
    /// </summary>
    /// <param name="itemId">ItemID (key) of removed item.</param>
    /// <param name="value">Value of removed item.</param>
    [Transactional(TransactionMode.Disabled)]
    protected internal virtual void OnRemoveComplete(long itemId, object value) 
    {
    }
    
    /// <summary>
    /// Performs additional custom processes before setting\changing a value in the
    /// collection instance.
    /// </summary>
    /// <param name="oldValue"><see cref="ValueTypeCollectionEntry"/> holding old item.</param>
    /// <param name="newValue">The new value of item to set.</param>
    [Transactional(TransactionMode.Disabled)]
    protected virtual void OnSet(ValueTypeCollectionEntry oldValue, object newValue)
    {
    }
    
    /// <summary>
    /// Performs additional custom processes after setting a value in the
    /// collection instance.
    /// </summary>
    /// <param name="newValue"><see cref="ValueTypeCollectionEntry"/> holding new item.</param>
    /// <param name="oldValue">The old value of item.</param>
    [Transactional(TransactionMode.Disabled)]
    protected virtual void OnSetComplete(ValueTypeCollectionEntry newValue, object oldValue)
    {
    }
    
    /// <summary>
    /// Performs additional custom processes when validating a value.
    /// </summary>
    /// <param name="value">The object to validate.</param>
    /// <remarks>
    /// The default implementation of this method determines whether value is a <see langword="null"/> 
    /// reference (Nothing in Visual Basic), and, if so, throws <see cref="ArgumentNullException"/>. 
    /// It is intended to be overridden by a derived class to perform additional action 
    /// when the specified element is validated.
    /// </remarks>
    [Transactional(TransactionMode.Disabled)]
    protected virtual void OnValidate(object value)
    {
    }
    
    /// <summary>
    /// Called on attachment to <see cref="DataObject"/>.
    /// </summary>
    [Transactional(TransactionMode.Disabled)]
    protected virtual void OnAttach()
    {
    }

    /// <summary>
    /// Called on recycle of this instance.
    /// </summary>
    /// <returns><see langword="True"/> if the instance was recycled 
    /// and can be reused; otherwise, <see langword="false"/>.</returns>
    [Transactional(TransactionMode.Disabled)]
    protected virtual bool OnRecycle()
    {
      return true;
    }
    
    // ToString implementation
    
    /// <summary>
    /// Returns <see cref="String"/> representation of current collection.
    /// </summary>
    /// <returns>The <see cref="String"/> representation of this collection.</returns>
    /// <remarks>
    /// This method returns <see cref="String"/> in the following format:
    /// "OwnerID=[OwnerID], PropertyName=[PropertyName]".
    /// </remarks>
    [Transactional(TransactionMode.Disabled)]
    public override string ToString()
    {
      return ToDebugString();
    }
    
    /// <summary>
    /// Returns debug <see cref="String"/> of current collection that is used for trace.
    /// </summary>
    /// <returns>Debug <see cref="String"/> of current collection.</returns>
    [Transactional(TransactionMode.Disabled)]
    protected internal virtual string ToDebugString()
    {
      return "OwnerID=" + Owner.GetInternalID() +
        ", PropertyName=" + Field.Name;
    }


    // Constructor

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="itemType">Type of collection items.</param>
    public ValueTypeCollection(System.Type itemType) : base()
    {
      this.itemType = itemType;
    }
  }
}
