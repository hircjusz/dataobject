// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Attributes;

namespace DataObjects.NET
{
  /// <summary>
  /// Enumeration of possible lock types.
  /// <seealso cref="QueryOptions"/>
  /// <seealso cref="DataObject.Lock"/>
  /// </summary>
  public enum LockType
  {
    /// <summary>
    /// None.
    /// Value is <see langword="0"/>. 
    /// </summary>
    None = 0,
    /// <summary>
    /// Locks of this type are automatically applied to all instances
    /// accessed by the queries till the end of transaction on the
    /// Repeatable Read isolation level and higher.
    /// Value is <see langword="1"/>. 
    /// </summary>
    Shared = 1,
    /// <summary>
    /// Update lock. Used on resources that can be updated. Prevents a common 
    /// form of deadlock that occurs when multiple sessions are reading, locking, 
    /// and potentially updating resources later.
    /// Value is <see langword="2"/>. 
    /// </summary>
    Update = 2,
    /// <summary>
    /// Exclusive lock. Used for data-modification operations. Ensures that 
    /// multiple updates cannot be made to the same resource at the same time.
    /// Value is <see langword="4"/>. 
    /// </summary>
    Exclusive = 4
  }
}
