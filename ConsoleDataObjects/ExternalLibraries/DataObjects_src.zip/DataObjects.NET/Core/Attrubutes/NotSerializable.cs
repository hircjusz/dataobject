// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using DataObjects.NET.Serialization;

namespace DataObjects.NET.Attributes
{
  /// <summary>
  /// Indicates that value of the property shouldn't be serialized/deserialized
  /// by <see cref="Serializer"/>.
  /// </summary>
  /// <remarks>
  /// <note>This attribute can be applied to persistent properties of any type.</note>
  /// <para>
  /// <example>Example:
  /// <code lang="C#">
  ///  public abstract class Person: DataObject
  ///  {
  ///    [Length(128)]
  ///    public abstract string FirstName {get; set;}
  ///    
  ///    [Length(128)]
  ///    public abstract string SecondName {get; set;}
  ///    
  ///    [Length(128)]
  ///    public abstract string Surname {get; set;}
  ///
  ///    // Look below, this is a calculated persistent property,
  ///    // so it isn't necessary to serialize it, since it can be
  ///    // re-calculated on deserialization.
  ///    [Length(768)]
  ///    [NotSerializable] // !!!
  ///    public abstract string FullName {get; set;}
  ///
  ///    ...
  ///
  ///    // This method is be virtual, because it should require a transaction
  ///    // to run. Actually all methods require a transaction to run by default,
  ///    // but an exception will be thrown if you'll declare a not virtual method
  ///    // without explicitely marking it as not transactional.
  ///    protected virtual void UpdateFullName()
  ///    {
  ///      FullName = (FirstName.Trim() + " " + 
  ///        SecondName.Trim() + " " + 
  ///        Surname.Trim()).Trim();
  ///    }
  ///
  ///    protected override void OnPropertyChanged(string name, Culture culture, object value)
  ///    {
  ///      base.OnPropertyChanged (name, culture, value);
  ///      if (name=="FirstName" || name=="SecondName" || name=="Surname")
  ///        UpdateFullName();
  ///    }
  ///    
  ///    protected override void OnDeserialized(DataObjects.NET.Serialization.Serializer serializer)
  ///    {
  ///      base.OnDeserialized (serializer);
  ///      UpdateFullName();
  ///    }
  ///
  ///    ...
  ///  }
  /// </code>
  /// </example>
  /// </para>
  /// <seealso cref="Serializer"/>
  /// </remarks>
  [AttributeUsage(AttributeTargets.Property, AllowMultiple = false, Inherited = true)]
  [Serializable]
  public class NotSerializableAttribute: DataObjectAttribute
  {
    private bool nonSerializable = true;
    /// <summary>
    /// <see langword="True"/> if property value shouldn't be serialized.
    /// <seealso cref="Serializer"/>.
    /// </summary>
    public  bool NotSerializable 
    {
      get {return nonSerializable;}
      set {nonSerializable = value;}
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    public NotSerializableAttribute() 
    {
    }
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="nonSerializable"><see langword="True"/> if property value is <see langword="null"/>able.</param>
    public NotSerializableAttribute(bool nonSerializable) 
    {
      this.nonSerializable = nonSerializable;
    }
  }
}
