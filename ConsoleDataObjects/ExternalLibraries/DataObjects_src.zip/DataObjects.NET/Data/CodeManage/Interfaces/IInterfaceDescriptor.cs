// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;

namespace DataObjects.NET.Data.CodeManage
{
  /// <summary>
  /// Describes an interface.
  /// </summary>
  internal interface IInterfaceDescriptor: IFieldContainerDescriptor
  {
    /// <summary>
    /// Gets base type descriptor.
    /// Always returns a descriptor of a <see cref="DataObjects.NET.DataObject"/> class.
    /// </summary>
    IClassDescriptor BaseType {get;}
    
    /// <summary>
    /// Gets child collections.
    /// </summary>
    ICollectionDescriptor[] Collections {get;}
    
    /// <summary>
    /// Gets implemented interfaces.
    /// </summary>
    IInterfaceDescriptor[] Implements {get;}
  }
}
