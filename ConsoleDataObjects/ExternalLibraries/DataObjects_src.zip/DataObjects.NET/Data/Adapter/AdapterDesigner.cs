// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license

using System;
using System.ComponentModel.Design;
using System.Data;
using System.Windows.Forms;
using DataObjects.NET.Data;

namespace DataObjects.NET.Data.Design
{
  /// <summary>
  /// Designer for <see cref="Adapter"/> component.
  /// </summary>
  public class AdapterDesigner: ComponentDesigner
  {
    /// <summary>
    /// Gets the design-time verbs supported by the component that is associated with the designer.
    /// </summary>
    public override DesignerVerbCollection Verbs {
      get {
        return new DesignerVerbCollection(
          new DesignerVerb[] {
            new DesignerVerb("Clear mappings", new EventHandler(OnClearMap)),
            new DesignerVerb("Create mappings", new EventHandler(OnAutoMap)),
            new DesignerVerb("Prepare DataSource", new EventHandler(OnPrepareDataSource))
            });
      }
    }
    
    private void OnClearMap(object sender, EventArgs e)
    {
      if (MessageBox.Show(
            "This operation will completely remove all mappings that were manually or automatically created. Continue?",
            "Confirm mapping removal",
            MessageBoxButtons.YesNo, 
            MessageBoxIcon.Question)==DialogResult.Yes) {
            
        IComponentChangeService componentChangeService = (IComponentChangeService)GetService(typeof(IComponentChangeService));
        
        componentChangeService.OnComponentChanging(this, null);
        ((Adapter)Component).ClearMapping();        
        componentChangeService.OnComponentChanged(this, null, null, null);
        
        MessageBox.Show(
          "All mappings were successfully removed.",
          "Information",
          MessageBoxButtons.OK,
          MessageBoxIcon.Information);
      }
    }
    
    private void OnAutoMap(object sender, EventArgs e)
    {
      IComponentChangeService componentChangeService = (IComponentChangeService)GetService(typeof(IComponentChangeService));
      
      componentChangeService.OnComponentChanging(this, null);
      MappingLog log = ((Adapter)Component).GenerateMappings();
      componentChangeService.OnComponentChanged(this, null, null, null);
        
      LogWindow logWindow = new LogWindow(log);
      logWindow.ShowDialog();
    }
    
    private void OnPrepareDataSource(object sender, EventArgs e)
    {
      Adapter adapter = (Adapter)Component;
      DataSet dataSet = adapter.dataSource;
      
      if (dataSet==null) {
        MessageBox.Show(
          "DataSource is null.",
          "Error",
          MessageBoxButtons.OK,
          MessageBoxIcon.Error);
        return;
      }

      IComponentChangeService componentChangeService = (IComponentChangeService)GetService(typeof(IComponentChangeService));      
      IComponentChangeService dataSetChangeService = (IComponentChangeService)dataSet.GetService(typeof(IComponentChangeService));
      
      componentChangeService.OnComponentChanging(this, null);
      dataSetChangeService.OnComponentChanging(dataSet, null);
      adapter.PrepareDataSource();
      dataSetChangeService.OnComponentChanged(dataSet, null, null, null);
      componentChangeService.OnComponentChanged(this, null, null, null);
      
      MessageBox.Show(
        "DataSource has been successfully prepared.",
        "Information",
        MessageBoxButtons.OK,
        MessageBoxIcon.Information);
    }
  }
}
