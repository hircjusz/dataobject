// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.IO;
using System.Collections;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Attributes;

namespace DataObjects.NET
{
  /// <summary>
  /// Base class for any collections that should be marshalled by 
  /// reference via .NET Remoting.
  /// </summary>
  [Serializable]
  #if (!NoMBR)
  public abstract class MarshalByRefCollectionBase: MarshalByRefObject, 
  #else
  public abstract class MarshalByRefCollectionBase: Object, 
  #endif
    IList, ICollection, IEnumerable, IDebugDump
  {
    private IList list = new ArrayList();
    
    /// <summary>
    /// Gets the number of elements contained in the 
    /// <see cref="MarshalByRefCollectionBase"/> instance.
    /// </summary>
    public int Count {
      get {
        return list.Count;
      }
    }
    
    /// <summary>
    /// Gets or sets an ArrayList containing the list of elements in the 
    /// <see cref="MarshalByRefCollectionBase"/> instance.
    /// </summary>
    protected IList InnerList {
      get {
        return list;
      }
      set {
        list = value;
      }
    }
    
    /// <summary>
    /// Gets an <see cref="IList"/> containing the list of elements in the 
    /// <see cref="MarshalByRefCollectionBase"/> instance.
    /// </summary>
    protected IList List {
      get {
        return (IList)this;
      }
    }
    
    /// <summary>
    /// Removes all objects from the 
    /// <see cref="MarshalByRefCollectionBase"/> instance.
    /// </summary>
    public void Clear() 
    {
      OnChange();
      OnClear();
      InnerList.Clear();
      OnClearComplete();
      OnChangeComplete();
    }
    
    /// <summary>
    /// Returns an enumerator that can iterate through the
    /// <see cref="MarshalByRefCollectionBase"/> instance.
    /// </summary>
    /// <returns>
    /// An <see cref="IEnumerator"/> for the 
    /// <see cref="MarshalByRefCollectionBase"/> instance.
    /// </returns>
    public virtual IEnumerator GetEnumerator()
    {
      return new MarshalByRefCollectionBaseEnumerator(this, InnerList.GetEnumerator());
    }
    
    /// <summary>
    /// Removes the element at the specified index of the
    /// <see cref="MarshalByRefCollectionBase"/> instance.
    /// </summary>
    /// <param name="index">The zero-based index of the element to remove.</param>
    /// <remarks>
    /// In collections of contiguous elements, such as lists, the elements that 
    /// follow the removed element move up to occupy the vacated spot. If the collection 
    /// is indexed, the indexes of the elements that are moved are also updated. This 
    /// behavior does not apply to collections where elements are conceptually grouped 
    /// into buckets, such as a hashtable.
    /// </remarks>
    /// <exception cref="ArgumentOutOfRangeException">
    /// index is less than zero, or
    /// index is equal to or greater than Count.
    /// </exception>
    public void RemoveAt(int index)
    {
      if (index<0 || index>=InnerList.Count)
        throw new ArgumentOutOfRangeException("Index is out of range.");
      Object o = InnerList[index];
      OnValidate(o);
      OnChange();
      OnRemove(index,o);
      InnerList.RemoveAt(index);
      OnRemoveComplete(index,o);  
      OnChangeComplete();
    }
    
    // ICollection methods implementation

    /// <summary>
    /// Copies the elements of the collection to an Array, 
    /// starting at a particular Array index.
    /// </summary>
    /// <param name="array">The one-dimensional Array that is the destination of the elements copied from collection. The Array must have zero-based indexing.</param>
    /// <param name="index">The zero-based index in array at which copying begins.</param>
    void ICollection.CopyTo(Array array, int index)
    {
      InnerList.CopyTo(array, index);
    }
    
    /// <summary>
    /// Gets a value indicating whether access to the 
    /// collection is synchronized (thread-safe).
    /// </summary>
    /// <returns><see langword="True"/> if access to the collection is synchronized (thread-safe); otherwise, <see langword="false"/>.</returns>
    bool ICollection.IsSynchronized {
      get {
        return InnerList.IsSynchronized;
      }
    }
    
    /// <summary>
    /// Gets an object that can be used to synchronize access to the collection.
    /// </summary>
    /// <returns>An object that can be used to synchronize access to the collection.</returns>
    object ICollection.SyncRoot {
      get {
        return InnerList.SyncRoot;
      }
    }
    
    // IList methods implementation

    /// <summary>
    /// Gets a value indicating whether the <see cref="IList"/> has a fixed size.
    /// </summary>
    /// <returns><see langword="True"/> if the <see cref="IList"/> has a fixed size; otherwise, <see langword="false"/>.</returns>
    bool IList.IsFixedSize {
      get {
        return InnerList.IsFixedSize;
      }
    }
    
    /// <summary>
    /// Gets a value indicating whether the <see cref="IList"/> is read-only.
    /// </summary>
    /// <returns><see langword="True"/> if the <see cref="IList"/> is read-only; otherwise, <see langword="false"/>.</returns>
    bool IList.IsReadOnly {
      get {
        return InnerList.IsReadOnly;
      }
    }
    
    /// <summary>
    /// Gets or sets the element at the specified index.
    /// </summary>
    /// <param name="index">The zero-based index of the element to get or set.</param>
    /// <returns>The element at the specified index.</returns>
    object IList.this[int index] {
      get {
        return InnerList[index];
      }
      set {
        if (index<0 || index>=InnerList.Count)
          throw new ArgumentOutOfRangeException("Index is out of range.");
        Object oldValue = InnerList[index];
        if (oldValue==value)
          return;
        OnValidate(value);
        OnChange();
        OnSet(index,oldValue,value);
        InnerList[index] = value;
        try {
          OnSetComplete(index,oldValue,value);
          OnChangeComplete();
        }
        catch (Exception) {
          InnerList[index] = oldValue;
          throw;
        }
      }
    }
    
    /// <summary>
    /// Adds new element to the collection.
    /// </summary>
    /// <param name="value">Item to add.</param>
    /// <returns>Index of newly added item.</returns>
    int  IList.Add(Object value) 
    {
      OnValidate(value);
      int c = InnerList.Count;
      OnChange();
      OnInsert(c,value);
      int r = InnerList.Add(value);
      try {
        OnInsertComplete(c,value);
        OnChangeComplete();
      }
      catch (Exception) {
        InnerList.RemoveAt(r);
        throw;
      }
      return r;
    }
    
    /// <summary>
    /// Determines whether collection contains a specific value.
    /// </summary>
    /// <param name="value">Value to search for.</param>
    /// <returns><see langword="True"/> if the object is found; otherwise, <see langword="false"/>.</returns>
    bool IList.Contains(Object value)
    {
      return InnerList.Contains(value);
    }
    
    /// <summary>
    /// Searches for the specified value and returns the index of the first occurrence within the current instance.
    /// </summary>
    /// <param name="value">The value to locate.</param>
    /// <returns>The index of the first occurrence of value within the entire collection, if found; otherwise, -1.</returns>
    int  IList.IndexOf(Object value)
    {
      return InnerList.IndexOf(value);
    }
    
    /// <summary>
    /// Inserts an element to the collection.
    /// </summary>
    /// <param name="index">The zero-based index at which value should be inserted.</param>
    /// <param name="value">Item to insert.</param>
    void IList.Insert(int index, Object value)
    {
      if (index<0 || index>InnerList.Count)
        throw new ArgumentOutOfRangeException("Index is out of range.");
      OnValidate(value);
      OnChange();
      OnInsert(index,value);
      InnerList.Insert(index,value);
      try {
        OnInsertComplete(index,value);
        OnChangeComplete();
      }
      catch (Exception) {
        InnerList.RemoveAt(index);
        throw;
      }
    }
    
    /// <summary>
    /// Removes element from the the collection.
    /// </summary>
    /// <param name="value">Item to remove.</param>
    void IList.Remove(Object value)
    {
      OnValidate(value);
      int i = InnerList.IndexOf(value);
      if (i<0)
        throw new ArgumentException("Argument wasn't found.");
      OnChange();
      OnRemove(i,value);
      InnerList.RemoveAt(i);
      OnRemoveComplete(i,value);  
      OnChangeComplete();
    }


    // Events

    /// <summary>
    /// Performs additional custom processes when changing the contents of the 
    /// <see cref="MarshalByRefCollectionBase"/> instance.
    /// </summary>
    protected virtual void OnChange()
    {
    }
    
    /// <summary>
    /// Performs additional custom processes after the contents of the 
    /// <see cref="MarshalByRefCollectionBase"/> instance was changed.
    /// </summary>
    protected virtual void OnChangeComplete()
    {
    }
    
    /// <summary>
    /// Performs additional custom processes when clearing the contents of the 
    /// <see cref="MarshalByRefCollectionBase"/> instance.
    /// </summary>
    protected virtual void OnClear()
    {
    }
    
    /// <summary>
    /// Performs additional custom processes after clearing the contents of the 
    /// <see cref="MarshalByRefCollectionBase"/> instance.
    /// </summary>
    protected virtual void OnClearComplete()
    {
    }
    
    /// <summary>
    /// Performs additional custom processes before inserting a new element into the
    /// <see cref="MarshalByRefCollectionBase"/> instance.
    /// </summary>
    /// <param name="index">The zero-based <paramref name="index"/> at which to insert value.</param>
    /// <param name="value">The new value of the element at <paramref name="index"/>.</param>
    protected virtual void OnInsert(int index, Object value) 
    {
    }
    
    /// <summary>
    /// Performs additional custom processes after inserting a new element into the
    /// <see cref="MarshalByRefCollectionBase"/> instance.
    /// </summary>
    /// <param name="index">The zero-based <paramref name="index"/> at which to insert value.</param>
    /// <param name="value">The new value of the element at <paramref name="index"/>.</param>
    protected virtual void OnInsertComplete(int index, Object value) 
    {
    }
    
    /// <summary>
    /// Performs additional custom processes before removing a new element into the
    /// <see cref="MarshalByRefCollectionBase"/> instance.
    /// </summary>
    /// <param name="index">The zero-based <paramref name="index"/> at which to insert value.</param>
    /// <param name="value">The value of the element to remove from <paramref name="index"/>.</param>
    protected virtual void OnRemove(int index, Object value) 
    {
    }
    
    /// <summary>
    /// Performs additional custom processes after removing a new element into the
    /// <see cref="MarshalByRefCollectionBase"/> instance.
    /// </summary>
    /// <param name="index">The zero-based <paramref name="index"/> at which to insert value.</param>
    /// <param name="value">The value of the element to remove from <paramref name="index"/>.</param>
    protected virtual void OnRemoveComplete(int index, Object value) 
    {
    }
    
    /// <summary>
    /// Performs additional custom processes before setting a value in the
    /// <see cref="MarshalByRefCollectionBase"/> instance.
    /// </summary>
    /// <param name="index">The zero-based <paramref name="index"/> at which <paramref name="oldValue"/> can be found.</param>
    /// <param name="oldValue">The value to replace with <paramref name="newValue"/>.</param>
    /// <param name="newValue">The new value of the element at <paramref name="index"/>.</param>
    protected virtual void OnSet(int index, Object oldValue, Object newValue)
    {
    }
    
    /// <summary>
    /// Performs additional custom processes after setting a value in the
    /// <see cref="MarshalByRefCollectionBase"/> instance.
    /// </summary>
    /// <param name="index">The zero-based <paramref name="index"/> at which <paramref name="oldValue"/> can be found.</param>
    /// <param name="oldValue">The value to replace with <paramref name="newValue"/>.</param>
    /// <param name="newValue">The new value of the element at <paramref name="index"/>.</param>
    protected virtual void OnSetComplete(int index, Object oldValue, Object newValue)
    {
    }
    
    /// <summary>
    /// Performs additional custom processes when validating a value.
    /// </summary>
    /// <param name="value">The object to validate.</param>
    /// <remarks>
    /// The default implementation of this method determines whether value is a <see langword="null"/> 
    /// reference (Nothing in Visual Basic), and, if so, throws <see cref="ArgumentNullException"/>. 
    /// It is intended to be overridden by a derived class to perform additional action 
    /// when the specified element is validated.
    /// </remarks>
    protected virtual void OnValidate(Object value)
    {
      if (value==null)
        throw new ArgumentNullException("value");
    }
    
    
    // Constructors

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <remarks>
    /// This constructor is called by derived class constructors to initialize state in this type.
    /// </remarks>
    protected MarshalByRefCollectionBase()
    {
    }
    
    
    // IDumpable support

    /// <summary>
    /// Dumps the content of the instance.
    /// </summary>
    /// <param name="output">Writer to output to.</param>
    /// <param name="indent">Indent.</param>
    public virtual void Dump(TextWriter output, string indent)
    {
      output.WriteLine(indent+"("+GetType().Name+"):");
      DumpMembers(output, indent+" ");
    }

    /// <summary>
    /// Dumps all member properties of the instance.
    /// </summary>
    /// <param name="output">Writer to output to.</param>
    /// <param name="indent">Indent.</param>
    public virtual void DumpMembers(TextWriter output, string indent)
    {
      int i = 0;
      if (Count!=0) {
        IList list = List;
        if (list[0] is IComparable) try {
          ArrayList copyList = new ArrayList(InnerList);
          copyList.Sort();
          list = copyList; 
        } catch {}
        output.WriteLine(indent+"List:");
        foreach (Object item in list) {
          output.WriteLine(indent+"#{0}:",i++);
          DumpItem(item,output,indent+" ");
        }
      }
      else
        output.WriteLine(indent+"Empty");
    }
    
    /// <summary>
    /// Dumps collection item.
    /// </summary>
    /// <param name="item">Item to dump.</param>
    /// <param name="output">Writer to output to.</param>
    /// <param name="indent">Indent.</param>
    public virtual void DumpItem(Object item, TextWriter output, string indent)
    {
      IDebugDump itemd = item as IDebugDump;
      if (itemd!=null)
        itemd.Dump(output,indent);
      else
        output.WriteLine(indent+item.ToString());
    }
  }
}
