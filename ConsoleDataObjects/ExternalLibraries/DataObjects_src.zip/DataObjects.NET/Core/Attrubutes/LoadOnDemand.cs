// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;

namespace DataObjects.NET.Attributes
{
  /// <summary>
  /// Indicates that value of the property should be loaded on the first
  /// access, but not on the instance loading.
  /// </summary>
  /// <remarks>
  /// <note>This attribute can be applied to persistent properties of any type.
  /// All collection properties (see <see cref="DataObjectCollection"/>) are
  /// always loaded on demand.</note>
  /// This attribute is a <see cref="DriverTypeSpecificAttribute">driver type-specific</see>,
  /// that means that it can be applied multiple times (with different parameters). 
  /// Each its application can be used or not - dependently on the current type 
  /// of the database driver. 
  /// See <see cref="DriverTypeSpecificAttribute.DriverTypes"/> property
  /// for further information.
  /// <para>
  /// <example>Example:
  /// <code lang="C#">
  ///  public abstract class Article: DataObject
  ///  {
  ///    [LoadOnDemand] // !!!
  ///    public abstract string Content {get; set;}
  ///    
  ///    ...
  ///  }
  /// </code>
  /// </example>
  /// </para>
  /// </remarks>
  [AttributeUsage(AttributeTargets.Property, AllowMultiple = true, Inherited = true)]
  [Serializable]
  public class LoadOnDemandAttribute: DriverTypeSpecificAttribute
  {
    private bool loadOnDemand = true;
    private int  threshold = 0;
    /// <summary>
    /// <see langword="True"/> if property value should be loaded on demand.
    /// </summary>
    public  bool LoadOnDemand 
    {
      get {return loadOnDemand;}
      set {loadOnDemand = value;}
    }
    
    /// <summary>
    /// Gets or sets the threshold value.
    /// </summary>
    public int Threshold {
      get {
        return threshold;
      }
      set {
        if (!loadOnDemand)
          throw new InvalidOperationException("The threshold is available only for properties are intended to be loaded on demand.");
        if (value>=0)
          threshold = value;
        else
          throw new ArgumentOutOfRangeException("value", "Argument should be greater or equal to zero.");
      }
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    public LoadOnDemandAttribute() 
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="loadOnDemand"><see langword="True"/> if property value should be loaded on demand.</param>
    public LoadOnDemandAttribute(bool loadOnDemand) 
    {
      this.loadOnDemand = loadOnDemand;
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="threshold">The threshold value. If the size of property is greater than threshold then property value should be loaded on demand.</param>
    public LoadOnDemandAttribute(int threshold) 
    {
      this.Threshold = threshold;
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="loadOnDemand"><see langword="True"/> if property value should be loaded on demand.</param>
    /// <param name="threshold">The threshold value. If the size of property is greater than threshold then property value should be loaded on demand.</param>
    public LoadOnDemandAttribute(bool loadOnDemand, int threshold) 
    {
      this.loadOnDemand = loadOnDemand;
      this.Threshold    = threshold;
    }
  }
}
