// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.IO;
using System.Threading;
using System.Configuration;
using System.Diagnostics;
using System.Globalization;
using System.Collections;
using DataObjects.NET;
using DataObjects.NET.Attributes;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Serialization;

namespace DataObjects.NET.Security
{
  /// <summary>
  /// This tagging interface should be implemented by any
  /// <see cref="DataObject"/> descendant that has no its
  /// own <see cref="AccessControlList"/>.
  /// <seealso cref="AccessControlList"/>
  /// <seealso cref="IDataObject"/>
  /// <seealso cref="DataObject"/>
  /// </summary>
  /// <remarks>
  /// <para>
  /// You can find more information about the whole DataObjects.NET
  /// security system <see cref="AccessControlList">here</see>.
  /// </para>
  /// <para>
  /// If some type is tagged by this interface, its <see cref="DataObject.Permissions"/>
  /// property always returns <see langword="null"/>, and any
  /// security <see cref="DataObject.Demand"/>s or <see cref="DataObject.IsAllowed"/>
  /// calls are forwarded to its <see cref="DataObject.SecurityParent"/>.
  /// </para>
  /// </remarks>
  public interface IHasNoAccessControlList: IDataObject
  {
  }
}
