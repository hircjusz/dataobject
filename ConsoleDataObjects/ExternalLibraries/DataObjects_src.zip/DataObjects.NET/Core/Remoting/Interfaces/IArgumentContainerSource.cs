// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

namespace DataObjects.NET.Remoting
{
  /// <summary>
  /// This interface should be implemented by any type that is capable of generating its own
  /// <see cref="ArgumentContainer"/> instance by its content.
  /// </summary>
  public interface IArgumentContainerSource
  {
    /// <summary>
    /// Creates source's representation as <see cref="ArgumentContainer"/> object.
    /// </summary>
    ArgumentContainer CreateParameter ();
  }
}
