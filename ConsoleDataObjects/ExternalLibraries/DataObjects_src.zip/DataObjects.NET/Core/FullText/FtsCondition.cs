// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Globalization;
using DataObjects.NET;

namespace DataObjects.NET.FullText
{
  /// <summary>
  /// Describes full-text search condition for the <see cref="SqlQuery"/>.
  /// Immutable class.
  /// <seealso cref="SqlQuery.FtsCondition"/>
  /// <seealso cref="DataObjects.NET.SqlQuery.CreateFtsCondition"/>
  /// <seealso cref="SqlQuery"/>
  /// <seealso cref="Query"/>
  /// </summary>
  /// <remarks>
  /// <para>
  /// You should consider the following rules while using this class:
  /// </para>
  /// <para>
  /// 1) Full-text search is performed on <see cref="FtRecord"/> objects (i.e. 
  ///    over column(s) of table related to this type). See 
  ///    <see cref="DataObjects.NET.FullText">DataObjects.NET.FullText</see>
  ///    namespace for further information.
  /// </para>
  /// <para>
  /// 2) If <see cref="Culture"/> is <see langword="null"/>, full-text
  ///    search will be performed over all registered <see cref="Culture"/>s. 
  ///    Note that this feature won't work on Microsoft SQL Server (and MSDE), 
  ///    if there is more then one LCID used with all these <see cref="Culture"/>s. 
  ///    This means that generally you shouldn't use this mode if you 
  ///    have more than one <see langword="different"/> <see cref="Culture"/> 
  ///    registered in the <see cref="Domain"/>
  ///    (also you can register a set of <see cref="Culture"/>s with the same
  ///    <see cref="CultureInfo"/> - in this case you'll be able to perform 
  ///    full-text search through all registered cultures in a single query).
  ///    So it depends on the underlying database server whether the full-text 
  ///    search through all <see cref="Culture"/>s will work or not. But
  ///    you can always use it with <see cref="FtsMode.LikeExpression"/>.
  /// </para>
  /// <para>
  /// 3) You can use <see langword="FullTextRank"/> column in the 
  ///    <see langword="order by"/> clause, if <see cref="Mode"/> is
  ///    <see cref="FtsMode.FreeText"/> or 
  ///    <see cref="FtsMode.Condition"/>. But you can't use
  ///    this column if <see cref="Mode"/> is 
  ///    <see cref="FtsMode.LikeExpression"/>.
  /// </para>
  /// </remarks>
  [Serializable]
  public sealed class FtsCondition
    : ICloneable
  {
    private FtsMode mode;
    /// <summary>
    /// Full-text search mode.
    /// </summary>
    public  FtsMode Mode {
      get {return mode;}
    }
    
    private string condition;
    /// <summary>
    /// Full-text search condition.
    /// </summary>
    public  string Condition {
      get {return condition;}
    }
    
    internal int top;
    /// <summary>
    /// Top-n-by-rank value, 0 means all.
    /// </summary>
    public  int Top {
      get {return top;}
    }
    
    internal bool orderByRank = false;
    /// <summary>
    /// Specifies whether results should be ordered by full-text search rank.
    /// When <see langword="true"/>, results are ordered by full-text search rank;
    /// otherwise results order is governed by "order by" clause of the query.
    /// </summary>
    public bool OrderByRank {
      get { return orderByRank; }
    }

    internal Session session;
    
    private Culture culture;
    /// <summary>
    /// Culture.
    /// </summary>
    public  Culture Culture {
      get {return culture;}
    }
    
    private ObjectModel.Type requestedType = null;

    /// <summary>
    /// Gets the <see cref="ObjectModel.Type"/> requested by 
    /// full-text query.
    /// </summary>
    public ObjectModel.Type RequestedType {
      get {
        return this.requestedType;
      }
    }

    // ICloneable support
    
    /// <summary>
    /// Creates a new object that is a copy of the current instance.
    /// </summary>
    /// <returns>A new object that is a copy of this instance.</returns>
    object ICloneable.Clone()
    {
      FtsCondition fts = new FtsCondition(
        culture, mode, condition, orderByRank, top);
      return fts;
    }
    
    /// <summary>
    /// Creates a new object that is a copy of the current instance.
    /// </summary>
    /// <returns>A clone of the instance.</returns>
    public FtsCondition Clone()
    {
      FtsCondition fts = new FtsCondition(
        requestedType, culture, mode, condition, orderByRank, top);
      return fts;
    }

    
    /// <summary>
    /// Initializes a new instance of this class.
    /// <seealso cref="DataObjects.NET.SqlQuery.CreateFtsCondition"/>
    /// </summary>
    /// <param name="requestedType">The <see cref="ObjectModel.Type"/> of the requested objects.</param>
    /// <param name="culture">Culture (specify if field is translatable).</param>
    /// <param name="mode">Search mode.</param>
    /// <param name="condition">Search string\condition (depends on <paramref name="mode"/>).</param>
    /// <param name="orderByRank">Specifies whether to other returned data by full-text search rank, or not.</param>
    /// <param name="topNByRank">Top-N-by-rank value, 0 means all.</param>
    public FtsCondition(
      ObjectModel.Type requestedType,
      Culture culture,
      FtsMode mode,
      string condition,
      bool orderByRank,
      int topNByRank)
    {
      this.requestedType = requestedType;
      this.culture = culture;
      this.mode = mode;
      this.condition = condition;
      this.top = topNByRank;
      this.orderByRank = orderByRank;
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// <seealso cref="DataObjects.NET.SqlQuery.CreateFtsCondition"/>
    /// </summary>
    /// <param name="culture">Culture (specify if field is translatable).</param>
    /// <param name="mode">Search mode.</param>
    /// <param name="condition">Search string\condition (depends on <paramref name="mode"/>).</param>
    /// <param name="orderByRank">Specifies whether to other returned data by full-text search rank, or not.</param>
    /// <param name="topNByRank">Top-N-by-rank value, 0 means all.</param>
    public FtsCondition(
      Culture culture,
      FtsMode mode,
      string condition,
      bool orderByRank,
      int topNByRank)
    {
      this.culture = culture;
      this.mode = mode;
      this.condition = condition;
      this.top = topNByRank;
      this.orderByRank = orderByRank;
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// <seealso cref="DataObjects.NET.SqlQuery.CreateFtsCondition"/>
    /// </summary>
    /// <param name="requestedType">The <see cref="ObjectModel.Type"/> of the requested objects.</param>
    /// <param name="culture">Culture (specify if field is translatable).</param>
    /// <param name="mode">Search mode.</param>
    /// <param name="condition">Search string\condition (depends on <paramref name="mode"/>).</param>
    /// <param name="orderByRank">Specifies whether to other returned data by full-text search rank, or not.</param>
    public FtsCondition(
      ObjectModel.Type requestedType,
      Culture culture,
      FtsMode mode,
      string condition,
      bool orderByRank): this(requestedType, culture, mode, condition, orderByRank, 0)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// <seealso cref="DataObjects.NET.SqlQuery.CreateFtsCondition"/>
    /// </summary>
    /// <param name="culture">Culture (specify if field is translatable).</param>
    /// <param name="mode">Search mode.</param>
    /// <param name="condition">Search string\condition (depends on <paramref name="mode"/>).</param>
    /// <param name="orderByRank">Specifies whether to other returned data by full-text search rank, or not.</param>
    public FtsCondition(
      Culture culture,
      FtsMode mode,
      string condition,
      bool orderByRank): this(culture, mode, condition, orderByRank, 0)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// <seealso cref="DataObjects.NET.SqlQuery.CreateFtsCondition"/>
    /// </summary>
    /// <param name="requestedType">The <see cref="ObjectModel.Type"/> of the requested objects.</param>
    /// <param name="culture">Culture (specify if field is translatable).</param>
    /// <param name="mode">Search mode.</param>
    /// <param name="condition">Search string\condition (depends on <paramref name="mode"/>).</param>
    /// <param name="topNByRank">Top-N-by-rank value, 0 means all.</param>
    public FtsCondition(
      ObjectModel.Type requestedType,
      Culture culture,
      FtsMode mode,
      string condition,
      int topNByRank)
    {
      this.requestedType = requestedType;
      this.culture = culture;
      this.mode = mode;
      this.condition = condition;
      this.top = topNByRank;
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// <seealso cref="DataObjects.NET.SqlQuery.CreateFtsCondition"/>
    /// </summary>
    /// <param name="culture">Culture (specify if field is translatable).</param>
    /// <param name="mode">Search mode.</param>
    /// <param name="condition">Search string\condition (depends on <paramref name="mode"/>).</param>
    /// <param name="topNByRank">Top-N-by-rank value, 0 means all.</param>
    public FtsCondition(
      Culture culture,
      FtsMode mode,
      string condition,
      int topNByRank)
    {
      this.culture = culture;
      this.mode = mode;
      this.condition = condition;
      this.top = topNByRank;
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// <seealso cref="DataObjects.NET.SqlQuery.CreateFtsCondition"/>
    /// </summary>
    /// <param name="requestedType">The <see cref="ObjectModel.Type"/> of the requested objects.</param>
    /// <param name="culture">Culture (specify if field is translatable).</param>
    /// <param name="mode">Search mode.</param>
    /// <param name="condition">Search string\condition (depends on <paramref name="mode"/>).</param>
    public FtsCondition(
      ObjectModel.Type requestedType,
      Culture culture,
      FtsMode mode,
      string condition): this(requestedType, culture, mode, condition, 0)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// <seealso cref="DataObjects.NET.SqlQuery.CreateFtsCondition"/>
    /// </summary>
    /// <param name="culture">Culture (specify if field is translatable).</param>
    /// <param name="mode">Search mode.</param>
    /// <param name="condition">Search string\condition (depends on <paramref name="mode"/>).</param>
    public FtsCondition(
      Culture culture,
      FtsMode mode,
      string condition): this(culture, mode, condition, 0)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// <seealso cref="DataObjects.NET.SqlQuery.CreateFtsCondition"/>
    /// </summary>
    /// <param name="requestedType">The <see cref="ObjectModel.Type"/> of the requested objects.</param>
    /// <param name="mode">Search mode.</param>
    /// <param name="condition">Search string\condition (depends on <paramref name="mode"/>).</param>
    /// <param name="topNByRank">Top-b-by-rank value, 0 means all.</param>
    public FtsCondition(
      ObjectModel.Type requestedType,
      FtsMode mode,
      string condition,
      int topNByRank)
    {
      this.requestedType = requestedType;
      this.mode = mode;
      this.condition = condition;
      this.top = topNByRank;
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// <seealso cref="DataObjects.NET.SqlQuery.CreateFtsCondition"/>
    /// </summary>
    /// <param name="mode">Search mode.</param>
    /// <param name="condition">Search string\condition (depends on <paramref name="mode"/>).</param>
    /// <param name="topNByRank">Top-b-by-rank value, 0 means all.</param>
    public FtsCondition(
      FtsMode mode,
      string condition,
      int topNByRank)
    {
      this.mode = mode;
      this.condition = condition;
      this.top = topNByRank;
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// <seealso cref="DataObjects.NET.SqlQuery.CreateFtsCondition"/>
    /// </summary>
    /// <param name="requestedType">The <see cref="ObjectModel.Type"/> of the requested objects.</param>
    /// <param name="mode">Search mode.</param>
    /// <param name="condition">Search string\condition (depends on <paramref name="mode"/>).</param>
    public FtsCondition(
      ObjectModel.Type requestedType,
      FtsMode mode,
      string condition): this(requestedType, mode, condition, 0)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// <seealso cref="DataObjects.NET.SqlQuery.CreateFtsCondition"/>
    /// </summary>
    /// <param name="mode">Search mode.</param>
    /// <param name="condition">Search string\condition (depends on <paramref name="mode"/>).</param>
    public FtsCondition(
      FtsMode mode,
      string condition): this(mode, condition, 0)
    {
    }
  }
}
