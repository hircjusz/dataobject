// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Attributes;

namespace DataObjects.NET
{
  /// <summary>
  /// Enumeration of possible database options for a <see cref="Domain"/>.
  /// <seealso cref="Domain.DatabaseOptions"/>
  /// </summary>
  [Flags]
  public enum DomainDatabaseOptions
  {
    /// <summary>
    /// Deafult foreign key creation mode.
    /// Value is <see langword="0x4"/> meaning that no options are set. 
    /// </summary>
    Default = 0x100,
    /// <summary>
    /// Foreign keys should be created.
    /// Value is <see langword="0x1"/>. 
    /// </summary>
    CreateForeignKeys = 0x1,
    /// <summary>
    /// "Null rows" should be created.
    /// This option has no effect, if <see cref="CreateForeignKeys"/>
    /// option is not used.
    /// If reference field is not nullable, we need to create 
    /// special dummy rows ("null rows") having <see cref="DataObject.ID"/>=0
    /// in almost any table containing persistent instance part (except
    /// collection tables);
    /// otherwise, check constraint will fail when such reference becomes
    /// set to null (so a corresponding column will contain 0 value).
    /// So if this flag is set, null rows will be created. 
    /// And if not set, no foreign key constraints will be created for 
    /// not <see cref="NullableAttribute">[Nullable]</see> reference fields.
    /// Null rows aren't returned by any view.
    /// Value is <see langword="0x2"/>. 
    /// </summary>
    CreateNullRows = 0x2,
    /// <summary>
    /// Enables usage of left outer, rather then inner joins in 
    /// views generated in database.
    /// This option may significantly improve the performance on 
    /// some queries (namely <code>Select count(*) from doMyTypeName</code>-like),
    /// but does not ensure that all locks will be propagated to 
    /// <see cref="DataObject"/>-related table (doDataObject), that
    /// may violate desirable transaction isolation rules. Note that
    /// locks aren't used in Oracle and Firebird, thus this option
    /// only improves the performance in case with these databases.
    /// Value is <see langword="0x4"/>. 
    /// </summary>
    UseOuterJoins = 0x4,
    /// <summary>
    /// Enables full-text indexing and search support.
    /// Value is <see langword="0x100"/>. 
    /// </summary>
    DisableFastLoadData = 0x8,
    /// <summary>
    /// Enables full-text indexing and search support.
    /// Value is <see langword="0x100"/>. 
    /// </summary>
    EnableFullTextSearch = 0x100,
    /// <summary>
    /// Enables versionizing ("browse past") mode - 
    /// an ability to browse the database at any previous moment of time.
    /// Value is <see langword="0x1000"/>. 
    /// </summary>
    EnableVersionizing = 0x1000,
    /// <summary>
    /// The same as <see cref="EnableVersionizing"/>.
    /// Value is <see langword="0x1000"/>. 
    /// </summary>
    EnableBrowsePast = 0x1000,
  }

    public enum IDStyle
    {
        Default = 0,
        Minimal = 1
    }

}
