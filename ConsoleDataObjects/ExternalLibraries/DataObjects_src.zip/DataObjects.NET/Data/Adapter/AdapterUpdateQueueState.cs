// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using DataObjects.NET;

namespace DataObjects.NET.Data
{
  /// <summary>
  /// Enumerates possible <see cref="AdapterUpdateQueue"/> states.
  /// </summary>
  public enum AdapterUpdateQueueState
  {
    /// <summary>
    /// <see cref="AdapterUpdateQueue"/> is empty.
    /// </summary>
    Empty = 0x0,
    
    /// <summary>
    /// <see cref="AdapterUpdateQueue"/> containes <see cref="DataObject.ID"/>
    /// registered for creation.
    /// </summary>
    Create = 0x1,
    
    /// <summary>
    /// <see cref="AdapterUpdateQueue"/> containes <see cref="DataObject.ID"/>
    /// registered for update.
    /// </summary>
    Update = 0x2,
    
    /// <summary>
    /// <see cref="AdapterUpdateQueue"/> containes <see cref="DataObject.ID"/>
    /// registered for removal.
    /// </summary>
    Remove = 0x3
  }
}
