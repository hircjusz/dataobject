// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;
using System.Collections.Specialized;
using System.Text;
using System.Runtime.Serialization;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Attributes;

namespace DataObjects.NET.ObjectModel
{
  /// <summary>
  /// A collection of <see cref="QueryRestriction"/> objects.
  /// You can't create instances of this type manually.
  /// <seealso cref="QueryRestriction"/>
  /// <seealso cref="Query"/>
  /// <seealso cref="SqlQuery"/>
  /// </summary>
  [Serializable]
  public class QueryRestrictionCollection : MarshalByRefCollectionBase
  { 
    private QueryBase query;

    /// <summary>
    /// Collection indexer.
    /// </summary>
    public QueryRestriction this[int n] {
      get {
        return (QueryRestriction)List[n];
      }
      set {
        List[n] = value;
      }
    }
    
    /// <summary>
    /// Adds new <see cref="QueryRestriction"/> to this collection.
    /// </summary>
    /// <param name="queryRestriction">Restriction to add.</param>
    public int Add(QueryRestriction queryRestriction)
    {
      query.translated = false;
      return List.Add(queryRestriction);
    }
    
    /// <summary>
    /// Performs additional custom processes when the contents of
    /// collection is changing.
    /// </summary>
    protected override void OnChange()
    {
      base.OnChange();
      query.translated = false;
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    internal QueryRestrictionCollection(QueryBase query)
    {
      this.query = query;
    }
  }
}
