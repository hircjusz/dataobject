// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;
using System.Runtime.Serialization;
using DataObjects.NET;
using DataObjects.NET.Attributes;
using DataObjects.NET.Serialization;
using DataObjects.NET.Security.Permissions;

namespace DataObjects.NET.FullText
{
  /// <summary>
  /// Performs auxiliary tasks.
  /// This service is used by DataObjects.NET full-text search engine.
  /// </summary>
  [ServiceType(DataServiceType.Shared)]
  [Sealed]
  public abstract class FtsEventWatcher: DataService,
    IDataObjectEventWatcher,
    ITransactionEventWatcher
  {
    private Hashtable createdObjects = null;
    
    /// <summary>
    /// Called on <see cref="DataObject"/> instance initialization.
    /// </summary>
    public void OnDataObjectCreated(DataObject dataObject)
    {
      if (!Domain.FtsDriver.FullTextFunctionsAvailable)
        return;
        
      if (dataObject is IFtObject) {
        if (dataObject.State==DataObjectState.Persistent)
          CreateFtRecord((IFtObject)dataObject);
        else
          createdObjects[dataObject] = createdObjects;
      }
    }

    /// <summary>
    /// Called after changes are persisted (see <see cref="DataObject.Persist"/> method)
    /// to the database.
    /// </summary>
    public void OnDataObjectPersisted(DataObject dataObject)
    {
      if (!Domain.FtsDriver.FullTextFunctionsAvailable)
        return;
        
      if (dataObject is IFtObject) {
        if (createdObjects.Contains(dataObject)) {
          createdObjects.Remove(dataObject);
          CreateFtRecord((IFtObject)dataObject);
        }
      }
    }
    
    private void CreateFtRecord(IFtObject ftObject)
    {
      DisableSecurity();
      try {
        if (ftObject.HasFtData)
          Session.CreateObject(typeof(FtRecord), new object[] { ftObject });
      }
      finally {
        EnableSecurity();
      }
    }

    /// <summary>
    /// Called before <see cref="DataObject"/> instance is removed (see <see cref="DataObject.Remove"/> method).
    /// </summary>
    public void OnDataObjectRemove(DataObject dataObject)
    {
    }
    
    /// <summary>
    /// Called before trying to reload the instance.
    /// Using this method you can disable instance reloading
    /// under certain circumstances (e.g. when it's well known that
    /// instance is never changing).
    /// </summary>
    /// <param name="dataObject">The DataObject instance the event invoked for.</param>
    /// <param name="skipReload">Caller always sets this 
    /// <see langword="false"/> parameter to false. You can set it to
    /// <see langword="true"/>, if reloading should be skipped.</param>
    public void OnDataObjectBeforeReload(DataObject dataObject, ref bool skipReload)
    {
    }
    
    /// <summary>
    /// Called after instance is loaded or reloaded.
    /// </summary>
    /// <param name="dataObject">The DataObject instance the event invoked for.</param>
    /// <param name="reload"><see langword="True"/>, if this method is
    /// invoked on reload; otherwise, <see langword="false"/>.</param>
    public void OnDataObjectLoad(DataObject dataObject, bool reload)
    {
    }

    /// <summary>
    /// Serializes object identity, when object is serialized as reference.
    /// </summary>
    /// <param name="dataObject">The DataObject instance the event invoked for.</param>
    /// <param name="serializer">Serializer that performs the serialization.</param>
    /// <param name="info">Serialization info.</param>
    /// <param name="context">Streaming context.</param>
    public void OnDataObjectSerializeIdentity(DataObject dataObject, Serializer serializer, SerializationInfo info, StreamingContext context)
    {
    }
    
    /// <summary>
    /// Converts serialized object identity to real <see cref="DataObject"/>
    /// instance. This method always called with so-called "null object"
    /// (see <see cref="Session.GetNullObject">Session.GetNullObject</see>)
    /// as it's first argument.
    /// </summary>
    /// <param name="dataObject">The DataObject instance the event invoked for.
    /// (It is always so-called "null object" 
    /// the result of <see cref="Session.GetNullObject">Session.GetNullObject</see> call)</param>
    /// <param name="deserializationResult">The result of identity deserialization.
    /// Initially it is the result of <see cref="DataObject.OnDeserializeIdentity"/> method call.</param>
    /// <param name="serializer">Serializer that performs the deserialization.</param>
    /// <param name="info">Serialization info.</param>
    /// <param name="context">Streaming context.</param>
    public void OnDataObjectDeserializeIdentity(DataObject dataObject, ref DataObject deserializationResult, Serializer serializer, SerializationInfo info, StreamingContext context)
    {
    }

    /// <summary>
    /// Called before instance is serialized (see <see cref="Serializer"/> class).
    /// </summary>
    /// <param name="dataObject">The DataObject instance the event invoked for.</param>
    /// <param name="serializer">Serializer that performs the serialization.</param>
    /// <param name="info">Serialization info.</param>
    /// <param name="context">Streaming context.</param>
    /// <param name="fields">A <see cref="Hashtable"/> initially containing pairs (Field name, <see langword="true"/>).
    /// You should set some values to <see langword="false"/> or <see langword="null"/> 
    /// in it to disable automatic serialization of corresponding field.
    /// E.g. you should clear it in case when you serialize all fields manually.</param>
    public void OnDataObjectSerializing(DataObject dataObject, Serializer serializer, SerializationInfo info, StreamingContext context, Hashtable fields)
    {
    }

    /// <summary>
    /// Called before instance is deserialized (see <see cref="Serializer"/> class).
    /// </summary>
    /// <param name="dataObject">The DataObject instance the event invoked for.</param>
    /// <param name="serializer">Serializer that performs the deserialization.</param>
    /// <param name="info">Serialization info.</param>
    /// <param name="context">Streaming context.</param>
    /// <param name="fields">A <see cref="Hashtable"/> initially containing pairs (Field name, <see langword="true"/>).
    /// You should set some values to <see langword="false"/> or <see langword="null"/> 
    /// in it to disable automatic deserialization of corresponding field.
    /// E.g. you should clear it in case when you deserialize all fields manually.</param>
    public void OnDataObjectDeserializing(DataObject dataObject, Serializer serializer, SerializationInfo info, StreamingContext context, Hashtable fields)
    {
    }

    /// <summary>
    /// Called on any error during deserialization (see 
    /// <see cref="Serializer"/> class) of instance field.
    /// Implement this method to handle deserialization
    /// errors. This can be very necessary if it's required 
    /// to deserialize another version of object - e.g. if
    /// this version was containing a field that doesn't
    /// exists in the current version.
    /// </summary>
    /// <param name="dataObject">The DataObject instance the event invoked for.</param>
    /// <param name="serializer">Serializer that performs the deserialization.</param>
    /// <param name="info">Serialization info.</param>
    /// <param name="context">Streaming context.</param>
    /// <param name="propertyName">The name of the field that was 
    /// deserializing.</param>
    /// <param name="culture">The <see cref="Culture"/> of the field that was
    /// deserializing.</param>
    /// <param name="exception">Exception that was thrown during attempt
    /// to deserialize <paramref name="propertyName"/>.</param>
    public void OnDataObjectPropertyDeserializationError(DataObject dataObject, Serializer serializer, SerializationInfo info, StreamingContext context, string propertyName, Culture culture, Exception exception)
    {
    }


    /// <summary>
    /// Called after instance is deserialized.
    /// </summary>
    /// <param name="dataObject">The DataObject instance the event invoked for.</param>
    /// <param name="serializer">Serializer that performs the deserialization.</param>
    public void OnDataObjectDeserialized(DataObject dataObject, Serializer serializer)
    {
    }

    /// <summary>
    /// Called when the whole object graph is completely deserialized.
    /// </summary>
    /// <param name="dataObject">The DataObject instance the event invoked for.</param>
    /// <param name="serializer">Serializer that performs the deserialization.</param>
    public void OnDataObjectGraphDeserialized(DataObject dataObject, Serializer serializer)
    {
    }

    /// <summary>
    /// Called during <see cref="DataObject.GetProperty"/> method execution.
    /// </summary>
    /// <param name="dataObject">The DataObject instance the event invoked for.</param>
    /// <param name="name">Property name.</param>
    /// <param name="culture">Property culture.</param>
    /// <param name="value">Stored property value.</param>
    public void OnDataObjectGetProperty(DataObject dataObject, string name, Culture culture, object value)
    {
    }

    /// <summary>
    /// Called during <see cref="DataObject.SetProperty"/> method execution.
    /// Note that this method isn't invoked during the deserialization.
    /// </summary>
    /// <param name="dataObject">The DataObject instance the event invoked for.</param>
    /// <param name="name">Property name.</param>
    /// <param name="culture">Property culture.</param>
    /// <param name="value">New property value.</param>
    public void OnDataObjectSetProperty(DataObject dataObject, string name, Culture culture, object value)
    {
    }
    
    /// <summary>
    /// Called when some property was changed.
    /// Note that this method isn't invoked during the deserialization.
    /// </summary>
    /// <param name="dataObject">The DataObject instance the event invoked for.</param>
    /// <param name="name">Property name.</param>
    /// <param name="culture">Property culture.</param>
    /// <param name="value">New property value.</param>
    public void OnDataObjectPropertyChanged(DataObject dataObject, string name, Culture culture, object value)
    {
    }

    /// <summary>
    /// Called before inner content of some non-<see cref="ValueType"/> 
    /// property is changed.
    /// </summary>
    /// <param name="dataObject">The DataObject instance the event invoked for.</param>
    /// <param name="name">Property name.</param>
    /// <param name="culture">Property culture.</param>
    /// <param name="value">Old property value.</param>
    public void OnDataObjectPropertyContentChanging(DataObject dataObject, string name, Culture culture, object value)
    {
    }

    /// <summary>
    /// Called when inner content of some non-<see cref="ValueType"/> 
    /// property was changed.
    /// Note that this method isn't invoked during the deserialization.
    /// </summary>
    /// <param name="dataObject">The DataObject instance the event invoked for.</param>
    /// <param name="name">Property name.</param>
    /// <param name="culture">Property culture.</param>
    /// <param name="value">New property value.</param>
    public void OnDataObjectPropertyContentChanged(DataObject dataObject, string name, Culture culture, object value)
    {
    }

    /// <summary>
    /// Called when a new <see cref="Transaction"/> is started.
    /// </summary>
    /// <param name="transaction">The newly created and started <see cref="Transaction"/>.</param>
    public void OnTransactionBegin(Transaction transaction)
    {
      if (!Domain.FtsDriver.FullTextFunctionsAvailable)
        return;
        
      if (transaction.IsOutermost)
        createdObjects = new Hashtable();
    }

    /// <summary>
    /// Called when a <see cref="Transaction"/> is going to be committed.
    /// </summary>
    /// <param name="transaction">The <see cref="Transaction"/> to be committed.</param>
    public void OnBeforeTransactionCommit (Transaction transaction)
    {
    }

    /// <summary>
    /// Called when a <see cref="Transaction"/> is committed.
    /// </summary>
    /// <param name="transaction">The committed <see cref="Transaction"/>.</param>
    public void OnTransactionCommit(Transaction transaction)
    {
      if (!Domain.FtsDriver.FullTextFunctionsAvailable)
        return;

      OnTransactionCommitOrRollback(transaction);
    }

    /// <summary>
    /// Called when a <see cref="Transaction"/> is going to be rolled back.
    /// </summary>
    /// <param name="transaction">The <see cref="Transaction"/> to be rolled back.</param>
    public void OnBeforeTransactionRollback (Transaction transaction)
    {
    }

    /// <summary>
    /// Called when a <see cref="Transaction"/> is rolled back.
    /// </summary>
    /// <param name="transaction">The rolled back <see cref="Transaction"/>.</param>
    public void OnTransactionRollback(Transaction transaction)
    {
      if (!Domain.FtsDriver.FullTextFunctionsAvailable)
        return;

      OnTransactionCommitOrRollback(transaction);
    }

    private void OnTransactionCommitOrRollback(Transaction transaction)
    {
      if (transaction.IsOutermost)
        createdObjects = null;
    }
  }
}
