// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Attributes;

namespace DataObjects.NET
{
  /// <summary>
  /// Enumeration of possible <see cref="DataObject"/> instance states.
  /// </summary>
  public enum DataObjectState
  {
    /// <summary>
    /// Instance is created, but not persisted yet.
    /// Value is <see langword="0"/>. 
    /// </summary>
    New = 0,
    /// <summary>
    /// Instance is already persisted.
    /// Value is <see langword="1"/>. 
    /// </summary>
    Persistent = 1,
    /// <summary>
    /// Instance is already deleted.
    /// Value is <see langword="2"/>. 
    /// </summary>
    Removed = 2
  }
}
