// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Attributes;
using DataObjects.NET.ObjectModel;

namespace DataObjects.NET
{
  /// <summary>
  /// Represents an entry in the <see cref="ValueTypeQueryResult"/> object.
  /// </summary>
  public sealed class ValueTypeQueryResultEntry
  {
    internal ValueTypeQueryResult queryResult;
    private long   ownerId;
    private long   itemId;
    private object iValue;

    /// <summary>
    /// Gets <see cref="DataObject.ID"/> of the owner
    /// (<see cref="DataObject"/> instance that stores the item).
    /// </summary>
    public long OwnerID {
      get {
        return ownerId;
      }
    }
    
    /// <summary>
    /// Gets the owner (<see cref="DataObject"/> instance) of this entry.
    /// </summary>
    public DataObject Owner {
      get {
        return queryResult.session[ownerId];
      }
    }

    /// <summary>
    /// Gets the ItemID (key) of the item, if the
    /// selected item is stored in the <see cref="ValueTypeCollection"/>
    /// or <see cref="DataObjectCollection"/>;
    /// otherwise, <see langword="0"/>.
    /// </summary>
    public long ItemID {
      get {
        return itemId;
      }
    }

    /// <summary>
    /// Gets the collection item.
    /// The difference between this property and <see cref="Value"/> 
    /// property is that this property always returns 
    /// <see cref="ValueTypeCollectionEntry"/> rather then
    /// its <see cref="ValueTypeCollectionEntry.Value"/> for
    /// any <see cref="ValueTypeCollection"/> item.
    /// </summary>
    public object Item {
      get {
        // Automatic Transactions support code
        TransactionController tc = queryResult.session.CreateTransactionController(TransactionMode.TransactionRequired);
      Reprocess:
        try {
          object r = InnerGetItem();
          tc.Commit();
          return r;
        }
        catch (Exception e) {
          if (tc.Rollback(e, true))
            goto Reprocess;             
          throw;
        }
      }
    }
    private object InnerGetItem()
    {
      Session session = queryResult.session;
      Field     field = queryResult.Field;
      DataObject  obj = session[ownerId];
      Field rf = field.RootField;
      if (rf is ValueTypeCollectionField) {
        ValueTypeCollection col = (ValueTypeCollection)obj.GetProperty(rf.Name, queryResult.Culture);
        if (field.IsRootField) {
          if (!queryResult.LoadOnDemand && 
              session.transaction!=null && 
              queryResult.TransactionContext.State==TransactionContextState.Valid)
            col.CacheItem(this);
          return col[itemId];
        }
        else
          return col[itemId];
      }
      else if (rf is DataObjectCollectionField) {
        DataObjectCollection col = (DataObjectCollection)obj.GetProperty(rf.Name, queryResult.Culture);
        DataObject val = session[itemId];
        if (val==null)
          return val;
        if (session.transaction!=null && 
            queryResult.TransactionContext.State==TransactionContextState.Valid)
          col.CacheItem(itemId, true);
        return val;
      }
      else
        return obj.GetProperty(field.AbsoluteName, queryResult.Culture);
    }
    
    /// <summary>
    /// Gets value of the collection item.
    /// The difference between this property and <see cref="Item"/> 
    /// property is that this property always returns 
    /// <see cref="ValueTypeCollectionEntry.Value"/> rather then
    /// its <see cref="ValueTypeCollectionEntry"/> for
    /// any <see cref="ValueTypeCollection"/> item.
    /// </summary>
    public object Value {
      get {
        // Automatic Transactions support code
        TransactionController tc = queryResult.session.CreateTransactionController(TransactionMode.TransactionRequired);
      Reprocess:
        try {
          object r = InnerGetValue();
          tc.Commit();
          return r;
        }
        catch (Exception e) {
          if (tc.Rollback(e, true))
            goto Reprocess;             
          throw;
        }
      }
    }
    private object InnerGetValue()
    {
      Session session = queryResult.session;
      Field     field = queryResult.Field;
      DataObject  obj = session[ownerId];
      Field rf = field.RootField;
      if (rf is ValueTypeCollectionField) {
        ValueTypeCollection col = (ValueTypeCollection)obj.GetProperty(rf.Name, queryResult.Culture);
        if (field.IsRootField) {
          if (!queryResult.LoadOnDemand && 
              session.transaction!=null && 
              queryResult.TransactionContext.State==TransactionContextState.Valid)
            col.CacheItem(this);
          return col[itemId].Value;
        }
        else
          return col.GetStructFieldValue(itemId, field.AbsoluteName);
      }
      else if (rf is DataObjectCollectionField) {
        DataObjectCollection col = (DataObjectCollection)obj.GetProperty(rf.Name, queryResult.Culture);
        DataObject val = session[itemId];
        if (val==null)
          return val;
        if (session.transaction!=null && 
            queryResult.TransactionContext.State==TransactionContextState.Valid)
          col.CacheItem(itemId, true);
        return val;
      }
      else
        return obj.GetProperty(field.AbsoluteName, queryResult.Culture);
    }
    
    /// <summary>
    /// Gets internal value of the collection item.
    /// </summary>
    internal object InternalValue {
      get {
        return iValue;
      }
    }
    

    // Constructor

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="ownerId">ObjectID of the collection item.</param>
    /// <param name="itemId">ItemID (key) of the collection item.</param>
    /// <param name="iValue">Internal value of the collection item.</param>
    internal ValueTypeQueryResultEntry(long ownerId, long itemId, object iValue)
    {
      this.ownerId  = ownerId;
      this.itemId   = itemId;
      this.iValue   = iValue;
    }
  }
}
