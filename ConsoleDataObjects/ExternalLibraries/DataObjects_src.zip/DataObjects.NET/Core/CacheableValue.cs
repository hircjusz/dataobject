// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;

namespace DataObjects.NET
{
  /// <summary>
  /// Provides information for 
  /// <see cref="DataObjects.NET.CacheableValue"/>-related events.
  /// <seealso cref="CacheableValueEventHandler"/>
  /// <seealso cref="DataObjects.NET.CacheableValue"/>
  /// </summary>
  public class CacheableValueEventArgs: EventArgs
  {
    private CacheableValue cacheableValue;
    /// <summary>
    /// Gets the <see cref="DataObjects.NET.CacheableValue"/> object
    /// that initiated the event.
    /// </summary>
    public   CacheableValue CacheableValue {
      get {
        return cacheableValue;
      }
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="cacheableValue"><see cref="DataObjects.NET.CacheableValue"/> object
    /// that initiated the event.</param>
    public CacheableValueEventArgs(CacheableValue cacheableValue)
    {
      this.cacheableValue = cacheableValue;
    }
  }

  /// <summary>
  /// Represents a method that handles 
  /// <see cref="DataObjects.NET.CacheableValue"/>-related events.
  /// <seealso cref="CacheableValueEventArgs"/>
  /// <seealso cref="DataObjects.NET.CacheableValue"/>
  /// </summary>
  public delegate void CacheableValueEventHandler(object sender, CacheableValueEventArgs e);

  /// <summary>
  /// Allows to cache any persistent data (value).
  /// </summary>
  /// <remarks>
  /// <para>
  /// Use this class to implement persistent data caching. The instance of this class 
  /// "wraps" a value of any type that can be cached, and ensures
  /// validity of cached value on any attempt to read it.
  /// </para>
  /// <para>
  /// Cache validity checks are based on <see cref="TransactionContext"/>
  /// in which cached value was calculated, <see cref="CalculationTime"/>
  /// and <see cref="ExpirationPeriod"/>. 
  /// See <see cref="EnsureCachedValueValidity"/> method for additional information.
  /// </para>
  /// <example>
  /// <code lang="C#">
  /// public abstract class CIsAMultipliedByB: DataObject 
  /// { 
  ///   public abstract double A {get; set;} 
  ///   public abstract double B {get; set;}
  ///
  ///   private CacheableValue cachedC;
  ///   private void CalculateC(object source, object sender, CacheableValueEventArgs e)
  ///   {
  ///     e.CacheableValue.Value = A*B;
  ///   }
  ///   public double C {
  ///     get {
  ///       if (cachedC==null)
  ///         cachedC = new CacheableValue(Session, new TimeSpan(60000),
  ///           new CacheableValueEventHandler(CalculateC));
  ///       return (double)cachedC.Value;
  ///     }
  ///   }
  ///
  ///   protected override void OnPropertyChanged(string name, Culture culture, object value) 
  ///   { 
  ///     base.OnPropertyChanged(name, culture, value); 
  ///     if (name=="A" || name=="B") 
  ///       cachedC = null; // Invalidation of cached value
  ///   }
  /// }
  /// </code>
  /// </example>
  /// </remarks>
  public class CacheableValue : SessionBoundObject
  {
    /// <summary>
    /// Gets "Infinite" calculation time. If <see cref="CalculationTime"/> equals
    /// to this constant, cached value is to be recalculated.
    /// Always returns <see cref="DateTime.MinValue">DateTime.MinValue</see>.
    /// </summary>
    public  static DateTime InfiniteCalculationTime {
      get {
        return DateTime.MinValue;
      }
    }
    
    private TransactionContext transactionContext = null;
    private DateTime calculationTime;
    private TimeSpan expirationPeriod;
    private object value;

    /// <summary>
    /// Gets or sets cached value. 
    /// </summary>
    /// <remarks>
    /// <para>This property contains nearly the following code:
    /// <example>Default Value property implementation:
    /// <code lang="C#">
    ///  public object Value {
    ///    get {
    ///      EnsureCachedValueValidity();
    ///      return this.value;
    ///    }
    ///    set {
    ///      this.value = value;
    ///      TransactionContext = Session.TransactionContext;
    ///      CalculationTime = DateTime.UtcNow;
    ///    }
    ///  }
    /// </code>
    /// </example>
    /// </para>
    /// </remarks>
    public object Value {
      get {
        EnsureCachedValueValidity();
        return this.value;
      }
      set {
        this.value = value;
        this.transactionContext = session.TransactionContext;
        this.calculationTime = DateTime.UtcNow;
      }
    }
    
    /// <summary>
    /// Gets or sets cached value without any additional checks\actions
    /// (which are performed by <see cref="Value"/> getter and setter).
    /// </summary>
    public object CachedValue {
      get {
        return this.value;
      }
      set {
        this.value = value;
      }
    }
    
    /// <summary>
    /// Gets or sets <see cref="DataObjects.NET.TransactionContext"/> object
    /// where cached value was retrieved (so this is the context
    /// where cached value is definitely valid).
    /// <seealso cref="InvalidateCache"/>
    /// <seealso cref="CalculationTime"/>
    /// </summary>
    public  TransactionContext TransactionContext
    {
      get {
        return transactionContext;
      }
      set {
        transactionContext = value;
      }
    }

    /// <summary>
    /// Gets or sets the time when cached value is (was) calculated.
    /// <seealso cref="InvalidateCache"/>
    /// <seealso cref="TransactionContext"/>
    /// </summary>
    public  DateTime CalculationTime
    {
      get {
        return calculationTime;
      }
      set {
        calculationTime = value;
      }
    }

    /// <summary>
    /// Gets or sets the length of period when cached value is definitely
    /// valid (regardless of <see cref="TransactionContext"/> value).
    /// <seealso cref="InvalidateCache"/>
    /// <seealso cref="TransactionContext"/>
    /// </summary>
    public  TimeSpan ExpirationPeriod
    {
      get {
        return expirationPeriod;
      }
      set {
        expirationPeriod = value;
      }
    }

    /// <summary>
    /// Invalidates cache, thus causing recalculation of cached value on 
    /// next attempt to read it.
    /// </summary>
    /// <remarks>
    /// This method sets <see cref="TransactionContext"/> to <see langword="null"/>,
    /// and <see cref="CalculationTime"/> to <see cref="InfiniteCalculationTime"/>.
    /// </remarks>
    protected virtual void InvalidateCache()
    {
      transactionContext = null;
      calculationTime    = InfiniteCalculationTime;
    }
    
    /// <summary>
    /// Checks if cached value is still valid.
    /// </summary>
    /// <remarks>
    /// <para>
    /// Cached value is valid while any of following conditions is correct:
    /// </para>
    /// <para>
    /// 1) <see cref="TransactionContext"/> is not <see langword="null"/> 
    /// and its <see cref="DataObjects.NET.TransactionContext.State"/> is 
    /// <see cref="TransactionContextState">Valid</see>.
    /// </para>
    /// <para>
    /// 2) <see cref="CalculationTime"/> is not equal to 
    /// <see cref="InfiniteCalculationTime"/>, and greater then
    /// <see cref="DateTime.UtcNow"/>-<see cref="ExpirationPeriod"/>.
    /// </para>
    /// <para>This method contains nearly the following code:
    /// <example>Default EnsureCacheValidity() implementation:
    /// <code lang="C#">
    ///   if (TransactionContext==null || 
    ///      TransactionContext.State!=TransactionContextState.Valid)
    ///    if (CalculationTime==InfiniteCalculationTime ||
    ///        (CalculationTime+ExpirationPeriod)>DateTime.Now)
    ///      DoCalculateValue();
    /// </code>
    /// </example>
    /// </para>
    /// </remarks>
    protected virtual void EnsureCachedValueValidity()
    {
      if (transactionContext==null || 
          transactionContext.State!=TransactionContextState.Valid)
        if (calculationTime==InfiniteCalculationTime ||
            (calculationTime+expirationPeriod)<DateTime.UtcNow)
          DoCalculateValue();
    }

    /// <summary>
    /// Recalculates cached value when <see cref="CalculateValue"/>
    /// event handlers aren't attached.
    /// </summary>
    /// <remarks>
    /// <para>
    /// This method is invoked by <see cref="DoCalculateValue"/> method
    /// in case when <see cref="CalculateValue"/> event handlers aren't attached.
    /// </para>
    /// <para>
    /// Default implementation of this method does nothing 
    /// (so cached value stays unchanged).
    /// </para>
    /// </remarks>
    protected virtual void OnCalculateValue()
    {
    }
    
    /// <summary>
    /// Recalculates cached value by invoking 
    /// <see cref="CalculateValue"/> delegate (if it's attached), or
    /// <see cref="OnCalculateValue"/> method.
    /// </summary>
    /// <remarks>
    /// <para>
    /// This method is invoked automatically by <see cref="EnsureCachedValueValidity"/> method.
    /// </para>
    /// <para>
    /// An implementation of this method tries to execute
    /// <see cref="CalculateValue"/> delegate (if it's attached); 
    /// otherwise it executes <see cref="OnCalculateValue"/> method.
    /// </para>
    /// </remarks>
    protected virtual void DoCalculateValue()
    {
      if (CalculateValue!=null)
        CalculateValue(this, new CacheableValueEventArgs(this));
      else
        OnCalculateValue();
    }
    
    /// <summary>
    /// Occurs when it's necessary to recalculate cached value.
    /// <seealso cref="OnCalculateValue"/>
    /// </summary>
    public event CacheableValueEventHandler CalculateValue;

    // Constructors
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="session">Session, to which current instance should be bound.</param>
    public CacheableValue(Session session) : base(session)
    {
      expirationPeriod = new TimeSpan(0);
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="session">Session, to which current instance should be bound.</param>
    /// <param name="calculateValue">Delegate that calculates cached value.</param>
    public CacheableValue(Session session, CacheableValueEventHandler calculateValue) : base(session)
    {
      expirationPeriod = new TimeSpan(0);
      CalculateValue += calculateValue;
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="session">Session, to which current instance should be bound.</param>
    /// <param name="expirationPeriod">Initial <see cref="ExpirationPeriod"/> value.</param>
    public CacheableValue(Session session, TimeSpan expirationPeriod) : base(session)
    {
      this.expirationPeriod = expirationPeriod;
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="session">Session, to which current instance should be bound.</param>
    /// <param name="expirationPeriod">Initial <see cref="ExpirationPeriod"/> value.</param>
    /// <param name="calculateValue">Delegate that calculates cached value.</param>
    public CacheableValue(Session session, TimeSpan expirationPeriod, 
      CacheableValueEventHandler calculateValue) : base(session)
    {
      this.expirationPeriod = expirationPeriod;
      CalculateValue += calculateValue;
    }
  }
}
