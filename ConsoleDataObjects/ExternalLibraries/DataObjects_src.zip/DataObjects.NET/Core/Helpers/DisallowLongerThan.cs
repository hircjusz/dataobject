// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;
using DataObjects.NET.Attributes;
using Offline=DataObjects.NET.Offline;

namespace DataObjects.NET.Helpers
{
  /// <summary>
  /// A <see cref="IPropertyValueValidator">validator</see> that
  /// checks if length (see <see cref="String.Length">String.Length</see>,
  /// <see cref="Array.Length">Array.Length</see>) of property value 
  /// is less then or equal to specified constant;
  /// throws <see cref="ArgumentOutOfRangeException"/> if this condition
  /// is violated.
  /// <seealso cref="ValidatorAttribute"/>
  /// </summary>
  /// <remarks>
  /// See <see cref="ValidatorAttribute"/> also.
  /// </remarks>
  [Serializable]
  public class DisallowLongerThan: IPropertyValueValidator, Offline.IPropertyValueValidator 
  {
    private int maximalLength;
    /// <summary>
    /// Gets maximal length (see <see cref="String.Length">String.Length</see>,
    /// <see cref="Array.Length">Array.Length</see>) of property value that passes 
    /// through this validator.
    /// </summary>
    public int MaximalLength {
      get {
        return maximalLength;
      }
    }

    /// <summary>
    /// Validates <see cref="DataObject"/> property value 
    /// before it is actually set by 
    /// <see cref="DataObject.SetProperty">DataObject.SetProperty</see>
    /// method.
    /// </summary>
    /// <param name="dataObject"><see cref="DataObject"/> instance
    /// which property is to be changed.</param>
    /// <param name="propertyName">Property name.</param>
    /// <param name="culture">Property culture.</param>
    /// <param name="value">New property value.</param>
    /// <remarks>
    /// Checks if length (see <see cref="String.Length">String.Length</see>,
    /// <see cref="Array.Length">Array.Length</see>) of property value 
    /// is less then or equal to specified constant;
    /// throws <see cref="ArgumentOutOfRangeException"/> if this condition
    /// is violated.
    /// </remarks>
    public void Validate(DataObject dataObject, string propertyName, Culture culture, object value) 
    {
      Validate(propertyName, value);
    }

    /// <summary>
    /// Validates <see cref="DataObject"/> property value 
    /// before it is actually set by 
    /// <see cref="DataObject.SetProperty">DataObject.SetProperty</see>
    /// method.
    /// </summary>
    /// <param name="dataObject"><see cref="Offline.DataObject"/> instance
    /// which property is to be changed.</param>
    /// <param name="propertyName">Property name.</param>
    /// <param name="culture">Property culture.</param>
    /// <param name="value">New property value.</param>
    /// <remarks>
    /// Checks if length (see <see cref="String.Length">String.Length</see>,
    /// <see cref="Array.Length">Array.Length</see>) of property value 
    /// is less then or equal to specified constant;
    /// throws <see cref="ArgumentOutOfRangeException"/> if this condition
    /// is violated.
    /// </remarks>
    public void Validate(Offline.DataObject dataObject, string propertyName, Offline.Culture culture, object value) 
    {
      Validate(propertyName, value);
    }
    
    private void Validate(string propertyName, object value)
    {
      if (value==null)
        return;
      if ((value is string) && (value as string).Length>maximalLength)
        throw new ArgumentOutOfRangeException(propertyName, value,
          String.Format(
            "Value of property \"{0}\" can't be longer then {1} (actual value length is {2}).", 
            propertyName, maximalLength, (value as string).Length));
      if ((value is Array) && (value as Array).Length>maximalLength)
        throw new ArgumentOutOfRangeException(propertyName, value,
          String.Format(
            "Value of property \"{0}\" can't be longer then {1} (actual value length is {2}).", 
            propertyName, maximalLength, (value as Array).Length));
      if ((value is ICollection) && (value as ICollection).Count>maximalLength)
        throw new ArgumentOutOfRangeException(propertyName, value,
          String.Format(
            "Value of property \"{0}\" can't be longer then {1} (actual value length is {2}).", 
            propertyName, maximalLength, (value as ICollection).Count));
    }
    
    /// <summary>
    /// Attaches a validator instance to a certain field.
    /// </summary>
    /// <param name="field">A <see cref="ObjectModel.Field"/> the validator is related to.</param>
    public void AttachToField (ObjectModel.Field field)
    {
      // Does nothing
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="maximalLength">
    /// Maximal length (see <see cref="String.Length">String.Length</see>,
    /// <see cref="Array.Length">Array.Length</see>) of property value that passes 
    /// through this validator.
    /// </param>
    public DisallowLongerThan(int maximalLength)
    {
      this.maximalLength = maximalLength;
    }
  }
}
