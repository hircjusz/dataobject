// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;
using System.Runtime.Serialization;
using DataObjects.NET;
using DataObjects.NET.Attributes;
using DataObjects.NET.Serialization;

namespace DataObjects.NET.Services
{
  /// <summary>
  /// A service that provides tracking features.
  /// </summary>
  [ServiceType(DataServiceType.Shared)]
  public abstract class TrackingService: DataService,
    IDataObjectEventWatcher,
    ITransactionEventWatcher
  {
    private Hashtable transactions = new Hashtable();
    
    /// <summary>
    /// Called on <see cref="DataObject"/> instance initialization.
    /// </summary>
    /// <param name="dataObject">The DataObject instance the event invoked for.</param>
    void IDataObjectEventWatcher.OnDataObjectCreated(DataObject dataObject)
    {
      Hashtable ts = (Hashtable)transactions[session.Transaction];
      if (ts!=null) {
        foreach (TrackingSet trackingSet in ts.Keys)
          trackingSet.OnDataObjectCreated(dataObject);
      }
    }

    /// <summary>
    /// Called after changes are persisted (see <see cref="DataObject.Persist"/> method)
    /// to the database.
    /// </summary>
    /// <param name="dataObject">The DataObject instance the event invoked for.</param>
    void IDataObjectEventWatcher.OnDataObjectPersisted(DataObject dataObject)
    {
      Hashtable ts = (Hashtable)transactions[session.Transaction];
      if (ts!=null) {
        foreach (TrackingSet trackingSet in ts.Keys)
          trackingSet.OnDataObjectPersisted(dataObject);
      }
    }

    /// <summary>
    /// Called before <see cref="DataObject"/> instance is removed (see <see cref="DataObject.Remove"/> method).
    /// </summary>
    /// <param name="dataObject">The DataObject instance the event invoked for.</param>
    void IDataObjectEventWatcher.OnDataObjectRemove(DataObject dataObject)
    {
      Hashtable ts = (Hashtable)transactions[session.Transaction];
      if (ts!=null) {
        foreach (TrackingSet trackingSet in ts.Keys)
          trackingSet.OnDataObjectRemove(dataObject);
      }
    }
    
    /// <summary>
    /// Called before trying to reload the instance.
    /// </summary>
    /// <param name="dataObject">The DataObject instance the event invoked for.</param>
    /// <param name="skipReload">Caller always sets this 
    /// <see langword="false"/> parameter to false. You can set it to
    /// <see langword="true"/>, if reloading should be skipped.</param>
    void IDataObjectEventWatcher.OnDataObjectBeforeReload(DataObject dataObject, ref bool skipReload)
    {
    }
    
    /// <summary>
    /// Called after instance is loaded or reloaded.
    /// </summary>
    /// <param name="dataObject">The DataObject instance the event invoked for.</param>
    /// <param name="reload"><see langword="True"/>, if this method is
    /// invoked on reload; otherwise, <see langword="false"/>.</param>
    void IDataObjectEventWatcher.OnDataObjectLoad(DataObject dataObject, bool reload)
    {
    }

    /// <summary>
    /// Serializes object identity, when object is serialized as reference.
    /// </summary>
    /// <param name="dataObject">The DataObject instance the event invoked for.</param>
    /// <param name="serializer">Serializer that performs the serialization.</param>
    /// <param name="info">Serialization info.</param>
    /// <param name="context">Streaming context.</param>
    void IDataObjectEventWatcher.OnDataObjectSerializeIdentity(DataObject dataObject, Serializer serializer, SerializationInfo info, StreamingContext context)
    {
    }

    /// <summary>
    /// Converts serialized object identity to real <see cref="DeserializationOptions"/>
    /// instance. This method always called with so-called "null object"
    /// (see <see cref="Session.GetNullObject">Session.GetNullObject</see>)
    /// as it's first argument.
    /// <seealso cref="DataObject"/>
    /// <seealso cref="DataObject"/>
    /// <seealso cref="IDataObjectEventWatcher.OnDataObjectSerializeIdentity"/>
    /// <seealso cref="Serializer"/>
    /// </summary>
    /// <param name="dataObject">The DataObject instance the event invoked for.
    /// (It is always so-called "null object" 
    /// the result of <see cref="SerializationOptions">Session.GetNullObject</see> call)</param>
    /// <param name="deserializationResult">The result of identity deserialization.
    /// Initially it is the result of <see cref="NET.Session.GetNullObject"/> method call.</param>
    /// <param name="serializer">Serializer that performs the deserialization.</param>
    /// <param name="info">Serialization info.</param>
    /// <param name="context">Streaming context.</param>
    /// <returns><see cref="DataObject.OnDeserializeIdentity"/> instance that corresponds to
    /// serialized object identity, or <see langword="null"/>.</returns>
    void IDataObjectEventWatcher.OnDataObjectDeserializeIdentity(DataObject dataObject, ref DataObject deserializationResult, Serializer serializer, SerializationInfo info, StreamingContext context)
    {
    }

    /// <summary>
    /// Called before instance is serialized (see <see cref="Serializer"/> class).
    /// </summary>
    /// <param name="dataObject">The DataObject instance the event invoked for.</param>
    /// <param name="serializer">Serializer that performs the serialization.</param>
    /// <param name="info">Serialization info.</param>
    /// <param name="context">Streaming context.</param>
    /// <param name="fields">A <see cref="Hashtable"/> initially containing pairs (Field name, <see langword="true"/>).
    /// You should set some values to <see langword="false"/> or <see langword="null"/> 
    /// in it to disable automatic serialization of corresponding field.
    /// E.g. you should clear it in case when you serialize all fields manually.</param>
    void IDataObjectEventWatcher.OnDataObjectSerializing(DataObject dataObject, Serializer serializer, SerializationInfo info, StreamingContext context, Hashtable fields)
    {
    }

    /// <summary>
    /// Called before instance is deserialized (see <see cref="Serializer"/> class).
    /// </summary>
    /// <param name="dataObject">The DataObject instance the event invoked for.</param>
    /// <param name="serializer">Serializer that performs the deserialization.</param>
    /// <param name="info">Serialization info.</param>
    /// <param name="context">Streaming context.</param>
    /// <param name="fields">A <see cref="Hashtable"/> initially containing pairs (Field name, <see langword="true"/>).
    /// You should set some values to <see langword="false"/> or <see langword="null"/> 
    /// in it to disable automatic deserialization of corresponding field.
    /// E.g. you should clear it in case when you deserialize all fields manually.</param>
    void IDataObjectEventWatcher.OnDataObjectDeserializing(DataObject dataObject, Serializer serializer, SerializationInfo info, StreamingContext context, Hashtable fields)
    {
    }

    /// <summary>
    /// Called on any error during deserialization (see 
    /// <see cref="Serializer"/> class) of instance field.
    /// </summary>
    /// <param name="dataObject">The DataObject instance the event invoked for.</param>
    /// <param name="serializer">Serializer that performs the deserialization.</param>
    /// <param name="info">Serialization info.</param>
    /// <param name="context">Streaming context.</param>
    /// <param name="propertyName">The name of the field that was 
    /// deserializing.</param>
    /// <param name="culture">The <see cref="Culture"/> of the field that was
    /// deserializing.</param>
    /// <param name="exception">Exception that was thrown during attempt
    /// to deserialize <paramref name="propertyName"/>.</param>
    void IDataObjectEventWatcher.OnDataObjectPropertyDeserializationError(DataObject dataObject, Serializer serializer, SerializationInfo info, StreamingContext context, string propertyName, Culture culture, Exception exception)
    {
    }

    /// <summary>
    /// Called after instance is deserialized.
    /// </summary>
    /// <param name="dataObject">The DataObject instance the event invoked for.</param>
    /// <param name="serializer">Serializer that performs the deserialization.</param>
    void IDataObjectEventWatcher.OnDataObjectDeserialized(DataObject dataObject, Serializer serializer)
    {
    }

    /// <summary>
    /// Called when the whole object graph is completely deserialized.
    /// </summary>
    /// <param name="dataObject">The DataObject instance the event invoked for.</param>
    /// <param name="serializer">Serializer that performs the deserialization.</param>
    void IDataObjectEventWatcher.OnDataObjectGraphDeserialized(DataObject dataObject, Serializer serializer)
    {
    }

    /// <summary>
    /// Called during <see cref="DataObject.GetProperty"/> method execution.
    /// </summary>
    /// <param name="dataObject">The DataObject instance the event invoked for.</param>
    /// <param name="name">Property name.</param>
    /// <param name="culture">Property culture.</param>
    /// <param name="value">Stored property value.</param>
    void IDataObjectEventWatcher.OnDataObjectGetProperty(DataObject dataObject, string name, Culture culture, object value)
    {
    }

    /// <summary>
    /// Called during <see cref="DataObject.SetProperty"/> method execution.
    /// </summary>
    /// <param name="dataObject">The DataObject instance the event invoked for.</param>
    /// <param name="name">Property name.</param>
    /// <param name="culture">Property culture.</param>
    /// <param name="value">New property value.</param>
    void IDataObjectEventWatcher.OnDataObjectSetProperty(DataObject dataObject, string name, Culture culture, object value)
    {
    }
    
    /// <summary>
    /// Called when some property was changed.
    /// </summary>
    /// <param name="dataObject">The DataObject instance the event invoked for.</param>
    /// <param name="name">Property name.</param>
    /// <param name="culture">Property culture.</param>
    /// <param name="value">New property value.</param>
    void IDataObjectEventWatcher.OnDataObjectPropertyChanged(DataObject dataObject, string name, Culture culture, object value)
    {
      Hashtable ts = (Hashtable)transactions[session.Transaction];
      if (ts!=null) {
        foreach (TrackingSet trackingSet in ts.Keys)
          trackingSet.OnDataObjectChanged(dataObject);
      }
    }

    /// <summary>
    /// Called before inner content of some non-<see cref="ValueType"/> 
    /// property is changed.
    /// </summary>
    /// <param name="dataObject">The DataObject instance the event invoked for.</param>
    /// <param name="name">Property name.</param>
    /// <param name="culture">Property culture.</param>
    /// <param name="value">Old property value.</param>
    void IDataObjectEventWatcher.OnDataObjectPropertyContentChanging(DataObject dataObject, string name, Culture culture, object value)
    {
    }

    /// <summary>
    /// Called when inner content of some non-<see cref="ValueType"/> 
    /// property was changed.
    /// </summary>
    /// <param name="dataObject">The DataObject instance the event invoked for.</param>
    /// <param name="name">Property name.</param>
    /// <param name="culture">Property culture.</param>
    /// <param name="value">New property value.</param>
    void IDataObjectEventWatcher.OnDataObjectPropertyContentChanged(DataObject dataObject, string name, Culture culture, object value)
    {
      Hashtable ts = (Hashtable)transactions[session.Transaction];
      if (ts!=null) {
        foreach (TrackingSet trackingSet in ts.Keys)
          trackingSet.OnDataObjectChanged(dataObject);
      }
    }

    /// <summary>
    /// Called when a new <see cref="Transaction"/> is started.
    /// </summary>
    /// <param name="transaction">The newly created and started <see cref="Transaction"/>.</param>
    void ITransactionEventWatcher.OnTransactionBegin(Transaction transaction)
    {
      Transaction outerTransaction = transaction.OuterTransaction;
      if (outerTransaction!=null) {
        Hashtable ts = (Hashtable)transactions[outerTransaction];
        if (ts!=null) {
          foreach (TrackingSet trackingSet in ts.Keys)
            trackingSet.OnTransactionBegin(transaction);
        }
      }
    }

    /// <summary>
    /// Called when a <see cref="Transaction"/> is going to be committed.
    /// </summary>
    /// <param name="transaction">The <see cref="Transaction"/> to be committed.</param>
    public void OnBeforeTransactionCommit (Transaction transaction)
    {
    }

    /// <summary>
    /// Called when a <see cref="Transaction"/> is committed.
    /// </summary>
    /// <param name="transaction">The committed <see cref="Transaction"/>.</param>
    void ITransactionEventWatcher.OnTransactionCommit(Transaction transaction)
    {
      Hashtable ts = (Hashtable)transactions[transaction];
      if (ts!=null) {
        TrackingSet[] sets = new TrackingSet[ts.Count];
        ts.Keys.CopyTo(sets, 0);
        foreach (TrackingSet trackingSet in sets)
          trackingSet.OnTransactionCommit();
      }
    }

    /// <summary>
    /// Called when a <see cref="Transaction"/> is going to be rolled back.
    /// </summary>
    /// <param name="transaction">The <see cref="Transaction"/> to be rolled back.</param>
    public void OnBeforeTransactionRollback (Transaction transaction)
    {
    }

    /// <summary>
    /// Called when a <see cref="Transaction"/> is rolled back.
    /// </summary>
    /// <param name="transaction">The rolled back <see cref="Transaction"/>.</param>
    void ITransactionEventWatcher.OnTransactionRollback(Transaction transaction)
    {
      Hashtable ts = (Hashtable)transactions[transaction];
      if (ts!=null) {
        TrackingSet[] sets = new TrackingSet[ts.Count];
        ts.Keys.CopyTo(sets, 0);
        foreach (TrackingSet trackingSet in sets)
          trackingSet.OnTransactionRollback();
      }
    }
    
    /// <summary>
    /// Registers <see cref="TrackingSet"/> instance. After registration TrackingSet starts
    /// to get all required notifications from <see cref="TrackingService"/>.
    /// </summary>
    /// <param name="trackingSet"><see cref="TrackingSet"/> to register.</param>
    internal void RegisterTrackingSet(TrackingSet trackingSet)
    {
      if (trackingSet==null)
        throw new ArgumentNullException("trackingSet");
      if (trackingSet.Session!=this.Session)
        throw new InvalidOperationException("TrackingSet belongs to another session.");
        
      Transaction transaction = trackingSet.Transaction;
      if (transaction==null)
        throw new InvalidOperationException("TrackingSet doesn't belong to any transactions.");
      if (transaction.IsFinished)
        throw new InvalidOperationException("Transaction is already finished.");
        
      Hashtable ts = (Hashtable)transactions[transaction];
      if (ts==null) {
        ts = new Hashtable();
        transactions[transaction] = ts;
      }
      ts[trackingSet] = ts;
    }
    
    /// <summary>
    /// Unregisters <see cref="TrackingSet"/> instance. 
    /// </summary>
    /// <param name="trackingSet"><see cref="TrackingSet"/> to unregister.</param>
    internal void UnregisterTrackingSet(TrackingSet trackingSet)
    {
      if (trackingSet==null)
        throw new ArgumentNullException("trackingSet");
      if (trackingSet.Session!=this.Session)
        throw new InvalidOperationException("TrackingSet belongs to another session.");
        
      Transaction transaction = trackingSet.Transaction;
      if (transaction==null)
        throw new InvalidOperationException("TrackingSet doesn't belong to any transactions.");
      
      Hashtable ts = (Hashtable)transactions[transaction];
      if (ts==null || !ts.Contains(trackingSet))
        throw new InvalidOperationException("TrackingSet was not registered.");
      
      ts.Remove(trackingSet);
    }
    
    /// <summary>
    /// Initializes an instance of this class.
    /// </summary>
    protected override void OnCreate()
    {
    }
  }
}
