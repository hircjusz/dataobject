// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.IO;
using System.Text;
using System.Threading;
using System.Collections;
using System.Collections.Specialized;
using System.Data;
using System.Reflection;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.EnterpriseServices;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Attributes;
using DataObjects.NET.Database;
using DataObjects.NET.ObjectModel;
using DataObjects.NET.DatabaseModel;
using DataObjects.NET.Serialization;
using DataObjects.NET.FullText;
using DataObjects.NET.Security;

namespace DataObjects.NET
{
  /// <summary>
  /// Base interface for any data interface.
  /// <see langword="Persistent"/>.
  /// <seealso cref="DataObject"/>
  /// </summary>
  public interface IDataObject: ISessionBoundObject, ISecureObject
  {
    /// <summary>
    /// Gets the ID (key) of the instance. ID is unique in the database (<see cref="Domain"/>) scope.
    /// </summary>
    [Persistent]
    [PropertyType(typeof(KeyField))]
    long ID {get;}

    /// <summary>
    /// Gets the instance's type ID. This field allows to determine the <see cref="System.Type"/> of the instance.
    /// </summary>
    [Persistent]
    int TypeID {get;}

    /// <summary>
    /// Gets the instance's version ID. This property is used for optimistic locking.
    /// </summary>
    [Persistent]
    int VersionID {get;}

    /// <summary>
    /// Gets the instance's <see cref="AccessControlList"/>.
    /// </summary>
    /// <remarks>
    /// <para>
    /// You can find more information about the whole DataObjects.NET
    /// security system <see cref="AccessControlList">here</see>.
    /// </para>
    /// </remarks>
    [Persistent]
    [Nullable]
    AccessControlList Permissions {get;}

    /// <summary>
    /// Holds serialized version of non-<see cref="LoadOnDemandAttribute">LoadOnDemand</see>
    /// object fields.
    /// This property is used to instantiate the object faster 
    /// (see "Fast fetches" description in the DataObjects.NET Manual).
    /// </summary>
    [Persistent]
    [Nullable]
    [NotSerializable]
    byte[] FastLoadData {get;}


    // Non-persistent properties & methods

    /// <summary>
    /// Gets or sets any persistent property of the instance by its name.
    /// </summary>
    [NotPersistent]
    object this[string propertyName] {get; set;}

    /// <summary>
    /// Gets or sets any persistent property of the instance by its name and culture.
    /// </summary>
    [NotPersistent]
    object this[string propertyName, Culture culture] {get; set;}

    /// <summary>
    /// Gets any persistent property of the instance by its name.
    /// </summary>
    /// <param name="name">Property name.</param>
    /// <returns>Property value.</returns>
    object GetProperty(string name);

    /// <summary>
    /// Gets any persistent property of the instance by its name and culture.
    /// </summary>
    /// <param name="name">Property name.</param>
    /// <param name="culture">Property culture.</param>
    /// <returns>Property value.</returns>
    object GetProperty(string name, Culture culture);

    /// <summary>
    /// Sets any persistent property of the instance by its name.
    /// </summary>
    /// <param name="name">Property name.</param>
    /// <param name="value">New property value.</param>
    void SetProperty(string name, object value);

    /// <summary>
    /// Sets any persistent property of the instance by its name.
    /// </summary>
    /// <param name="name">Property name.</param>
    /// <param name="culture">Property culture.</param>
    /// <param name="value">New property value.</param>
    [NotOverridable]
    void SetProperty(string name, Culture culture, object value);

//    /// <summary>
//    /// Increases the value of <see cref="VersionID"/> property of the
//    /// instance and persists it.
//    /// </summary>
//    void IncreaseVersion();
    
    /// <summary>
    /// Gets the <see cref="DataObjectState">state</see> of the instance.
    /// This property getter always updates instance's 
    /// <see cref="TransactionContext"/> (makes it equal to 
    /// <see cref="Session.TransactionContext">Session.TransactionContext</see>)
    /// and <see cref="Reload"/>s the instance if necessary.
    /// </summary>
    [NotPersistent]
    DataObjectState State {get;}

    /// <summary>
    /// Gets the <see cref="DataObjects.NET.ObjectModel.Type"/> of this instance.
    /// </summary>
    [NotPersistent]
    ObjectModel.Type Type {get;}

    /// <summary>
    /// Gets the <see cref="DataObjects.NET.TransactionContext"/> 
    /// where instance data was retrieved (so this is the context
    /// where this data is definitely valid).
    /// <seealso cref="State"/>
    /// <seealso cref="Reload"/>
    /// <seealso cref="DataObjects.NET.TransactionContext"/>
    /// </summary>
    /// <remarks>
    /// Value of this property is automatically changed during
    /// the life of <see cref="DataObject"/> instance - it becomes
    /// equal to <see cref="DataObjects.NET.Session.TransactionContext">Session.TransactionContext</see>
    /// on almost any attempt to access the property of <see cref="DataObject"/>
    /// or invoke its method. It's possible that instance will be 
    /// <see cref="Reload"/>ed on such an operation.
    /// </remarks>
    [NotPersistent]
    TransactionContext TransactionContext {get;}

    /// <summary>
    /// Gets the <see cref="DataObjects.NET.Transaction"/> 
    /// where instance data was retrieved (so this is the transaction
    /// where this data is definitely valid).
    /// <seealso cref="State"/>
    /// <seealso cref="Reload"/>
    /// <seealso cref="DataObjects.NET.Transaction"/>
    /// <seealso cref="DataObjects.NET.TransactionContext"/>
    /// </summary>
    /// <remarks>
    /// Value of this property is automatically changed during
    /// the life of <see cref="DataObject"/> instance - it becomes
    /// equal to <see cref="DataObjects.NET.Session.Transaction">Session.Transaction</see>
    /// on almost any attempt to access the property of <see cref="DataObject"/>
    /// or invoke its method. It's possible that instance will be 
    /// <see cref="Reload"/>ed on such an operation.
    /// </remarks>
    [NotPersistent]
    Transaction Transaction {get;}

    /// <summary>
    /// <see langword="True"/> if some persistent properties 
    /// of instance were changed, but not yet persisted - this means 
    /// that instance contains delayed updates.
    /// <seealso cref="Persist"/>
    /// </summary>
    [NotPersistent]
    bool IsChanged {get;}

    /// <summary>
    /// <see langword="True"/> if <see cref="Persist"/> method of this instance is executing now.
    /// </summary>
    [NotPersistent]
    bool IsPersisting {get;}

    /// <summary>
    /// Gets the count of recursive calls to <see cref="Persist"/> method of this instance.
    /// </summary>
    [NotPersistent]
    int PersistDepth {get;}

    /// <summary>
    /// <see langword="True"/> if <see cref="Remove"/> method of this instance is executing now.
    /// </summary>
    [NotPersistent]
    bool IsRemoving {get;}

    /// <summary>
    /// <see langword="True"/> if instance is deserializing now.
    /// </summary>
    [NotPersistent]
    bool IsDeserializing {get;}

    /// <summary>
    /// Persists instance to the database.
    /// </summary>
    /// <remarks>
    /// Normally you shouldn't call this method manually - DataObjects.NET
    /// persists instances transparently on any changes or delayes the call
    /// to this method before the moment then this will be absolutely
    /// necessary.
    /// <seealso cref="IsChanged"/>
    /// </remarks>
    void Persist();

    /// <summary>
    /// Loads all properties of the instance including 
    /// properties marked by [<see cref="LoadOnDemandAttribute"/>].
    /// </summary>
    void LoadAll();

    /// <summary>
    /// Reloads the instance from the database.
    /// </summary>
    /// <remarks>
    /// <para>
    /// Normally you should never call this method directly except
    /// if you're working on read committed <see cref="IsolationLevel"/>.
    /// </para>
    /// <para>
    /// This method first performs version check - it compares
    /// <see cref="VersionID"/> property value of instance with
    /// one stored in the database. If versions are equals, it does nothing,
    /// otherwise it refetches all instance properties without 
    /// <see cref="LoadOnDemandAttribute"/> applied (and marks all
    /// other properties as "should fetch on demand").
    /// </para>
    /// <para>
    /// This method is called automatically on almost any operation 
    /// with instance if DataObjects.NET notices that instance data isn't 
    /// valid in current <see cref="DataObjects.NET.Session.TransactionContext">Session.TransactionContext</see>.
    /// It compares instance's <see cref="TransactionContext"/> with 
    /// <see cref="DataObjects.NET.Session.TransactionContext">Session.TransactionContext</see>
    /// (reference comparison) to check this condition (equals
    /// means that instance data is valid).
    /// </para>
    /// <para>
    /// Instance's <see cref="TransactionContext"/> becomes equal to 
    /// <see cref="DataObjects.NET.Session.TransactionContext">Session.TransactionContext</see>
    /// after call to this method.
    /// </para>
    /// <seealso cref="TransactionContext"/>
    /// <seealso cref="DataObjects.NET.Session.TransactionContext"/>
    /// </remarks>
    void Reload();

    /// <summary>
    /// Updates inconsistent <see cref="FastLoadData"/> and <see cref="Permission"/>
    /// data of the instance (e.g. when <see cref="FastLoadData"/> is empty or 
    /// <see cref="Permissions"/> contain some allow\deny <see cref="PermissionSet"/>s 
    /// for a <see cref="Principal"/> that currently doesn't exist).
    /// </summary>
    void UpdateInconsistentData();

    /// <summary>
    /// Updates inconsistent <see cref="FastLoadData"/> and <see cref="Permission"/> 
    /// data of the instance (e.g. when <see cref="FastLoadData"/> is empty or 
    /// <see cref="Permissions"/> contain some allow\deny <see cref="PermissionSet"/>s 
    /// for a <see cref="Principal"/> that currently doesn't exist).
    /// </summary>
    /// <param name="probability">A probability (in percents) of update. 
    /// Used only when update is necessary.</param>
    void UpdateInconsistentData(int probability);

    /// <summary>
    /// Removes the instance and all 
    /// <see cref="ContainedAttribute">contained</see> instances.
    /// </summary>
    void Remove();

    /// <summary>
    /// Tries to aquire a lock of <paramref name="lockType"/> on the instance.
    /// </summary>
    /// <param name="lockType">Type of lock to aquire.</param>
    void Lock(LockType lockType);
    
    /// <summary>
    /// Gets the <see cref="Session.SecurityRoot"/> object.
    /// <seealso cref="ISecurityRoot"/>
    /// <seealso cref="SecurityRoot"/>
    /// </summary>
    /// <returns><see cref="Session.SecurityRoot"/> object.</returns>
    /// <remarks>
    /// <para>
    /// You can find more information about the whole DataObjects.NET
    /// security system <see cref="AccessControlList">here</see>.
    /// </para>
    /// </remarks>
    [NotPersistent]
    DataObject SecurityRoot {get;}

    /// <summary>
    /// Gets the security parent object for this <see cref="DataObject"/> instance.
    /// This property is used by the security system during permission
    /// demands.
    /// </summary>
    /// <returns>Parent object for this <see cref="DataObject"/> instance.</returns>
    /// <remarks>
    /// <para>
    /// See <see cref="DataObject.SecurityParent">DataObject.SecurityParent</see>
    /// property description for additional information.
    /// </para>
    /// </remarks>
    [NotPersistent]
    DataObject SecurityParent {get;}

    /// <summary>
    /// Gets the collection (<see cref="QueryResult"/>) of children objects 
    /// for this <see cref="DataObject"/> instance.
    /// This property is used by the security system during changing child object
    /// permissions (see <see cref="AccessControlList.ResetChildrenPermissions"/>). 
    /// </summary>
    /// <remarks>
    /// <para>
    /// This property can return <see langword="null"/> value (this should
    /// be considered as absence of any child objects).
    /// </para>
    /// <para>
    /// See <see cref="DataObject.SecurityChildren">DataObject.SecurityChildren</see>
    /// property description for additional information.
    /// </para>
    /// </remarks>
    [NotPersistent]
    QueryResult SecurityChildren {get;}

    /// <summary>
    /// Gets object version code.
    /// Version code is a string identifying
    /// "UI version" of the current instance.
    /// <seealso cref="CompareVersionCode"/>
    /// <seealso cref="VersionID"/>
    /// </summary>
    /// <remarks>
    /// <para>
    /// Usually lots of types can be modified 
    /// by user (manually) and by some automatic 
    /// services, such as full-text indexer.
    /// Since both update types change <see cref="VersionID"/>
    /// property, it's impossible to use its value
    /// for detecting the "UI changes" (changes
    /// made to the same object by different persons - 
    /// e.g. to implement an optimistic locking
    /// behavior in the web application.
    /// </para>
    /// <para>
    /// <see cref="VersionCode"/> property provides a common
    /// way of doing this - by default any <see cref="DataObject"/>
    /// instance returns its <see cref="VersionID"/> value from
    /// this property, but you can override it property in your 
    /// descendants. E.g. you can return a value of your own
    /// <see langword="ModifyDate"/> property, that doesn't change
    /// on any service-made updates, and thus allows to detect the
    /// UI changes better.
    /// </para>
    /// </remarks>
    [NotPersistent]
    string VersionCode {get;}
    
    /// <summary>
    /// Return <see langword="true"/> if specified 
    /// <paramref name="versionCode"/> corresponds to the
    /// active "UI state" of instance;
    /// otherwise, <see langword="false"/>.
    /// See <see cref="VersionCode"/> property description for
    /// additional information.
    /// <seealso cref="VersionCode"/>
    /// <seealso cref="VersionID"/>
    /// </summary>
    /// <param name="versionCode">Version code to check.</param>
    /// <returns><see langword="True"/> if specified 
    /// <paramref name="versionCode"/> corresponds to the
    /// active "UI state" of instance;
    /// otherwise, <see langword="false"/>.</returns>
    /// <remarks>
    /// By default any <see cref="DataObject"/> instance returns 
    /// <see langword="true"/>, if specified <paramref name="versionCode"/>
    /// equals to its <see cref="VersionID"/>; otherwise it returns
    /// <see langword="false"/>.
    /// </remarks>
    bool CompareVersionCode(string versionCode);
  }
}
