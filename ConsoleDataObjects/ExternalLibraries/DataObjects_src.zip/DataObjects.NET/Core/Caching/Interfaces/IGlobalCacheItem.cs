// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;

namespace DataObjects.NET.Caching
{
  /// <summary>
  /// This interface should be implemented by classes,
  /// that can be stored in global cache.
  /// </summary>
  public interface IGlobalCacheItem: 
    IGlobalCacheItemValidationInfo,
    ICloneable
  {
    /// <summary>
    /// Gets item type.
    /// </summary>
    GlobalCacheItemType ItemType {get;}
    
    /// <summary>
    /// Gets a value indicating whether current item can be cached.
    /// </summary>
    bool CanCache {get;}
    
    /// <summary>
    /// This method is called when item is placed into global cache.
    /// </summary>
    void OnCached();
    
    /// <summary>
    /// This method is called when item is validated by validation info.
    /// </summary>
    /// <param name="vInfo">Validation info.</param>
    void OnValidated(IGlobalCacheItemValidationInfo vInfo);
  }
}
