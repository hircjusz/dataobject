// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;
using System.Runtime.Serialization;
using DataObjects.NET;
using DataObjects.NET.ObjectModel;

namespace DataObjects.NET
{
  [Serializable]
  internal class StructHolder : ISerializable, ICloneable
  {
    private string[] fieldNames;
    private object[] fieldValues;
    private BitArray changedFields;
//    private bool     validated;

    public string[] FieldNames {
      get {
        return fieldNames;
      }
    }

    public object[] FieldValues {
      get{
        return fieldValues;
      }
    }

    public BitArray ChangedFields {
      get {
        return changedFields;
      }
    }

//    public void Validate(StructField field)
//    {
//      if (validated)
//        return;
//
//      int i, j;
//      for (i = 0; i<field.ContainedFields.Count && i<fieldNames.Length && field.ContainedFields[i].Name==fieldNames[i]; i++);
//      if (i!=field.ContainedFields.Count || i!=fieldNames.Length) {
//        object[] newFieldValues   = new object[field.ContainedFields.Count];
//        bool[]   newChangedFields = new bool[field.ContainedFields.Count];
//        for (i = 0; i<field.ContainedFields.Count; i++)
//          for (j = 0; j<fieldNames.Length; j++)
//            if (field.ContainedFields[i].Name==fieldNames[j]) {
//              newFieldValues[i]   = fieldValues[j];
//              newChangedFields[i] = changedFields[j];
//              break;
//            }
//        fieldValues   = newFieldValues;
//        fieldNames    = field.MemberNames;
//        changedFields = newChangedFields;
//      }
//      validated = true;
//    }

    object ICloneable.Clone()
    {
      return Clone();
    }
    
    public StructHolder Clone()
    {
      object[] newFieldValues = new object[fieldValues.Length];
      int l = fieldValues.Length;
      for (int i = 0; i<l; i++) {
        object curentValue = fieldValues[i];
        if (curentValue is ICloneable)
          newFieldValues[i] = (curentValue as ICloneable).Clone();
        else
          newFieldValues[i] = curentValue;
      }

      StructHolder clone  = new StructHolder();
      clone.fieldValues   = newFieldValues;
      clone.fieldNames    = fieldNames;
      clone.changedFields = (BitArray)changedFields.Clone();
//      clone.validated = validated;
      return clone;
    }

    /// <summary>
    /// Serializer.
    /// </summary>
    /// <param name="info"><see cref="SerializationInfo"/> object.</param>
    /// <param name="context"><see cref="StreamingContext"/> object.</param>
    public void GetObjectData(SerializationInfo info, StreamingContext context)
    {
      info.AddValue("FieldNames",  fieldNames);
      info.AddValue("FieldValues", fieldValues);
    }
    
    
    // Constructors

    private StructHolder()
    {
    }

    public StructHolder(object[] fieldValues, string[] fieldNames, bool changed)
    {
//      this.validated   = true;
      this.fieldNames  = fieldNames;
      this.fieldValues = fieldValues;
      this.changedFields = new BitArray(fieldValues.Length);
      for (int i = 0; i < fieldValues.Length; i++)
        changedFields[i] = changed;
    }

    /// <summary>
    /// Deserialization constructor.
    /// </summary>
    /// <param name="info"><see cref="SerializationInfo"/> object.</param>
    /// <param name="context"><see cref="StreamingContext"/> object.</param>
    protected StructHolder(SerializationInfo info, StreamingContext context)
    {
//      validated     = false;
      fieldNames    = (string[])info.GetValue("FieldNames", typeof(object));
      fieldValues   = (object[])info.GetValue("FieldValues", typeof(object));
      changedFields = new BitArray(fieldValues.Length);
      for (int i = 0; i < fieldValues.Length; i++)
        changedFields[i] = false;
    }
  }
}
