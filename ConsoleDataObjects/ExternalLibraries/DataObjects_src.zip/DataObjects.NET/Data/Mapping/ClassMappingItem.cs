// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.ComponentModel;
using DataObjects.NET.Data.Design;

namespace DataObjects.NET.Data
{
  /// <summary>
  /// Class mapping item.
  /// </summary>
  [TypeConverter(typeof(ClassMappingItemConverter))]
  public class ClassMappingItem: FullContainerMappingItem
  {
    private string className;
    
    /// <summary>
    /// Gets item name.
    /// </summary>
    public override string Name {
      get {
        if (className!=null)
          return className;
        return "Class Mapping Item";
      }
    }
    
    /// <summary>
    /// Gets or sets class name.
    /// </summary>
    [Category("Mapping")]
    [TypeConverter(typeof(ClassNameConverter))]
    public string ClassName {
      get {
        return className;
      }
      set {
        className = value;
      }
    }
    
    /// <summary>
    /// Initializes a new instance of the <see cref="ClassMappingItem"/> class.
    /// </summary>
    public ClassMappingItem(): this(null, null)
    {
    }
    
    /// <summary>
    /// Initializes a new instance of the <see cref="ClassMappingItem"/> class.
    /// </summary>
    /// <param name="className">Class name.</param>
    /// <param name="tableName">Database table name.</param>
    public ClassMappingItem(string className, string tableName): base(tableName)
    {
      this.className = className;
    }
  }
}
