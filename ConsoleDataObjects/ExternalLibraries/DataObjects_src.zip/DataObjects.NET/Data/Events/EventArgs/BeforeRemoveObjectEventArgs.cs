// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using DataObjects.NET;
using DataObjects.NET.Data;

namespace DataObjects.NET.Data
{
  /// <summary>
  /// Provides information for <see cref="Adapter.BeforeRemoveObject"/> event.
  /// </summary>
  public class BeforeRemoveObjectEventArgs
  {
    private DataObject dataObject;
    
    /// <summary>
    /// Gets <see cref="DataObject"/> instance that will be removed.
    /// </summary>
    public DataObject DataObject {
      get {
        return dataObject;
      }
    }
    
    /// <summary>
    /// Initializes a new instance of the <see cref="BeforeRemoveObjectEventArgs"/> class.
    /// </summary>
    /// <param name="dataObject"><see cref="DataObject"/> instance that will be removed.</param>
    internal BeforeRemoveObjectEventArgs(DataObject dataObject)
    {
      if (dataObject==null)
        throw new ArgumentNullException("dataObject");
        
      this.dataObject = dataObject;
    }
  }
}
