// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Data;
using System.Collections;
using System.Collections.Specialized;
using System.Reflection;
using System.Text.RegularExpressions;
using System.CodeDom;
using System.CodeDom.Compiler;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Attributes;
using DataObjects.NET.Database;
using DataObjects.NET.ObjectModel;
using DataObjects.NET.ObjectModel.Builders;

namespace DataObjects.NET
{
  /// <summary>
  /// Keeps the result of proxy classes building.
  /// See <see cref="ProxyBuilder"/> for details.
  /// </summary>
  #if (!NoMBR)
  public class ProxyBuilderResults: MarshalByRefObject
  #else
  public class ProxyBuilderResults: Object
  #endif
  {
    private Assembly assembly;
    /// <summary>
    /// Holds reference to assembly with generated proxy classes.
    /// </summary>
    public  Assembly Assembly {
      get {return assembly;}
    }
    
    private NameValueCollection proxyNames;
    /// <summary>
    /// Maps names of DataObject types to names of their proxy types.
    /// </summary>
    public  string GetProxyName(string fullTypeName) 
    {
      return proxyNames[fullTypeName];
    }
    
    private NameValueCollection offlineProxyNames;
    /// <summary>
    /// Maps names of DataObject types to names of their offline proxy types.
    /// </summary>
    public  string GetOfflineProxyName(string fullTypeName) 
    {
      return offlineProxyNames[fullTypeName];
    }

    
    private CompilerResults compilerResults;
    /// <summary>
    /// Provides access to the result of proxy assembly compilation.
    /// </summary>
    public  CompilerResults CompilerResults {
      get {return compilerResults;}
    }
    
    
    // Constructor
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="compilerResults">Result of proxy accemply compilation.</param>
    /// <param name="assembly">Proxy assembly.</param>
    /// <param name="proxyNames">Holds proxy name mapping.</param>
    /// <param name="offlineProxyNames">Holds offline proxy name mapping.</param>
    internal ProxyBuilderResults(CompilerResults compilerResults, 
      Assembly assembly,
      NameValueCollection proxyNames, 
      NameValueCollection offlineProxyNames) 
    {
      this.assembly = assembly;
      this.compilerResults = compilerResults;
      if (compilerResults!=null && !compilerResults.Errors.HasErrors)
        this.assembly = compilerResults.CompiledAssembly;
      this.proxyNames = proxyNames;
      this.offlineProxyNames = offlineProxyNames;
    }
  }
}
