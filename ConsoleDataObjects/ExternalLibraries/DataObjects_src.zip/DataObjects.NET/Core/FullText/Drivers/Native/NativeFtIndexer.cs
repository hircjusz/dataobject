// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Diagnostics;
using DataObjects.NET;
using DataObjects.NET.Attributes;
using DataObjects.NET.Exceptions;
using DataObjects.NET.FullText;

namespace DataObjects.NET.FullText.Drivers.Native
{
  /// <summary>
  /// A service that performs full-text indexing for the
  /// <see cref="NativeFtsDriver"/>.
  /// </summary>
  public sealed class NativeFtIndexer
    : IFtIndexer
  {
    private FtIndexerService containerService;
    private const int maxCreateFtRecordsPerIteration   = 5000;
    private const int maxUpdateFtRecordsPerIteration   = 5000;
    private const int maxInvalidateObjectsPerIteration = 5000;
    
    private TimeSpan period      = TimeSpan.FromMinutes(3);
    private TimeSpan shortPeriod = TimeSpan.FromSeconds(10);
    private TimeSpan nextPeriod  = TimeSpan.FromMinutes(3);
    private int      maxObjectsPerIteration = 200;
    
    /// <summary>
    /// Gets the delay to make before the next execution.
    /// </summary>
    /// <param name="e">Exception thrown by previous <see cref="Execute"/> call, <see langword="null"/> if call succeeded.</param>
    /// <returns>delay.</returns>
    [Transactional(TransactionMode.Disabled)]
    public TimeSpan GetDelay(Exception e)
    {
      return nextPeriod;
    }

    /// <summary>
    /// This method is invoked by <see cref="FtIndexerService"/> periodically
    /// and makes all indexing job.
    /// </summary>
    public void Execute()
    {
      TransactionController transactionController = containerService.Session.CreateTransactionController(TransactionMode.TransactionRequired);
      Reprocess:
      try {
        nextPeriod = period;
        if (!containerService.Domain.DriverInfo.SupportsFullTextIndexing)
          return;
        try {
          // We need maximal permissions during re-indexing
          using (containerService.CreateSecurityDisabler()) {
            int removed = RemoveFtRecords(maxObjectsPerIteration);
            UpdateFtRecords(maxObjectsPerIteration - removed);
          }
        }
        catch (TransactionCanBeReprocessedException e) {
          nextPeriod = shortPeriod;
#if DEBUG
          Debug.WriteLineIf(FtsDriver.TraceIndexerExceptionsSwitch.TraceInfo, String.Format("{0} Info: An exception {1} occured during full-text indexing. Indexing attempt will be re-executed in {2} second(s).", DateTime.Now, e.ToString(), shortPeriod.TotalSeconds), FtsDriver.TraceIndexerExceptionsCategoryName);
#else
          Trace.WriteLineIf(FtsDriver.TraceIndexerExceptionsSwitch.TraceInfo, String.Format("{0} Info: An exception {1} occured during full-text indexing. Indexing attempt will be re-executed in {2} second(s).", DateTime.Now, e.Message, shortPeriod.TotalSeconds), FtsDriver.TraceIndexerExceptionsCategoryName);
#endif
          throw;
        }
        catch (Exception e) {
          nextPeriod = shortPeriod;
#if DEBUG
          Debug.WriteLineIf(FtsDriver.TraceIndexerExceptionsSwitch.TraceError, String.Format("{0} Error: An exception {1} occured during indexing", DateTime.Now, e.ToString()), FtsDriver.TraceIndexerExceptionsCategoryName);
#else
          Trace.WriteLineIf(FtsDriver.TraceIndexerExceptionsSwitch.TraceError, String.Format("{0} Error: An exception {1} occured during indexing", DateTime.Now, e.Message), FtsDriver.TraceIndexerExceptionsCategoryName);
#endif
          throw;
        }
      }
      catch (Exception e) {
        if (transactionController.Rollback(e, true))
          goto Reprocess;
        throw;
      }
    }
    
    /// <summary>
    /// Creats <see cref="FtRecord"/>s for all <see cref="IFtObject"/> instances
    /// that can provide full-text data but don't have correspondent 
    /// <see cref="FtRecord"/>s for some reasons. 
    /// </summary>
    /// <remarks>
    /// This method is potentially useful for upgrading form earlier versions.
    /// </remarks>
    public void CreateFtRecords()
    {
      using (containerService.CreateSecurityDisabler()) {
        Query q = new Query(containerService.Session,
          "Select IFtObject instances as $fto " + 
          "where not exists {Select FtRecord objects where ({FtObject}={$fto})}");
        
        QueryResult r = q.Execute(QueryOptions.LoadOnDemand);
        int cnt = r.Count;
        
        for (int i = 0; i<cnt; i+=maxCreateFtRecordsPerIteration) {
          int preloadCnt = maxCreateFtRecordsPerIteration;
          if ((i + preloadCnt)>cnt)
            preloadCnt = cnt - i;
          
          long[] ids = r.GetIDs(i, preloadCnt);
          containerService.Session.Preload(ids);
          
          foreach (long id in ids) {
            IFtObject ftObject = (IFtObject)containerService.Session[id];
            if (ftObject.HasFtData)
              containerService.Session.CreateObject(typeof(FtRecord), new object[] {ftObject});
          }
        }
      }
    }
    
    /// <summary>
    /// Removes all <see cref="FtRecord"/>s which don't have corresponding
    /// <see cref="IFtObject"/> instances. Normally full-text indexer
    /// removes such <see cref="FtRecord"/>s in one or several iterations. 
    /// But in case when it is required to remove all such <see cref="FtRecord"/>s
    /// immediately this method may be used.
    /// </summary>
    /// <remarks>
    /// This method is potentially useful for upgrading form earlier versions.
    /// </remarks>
    public void CleanupFtRecords()
    {
      using (containerService.CreateSecurityDisabler()) {
        RemoveFtRecords(-1);
      }
    }
    
    /// <summary>
    /// Updates all full-text data which is not up-to-date.
    /// Normally full-text indexer updates full-text data in one or several
    /// iterations. But in case when it is necessary to update all full-text
    /// data immediately this method may be used.
    /// </summary>
    /// <remarks>
    /// This method is potentially useful for upgrading form earlier versions.
    /// </remarks>
    public void UpdateIndex()
    {
      using (containerService.CreateSecurityDisabler()) {
        UpdateFtRecords(-1);
      }
    }
    
    /// <summary>
    /// Invalidates all full-text data. Sets <see cref="IFtObject.FtRecordIsUpToDate"/>
    /// to <see langword="false"/> for all <see cref="IFtObject"/> objects.
    /// </summary>
    /// <remarks>
    /// This method is potentially useful for upgrading form earlier versions.
    /// </remarks>
    public void InvalidateIndex()
    {
      using (containerService.CreateSecurityDisabler()) {
        Query q = new Query(containerService.Session, "Select IFtObject instances");
          
        QueryResult r = q.Execute(QueryOptions.LoadOnDemand);
        int cnt = r.Count;
      
        for (int i = 0; i<cnt; i+=maxInvalidateObjectsPerIteration) {
          int preloadCnt = maxInvalidateObjectsPerIteration;
          if ((i + preloadCnt)>cnt)
            preloadCnt = cnt - i;
        
          long[] ids = r.GetIDs(i, preloadCnt);
          containerService.Session.Preload(ids);
        
          foreach (long id in ids) {
            IFtObject ftObject = (IFtObject) containerService.Session[id];
            ftObject.SetProperty("FtRecordIsUpToDate", null, false);
          }
        }
      }
    }
    
    private int RemoveFtRecords(int maxObjectsPerIteration)
    {
      if (maxObjectsPerIteration==0)
        return 0;
        
      Query q = new Query(containerService.Session,
        "Select " +
        ((maxObjectsPerIteration>0) ? ("top " + maxObjectsPerIteration + " ") : "") +
        "FtRecord instances " +
        ((maxObjectsPerIteration>0) ? "with (SkipLocked) " : "") +
        "where {FtObject}=0");
        
      QueryResult r = q.Execute(QueryOptions.LoadOnDemand);
      int cnt = r.Count;
      
      if (maxObjectsPerIteration>0 && cnt==maxObjectsPerIteration)
        nextPeriod = shortPeriod;
      
      containerService.Session.RemoveObjects(r.GetIDs());
      
      return cnt;
    }
    
    private int UpdateFtRecords(int maxObjectsPerIteration)
    {
      if (maxObjectsPerIteration==0)
        return 0;
        
      string falseValue = containerService.Domain.DriverInfo.SupportsRealBoolean ? "false" : "0";
      Query q = new Query(containerService.Session, 
        "Select " +
        ((maxObjectsPerIteration>0) ? ("top " + maxObjectsPerIteration + " ") : "") +
        "FtRecord instances " +
        ((maxObjectsPerIteration>0) ? "with (SkipLocked) " : "") +
        "inner join $root.FtObject as $fto " +
        "where {$fto.FtRecordIsUpToDate}="+falseValue);
        
      QueryResult r = q.Execute(QueryOptions.LoadOnDemand);
      int cnt = r.Count;
      
      if (maxObjectsPerIteration>0 && cnt==maxObjectsPerIteration)
        nextPeriod = shortPeriod;
      
      for (int i = 0; i<cnt; i+=maxUpdateFtRecordsPerIteration) {
        int preloadCnt = maxUpdateFtRecordsPerIteration;
        if ((i + preloadCnt)>cnt)
          preloadCnt = cnt - i;
        
        long[] ids = r.GetIDs(i, preloadCnt);
        containerService.Session.Preload(ids);
        
        foreach (long id in ids) {
          FtRecord ftRecord = (FtRecord)containerService.Session[id];
          IFtObject ftObject = ftRecord.FtObject;
          if (ftObject.HasFtData)
            ftRecord.UpdateFtData();
          else
            ftRecord.Remove();
          ftObject.SetProperty("FtRecordIsUpToDate", null, true);
        }
      }
      
      return cnt;
    }
    
    /// <summary>
    /// Sets the <see cref="FtIndexerService"/> which is runs the indexer.
    /// </summary>
    void IFtIndexer.SetContainerService(FtIndexerService containerService)
    {
      if (this.containerService!=null)
        throw new InvalidOperationException("SetContainerService method can be called only once.");
      this.containerService = containerService;
    }
    
    // Constructors

    /// <summary>
    /// Initializes an instance of this class.
    /// </summary>
    public NativeFtIndexer()
    {
    }

    /// <summary>
    /// Initializes an instance of this class.
    /// </summary>
    /// <param name="period">Time interval between indexing iterations.</param>
    public NativeFtIndexer(TimeSpan period)
    {
      this.period = period;
    }
    
    /// <summary>
    /// Initializes an instance of this class.
    /// </summary>
    /// <param name="period">Time interval between indexing iterations.</param>
    /// <param name="shortPeriod">Time interval between next indexing iteration 
    /// in case when the previous indexing iteration wasn't fully completed.</param>
    public NativeFtIndexer(TimeSpan period, TimeSpan shortPeriod)
    {
      this.period = period;
      this.shortPeriod = shortPeriod;
    }
    
    /// <summary>
    /// Initializes an instance of this class.
    /// </summary>
    /// <param name="period">Time interval between indexing iterations.</param>
    /// <param name="shortPeriod">Time interval between next indexing iteration 
    /// in case when the previous indexing iteration wasn't fully completed.</param>
    /// <param name="maxObjectsPerIteration">Maximal number of objects that can 
    /// be processed per one iteration.</param>
    public NativeFtIndexer(TimeSpan period, TimeSpan shortPeriod, int maxObjectsPerIteration)
    {
      this.period = period;
      this.shortPeriod = shortPeriod;
      this.maxObjectsPerIteration = maxObjectsPerIteration;
    }
    
    /// <summary>
    /// Initializes an instance of this class.
    /// </summary>
    /// <param name="maxObjectsPerIteration">Maximal number of objects that can 
    /// be processed per one iteration.</param>
    public NativeFtIndexer(int maxObjectsPerIteration)
    {
      this.maxObjectsPerIteration = maxObjectsPerIteration;
    }
  }
}
