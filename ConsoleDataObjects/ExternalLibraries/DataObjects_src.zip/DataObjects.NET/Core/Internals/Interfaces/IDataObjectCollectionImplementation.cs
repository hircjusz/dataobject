// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;

namespace DataObjects.NET.Internals
{
  /// <summary>
  /// An interface describing underlying <see cref="DataObjectCollection"/> implementation.
  /// </summary>
  public interface IDataObjectCollectionImplementation
  {
    /// <summary>
    /// Called on attachment to <see cref="DataObject"/>.
    /// </summary>
    void Attach();

    /// <summary>
    /// Called on detachment from <see cref="DataObject"/>.
    /// </summary>
    void Detach();

    /// <summary>
    /// Invalidates caches.
    /// </summary>
    void InvalidateCache();

    /// <summary>
    /// <see langword="True"/> if the collection is completely loaded;
    /// otherwise, <see langword="false"/>.
    /// </summary>
    bool IsLoaded {get;}
    
    /// <summary>
    /// Loads collection from the database.
    /// </summary>
    void Load();

    /// <summary>
    /// Loads collection content from the given <see cref="ArrayList"/>.
    /// </summary>
    void Load(ArrayList queryResultData);

    /// <summary>
    /// Loads collection content from the given <see cref="ArrayList"/> contaning preload data.
    /// </summary>
    void Load(ArrayList dbItems, int startIndex, int count);

    /// <summary>
    /// Loads collection content from deserialized 
    /// <see cref="DataObject.FastLoadData"/> for this collection.
    /// </summary>
    /// <param name="itemIds">An <see cref="Array"/> containing item IDs.</param>
    /// <param name="count">The count of items in the collection.</param>
    void Load(long[] itemIds,  int count);

    /// <summary>
    /// Caches the specified item.
    /// </summary>
    /// <param name="value">Item to cache.</param>
    /// <param name="exists"><see langword="True"/> if the specified item exists
    /// in the collection; otherwise, <see langword="false"/>.</param>
    void CacheItem(long value, bool exists);

    /// <summary>
    /// Gets the number of elements contained in the collection.
    /// </summary>
    int Count {get;}
    
    /// <summary>
    /// Returns an <see cref="Array"/> with contained items.
    /// </summary>
    /// <returns><see cref="Array"/> with contained items.</returns>
    long[] GetContainedItems();

    /// <summary>
    /// Returns an enumerator that can iterate through the
    /// collection instance.
    /// </summary>
    /// <returns>
    /// An <see cref="IEnumerator"/> for the 
    /// collection instance.
    /// </returns>
    IEnumerator GetEnumerator();

    /// <summary>
    /// Removes all objects from the collection instance.
    /// </summary>
    void Clear();

    /// <summary>
    /// Returns <see langword="True"/> if the specified item
    /// exists in the collection; otherwise, <see langword="false"/>.
    /// </summary>
    /// <param name="value">Item to check.</param>
    /// <returns><see langword="True"/> if the specified item
    /// exists in the collection; otherwise, <see langword="false"/>.</returns>
    bool Contains(long value);
    
    /// <summary>
    /// Searches for the specified value and returns the index of the first occurrence within the current instance.
    /// </summary>
    /// <param name="value">The value to locate.</param>
    /// <returns>The index of the first occurrence of value within the entire collection, if found; otherwise, -1.</returns>
    int IndexOf(long value);
    
    /// <summary>
    /// Adds new element to the collection.
    /// </summary>
    /// <param name="value">Item to add.</param>
    /// <returns>Index of newly added item.</returns>
    int  Add(long value);
    
    /// <summary>
    /// Removes element from the collection instance.
    /// </summary>
    /// <param name="value">Item to remove.</param>
    void Remove(long value);
    
    /// <summary>
    /// Gets the element at the specified index.
    /// </summary>
    /// <param name="index">Item index.</param>
    long GetItem(int index);
    
    /// <summary>
    /// Sets the element in the collection.
    /// </summary>
    /// <param name="oldValue">Old value.</param>
    /// <param name="newValue">New value.</param>
    void SetItem(long oldValue, long newValue);

    /// <summary>
    /// Indicates whether collection contains delayed updates.
    /// </summary>
    bool IsChanged {get;}

    /// <summary>
    /// Persists all delayed updates from the collection to the database.
    /// </summary>
    void Persist();

    /// <summary>
    /// Clears all delayed updates.
    /// </summary>
    void ClearChanges();

    /// <summary>
    /// Restricts query range to elements of collection.
    /// </summary>
    /// <param name="query">Query to restrict.</param>
    void RestrictQuery(QueryBase query);
    
    /// <summary>
    /// Loads collection content from <see cref="DataObjects.NET.Caching.GlobalCache"/>.
    /// </summary>
    /// <returns>Cached collection content.</returns>
    long[] LoadItemsFromGlobalCache();
    
    /// <summary>
    /// Saves collection content to <see cref="DataObjects.NET.Caching.GlobalCache"/>.
    /// </summary>
    void SaveItemsToGlobalCache();
    
    /// <summary>
    /// Loads the number of elements contained in the collection from <see cref="DataObjects.NET.Caching.GlobalCache"/>.
    /// </summary>
    /// <returns>Cached collection size.</returns>
    int LoadCountFromGlobalCache();
    
    /// <summary>
    /// Saves the number of elements contained int the collection to <see cref="DataObjects.NET.Caching.GlobalCache"/>.
    /// </summary>
    void SaveCountToGlobalCache();
  }
}
