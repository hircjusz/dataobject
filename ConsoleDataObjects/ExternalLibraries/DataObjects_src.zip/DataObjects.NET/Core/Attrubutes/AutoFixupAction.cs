// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;

namespace DataObjects.NET.Attributes
{
  /// <summary>
  /// Enumerates supported actions to maintain referential integrity.
  /// See <see cref="AutoFixupAttribute"/>.
  /// <seealso cref="AutoFixupAttribute"/>
  /// </summary>
  public enum AutoFixupAction
  {
    /// <summary>
    /// Denotes that no action required to support referential integrity.
    /// </summary>
    None,
    
    /// <summary>
    /// Default auto-fixup action. Denotes that a reference should be automatically set to
    /// <see langword="null"/> on removal of its target.
    /// </summary>
    Clear,
    
    /// <summary>
    /// Denotes that it's necessary to prevent removal of reference target.
    /// An exception will be thrown on attempt to do this except the case when
    /// reference holder object is also <see cref="DataObject.IsRemoving">removing</see>.
    /// </summary>
    Block
  }
}
