// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Attributes;
using DataObjects.NET.Caching;

namespace DataObjects.NET
{
  /// <summary>
  /// Enumeration of possible <see cref="DataObject"/> instance 
  /// caching states.
  /// <seealso cref="SessionCache.GetObjectCachingState"/>
  /// <seealso cref="SessionCache.IsObjectCached"/>
  /// <seealso cref="Session.Preload"/>
  /// </summary>
  public enum DataObjectCachingState
  {
    /// <summary>
    /// Instance is not cached (so it was never accessed, or
    /// it was accessed, but collected by a garbage collector further).
    /// Value is <see langword="0"/>. 
    /// </summary>
    NotCached = 0,
    /// <summary>
    /// Instance is cached (so an attempt to access this instance in
    /// the current transaction will not lead any queries).
    /// Value is <see langword="1"/>. 
    /// </summary>
    Cached = 1,
    /// <summary>
    /// Instance is cached, but its version should be checked to
    /// determine if its cached data is valid. So an attempt to
    /// access any persistent property of this instance will lead
    /// to an additional version check query. E.g. any cached instance
    /// gets this state on completion of the outermost transaction
    /// where it was accessed.
    /// Value is <see langword="3"/>. 
    /// </summary>
    CachedButRequiresVersionCheck = 3,
    /// <summary>
    /// Instance is cached, but it contains a "dirty" data.
    /// So its data will be re-fetched from the database
    /// on attempt to access any its persistent property.
    /// E.g. an instance gets this state if it was modified 
    /// or fetched diring a transaction that was rolled back.
    /// This state has almost the same meaning as 
    /// <see cref="NotCached"/> state.
    /// Value is <see langword="4"/>. 
    /// </summary>
    CachedButDirty = 4
  }
}
