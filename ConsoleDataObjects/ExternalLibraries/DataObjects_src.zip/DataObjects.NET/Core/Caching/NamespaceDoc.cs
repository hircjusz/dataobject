// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;

namespace DataObjects.NET.Caching
{
  /// <summary>
  /// Contains caching-related classes. Most important of them are
  /// <see cref="GlobalCache"/> and <see cref="SessionCache"/>.
  /// </summary>
  internal class NamespaceDoc {}
}
