// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using DataObjects.NET;
using DataObjects.NET.Data;

namespace DataObjects.NET.Data
{
  /// <summary>
  /// Represents a method that will handle the <see cref="Adapter.EnqueueObject"/> events.
  /// </summary>
  /// <param name="sender">The source of the event.</param>
  /// <param name="e">An <see cref="EnqueueObjectEventArgs"/> that contains the event data.</param>
  /// <remarks>
  /// <para>
  /// This event is raised when <see cref="Adapter"/> prepares to enqueue the <see cref="DataObject"/>
  /// for further filling. 
  /// </para>
  /// <para>
  /// Setting <see cref="EnqueueObjectEventArgs.Enqueue"/> property
  /// to <see langword="false"/> event handler makes <see cref="Adapter"/> not to enqueue current
  /// <see cref="DataObject"/> so this object will not be filled.
  /// </para>
  /// </remarks>
  public delegate void EnqueueObjectEventHandler(object sender, EnqueueObjectEventArgs e);
}
