// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;

namespace DataObjects.NET.Internals
{
  /// <summary>
  /// Contains a set of classes and interfaces
  /// that usually shouldn't be used outside of
  /// DataObjects.NET.
  /// </summary>
  internal class NamespaceDoc {}
}
