// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using DataObjects.NET.Attributes;

namespace DataObjects.NET
{
  /// <summary>
  /// Allows to validate <see cref="DataObject"/> property value 
  /// before it is actually set by 
  /// <see cref="DataObject.SetProperty">DataObject.SetProperty</see>
  /// method.
  /// <seealso cref="ValidatorAttribute"/>
  /// </summary>
  /// <remarks>
  /// See <see cref="ValidatorAttribute"/> also.
  /// </remarks>
  public interface IPropertyValueValidator 
  {
    /// <summary>
    /// Validates <see cref="DataObject"/> property value 
    /// before it is actually set by 
    /// <see cref="DataObject.SetProperty">DataObject.SetProperty</see>
    /// method.
    /// </summary>
    /// <param name="dataObject"><see cref="DataObject"/> instance
    /// which property is to be changed.</param>
    /// <param name="propertyName">Property name.</param>
    /// <param name="culture">Property culture.</param>
    /// <param name="value">Value to validate.</param>
    /// <remarks>
    /// <note type="note">This method should be completely thread-safe 
    /// (it should be possible to invoke this method on a single instance
    /// of class that implements it from multiple threads simultaneously).</note>
    /// </remarks>
    void Validate(DataObject dataObject, string propertyName, Culture culture, object value);

    /// <summary>
    /// Attaches a validator instance to a certain field.
    /// </summary>
    /// <param name="field">A <see cref="ObjectModel.Field"/> the validator is related to.</param>
    void AttachToField (ObjectModel.Field field);
  }
}
