// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;
using DataObjects.NET.Data;

namespace DataObjects.NET.Data
{
  /// <summary>
  /// Provides logging capabilities for Mapping Generator.
  /// </summary>
  public class MappingLog
  {
    private ArrayList removed = new ArrayList();
    private ArrayList created = new ArrayList();
    
    /// <summary>
    /// Gets a list of removed mapping item records.
    /// </summary>
    public ArrayList RemovedMappingItems {
      get {
        return removed;
      }
    }
    
    /// <summary>
    /// Gets a list of created mapping item records.
    /// </summary>
    public ArrayList CreatedMappingItems {
      get {
        return created;
      }
    }
  
    internal static string GetMappingItemSource(MappingItemBase item)
    {
      string source = null;
      if (item is InterfaceMappingItem)
        source = ((InterfaceMappingItem)item).InterfaceName;
      else if (item is ClassMappingItem)
        source = ((ClassMappingItem)item).ClassName;
      else if (item is DocMappingItem)
        source = ((DocMappingItem)item).CollectionName;
      else if (item is VtcMappingItem)
        source = ((VtcMappingItem)item).CollectionName;
      else if (item is FieldMappingItem)
        source = ((FieldMappingItem)item).FieldName;
      if (source==null)
        source = "";
      MappingItemBase parentItem = item.MappingCollection.Owner as MappingItemBase;
      if (parentItem!=null) {
        string parentSource = GetMappingItemSource(parentItem);
        if (parentSource!=null && parentSource.Length!=0)
          source = parentSource + "." + source;
      }
      return source;
    }
    
    internal static string GetMappingItemDestination(MappingItemBase item)
    {
      if (item is FieldMappingItem) {
        string columnName = ((FieldMappingItem)item).ColumnName;
        if (columnName==null)
          columnName = "";
        return String.Format(
          "{0}.[{1}]",
          GetMappingItemDestination(item.MappingCollection.Owner as MappingItemBase),
          columnName);
      }
      string destination = null;
      if (item is MappingToTableItem)
        destination = ((MappingToTableItem)item).TableName;
      return String.Format("[{0}]", (destination==null) ? "" : destination);
    }
  
    /// <summary>
    /// Adds mapping item to the log of removed items.
    /// </summary>
    /// <param name="item"><see cref="MappingItemBase"/> to add to the log.</param>
    public void AddMappingToRemoveLog(MappingItemBase item)
    {
      if (item==null)
        throw new ArgumentNullException("item");
      removed.Add(new MappingLogRecord(GetMappingItemSource(item), GetMappingItemDestination(item)));
    }
    
    /// <summary>
    /// Adds mapping item to the log of created items.
    /// </summary>
    /// <param name="item"><see cref="MappingItemBase"/> to add to the log.</param>
    public void AddMappingToCreateLog(MappingItemBase item)
    {
      if (item==null)
        throw new ArgumentNullException("item");
      created.Add(new MappingLogRecord(GetMappingItemSource(item), GetMappingItemDestination(item)));
    }
  }
}
