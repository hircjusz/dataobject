// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using DataObjects.NET.Offline;

namespace DataObjects.NET.Attributes
{
  /// <summary>
  /// Indicates that offline method has its online analogue.
  /// All invocations of such offline method will be registered
  /// (see <see cref="ObjectSet.DisableBusinessMethodCallRegistration">ObjectSet.DisableBusinessMethodCallRegistration</see>
  /// and <see cref="ObjectSet.EnableBusinessMethodCallRegistration">ObjectSet.EnableBusinessMethodCallRegistration</see>),
  /// and corresponding online methods will be invoked
  /// on the corresponding server-side objects during 
  /// <see cref="ObjectSet.ApplyChanges">ObjectSet.ApplyChanges</see>
  /// execution - to reproduce the actions performed by the 
  /// offline methods, but on the server side.
  /// </summary>
  [AttributeUsage(AttributeTargets.Method, AllowMultiple = false, Inherited = true)]
  [Serializable]
  public class OfflineBusinessMethodAttribute: DataObjectAttribute
  {
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    public OfflineBusinessMethodAttribute() 
    {
    }
  }
}
