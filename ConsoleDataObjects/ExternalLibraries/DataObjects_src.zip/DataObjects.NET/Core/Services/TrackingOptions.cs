// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using DataObjects.NET;

namespace DataObjects.NET.Services
{
  /// <summary>
  /// Enumeration of possible tracking options for a
  /// particular <see cref="TrackingSet"/>.
  /// </summary>
  [Flags]
  public enum TrackingOptions
  {
    /// <summary>
    /// Enables detection <see cref="DataObject"/> creations.
    /// Value is <see langword="0x1"/>.
    /// </summary>
    DetectCreations = 0x1,
    /// <summary>
    /// Enables detection of <see cref="DataObject"/> removals.
    /// Value is <see langword="0x2"/>.
    /// </summary>
    DetectRemovals = 0x2,
    /// <summary>
    /// Enables detection of other changes made to <see cref="DataObject"/> instances.
    /// Value is <see langword="0x4"/>.
    /// </summary>
    DetectChanges = 0x4
  }
}
