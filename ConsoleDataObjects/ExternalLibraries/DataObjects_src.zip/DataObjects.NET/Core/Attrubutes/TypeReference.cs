// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;

namespace DataObjects.NET.Attributes
{
  /// <summary>
  /// Specifies DataObjects.NET to add a reference to assembly
  /// with specified <see cref="System.Type"/> into assembly 
  /// with proxy classes.
  /// </summary>
  /// <remarks>
  /// <note>This attribute can be applied to persistent types
  /// (<see cref="DataObject"/> descendants) or services
  /// (<see cref="DataService"/> descendants).</note>
  /// <para>
  /// It's difficult to detect all assemblies that should be
  /// referenced by proxy assembly during its code generation. 
  /// E.g. it's not enough to analyze all types used in proxy 
  /// classes. 
  /// </para>
  /// <para>
  /// If DataObjects.NET can't determine that some assembly is 
  /// required to build an assembly with proxies, you should use 
  /// this attribute to manually specify a type from this assembly 
  /// (this specification will allow DataObjects.NET to locate 
  /// required assembly).
  /// </para>
  /// <para>
  /// This type is mentioned in error message if such situation
  /// takes place (it can occur only during <see cref="Domain.Build">Domain.Build</see>
  /// method execution.
  /// </para>
  /// <para>
  /// <example>Example:
  /// <code lang="C#">
  ///  [TypeReference(typeof(SomeTypeThatCanAppearInProxyCodeButUndetectedByDataObjectsDotNet))]
  ///  public abstract class SomePersistentType: DataObject
  ///  {
  ///    ...
  ///  {
  /// </code>
  /// </example>
  /// </para>
  /// </remarks>
  [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method | AttributeTargets.Property, 
    AllowMultiple = true, Inherited = false)]
  [Serializable]
  public class TypeReferenceAttribute: DataObjectAttribute
  {
    private Type type;
    /// <summary>
    /// Type to add a reference to assembly of.
    /// </summary>
    public  Type Type 
    {
      get {return type;}
      set {type = value;}
    }


    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="type">Type to add a reference to assembly of.</param>
    public TypeReferenceAttribute(Type type)
    {
      this.type = type;
    }
  }
}
