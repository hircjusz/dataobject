// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;

namespace DataObjects.NET.Attributes
{
  /// <summary>
  /// Specifies that class can't be inherited.
  /// </summary>
  /// <remarks>
  /// <note>This attribute can be applied to persistent types
  /// (<see cref="DataObject"/> descendants) or services
  /// (<see cref="DataService"/> descendants).</note>
  /// This attribute allows to mark a persistent class as sealed.
  /// You can't simply declare that class is sealed because
  /// all DataObjects.NET persistent classes are abstract (so they can't
  /// be normally sealed).
  /// <para>
  /// <example>Example:
  /// <code lang="C#">
  ///  [Sealed] // !!!
  ///  public abstract class SealedUser: StdUser
  ///  {
  ///    ...
  ///  }
  /// </code>
  /// </example>
  /// </para>
  /// <seealso cref="AbstractAttribute"/>
  /// </remarks>
  [AttributeUsage(AttributeTargets.Class, AllowMultiple = false, Inherited = false)]
  [Serializable]
  public class SealedAttribute: DataObjectAttribute
  {
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    public SealedAttribute() 
    {
    }
  }
}
