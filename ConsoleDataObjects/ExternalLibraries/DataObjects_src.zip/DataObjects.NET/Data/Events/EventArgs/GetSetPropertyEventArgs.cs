// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using DataObjects.NET;
using DataObjects.NET.Data;

namespace DataObjects.NET.Data
{
  /// <summary>
  /// Provides information for <see cref="Adapter.GetProperty"/> and <see cref="Adapter.SetProperty"/> events.
  /// </summary>
  public class PropertyEventArgs: EventArgs
  {
    private DataObject dataObject;
    private string propertyName;
    private Culture culture;
    private object value;
    
    /// <summary>
    /// Gets <see cref="DataObject"/> instance containing
    /// the property to get or to set value of.
    /// </summary>
    public DataObject DataObject {
      get {
        return dataObject;
      }
    }
    
    /// <summary>
    /// Gets the name of the property to get or to set the value of.
    /// </summary>
    public string PropertyName {
      get {
        return propertyName;
      }
    }
    
    /// <summary>
    /// Gets <see cref="Culture"/> of the property to get or to set the value of.
    /// </summary>
    public Culture Culture {
      get {
        return culture;
      }
    }
    
    /// <summary>
    /// Gets or sets the property value to use.
    /// <see cref="Adapter"/> sets this property to
    /// value it intends to use, you can change it to make
    /// <see cref="Adapter"/> to use another value.
    /// </summary>
    public object Value {
      get {
        return this.value;
      }
      set {
        this.value = value;
      }
    }
    
    /// <summary>
    /// Initializes a new instance of the <see cref="PropertyEventArgs"/> class.
    /// </summary>
    /// <param name="dataObject">Target <see cref="DataObject"/>.</param>
    /// <param name="propertyName">Property name.</param>
    /// <param name="culture">Culture which is used to get or to set property value. Value can be null.</param>
    /// <param name="value">Suggested property value. Value can be null.</param>
    internal PropertyEventArgs(DataObject dataObject, string propertyName, Culture culture, object value)
    {
      if (dataObject==null)
        throw new ArgumentNullException("dataObject");
      if (propertyName==null)
        throw new ArgumentNullException("propertyName");
        
      this.dataObject = dataObject;
      this.propertyName = propertyName;
      this.culture = culture;
      this.value = value;
    }
  }
}
