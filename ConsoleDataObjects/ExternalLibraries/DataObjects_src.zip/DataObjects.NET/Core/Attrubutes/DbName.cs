// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Text;
using System.Text.RegularExpressions;

namespace DataObjects.NET.Attributes
{
  /// <summary>
  /// Specifies the base part of the field's related column name 
  /// or the base part of the class' related table name.
  /// </summary>
  /// <remarks>
  /// <para>
  /// You can use the following characters in <see cref="DbName"/>s: [_A-Za-z0-9-]. 
  /// <see cref="DbName"/> can't be an empty string or <see langword="null"/>.
  /// </para>
  /// <para>
  /// <example>Example:
  /// <code lang="C#">
  ///  public abstract class Person: DataObject
  ///  {
  ///    ...
  ///
  ///    [DbName("FN")] // !!!
  ///    public abstract string FullName {get; set;}
  ///
  ///    ...
  ///  }
  /// </code>
  /// </example>
  /// </para>
  /// <seealso cref="AliasAttribute"/>
  /// </remarks>
  [AttributeUsage(AttributeTargets.Class | AttributeTargets.Interface | AttributeTargets.Property | AttributeTargets.Field, 
    AllowMultiple = false, Inherited = true)]
  [Serializable]
  public class DbNameAttribute: DataObjectAttribute
  {
    private string dbName;
    /// <summary>
    /// Gets or sets the base part of the field's related column name 
    /// or the base part of the class' related table name.
    /// </summary>
    /// <remarks>
    /// You can use the following characters in <see cref="DbName"/>s: [_A-Za-z0-9-]. 
    /// <see cref="DbName"/> can't be an empty string or <see langword="null"/>.
    /// </remarks>
    public string DbName {
      get {return dbName;}
      set {dbName = value;}
    }

    /// <summary>
    /// Returns <see langword="true"/> if <see cref="DbName"/> is valid;
    /// otherwise, <see langword="false"/>.
    /// </summary>
    /// <returns><see langword="True"/> if <see cref="DbName"/> is valid;
    /// otherwise, <see langword="false"/>.</returns>
    public bool Validate()
    {
      if (dbName==null || dbName=="")
        return false;
      Regex re = new Regex("^[_A-Za-z0-9\\-]+$");
      if (!re.IsMatch(dbName))
        return false;
      return true;
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="dbName">The base part of the field's related column name 
    /// or the base part of the class' related table name.</param>
    public DbNameAttribute(string dbName) 
    {
      this.dbName = dbName;
    }
  }
}
