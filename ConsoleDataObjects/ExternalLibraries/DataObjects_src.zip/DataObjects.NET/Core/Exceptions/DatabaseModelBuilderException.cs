// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Runtime.Serialization;
using DataObjects.NET.DatabaseModel;

namespace DataObjects.NET.Exceptions
{
  /// <summary>
  /// Describes different errors which may occur while building
  /// <see cref="Database">database model</see>.
  /// </summary>
  [Serializable]
  public class DatabaseModelBuilderException: DataObjectsDotNetException
  {
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    public DatabaseModelBuilderException(): base("Database Model Builder error.") {}

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="text">Text of message.</param>
    public DatabaseModelBuilderException(string text): base(text) {}

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="innerException">Inner exception.</param>
    public DatabaseModelBuilderException(Exception innerException): this("Database Model Builder error.",innerException) 
    {
    }
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="text">Text of message.</param>
    /// <param name="innerException">Inner exception.</param>
    public DatabaseModelBuilderException(string text, Exception innerException): base(text,innerException) 
    {
    }
    
    /// <summary>
    /// Deserialization constructor.
    /// </summary>
    /// <param name="info"><see cref="SerializationInfo"/> object.</param>
    /// <param name="context"><see cref="StreamingContext"/> object.</param>
    protected DatabaseModelBuilderException(SerializationInfo info, StreamingContext context):
      base(info, context)
    {
    }
  }
}
