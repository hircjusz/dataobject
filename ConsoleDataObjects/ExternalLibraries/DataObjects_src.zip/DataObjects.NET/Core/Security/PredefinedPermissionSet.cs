// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.IO;
using System.Threading;
using System.Configuration;
using System.Runtime.Serialization;
using System.Diagnostics;
using System.Globalization;
using System.Collections;
using DataObjects.NET;
using DataObjects.NET.Attributes;
using DataObjects.NET.Exceptions;

namespace DataObjects.NET.Security
{
  /// <summary>
  /// Base class for any predefined security permission set.
  /// <seealso cref="PermissionSet"/>
  /// <seealso cref="IPermission"/>
  /// <seealso cref="IPermissionSet"/>
  /// </summary>
  /// <remarks>
  /// <para>
  /// You can find more information about the whole DataObjects.NET
  /// security system <see cref="AccessControlList">here</see>.
  /// </para>
  /// </remarks>
  public abstract class PredefinedPermissionSet: PermissionSet
  {
  }
}
