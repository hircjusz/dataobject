// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using DataObjects.NET.Data;

namespace DataObjects.NET.Data.Design
{
  /// <summary>
  /// Editor for the DataObjectCollection mapping collections.
  /// </summary>
  public class DocMappingCollectionEditor: MappingCollectionEditorBase
  {
    /// <summary>
    /// Initializes a new instance of the <see cref="DocMappingCollectionEditor"/> class.
    /// </summary>
    public DocMappingCollectionEditor(): base(typeof(DocMappingCollection), typeof(DocMappingItem))
    {
    }
  }
}
