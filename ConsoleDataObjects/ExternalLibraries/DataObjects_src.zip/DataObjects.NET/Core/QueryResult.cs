// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;
using System.Runtime.Serialization;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Attributes;
using DataObjects.NET.Database;
using DataObjects.NET.Offline;

namespace DataObjects.NET
{
  /// <summary>
  /// Represents a collection of <see cref="DataObject"/>s that can be 
  /// returned by the <see cref="QueryBase.Execute"/> method.
  /// </summary>
  public sealed class QueryResult: SessionBoundLockableCollectionBase,
    IList, ICollection, IEnumerable,
    IConvertibleToOffline
  { 
    private QueryOptions options;
    private TransactionContext preLoadTransactionContext;
    
    /// <summary>
    /// Gets the options describing internal behavior of
    /// the <see cref="QueryResult"/>. 
    /// Value of this property can't be changed, but it can be 
    /// specified during the <see cref="QueryResult"/> creation.
    /// </summary>
    public QueryOptions Options {
      get {
        return options;
      }
    }

    /// <summary>
    /// Locks the collection.
    /// </summary>
    /// <param name="recursive">Always unused 
    /// (in case with <see cref="QueryResult"/>).</param>
    public override void Lock(bool recursive) 
    {
      InnerList = ArrayList.ReadOnly(InnerList);
    }
    
    /// <summary>
    /// Collection indexer.
    /// </summary>
    public DataObject this[int n] {
      get {
        return (DataObject)List[n];
      }
      set {
        List[n] = value;
      }
    }
    
    /// <summary>
    /// Gets list of <see cref="DataObject.ID"/>s 
    /// of contained <see cref="DataObject"/>s.
    /// Generally this method should be used to store 
    /// the list of fetched objects to use it further
    /// (e.g. to cache the result of some operation -
    /// like full-text search in the web applications).
    /// <seealso cref="SetIDs"/>
    /// <seealso cref="AddRange"/>
    /// </summary>
    public long[] GetIDs()
    {
      ArrayList list = InnerList;
      int c = list.Count;
      long[] IDList = new long[Count];
      for (int i = 0; i<c; i++)
        IDList[i] = ((DataObjectIdentificationInfo)(list[i])).ID;
      return IDList;
    }

    /// <summary>
    /// Gets list of <see cref="DataObject.ID"/>s 
    /// of contained <see cref="DataObject"/>s.
    /// Generally this method should be used to store 
    /// the list of fetched objects to use it further
    /// (e.g. to cache the result of some operation -
    /// like full-text search in the web applications).
    /// <seealso cref="SetIDs"/>
    /// <seealso cref="AddRange"/>
    /// </summary>
    /// <param name="startIndex">Start index.</param>
    /// <param name="count">Number of IDs to get.</param>
    public long[] GetIDs(int startIndex, int count)
    {
      ArrayList list = InnerList;
      long[] IDList = new long[count];
      for (int i = 0; i<count; i++)
        IDList[i] = ((DataObjectIdentificationInfo)(list[startIndex+i])).ID;
      return IDList;
    }

    /// <summary>
    /// Gets <see cref="DataObject.ID"/>
    /// of contained <see cref="DataObject"/> instance
    /// with specified <paramref name="index"/>.
    /// <seealso cref="GetIDs"/>
    /// </summary>
    /// <param name="index">Item index.</param>
    public long GetID(int index)
    {
      return ((DataObjectIdentificationInfo)(InnerList[index])).ID;
    }

    /// <summary>
    /// Sets list of contained <see cref="DataObject"/>s
    /// by array of their <see cref="DataObject.ID"/>s.
    /// Generally this method should be used to restore 
    /// the list of objects previously returned by <see cref="GetIDs"/>.
    /// (e.g. to restore cached result of some operation -
    /// like full-text search in the web applications).
    /// <seealso cref="GetIDs"/>
    /// <seealso cref="AddRange"/>
    /// </summary>
    /// <param name="src">An array of <see cref="DataObject.ID"/>s that 
    /// content should be copied.</param>
    public void SetIDs(long[] src)
    {
      ArrayList list = InnerList;
      list.Clear();
      int c = src.Length;
      for (int i = 0; i<c; i++)
        list.Add(new DataObjectIdentificationInfo(src[i]));
    }
    
    /// <summary>
    /// Copies the elements of the <see cref="QueryResult"/> to a new array.
    /// </summary>
    /// <returns>An array containing copies of the elements of the <see cref="QueryResult"/>.</returns>
    public DataObject[] ToArray()
    {
      return (DataObject[])ToArray(typeof(DataObject));
    }

    /// <summary>
    /// Copies the elements of the <see cref="QueryResult"/> to a new array 
    /// of the specified type.
    /// </summary>
    /// <param name="type">The <see cref="Type"/> of array to create and copy elements to.</param>
    /// <returns>An array of the specified type containing copies of the elements of the <see cref="QueryResult"/>.</returns>
    public Array ToArray(Type type)
    {
      int cnt = Count;
      Array array = Array.CreateInstance(type, cnt);
      for (int i = 0; i<cnt; i++)
        array.SetValue(List[i],i);
      return array;
    }

    /// <summary>
    /// Converts <see cref="QueryResult"/> instance to its offline analogue.
    /// </summary>
    object IConvertibleToOffline.ToOffline()
    {
      return this.ToOffline();
    }
    
    /// <summary>
    /// Converts <see cref="QueryResult"/> instance to its offline analogue.
    /// </summary>
    public Offline.QueryResult ToOffline()
    {
      return this.ToOffline(new FillDescriptor());
    }

    /// <summary>
    /// Converts <see cref="QueryResult"/> instance to its offline analogue.
    /// </summary>
    /// <param name="fillExpression">Fill expression (textual
    /// <see cref="Offline.FillDescriptor"/> definition) describing 
    /// desired way of conversion.</param>
    public Offline.QueryResult ToOffline(string fillExpression)
    {
      return this.ToOffline(new FillDescriptor(Domain.ObjectModel, fillExpression));
    }

    /// <summary>
    /// Converts <see cref="QueryResult"/> instance to its offline analogue.
    /// </summary>
    /// <param name="fillDescriptor"><see cref="Offline.FillDescriptor"/> 
    /// desired way of conversion.</param>
    public Offline.QueryResult ToOffline(Offline.FillDescriptor fillDescriptor)
    {
      Offline.Internals.ObjectSetProvider osProvider = 
        (Offline.Internals.ObjectSetProvider)Session.GetService(typeof(Offline.Internals.ObjectSetProvider));
      return osProvider.CreateObjectSet(GetIDs(), fillDescriptor);
    }

    /// <summary>
    /// Preloads all <see cref="DataObject"/> instances stored in this result set.
    /// </summary>
    [Transactional(TransactionMode.TransactionRequired)]
    public Helpers.StrongReferenceHolder Preload()
    {
      if (preLoadTransactionContext!=null &&
          preLoadTransactionContext.State==TransactionContextState.Valid)
        return null;
        
      // Automatic Transactions support code
      TransactionController tc = session.CreateTransactionController( TransactionMode.TransactionRequired);
    Reprocess:
      try {
        Helpers.StrongReferenceHolder r = InnerPreload();
        tc.Commit();
        return r;
      }
      catch (Exception e) {
        if (tc.Rollback(e, true))
          goto Reprocess;             
        throw;
      }
    }
    private Helpers.StrongReferenceHolder InnerPreload()
    {
      Helpers.StrongReferenceHolder r = session.Preload(GetIDs());
      preLoadTransactionContext = session.transactionContext;
      return r;
    }

    /// <summary>
    /// Adds new value to this collection. If element with the same
    /// name is already exists in this collection, <see cref="InvalidOperationException"/>
    /// will be thrown.
    /// </summary>
    /// <param name="value">DataObject to add.</param>
    public int Add(DataObject value)
    {
      return List.Add(value);
    }
    
    /// <summary>
    /// Adds a list of <see cref="DataObject"/>s to the <see cref="QueryResult"/>
    /// by array of their <see cref="DataObject.ID"/>s.
    /// Generally this method should be used to restore 
    /// the list of objects previously returned by <see cref="GetIDs"/>.
    /// (e.g. to restore cached result of some operation -
    /// like full-text search in the web applications).
    /// <seealso cref="GetIDs"/>
    /// <seealso cref="SetIDs"/>
    /// </summary>
    /// <param name="src">An array of <see cref="DataObject.ID"/>s that 
    /// content should be added.</param>
    public void AddRange(long[] src)
    {
      ArrayList list = InnerList;
      int c = src.Length;
      for (int i = 0; i<c; i++)
        list.Add(new DataObjectIdentificationInfo(src[i]));
    }

    /// <summary>
    /// <para>Copies the elements of an array to the end of the <see cref='QueryResult'/>.</para>
    /// </summary>
    /// <param name='value'>
    ///   An array of type <see cref='DataObject'/> containing the objects to add to the collection.
    /// </param>
    /// <returns>
    ///   <para>None.</para>
    /// </returns>
    /// <seealso cref='QueryResult.Add'/>
    public void AddRange(DataObject[] value) {
      ArrayList list = InnerList;
      int c = value.Length;
      if ((options & QueryOptions.HoldInMemory)!=0)
        for (int i = 0; i<c; i++)
          list.Add(new DataObjectIdentificationInfo(value[i]));
      else
        for (int i = 0; i<c; i++)
          list.Add(new DataObjectIdentificationInfo((long)value[i].GetProperty("ID",null)));
    }

    /// <summary>
    ///   <para>
    ///     Adds the contents of another <see cref='QueryResult'/> to the end of the collection.
    ///  </para>
    /// </summary>
    /// <param name='value'>
    ///    A <see cref='QueryResult'/> containing the objects to add to the collection.
    /// </param>
    /// <returns>
    ///   <para>None.</para>
    /// </returns>
    /// <seealso cref='QueryResult.Add'/>
    public void AddRange(QueryResult value) {
      if (session!=value.session)
        throw new InvalidOperationException("Collections belongs to different sessions.");
      InnerList.AddRange(value.InnerList);
    }

    /// <summary>
    /// Determines, if this collection contains specified value.
    /// </summary>
    /// <param name="value">DataObject to search for.</param>
    /// <returns><see langword="True"/> if value was found.</returns>
    public bool Contains(DataObject value)
    {
      return List.Contains(value);
    }

    /// <summary>
    /// Copies elements of this collection to <see cref="Array"/>.
    /// </summary>
    /// <param name="values">Destination array.</param>
    /// <param name="offset">Offset in array to start from.</param>
    public void CopyTo(DataObject[] values, int offset)
    {
      List.CopyTo(values, offset);
    }

    /// <summary>
    /// Searches for the specified value and returns the index of the first occurrence within the current instance.
    /// </summary>
    /// <param name="value">The value to locate.</param>
    /// <returns>The index of the first occurrence of value within the entire collection, if found; otherwise, -1.</returns>
    public int IndexOf(DataObject value)
    {
      return List.IndexOf(value);
    }

    /// <summary>
    /// Inserts value to collection.
    /// </summary>
    /// <param name="offset">Offset of value.</param>
    /// <param name="value">DataObject to insert.</param>
    public void Insert(int offset, DataObject value)
    {
      List.Insert(offset, value);
    }

    /// <summary>
    /// Removes value from collection.
    /// </summary>
    /// <param name="value">DataObject to remove.</param>
    public void Remove(DataObject value)
    {
      List.Remove(value);
    }
    
    /// <summary>
    /// Validating a value.
    /// </summary>
    /// <param name="value">The object to validate.</param>
    protected override void OnValidate(Object value)
    {
      DataObject o = (DataObject)value;
      if (o==null)
        return;
      if (o.session!=session)
        throw new InvalidOperationException("Validation failed: instance belongs to different session.");
    }
    

    // IList, ICollection, IEnumerable methods implementation
    
    /// <summary>
    /// Returns an enumerator that can iterate through the
    /// <see cref="QueryResult"/> instance.
    /// </summary>
    /// <returns>An <see cref="IEnumerator"/> for the 
    /// <see cref="QueryResult"/> instance.</returns>
    public override IEnumerator GetEnumerator()
    {
      return new QueryResultEnumerator(this, InnerList.GetEnumerator());
    }
    
    void ICollection.CopyTo(Array array, int index)
    {
      foreach (object o in List)
        array.SetValue(o,index++);
    }
    
    object IList.this[int index] {
      get {
        DataObjectIdentificationInfo info = (DataObjectIdentificationInfo)InnerList[index];
        if (info.RealObject!=null) {
          if (info.RealObject.State==DataObjectState.Removed)
            return null;
          else
            return info.RealObject;
        }
        if (info.ID==0)
          return null;
        DataObject o = session[info.ID];
        if ((options & QueryOptions.HoldInMemory)!=0)
          info.RealObject = o;
        return o;
      }
      set {
        if (index<0 || index>=InnerList.Count)
          throw new ArgumentOutOfRangeException("Index is out of range.");
        OnValidate(value);
        DataObject o = (DataObject)value;
        long id = 0;
        if (o!=null) {
          if (o.State==DataObjectState.Removed)
            o = null;
          else
            id = (long)o.GetProperty("ID",null);
        }
        DataObjectIdentificationInfo info = (DataObjectIdentificationInfo)InnerList[index];
        if (info.ID==id)
          return;
        if ((options & QueryOptions.HoldInMemory)!=0)
          InnerList[index] = new DataObjectIdentificationInfo(id,o);
        else
          InnerList[index] = new DataObjectIdentificationInfo(id);
      }
    }
    
    /// <summary>
    /// Determines whether collection contains a specific value.
    /// </summary>
    /// <param name="value">Value to search for.</param>
    /// <returns><see langword="True"/> if the object is found; otherwise, <see langword="false"/>.</returns>
    bool IList.Contains(Object value) 
    {
      return List.IndexOf(value)>=0;
    }
    
    /// <summary>
    /// Searches for the specified value and returns the index of the first occurrence within the current instance.
    /// </summary>
    /// <param name="value">The value to locate.</param>
    /// <returns>The index of the first occurrence of value within the entire collection, if found; otherwise, -1.</returns>
    int  IList.IndexOf(Object value)
    {
      OnValidate(value);
      DataObject o = (DataObject)value;
      long id = 0;
      if (o!=null) {
        switch (o.State) {
        case DataObjectState.New:
          return -1;
        case DataObjectState.Removed:
          o = null;
          break;
        default:
          id = (long)o.GetProperty("ID",null);
          break;
        }
      }
      ArrayList list = InnerList;
      int c = list.Count;
      if (id!=0) {
        for (int i = 0; i<c; i++) {
          DataObjectIdentificationInfo info = (DataObjectIdentificationInfo)InnerList[i];
          if (info.ID==id) {
            if (info.RealObject!=null) {
              if (info.RealObject==o)
                return i;
              else
                throw new DataObjectsDotNetException(String.Format(
                  "Internal error: different instance with ID=\"{0}\" "+
                  "found during QueryResult.IndexOf(...) execution.",id));
            }
            else
              return i;
          }
        }
      }
      else {
        for (int i = 0; i<c; i++) {
          DataObjectIdentificationInfo info = (DataObjectIdentificationInfo)InnerList[i];
          if (info.ID==0)
            return i;
          else {
            if (info.RealObject!=null) {
              if (info.RealObject.State==DataObjectState.Removed)
                return i;
            }
            else {
              if (session[info.ID]==null)
                return i;
            }
          }
        }
      }
      return -1;
    }
    
    /// <summary>
    /// Adds new element to the collection.
    /// </summary>
    /// <param name="value">Item to add.</param>
    /// <returns>Index of newly added item.</returns>
    int  IList.Add(Object value) 
    {
      OnValidate(value);
      DataObject o = (DataObject)value;
      long id = 0;
      if (o!=null) {
        if (o.State==DataObjectState.Removed)
          o = null;
        else
          id = (long)o.GetProperty("ID",null);
      }
      if ((options & QueryOptions.HoldInMemory)!=0)
        return InnerList.Add(new DataObjectIdentificationInfo(id,o));
      else
        return InnerList.Add(new DataObjectIdentificationInfo(id));
    }
    
    /// <summary>
    /// Inserts an element to the collection.
    /// </summary>
    /// <param name="index">The zero-based index at which value should be inserted.</param>
    /// <param name="value">Item to insert.</param>
    void IList.Insert(int index, Object value)
    {
      if (index<0 || index>InnerList.Count)
        throw new ArgumentOutOfRangeException("Index is out of range.");
      OnValidate(value);
      DataObject o = (DataObject)value;
      long id = 0;
      if (o!=null) {
        if (o.State==DataObjectState.Removed)
          o = null;
        else
          id = (long)o.GetProperty("ID",null);
      }
      if ((options & QueryOptions.HoldInMemory)!=0)
        InnerList.Insert(index, new DataObjectIdentificationInfo(id,o));
      else
        InnerList.Insert(index, new DataObjectIdentificationInfo(id));
    }
    
    /// <summary>
    /// Removes element from the the collection.
    /// </summary>
    /// <param name="value">Item to remove.</param>
    void IList.Remove(Object value)
    {
      OnValidate(value);
      int i = List.IndexOf(value);
      if (i<0)
        throw new ArgumentException("Argument wasn't found.");
      InnerList.RemoveAt(i);
    }

    
    // Constructors

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="session">Session, to which this collection is bound.</param>
    /// <param name="options">Options describing internal behavior of
    /// the <see cref="QueryResult"/>.</param>
    public QueryResult(Session session, QueryOptions options):
      base(session)
    {
//      if (session.transaction==null)
//        throw new TransactionRequiredException();
//      if (session.transaction.isFinished)
//        throw new SecurityException("Transaction is locked.", session.transaction.RollbackException);
      this.options = options & 
        (QueryOptions.HoldInMemory | QueryOptions.LoadOnDemand);
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="session">Session, to which this collection is bound.</param>
    public QueryResult(Session session):
      base(session)
    {
//      if (session.transaction==null)
//        throw new TransactionRequiredException();
//      if (session.transaction.isFinished)
//        throw new TransactionIsLockedException(session.transaction.RollbackException);
      this.options = QueryOptions.Default;
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="session">Session, to which this collection is bound.</param>
    /// <param name="src"><see cref="QueryResult"/> that content should be copied.</param>
    public QueryResult(Session session, QueryResult src): 
      this(session, src.options)
    {
      AddRange(src);
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="session">Session, to which this collection is bound.</param>
    /// <param name="options">Options describing internal behavior of
    /// the <see cref="QueryResult"/>.</param>
    /// <param name="src"><see cref="QueryResult"/> that content should be copied.</param>
    public QueryResult(Session session, QueryOptions options, QueryResult src): 
      this(session, options)
    {
      AddRange(src);
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="session">Session, to which this collection is bound.</param>
    /// <param name="options">Options describing internal behavior of
    /// the <see cref="QueryResult"/>.</param>
    /// <param name="src">Array of <see cref="DataObject"/>s that 
    /// content should be copied.</param>
    public QueryResult(Session session, QueryOptions options, DataObject[] src): 
      this(session, options)
    {
      AddRange(src);
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="session">Session, to which this collection is bound.</param>
    /// <param name="src">Array of <see cref="DataObject"/>s that content should be copied.</param>
    public QueryResult(Session session, DataObject[] src): 
      this(session)
    {
      AddRange(src);
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="session">Session, to which this collection is bound.</param>
    /// <param name="options">Options describing internal behavior of
    /// the <see cref="QueryResult"/>.</param>
    /// <param name="src">Array of <see cref="DataObject.ID"/> values that 
    /// content should be copied.</param>
    public QueryResult(Session session, QueryOptions options, long[] src): 
      this(session, options)
    {
      AddRange(src);
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="session">Session, to which this collection is bound.</param>
    /// <param name="src">Array of <see cref="DataObject.ID"/> values that 
    /// content should be copied.</param>
    public QueryResult(Session session, long[] src): 
      this(session)
    {
      AddRange(src);
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="session">Session, to which this collection is bound.</param>
    /// <param name="options">Options describing internal behavior of
    /// the <see cref="QueryResult"/>.</param>
    /// <param name="queryResultData">List of <see cref="DataObjectIdentificationInfo"/> objects.</param>
    internal QueryResult(Session session, QueryOptions options, ArrayList queryResultData): 
      this(session)
    {
      this.options = options & 
        (QueryOptions.HoldInMemory | QueryOptions.LoadOnDemand);
      InnerList = queryResultData;
    }
  }
}
