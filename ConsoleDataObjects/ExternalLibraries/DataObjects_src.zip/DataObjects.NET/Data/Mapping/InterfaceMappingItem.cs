// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.ComponentModel;
using DataObjects.NET.Data.Design;

namespace DataObjects.NET.Data
{
  /// <summary>
  /// Interface mapping item.
  /// </summary>
  [TypeConverter(typeof(InterfaceMappingItemConverter))]
  public class InterfaceMappingItem: FullContainerMappingItem
  {
    private string interfaceName;
    
    /// <summary>
    /// Gets item name.
    /// </summary>
    public override string Name {
      get {
        if (interfaceName!=null)
          return interfaceName;
        return "Interface Mapping Item";
      }
    }
    
    /// <summary>
    /// Gets or sets interface name.
    /// </summary>
    [Category("Mapping")]
    [TypeConverter(typeof(InterfaceNameConverter))]
    public string InterfaceName {
      get {
        return interfaceName;
      }
      set {
        interfaceName = value;
      }
    }
    
    /// <summary>
    /// Initializes a new instance of the <see cref="InterfaceMappingItem"/> class.
    /// </summary>
    public InterfaceMappingItem(): this(null, null)
    {
    }
    
    /// <summary>
    /// Initializes a new instance of the <see cref="InterfaceMappingItem"/> class.
    /// </summary>
    /// <param name="interfaceName">Interface name.</param>
    /// <param name="tableName">Database table name.</param>
    public InterfaceMappingItem(string interfaceName, string tableName): base(tableName)
    {
      this.interfaceName = interfaceName;
    }
  }
}
