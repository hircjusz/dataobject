// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization.Formatters.Soap;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Attributes;

namespace DataObjects.NET.Serialization
{
  /// <summary>
  /// Enumeration of possible formatter (<see cref="IFormatter"/>) types 
  /// for the <see cref="Serializer"/>.
  /// </summary>
  public enum FormatterType
  {
    /// <summary>
    /// Custom formatter (use <see cref="Serializer.RealFormatter"/>
    /// to set it).
    /// </summary>
    Custom = -1,
    /// <summary>
    /// <see cref="BinaryFormatter"/>. Default value of the
    /// <see cref="Serializer.FormatterType"/> property.
    /// </summary>
    Binary = 1,
    /// <summary>
    /// <see cref="SoapFormatter"/>
    /// </summary>
    Soap = 2,
//    /// <summary>
//    /// Actually there is no <see cref="IFormatter"/> of this type 
//    /// (in the .NET Framework), except DataObjects.NET uses internal 
//    /// XML serizlization methods in this case. Currently unsupported.
//    /// </summary>
//    Xml = 3,
  }
}
