// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;
using System.ComponentModel;
using DataObjects.NET.Data;
using DataObjects.NET.Data.CodeManage;

namespace DataObjects.NET.Data.Design
{
  /// <summary>
  /// FieldNameConverter is used only to get a list of available field names for UI designers.
  /// </summary>
  public class FieldNameConverter: StringConverter
  {
    /// <summary>
    /// Returns whether this object supports a standard set of values that can be picked from a list, using the specified context.
    /// </summary>
    /// <param name="context">An <see cref="ITypeDescriptorContext"/> that provides a format context.</param>
    /// <returns><see langword="True"/> if <see cref="GetStandardValues"/> should be called to find a common set of values the object supports; otherwise, <see langword="false"/>.</returns>
    public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
    {
      return true;
    }
    
    /// <summary>
    /// Returns a collection of standard values for the data type this type converter is designed for when provided with a format context.
    /// </summary>
    /// <param name="context">An <see cref="ITypeDescriptorContext"/> that provides a format context that can be used to extract additional 
    /// information about the environment from which this converter is invoked. This parameter or properties of this parameter can be a null reference .</param>
    /// <returns>A <see cref="TypeConverter.StandardValuesCollection"/> that holds a standard set of valid values, or a null reference if the data type does not support a standard set of values.</returns>
    public override System.ComponentModel.TypeConverter.StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
    {
      MappingItemBase mappingItem = context.Instance as MappingItemBase;
      if (mappingItem!=null) {
        ArrayList list = GetFieldNames(mappingItem);
        list.Sort();
        return new StandardValuesCollection(list);
      }
      return null;
    }
    
    private IElementDescriptor GetDescriptor(MappingItemBase item)
    {
      if (item==null)
        return null;
      Adapter adapter = item.GetAdapter();
      if (adapter!=null && adapter.CodeManager!=null) {
        while (item!=null && !(item is FieldContainerMappingItem))
          item =  item.MappingCollection.Owner as MappingItemBase;
        if (item is InterfaceMappingItem) {
          string interfaceName = ((InterfaceMappingItem)item).InterfaceName;
          IInterfaceDescriptor id = adapter.CodeManager.GetInterfaceByFullName(interfaceName);
          if (id==null)
            id = adapter.CodeManager.GetInterfaceByName(interfaceName, true);
          return  id;
        } else if (item is ClassMappingItem) {
          string className = ((ClassMappingItem)item).ClassName;
          IClassDescriptor cd = adapter.CodeManager.GetClassByFullName(className);
          if (cd==null)
            cd = adapter.CodeManager.GetClassByName(className, true);
          return cd;
        } else if (item is VtcMappingItem) {
          ICollectionDescriptor[] collections = null;
          IElementDescriptor elementDescriptor = GetDescriptor(item.MappingCollection.Owner as MappingItemBase);
          if (elementDescriptor is IInterfaceDescriptor)
            collections = ((IInterfaceDescriptor)elementDescriptor).Collections;
          if (collections!=null) {
            string collectionName = ((VtcMappingItem)item).CollectionName;
            string[] parts = collectionName.Split(new char[] {'-'});
            if (parts.Length==2)
              collectionName=parts[0];
            foreach (ICollectionDescriptor cd in collections)
              if ((cd as IValueTypeCollectionDescriptor)!=null && ((IValueTypeCollectionDescriptor)cd).Name==collectionName)
                return cd;
          }
        }
      }
      return null;
    }
    
    private ArrayList GetFieldNames(MappingItemBase item)
    {
      ArrayList list = new ArrayList();
      IElementDescriptor element = GetDescriptor(item);
      IFieldDescriptor[] fields = null;
      if (element is IFieldContainerDescriptor)
        fields = ((IFieldContainerDescriptor)element).Fields;
      if (fields!=null)
        FillNameList(list, null, fields);
      return list;
    }
    
    private void FillNameList(IList list, string prefix, IFieldDescriptor[] fields)
    {
      foreach (IFieldDescriptor fd in fields) {
        string name = (prefix==null) ? fd.Name : (prefix + "." + fd.Name);
        if (fd.Fields.Length>0)
          FillNameList(list, name, fd.Fields);
        else
          list.Add(name);
      }
    }
  }
}
