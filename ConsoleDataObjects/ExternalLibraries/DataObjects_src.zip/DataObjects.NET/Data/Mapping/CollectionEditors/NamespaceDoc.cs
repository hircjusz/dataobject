// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;

namespace DataObjects.NET.Data.Design
{
  /// <summary>
  /// Contains collection editors and type converters.
  /// </summary>
  internal class NamespaceDoc {}
}
