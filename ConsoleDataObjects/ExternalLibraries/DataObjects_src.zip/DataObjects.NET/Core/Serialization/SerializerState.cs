// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Attributes;

namespace DataObjects.NET.Serialization
{
  /// <summary>
  /// Enumerates possible <see cref="Serializer"/> states.
  /// </summary>
  public enum SerializerState
  {
    /// <summary>
    /// Serializer is ready.
    /// Value is <see langword="0x0"/>. 
    /// </summary>
    Ready = 0,
    /// <summary>
    /// Serializer is performing serialization.
    /// Value is <see langword="0x1"/>. 
    /// </summary>
    Serializing = 1,
    /// <summary>
    /// Serializer is performing deserialization.
    /// Value is <see langword="0x2"/>. 
    /// </summary>
    Deserializing = 2,
  }
}
