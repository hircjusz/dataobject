// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Runtime.Serialization.Formatters;
using System.Runtime.Serialization.Formatters.Binary;
using DataObjects.NET;
using DataObjects.NET.Caching;

namespace DataObjects.NET.Database
{
  /// <summary>
  /// Summary description for PropertyInstantiationInfo.
  /// </summary>
  public sealed class PropertyInstantiationInfo: IGlobalCacheItem
  {
    private long id;
    private int versionID;
    private string propertyName;
    private int dataSize;
    private object data;
    private GlobalCacheItemType itemType;
    
    /// <summary>
    /// Gets a key that is used as a global cache key.
    /// </summary>
    object IGlobalCacheItemValidationInfo.Key {
      get {
        return new PropertyKey(id, propertyName);
      }
    }
    
    /// <summary>
    /// Gets or sets <see cref="DataObject.ID"/> property value.
    /// </summary>
    public long ID {
      get { return id; }
      set { id = value; }
    }
    
    /// <summary>
    /// Gets or sets <see cref="DataObject.VersionID"/> property value.
    /// </summary>
    public int VersionID {
      get { return versionID; }
      set { versionID = value; }
    }
    
    /// <summary>
    /// Gets or sets <see cref="DataObject"/>'s property name.
    /// </summary>
    public string PropertyName {
      get { return propertyName; }
      set { propertyName = value; }
    }
    
    /// <summary>
    /// Sets property value.
    /// </summary>
    /// <param name="value">Property value.</param>
    public void SetValue(object value)
    {
      if (value==null) {
        data = null;
        dataSize = 0;
        return;
      }
      
      System.Type type = value.GetType();
      
      if (type.IsPrimitive) {
        data = value;
        dataSize = Marshal.SizeOf(type);
        return;
      }
      
      if (type.IsArray) {
        System.Type elementType = type.GetElementType();
        if (elementType.IsPrimitive) {
          data = value;
          dataSize = ((Array)value).Length*Marshal.SizeOf(elementType);
          return;
        }
      }
      
      BinaryFormatter bf = new BinaryFormatter();
      bf.AssemblyFormat = FormatterAssemblyStyle.Simple;
      bf.TypeFormat = FormatterTypeStyle.TypesWhenNeeded;
      
      MemoryStream stream = new MemoryStream();
      bf.Serialize(stream, value);
      
      data = stream.ToArray();
      dataSize = -1;
    }
    
    /// <summary>
    /// Returns property value.
    /// </summary>
    /// <returns>Property value.</returns>
    public object GetValue()
    {
      if (dataSize>=0)
        return data;
        
      BinaryFormatter bf = new BinaryFormatter();
      bf.AssemblyFormat = FormatterAssemblyStyle.Simple;
      bf.TypeFormat = FormatterTypeStyle.TypesWhenNeeded;
      
      return bf.Deserialize(new MemoryStream((byte[])data));
    }
    
    /// <summary>
    /// Returns estimated size of this object in bytes.
    /// </summary>
    public int Size {
      get {
        return 12 + 8 + 8 + 8 + (dataSize>=0 ? dataSize : 8+((Array)data).Length);
      }
    }
    
    /// <summary>
    /// Gets item type.
    /// </summary>
    GlobalCacheItemType IGlobalCacheItem.ItemType {
      get {
        return itemType;
      }
    }
    
    /// <summary>
    /// Gets a value indicating whether current item can be cached.
    /// </summary>
    bool IGlobalCacheItem.CanCache {
      get { return true; }
    }
    
    /// <summary>
    /// This method is called when item is placed into global cache.
    /// </summary>
    void IGlobalCacheItem.OnCached()
    {
    }
    
    /// <summary>
    /// This method is called when item is validated by validation info.
    /// </summary>
    /// <param name="vInfo">Validation info.</param>
    void IGlobalCacheItem.OnValidated(IGlobalCacheItemValidationInfo vInfo)
    {
    }
    
    /// <summary>
    /// Creates a new object that is a copy of the current instance.
    /// </summary>
    /// <returns>A new object that is a copy of this instance.</returns>
    object ICloneable.Clone()
    {
      PropertyInstantiationInfo clone = new PropertyInstantiationInfo();
      clone.itemType     = this.itemType;
      clone.ID           = this.ID;
      clone.PropertyName = this.PropertyName;
      clone.VersionID    = this.VersionID;
      clone.data         = this.data;
      clone.dataSize     = this.dataSize;
      return clone;
    }
    

    // Constructors
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    private PropertyInstantiationInfo()
    {
    }
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="itemType">Initial <see cref="IGlobalCacheItem.ItemType"/> value.</param>
    /// <param name="id">Initial <see cref="PropertyInstantiationInfo.ID"/> value.</param>
    /// <param name="propertyName">Initial <see cref="PropertyInstantiationInfo.PropertyName"/> value.</param>
    /// <param name="versionID">Initial <see cref="PropertyInstantiationInfo.VersionID"/> value.</param>
    public PropertyInstantiationInfo(GlobalCacheItemType itemType, long id, string propertyName, int versionID)
    {
      this.itemType = itemType;
      this.id = id;
      this.propertyName = propertyName;
      this.versionID = versionID;
    }
  }
}
