// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.IO;
using System.Threading;
using System.Configuration;
using System.Diagnostics;
using System.Globalization;
using System.Collections;
using DataObjects.NET;
using DataObjects.NET.Attributes;
using DataObjects.NET.Exceptions;
using DataObjects.NET.FullText;

namespace DataObjects.NET.Security.Permissions
{
  /// <summary>
  /// This permission is required to change any full-text indexing
  /// data (see <see cref="IFtObject"/>, <see cref="FtRecord"/>).
  /// <seealso cref="IPermission"/>
  /// <seealso cref="IPermissionSet"/>
  /// <seealso cref="PermissionSet"/>
  /// </summary>
  [Serializable]
  public class ChangeFullTextDataPermission: Permission
  {
    private static ChangeFullTextDataPermission _value = new ChangeFullTextDataPermission();
    /// <summary>
    /// Represents the instance of the this class.
    /// Normally you should use this static member to obtain
    /// an instance of this type (e.g. to improve permission
    /// checking cache performance and reduce the memory usage), 
    /// but this isn't strongly required.
    /// </summary>
    public  static ChangeFullTextDataPermission Value {
      get {return _value;}
    }
  }
}
