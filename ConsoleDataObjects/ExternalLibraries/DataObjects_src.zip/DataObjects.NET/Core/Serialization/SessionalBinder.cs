// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Reflection;
using System.Runtime.Serialization;
using DataObjects.NET.ObjectModel;
using DataObjects.NET.Security;
using DataObjects.NET.Security.Permissions;
using Type = System.Type;

namespace DataObjects.NET.Serialization
{
  /// <summary>
  /// Serialization binder used internally in the <see cref="Session"/>
  /// allowing <see cref="SessionalSerializationSurrogate"/> to make its job.
  /// </summary>
  public sealed class SessionalBinder: SerializationBinder
  {
    private Session session;
    /// <summary>
    /// Session of the binder.
    /// </summary>
    public  Session Session {
      get {return session;}
    }
    
    /// <summary>
    /// Provides a valid types for proxy classes.
    /// </summary>
    /// <param name="assemblyName">Specifies the <see cref="Assembly"/> name of the serialized object.</param>
    /// <param name="typeName">Specifies the <see cref="System.Type"/> name of the serialized object.</param>
    /// <returns></returns>
    public override System.Type BindToType(string assemblyName, string typeName) 
    {
      switch (typeName) {
      case "DataObjects.NET.Serialization.FastLoadDataSubstitution":
        return typeof(FastLoadDataSubstitution);
      case "DataObjects.NET.Serialization.DataObjectReference":
        return typeof(DataObjectReference);
      case "DataObjects.NET.Security.AccessControlList":
        return typeof(AccessControlList);
      case "DataObjects.NET.Security.PermissionSet":
        return typeof(PermissionSet);
      }
      // http://server:8888/DataObjects.NET/Lists/Bugs/DispForm.aspx?ID=21
      assemblyName = assemblyName.Split(',',' ')[0];
      Type result = System.Type.GetType(typeName+", "+assemblyName);
      if ((result == null) && (typeName.ToLower().EndsWith("permission"))) {
        return typeof(NotDeserializedPermission);
      }
      return result;

    }
    
    /// <summary>
    /// Initializes an instance of this class.
    /// </summary>
    /// <param name="session">Session of the binder.</param>
    public SessionalBinder(Session session)
    {
      if (session==null)
        throw new ArgumentNullException("session");
      this.session = session;
    }
  }
}
