// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;

namespace DataObjects.NET
{
  /// <summary>
  /// Allows to cache any persistent collection. See <see cref="CacheableValue"/>
  /// for additional information (this class adds just one new property).
  /// </summary>
  public class CacheableCollection : CacheableValue
  {
    /// <summary>
    /// Gets cached collection (the same as 
    /// (<see cref="ICollection"/>)<see cref="CacheableValue.Value"/>).
    /// </summary>
    public ICollection Collection {
      get {
        return (ICollection)Value;
      }
    }


    // Constructors
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="session">Session, to which current instance should be bound.</param>
    public CacheableCollection(Session session) : base(session)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="session">Session, to which current instance should be bound.</param>
    /// <param name="calculate">Delegate that calculates cached value.</param>
    public CacheableCollection(Session session, CacheableValueEventHandler calculate) : 
      base(session, calculate)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="session">Session, to which current instance should be bound.</param>
    /// <param name="expirationPeriod">Initial <see cref="CacheableValue.ExpirationPeriod"/> value.</param>
    public CacheableCollection(Session session, TimeSpan expirationPeriod) : 
      base(session, expirationPeriod)
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="session">Session, to which current instance should be bound.</param>
    /// <param name="expirationPeriod">Initial <see cref="CacheableValue.ExpirationPeriod"/> value.</param>
    /// <param name="calculate">Delegate that calculates cached value.</param>
    public CacheableCollection(Session session, TimeSpan expirationPeriod, 
      CacheableValueEventHandler calculate) : base(session, expirationPeriod, calculate)
    {
    }
  }
}
