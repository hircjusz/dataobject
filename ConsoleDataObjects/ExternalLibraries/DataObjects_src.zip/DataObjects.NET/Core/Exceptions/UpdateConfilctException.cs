// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Runtime.Serialization;
using DataObjects.NET.Database;

namespace DataObjects.NET.Exceptions
{
  /// <summary>
  /// Thrown by <see cref="Persister"/> when snapshot-specific exception takes place.
  /// <seealso cref="DeadlockException"/>
  /// <seealso cref="TransactionCanBeReprocessedException"/>
  /// <seealso cref="InstanceVersionChangedException"/>
  /// <seealso cref="Session.ReprocessingAttemptsCount"/>
  /// <seealso cref="Session.ReprocessingDelay"/>
  /// </summary>
  [Serializable]
  public class UpdateConfilctException: TransactionCanBeReprocessedException
  {
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="innerException">Inner exception.</param>
    public UpdateConfilctException(Exception innerException): base(innerException.Message,innerException) 
    {
    }
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="text">Text of message.</param>
    /// <param name="innerException">Inner exception.</param>
    public UpdateConfilctException(string text, Exception innerException): base(text,innerException) 
    {
    }
    
    /// <summary>
    /// Deserialization constructor.
    /// </summary>
    /// <param name="info"><see cref="SerializationInfo"/> object.</param>
    /// <param name="context"><see cref="StreamingContext"/> object.</param>
    protected UpdateConfilctException(SerializationInfo info, StreamingContext context):
      base(info, context)
    {
    }
  }
}
