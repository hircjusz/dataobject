// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Text;
using System.IO;
using System.Runtime.InteropServices;

// Contains helper classes, constants and methods for 
// DataObjects.NET.FullText.Filters.IndexServiceFilter
namespace DataObjects.NET.FullText.Filters
{
  // Misc. structs and enums

  class STGTY
  {
    internal const int STGTY_STORAGE = 1;
    internal const int STGTY_STREAM = 2;
    internal const int STGTY_LOCKBYTES = 3;
    internal const int STGTY_PROPERTY = 4;
  }

  class STREAM_CONST
  {
    internal const int STREAM_SEEK_SET  = 0;
    internal const int STREAM_SEEK_CUR  = 1;
    internal const int STREAM_SEEK_END  = 2;
  }

  class FILTER_CONST
  {
    public const int  FILTER_E_END_OF_CHUNKS          =(unchecked((int)0x80041700));
    public const int  FILTER_E_NO_MORE_TEXT           =(unchecked((int)0x80041701));
    public const int  FILTER_E_NO_MORE_VALUES         =(unchecked((int)0x80041702));

    public const int  FILTER_E_NO_TEXT                =(unchecked((int)0x80041705));
    public const int  FILTER_E_NO_VALUES              =(unchecked((int)0x80041706));
    public const int  FILTER_S_LAST_TEXT              =(unchecked((int)0x00041709));
  }

  [Flags]
  enum IFILTER_INIT
  {
    NONE                   = 0,
    CANON_PARAGRAPHS       = 1,
    HARD_LINE_BREAKS       = 2,
    CANON_HYPHENS          = 4,
    CANON_SPACES           = 8,
    APPLY_INDEX_ATTRIBUTES = 16,
    APPLY_CRAWL_ATTRIBUTES = 256,
    APPLY_OTHER_ATTRIBUTES = 32,
    INDEXING_ONLY          = 64,
    SEARCH_LINKS           = 128,        
    FILTER_OWNED_VALUE_OK  = 512
  }
  
  [Flags]
  enum IFILTER_FLAGS
  {
    OLE_PROPERTIES = 1
  }

  enum CHUNK_BREAKTYPE
  {
    CHUNK_NO_BREAK = 0,
    CHUNK_EOW      = 1,
    CHUNK_EOS      = 2,
    CHUNK_EOP      = 3,
    CHUNK_EOC      = 4
  }

  [Flags]
  enum CHUNKSTATE
  {
    CHUNK_TEXT               = 0x1,
    CHUNK_VALUE              = 0x2,
    CHUNK_FILTER_OWNED_VALUE = 0x4
  }

  enum PSKIND
  {
    LPWSTR = 0,
    PROPID = 1
  }

  [StructLayout(LayoutKind.Sequential)]
  struct PROPSPEC
  {
    uint ulKind;
    uint propid;
    IntPtr lpwstr;
  }

  [StructLayout(LayoutKind.Sequential)]
  struct FULLPROPSPEC
  {
    Guid guidPropSet;
    PROPSPEC psProperty;
  }

  [StructLayout(LayoutKind.Sequential)]
  internal struct STAT_CHUNK
  {
    internal uint  idChunk;
    [MarshalAs(UnmanagedType.U4)] internal  CHUNK_BREAKTYPE breakType;
    [MarshalAs(UnmanagedType.U4)] internal CHUNKSTATE flags;
    internal uint locale;
    [MarshalAs(UnmanagedType.Struct)] internal FULLPROPSPEC attribute;
    internal uint idChunkSource;
    internal uint cwcStartSource;
    internal uint cwcLenSource;
  }

  [StructLayout(LayoutKind.Sequential)]
  struct FILTERREGION
  {
    uint idChunk;
    uint cwcStart;
    uint cwcExtent;
  }

  [StructLayout(LayoutKind.Sequential)]
  struct PROPVARIANT 
  {
    UnmanagedType vt;  
    Int16 wReserved1;  
    Int16 wReserved2;  
    Int16 wReserved3; 
    Int64 value;
  }

  // IFilter (COM interface)

  [ComImport]
  [Guid("89BCB740-6119-101A-BCB7-00DD010655AF")]
  [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
  interface IFilter
  {
    void Init([MarshalAs(UnmanagedType.U4)] IFILTER_INIT grfFlags, 
      uint cAttributes,
      [MarshalAs(UnmanagedType.LPArray, SizeParamIndex=1)] FULLPROPSPEC[] aAttributes,
      ref uint pdwFlags);

    [PreserveSig] int GetChunk([MarshalAs(UnmanagedType.Struct)] out STAT_CHUNK pStat);

    [PreserveSig] int GetText(ref uint pcwcBuffer, [MarshalAs(UnmanagedType.LPWStr)] StringBuilder buffer);

    [PreserveSig] int GetValue(ref UIntPtr ppPropValue);

    void BindRegion([MarshalAs(UnmanagedType.Struct)]FILTERREGION origPos, ref Guid riid, ref UIntPtr ppunk);
  }


  // IPersistStream (COM interface)

  [InterfaceType(ComInterfaceType.InterfaceIsIUnknown),
  Guid("0000010c-0000-0000-C000-000000000046")]
  interface IPersist
  {
    void GetClassID( /* [out] */ out Guid pClassID);
  };
    
  [InterfaceType(ComInterfaceType.InterfaceIsIUnknown),
  Guid("00000109-0000-0000-C000-000000000046")]
  interface IPersistStream : IPersist
  {
    new void GetClassID(out Guid pClassID);

    [PreserveSig]
    int IsDirty( ); 
    void Load([In] UCOMIStream pStm);
    void Save([In] UCOMIStream pStm, [In, MarshalAs(UnmanagedType.Bool)] bool fClearDirty);
    void GetSizeMax(out long pcbSize);
  };


  // Stream 2 UCOMIStream wrapper

  class Stream2UCOMIStreamWrapper : UCOMIStream
  {
    private Stream stream;
    internal Stream2UCOMIStreamWrapper (Stream stream)
    {
      this.stream = stream;
    }
    
    public void Clone(
      out UCOMIStream ppstm
      )
    {
      ppstm = null;
      throw new NotImplementedException("Clone is not implemented for Stream2UCOMIStreamWrapper");
    }

    public void Commit(
      int grfCommitFlags
      )
    {
      throw new NotImplementedException("Commit is not implemented for Stream2UCOMIStreamWrapper");
    }

    public unsafe void CopyTo(
      UCOMIStream pstm,
      long cb,
      IntPtr pcbRead,
      IntPtr pcbWritten
      )
    {
      throw new NotImplementedException("CopyTo is not implemented for Stream2UCOMIStreamWrapper");
    }

    public void LockRegion(
      long libOffset,
      long cb,
      int dwLockType
      )
    {
      throw new NotImplementedException("LockRegion is not implemented for Stream2UCOMIStreamWrapper");
    }

    public unsafe void Read(
      /*[
        Out
        ] */
      byte[] pv,
      int cb,
      IntPtr pcbRead
      )
    {
      int iReadBytes = stream.Read(pv,0,cb);
      if ((int *)pcbRead != null)
      {
        *(int *)pcbRead = iReadBytes;
      }
    }

    public void Revert()
    {
      throw new NotImplementedException("Revert is not implemented for Stream2UCOMIStreamWrapper");
    }

    public  unsafe void Seek(
      long dlibMove,
      int dwOrigin,
      IntPtr plibNewPosition
      )
    {
      if (dwOrigin==STREAM_CONST.STREAM_SEEK_SET)
      {
        stream.Seek(dlibMove,SeekOrigin.Begin);
      }
      else if (dwOrigin==STREAM_CONST.STREAM_SEEK_CUR)
      {
        stream.Seek(dlibMove,SeekOrigin.Current);
      }
      else if (dwOrigin==STREAM_CONST.STREAM_SEEK_END)
      {
        stream.Seek(dlibMove,SeekOrigin.End);
      }


      if ((int *)plibNewPosition  != null)
      {
        *(int *)plibNewPosition = (int)stream.Position;
      }
    }

    public void SetSize(
      long libNewSize
      )
    {
      throw new NotImplementedException("SetSize is not implemented for Stream2UCOMIStreamWrapper");
    }

    public void Stat(
      out STATSTG pstatstg,
      int grfStatFlag
      )
    {
      pstatstg = new STATSTG();
      pstatstg.type = STGTY.STGTY_STREAM;
      pstatstg.cbSize = stream.Length;;
    }

    public void UnlockRegion(
      long libOffset,
      long cb,
      int dwLockType
      )
    {
      throw new NotImplementedException("UnlockRegion is not implemented for Stream2UCOMIStreamWrapper");
    }

    public void Write(
      byte[] pv,
      int cb,
      IntPtr pcbWritten
      )
    {
      throw new NotImplementedException("Write is not implemented for Stream2UCOMIStreamWrapper");
    }
  }
}

