// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;
using System.Text;
using DataObjects.NET.Attributes;
using DataObjects.NET.Database;

namespace DataObjects.NET.Helpers
{
  /// <summary>
  /// A <see cref="IPropertyValueValidator">validator</see> that
  /// checks uniqueness of property value; 
  /// throws <see cref="ArgumentOutOfRangeException"/> if this condition
  /// is violated.
  /// <seealso cref="ValidatorAttribute"/>
  /// </summary>
  /// <remarks>
  /// See <see cref="ValidatorAttribute"/> also.
  /// </remarks>
  [Serializable]
  public class UniqueValidator: IPropertyValueValidator 
  {
    private string[] fieldNames = new string[0];
    /// <summary>
    /// Fields which value combinations should be unique.
    /// </summary>
    public  string[] Fields {
      get {return fieldNames;}
      set {fieldNames = value;}
    }

    /// <summary>
    /// Validates <see cref="DataObject"/> property value 
    /// before it is actually set by 
    /// <see cref="DataObject.SetProperty">DataObject.SetProperty</see>
    /// method.
    /// </summary>
    /// <param name="dataObject"><see cref="DataObject"/> instance
    /// which property is to be changed.</param>
    /// <param name="propertyName">Property name.</param>
    /// <param name="culture">Property culture.</param>
    /// <param name="value">New property value.</param>
    /// <remarks>
    /// Checks uniqueness of property value; 
    /// throws <see cref="ArgumentOutOfRangeException"/> if this condition
    /// is violated.
    /// </remarks>
    public void Validate(DataObject dataObject, string propertyName, Culture culture, object value) 
    {
      Session           session = dataObject.Session;
      ObjectModel.Type  type    = dataObject.Type;
      ObjectModel.Field field = GetField(type, propertyName, false);
      value = ConvertValueToInternal(dataObject, field, culture, value);
      if (value==terminateExecutionMark)
        return;

      ObjectModel.Type searchType = null;
      ArrayList listSearchColumns = new ArrayList();
      if (fieldNames.Length==0) {
        searchType = field.RootField.DeclaredField.Type;
        field.InternalValueToRecord(session, dataObject, culture, value, listSearchColumns);
      }
      else {
        ObjectModel.Field[] fields = GetFields(type, fieldNames);
        for (int fieldIndex=0, fieldCount=fields.Length; fieldIndex<fieldCount; fieldIndex++) {
          ObjectModel.Field currentField = fields[fieldIndex];
          ObjectModel.Field currentRootField = currentField.RootField;
          ObjectModel.Type currentDeclaredType = currentRootField.DeclaredField.Type;
          if (searchType==null || currentDeclaredType.IsDescendantOf(searchType))
            searchType = currentDeclaredType;
          object fieldValue = value;
          if (currentField!=field) {
            if (currentRootField==field) {
              string containedFieldName = currentField.AbsoluteName.Substring(currentRootField.AbsoluteName.Length+1);
              fieldValue = ((ObjectModel.ISupportsIndexingField)currentRootField).GetContainedFieldValue(dataObject, culture, fieldValue, null, containedFieldName);
            }
            else {
              fieldValue = dataObject.GetProperty(currentField.AbsoluteName, culture);
              fieldValue = ConvertValueToInternal(dataObject, currentField, culture, fieldValue);
            }
          }
          currentField.InternalValueToRecord(session, dataObject, culture, fieldValue, listSearchColumns);
        }
      }
      StringBuilder sbText = new StringBuilder();
      Query query = session.CreateQuery();
      sbText.AppendFormat("Select count {0} instances where {{ID}}<>{1}", searchType.Name, dataObject.ID);
      for (int columnIndex=0, columnCount=listSearchColumns.Count; columnIndex<columnCount; columnIndex++) {
        ColumnValue columnValue = (ColumnValue)listSearchColumns[columnIndex];
        string paramName = "@P"+columnIndex.ToString();
        sbText.AppendFormat(" and {{{0}}}={1}", 
          GetDbName(session, columnValue.Column.RelatedField, culture), paramName);
        query.Parameters.Add(paramName, columnValue.Value);
      }
      query.Text = sbText.ToString();
      if(query.ExecuteCount() != 0) {
        if (fieldNames.Length<2)
          throw new ArgumentOutOfRangeException(propertyName, value,
            String.Format("The specified value of \"{0}\" field of \"{1}\" type is not unique.", propertyName, searchType.Name));
        sbText.Length = 0;
        sbText.Append("A combination of values of ");
        for (int fieldIndex=1, count=fieldNames.Length; fieldIndex<count; fieldIndex++)
          sbText.AppendFormat("\"{0}\", ", fieldNames[fieldIndex-1]);
        sbText.Length-=2;
        sbText.AppendFormat(" and \"{0}\" fields of \"{1}\" type is not unique.", fieldNames[fieldNames.Length-1], searchType.Name);
        throw new ArgumentOutOfRangeException(propertyName, value, sbText.ToString());
      }
    }

    /// <summary>
    /// Attaches a validator instance to a certain field.
    /// </summary>
    /// <param name="field">A <see cref="ObjectModel.Field"/> the validator is related to.</param>
    public void AttachToField (ObjectModel.Field field)
    {
      // Does nothing
    }

    private static object terminateExecutionMark = new object();
    private static object ConvertValueToInternal(DataObject dataObject, ObjectModel.Field field, Culture culture, object value)
    {
      string fieldName = field.AbsoluteName;
      if (field.TypeModifier!=null) {
        if (value!=null && !(field.ExternalType.IsInstanceOfType(value)))
          return terminateExecutionMark; // SetProperty method throws an exception in this case. So we stop validation.
        value = field.TypeModifier.ConvertToInternalValue(dataObject, fieldName, culture, value);
      }
      return field.ConvertValueToInternal(dataObject, culture, value);
    }

    private static string GetDbName (Session session, ObjectModel.Field field, Culture culture)
    {
      string[] nameParts = field.AbsoluteName.Split('.');
      string quotedName = "\"" + String.Join("\".\"", nameParts) + "\"";
      ObjectModel.Field rootField = field.RootField == null ? field : field.RootField;
      if (!rootField.Translatable)
        return quotedName;
      if (culture==null)
        culture=session.Culture;
      int dotIndex = quotedName.IndexOf(".");
      if (dotIndex>0) {
        string rootName = quotedName.Substring(0, dotIndex) + "-\"" + culture.Name + "\"";
        return rootName + quotedName.Substring(dotIndex);
      }
      else
        return quotedName + "-\"" + culture.Name + "\"";
    }

    internal static ObjectModel.Field[] GetFields (ObjectModel.Type type, string[] fieldNames)
    {
      return GetFields(type, fieldNames, false);
    }

    internal static ObjectModel.Field[] GetFields (ObjectModel.Type type, string[] fieldNames, bool getRoots)
    {
      Hashtable hsFields = new Hashtable();
      for (int fieldIndex=0, fieldCount=fieldNames.Length; fieldIndex<fieldCount; fieldIndex++)
        hsFields[GetField(type, fieldNames[fieldIndex], getRoots)] = hsFields;
      ObjectModel.Field[] fields = new ObjectModel.Field[hsFields.Count];
      hsFields.Keys.CopyTo(fields, 0);
      return fields;
    }

    private static ObjectModel.Field GetField (ObjectModel.Type type, string fieldName, bool getRoots)
    {
      if (fieldName==null)
        throw new ArgumentNullException("Invalid UniqueValidator field name: The field name can't be null.");
      if (fieldName.IndexOf('-')>=0)
        throw new ArgumentException("Invalid UniqueValidator field name: Cultures are not allowed in the field names.");
      if (fieldName.IndexOf('[')>=0  || fieldName.IndexOf(']')>=0)
        throw new ArgumentException("Invalid UniqueValidator field name: Unable to access collection items.");
      string partName = null;
      int dotPosition = fieldName.IndexOf('.');
      if (dotPosition >= 0) {
        partName  = fieldName.Substring(dotPosition + 1);
        fieldName = fieldName.Substring(0, dotPosition);
      }
      ObjectModel.Field rootField = type.Fields[fieldName];
      if (rootField==null)
        throw new InvalidOperationException(String.Format("The field \"{0}\" of \"{1}\" type is not found.", fieldName, type.Name));
      if (dotPosition>=0 && !getRoots) {
        ObjectModel.Field containedField = rootField.ContainedFields[partName];
        if (containedField==null)
          throw new InvalidOperationException(String.Format("The field \"{0}.{1}\" of \"{2}\" type is not found.", fieldName, partName, type.Name));
        return containedField;
      }
      return rootField;
    }

    /// <summary>
    /// Determines whether two <see cref="UniqueValidator"/> instances are equal.
    /// </summary>
    /// <returns><see langword="true"/> if the specified <see cref="UniqueValidator"/> is equal to the current one; otherwise, <see langword="false"/>.</returns>
    public override bool Equals(object obj)
    {
      bool referencesEqual = base.Equals(obj);
      if (referencesEqual || fieldNames.Length==0)
        return referencesEqual;
      UniqueValidator validator = obj as UniqueValidator;
      if (validator!=null) {
        string strFields = String.Join("", fieldNames);
        string strValidatorFields = String.Join("", validator.fieldNames);
        return strFields.Equals(strValidatorFields);
      }
      return false;
    }

    /// <summary>
    /// Serves as a hash function for a <see cref="UniqueValidator"/> type.
    /// </summary>
    /// <returns>A hash code for the current <see cref="UniqueValidator"/>.</returns>
    public override int GetHashCode()
    {
      if (fieldNames.Length==0)
        return base.GetHashCode();
      return String.Join("", fieldNames).GetHashCode();
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    public UniqueValidator()
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="fields">An <see cref="Array"/> of field names.
    /// Any combination of values of these fields should be unique.</param>
    public UniqueValidator(string[] fields)
    {
      this.fieldNames = (string[])fields.Clone();
      Array.Sort(this.fieldNames);
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="fields">A string containing comma-separated field names.
    /// Any combination of values of these fields should be unique.</param>
    public UniqueValidator(string fields) 
    {
      this.fieldNames = fields.Split(',');
      for (int i = 0; i<this.fieldNames.Length; i++)
        this.fieldNames[i] = this.fieldNames[i].Trim();
      Array.Sort(this.fieldNames);
    }
  }
}
