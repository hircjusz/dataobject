// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Attributes;

namespace DataObjects.NET
{
  /// <summary>
  /// Enumeration of possible <see cref="TransactionContext"/> states.
  /// <seealso cref="TransactionContext.State"/>
  /// </summary>
  public enum TransactionContextState
  {
    /// <summary>
    /// Transaction context is valid.
    /// This means it belongs to active outermost transaction and 
    /// doesn't contains any dirty data (it doesn't belong to any
    /// inner or outermost transaction that was rolled back).
    /// Any <see cref="DataObject"/> instance in this context contains
    /// valid data.
    /// Any cached data fetched in this context can be used.
    /// Value is <see langword="0"/>. 
    /// </summary>
    Valid = 0,
    /// <summary>
    /// Transaction context belongs to another outermost transaction
    /// and doesn't contain any dirty data (it doesn't belong to any
    /// inner or outermost transaction that was rolled back).
    /// Any <see cref="DataObject"/> instance in this context should
    /// perform version check to ensure its data is valid 
    /// (<see cref="DataObject"/>s always perform this check when
    /// this is necessary).
    /// Any cached data fetched in this context should be re-evaluated,
    /// if some of <see cref="DataObject"/> instances it depends on
    /// doesn't passed a version check.
    /// Value is <see langword="0x1"/>. 
    /// </summary>
    BelongsToAnotherOutermostTransaction = 0x1,
    /// <summary>
    /// Transaction context belongs to another outermost transaction
    /// and doesn't contain any dirty data (it doesn't belong to any
    /// inner or outermost transaction that was rolled back).
    /// Synonym of <see cref="BelongsToAnotherOutermostTransaction"/>.
    /// Value is <see langword="0x1"/>. 
    /// </summary>
    RequiresVersionCheck = 0x1,
    /// <summary>
    /// Transaction context is dirty.
    /// This means it belong to some inner or outermost transaction 
    /// that was rolled back.
    /// Any <see cref="DataObject"/> instance in this context should
    /// be <see cref="DataObject.Reload"/>ed.
    /// (<see cref="DataObject"/>s always perform this operation when
    /// this is necessary).
    /// Any cached data fetched in this context should be re-evaluated.
    /// Value is <see langword="0x2"/>. 
    /// </summary>
    Dirty = 0x2
  }
}
