// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Collections;
using System.Collections.Specialized;
using System.EnterpriseServices;
using System.Data;
using System.Data.OleDb;
using DataObjects.NET.Database;
using DataObjects.NET.Exceptions;
using DataObjects.NET.Attributes;
using DataObjects.NET.ObjectModel;
using DataObjects.NET.DatabaseModel;
using DataObjects.NET.FullText;
using DataObjects.NET.FullText.Drivers.Native;

namespace DataObjects.NET.Database.Drivers.MSAccess
{
  /// <summary>
  /// Microsoft Access implementation of <see cref="Persister"/>.
  /// </summary>
  public class MSAccessPersister: Persister
  {
    OleDbCommand  cmd;
    StringBuilder sbCmd  = new StringBuilder(256);
    StringBuilder sbCols = new StringBuilder(128);
    StringBuilder sbVals = new StringBuilder(128);
    Utils         utils;
//    IsolationLevel lastIsolationLevel = IsolationLevel.Unspecified;
    ArrayList savepoints = new ArrayList();
    Hashtable savepointsH = new Hashtable();

    // Pre-calculated values
    string     tDataObject;
    string     cID;
    string     cTypeId;
    string     cVersionId;
    string     cPermissions;
    string     cFastLoadData;
    string     cAll;
    string     cFullFtObject;

    // Transactions, savepoints...
    
    /// <summary>
    /// Begins a new transaction. <see cref="SetTransaction"/> should be
    /// additionally called to switch the persister to a new transaction.
    /// </summary>
    /// <param name="isolationLevel">Isolation level.</param>
    /// <returns>Newly started transaction.</returns>
    public override IDbTransaction BeginTransaction(IsolationLevel isolationLevel)
    {
      return Connection.BeginTransaction(Driver.TranslateIsolationLevel(isolationLevel));
    }


    /// <summary>
    /// Called when it's necessary to change the command timeout value.
    /// </summary>
    /// <param name="commandTimeout">New command timeout value.</param>
    public override void SetCommandTimeout(int commandTimeout)
    {
      base.SetCommandTimeout(commandTimeout);
      EnsureCommandValid(cmd);
      cmd.CommandTimeout = commandTimeout;
    }
    
    /// <summary>
    /// Called when it's necessary to switch the persister to the
    /// next transaction.
    /// </summary>
    /// <param name="transaction">New transaction (can be <see langword="null"/>).</param>
    public override void SetTransaction(IDbTransaction transaction)
    {
      savepoints.Clear();
      savepointsH.Clear();

      base.SetTransaction( transaction );
      EnsureCommandValid(cmd);
      cmd.Transaction = (OleDbTransaction)transaction;
    }
    
    /// <summary>
    /// Changes current isolation level.
    /// </summary>
    /// <param name="isolationLevel">New isolation level.</param>
    public override void ChangeIsolationLevel(IsolationLevel isolationLevel)
    {
      EnsureCommandValid(cmd);
      cmd.Parameters.Clear();

      // not supported by Access
    }

    /// <summary>
    /// Creates transaction savepoint.
    /// </summary>
    /// <param name="name">Savepoint name.</param>
    public override void CreateSavepoint( string name )
    {
      savepointsH[name] = savepoints.Count;
      savepoints.Add( name );
      EnsureCommandValid(cmd);
      cmd.Parameters.Clear();
      cmd.CommandText = "Begin Transaction";
      ( (MSAccessDriver)Driver ).LogSqlCommand( "MSAccessPersister.CreateSavepoint (" + name + ")", cmd );
      cmd.ExecuteNonQuery();
    }

    /// <summary>
    /// Performs a rollback to the specified savepoint.
    /// </summary>
    /// <param name="name">Savepoint name.</param>
    public override void RollbackToSavepoint(string name)
    {
      EnsureCommandValid(cmd);
      cmd.Parameters.Clear();

      object occurO = savepointsH[name];
      if (occurO==null)
        throw new InvalidOperationException( "Savepoint isn't available." );
      int occur = (int)occurO;
      int count = savepoints.Count;
      for (int i = count - 1; i >= occur; i--) {
        cmd.CommandText = "Rollback Transaction";
        ( (MSAccessDriver)Driver ).LogSqlCommand( "MSAccessPersister.RollbackSavepoint (" + name + ")", cmd );
        cmd.ExecuteNonQuery();
        savepointsH.Remove( savepoints[i] );
        savepoints.RemoveAt( i );
      }
    }

    /// <summary>
    /// Disposes specified transaction savepoint.
    /// </summary>
    /// <param name="name">Savepoint name.</param>
    public override void DisposeSavepoint(string name)
    {
      EnsureCommandValid(cmd);
      cmd.Parameters.Clear();

      object occurO = savepointsH[name];
      if (occurO==null)
        throw new InvalidOperationException( "Savepoint isn't available." );
      int occur = (int)occurO;
      int count = savepoints.Count;
      for (int i = count - 1; i >= occur; i--) {
        cmd.CommandText = "Commit Transaction";
        ( (MSAccessDriver)Driver ).LogSqlCommand( "MSAccessPersister.DisposeSavepoint (" + name + ")", cmd );
        cmd.ExecuteNonQuery();
        savepointsH.Remove( savepoints[i] );
        savepoints.RemoveAt( i );
      }
    }


    // Persistence

    /// <summary>
    /// Fetches set of DataObject instance columns.
    /// </summary>
    /// <param name="view"><see cref="View"/> to select from.</param>
    /// <param name="columns">List of <see cref="ViewColumn"/>s to fetch values of.</param>
    /// <param name="id">Instance ID.</param>
    /// <param name="expectedVersionID">Expected VersionID value.</param>
    /// <param name="checkVersions"><see langword="True"/> if version check is required.</param>
    /// <returns>Fetched columns.</returns>
    public override IDictionary FetchInstanceColumns(View view, ArrayList columns, long id, int expectedVersionID, bool checkVersions)
    {
      string sFrom = "["+view.Name+"]";
      sbCmd.Length = 0;
      string sDiv = "";
      foreach (ViewColumn vc in columns) {
        sbCmd.Append(sDiv+"["+vc.Name+"]");
        sDiv = ", ";
      }
      string sColumns = sbCmd.ToString();
      
      EnsureCommandValid(cmd);
      cmd.Parameters.Clear();
      cmd.Parameters.Add(new OleDbParameter("@ID",(object)id));
      if (checkVersions) { 
        cmd.CommandText = 
          "Select "+sColumns+"\nfrom "+sFrom+
          "\nwhere "+cID+"=@ID and "+cVersionId+"=@ExpectedVersionID";
        cmd.Parameters.Add(new OleDbParameter("@ExpectedVersionID",(object)expectedVersionID));
      }
      else {
        cmd.CommandText = 
          "Select "+sColumns+"\nfrom "+sFrom+
          "\nwhere "+cID+"=@ID";
      }

      ((MSAccessDriver)Driver).LogSqlCommand( "MSAccessPersister.FetchInstanceColumns", cmd );
      using (OleDbDataReader r = cmd.ExecuteReader()) {
        if (!r.Read()) {
          r.NextResult(); // Bug workaround. 
                          // Read ms-help://MS.MSDNQTR.2003APR.1033/enu_kbwebdatanetkb/webdatanetkb/316667.htm
          return null;
        }
        else {
          IDictionary d;
          int fCnt = r.FieldCount;
          if (fCnt>10)
            d = new Hashtable(fCnt);
          else
            d = new ListDictionary();
          for (int i = 0; i<fCnt; i++)
            d.Add(r.GetName(i),r.GetValue(i));
          r.NextResult(); // Bug workaround. 
                          // Read ms-help://MS.MSDNQTR.2003APR.1033/enu_kbwebdatanetkb/webdatanetkb/316667.htm
          return d;
        }
      }
    }

    /// <summary>
    /// Fetches a set of DataObject instance columns.
    /// </summary>
    /// <param name="view"><see cref="View"/> to select from.</param>
    /// <param name="columns">List of <see cref="ViewColumn"/>s to fetch values of.</param>
    /// <param name="ids">An <see cref="Array"/> containing instance IDs.</param>
    /// <param name="expectedVersionIDs">An <see cref="Array"/> containing expected VersionID values.</param>
    /// <param name="checkVersions"><see langword="True"/> if version check is required.</param>
    /// <returns>Fetched columns.</returns>
    public override ArrayList FetchInstanceColumns(View view, ArrayList columns, long[] ids, int[] expectedVersionIDs, bool checkVersions) 
    {
      ArrayList result = new ArrayList();
      if (ids.Length==0)
        return result;
      
      sbCmd.Length = 0;
      sbCmd.Append("Select ");
      string sDiv = "";
      foreach (ViewColumn vc in columns) {
        sbCmd.Append(sDiv+"["+vc.Name+"]");
        sDiv = ", ";
      }
      sbCmd.Append("\nfrom ["+view.Name+"]\nwhere (");
      for (int i = 0, idCnt = ids.Length; i<idCnt; i++) {
        if (ids[i]==0)
          break;
        if (i>0) 
          sbCmd.Append(") or (");
        sbCmd.Append(cID+"="+ids[i]);
        if (checkVersions)
          sbCmd.Append(" and "+cVersionId+"="+expectedVersionIDs[i]);
      }
      sbCmd.Append(")");

      EnsureCommandValid(cmd);
      cmd.Parameters.Clear();
      cmd.CommandText = sbCmd.ToString();

      ((MSAccessDriver)Driver).LogSqlCommand( "MSAccessPersister.InsertInstanceColumns", cmd );
      using (OleDbDataReader r = cmd.ExecuteReader()) {
        while (r.Read()) {
          IDictionary d;
          int fCnt = r.FieldCount;
          if (fCnt>10)
            d = new Hashtable(fCnt);
          else
            d = new ListDictionary();
          for (int i = 0; i<fCnt; i++)
            d.Add(r.GetName(i),r.GetValue(i));
          result.Add(d);
        }
        r.NextResult(); // Bug workaround. 
                        // Read ms-help://MS.MSDNQTR.2003APR.1033/enu_kbwebdatanetkb/webdatanetkb/316667.htm
        r.Close();
      }
      return result;
    }
    
    /// <summary>
    /// Fetches DataObject instantiation info by the ID of instance.
    /// </summary>
    /// <param name="table">Table to fetch record from.</param>
    /// <param name="id">Instance ID.</param>
    /// <returns>Instantiation info.</returns>
    public override DataObjectInstantiationInfo FetchDataObject(Table table, long id)
    {
      EnsureCommandValid(cmd);
      cmd.Parameters.Clear();
      cmd.CommandText = 
        "Select "+cAll + 
        " from ["+table.Name+"] "+ // with (FASTFIRSTROW)"+  // Access doesn't support FASTFIRSTROW
        "\nwhere "+cID+"=@ID";
      cmd.Parameters.Add(new OleDbParameter("@ID",(object)id));

      ((MSAccessDriver)Driver).LogSqlCommand( "MSAccessPersister.FetchDataObject", cmd );
      
      using (OleDbDataReader r = cmd.ExecuteReader()) {
        try {
          if (!r.Read())
            return null;
          #if MONO
          if (0==Convert.ToInt32(r.GetValue(0)))
          #else
          if (0==r.GetInt32(0))
          #endif
            return null;
          return new DataObjectInstantiationInfo(
            id,
            r.GetInt32(1),
            r.GetInt32(2),
            r[3] as byte[],
            r[4] as byte[],
            Session.TransactionContext);
        }
        finally {
          r.NextResult(); // Bug workaround. 
                          // Read ms-help://MS.MSDNQTR.2003APR.1033/enu_kbwebdatanetkb/webdatanetkb/316667.htm
        }
      }
    }
    
    /// <summary>
    /// Checks VersionID of DataObject instance with specified ID and fetches instance columns if version is changed.
    /// </summary>
    /// <param name="table">Table to fetch record from.</param>
    /// <param name="id">Instance ID.</param>
    /// <param name="expectedVersionID">Expected VersionID value.</param>
    /// <returns>Instantiation info, <see langword="null"/> if instance version 
    /// wasn't changed, or <see cref="DataObjectInstantiationInfo"/> with 
    /// <see cref="DataObjectIdentificationInfo.ID"/>=0 if no instance with 
    /// specified ID was found.</returns>
//    public override DataObjectInstantiationInfo FetchDataObjectIfVersionChanged(Table table, long id, int expectedVersionID)
    //SM begin
    public override DataObjectInstantiationInfo FetchDataObjectIfVersionChanged(Table table, long id, int expectedVersionID, object ctx)
    //SM end

    {
        //SM begin
        if (!DataObjects.NET.Caching.ChangeCache.getInstance().isChanged(id, ctx)) return null;
        //SM end

      EnsureCommandValid(cmd);
      cmd.Parameters.Clear();
      cmd.CommandText = 
        "Select Count(*) from ["+table.Name+"] "+ //with (FASTFIRSTROW)"+ // Access doesn't support FASTFIRSTROW
        " where "+cID+"=" + id.ToString() + " and "+cVersionId+"=" + expectedVersionID.ToString();
      ((MSAccessDriver)Driver).LogSqlCommand( "MSAccessPersister.FetchDataObjectIfVersionChanged", cmd );
      object count = cmd.ExecuteScalar();
      if (0!=Convert.ToInt32(count))
      {
        return null;
      }
      else
      {
        /* Access doesn't support IF/ELSE sql construct
        "If 0<Some(Select "+cTypeId+" from ["+table.Name+"] with (FASTFIRSTROW)"+
          " where "+cID+"=" + id.ToString() + " and "+cVersionId+"=" + expectedVersionID.ToString() + ")" +
        "\n  Select null" +
        "\nElse" +
        "\n  Select "+cAll+" from ["+table.Name+"] with (FASTFIRSTROW)"+
           " where "+cID+"=" + id.ToString();
        */
        cmd.CommandText = "Select "+cAll+" from ["+table.Name+"] "+ // with (FASTFIRSTROW)"+ // Access doesn't support FASTFIRSTROW
          " where "+cID+"=" + id.ToString();

        ((MSAccessDriver)Driver).LogSqlCommand( "MSAccessPersister.FetchDataObjectIfVersionChanged", cmd );
        
        using (OleDbDataReader r = cmd.ExecuteReader()) 
        {
          try 
          {
            if (!r.Read())
              return new DataObjectInstantiationInfo();
            object r0 = r[0];
            if (r0==DBNull.Value)
              return null;
            if (0==Convert.ToInt32(r0))
              return new DataObjectInstantiationInfo();
            return new DataObjectInstantiationInfo(
              id,
              r.GetInt32(1),
              r.GetInt32(2),
              r[3] as byte[],
              r[4] as byte[],
              Session.TransactionContext);
          }
          finally 
          {
            r.NextResult(); // Bug workaround. 
            // Read ms-help://MS.MSDNQTR.2006JAN.1033/enu_kbwebdatanetkb/webdatanetkb/316667.htm
          }
        }
      }
    }

    /// <summary>
    /// Inserts DataObject instance columns.
    /// </summary>
    /// <param name="columnValues">A list of <see cref="ColumnValue"/>s to insert.</param>
    /// <param name="tables">An <see cref="Array"/> of all <see cref="Table"/>s related to the class of instance.</param>
    /// <returns>New ID value.</returns>
      public override long InsertInstanceColumns(DataObjects.NET.ObjectModel.Type type, ArrayList columnValues, Table[] tables)
    {
      // Access requires individual SQL statements - doesn't support batches

      FlushDelayedSavepoints();

      sbCmd.Length  = 0;
      sbCols.Length = 0;
      sbVals.Length = 0;
      long          ID = 0;
      string        sDiv  = "";

      int tCnt = tables.Length;
      int cCnt = columnValues.Count;

      
      int j = 0;
      for( int i = 0; i<tCnt; i++ ) {
        Table t = tables[i];

        sbCols.Length = 0;
        sbVals.Length = 0;
        if (i!=0) {
          sbCols.Append(cID);
          sbVals.Append(ID.ToString());
          sDiv = ", ";
        }

        EnsureCommandValid(cmd);
        cmd.Parameters.Clear();
        while (j<cCnt) {
          ColumnValue cv = (ColumnValue)columnValues[j++];
          if (cv.Column.Table!=t) {
            j--;
            break;
          }
          string pName = "@P"+j.ToString();
          sbCols.Append(sDiv+"["+cv.Column.Name+"]");
          sbVals.Append(sDiv+pName);

#if MONO
          // We have to use the following 3-stage OleDbParameter creation procedure because 
          // under the Mono if we try to call OleDbParameter(string Name, object Value) constructor and
          // the second parameter is null the OleDbParameter(string Name, OleDbType dbType) constructor
          // will be called and Exception will be thrown.
          OleDbParameter p = new OleDbParameter();
          p.ParameterName = pName;
          p.Value = cv.Value;
          
          p.DbType = utils.GetDbType(cv.Column.SqlType);
//          if (p.Size==0 && p.DbType==DbType.Binary) {
//            // Mono does not permit binary fields of zero size. 
//            p.Value = new byte[] {0x00};
//          }
#else
          object value = cv.Value;
          if (value.GetType() == typeof(DateTime)) 
            value = ((DateTime)value).ToOADate(); 
          OleDbParameter p = new OleDbParameter(pName, value);
          p.DbType = utils.GetDbType(cv.Column.SqlType);
#endif

          cmd.Parameters.Add(p);

          sDiv = ", ";
        }
        
        cmd.CommandText =  
          "Insert into ["+t.Name+"] ("+sbCols.ToString ()+")"+
          "\nvalues ("+sbVals.ToString()+")";
        ((MSAccessDriver)Driver).LogSqlCommand( "MSAccessPersister.InsertInstanceColumns", cmd );
        try {
          cmd.ExecuteNonQuery();
        }
        catch (Exception) {
          foreach(OleDbParameter p in cmd.Parameters)
            if (!(p.Value is IConvertible))
              break;
          throw;
        }

        if (i==0) {
          cmd.CommandText = "Select @@IDENTITY";
          ((MSAccessDriver)Driver).LogSqlCommand( "MSAccessPersister.InsertInstanceColumns", cmd );
          ID = Convert.ToInt32(cmd.ExecuteScalar());
        }            
      }
      if (ID==0)
        throw new PersisterException("Error on fetching instance ID (identity column).");
      return ID;
    }
    
    /// <summary>
    /// Updates DataObject instance columns.
    /// </summary>
    /// <param name="columnValues">A list of <see cref="ColumnValue"/>s to update.</param>
    /// <param name="tables">An <see cref="Array"/> of all <see cref="Table"/>s related to the class of instance.</param>
    /// <param name="id">Instance ID.</param>
    /// <param name="expectedVersionID">Expected VersionID value.</param>
    /// <returns>New VersionID value.</returns>
    public override void UpdateInstanceColumns(ArrayList columnValues, Table[] tables, long id, int expectedVersionID)
    {
      int cCnt = columnValues.Count;
      if (cCnt==0)
        return;

      FlushDelayedSavepoints();

      sbCmd.Length  = 0;
      sbVals.Length = 0;
      string  sDiv  = "";

      int j = 0;
      Table lastTable = (columnValues[0] as ColumnValue).Column.Table;
      EnsureCommandValid(cmd);
      while (true) 
      {
        ColumnValue cv = null;
        cmd.Parameters.Clear();
        while (j<cCnt) {
          cv = (ColumnValue)columnValues[j++];
          if (cv.Column.Table!=lastTable) {
            j--;
            break;
          }
          string pName = "@P"+j.ToString();
          sbVals.Append(sDiv+"["+cv.Column.Name+"]="+pName);
          
#if MONO
          // We have to use the following 3-stage OleDbParameter creation procedure because 
          // under the Mono if we try to call OleDbParameter(string Name, object Value) constructor and
          // the second parameter is null the OleDbParameter(string Name, OleDbType dbType) constructor
          // will be called and Exception will be thrown.
          OleDbParameter p = new OleDbParameter();
          p.ParameterName = pName;
          p.Value = cv.Value;
          
          p.DbType = utils.GetDbType(cv.Column.SqlType);
//          if (p.Size==0 && p.DbType==DbType.Binary) {
//            // Mono does not permit binary fields of zero size. 
//            p.Value = new byte[] {0x00};
//          }
#else
          object value = cv.Value;
          if (value.GetType()==typeof(DateTime))
            value = ((DateTime)value).ToOADate(); 
          OleDbParameter p = new OleDbParameter(pName, value);
          p.DbType = utils.GetDbType(cv.Column.SqlType);
          if (p.DbType == DbType.Decimal) {
            p.DbType = DbType.String;
            p.Value = value.ToString();
          }
#endif
          
          cmd.Parameters.Add(p);
          sDiv = ", ";
        }
        if (lastTable.RelatedType.BaseType==null) {
          cmd.CommandText =  
            "Update ["+lastTable.Name+"]"+
            "\nset "+sbVals.ToString()+
            "\nwhere "+cID+"=" + id.ToString() + " and "+cVersionId+"=" + expectedVersionID.ToString();
          ((MSAccessDriver)Driver).LogSqlCommand( "MSAccessPersister.UpdateInstanceColumns", cmd );
          int rowcount = cmd.ExecuteNonQuery(); // NOTE:  Access seems to return 0 if the WHERE clause is parameterized, so explicitly include the ID and ExpectedVersionID values
          if (rowcount!=1)
            throw new InstanceVersionChangedException();
        }
        else {
          cmd.CommandText =
            "Update ["+lastTable.Name+"]"+
            "\nset "+sbVals.ToString()+
            "\nwhere "+cID+"=" + id.ToString();

          ((MSAccessDriver)Driver).LogSqlCommand( "MSAccessPersister.UpdateInstanceColumns", cmd );
          int rowcount = cmd.ExecuteNonQuery();// NOTE:  Access seems to return 0 if the WHERE clause is parameterized, so explicitly include the ID value
          if (rowcount!=1)
          {
            throw new InstanceVersionChangedException();
          }
        }
        sbVals.Length = 0;
        sDiv  = "";
        lastTable = cv.Column.Table;
        if (j>=cCnt)
          break;
      }
    }
    
    /// <summary>
    /// Updates VersionID of DataObject instance to <paramref name="newVersionID"/>.
    /// </summary>
    /// <param name="table">Table to update record in.</param>
    /// <param name="id">Instance ID.</param>
    /// <param name="expectedVersionID">Expected VersionID value.</param>
    /// <param name="newVersionID">New VersionID value.</param>
    public override void UpdateInstanceVersion(Table table, long id, int expectedVersionID, int newVersionID)
    {
      FlushDelayedSavepoints();

      EnsureCommandValid(cmd);
      cmd.Parameters.Clear();
      cmd.CommandText = 
        "Update ["+table.Name+"]" +
          " set "+cVersionId+"=" + newVersionID.ToString() +
          " where "+cID+"=" + id.ToString() + " and "+cVersionId+"=" + expectedVersionID.ToString();

      ((MSAccessDriver)Driver).LogSqlCommand( "MSAccessPersister.UpdateInstanceVersion", cmd );
      if (cmd.ExecuteNonQuery()!=1)
        throw new InstanceVersionChangedException();
    }
    
    /// <summary>
    /// Deletes DataObject instance by its ID.
    /// </summary>
    /// <param name="tables">An <see cref="Array"/> of all <see cref="Table"/>s related to the class of instance.</param>
    /// <param name="id">Instance ID.</param>
    /// <param name="expectedVersionID">Expected VersionID value.</param>
    public override void DeleteDataObject(Table[] tables, long id, int expectedVersionID)
    {
      FlushDelayedSavepoints();

      EnsureCommandValid(cmd);
      cmd.Parameters.Clear();
      sbCmd.Length = 0;
      bool bRemoveOnlyDataObjectRow = 
        (Driver.Domain.DatabaseOptions & DomainDatabaseOptions.CreateForeignKeys)!=0;

      cmd.Parameters.Add(new OleDbParameter("@ID",(object)id));
      int tCnt = tables.Length;

      for (int i = 0; i<tCnt; i++) {
        sbCmd.Length = 0;
        Table t = tables[i];
        if (t.RelatedType.BaseType==null) {
          sbCmd.Append(
            "\nDelete from [" + t.Name + "]" +
              "\nwhere " + cID + "=" + id.ToString() + " and " + cVersionId + "=" + expectedVersionID.ToString() + ";");
        }
        else if (!bRemoveOnlyDataObjectRow) {
          sbCmd.Append(
            "\nDelete from [" + t.Name + "]" +
              "\nwhere " + cID + "=" + id.ToString() + ";");
        }
        cmd.CommandText = sbCmd.ToString();
        if (cmd.CommandText.Length > 0) {
          ((MSAccessDriver) Driver).LogSqlCommand("MSAccessPersister.DeleteDataObject", cmd);
          int rowcount = cmd.ExecuteNonQuery();
          if (rowcount!=1)
            throw new InstanceVersionChangedException();
        }
      }

    }
    
    /// <summary>
    /// Locks DataObject instance columns by its ID.
    /// </summary>
    /// <param name="view">View to lock row in.</param>
    /// <param name="id">Instance ID.</param>
    /// <param name="expectedVersionID">Expected VersionID value.</param>
    /// <param name="lockType">Type of lock to aquire.</param>
    public override void LockDataObject(View view, long id, int expectedVersionID, LockType lockType)
    {
      EnsureCommandValid(cmd);
      cmd.Parameters.Clear();
      cmd.CommandText = 
        "Select "+cTypeId+" from ["+view.Name+"] "+TranslateLockTypeToHints(lockType) +
        "\nwhere "+cID+"=" + id.ToString() + " and "+cVersionId+"=" + expectedVersionID.ToString();

      ((MSAccessDriver)Driver).LogSqlCommand( "MSAccessPersister.LockDataObject", cmd );
      if (cmd.ExecuteScalar()==null)
        throw new InstanceVersionChangedException();
    }
    
    private string TranslateLockTypeToHints(LockType lockType)
    {
      return string.Empty;

      /* Access doesn't support WITH hints
      string hint = "FASTFIRSTROW";
      
      if (lockType==LockType.Exclusive)
        hint += ", XLOCK";
      else if (lockType==LockType.Update)
        hint += ", UPDLOCK";
      
      return "with ("+hint+")";
      */
    }
    
    
    // Query

    /// <summary>
    /// Builds <see cref="Query"/> command.
    /// </summary>
    /// <param name="forSubQuery">Indicates whether to preparing a command for subquery.</param>
    /// <param name="idOnly">Indicates whether to include only IDs.</param>
    /// <param name="view">View to fetch records from.</param>
    /// <param name="aliasName">View alias name.</param>
    /// <param name="options">Query options.</param>
    /// <param name="top">Number of rows to fetch, 0 means all.</param>
    /// <param name="joins">Joins descriptor.</param>
    /// <param name="sqlCondition">Condition.</param>
    /// <param name="ftsCondition">Full-text search condition.</param>
    /// <param name="sqlRestriction">Additional restriction.</param>
    /// <param name="sqlOrderBy">Order by expression.</param>
    /// <param name="isDistinct"><see langword="True"/> if a <see cref="QueryOptions.Distinct"/>
    /// was applied; otherwise, <see langword="false"/>.</param>
    /// <param name="ftsResult"><see cref="FtsResult">Full-text search results</see> for non-native driver. </param>
    /// <returns>Fetched columns.</returns>
    public override string BuildQueryCommandText(
      bool forSubQuery, 
      bool idOnly,
      View view, 
      string aliasName,
      QueryOptions options,
      string freeOptions,
      long top, 
      JoinTranslationResult joins, 
      string sqlCondition, 
      FtsCondition ftsCondition,
      string sqlRestriction, 
      string sqlOrderBy,
        PageInfo pageInfo,
      ref bool isDistinct,
      ref FtsResult ftsResult
      )
    {
      string sqlJoin = joins.JoinClause;
      string fullViewName  = "["+view.Name+"]";
      string fullAliasName = "["+aliasName+"]";
      string cFullAliasedAll = fullAliasName+"."+cID+", "+
        " "+fullAliasName+"."+cVersionId+", "+
        " "+fullAliasName+"."+cTypeId+", "+
        " "+fullAliasName+"."+cPermissions+", "+
        " "+fullAliasName+"."+cFastLoadData;
      string cFullAliasedLOD = fullAliasName+"."+cID+", "+
        " "+fullAliasName+"."+cVersionId;
      string sqlOtherFetchColumns = "";
      
      if (ftsCondition!=null) {
        ObjectModel.Type t = Session.domain.Types[typeof (FtRecord)];
        Field f = t.Fields["FtData"];
        Culture fc = ftsCondition.Culture;
        Column c = f.RelatedColumns[fc==null ? 0 : fc.Index];

        if (!(Driver.Domain.FtsDriver is NativeFtsDriver)) {
          string ftsInExpression = ftsResult.ConvertToSqlInExpression();
          if (sqlCondition!="")
            sqlCondition += " and ";
          sqlCondition += " (" + fullAliasName + "." + cID + " in (" + ftsInExpression + "))";
        }
        else {
          if (ftsCondition.Mode==FtsMode.LikeExpression) {
            string likePart =
              utils.QuoteDoubleIdentifier(t.RelatedTable.Name, c.Name) +
                " like " + utils.QuoteString(ftsCondition.Condition);
            if (fc==null) {
              int cCnt = Session.domain.Cultures.Count;
              for (int i = 1; i<cCnt; i++)
                likePart += " or " +
                  utils.QuoteDoubleIdentifier(t.RelatedTable.Name, f.RelatedColumns[i].Name) +
                  " like " + utils.QuoteString(ftsCondition.Condition);
            }
            sqlJoin += " inner join " +
              utils.QuoteIdentifier(t.RelatedTable.Name) + " on ((" + likePart + ") and " +
              fullAliasName + "." + cID + "=" + cFullFtObject + ")";
          }
          else {
            sqlJoin +=
              " inner join " +
                utils.QuoteIdentifier(t.RelatedTable.Name) + " on " +
                fullAliasName + "." + cID + "=" + cFullFtObject +
                " inner join " +
                (ftsCondition.Mode==FtsMode.Condition ? "ContainsTable" : "FreeTextTable") +
                "(" +
                utils.QuoteIdentifier(t.RelatedTable.Name) + ", " +
                (fc!=null ? utils.QuoteIdentifier(c.Name) : "*") + ", " +
                utils.QuoteString(ftsCondition.Condition) +
                (ftsCondition.Top!=0 ? (", " + ftsCondition.Top.ToString()) : "") +
                ") [FullTextSearch-Rowset] on " +
                "[FullTextSearch-Rowset].[KEY]=" + utils.QuoteIdentifier(t.RelatedTable.Name) + "." + cID;
            sqlOtherFetchColumns = ", [FullTextSearch-Rowset].[RANK] as [FullTextRank]";
            if (ftsCondition.OrderByRank) {
              if (sqlOrderBy!="")
                sqlOrderBy = "[FullTextRank], "+sqlOrderBy;
              else
                sqlOrderBy = "[FullTextRank]";
            }
          }
        }
      }

      bool bDistinct  = (options & QueryOptions.Distinct)!=0;
      bool bCount     = (options & QueryOptions.Count)!=0;
      bool bLOD       = (options & QueryOptions.LoadOnDemand)!=0;
      bool bOrdered   = sqlOrderBy!="" && !bCount;
      isDistinct = bDistinct && (bCount || (bLOD && !bOrdered && sqlOtherFetchColumns==""));

      string sFieldList;
      if (bCount) {
        if (isDistinct)
          sFieldList = "count(distinct "+fullAliasName+"."+cID+")";
        else
          sFieldList = "count("+fullAliasName+"."+cID+")";
      } else if (idOnly) {
        if (isDistinct)
          sFieldList = "distinct "+fullAliasName+"."+cID;
        else
          sFieldList = fullAliasName+"."+cID;
      } else {
        if (isDistinct)
          sFieldList = cFullAliasedLOD;
        else
          sFieldList = (bLOD ? cFullAliasedLOD : cFullAliasedAll) + sqlOtherFetchColumns;
      }
      
      string cText =
        "Select" +
          ((isDistinct && !bCount) ? " distinct" : "") +
          ((top>0) ? (" top "+top.ToString()) : "") +
          " "+sFieldList +
        " from "+ joins.FromClausePrefix + " " + fullViewName+" "+fullAliasName + 
          TranslateQueryOptionsToHints(options);
      if (sqlJoin!="")  
        cText += "\n  "+sqlJoin;
      
      if (sqlCondition!="") {
        if (sqlRestriction!="")
          cText += "\nwhere ("+sqlCondition+") and ("+sqlRestriction+")";
        else
          cText += "\nwhere ("+sqlCondition+")";
      }
      else {
        if (sqlRestriction!="")
          cText += "\nwhere ("+sqlRestriction+")";
      }
          
      if (sqlOrderBy!="" && ((options & QueryOptions.Count)==0))
        cText += "\norder by "+sqlOrderBy;
        
      return cText;  
    }
    
    /// <summary>
    /// Translates <see cref="QueryOptions"/> to hints.
    /// </summary>
    /// <param name="options">Options to translate.</param>
    /// <returns>A string containing hints corresponding to specified
    /// <paramref name="options"/>.</returns>
    internal static string TranslateQueryOptionsToHints(QueryOptions options)
    {
      return string.Empty; 

      /* Access doesn't support hints
      string hint = "";
      
      if ((options & QueryOptions.SkipLocked)!=0)
        hint += ", READPAST";
      if ((options & QueryOptions.FastFirst)!=0)
        hint += ", FASTFIRSTROW";
      
      if ((options & QueryOptions.OnReadUncommitted)!=0)
        throw new InvalidOperationException("QueryOptions-specified isolation level should be ReadCommitted or higher.");
      else if ((options & QueryOptions.OnReadCommitted)!=0)
        hint += ", READCOMMITTED";
      else if ((options & QueryOptions.OnRepeatableRead)!=0)
        hint += ", REPEATABLEREAD";
      else if ((options & QueryOptions.OnSerializable)!=0)
        hint += ", SERIALIZABLE";
      
      if ((options & QueryOptions.LockRows)!=0)
        hint += ", ROWLOCK";
      if ((options & QueryOptions.LockPages)!=0)
        hint += ", PAGLOCK";
      if ((options & QueryOptions.LockTables)!=0)
        hint += ", TABLOCK";
      
      if ((options & QueryOptions.ForExclusive)!=0)
        hint += ", XLOCK";
      else if ((options & QueryOptions.ForUpdate)!=0)
        hint += ", UPDLOCK";
      
      if (hint.Length>0)
        return " with ("+hint.Substring(2)+")";
      else
        return "";
      */
    }
    
    
    // Command execution
    
    /// <summary>
    /// Executes the command.
    /// </summary>
    /// <param name="command">Command to execute.</param>
    /// <returns><see cref="IDataReader"/> containing result set.</returns>
    public override IDataReader ExecuteReader(IDbCommand command)
    {
      ((MSAccessDriver)Driver).LogSqlCommand( "MSAccessPersister.ExecuteReader", command as OleDbCommand );
      return command.ExecuteReader();
    }

    /// <summary>
    /// Executes the command.
    /// </summary>
    /// <param name="command">Command to execute.</param>
    /// <param name="top">Number of rows to fetch, 0 means all.</param>
    /// <returns><see cref="ArrayList"/> only DataObject-related columns of result set.</returns>
    public override ArrayList ExecuteAndFetchDataObjects(IDbCommand command, long top)
    {
      ArrayList lIn  = new ArrayList();
      IDataReader r  = null;
      int fieldCount = 0;
      TransactionContext transactionContext = Session.TransactionContext;
      
      ((MSAccessDriver)Driver).LogSqlCommand( "MSAccessPersister.ExecuteAndFetchDataObjects", command as OleDbCommand );
      using (r = command.ExecuteReader()) {
        if (top==0) {
          while (r.Read()) {
            if (fieldCount==0)
              fieldCount = r.FieldCount;
#if MONO
            long id = Convert.ToInt32(r.GetValue(0));
#else
            long id = r.GetInt32(0);
#endif
            int  versionId = r.GetInt32(1);
            DataObjectIdentificationInfo info = IsObjectCached(Session, id, versionId, transactionContext);
            if (info==null) {
              if (fieldCount<5)
                info = new DataObjectValidationInfo(id, versionId, transactionContext);
              else
                info = new DataObjectInstantiationInfo(
                  id, r.GetInt32(2), versionId,
                  r[3] as byte[],
                  r[4] as byte[],
                  transactionContext);
              TryCacheIdentificationInfo(Session, info);
            }
            lIn.Add(info);
          }
        }
        else {
          while (r.Read() && (top--)>0) {
            if (fieldCount==0)
              fieldCount = r.FieldCount;
#if MONO
            long id = Convert.ToInt32(r.GetValue(0));
#else
            long id = r.GetInt32(0);
#endif
            int  versionId = r.GetInt32(1);
            DataObjectIdentificationInfo info = IsObjectCached(Session, id, versionId, transactionContext);
            if (info==null) {
              if (fieldCount<5)
                info = new DataObjectValidationInfo(id, versionId, transactionContext);
              else
                info = new DataObjectInstantiationInfo(
                  id, r.GetInt32(2), versionId,
                  r[3] as byte[],
                  r[4] as byte[],
                  transactionContext);
              TryCacheIdentificationInfo(Session, info);
            }
            lIn.Add(info);
          }
        }
        r.NextResult(); // Bug workaround. 
        // Read ms-help://MS.MSDNQTR.2003APR.1033/enu_kbwebdatanetkb/webdatanetkb/316667.htm
        r.Close();
        return lIn;
      }
    }

    /// <summary>
    /// Executes the command.
    /// </summary>
    /// <param name="command">Command to execute.</param>
    /// <returns>Execution result.</returns>
    public override object ExecuteScalar(IDbCommand command)
    {
      ((MSAccessDriver)Driver).LogSqlCommand( "MSAccessPersister.ExecuteScalar", command as OleDbCommand );
      return command.ExecuteScalar();
    }

    /// <summary>
    /// Executes the command.
    /// </summary>
    /// <param name="command">Command to execute.</param>
    public override void ExecuteNonQuery(IDbCommand command)
    {
      ((MSAccessDriver)Driver).LogSqlCommand( "MSAccessPersister.ExecuteNonQuery", command as OleDbCommand );
      command.ExecuteNonQuery();
    }
    
    
    // Constructor

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="session"><see cref="Session"/>, to which Persister belongs.</param>
    public MSAccessPersister(Session session): base(session)
    {
      cmd   = (OleDbCommand)Driver.CreateCommand(Connection);
      utils = Driver.Utils;
      SetPersisterForCollections(new MSAccessPersisterForCollections(this));

      ObjectModel.Type t = Driver.Domain.ObjectModel.Types[typeof(DataObject)];
      tDataObject   = "["+t.RelatedTable.Name+"]";
      cID           = "["+t.Fields["ID"].RelatedColumns[0].Name+"]";
      cTypeId       = "["+t.Fields["TypeID"].RelatedColumns[0].Name+"]";
      cVersionId    = "["+t.Fields["VersionID"].RelatedColumns[0].Name+"]";
      cPermissions  = "["+t.Fields["Permissions"].RelatedColumns[0].Name+"]";
      cFastLoadData = "["+t.Fields["FastLoadData"].RelatedColumns[0].Name+"]";
      cAll          = cID+", "+cTypeId+", "+cVersionId+", "+cPermissions+", "+cFastLoadData;

      t = Driver.Domain.ObjectModel.Types[typeof(FtRecord)];
      cFullFtObject = "["+t.RelatedTable.Name+"].["+t.Fields["FtObject"].RelatedColumns[0].Name+"]";
    }
  }
}
