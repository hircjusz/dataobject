// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Runtime.Serialization;

namespace DataObjects.NET.Exceptions
{
  /// <summary>
  /// Thrown by <see cref="Query"/> and <see cref="SqlQuery"/> on 
  /// different SQL syntax related errors.
  /// </summary>
  [Serializable]
  public class InvalidSqlException: PersisterException
  {
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    public InvalidSqlException(): base("Invalid SQL expression.") {}
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="message">Error message.</param>
    public InvalidSqlException(string message): base(message) {}

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="message">Error message.</param>
    /// <param name="sql">SQL code containing error.</param>
    /// <param name="pos">Error position.</param>
    public InvalidSqlException(string message, string sql, int pos): 
      base(
        "Invalid SQL expression ("+message+"): \""+
          sql.Substring(0,pos)+
          "[Error]"+
          sql.Substring(pos)+"\".") {}

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="sql">SQL code containing error.</param>
    /// <param name="pos">Error position.</param>
    public InvalidSqlException(string sql, int pos): 
      base(
        "Invalid SQL expression: \""+
          sql.Substring(0,pos)+
          "[Error]"+
          sql.Substring(pos)+"\".") {}
    
    /// <summary>
    /// Deserialization constructor.
    /// </summary>
    /// <param name="info"><see cref="SerializationInfo"/> object.</param>
    /// <param name="context"><see cref="StreamingContext"/> object.</param>
    protected InvalidSqlException(SerializationInfo info, StreamingContext context):
      base(info, context)
    {
    }
  }
}
