// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;

namespace DataObjects.NET
{
  internal sealed class ConnectionInfoHelper
  {
    const int    Basis  = 6;
    const string Chars  = "0123456789QWERTYUIOPASDFGHJKLZXCVBNM@qwertyuiopasdfghjklzxcvbnm#";
    static bool[][] InvChars;
    const string SplitStr  = "-";
    
    public static object StripUnicodeChars(string data)
    {
      if (InvChars==null)
        Init();
      int l = data.Length;
      BitArray bits = new BitArray(l*Basis,false);
      int iBit = 0;
      int i = 0;
      int sl = SplitStr.Length;
      while (i<l) {
        int c = data[i++];
        if (c<0 || c>127)
          return null;
        bool[] bools = InvChars[c];
        if (bools==null)
          return null;
        if (bools.Length==0)
          continue;
        for (int j = 0; j<Basis; j++)
          bits[iBit++] = bools[j];
      }
      bits.Length = iBit;
      l = bits.Length/8;
      if (l*8!=bits.Length) {
        for (int t = l*8; t<bits.Length; t++)
          if (bits[t])
            return null;
        bits.Length = l*8;
      }
      if ((iBit-bits.Length)>=Basis)
        return null;
      byte[] bresult = new byte[l];
      bits.CopyTo(bresult,0);
      return bresult;
    }
    
    static void Init()
    {
      InvChars = new bool[128][];
      for (int i = 0; i<Chars.Length; i++)
      {
        int c = Convert.ToInt32(Chars[i]);
        if (c<0 || c>127)
          throw new DataObjectsDotNetException("Internal error.");
        BitArray bits = new BitArray(BitConverter.GetBytes(i));
        bool[] bools = new bool[Basis];
        for (int j = 0; j<Basis; j++)
          bools[j] = bits[j];
        InvChars[c] = bools;
      }
      for (int i = 0; i<SplitStr.Length; i++)
      {
        int c = Convert.ToInt32(SplitStr[i]);
        if (c<0 || c>127)
          throw new DataObjectsDotNetException("Internal error.");
        bool[] bools = new bool[0];
        InvChars[c] = bools;
      }
    }
  }
}
