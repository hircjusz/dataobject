// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.IO;
using DataObjects.NET.Internals.SharpZipLib.Zip.Compression; 
using DataObjects.NET.Attributes;

namespace DataObjects.NET.Helpers
{
  /// <summary>
  /// A <see cref="IPropertyStorageValueModifier">property storage value modifier</see> that
  /// compresses internal property value before
  /// persisting it to the database and decomresses
  /// it back on fetches.
  /// <seealso cref="StorageValueModifierAttribute"/>
  /// </summary>
  /// <remarks>
  /// <see cref="Compressor"/> can be used to compress persistent properties
  /// of type <see langword="byte[]"/> (managed by <see cref="DataObjects.NET.ObjectModel.BlobField"/>) 
  /// or of type <see cref="Object"/> (managed by <see cref="DataObjects.NET.ObjectModel.ObjectField"/>).
  /// See <see cref="StorageValueModifierAttribute"/> also.
  /// </remarks>
  [Serializable]
  public class Compressor: IPropertyStorageValueModifier
  {
    private CompressionMethod compressionMethod = CompressionMethod.Zip;

    /// <summary>
    /// Gets the <see cref="CompressionMethod">method</see> of compression.
    /// Default value is <see cref="CompressionMethod">CompressionMethod.Zip</see>.
    /// </summary>
    public  CompressionMethod CompressionMethod {
      get {
        return compressionMethod;
      }
    }

    private CompressionLevel compressionLevel = CompressionLevel.Fastest;


    /// <summary>
    /// Gets the <see cref="CompressionLevel">level</see> of compression.
    /// Default value is <see cref="CompressionLevel">CompressionLevel.Fastest</see>.
    /// </summary>
    public  CompressionLevel CompressionLevel{
      get {
        return compressionLevel;
      }
    }
  
    /// <summary>
    /// Compresses value that DataObjects.NET is going to persist to
    /// the storage.
    /// </summary>
    /// <param name="session"><see cref="Session"/> where conversion occurs.</param>
    /// <param name="dataObject"><see cref="DataObject"/> for which we  store a property.</param>
    /// <param name="propertyName">Property name.</param>
    /// <param name="culture">Property culture.</param>
    /// <param name="value">Internal value.</param>
    /// <returns>Value to be stored into database.</returns>
    /// <remarks>
    /// <para>
    /// Remember that value passed to this method may differ from
    /// value returned by <see cref="DataObject.GetProperty"/> method.
    /// For example, any <see cref="Object"/> property is stored
    /// as <see cref="Byte"/> <see cref="Array"/>.
    /// </para>
    /// </remarks>
    public object ConvertToStorageValue(Session session, DataObject dataObject, string propertyName, Culture culture, object value)
    {
      return ConvertToStorageValue(value);
    }

    /// <summary>
    /// Decompresses value fetched by DataObjects.NET from the storage.
    /// </summary>
    /// <param name="session"><see cref="Session"/> where conversion occurs.</param>
    /// <param name="dataObject"><see cref="DataObject"/> for which we  load a property value.</param>
    /// <param name="propertyName">Property name.</param>
    /// <param name="culture">Property culture.</param>
    /// <param name="value">Loaded value.</param>
    /// <returns>Value to be stored in <see cref="DataObject"/>.</returns>
    /// <remarks>
    /// <para>
    /// Remember that value passed to this method may differ from
    /// value returned by <see cref="DataObject.GetProperty"/> method.
    /// For example, any <see cref="Object"/> property is stored
    /// as <see cref="Byte"/> <see cref="Array"/>.
    /// </para>
    /// </remarks>
    public object ConvertFromStorageValue(Session session, DataObject dataObject, string propertyName, Culture culture, object value)
    {
      return ConvertFromStorageValue(value);
    }

    private object ConvertToStorageValue(object value)
    {
      byte[] data = (byte[])value;
      if (data==null || data.Length==0)
        return data;
        
      CompressionMethod cm = compressionMethod;
      if (compressionLevel==CompressionLevel.None)
        cm = CompressionMethod.None;

      using (MemoryStream ms = new MemoryStream(256)) {
        ms.WriteByte((byte)cm);
        switch (cm) {
        case CompressionMethod.None:
          ms.Write(data, 0, data.Length);
          break;
        case CompressionMethod.Zip:
          int level;
          if (CompressionLevel==CompressionLevel.Fast || CompressionLevel==CompressionLevel.Fastest) {
            level = Deflater.BEST_SPEED; 
          }
          else {
            if (CompressionLevel==CompressionLevel.Normal)
              level = Deflater.DEFAULT_COMPRESSION;
            else
              level = Deflater.BEST_COMPRESSION; 
          }

          Deflater deflater = new Deflater(level);
          deflater.SetInput(data, 0, data.Length);
          deflater.Finish();
          byte[] buffer = new byte[1024];
          while (!deflater.IsFinished) 
          {
            int l = deflater.Deflate(buffer);
            ms.Write(buffer, 0, l);
          }
          break;
        default:
          throw new InvalidOperationException("Unknown compression method.");
        }
        return ms.ToArray();
      }
    }
    
    private object ConvertFromStorageValue(object value)
    {
      byte[] data = (byte[])value;
      if (data==null || data.Length==0)
        return data;

      CompressionMethod cm = compressionMethod;
      try {
        cm = (CompressionMethod)data[0];
      }
      catch (Exception e) {
        throw new InvalidOperationException("Unknown compression method.",e);
      }

      int len = data.Length-1;
      switch (cm) {
      case CompressionMethod.None:
        byte[] ret = new byte[len];
        Array.Copy(data, 1, ret, 0, len);
        return ret;
      case CompressionMethod.Zip:
        Inflater inflater = new Inflater();
        inflater.SetInput(data, 1, len);
        using (MemoryStream ms = new MemoryStream(len>256 ? len : 256)) 
        {
          byte[] buffer = new byte[1024];
          while (!inflater.IsFinished) 
          {
            int l = inflater.Inflate(buffer);
            ms.Write(buffer, 0, l);
          }
          return ms.ToArray();
        }
      default:
        throw new InvalidOperationException("Unknown compression method.");
      }
    }

    // Constructors

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    public Compressor()
    {
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="compressionMethod">Compression method.</param>
    public Compressor(CompressionMethod compressionMethod)
    {
      this.compressionMethod = compressionMethod;
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="compressionLevel">The level of compression.</param>
    public Compressor(CompressionLevel compressionLevel)
    {
      this.compressionLevel  = compressionLevel;
    }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="compressionMethod">Compression method.</param>
    /// <param name="compressionLevel">The level of compression.</param>
    public Compressor(CompressionMethod compressionMethod, CompressionLevel compressionLevel)
    {
      this.compressionMethod = compressionMethod;
      this.compressionLevel  = compressionLevel;
    }
  }
}
