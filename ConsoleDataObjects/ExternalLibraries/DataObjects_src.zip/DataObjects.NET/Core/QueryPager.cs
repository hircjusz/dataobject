// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;
using System.Diagnostics;

namespace DataObjects.NET
{
  /// <summary>
  /// Provides paging functionality for any <see cref="Query"/> or <see cref="SqlQuery"/>
  /// - allows to browse large result sets page-by-page.
  /// </summary>
  public class QueryPager: Pager
  {
    private const int         MinimalTopValue = 16;
    private QueryBase         query;
    private QueryPagerOptions options = QueryPagerOptions.Default;
    private PageInfo pageInfo;
    
    /// <summary>
    /// Gets <see cref="Query"/> or <see cref="SqlQuery"/> object
    /// which result set is browsed by the pager.
    /// </summary>
    public QueryBase Query {
      get {
        return query;
      }
    }
    
    /// <summary>
    /// Gets or sets paging options.
    /// </summary>
    public QueryPagerOptions Options {
      get {
        return options;
      }
      set {
        if (((value & QueryPagerOptions.GrowExpotentially)!=0)==
            ((value & QueryPagerOptions.GrowPageByPage)!=0))
          throw new ArgumentException(
            "Options should include just one of GrowExpotentially\\GrowPageByPage flags.", "value");
        options = value;
      }
    }
    
    /// <summary>
    /// Returns total count of items when <see cref="Pager.TotalCount"/>
    /// isn't specified explicitely.
    /// </summary>
    /// <returns>Total count of items.</returns>
    protected override int GetTotalCount()
    {
      int top = (int)Query.Top;
      int totalCount = (int)Query.ExecuteCount();
      if (top<=0)
        return totalCount;
      else
        return top<totalCount ? top : totalCount;
    }
    
    /// <summary>
    /// Returns <see langword="true"/> if <see cref="Pager.BaseCollection"/> 
    /// item with specified <paramref name="index"/> is loaded (available); 
    /// otherwise, <see langword="false"/>.
    /// <seealso cref="Pager.BaseCollection"/>
    /// <seealso cref="Pager.EnsureItemAvailability"/>
    /// <seealso cref="LoadBaseCollectionRange"/>
    /// </summary>
    /// <param name="index">Absolute index of item to check.</param>
    /// <returns><see langword="True"/> if <see cref="Pager.BaseCollection"/> 
    /// item with specified <paramref name="index"/> is loaded (available); 
    /// otherwise, <see langword="false"/>.</returns>
    protected override bool IsBaseCollectionItemLoaded(int index)
    {      
      if (BaseCollection==null)
        return false;
      int cnt = BaseCollection.Count;
      if (index>=cnt)
        return false;
      if ((Options & QueryPagerOptions.PreLoadPages)==0)
        return true;
      int ps = PageSize;
      if (ps==0)
        ps = 1;
      int pageStart = (index/ps)*ps;
      if (Query.ResultType==QueryResultType.Instances) {
        QueryResult qr = (QueryResult)BaseCollection;
        int pageEnd = (pageStart+ps)>cnt ? (cnt-1) : (pageStart+ps-1);
        if (!Query.Session.Cache.IsObjectCached(qr.GetID(pageEnd))) {
//          Trace.WriteLine(String.Format(
//            "QueryPager: Preloading on accessing index {0}", index));
          long[] toPreLoad = qr.GetIDs(pageStart,pageEnd-pageStart+1);
          Query.Session.Preload(toPreLoad);
        }
      }
      return true;
    }
    
    /// <summary>
    /// Loads a range of items into <see cref="Pager.BaseCollection"/>.
    /// Override this method to implement custom page loading behavior.
    /// <seealso cref="Pager.BaseCollection"/>
    /// <seealso cref="Pager.EnsureItemAvailability"/>
    /// <seealso cref="Pager.IsBaseCollectionItemLoaded"/>
    /// </summary>
    /// <param name="startIndex">Absolute index of first item to load.</param>
    /// <param name="requiredItemIndex">Index of item that should be definitely loaded.</param>
    /// <param name="count">Number of items to load.</param>
    protected override void LoadBaseCollectionRange(int startIndex, int count, int requiredItemIndex)
    {
      if (count < 1)
        throw new ArgumentOutOfRangeException("count", count,
          "Count should be greater then or equal to 1.");                    
      
      int collectionCount = BaseCollection==null ? 0 : BaseCollection.Count;
      if (collectionCount>=startIndex+count)
        return;                  
        
      int top;
      if ((Options & QueryPagerOptions.GrowExpotentially)!=0) {
        top = (collectionCount>MinimalTopValue) ? collectionCount : MinimalTopValue;
        while (top<(startIndex+count))
          top *= 2;
      }
      else
        top = startIndex+count;
        
//      Trace.WriteLine(String.Format(
//        "QueryPager: Loading range 0-{0}", top-1));

    if (Query.ResultType == QueryResultType.Instances)
    {
        if (pageInfo == null)
            pageInfo = new PageInfo(PageSize);
        pageInfo.PageNum = Page;
        SetBaseCollection(Query.Execute(top, Query.Options | QueryOptions.LoadOnDemand, pageInfo));
    }
    else
        SetBaseCollection(Query.ExecuteValueTypeQueryResult(top));
      if (!IsBaseCollectionItemLoaded(requiredItemIndex))
        throw new InvalidOperationException(String.Format(
          "Can't load item with absolute index {0}.", requiredItemIndex));
    }
    
    /// <summary>
    /// Reloads pager
    /// </summary>
    public override void Reload()
    {
      SetBaseCollection(null);
      base.Reload();
    }

    
    // Constructors

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="query">A <see cref="Query"/> or <see cref="SqlQuery"/>
    /// object which result should be browsed page-by-page.</param>
    /// <param name="pageSize">Page size.</param>
    /// <param name="options">Paging options.</param>
    public QueryPager(QueryBase query, int pageSize, QueryPagerOptions options): base()
    {                          
      if (query==null)
        throw new ArgumentNullException("query");
      this.query = query;
      Options  = options;
      PageSize = pageSize;
     }

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="query">A <see cref="Query"/> or <see cref="SqlQuery"/>
    /// object which result should be browsed page-by-page.</param>
    /// <param name="pageSize">Page size.</param>
    public QueryPager(QueryBase query, int pageSize): this(query, pageSize, QueryPagerOptions.Default)
    {
    }
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="query">A <see cref="Query"/> or <see cref="SqlQuery"/>
    /// object which result should be browsed page-by-page.</param>
    /// <param name="options">Paging options.</param>
    public QueryPager(QueryBase query, QueryPagerOptions options): this(query, DefaultPageSize, options)
    {
    }
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="query">A <see cref="Query"/> or <see cref="SqlQuery"/>
    /// object which result should be browsed page-by-page.</param>
    public QueryPager(QueryBase query): this(query, DefaultPageSize, QueryPagerOptions.Default)
    {
    }
  }
}
