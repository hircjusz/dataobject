// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Reflection;

namespace DataObjects.NET.Attributes
{
  /// <summary>
  /// Base class for <see cref="CorrectorAttribute"/>, <see cref="ValidatorAttribute"/>,
  /// <see cref="TypeModifierAttribute"/> and <see cref="StorageValueModifierAttribute"/>.
  /// Each of these attributes allows to associate a custom type of object
  /// with some <see cref="DataObject"/> property.
  /// </summary>
  [Serializable]
  public abstract class AssociatedObjectAttribute: DataObjectAttribute
  {
    private Type associatedObjectType;
    /// <summary>
    /// Gets or sets the <see cref="Type"/> of associated object.
    /// </summary>
    public Type AssociatedObjectType {
      get {return associatedObjectType;}
      set {associatedObjectType = value;}
    }

    private object[] constructorArguments = new object[] {};
    /// <summary>
    /// Gets or sets an <see cref="Array"/> of arguments 
    /// to pass to the <see cref="AssociatedObjectType"/>
    /// constructor (see <see cref="CreateAssociatedObject"/> method).
    /// </summary>
    public object[] ConstructorArguments {
      get {return constructorArguments;}
      set {constructorArguments = value;}
    }
    
    /// <summary>
    /// Returns a new instance of <see cref="AssociatedObjectType"/>
    /// created by one of its constructors (that is compatible
    /// with <see cref="ConstructorArguments"/>).
    /// </summary>
    /// <returns>New instance of <see cref="AssociatedObjectType"/>
    /// created by one of its constructors.</returns>
    public object CreateAssociatedObject()
    {
      object[] cArgs = constructorArguments;
      if (cArgs==null)
        cArgs = new object[0];
      try {
        return associatedObjectType.InvokeMember(null,
          BindingFlags.DeclaredOnly | 
          BindingFlags.Public | BindingFlags.NonPublic | 
          BindingFlags.Instance | BindingFlags.CreateInstance,
          null, null, cArgs);
      }
      catch (TargetInvocationException e) {
        throw e.InnerException;
      }
    }

    
    // Constructors

    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="associatedObjectType"><see cref="Type"/> of associated object.</param>
    /// <param name="constructorArguments">An <see cref="Array"/> of arguments 
    /// to pass to the <paramref name="associatedObjectType"/> constructor.</param>
    protected AssociatedObjectAttribute(Type associatedObjectType, params object[] constructorArguments): 
      base()
    {
      this.associatedObjectType = associatedObjectType;
      if (constructorArguments!=null)
        this.constructorArguments = constructorArguments;
    }
    
    /// <summary>
    /// Initializes a new instance of this class.
    /// </summary>
    /// <param name="associatedObjectType"><see cref="Type"/> of associated object.</param>
    protected AssociatedObjectAttribute(Type associatedObjectType)
    {
      this.associatedObjectType = associatedObjectType;
    }
  }
}
