// This source file is a part of DataObjects.NET
// Copyright (C) 2003-2005 X-tensive.com, INLINE.
// All rights reserved.
// For conditions of distribution and use, see license.

using System;
using System.Collections;
using DataObjects.NET;
using DataObjects.NET.ObjectModel;

namespace DataObjects.NET.Data.CodeManage
{
  /// <summary>
  /// Code manager that is used in runtime.
  /// </summary>
  internal class RuntimeCodeManager: CodeManagerBase
  {
    private bool isInitialized = false;
    private Model model;
    private IInterfaceDescriptor[] interfaces;
    private IClassDescriptor[] classes;
    private IClassDescriptor root;
    private Hashtable interfaceDescriptorByName;
    private Hashtable derivedClassesByName;
    
    /// <summary>
    /// Gets object model.
    /// </summary>
    internal Model ObjectModel {
      get {
        return model;
      }
    }
  
    /// <summary>
    /// Returns an array of available interface descriptors.
    /// </summary>
    /// <returns>An array of available interface descriptors.</returns>
    internal protected override IInterfaceDescriptor[] GetInterfaces()
    {
      EnsureInitialized();
      return interfaces;
    }
    
    /// <summary>
    /// Returns an array of available class descriptors.
    /// </summary>
    /// <returns>An array of available class descriptors.</returns>
    internal protected override IClassDescriptor[] GetClasses()
    {
      EnsureInitialized();
      return classes;
    }
    
    /// <summary>
    /// Returns a descriptor of a root class.
    /// </summary>
    /// <returns>Returns a descriptor of a root class.</returns>
    internal protected override IClassDescriptor GetRoot()
    {
      EnsureInitialized();
      return root;
    }
    
    /// <summary>
    /// Returns interface descriptor by interface full name.
    /// </summary>
    /// <param name="fullName">Interface full name.</param>
    /// <returns>Interface descriptor by interface full name.</returns>
    internal IInterfaceDescriptor GetInterface(string fullName)
    {
      return (IInterfaceDescriptor)interfaceDescriptorByName[fullName];
    }
    
    /// <summary>
    /// Returns a list of derived classes' descriptors by class full name.
    /// </summary>
    /// <param name="fullName">Class full name.</param>
    /// <returns>Class descriptor by class full name.</returns>
    internal ArrayList GetDerivedClasses(string fullName)
    {
      return (ArrayList)derivedClassesByName[fullName];
    }
    
    private void FillClassesList(ArrayList list, IClassDescriptor cd)
    {
      list.Add(cd);
      foreach (IClassDescriptor childClass in cd.DerivedClasses)
        FillClassesList(list, childClass);
    }
    
    private void EnsureInitialized()
    {
      if (!isInitialized) {
        interfaceDescriptorByName = new Hashtable();
        derivedClassesByName = new Hashtable();
        
        foreach (ObjectModel.Type tp in model.Types) {
          if (!tp.IsInterface) {
            ObjectModel.Type baseType = tp.BaseType;
            if (baseType!=null) {
              string baseTypeName = baseType.SourceType.FullName;
              if (!derivedClassesByName.ContainsKey(baseTypeName))
                derivedClassesByName.Add(baseTypeName, new ArrayList());
              ((ArrayList)derivedClassesByName[baseTypeName]).Add(tp);
            }
          }
        }
        
        ArrayList interfacesList = new ArrayList();
        foreach (ObjectModel.Type tp in model.Types) {
          if (tp.IsInterface) {
            InterfaceDescriptor id = new InterfaceDescriptor(tp, this);
            interfacesList.Add(id);
            interfaceDescriptorByName[id.FullName] = id;
          }
        }
        interfaces = (IInterfaceDescriptor[])interfacesList.ToArray(typeof(InterfaceDescriptor));
        foreach (InterfaceDescriptor inter in interfaces)
          inter.Runtime_EnsureFillImplementedInterfaces();
        
        root = new ClassDescriptor(null, ObjectModel.Types[typeof(DataObjects.NET.DataObject)], this);

        ArrayList classesList = new ArrayList();
        FillClassesList(classesList, root);
        classes = (IClassDescriptor[])classesList.ToArray(typeof(ClassDescriptor));
        
        isInitialized = true;
      }
    }
    
    /// <summary>
    /// Initializes a new instance of the <see cref="RuntimeCodeManager"/> class.
    /// </summary>
    /// <param name="model"><see cref="Model"/>.</param>
    internal RuntimeCodeManager(Model model)
    {
      if (model==null)
        throw new ArgumentNullException("model");
      this.model = model;
    }
  }
}
